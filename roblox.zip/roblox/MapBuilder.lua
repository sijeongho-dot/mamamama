--[[
MapBuilder.lua - assembles the whole dino game map in Roblox Studio.

How to use: paste this whole file into the Studio Command Bar and press Enter once.
Running it again is safe: it deletes Workspace.Map, clears the terrain area it owns and
builds everything again.

- Ground, paths and borders are Parts and Terrain (no meshes). Every part is Anchored.
- The ground looks like LEGO bricks: every floor part is shiny plastic with studs on top (the
  classic Roblox Studs surface, one stud per stud of size): a green baseplate under the whole map
  (there is no terrain grass floor at all),
  and the round floors (battlefield band, mineral ring, walkway, plaza) built from brick rows, so
  their edges step like a LEGO circle. The terrain stays only for the hills outside the wall.
- Removes the place template's own grey "Baseplate" part (Workspace.Baseplate): it sits exactly at
  the ground height and would cover the LEGO floor with its grid.
- Blender models are cloned from ServerStorage.Assets by object name (Zone_KeyAltar,
  Base_Shop, ...). They may sit anywhere inside Assets, e.g. inside the Base_Set / Center_Set
  models the importer makes from exports/Base_Set.fbx and exports/Center_Set.fbx.
  Missing models are skipped and listed in the Output window.
- If the Assets folder is misnamed ("assets", extra spaces) or elsewhere (ReplicatedStorage,
  Workspace, a sub folder), it is still used and the Output window says where it was found;
  if there is none, the Output window lists what ServerStorage holds.
- Run it in edit mode, not while playing (it stops and says so). Clear the Command Bar before pasting.
- Turns off the terrain's grass decoration (tall grass blades would hide the low ground parts).
- +Y is up, the map center is (0, 0, 0), units are studs. Compass: north = -Z, east = +X.

Layout (distance from the center; twice as wide as the 1.5x layout, plots and plaza keep their size):
    0-30    key zone plaza: Zone_KeyAltar in the middle, Zone_Leaderboard against its north rim facing the center
    30-45   stone walkway ring joining the paths
    45-360  mineral ring (dirt): 750 invisible OreSpawns points, evenly spread (no zones); rocks and
            some trees out on it (FieldDecor)
    360     battlefield edge: orange band + flags, invisible "Battlefield" cylinder (r 360, h 60)
    470     8 bases (Base1-Base8), plots 210 wide x 165 deep, entrances facing the center
            (fronts about 20 studs past the battlefield band)
    0-760   LEGO baseplate; stone paths from each base entrance to the walkway; trees and rocks
    760+    terrain hills and trees, invisible wall at radius 760

Inside a plot, "front" is the entrance side and left / right are as seen by a player walking in.
Front strip: deposit bin (middle), shop (left), team spawn (right). Behind it the plot is split
by a low fence: the defense field on the right (arena + spawn portal), the farm field on the
left (farm pen), each with a sign part at its entrance (DefenseSign, FarmSign).
]]

-- the whole script is one block: its locals are freed at the end, so pasting it into the Command Bar
-- more than once (old text left in the bar) does not run out of local variables
do
	local Workspace = game:GetService("Workspace")
	local ServerStorage = game:GetService("ServerStorage")
	local ReplicatedStorage = game:GetService("ReplicatedStorage")
	local Terrain = Workspace.Terrain

	if game:GetService("RunService"):IsRunning() then -- while playing, changes vanish and ServerStorage may look empty
		warn("[MapBuilder] 플레이(테스트) 중입니다. 플레이를 멈추고 편집 상태에서 다시 실행하세요.")
		return
	end

	-- ---------------------------------------------------------------------------
	-- Settings
	-- ---------------------------------------------------------------------------

	-- sizes of the map layout (Config.Map holds the same numbers for game code); flags, fences,
	-- signs and spawns are sized for players and do not grow with the map
	local MAP_R = 760 -- playable radius (invisible wall); (was 960) the bases came in, so the wall did too
	local KEY_R, WALK_R = 30, 45 -- key zone plaza, walkway ring
	local RING_IN, RING_OUT = 45, 360 -- mineral ring; RING_OUT is also the battlefield radius (was 180)
	local BAND_W, FLAG_STEP, BF_HEIGHT = 6, 20, 60
	local BASE_COUNT, BASE_R = 8, 470 -- (was 690: 250 studs of empty field between the minerals and the bases)
	local PLOT_W, PLOT_D = 210, 165 -- plot width (across) and depth (entrance to back)
	local FIELD_V = 60 -- depth where the two fields start; the divider fence runs from here to the back
	local BASE_ANGLE0 = 22.5 -- compass angle of Base1 (0 = north); keeps every base off the leaderboard's back
	local ENTRANCE_W, PATH_W = 15, 18
	local PATH_END = BASE_R - PLOT_D / 2 + 18 -- paths run 18 studs into each plot, up to the deposit bin
	local ORE_COUNT, ORE_GAP = 1100, 10 -- (was 250, then 750 / 12; 2026-10-02 "배틀필드 … 미네랄 더 채워놔봐 … 너무 휑해")
	local LEADERBOARD_GAP = 1.5 -- the leaderboard stands against the altar's rim, this far out
	-- (2026-10-03, "배경에 거대 워터폴 추가 들어가진 못하지만 배경에 넣는거야 그냥" → "나이아가라 폭포를 참고해서 … 숲이랑
	-- 어우러지게") a wide horseshoe waterfall far behind the wall (Prop_Waterfall, tools/make_waterfall.py: the same
	-- layout numbers, in the model's own studs: crest radius, arc, cliff height, half width, back, its middle front to
	-- back) with a forest on its banks and beside its gorge (no moving parts)
	-- (2026-10-03, "배경 요소가 너무 작다. 눈에 띄겠냐 훨씬 크게 해야지 넓고") Scale: the model made this many times bigger;
	-- Front: studs from the map's middle to its nearest edge; the forest grows with it
	-- (2026-10-03, "밑에 고이는 물부분은 없애도 되지 않나", "그러고 더 가까이") no pool any more: FrontEdge is the model's
	-- front (its spray and side steps), Front studs from the middle (was the pool's edge at 860)
	local WATERFALL = { Angle = 0, Front = 790, Scale = 2.6, Sink = 6, CrestR = 230, Arc = 78, Height = 100, HalfWidth = 430,
		Back = 420, FrontEdge = 11, Middle = 234, -- (Height was 150: "나이아가라 키 좀 줄여")
		BankTrees = 7, SideTrees = 5, TreeGap = 60, TreeSize = { 3.6, 5.6 }, -- (in the model's own studs; tree clumps: each side)
		-- (2026-10-03, "폭포 좌우가 너무 탁 잘린 느낌") its sides step down into the hills (make_waterfall.py WING_*):
		-- the first step Start past HalfWidth, Step apart, each Steps[k] × Height tall; WingTrees clumps on each step
		Wing = { Start = 40, Step = 55, Steps = { 0.88, 0.7, 0.52, 0.36, 0.22, 0.1 }, WingTrees = 2 } }
	-- (2026-10-03, "폭포 외에도 배경을 다채롭게 할만한 요소들 알아서 넣어봐. 렉 없게 고려하고", "어차피 가는 곳이 아니니 모션은
	-- 다 넣지 말고") more far scenery round the map, in the gaps between the bases, beyond the hills: one static mesh each
	-- (tools/make_backdrop.py; Dino_Brachio is the game's own, made giant), no collisions, touches, queries or shadows,
	-- nothing moving. Height: scaled to this many studs tall (nil: as made). Trees: how many tree clumps round its foot.
	-- (2026-10-03, "배경 요소가 너무 작다 … 훨씬 크게 해야지 넓고", "좀 더 가까이 놔도 되고") Front: studs from the map's middle
	-- to its nearest edge (the wall is at 760, the hills out to about 1000: just past the wall, among the hills);
	-- Scale: times as made (or Height: studs tall). (2026-10-03, "화산이나 설산도 더 가까이 배치해도 될듯") the volcano and
	-- the mountains just past the wall (790-820)
	local BACKDROP = {
		{ Asset = "Prop_Volcano", Angle = 135, Front = 790, Scale = 2.4, Sink = 8 },
		{ Asset = "Prop_Mountains", Angle = 245, Front = 800, Scale = 2.6, Sink = 10 },
		{ Asset = "Prop_Mountains", Angle = 298, Front = 820, Scale = 2.2, Sink = 10 },
		{ Asset = "Prop_RockArch", Angle = 75, Front = 840, Scale = 3.2, Sink = 4, Trees = 6,
			-- ("아치 안이 비어보임. 뭐라도 채워 넣고", "아치안 티라노 훨 크게 아치안 3분의 1은 채우도록": the opening is about
			-- 260 wide and 400 tall; turned a little so its length shows)
			Inside = { Asset = "Dino_TRex", Height = 250, Turn = 30, Trees = 4 } },
		{ Asset = "Prop_GiantRibs", Angle = 180, Front = 830, Height = 330, Sink = 20, Turn = 70 }, -- (Sink was 6: "배경화석은 조금 내리던가")
		{ Asset = "Dino_Brachio", Angle = 45, Front = 860, Height = 420, Turn = 110, Trees = 2 },
		{ Asset = "Dino_Brachio", Angle = 207, Front = 900, Height = 360, Turn = -60, Trees = 2 },
		{ Asset = "Dino_Brachio", Angle = 318, Front = 860, Height = 380, Turn = 160, Trees = 2 },
	}
	-- (2026-10-03, "기지쪽도 꾸며봐") each base: two team-colored flag poles at the entrance with a string of pennants
	-- between them, and flower planters along the inside of the front fence and in the corners (plot u across, v deep);
	-- the poles and planters solid (2026-10-03; at first nothing was), nothing moving
	local BASE_DECOR = { PoleHeight = 16, PoleOut = 1, FlagSize = Vector3.new(0.3, 4, 6), Pennants = 9, PennantSag = 2.5,
		Planters = { { -75, 5 }, { -35, 5 }, { 35, 5 }, { 75, 5 }, { -86, 156 } }, PlanterSize = Vector3.new(7, 1.6, 3),
		FlowerColors = { Color3.fromRGB(255, 120, 160), Color3.fromRGB(255, 220, 80), Color3.fromRGB(170, 120, 255),
			Color3.fromRGB(255, 255, 255) } }
	-- (2026-10-03, "기지 내부는 왜 안꾸몄지", "배틀필드 내 배치물 조금씩 갖다가 꾸미든가 해") battlefield things inside each base,
	-- both sides alike: { u (from the middle line, mirrored), v (in from the front), kinds... } — along the side fences
	-- (the front corners, beside the arena and the farm), clear of the stalls, signs, lamps and arena spotlights;
	-- a spot's next kinds Step studs in toward the middle; sizes × DECOR_SCALE; a dino nest (Prop_Nest) NestScale;
	-- solid like the same things elsewhere (2026-10-03); deeper than FIELD_V only on the farm's side (2026-10-06: the
	-- defense maps' roads reach the defense field's fences, so neither these nor a planter stand there)
	local BASE_PROPS = { Scale = { 0.45, 0.7 }, NestScale = 2.2, Step = 4.5,
		Spots = { { 95, 18, "rock", "bush" }, { 95, 40, "nest" }, { 96, 85, "log", "mushroom" }, { 96, 140, "rock", "bush" },
			{ 55, 7, "mushroom", "bush" } } }
	local BACKDROP_TREE_SCALE = 2.2 -- the trees round the scenery: this many times the hills' trees
	-- the ground under the far scenery, past the baseplate's edge (one flat green sheet of FAR_GROUND_TILES² tiles)
	local FAR_GROUND = { Tiles = 3, TileSize = 2048, Below = 0.6 }
	-- (2026-10-03, "중앙 배틀필드도 손봐봐 더 꾸밀 요소가 있나") the dig site and the dinos' life out on the battlefield, a few
	-- of each (tools/make_fieldprops.py): between Radius studs from the center, Gap apart; Foot: how far it reaches
	-- from its middle (placed right after the giant fossils, before the rocks and trees, which keep off it), Clear
	-- studs more off the ore spots; no collisions (nothing to get stuck on while mining or fleeing), nothing moving;
	-- Shadow: casts one
	local FIELD_PROPS = {
		{ Asset = "Prop_DigCamp", Count = 6, Scale = 3.0, Radius = { 220, 335 }, Gap = 90, Clear = 6, Foot = 22, Shadow = true,
			Precise = true }, -- (was 1.6: "작아서 어딨는지 못찾았네 키워")
		{ Asset = "Prop_Nest", Count = 10, Scale = 4.0, Radius = { 80, 340 }, Gap = 60, Clear = 4, Foot = 8 }, -- (was 2.0: "둥지랑 타르 웅덩이도 키워")
		{ Asset = "Prop_TarPit", Count = 6, Scale = 3.0, Radius = { 100, 330 }, Gap = 80, Clear = 6, Foot = 15 }, -- (was 1.6)
	}
	local BACKDROP_TREE_RING = { 0.55, 1.1 } -- × the piece's half width from its middle
	local BACKDROP_TREE_SIZE = { 3.4, 5.2 }
	local ARENA_GATE = 26.35 * 1.5 -- Base_Arena center -> gap in its front curb for the portal (tools/make_map.py CURB_R × MAP_SCALE)
	local ASSET_FRONT_YAW = 0 -- extra turn (degrees) for every model, if imported models do not face -Z
	local TERRAIN_R = 1500 -- terrain ground radius; the area -1500..1500 is cleared and rebuilt
	local BASEPLATE_R = TERRAIN_R -- the green stud baseplate covers the whole area, -1500..1500 (4 bricks)
	local BASEPLATE_TOP = 0.2 -- its top
	local TERRAIN_TOP = BASEPLATE_TOP -- the ground height when a raycast finds nothing
	local BRICK_ROW = 4 -- studs: round floors are rows of bricks this deep (a stepped, LEGO-like edge)
	local DECOR_SCALE = 2.5 -- trees and rocks: a size-1 tree is about 11.5 tall, so ×2.5 is 4-7 players tall
	local DECOR_COUNT, DECOR_GAP = 850, 15 -- (was 600, 18) props between the bases, and their spacing
	local FIELD_DECOR_COUNT, FIELD_GAP = 500, 12 -- (was 260, 16, then 420, 13) props out on the battlefield, and their spacing
	-- (2026-10-02, "배틀필드 갈색부분 땅에도 무늬를 좀 넣어주자. 너무 심심하다") the brown ring's patterns, flat on the
	-- ground: patches of darker, lighter and sandy earth (each a few round blobs), cracks, pebble clusters and dino
	-- footprint trails (FootprintSteps prints, Stride studs apart)
	local FIELD_GROUND = { Patches = 170, PatchRadius = { 4, 13 }, Cracks = 80, CrackSegments = { 3, 5 },
		Pebbles = 110, PebbleCluster = { 3, 7 }, Trails = 26, FootprintSteps = { 6, 10 }, Stride = 4.2 }
	-- giant footprints pressed into the ground (studs): Walks places, Steps prints each, Stride apart, Spread to each
	-- side; the pad's radius, the toes' size; heaped earth lumps round each part of the outline; Clear from props
	-- and paths
	local GIANT_PRINTS = { Walks = 2, Steps = 3, Stride = 22, Spread = 5, Pad = 4.5, ToeLength = 6, ToeWidth = 2.4,
		RimLumps = 7, RimSize = { 0.9, 1.6 }, Clear = 14 }
	-- what each place gets, as shares that add up to 1
	local DECOR_MIX = { tree = 0.42, rock = 0.18, bush = 0.22, mushroom = 0.10, log = 0.08 }
	local FIELD_MIX = { rock = 0.45, bush = 0.20, tree = 0.12, log = 0.12, mushroom = 0.11 }
	local FOSSIL_COUNT, FOSSIL_GAP = 10, 60 -- giant fossil skeletons on the battlefield: landmarks and cover
	-- (2026-10-03, "배틀필드 내 물체들 겹침현상") how far each battlefield thing reaches from its middle, × its size:
	-- a tree's crown, a rock with its small stone, a bush's balls, a log with its stump, mushrooms; a fossil (spine,
	-- ribs and skull) × its size. Neighbors keep their reaches apart, PROP_OVERLAP of the newcomer's allowed to touch
	local PROP_REACH = { tree = 4.8, rock = 3.2, bush = 2.8, log = 4.2, mushroom = 1.6 }
	local FOSSIL_REACH = 13
	local PROP_OVERLAP = 0.85
	local POND_COUNT, POND_GAP = 12, 90 -- ponds between the bases
	-- (2026-10-02, "배틀필드에도 풀 더": 360 / 170, gaps 7 / 12) little grass tufts growing all over the battlefield
	local GRASS_COUNT, GRASS_GAP, GRASS_BLADES = 600, 6, 4
	-- (2026-10-02, "이래 겹치는거 없게": grass grew into bushes and rocks) studs kept between grass and a prop's middle
	local PROP_CLEAR = 7
	-- flowers in a share of the clumps: 1-MaxPerClump of one color, Height × the clump's scale, heads Head studs
	local FLOWERS = { Share = 0.3, MaxPerClump = 3, Height = { 0.9, 1.4 }, Head = 0.42, Colors = {
		Color3.fromRGB(255, 120, 170), Color3.fromRGB(250, 248, 240), Color3.fromRGB(170, 110, 235),
		Color3.fromRGB(235, 70, 70), Color3.fromRGB(110, 180, 255), Color3.fromRGB(255, 160, 60),
		Color3.fromRGB(255, 220, 70) } } -- pink, white, purple, red, sky blue, orange, yellow
	-- with the Blender grass clumps (Prop_Grass_A/B/C in Assets): fewer of them, a little here and there
	local GRASS_ASSET_COUNT, GRASS_ASSET_GAP, GRASS_ASSET_SCALE = 320, 9, { 1.6, 2.6 }
	-- (2026-10-02, "안전지대 울타리 밖 트랙 밖 쪽 풀 좀 더") the safe land too: between and behind the bases, outside the
	-- plots' fences and the race track (folder SafeGrass), the Blender clumps or the part tufts
	-- (2026-10-02, "울타리밖 야생공룡 지역에 풀이 없냐": 420 single clumps over that whole land stood ~46 studs
	-- apart) in patches now: PATCHES patch middles at least PATCH_GAP apart, each SIZE tufts within RADIUS
	local SAFE_GRASS = { Patches = 320, PatchGap = 24, Size = { 3, 6 }, Radius = 7, TuftGap = 2.5 } -- the part tufts
	-- (2026-10-02: lowered for the little wild dinos, then "안전지대 풀 안낮춰도 돼": as tall as the battlefield's;
	-- the little dinos grew instead, Wildlife HERDS.Height)
	local SAFE_GRASS_ASSET = { Patches = 460, PatchGap = 20, Size = { 3, 7 }, Radius = 8, TuftGap = 3 } -- the Blender clumps
	-- Blender trees (Prop_Tree_Pine/Round/Palm in Assets) stand in for this share of the trees
	local FOLIAGE_TREES = { "Prop_Tree_Pine", "Prop_Tree_Round", "Prop_Tree_Palm" }
	local FOLIAGE_GRASS = { "Prop_Grass_A", "Prop_Grass_B", "Prop_Grass_C" }
	local FOLIAGE_TREE_SHARE = 0.6
	local FOLIAGE_TREE_SIZE = 12 -- studs, the Blender trees' height at scale 1 (tools/make_foliage.py)
	-- (2026-10-02, "다른나무 다 괜찮은데 야자나무는 사람 통과가 되는데": the palm's trunk leans and its crown is off to one
	-- side, so the middle of its box, where the trunk collider stood, is ~2 studs from its foot) the trunk's line
	-- in the model at scale 1: points up the trunk { x, y, z, radius } in studs from its bottom middle, from
	-- tools/make_foliage.py build_palm (Blender x -> -x, Blender y -> z); a collider along each step
	local TRUNK_LINES = {
		Prop_Tree_Palm = { { 2.15, 0.35, 0.25, 0.87 }, { 2.07, 2.60, 0.25, 0.82 }, { 1.82, 4.86, 0.25, 0.76 },
			{ 1.40, 7.11, 0.25, 0.71 }, { 0.82, 9.37, 0.25, 0.66 }, { 0.07, 11.6, 0.25, 0.61 } },
	}
	-- (2026-10-02, "나무 높이나 두께(특히두께)를 올려도 될거 같은데") every tree TREE_TALLER times as tall and, on top
	-- of that, TREE_WIDER times as wide (trunk and crown: chubbier, in the game's toy look)
	local TREE_TALLER, TREE_WIDER = 1.15, 1.45
	-- (2026-10-02, "야자나무들 다 떠있는거 같은데") the Blender trunks end in a rounded cap: each tree stands this far
	-- (studs at scale 1) into the ground, so the trunk's straight side meets the grass
	local TREE_SINK = 0.9
	-- the race track (Race service; Config.Race holds the same numbers): a paved ring between the
	-- battlefield flags and the base fences, raced clockwise seen from above (compass angle going up),
	-- the finish line at FINISH_ANGLE
	local ROAD_R, ROAD_W = 375, 20 -- 365..385: from just past the battlefield band to just before the base fences
	local ROAD_SEGMENTS = 120
	local FINISH_ANGLE = 0 -- north: between the paths of Base8 and Base1
	local ARROW_EVERY = 10 -- degrees between the direction arrows painted on the road
	local START_BACK = 2.5 -- degrees behind the finish line: the two start slots
	-- (2026-10-02, "신호등 모델링해서 기지와 기지 사이 안전지대 쪽 길가에 등이 트랙 진행방향과 마주보도록") traffic lights
	-- (Prop_TrafficLight, tools/make_traffic_light.py) on the road's outer side, between the bases (every 45
	-- degrees) and one just past the finish arch facing the start boxes; their lamps face the racers coming.
	-- The lamps are Neon discs put in the model's sockets (LIGHT_LAMPS: model space, the front is -Z);
	-- StarterPlayerScripts/TrafficLights lights them
	local LIGHT_OUT = 14 -- studs out from the road's middle line (the road is 20 wide)
	local LIGHT_START_ANGLE = 2 -- degrees past the finish line: the one facing the start boxes
	local LIGHT_LAMPS = { { "Red", Vector3.new(0, 11.37, -0.96) }, { "Yellow", Vector3.new(0, 9.46, -0.96) },
		{ "Green", Vector3.new(0, 7.55, -0.96) } }
	local LIGHT_LAMP_RADIUS = 0.81
	-- (2026-10-03, "처음부터 배경에 개별로 심어진 나무들이 렉을 유발하진 않나? 얘들도 통짜로 모델링 하나로 넣으면 안 되나") the
	-- trees nobody can reach (the hills past the wall, round the waterfall and the far scenery) are clumps of 5-7
	-- trees in one mesh each (tools/make_forest.py), not three parts a tree: BORDER_TREES clumps (was 340 trees),
	-- BORDER_GAP studs apart (was 25)
	local BORDER_TREES, BORDER_GAP = 60, 60
	local TREE_CLUMPS = { "Prop_TreeClump_A", "Prop_TreeClump_B" } -- dark leaves; Prop_TreeClump_C: the lighter green

	-- ground part tops (the terrain surface is y = 0)
	-- the plots get a floor part: flat models (arena track, farm pen floor) sank into the terrain surface
	local TOP = { band = 0.3, dirt = 0.35, plot = 0.5, path = 0.55, walk = 0.6, plaza = 0.7, road = 0.65 }
	local PLOT_FLOOR_THICKNESS = 2 -- reaches well into the terrain

	local COLOR = {
		dirt = Color3.fromRGB(150, 105, 62),
		band = Color3.fromRGB(255, 150, 40),
		stone = Color3.fromRGB(158, 156, 150),
		plaza = Color3.fromRGB(228, 206, 158),
		plotFloor = Color3.fromRGB(150, 205, 110),
		baseplate = Color3.fromRGB(88, 171, 65), -- LEGO bright grass green
		fence = Color3.fromRGB(160, 112, 60),
		trunk = Color3.fromRGB(112, 74, 42),
		leaf = Color3.fromRGB(76, 165, 72),
		leafLight = Color3.fromRGB(104, 190, 84),
		road = Color3.fromRGB(68, 70, 78),
		roadLine = Color3.fromRGB(240, 240, 235),
		roadArrow = Color3.fromRGB(255, 205, 60),
		finishDark = Color3.fromRGB(30, 30, 34),
		finishPost = Color3.fromRGB(220, 60, 60),
		leafDark = Color3.fromRGB(52, 128, 60),
		grass = Color3.fromRGB(96, 178, 70),
		grassLight = Color3.fromRGB(130, 200, 90),
		rock = Color3.fromRGB(128, 128, 134),
		bone = Color3.fromRGB(236, 226, 200),
		mushroomCap = Color3.fromRGB(230, 70, 60),
		mushroomStem = Color3.fromRGB(245, 238, 220),
		water = Color3.fromRGB(70, 150, 230),
		pole = Color3.fromRGB(245, 245, 240),
		flag = Color3.fromRGB(255, 120, 20),
		defenseSign = Color3.fromRGB(214, 84, 58),
		farmSign = Color3.fromRGB(112, 178, 78),
		-- (2026-10-02) the battlefield's earth patterns (FIELD_GROUND)
		dirtDark = Color3.fromRGB(122, 84, 50),
		dirtLight = Color3.fromRGB(176, 128, 80),
		sand = Color3.fromRGB(196, 162, 108),
		crack = Color3.fromRGB(92, 62, 36),
		pebble = Color3.fromRGB(150, 144, 134),
		pebbleDark = Color3.fromRGB(112, 100, 88),
	}
	local TEAM_COLORS = { "Bright red", "Bright blue", "Lime green", "New Yeller",
		"Bright violet", "Deep orange", "Toothpaste", "Hot pink" }

	-- models that travel with another model (flat planes placed next to it in the Blender set)
	local COMPANIONS = {
		Base_Shop = { "Shop_Sign" },
		Base_SpawnPortal = { "SpawnPortal_Disc" },
		Zone_Leaderboard = { "Leaderboard_Screen" },
	}

	-- ---------------------------------------------------------------------------
	-- Helpers
	-- ---------------------------------------------------------------------------

	-- unit vector for a compass angle in degrees (0 = north / -Z, 90 = east / +X)
	local function dir(deg)
		local a = math.rad(deg)
		return Vector3.new(math.sin(a), 0, -math.cos(a))
	end

	-- small deterministic random generator, so every run builds the same map
	local seed = 1
	local function reseed(s)
		seed = s
	end
	local function rand()
		seed = (seed * 48271) % 2147483647
		return seed / 2147483647
	end

	local function folder(name, parent)
		local f = Instance.new("Folder")
		f.Name = name
		f.Parent = parent
		return f
	end

	local function newPart(props, className)
		local p = Instance.new(className or "Part")
		p.Anchored = true
		p.Material = Enum.Material.SmoothPlastic
		p.TopSurface = Enum.SurfaceType.Smooth
		p.BottomSurface = Enum.SurfaceType.Smooth
		if props.Shape then
			p.Shape = props.Shape -- before Size, so balls keep the given size
		end
		for key, value in pairs(props) do
			if key ~= "Parent" and key ~= "Shape" then
				p[key] = value
			end
		end
		p.Parent = props.Parent
		return p
	end

	local function hidden(p, canTouch, canQuery)
		p.Transparency = 1
		p.CanCollide = false
		p.CanTouch = canTouch
		p.CanQuery = canQuery
		p.CastShadow = false
		return p
	end

	local UPRIGHT = CFrame.Angles(0, 0, math.rad(90)) -- cylinder parts lie along X; this stands them up

	-- a floor part that looks like a LEGO brick: shiny plastic, studs on top
	local function brick(p)
		p.Material = Enum.Material.Plastic
		p.TopSurface = Enum.SurfaceType.Studs
		return p
	end

	-- a round floor around the map center (top at `top`), built from rows of bricks BRICK_ROW deep whose
	-- widths follow the circle in whole studs (even, so the studs line up from row to row)
	local function disc(name, radius, top, color, parent)
		local model = Instance.new("Model")
		model.Name = name
		local rows = math.ceil(radius / BRICK_ROW)
		for i = -rows, rows - 1 do
			local z = (i + 0.5) * BRICK_ROW
			local half = math.floor(math.sqrt(math.max(0, radius * radius - z * z)) / 2 + 0.5) * 2
			if half >= 2 then
				brick(newPart({ Name = "Row", Size = Vector3.new(half * 2, 1, BRICK_ROW), CFrame = CFrame.new(0, top - 0.5, z),
					Color = color, Parent = model }))
			end
		end
		model.Parent = parent
		return model
	end

	local function farFrom(points, p, gap)
		for _, q in ipairs(points) do
			if (q - p).Magnitude < gap then
				return false
			end
		end
		return true
	end

	-- is a thing of reach r at p clear of every one placed (points with their own reaches)?
	local function roomAt(points, reaches, p, r)
		for i, q in ipairs(points) do
			if (q - p).Magnitude < r + (reaches[i] or 0) then
				return false
			end
		end
		return true
	end

	local baseAngles = {}
	for i = 1, BASE_COUNT do
		baseAngles[i] = BASE_ANGLE0 + (i - 1) * 360 / BASE_COUNT
	end

	local function onPath(p, margin)
		for _, a in ipairs(baseAngles) do
			local along, side = p:Dot(dir(a)), math.abs(p:Dot(dir(a + 90)))
			if along > WALK_R - 4 and along < PATH_END + margin and side < PATH_W / 2 + margin then
				return true
			end
		end
		return false
	end

	local function onRoad(p, margin)
		return math.abs(Vector3.new(p.X, 0, p.Z).Magnitude - ROAD_R) < ROAD_W / 2 + margin
	end

	local function inPlot(p, margin)
		for _, a in ipairs(baseAngles) do
			local rel = p - dir(a) * BASE_R
			if math.abs(rel:Dot(dir(a + 90))) < PLOT_W / 2 + margin and math.abs(rel:Dot(dir(a))) < PLOT_D / 2 + margin then
				return true
			end
		end
		return false
	end

	-- ---------------------------------------------------------------------------
	-- Start: remove the old map, rebuild the terrain
	-- ---------------------------------------------------------------------------

	while Workspace:FindFirstChild("Map") do
		Workspace.Map:Destroy()
	end
	-- the template's grey grid baseplate (top at y = 0, like our floor): it would hide the LEGO ground
	for _, child in ipairs(Workspace:GetChildren()) do
		if child:IsA("BasePart") and child.Name == "Baseplate" then
			child:Destroy()
			print("[MapBuilder] 템플릿 기본 바닥(Workspace.Baseplate)을 지웠습니다: 레고 바닥이 보이게")
		end
	end
	local map = folder("Map", Workspace)
	local groundFolder = folder("Ground", map)

	for x = -TERRAIN_R + 125, TERRAIN_R - 125, 250 do -- clear the map's terrain area in chunks
		for z = -TERRAIN_R + 125, TERRAIN_R - 125, 250 do
			Terrain:FillBlock(CFrame.new(x, 44, z), Vector3.new(250, 120, 250), Enum.Material.Air)
		end
	end
	-- no terrain grass floor any more: the LEGO baseplate is the whole ground (terrain rounds its surface to
	-- 4-stud cells and showed through the baseplate). The terrain is only the hills outside the wall.
	-- no tall animated grass blades: they hide the low paths, rings and arena floors
	if not pcall(function()
		Terrain.Decoration = false
	end) then
		warn("[MapBuilder] 풀 장식을 끄지 못했습니다. Workspace > Terrain 속성에서 Decoration 체크를 끄세요.")
	end

	-- hills beyond the wall: an inner ring of smaller hills and an outer ring of big ones
	local hills = {}
	local function hillRing(count, radMin, radVar, depthMin, depthVar, gap, spread)
		for k = 0, count - 1 do
			local ang = (k + rand() * 0.6 - 0.3) * 360 / count
			local rad = radMin + rand() * radVar
			local cy = -(depthMin + rand() * depthVar)
			local foot = math.sqrt(rad * rad - cy * cy) -- hill radius at ground level
			local dist = MAP_R + gap + foot + rand() * spread
			local center = dir(ang) * dist + Vector3.new(0, cy, 0)
			Terrain:FillBall(center, rad, Enum.Material.Grass)
			table.insert(hills, { center = center, rad = rad })
		end
	end
	reseed(303)
	hillRing(60, 42, 24, 6, 12, 6, 21)
	hillRing(44, 63, 24, 12, 15, 54, 36)

	-- the ground height anywhere: a raycast against the ground parts only, and the hills worked out
	-- from their spheres. Never a raycast against the terrain: right after the terrain is cleared and
	-- filled again, raycasts can still hit the old terrain (an older map's hills), which left trees
	-- floating in the air.
	local groundParams = RaycastParams.new()
	groundParams.FilterType = Enum.RaycastFilterType.Include
	groundParams.FilterDescendantsInstances = { groundFolder }
	local function groundY(x, z)
		local hit = Workspace:Raycast(Vector3.new(x, 200, z), Vector3.new(0, -300, 0), groundParams)
		local y = hit and hit.Position.Y or TERRAIN_TOP
		for _, h in ipairs(hills) do
			local dx, dz = x - h.center.X, z - h.center.Z
			local inside = h.rad * h.rad - dx * dx - dz * dz
			if inside > 0 then
				y = math.max(y, h.center.Y + math.sqrt(inside))
			end
		end
		return y
	end

	-- the green stud baseplate: the whole map's ground, top at BASEPLATE_TOP (the terrain grass under it)
	for _, sx in ipairs({ -1, 1 }) do
		for _, sz in ipairs({ -1, 1 }) do
			brick(newPart({ Name = "Baseplate", Size = Vector3.new(BASEPLATE_R, 2, BASEPLATE_R),
				CFrame = CFrame.new(sx * BASEPLATE_R / 2, BASEPLATE_TOP - 1, sz * BASEPLATE_R / 2), Color = COLOR.baseplate,
				Parent = groundFolder }))
		end
	end
	disc("BattlefieldBand", RING_OUT + BAND_W / 2, TOP.band, COLOR.band, groundFolder)
	disc("MineralRing", RING_OUT - BAND_W / 2, TOP.dirt, COLOR.dirt, groundFolder)
	disc("Walkway", WALK_R, TOP.walk, COLOR.stone, groundFolder)
	disc("KeyPlaza", KEY_R, TOP.plaza, COLOR.plaza, groundFolder)
	for i, a in ipairs(baseAngles) do -- stone paths: walkway -> base entrance
		local r0 = WALK_R - 2
		local mid = dir(a) * ((r0 + PATH_END) / 2) + Vector3.new(0, TOP.path - 0.5, 0)
		brick(newPart({ Name = "Path" .. i, Size = Vector3.new(PATH_W, 1, math.floor(PATH_END - r0)),
			CFrame = CFrame.lookAt(mid, mid + dir(a)), Color = COLOR.stone, Parent = groundFolder }))
		-- base plot floor: everything in the base stands on it
		local floorCenter = dir(a) * BASE_R + Vector3.new(0, TOP.plot - PLOT_FLOOR_THICKNESS / 2, 0)
		brick(newPart({ Name = "PlotFloor" .. i, Size = Vector3.new(PLOT_W, PLOT_FLOOR_THICKNESS, PLOT_D),
			CFrame = CFrame.lookAt(floorCenter, floorCenter + dir(a)), Color = COLOR.plotFloor, Parent = groundFolder }))
	end

	-- ---------------------------------------------------------------------------
	-- Blender models from ServerStorage.Assets
	-- ---------------------------------------------------------------------------

	-- the Assets folder: ServerStorage.Assets, or failing that anything called "assets" (any case, spaces
	-- around it) in ServerStorage, ReplicatedStorage or Workspace
	local function findAssetsFolder()
		local exact = ServerStorage:FindFirstChild("Assets")
		if exact then
			return exact
		end
		local function looksLikeAssets(inst)
			return (inst:IsA("Folder") or inst:IsA("Model")) and string.lower(inst.Name):match("^%s*(.-)%s*$") == "assets"
		end
		for _, place in ipairs({ ServerStorage, ReplicatedStorage, Workspace }) do
			for _, d in ipairs(place:GetDescendants()) do
				if looksLikeAssets(d) then
					warn(string.format("[MapBuilder] Assets 폴더를 '%s'에서 찾아 사용합니다. ServerStorage 바로 아래에 이름 'Assets'로 두는 것을 권장합니다.",
						d:GetFullName()))
					return d
				end
			end
		end
		local names = {}
		for _, c in ipairs(ServerStorage:GetChildren()) do
			table.insert(names, string.format("'%s'(%s)", c.Name, c.ClassName))
		end
		warn("[MapBuilder] Assets 폴더를 못 찾았습니다. 지금 ServerStorage 안: "
			.. (#names > 0 and table.concat(names, ", ") or "비어 있음"))
		return nil
	end
	local assets = findAssetsFolder()
	local missing, missingSeen = {}, {}
	local function noteMissing(name)
		if not missingSeen[name] then
			missingSeen[name] = true
			table.insert(missing, name)
		end
	end

	local function findAsset(name, near)
		if near and near:FindFirstChild(name) then
			return near[name]
		end
		return assets and assets:FindFirstChild(name, true)
	end

	local function worldBounds(inst)
		local parts = inst:GetDescendants()
		table.insert(parts, inst)
		local lo = { math.huge, math.huge, math.huge }
		local hi = { -math.huge, -math.huge, -math.huge }
		for _, p in ipairs(parts) do
			if p:IsA("BasePart") then
				local h = p.Size / 2
				for _, sx in ipairs({ -1, 1 }) do
					for _, sy in ipairs({ -1, 1 }) do
						for _, sz in ipairs({ -1, 1 }) do
							local c = p.CFrame * Vector3.new(h.X * sx, h.Y * sy, h.Z * sz)
							lo = { math.min(lo[1], c.X), math.min(lo[2], c.Y), math.min(lo[3], c.Z) }
							hi = { math.max(hi[1], c.X), math.max(hi[2], c.Y), math.max(hi[3], c.Z) }
						end
					end
				end
			end
		end
		return lo, hi
	end

	-- Clone a model and stand its bottom center on target (a CFrame on the ground whose LookVector is
	-- where the model's front should face). Returns the placed Model, or nil if it is missing.
	local function placeAsset(name, target, parent)
		local source = findAsset(name)
		if not source then
			noteMissing(name)
			return nil
		end
		local main = source:Clone()
		local model = main
		if not main:IsA("Model") then
			model = Instance.new("Model")
			model.Name = name
			main.Parent = model
		end
		for _, extraName in ipairs(COMPANIONS[name] or {}) do
			if not model:FindFirstChild(extraName, true) then
				local extra = findAsset(extraName, source.Parent) -- the one from the same set keeps its offset
				if extra then
					extra:Clone().Parent = model
				else
					noteMissing(extraName)
				end
			end
		end
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") then
				d.Anchored = true
			end
		end
		local lo, hi = worldBounds(main) -- bottom center of the model itself (companions just follow)
		model.PrimaryPart = nil
		model.WorldPivot = CFrame.new((lo[1] + hi[1]) / 2, lo[2], (lo[3] + hi[3]) / 2)
		model:PivotTo(target * CFrame.Angles(0, math.rad(ASSET_FRONT_YAW), 0))
		model.Parent = parent
		return model
	end

	-- Roblox parts stop at 2048 studs a side: a model scaled past that is squashed (its pieces then miss the trees
	-- planted for them); the big far pieces come as several meshes (make_waterfall.split_wide), this tells if not
	local function warnTooBig(model)
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") and math.max(d.Size.X, d.Size.Y, d.Size.Z) > 2047 then
				warn(("[MapBuilder] %s 이(가) 2048스터드를 넘어 찌그러졌습니다. exports/new 의 새 FBX(여러 조각)로 교체하세요.")
					:format(model.Name))
				return
			end
		end
	end

	local function onGround(pos, face)
		local p = Vector3.new(pos.X, groundY(pos.X, pos.Z), pos.Z)
		return CFrame.lookAt(p, p + face)
	end

	-- ---------------------------------------------------------------------------
	-- Key zone
	-- ---------------------------------------------------------------------------

	do -- (a function of its own: the Command Bar gives each function only 200 locals)
		local function section()
			local keyZone = folder("KeyZone", map)
			local altar = placeAsset("Zone_KeyAltar", onGround(Vector3.zero, Vector3.new(0, 0, -1)), keyZone)
			-- the leaderboard stands right against the altar's rim (north), facing the middle
			local altarRim = 12
			if altar then
				local _, altarSize = altar:GetBoundingBox()
				altarRim = math.max(altarSize.X, altarSize.Z) / 2
			end
			local boardDist = altarRim + LEADERBOARD_GAP
			local board = placeAsset("Zone_Leaderboard", onGround(Vector3.new(0, 0, -boardDist), Vector3.new(0, 0, 1)), keyZone)
			if board then -- its back to the rim: push it out by half its own depth
				local _, boardSize = board:GetBoundingBox()
				local depth = math.min(boardSize.X, boardSize.Z)
				board:PivotTo(onGround(Vector3.new(0, 0, -(boardDist + depth / 2)), Vector3.new(0, 0, 1))
					* CFrame.Angles(0, math.rad(ASSET_FRONT_YAW), 0))
			end

			-- ---------------------------------------------------------------------------
			-- Mineral ring: ore spawn points (the game spawns the ores)
		end
		section()
	end
	-- ---------------------------------------------------------------------------

	-- (2026-10-03, "이번에 추가한 배틀필드에 알밖에 못찾겠음") the battlefield's big things choose their spots first:
	-- the 1,100 ore spots cover the whole ring about 10 studs apart, so nothing chosen after them ever found the
	-- clear ground a camp or a tar pit needs. Now the ore spots keep off these (fieldPlan: giant fossils, then
	-- FIELD_PROPS; placed further down, where the battlefield is decorated)
	local fieldPlan = { spots = {}, reach = {}, fossils = {}, props = {} }
	do
		local plan = fieldPlan
		reseed(404)
		local tries = 0
		while #plan.fossils < FOSSIL_COUNT and tries < 5000 do -- landmarks spread over the middle of the field
			tries += 1
			local p = dir(rand() * 360) * (120 + rand() * (RING_OUT - 150))
			local size = 1.3 + rand() * 0.5
			local fits = not onPath(p, 14)
			for _, f in ipairs(plan.fossils) do
				fits = fits and (f.p - p).Magnitude >= FOSSIL_GAP
			end
			if fits then
				table.insert(plan.fossils, { p = p, size = size, yaw = rand() * 360 })
				table.insert(plan.spots, p)
				table.insert(plan.reach, FOSSIL_REACH * size)
			end
		end
		reseed(808)
		for k, item in ipairs(FIELD_PROPS) do
			local mine = {}
			tries = 0
			while #mine < item.Count and tries < 4000 do
				tries += 1
				local p = dir(rand() * 360) * (item.Radius[1] + rand() * (item.Radius[2] - item.Radius[1]))
				if not onPath(p, item.Foot + 4) and farFrom(mine, p, item.Gap) and roomAt(plan.spots, plan.reach, p, item.Foot) then
					table.insert(mine, p)
					table.insert(plan.spots, p)
					table.insert(plan.reach, item.Foot + item.Clear)
				end
			end
			plan.props[k] = mine
		end
		-- the giant footprints' walks (GIANT_PRINTS): each print kept clear by its pad and toes and gp.Clear
		local gp = GIANT_PRINTS
		local printReach = gp.Pad + gp.ToeLength
		plan.walks = {}
		tries = 0
		while #plan.walks < gp.Walks and tries < 3000 do
			tries += 1
			local start = dir(rand() * 360) * (WALK_R + gp.Clear + rand() * (RING_OUT - WALK_R - 2 * gp.Clear))
			local heading = rand() * 360
			local spots, fits = {}, true
			for k = 0, gp.Steps - 1 do
				local at = start + dir(heading) * (k * gp.Stride) + dir(heading + 90) * ((k % 2 == 0) and gp.Spread or -gp.Spread)
				if onPath(at, gp.Clear) or not roomAt(plan.spots, plan.reach, at, printReach)
					or at.Magnitude > RING_OUT - gp.Clear or at.Magnitude < WALK_R + gp.Clear then
					fits = false
					break
				end
				table.insert(spots, at)
			end
			if fits then
				table.insert(plan.walks, { heading = heading, spots = spots })
				for _, at in ipairs(spots) do
					table.insert(plan.spots, at)
					table.insert(plan.reach, printReach)
				end
			end
		end
	end

	local oreFolder = folder("OreSpawns", map)
	local ores, oreTries = {}, 0
	local oreLo, oreHi = RING_IN + 2, RING_OUT - BAND_W / 2 - 2
	reseed(101)
	while #ores < ORE_COUNT and oreTries < 50000 do -- random points, evenly spread: none closer than ORE_GAP
		oreTries += 1
		local r = math.sqrt(oreLo ^ 2 + rand() * (oreHi ^ 2 - oreLo ^ 2))
		local p = dir(rand() * 360) * r
		if not onPath(p, 3) and farFrom(ores, p, ORE_GAP) and roomAt(fieldPlan.spots, fieldPlan.reach, p, 2) then
			table.insert(ores, p)
		end
	end
	for i, p in ipairs(ores) do
		hidden(newPart({ Name = string.format("OreSpawn%03d", i), Size = Vector3.new(1, 1, 1),
			CFrame = CFrame.new(p.X, groundY(p.X, p.Z), p.Z), Parent = oreFolder }), false, false)
	end

	-- ---------------------------------------------------------------------------
	-- Battlefield: orange band (a ground disc above), flags, invisible cylinder
	-- ---------------------------------------------------------------------------

	local battlefield = hidden(newPart({ Name = "Battlefield", Shape = Enum.PartType.Cylinder,
		Size = Vector3.new(BF_HEIGHT, RING_OUT * 2, RING_OUT * 2),
		CFrame = CFrame.new(0, BF_HEIGHT / 2, 0) * UPRIGHT, Parent = map }), true, true)
	battlefield:SetAttribute("Radius", RING_OUT)

	local flagFolder = folder("BattlefieldFlags", map)
	local flagCount = math.floor(2 * math.pi * RING_OUT / FLAG_STEP + 0.5)
	for k = 0, flagCount - 1 do
		local a = k * 360 / flagCount
		local p = dir(a) * RING_OUT
		if not onPath(p, 1.5) then
			local base = Vector3.new(p.X, TOP.band, p.Z)
			local tangent = dir(a + 90)
			local flag = Instance.new("Model")
			flag.Name = "Flag"
			newPart({ Name = "Pole", Shape = Enum.PartType.Cylinder, Size = Vector3.new(8, 0.5, 0.5),
				CFrame = CFrame.new(base + Vector3.new(0, 4, 0)) * UPRIGHT, Color = COLOR.pole, Parent = flag })
			local cloth = base + Vector3.new(0, 6.8, 0) + tangent * 1.6
			newPart({ Name = "Cloth", Size = Vector3.new(0.2, 2, 3), CFrame = CFrame.lookAt(cloth, cloth + tangent),
				Color = COLOR.flag, Parent = flag })
			flag.Parent = flagFolder
		end
	end

	-- ---------------------------------------------------------------------------
	-- Race track: a paved ring between the battlefield band and the base fences
	-- ---------------------------------------------------------------------------

	local track = folder("RaceTrack", groundFolder) -- on the ground folder: decor and raycasts see the road
	do -- (a function of its own: the Command Bar gives each function only 200 locals)
		local function section()
			track:SetAttribute("Radius", ROAD_R)
			track:SetAttribute("Width", ROAD_W)
			track:SetAttribute("FinishAngle", FINISH_ANGLE)
			-- a flat piece on the road at compass angle a, `along` studs long in the racing direction, `across` wide,
			-- `out` studs outward from the road's middle line, its top `lift` above the road
			local function roadPiece(name, a, along, across, out, lift, color, parent)
				local c = dir(a) * (ROAD_R + out) + Vector3.new(0, TOP.road + lift - 0.1, 0)
				return newPart({ Name = name, Size = Vector3.new(across, 0.2, along), CFrame = CFrame.lookAt(c, c + dir(a + 90)),
					Color = color, CanCollide = false, CastShadow = false, Parent = parent or track })
			end
			local segAngle = 360 / ROAD_SEGMENTS
			local segLength = 2 * (ROAD_R + ROAD_W / 2) * math.sin(math.rad(segAngle / 2)) + 0.5 -- the outer edge's chord, a little overlap
			for k = 0, ROAD_SEGMENTS - 1 do
				local a = (k + 0.5) * segAngle
				local c = dir(a) * ROAD_R + Vector3.new(0, TOP.road - 0.5, 0)
				newPart({ Name = "Road", Size = Vector3.new(ROAD_W, 1, segLength), CFrame = CFrame.lookAt(c, c + dir(a + 90)),
					Color = COLOR.road, Parent = track })
				for _, side in ipairs({ -1, 1 }) do -- white edge lines
					roadPiece("EdgeLine", a, segLength, 0.8, side * (ROAD_W / 2 - 1), 0.04, COLOR.roadLine)
				end
				local toArrow = math.abs((a + ARROW_EVERY / 2) % ARROW_EVERY - ARROW_EVERY / 2)
				if toArrow > 3.5 and math.abs(((a - FINISH_ANGLE + 180) % 360) - 180) > 4 then -- dashed middle line
					roadPiece("MiddleLine", a, 6, 0.6, 0, 0.04, COLOR.roadLine)
				end
			end
			-- yellow double chevrons (">>") painted every ARROW_EVERY degrees, pointing the racing direction
			for a = ARROW_EVERY, 360 - ARROW_EVERY, ARROW_EVERY do
				if math.abs(((a - FINISH_ANGLE + 180) % 360) - 180) > 4 then
					local arrow = Instance.new("Model")
					arrow.Name = "Arrow"
					local fwd, out = dir(a + 90), dir(a)
					for _, back in ipairs({ 0, 3.2 }) do
						local tip = dir(a) * ROAD_R - fwd * back + Vector3.new(0, TOP.road + 0.06, 0)
						for _, side in ipairs({ -1, 1 }) do
							local tail = tip - fwd * 3 + out * side * 4
							local length = (tip - tail).Magnitude + 1.2
							local mid = (tip + tail) / 2
							newPart({ Name = "Chevron", Size = Vector3.new(1.2, 0.2, length), CFrame = CFrame.lookAt(mid, tip),
								Color = COLOR.roadArrow, CanCollide = false, CastShadow = false, Parent = arrow })
						end
					end
					arrow.Parent = track
				end
			end
			-- the finish line: a black and white checkered strip across the road
			local CHECK = 2
			local across = math.floor(ROAD_W / CHECK)
			local fwd0 = dir(FINISH_ANGLE + 90)
			for i = 0, across - 1 do
				for j = 0, 1 do
					local out = (i + 0.5) * CHECK - across * CHECK / 2
					local c = dir(FINISH_ANGLE) * (ROAD_R + out) + fwd0 * ((j - 0.5) * CHECK) + Vector3.new(0, TOP.road + 0.05, 0)
					newPart({ Name = "FinishCheck", Size = Vector3.new(CHECK, 0.2, CHECK), CFrame = CFrame.lookAt(c, c + fwd0),
						Color = (i + j) % 2 == 0 and COLOR.roadLine or COLOR.finishDark, CanCollide = false, CastShadow = false,
						Parent = track })
				end
			end
			-- two white start boxes START_BACK degrees behind the line, side by side
			for slot, side in ipairs({ -1, 1 }) do
				local a = FINISH_ANGLE - START_BACK
				for _, e in ipairs({ { 0, -3.5, 7, 0.5 }, { 0, 3.5, 7, 0.5 }, { -3.25, 0, 0.5, 7 }, { 3.25, 0, 0.5, 7 } }) do
					local c = dir(a) * (ROAD_R + side * ROAD_W / 4 + e[1]) + dir(a + 90) * e[2] + Vector3.new(0, TOP.road + 0.04, 0)
					newPart({ Name = "StartBox" .. slot, Size = Vector3.new(e[3], 0.2, e[4]), CFrame = CFrame.lookAt(c, c + dir(a + 90)),
						Color = COLOR.roadLine, CanCollide = false, CastShadow = false, Parent = track })
				end
			end
			-- the finish arch: two red posts beside the road and a checkered banner over it
			local arch = Instance.new("Model")
			arch.Name = "FinishArch"
			local ARCH_H = 16
			for _, side in ipairs({ -1, 1 }) do
				local c = dir(FINISH_ANGLE) * (ROAD_R + side * (ROAD_W / 2 + 1.5)) + Vector3.new(0, TOP.road + ARCH_H / 2, 0)
				newPart({ Name = "Post", Size = Vector3.new(1.6, ARCH_H, 1.6), CFrame = CFrame.new(c), Color = COLOR.finishPost,
					Parent = arch })
			end
			local bannerC = dir(FINISH_ANGLE) * ROAD_R + Vector3.new(0, TOP.road + ARCH_H - 1.5, 0)
			local banner = newPart({ Name = "Banner", Size = Vector3.new(ROAD_W + 4.6, 3.4, 0.8),
				CFrame = CFrame.lookAt(bannerC, bannerC + fwd0), Color = COLOR.finishDark, CanCollide = false, Parent = arch })
			for _, face in ipairs({ Enum.NormalId.Front, Enum.NormalId.Back }) do
				local gui = Instance.new("SurfaceGui")
				gui.Face = face
				gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
				gui.PixelsPerStud = 30
				gui.Parent = banner
				local label = Instance.new("TextLabel")
				label.Size = UDim2.fromScale(1, 1)
				label.BackgroundTransparency = 1
				label.Text = "🏁 결승선 FINISH 🏁"
				label.TextScaled = true
				label.Font = Enum.Font.FredokaOne
				label.TextColor3 = COLOR.roadLine
				label.Parent = gui
			end
			arch.Parent = map

			-- traffic lights (see LIGHT_* above)
			local lights = folder("TrafficLights", map)
			for k = 0, 7 do
				local a = k == 0 and FINISH_ANGLE + LIGHT_START_ANGLE or k * 45
				local target = onGround(dir(a) * (ROAD_R + LIGHT_OUT), dir(a - 90)) -- facing back the way racers come
				local model = placeAsset("Prop_TrafficLight", target, lights)
				if not model then -- (not imported yet: a plain one of parts)
					model = Instance.new("Model")
					model.Name = "Prop_TrafficLight"
					newPart({ Name = "Pole", Size = Vector3.new(1.2, 7.2, 1.2), CFrame = target * CFrame.new(0, 3.6, 0),
						Color = COLOR.finishDark, Parent = model })
					newPart({ Name = "Housing", Size = Vector3.new(3, 6.4, 1.8), CFrame = target * CFrame.new(0, 9.46, 0),
						Color = COLOR.finishDark, Parent = model })
					model.Parent = lights
				end
				model:SetAttribute("Start", k == 0)
				for _, lamp in ipairs(LIGHT_LAMPS) do
					newPart({ Name = "Lamp" .. lamp[1], Shape = Enum.PartType.Cylinder,
						Size = Vector3.new(0.2, LIGHT_LAMP_RADIUS * 2, LIGHT_LAMP_RADIUS * 2),
						CFrame = target * CFrame.new(lamp[2]) * CFrame.Angles(0, math.rad(90), 0), Color = COLOR.finishDark,
						CanCollide = false, CanQuery = false, CastShadow = false, Parent = model })
				end
			end

			-- ---------------------------------------------------------------------------
			-- Bases
		end
		section()
	end
	-- ---------------------------------------------------------------------------

	-- low wooden fence along runs of plot coordinates {u0, v0, u1, v1} (u = right, v = depth from the entrance)
	local function fence(parent, runs, plotPoint, y)
		local fenceFolder = folder("Fence", parent)
		local posts = {}
		for _, run in ipairs(runs) do
			local a = plotPoint(run[1], run[2]) + Vector3.new(0, y, 0)
			local b = plotPoint(run[3], run[4]) + Vector3.new(0, y, 0)
			local length = (b - a).Magnitude
			for _, h in ipairs({ 1.1, 2.2 }) do -- two rails
				local mid = (a + b) / 2 + Vector3.new(0, h, 0)
				newPart({ Name = "Rail", Size = Vector3.new(0.4, 0.4, length), CFrame = CFrame.lookAt(mid, b + Vector3.new(0, h, 0)),
					Color = COLOR.fence, Parent = fenceFolder })
			end
			local n = math.ceil(length / 5)
			for k = 0, n do
				local p = a:Lerp(b, k / n)
				local key = string.format("%.1f,%.1f", p.X, p.Z)
				if not posts[key] then -- corners and joints are shared by two runs
					posts[key] = true
					local c = p + Vector3.new(0, 1.5, 0)
					newPart({ Name = "Post", Size = Vector3.new(0.8, 3, 0.8), CFrame = CFrame.lookAt(c, c + (b - a).Unit),
						Color = COLOR.fence, Parent = fenceFolder })
				end
			end
		end
	end

	-- sign board on two posts, its front face (the part's Front, for a SurfaceGui) toward face
	local function sign(name, target, color, parent)
		newPart({ Name = name, Size = Vector3.new(7, 2.6, 0.4), CFrame = target * CFrame.new(0, 3.5, 0), Color = color,
			Parent = parent })
		for _, x in ipairs({ -2.8, 2.8 }) do
			newPart({ Name = name .. "Post", Size = Vector3.new(0.5, 4.8, 0.5), CFrame = target * CFrame.new(x, 2.4, 0.3),
				Color = COLOR.fence, Parent = parent })
		end
	end

	-- a base's flags, pennants and planters (BASE_DECOR); its own function (the Command Bar's 200 locals)
	local function decorateBase(base, plotPoint, out, teamColor)
		local d = BASE_DECOR
		local decor = folder("BaseDecor", base)
		local y0 = groundY(plotPoint(0, 0).X, plotPoint(0, 0).Z)
		local function put(props) -- (2026-10-03, "지형지물 통과 가능한데": the poles and planters stop you, the rest not)
			local solid = props.Name == "FlagPole" or props.Name == "Planter"
			props.CanCollide, props.CanTouch, props.CanQuery = solid, false, solid
			props.Parent = decor
			return newPart(props)
		end
		-- the flag poles either side of the entrance, a flag on each, a gold ball on top
		local tops = {}
		for _, side in ipairs({ -1, 1 }) do
			local foot = plotPoint(side * (ENTRANCE_W / 2 + d.PoleOut), 0.5)
			foot = Vector3.new(foot.X, y0, foot.Z)
			put({ Name = "FlagPole", Shape = Enum.PartType.Cylinder, Size = Vector3.new(d.PoleHeight, 0.6, 0.6),
				CFrame = CFrame.new(foot + Vector3.new(0, d.PoleHeight / 2, 0)) * UPRIGHT, Color = COLOR.fence })
			put({ Name = "FlagBall", Shape = Enum.PartType.Ball, Size = Vector3.one * 1.2,
				CFrame = CFrame.new(foot + Vector3.new(0, d.PoleHeight + 0.4, 0)), Color = Color3.fromRGB(255, 205, 60),
				Material = Enum.Material.SmoothPlastic })
			local flagAt = foot + Vector3.new(0, d.PoleHeight - d.FlagSize.Y / 2 - 0.6, 0) - out * (d.FlagSize.Z / 2 + 0.3)
			put({ Name = "Flag", Size = d.FlagSize, CFrame = CFrame.lookAt(flagAt, flagAt + out), Color = teamColor })
			table.insert(tops, foot + Vector3.new(0, d.PoleHeight - 0.5, 0))
		end
		-- the string of pennants across the entrance, sagging a little
		local a, b = tops[1], tops[2]
		for k = 1, d.Pennants do
			local t = k / (d.Pennants + 1)
			local p = a:Lerp(b, t) - Vector3.new(0, math.sin(t * math.pi) * d.PennantSag, 0)
			put({ Name = "Pennant", Size = Vector3.new(0.15, 1.4, 1.1), CFrame = CFrame.lookAt(p, p + out) * CFrame.new(0, -0.7, 0),
				Color = k % 2 == 0 and Color3.new(1, 1, 1) or teamColor })
		end
		local mid = a:Lerp(b, 0.5) - Vector3.new(0, d.PennantSag, 0)
		for _, half in ipairs({ { a, mid }, { mid, b } }) do
			local p, q = half[1], half[2]
			put({ Name = "PennantRope", Size = Vector3.new(0.12, 0.12, (q - p).Magnitude), CFrame = CFrame.lookAt((p + q) / 2, q),
				Color = Color3.fromRGB(240, 240, 240) })
		end
		-- planters: a wooden box, dark soil and flowers
		for _, spot in ipairs(d.Planters) do
			local c = plotPoint(spot[1], spot[2])
			c = Vector3.new(c.X, groundY(c.X, c.Z), c.Z)
			local frame = CFrame.lookAt(c, c + out)
			put({ Name = "Planter", Size = d.PlanterSize, CFrame = frame * CFrame.new(0, d.PlanterSize.Y / 2, 0), Color = COLOR.fence })
			put({ Name = "Soil", Size = d.PlanterSize - Vector3.new(0.6, 0, 0.6), CFrame = frame * CFrame.new(0, d.PlanterSize.Y + 0.05, 0),
				Color = Color3.fromRGB(92, 64, 44) })
			for k = 1, 5 do
				local x = -d.PlanterSize.X / 2 + 0.9 + (k - 1) * (d.PlanterSize.X - 1.8) / 4
				put({ Name = "Flower", Shape = Enum.PartType.Ball, Size = Vector3.one * (0.9 + (k % 2) * 0.3),
					CFrame = frame * CFrame.new(x, d.PlanterSize.Y + 0.7, (k % 2 - 0.5) * 0.8),
					Color = d.FlowerColors[(k - 1) % #d.FlowerColors + 1], Material = Enum.Material.SmoothPlastic })
			end
		end
		for _, part in ipairs(decor:GetDescendants()) do
			if part:IsA("BasePart") then
				part.CastShadow = part.Name == "FlagPole" or part.Name == "Planter"
			end
		end
	end

	for i, a in ipairs(baseAngles) do
		local out, right = dir(a), dir(a + 90) -- out: from the center through the plot; right: a player's right walking in
		local center = out * BASE_R
		local function plotPoint(u, v)
			return center + right * u + out * (v - PLOT_D / 2)
		end
		local function at(u, v, face)
			return onGround(plotPoint(u, v), face)
		end
		local base = folder("Base" .. i, map)
		base:SetAttribute("BaseIndex", i)
		base:SetAttribute("TeamColor", TEAM_COLORS[i])

		-- front strip
		placeAsset("Base_DepositBin", at(0, 27, -out), base) -- front middle
		placeAsset("Base_Shop", at(-52.5, 27, -out), base) -- front left
		newPart({ Name = "SpawnLocation", Size = Vector3.new(6, 1, 6), CFrame = at(52.5, 27, -out) * CFrame.new(0, 0.5, 0),
			BrickColor = BrickColor.new(TEAM_COLORS[i]), TeamColor = BrickColor.new(TEAM_COLORS[i]), Neutral = false,
			AllowTeamChangeOnTouch = false, Parent = base }, "SpawnLocation") -- front right
		-- defense field (back right): arena with its curb gap toward the entrance, the portal in the gap
		local arenaCF = at(52.5, 111, -out)
		placeAsset("Base_Arena", arenaCF, base)
		placeAsset("Base_SpawnPortal", arenaCF * CFrame.new(0, 0, -ARENA_GATE), base)
		sign("DefenseSign", at(22, FIELD_V + 3, -out), COLOR.defenseSign, base)
		-- farm field (back left): the pen's gate toward the entrance
		placeAsset("Base_FarmPen", at(-52.5, 111, -out), base)
		sign("FarmSign", at(-33, FIELD_V + 3, -out), COLOR.farmSign, base)

		local hw, gap = PLOT_W / 2, ENTRANCE_W / 2
		fence(base, {
			{ -hw, PLOT_D, hw, PLOT_D }, { -hw, 0, -hw, PLOT_D }, { hw, 0, hw, PLOT_D }, -- back and sides
			{ -hw, 0, -gap, 0 }, { gap, 0, hw, 0 }, -- front, leaving the entrance open
			{ 0, FIELD_V, 0, PLOT_D }, -- between the two fields
		}, plotPoint, groundY(center.X, center.Z))
		decorateBase(base, plotPoint, out, BrickColor.new(TEAM_COLORS[i]).Color)
		local zoneCenter = center + Vector3.new(0, 30, 0)
		hidden(newPart({ Name = "SafeZone", Size = Vector3.new(PLOT_W, 60, PLOT_D),
			CFrame = CFrame.lookAt(zoneCenter, zoneCenter + out), Parent = base }), true, true)
	end

	-- ---------------------------------------------------------------------------
	-- Decoration: trees and rocks between the bases, the border beyond MAP_R
	-- ---------------------------------------------------------------------------

	local function tree(parent, pos, s, yaw, leafColor)
		local m = Instance.new("Model")
		m.Name = "Tree"
		s *= TREE_TALLER
		local trunkH = 5 * s
		local w = TREE_WIDER
		newPart({ Name = "Trunk", Shape = Enum.PartType.Cylinder, Size = Vector3.new(trunkH + 1, 1.6 * s * w, 1.6 * s * w),
			CFrame = CFrame.new(pos + Vector3.new(0, trunkH / 2 - 0.5, 0)) * UPRIGHT, Color = COLOR.trunk, Parent = m })
		newPart({ Name = "Leaves", Shape = Enum.PartType.Ball, Size = Vector3.one * 7 * s * math.sqrt(w),
			CFrame = CFrame.new(pos + Vector3.new(0, trunkH + 2 * s, 0)), Color = leafColor, Parent = m })
		newPart({ Name = "Leaves", Shape = Enum.PartType.Ball, Size = Vector3.one * 4.5 * s * math.sqrt(w),
			CFrame = CFrame.new(pos + Vector3.new(0, trunkH + 5 * s, 0) + dir(yaw) * 1.2 * s), Color = COLOR.leafLight,
			Parent = m })
		m.Parent = parent
		return m
	end

	-- a clump of trees in one mesh where nobody goes (TREE_CLUMPS), sized like tree(s): its trunks' feet at pos;
	-- light: the lighter green one. Without the models, one tree() there instead.
	local function treeClump(parent, pos, s, yaw, light)
		local name = light and "Prop_TreeClump_C" or TREE_CLUMPS[1 + math.floor(rand() * #TREE_CLUMPS)]
		local model = placeAsset(name, CFrame.new(pos) * CFrame.Angles(0, math.rad(yaw), 0), parent)
		if model then
			model:ScaleTo(s)
		else
			model = tree(parent, pos, s, yaw, light and COLOR.leaf or COLOR.leafDark)
		end
		model.Name = "TreeClump" -- (not a fruit tree: Fruits looks for "Tree")
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") then
				d.CanCollide, d.CanTouch, d.CanQuery = false, false, false
			end
		end
	end

	local function rock(parent, pos, s, yaw)
		local m = Instance.new("Model")
		m.Name = "Rock"
		newPart({ Name = "Stone", Size = Vector3.new(3.6, 2.4, 3) * s,
			CFrame = CFrame.new(pos + Vector3.new(0, 0.8 * s, 0)) * CFrame.Angles(0, math.rad(yaw), math.rad(10)),
			Color = COLOR.rock, Parent = m })
		newPart({ Name = "Stone", Size = Vector3.new(1.8, 1.4, 1.6) * s,
			CFrame = CFrame.new(pos + dir(yaw) * 2.2 * s + Vector3.new(0, 0.4 * s, 0)) * CFrame.Angles(math.rad(8), math.rad(yaw + 40), 0),
			Color = COLOR.rock, Parent = m })
		m.Parent = parent
	end

	-- a bush: three low leaf balls you can walk into and hide in
	local function bush(parent, pos, s)
		local m = Instance.new("Model")
		m.Name = "Bush"
		for i, b in ipairs({ { 3.2, 0, 0 }, { 2.6, 1.3, 0.6 }, { 2.3, -1.1, -0.9 } }) do
			local size = b[1] * s
			newPart({ Name = "Leaves", Shape = Enum.PartType.Ball, Size = Vector3.one * size, CanCollide = false,
				CFrame = CFrame.new(pos + Vector3.new(b[2] * s, size * 0.35, b[3] * s)),
				Color = i == 1 and COLOR.leafDark or COLOR.leaf, Parent = m })
		end
		m.Parent = parent
	end

	-- a fallen log to jump over, with a stump at one end
	local function log(parent, pos, s, yaw)
		local m = Instance.new("Model")
		m.Name = "Log"
		newPart({ Name = "Log", Shape = Enum.PartType.Cylinder, Size = Vector3.new(7 * s, 1.3 * s, 1.3 * s),
			CFrame = CFrame.new(pos + Vector3.new(0, 0.6 * s, 0)) * CFrame.Angles(0, math.rad(yaw), 0), Color = COLOR.trunk,
			Parent = m })
		newPart({ Name = "Log", Shape = Enum.PartType.Cylinder, Size = Vector3.new(1.2 * s, 1.7 * s, 1.7 * s),
			CFrame = CFrame.new(pos + dir(yaw) * 4.6 * s + Vector3.new(0, 0.6 * s, 0)) * UPRIGHT, Color = COLOR.trunk, Parent = m })
		m.Parent = parent
	end

	-- a few toadstools: white stems, red caps with white spots
	local function mushroom(parent, pos, s, yaw)
		local m = Instance.new("Model")
		m.Name = "Mushroom"
		for i = 1, 3 do
			local k = ({ 1, 0.7, 0.5 })[i]
			local at = pos + dir(yaw + i * 120) * (i == 1 and 0 or 1.6 * s)
			local h = 1.8 * s * k
			newPart({ Name = "Stem", Shape = Enum.PartType.Cylinder, Size = Vector3.new(h, 0.7 * s * k, 0.7 * s * k),
				CFrame = CFrame.new(at + Vector3.new(0, h / 2, 0)) * UPRIGHT, Color = COLOR.mushroomStem, Parent = m })
			local cap = 2.4 * s * k
			newPart({ Name = "Cap", Shape = Enum.PartType.Ball, Size = Vector3.one * cap,
				CFrame = CFrame.new(at + Vector3.new(0, h + cap * 0.15, 0)), Color = COLOR.mushroomCap, Parent = m })
			newPart({ Name = "Spot", Shape = Enum.PartType.Ball, Size = Vector3.one * cap * 0.22, CanCollide = false,
				CFrame = CFrame.new(at + Vector3.new(cap * 0.2, h + cap * 0.55, 0)), Color = COLOR.mushroomStem, Parent = m })
		end
		m.Parent = parent
	end

	-- a grass tuft: a few thin blades leaning out, not in the way of anything (no collision, no shadow)
	local function grass(parent, pos, s, yaw)
		local m = Instance.new("Model")
		m.Name = "Grass"
		for i = 1, GRASS_BLADES do
			local a = yaw + i * 360 / GRASS_BLADES + rand() * 40
			local h = (1.1 + rand() * 1.1) * s
			local lean = math.rad(15 + rand() * 20)
			local blade = newPart({ Name = "Blade", Size = Vector3.new(0.2 * s, h, 0.55 * s), CanCollide = false,
				CanQuery = false, CanTouch = false, CastShadow = false,
				CFrame = CFrame.new(pos) * CFrame.Angles(0, math.rad(a), 0) * CFrame.new(0, 0, -0.3 * s)
					* CFrame.Angles(-lean, 0, 0) * CFrame.new(0, h / 2 - 0.1, 0),
				Color = i % 2 == 0 and COLOR.grass or COLOR.grassLight, Parent = m }, "WedgePart")
			blade.Material = Enum.Material.Grass
		end
		m.Parent = parent
		return m
	end

	-- (2026-10-02, "풀에자라는 꽃색도 다양화해") little flowers of many colors in some clumps (the Blender clumps'
	-- own flowers are painted into the mesh, always yellow): a stem and a round head, inside the clump's model so they
	-- bend with it (StarterPlayerScripts/GrassSway); the clump's own height × s
	local function flowers(model, pos, s)
		if not model or rand() >= FLOWERS.Share then
			return
		end
		local color = FLOWERS.Colors[math.floor(rand() * #FLOWERS.Colors) + 1] -- (one kind a clump)
		for _ = 1, 1 + math.floor(rand() * FLOWERS.MaxPerClump) do
			local at = pos + dir(rand() * 360) * rand() * 0.45 * s
			local h = (FLOWERS.Height[1] + rand() * (FLOWERS.Height[2] - FLOWERS.Height[1])) * s
			newPart({ Name = "FlowerStem", Size = Vector3.new(0.12, h, 0.12), CFrame = CFrame.new(at + Vector3.new(0, h / 2, 0)),
				Color = COLOR.grass, CanCollide = false, CanTouch = false, CanQuery = false, CastShadow = false, Parent = model })
			local head = FLOWERS.Head * (0.8 + rand() * 0.4) * math.sqrt(s)
			newPart({ Name = "Flower", Shape = Enum.PartType.Ball, Size = Vector3.one * head,
				CFrame = CFrame.new(at + Vector3.new(0, h + head * 0.3, 0)), Color = color, CanCollide = false,
				CanTouch = false, CanQuery = false, CastShadow = false, Parent = model })
		end
	end

	-- a giant fossil skeleton half out of the ground: a spine, arching ribs to hide between, a skull
	local function fossil(parent, pos, s, yaw)
		local m = Instance.new("Model")
		m.Name = "Fossil"
		local base = CFrame.new(pos) * CFrame.Angles(0, math.rad(yaw), 0)
		local length = 16 * s
		newPart({ Name = "Bone", Shape = Enum.PartType.Cylinder, Size = Vector3.new(length, 1.2 * s, 1.2 * s),
			CFrame = base * CFrame.new(0, 6 * s, 0), Color = COLOR.bone, Parent = m })
		for i = 0, 5 do
			local x = -length / 2 + (i + 1) * length / 7
			local rib = 6.5 * s * (1 - math.abs(i - 2.5) / 6)
			for _, side in ipairs({ -1, 1 }) do -- a rib from the spine curving down to the ground
				newPart({ Name = "Bone", Size = Vector3.new(0.8 * s, rib, 0.8 * s),
					CFrame = base * CFrame.new(x, 6 * s - rib / 2 + 0.3 * s, side * rib * 0.35) * CFrame.Angles(side * math.rad(-28), 0, 0),
					Color = COLOR.bone, Parent = m })
			end
		end
		newPart({ Name = "Bone", Size = Vector3.new(4.5, 3.2, 3.4) * s, CFrame = base * CFrame.new(length / 2 + 2 * s, 2.8 * s, 0)
			* CFrame.Angles(0, 0, math.rad(-15)), Color = COLOR.bone, Parent = m }) -- the skull
		newPart({ Name = "Bone", Size = Vector3.new(3.8, 0.9, 2.8) * s, CFrame = base * CFrame.new(length / 2 + 2.6 * s, 0.9 * s, 0),
			Color = COLOR.bone, Parent = m }) -- its jaw on the ground
		m.Parent = parent
	end

	-- a round pond: water to splash through, stones around it
	local function pond(parent, pos, radius)
		local m = Instance.new("Model")
		m.Name = "Pond"
		newPart({ Name = "Water", Shape = Enum.PartType.Cylinder, Size = Vector3.new(0.3, radius * 2, radius * 2), CanCollide = false,
			Material = Enum.Material.Glass, Transparency = 0.25, CFrame = CFrame.new(pos + Vector3.new(0, 0.12, 0)) * UPRIGHT,
			Color = COLOR.water, Parent = m })
		for k = 0, 9 do
			local a = k * 36 + rand() * 12
			local size = 1.4 + rand() * 1.4
			newPart({ Name = "Stone", Size = Vector3.new(size * 1.3, size * 0.7, size), CFrame = CFrame.new(pos + dir(a) * (radius + 0.6)
				+ Vector3.new(0, size * 0.25, 0)) * CFrame.Angles(0, math.rad(a), 0), Color = COLOR.rock, Parent = m })
		end
		m.Parent = parent
	end

	local function pick(mix)
		local roll, sum = rand(), 0
		for _, kind in ipairs({ "tree", "rock", "bush", "mushroom", "log" }) do
			sum += mix[kind] or 0
			if roll < sum then
				return kind
			end
		end
		return "rock"
	end

	-- a Blender plant from Assets (tools/make_foliage.py), s times its size, turned yaw degrees; nothing
	-- collides but an invisible trunk for the trees. nil when the asset is missing
	local function hasAll(names)
		for _, name in ipairs(names) do
			if not findAsset(name) then
				return false
			end
		end
		return true
	end
	local foliageTrees, foliageGrass = hasAll(FOLIAGE_TREES), hasAll(FOLIAGE_GRASS)
	local function foliage(name, pos, s, yaw, parent, trunk)
		local source = findAsset(name)
		if not source then
			return nil
		end
		local model = source:Clone()
		if not model:IsA("Model") then
			local wrap = Instance.new("Model")
			wrap.Name = name
			model.Parent = wrap
			model = wrap
		end
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") then
				d.Anchored, d.CanCollide, d.CanTouch, d.CanQuery = true, false, false, false
				-- (2026-10-02, "떠있는 야자나무": the palm, made without a round trunk collider, cast no shadow and looked
				-- afloat) every tree casts its shadow, the grass does not
				d.CastShadow = trunk ~= nil or TRUNK_LINES[name] ~= nil
			end
		end
		local lo, hi = worldBounds(model)
		model.WorldPivot = CFrame.new((lo[1] + hi[1]) / 2, lo[2], (lo[3] + hi[3]) / 2)
		model:ScaleTo(s)
		model:PivotTo(CFrame.new(pos) * CFrame.Angles(0, math.rad(yaw), 0))
		if trunk then -- bump into the trunk, walk under the leaves
			newPart({ Name = "TrunkCollider", Shape = Enum.PartType.Cylinder, Size = Vector3.new(trunk.Y, trunk.X, trunk.X),
				CFrame = CFrame.new(pos + Vector3.new(0, trunk.Y / 2, 0)) * UPRIGHT, Transparency = 1, CanTouch = false,
				Parent = model })
		end
		model.Parent = parent
		return model
	end

	local function prop(parent, kind, pos, s, yaw, leafColor)
		if kind == "tree" and foliageTrees and rand() < FOLIAGE_TREE_SHARE then
			-- a Blender tree about as tall as the part-built one (11.5 × s)
			local scale = 11.5 * s / FOLIAGE_TREE_SIZE * TREE_TALLER
			local name = FOLIAGE_TREES[math.floor(rand() * #FOLIAGE_TREES) + 1]
			pos -= Vector3.new(0, TREE_SINK * scale, 0) -- (the trunk's rounded foot goes into the ground)
			local line = TRUNK_LINES[name]
			local model = foliage(name, pos, scale, yaw, parent,
				not line and Vector2.new(1.5 * scale * TREE_WIDER, 6 * scale) or nil)
			if model and line then -- a leaning trunk: colliders up its line (as wide as the trunk drawn below)
				local turn = CFrame.new(pos) * CFrame.Angles(0, math.rad(yaw), 0)
				local function at(p)
					return turn * Vector3.new(p[1] * scale * TREE_WIDER, p[2] * scale, p[3] * scale * TREE_WIDER)
				end
				for i = 1, #line - 1 do
					local a, b = at(line[i]), at(line[i + 1])
					local r = (line[i][4] + line[i + 1][4]) / 2 * scale * TREE_WIDER
					newPart({ Name = "TrunkCollider", Shape = Enum.PartType.Cylinder,
						Size = Vector3.new((b - a).Magnitude + r, 2 * r, 2 * r),
						CFrame = CFrame.lookAt((a + b) / 2, b) * CFrame.Angles(0, math.pi / 2, 0), Transparency = 1,
						CanTouch = false, Parent = model })
				end
			end
			if model then -- wider round the trunk's line, the trunk collider already is
				for _, d in ipairs(model:GetDescendants()) do
					if d:IsA("BasePart") and d.Name ~= "TrunkCollider" then
						local off = d.Position - pos
						d.Size = Vector3.new(d.Size.X * TREE_WIDER, d.Size.Y, d.Size.Z * TREE_WIDER)
						d.CFrame = CFrame.new(pos + Vector3.new(off.X * TREE_WIDER, off.Y, off.Z * TREE_WIDER)) * d.CFrame.Rotation
					end
				end
			end
		elseif kind == "tree" then
			tree(parent, pos, s, yaw, leafColor)
		elseif kind == "rock" then
			rock(parent, pos, s, yaw)
		elseif kind == "bush" then
			bush(parent, pos, s * 0.8)
		elseif kind == "mushroom" then
			mushroom(parent, pos, s * 0.7, yaw)
		else
			log(parent, pos, s * 0.8, yaw)
		end
	end

	local decorFolder = folder("Decor", map)
	local decor, decorTries = {}, 0
	reseed(202)
	-- ponds first (they need the most room), then the rest between them
	local ponds, pondTries = {}, 0
	while #ponds < POND_COUNT and pondTries < 5000 do
		pondTries += 1
		local r = RING_OUT + 40 + rand() * (MAP_R - RING_OUT - 70)
		local p = dir(rand() * 360) * r
		if not inPlot(p, 30) and not onPath(p, 24) and not onRoad(p, 24) and farFrom(ponds, p, POND_GAP) then
			table.insert(ponds, p)
			table.insert(decor, p)
			pond(decorFolder, Vector3.new(p.X, groundY(p.X, p.Z), p.Z), 9 + rand() * 7)
		end
	end
	while #decor < DECOR_COUNT and decorTries < 30000 do
		decorTries += 1
		local r = math.sqrt((RING_OUT + 12) ^ 2 + rand() * ((MAP_R - 8) ^ 2 - (RING_OUT + 12) ^ 2))
		local p = dir(rand() * 360) * r
		if not inPlot(p, 14) and not onPath(p, 12) and not onRoad(p, 12) and farFrom(decor, p, DECOR_GAP)
			and farFrom(ponds, p, 22) then
			table.insert(decor, p) -- canopies stay off plots, paths and ponds
			local s, yaw = (0.8 + rand() * 0.6) * DECOR_SCALE, rand() * 360
			prop(decorFolder, pick(DECOR_MIX), Vector3.new(p.X, groundY(p.X, p.Z), p.Z), s, yaw, COLOR.leaf)
		end
	end

	-- the battlefield: rocks (mostly) and a few trees between the ore spots, off the paths and the plaza,
	-- so the open field has cover and landmarks
	local fieldFolder = folder("FieldDecor", map)
	local field, fieldTries = {}, 0
	local fieldRadius = {} -- (each one's reach, by field's order)
	-- giant fossils first, where fieldPlan put them (before the ore spots)
	local fossils = {}
	for _, f in ipairs(fieldPlan.fossils) do
		table.insert(fossils, f.p)
		table.insert(field, f.p)
		table.insert(fieldRadius, FOSSIL_REACH * f.size)
		fossil(fieldFolder, Vector3.new(f.p.X, groundY(f.p.X, f.p.Z), f.p.Z), f.size, f.yaw)
	end
	for _, walk in ipairs(fieldPlan.walks) do -- (the giant footprints, drawn with the ground marks: kept clear)
		for _, at in ipairs(walk.spots) do
			table.insert(field, at)
			table.insert(fieldRadius, GIANT_PRINTS.Pad + GIANT_PRINTS.ToeLength)
		end
	end
	reseed(404)
	do -- (a function of its own: the Command Bar gives each function only 200 locals)
		local function section()
			-- the dig camps, nests and tar pits (FIELD_PROPS), off the paths, the ore spots and the other props
			-- (2026-10-03, "지형지물 통과 가능한데 새로운거") solid like the rocks and trees, and kept in FieldDecor so
			-- everything that keeps off those (speed pads, chests, the zombies' and wild dinos' ground) keeps off these
			local fieldProps = folder("FieldProps", fieldFolder)
			reseed(808)
			for k, item in ipairs(FIELD_PROPS) do
				local placed = 0
				for _, p in ipairs(fieldPlan.props[k]) do -- (spots chosen before the ore spots: fieldPlan)
					local at = Vector3.new(p.X, groundY(p.X, p.Z), p.Z)
					local model = placeAsset(item.Asset, CFrame.new(at) * CFrame.Angles(0, math.rad(rand() * 360), 0), fieldProps)
					if not model then
						break -- (not in Assets: noted once by placeAsset)
					end
					model:ScaleTo(item.Scale)
					for _, d in ipairs(model:GetDescendants()) do
						if d:IsA("BasePart") then
							d.CanCollide, d.CanTouch, d.CanQuery, d.CastShadow = true, false, true, item.Shadow == true
							if item.Precise then -- (walk round the tent and between the crates, not into a box round all)
								pcall(function()
									d.CollisionFidelity = Enum.CollisionFidelity.PreciseConvexDecomposition
								end)
							end
						end
					end
					placed += 1
					table.insert(field, p) -- (the rocks, trees, grass and ground marks keep off it)
					table.insert(fieldRadius, item.Foot)
				end
				if placed < item.Count and findAsset(item.Asset) then
					warn(("[MapBuilder] 배틀필드 %s: %d개 중 %d개만 놓음 (자리 부족)"):format(item.Asset, item.Count, placed))
				end
			end
		end
		section()
	end
	-- then the rocks, bushes, trees, logs and mushrooms, each kept off the others by its own size (PROP_REACH;
	-- 2026-10-03, "배틀필드 내 물체들 겹침현상": only their middles were kept FIELD_GAP apart, and a big tree's
	-- crown or a fossil's ribs went through a rock)
	local placedProps = #field
	while #field < FIELD_DECOR_COUNT + placedProps and fieldTries < 60000 do
		fieldTries += 1
		local r = math.sqrt((WALK_R + 20) ^ 2 + rand() * ((RING_OUT - 12) ^ 2 - (WALK_R + 20) ^ 2))
		local p = dir(rand() * 360) * r
		local kind, s, yaw = pick(FIELD_MIX), (0.6 + rand() * 0.9) * DECOR_SCALE, rand() * 360
		local reach = PROP_REACH[kind] * s
		if not onPath(p, 6) and farFrom(ores, p, 9) and farFrom(field, p, FIELD_GAP)
			and roomAt(field, fieldRadius, p, reach * PROP_OVERLAP) then
			table.insert(field, p)
			table.insert(fieldRadius, reach)
			prop(fieldFolder, kind, Vector3.new(p.X, groundY(p.X, p.Z), p.Z), s, yaw, COLOR.leafDark)
		end
	end


	-- (2026-10-03, "기지 내부는 왜 안꾸몄지", "배틀필드 내 배치물 조금씩 갖다가 꾸미든가 해") inside each base, a few of the
	-- battlefield's things along the side fences, where nothing of the game stands (BASE_PROPS)
	do -- (a function of its own: the Command Bar gives each function only 200 locals)
		local function section()
			local bp = BASE_PROPS
			reseed(909)
			for i, a in ipairs(baseAngles) do
				local base = map:FindFirstChild("Base" .. i)
				if base then
					local out, right = dir(a), dir(a + 90)
					local center = out * BASE_R
					local holder = folder("BaseProps", base)
					for _, spot in ipairs(bp.Spots) do
						for _, side in ipairs(spot[2] > FIELD_V and { -1 } or { -1, 1 }) do
							local u, v = side * spot[1], spot[2]
							for k = 3, #spot do
								local kind = spot[k]
								local p = center + right * (u - side * (k - 3) * bp.Step) + out * (v - PLOT_D / 2 + (k - 3) * bp.Step * 0.5)
								local at = Vector3.new(p.X, groundY(p.X, p.Z), p.Z)
								if kind == "nest" then
									local nest = placeAsset("Prop_Nest", CFrame.lookAt(at, at - out), holder)
									if nest then
										nest:ScaleTo(bp.NestScale)
									else
										prop(holder, "bush", at, bp.Scale[2] * DECOR_SCALE, 0, COLOR.leaf)
									end
								else
									local size = (bp.Scale[1] + rand() * (bp.Scale[2] - bp.Scale[1])) * DECOR_SCALE
									prop(holder, kind, at, size, rand() * 360, COLOR.leaf)
								end
							end
						end
					end
					-- (2026-10-03, "지형지물 통과 가능한데 새로운거") as solid as the same things elsewhere on the map: rocks,
					-- logs and the nests stop you, bushes and mushrooms don't (prop's own settings)
				end
			end
		end
		section()
	end

	-- grass tufts all over the battlefield, off the paths and the ore spots (they grow next to rocks)
	local grassFolder = folder("FieldGrass", map)
	local tufts, grassTries = {}, 0
	reseed(505)
	-- the Blender clumps when they are in Assets (fewer, a little here and there), else the part tufts
	local grassCount = foliageGrass and GRASS_ASSET_COUNT or GRASS_COUNT
	local grassGap = foliageGrass and GRASS_ASSET_GAP or GRASS_GAP
	while #tufts < grassCount and grassTries < 40000 do
		grassTries += 1
		local r = math.sqrt((WALK_R + 10) ^ 2 + rand() * ((RING_OUT - 6) ^ 2 - (WALK_R + 10) ^ 2))
		local p = dir(rand() * 360) * r
		if not onPath(p, 3) and farFrom(ores, p, 6) and farFrom(tufts, p, grassGap) and farFrom(field, p, PROP_CLEAR) then
			table.insert(tufts, p)
			local at = Vector3.new(p.X, groundY(p.X, p.Z), p.Z)
			if foliageGrass then
				local scale = GRASS_ASSET_SCALE[1] + rand() * (GRASS_ASSET_SCALE[2] - GRASS_ASSET_SCALE[1])
				flowers(foliage(FOLIAGE_GRASS[math.floor(rand() * #FOLIAGE_GRASS) + 1], at, scale, rand() * 360, grassFolder), at, scale)
			else
				local s = 0.8 + rand() * 0.6
				flowers(grass(grassFolder, at, s, rand() * 360), at, s)
			end
		end
	end

	do -- (a function of its own: the Command Bar gives each function only 200 locals)
		local function section()
			-- the battlefield's earth patterns (FIELD_GROUND): no collision, no raycast hits, no shadow; each a hair above
			-- the brown ring (a little different heights so overlapping ones don't flicker)
			local groundDecor = folder("FieldGround", map)
			reseed(707)
			local fg = FIELD_GROUND
			local layer = 0
			local function flatPart(name, size, cf, color, shape)
				layer = (layer + 1) % 9
				local part = newPart({ Name = name, Shape = shape, Size = size, CFrame = CFrame.new(0, layer * 0.004, 0) * cf,
					Color = color, CanCollide = false, CanTouch = false, CanQuery = false, CastShadow = false, Parent = groundDecor })
				return part
			end
			-- (2026-10-03, "바닥 무늬 겹침 현상 있음") the marks keep off one another too: every mark put down is a circle
			-- (marks: { at, radius }), the giant prints' first (they are planned before everything), and a new one is
			-- only put where it overlaps none of them
			local marks = {}
			local function markFree(p, radius)
				for _, m in ipairs(marks) do
					if (Vector3.new(p.X, 0, p.Z) - Vector3.new(m[1].X, 0, m[1].Z)).Magnitude < radius + m[2] then
						return false
					end
				end
				return true
			end
			local function mark(p, radius)
				table.insert(marks, { p, radius })
			end
			local MARK_TRIES = 4
			for _, walk in ipairs(fieldPlan.walks) do
				for _, at in ipairs(walk.spots) do
					mark(at, GIANT_PRINTS.Pad + GIANT_PRINTS.ToeLength + 3)
				end
			end
			-- (2026-10-03, "배틀필드 내 물체들 겹침현상") the marks keep off the rocks, trees, fossils and props too (reach)
			local function fieldSpot(margin, reach, room)
				for _ = 1, 40 do
					local r = math.sqrt((WALK_R + 6) ^ 2 + rand() * ((RING_OUT - 10) ^ 2 - (WALK_R + 6) ^ 2))
					local p = dir(rand() * 360) * r
					if not onPath(p, margin) and roomAt(field, fieldRadius, p, reach or margin) and markFree(p, room or 0) then
						return p
					end
				end
				return nil
			end
			local GROUND_Y = TOP.dirt + 0.02
			local UPRIGHT_DISC = CFrame.Angles(0, 0, math.rad(90)) -- a cylinder lying flat
			-- patches: two or three round blobs of one earth color
			local patchColors = { COLOR.dirtDark, COLOR.dirtLight, COLOR.sand, COLOR.dirtDark }
			-- (each kind keeps looking, up to MARK_TRIES times its count, till it has its count of marks)
			local placed, tries = 0, 0
			while placed < fg.Patches and tries < fg.Patches * MARK_TRIES do
				tries += 1
				local radius = fg.PatchRadius[1] + rand() * (fg.PatchRadius[2] - fg.PatchRadius[1])
				local p = fieldSpot(2, radius * 1.4, radius * 1.6)
				if p then
					placed += 1
					mark(p, radius * 1.6) -- (its blobs reach about this far)
					local color = patchColors[math.floor(rand() * #patchColors) + 1]
					for b = 1, 2 + math.floor(rand() * 2) do
						local at = p + (b == 1 and Vector3.zero or dir(rand() * 360) * radius * 0.6)
						local rad = radius * (b == 1 and 1 or 0.45 + rand() * 0.35)
						flatPart("EarthPatch", Vector3.new(0.06, rad * 2, rad * 2), CFrame.new(at.X, GROUND_Y, at.Z) * UPRIGHT_DISC,
							color, Enum.PartType.Cylinder)
					end
				end
			end
			-- cracks: a zigzag of thin dark lines
			placed, tries = 0, 0
			while placed < fg.Cracks and tries < fg.Cracks * MARK_TRIES do
				tries += 1
				local p = fieldSpot(2, 14, 2)
				if p then
					-- the whole zigzag first; it stops where it would run into another mark
					local heading = rand() * 360
					local points = { p }
					local at = p
					for _ = 1, fg.CrackSegments[1] + math.floor(rand() * (fg.CrackSegments[2] - fg.CrackSegments[1] + 1)) do
						heading += (rand() - 0.5) * 80
						local to = at + dir(heading) * (2.5 + rand() * 3.5)
						if not markFree(to, 1.5) or not markFree((at + to) / 2, 1.5) then
							break
						end
						table.insert(points, to)
						at = to
					end
					if #points >= 3 then -- (two lines at least, else it is no crack: look again)
						placed += 1
					else
						points = {}
					end
					for k = 2, #points do
						local from, to = points[k - 1], points[k]
						local mid = (from + to) / 2
						flatPart("Crack", Vector3.new(0.35 + rand() * 0.25, 0.06, (to - from).Magnitude + 0.3),
							CFrame.lookAt(Vector3.new(mid.X, GROUND_Y + 0.03, mid.Z), Vector3.new(to.X, GROUND_Y + 0.03, to.Z)), COLOR.crack)
					end
					for k = 1, #points do
						mark(points[k], 1.5)
						if k > 1 then
							mark((points[k - 1] + points[k]) / 2, 1.5)
						end
					end
				end
			end
			-- pebbles: little stones in a cluster, half in the ground
			for _ = 1, fg.Pebbles do
				local p = fieldSpot(3, 3.5, 3.5)
				if p then
					mark(p, 3.5)
					for _ = 1, fg.PebbleCluster[1] + math.floor(rand() * (fg.PebbleCluster[2] - fg.PebbleCluster[1] + 1)) do
						local at = p + dir(rand() * 360) * rand() * 2.5
						local size = 0.4 + rand() * 0.8
						flatPart("Pebble", Vector3.one * size, CFrame.new(at.X, TOP.dirt - size * 0.2, at.Z), -- (a ball, mostly sunk)
							rand() < 0.5 and COLOR.pebble or COLOR.pebbleDark, Enum.PartType.Ball)
					end
				end
			end
			-- dino footprints: trails of three-toed prints, left and right, across the ring
			placed, tries = 0, 0
			while placed < fg.Trails and tries < fg.Trails * MARK_TRIES do
				tries += 1
				local p = fieldSpot(4, nil, 2.5)
				if p then
					placed += 1
					local heading = rand() * 360
					local big = 0.8 + rand() * 0.7 -- (a bigger dino, bigger prints)
					local steps = fg.FootprintSteps[1] + math.floor(rand() * (fg.FootprintSteps[2] - fg.FootprintSteps[1] + 1))
					for k = 0, steps - 1 do
						heading += (rand() - 0.5) * 12
						local side = (k % 2 == 0 and 1 or -1) * 0.9 * big
						local at = p + dir(heading) * (k * fg.Stride * big) + dir(heading + 90) * side
						if onPath(at, 1) or not roomAt(field, fieldRadius, at, 1.5) or not markFree(at, 1.6 * big) then
							break
						end
						mark(at, 1.6 * big) -- (the next print, a stride on, is clear of it)
						local frame = CFrame.new(at.X, GROUND_Y + 0.05, at.Z) * CFrame.Angles(0, math.rad(-heading), 0)
						flatPart("Footprint", Vector3.new(0.06, 1.3 * big, 1.3 * big), frame * UPRIGHT_DISC, COLOR.dirtDark,
							Enum.PartType.Cylinder) -- the pad
						for _, toe in ipairs({ -30, 0, 30 }) do -- three toes, spread forward
							local toeFrame = frame * CFrame.Angles(0, math.rad(toe), 0) * CFrame.new(0, 0, -1.05 * big)
							flatPart("Footprint", Vector3.new(0.38 * big, 0.06, 1.0 * big), toeFrame, COLOR.dirtDark)
						end
					end
				end
			end

			-- (2026-10-02, "배틀필드에 거대 공룡 발자국 모양으로 홈도 파진다거나 할 수 있나 한 두군데") giant footprints that look
			-- pressed into the ground: a dark sunken print (the pad and three long toes) with heaped earth round its edge,
			-- GIANT_PRINTS.Walks places, Steps prints each, left and right as a giant walked by. (The ground is parts: a
			-- real hole would mean cutting the floor; the look of one does not.) Walkable: the rim is low.
			local gp = GIANT_PRINTS
			reseed(808)
			local walks = 0
			for _, walk in ipairs(fieldPlan.walks) do -- (chosen before the ore spots and the rocks: fieldPlan)
				local heading, spots = walk.heading, walk.spots
				do
					walks += 1
					for _, at in ipairs(spots) do
						local frame = CFrame.new(at.X, GROUND_Y + 0.06, at.Z) * CFrame.Angles(0, math.rad(-heading), 0)
						local outline = {} -- (rim mounds go round these)
						flatPart("GiantPrint", Vector3.new(0.06, gp.Pad * 2, gp.Pad * 2), frame * UPRIGHT_DISC, COLOR.crack,
							Enum.PartType.Cylinder)
						table.insert(outline, { frame.Position, gp.Pad })
						for _, toe in ipairs({ -32, 0, 32 }) do
							local toeFrame = frame * CFrame.Angles(0, math.rad(toe), 0) * CFrame.new(0, 0, -(gp.Pad + gp.ToeLength * 0.4))
							flatPart("GiantPrint", Vector3.new(gp.ToeWidth, 0.06, gp.ToeLength), toeFrame, COLOR.crack)
							local tip = (toeFrame * CFrame.new(0, 0, -gp.ToeLength / 2)).Position
							flatPart("GiantPrint", Vector3.new(0.06, gp.ToeWidth, gp.ToeWidth), CFrame.new(tip) * UPRIGHT_DISC,
								COLOR.crack, Enum.PartType.Cylinder) -- (a round toe tip)
							table.insert(outline, { toeFrame.Position, gp.ToeWidth / 2 + 0.6 })
							table.insert(outline, { tip, gp.ToeWidth / 2 })
						end
						-- heaped earth: lumps round the outside of the print, not over it
						for _, o in ipairs(outline) do
							for m = 1, gp.RimLumps do
								local p = o[1] + dir(m * 360 / gp.RimLumps + rand() * 20) * (o[2] + 0.5)
								local inside = false
								for _, other in ipairs(outline) do
									if (Vector3.new(p.X, 0, p.Z) - Vector3.new(other[1].X, 0, other[1].Z)).Magnitude < other[2] then
										inside = true
									end
								end
								if not inside then
									local size = gp.RimSize[1] + rand() * (gp.RimSize[2] - gp.RimSize[1])
									flatPart("GiantPrintRim", Vector3.one * size, CFrame.new(p.X, TOP.dirt - size * 0.3, p.Z),
										rand() < 0.5 and COLOR.dirtLight or COLOR.dirt, Enum.PartType.Ball)
								end
							end
						end
					end
				end
			end
			if walks < gp.Walks then
				warn(string.format("[MapBuilder] 거대 공룡 발자국 자리를 %d/%d곳만 찾았습니다", walks, gp.Walks))
			end
		end
		section()
	end

	do -- (a function of its own: the Command Bar gives each function only 200 locals)
		local function section()
			-- grass in the safe land, outside the base fences and the race track, off the paths and the ponds: in
			-- patches (SAFE_GRASS / SAFE_GRASS_ASSET)
			local safeGrassFolder = folder("SafeGrass", map)
			local patches, patchTries = {}, 0
			reseed(606)
			local sg = foliageGrass and SAFE_GRASS_ASSET or SAFE_GRASS
			local function grassOk(p)
				return not inPlot(p, 6) and not onPath(p, 4) and not onRoad(p, 4) and farFrom(ponds, p, 18)
					and farFrom(decor, p, PROP_CLEAR)
			end
			while #patches < sg.Patches and patchTries < 60000 do
				patchTries += 1
				local r = math.sqrt((ROAD_R + ROAD_W / 2 + 6) ^ 2 + rand() * ((MAP_R - 6) ^ 2 - (ROAD_R + ROAD_W / 2 + 6) ^ 2))
				local center = dir(rand() * 360) * r
				if grassOk(center) and farFrom(patches, center, sg.PatchGap) then
					table.insert(patches, center)
					local tufts = {}
					local want = sg.Size[1] + math.floor(rand() * (sg.Size[2] - sg.Size[1] + 1))
					for _ = 1, want * 4 do
						if #tufts >= want then
							break
						end
						local a, d = rand() * 360, math.sqrt(rand()) * sg.Radius
						local p = center + dir(a) * d
						if grassOk(p) and farFrom(tufts, p, sg.TuftGap) then
							table.insert(tufts, p)
							local at = Vector3.new(p.X, groundY(p.X, p.Z), p.Z)
							if foliageGrass then
								local scale = GRASS_ASSET_SCALE[1] + rand() * (GRASS_ASSET_SCALE[2] - GRASS_ASSET_SCALE[1])
								flowers(foliage(FOLIAGE_GRASS[math.floor(rand() * #FOLIAGE_GRASS) + 1], at, scale, rand() * 360,
									safeGrassFolder), at, scale)
							else
								local s = 0.8 + rand() * 0.6
								flowers(grass(safeGrassFolder, at, s, rand() * 360), at, s)
							end
						end
					end
				end
			end
		end
		section()
	end

	local boundary = folder("Boundary", map)
	local wallCount = 64
	for k = 0, wallCount - 1 do -- invisible wall just outside MAP_R
		local a = (k + 0.5) * 360 / wallCount
		local p = dir(a) * (MAP_R + 1) + Vector3.new(0, 50, 0)
		local length = 2 * (MAP_R + 2) * math.tan(math.pi / wallCount) + 1
		hidden(newPart({ Name = "InvisibleWall", Size = Vector3.new(length, 120, 2), CFrame = CFrame.lookAt(p, Vector3.new(0, 50, 0)),
			Parent = boundary }), false, false).CanCollide = true
	end

	local borderTrees, borderTries = {}, 0
	reseed(404)
	while #borderTrees < BORDER_TREES and borderTries < 10000 do -- trees on the hills
		borderTries += 1
		local r = MAP_R + 10 + rand() * 150
		local p = dir(rand() * 360) * r
		if farFrom(borderTrees, p, BORDER_GAP) then
			table.insert(borderTrees, p)
			local s, yaw = (1.3 + rand() * 0.8) * DECOR_SCALE, rand() * 360
			local y = groundY(p.X, p.Z) -- (the lowest ground under the clump: no trunk left hanging over the slope)
			for k = 0, 3 do
				local q = p + dir(k * 90) * 6 * s
				y = math.min(y, groundY(q.X, q.Z))
			end
			treeClump(boundary, Vector3.new(p.X, y - s, p.Z), s, yaw) -- sunk into the slope
		end
	end

	-- the giant waterfall in the background (beyond the hills; nobody can get there), facing the map, in its forest
	do -- (a function of its own: the Command Bar gives each function only 200 locals)
		local function section()
			local w = WATERFALL
			local k = w.Scale
			local at = dir(w.Angle) * (w.Front + (w.Middle - w.FrontEdge) * k)
			local base = Vector3.new(at.X, groundY(at.X, at.Z) - w.Sink, at.Z)
			local face = Vector3.new(-at.X, 0, -at.Z).Unit -- toward the map: the horseshoe's open side
			local side = face:Cross(Vector3.yAxis)
			-- a point in the model's own layout (x across, y from the open side to the back, as in make_waterfall.py)
			local function spot(x, y, up)
				return base + (side * x - face * (y - w.Middle) + Vector3.new(0, up or 0, 0)) * k
			end
			local fall = placeAsset("Prop_Waterfall", CFrame.lookAt(base, base + face), boundary)
			if fall then
				fall:ScaleTo(k) -- (round its bottom middle: it stays where it stands)
				warnTooBig(fall)
				fall.ModelStreamingMode = Enum.ModelStreamingMode.Persistent -- (far past the streaming radius: always sent)
				local lo, hi = worldBounds(fall)
				if math.max(hi[1] - lo[1], hi[3] - lo[3]) < (w.HalfWidth + w.Wing.Start) * 2 * k then
					warn("[MapBuilder] Prop_Waterfall이 예전 모델입니다(양옆 계단 없음). ServerStorage.Assets의 것을 지우고 "
						.. "exports/new/2026-10-03_status_waterfall/Prop_Waterfall.fbx 를 넣은 뒤 MapBuilder를 다시 실행하세요.")
				end
				for _, d in ipairs(fall:GetDescendants()) do
					if d:IsA("BasePart") then -- (queries stay on until the trees are planted: they look for its surface)
						d.CanCollide, d.CanTouch, d.CastShadow = false, false, false
					end
				end
				-- (2026-10-03, "배경에 나무가 공중에 떠있잖아") a tree never stands higher than the model's own surface
				-- under it (or the ground, off the model): an older or differently shaped model leaves none in the air
				local surface = RaycastParams.new()
				surface.FilterType = Enum.RaycastFilterType.Include
				surface.FilterDescendantsInstances = { fall }
				local function standOn(p)
					local hit = Workspace:Raycast(p + Vector3.new(0, 2000, 0), Vector3.new(0, -4000, 0), surface)
					local y = hit and math.min(p.Y, hit.Position.Y) or math.min(p.Y, groundY(p.X, p.Z))
					return Vector3.new(p.X, y, p.Z)
				end
				local woods = Instance.new("Model") -- (a model, so it can be always sent too)
				woods.Name = "WaterfallForest"
				woods.ModelStreamingMode = Enum.ModelStreamingMode.Persistent
				woods.Parent = boundary
				local planted = {}
				local function plant(x, y, up)
					local p = standOn(spot(x, y, up))
					if not farFrom(planted, p, w.TreeGap * k) then
						return
					end
					table.insert(planted, p)
					local s = (w.TreeSize[1] + rand() * (w.TreeSize[2] - w.TreeSize[1])) * k
					treeClump(woods, p - Vector3.new(0, s, 0), s, rand() * 360, rand() >= 0.6)
				end
				reseed(505)
				local crestEnd = w.CrestR * math.sin(math.rad(w.Arc))
				local crestY = w.CrestR * math.cos(math.rad(w.Arc))
				for _, sign in ipairs({ -1, 1 }) do
					for _ = 1, w.BankTrees * 3 do -- on the banks' tops, thick by the falls
						if #planted >= w.BankTrees * (sign == -1 and 1 or 2) then
							break
						end
						plant(sign * (crestEnd + 18 + rand() * (w.HalfWidth - crestEnd - 26)), crestY + 12 + rand() * (w.Back - crestY - 22),
							w.Height)
					end
				end
				local onBanks = #planted
				for _, sign in ipairs({ -1, 1 }) do
					for _ = 1, w.SideTrees * 3 do -- on the ground beside the gorge, in front of the cliffs
						if #planted >= onBanks + w.SideTrees * (sign == -1 and 1 or 2) then
							break
						end
						local x = w.HalfWidth * 0.8 + rand() * w.HalfWidth * 0.57
						local y = w.FrontEdge + rand() * (crestY - 25 - w.FrontEdge)
						plant(sign * x, y, 0)
					end
				end
				for _, sign in ipairs({ -1, 1 }) do -- on the steps down at the sides (the falls fade into the woods)
					for step, share in ipairs(w.Wing.Steps) do
						for _ = 1, w.Wing.WingTrees do
							local x = w.HalfWidth + w.Wing.Start + (step - 1) * w.Wing.Step + (rand() - 0.5) * 50
							plant(sign * x, crestY + 20 + rand() * (w.Back - crestY - 60), w.Height * share - 6)
						end
					end
				end
				for _, d in ipairs(fall:GetDescendants()) do -- (planted: nothing more to look for)
					if d:IsA("BasePart") then
						d.CanQuery = false
					end
				end
				-- (2026-10-03, "폭포는 굳이 모션 안 넣어도 돼": no mist particles; the foam in the model is enough)
			end
		end
		section()
	end

	-- more far scenery (BACKDROP): static, nothing to bump into, no shadows
	do -- (a function of its own: the Command Bar gives each function only 200 locals)
		local function section()
			local scenery = Instance.new("Model") -- (far past the streaming radius: always sent, so it shows)
			scenery.Name = "Backdrop"
			scenery.ModelStreamingMode = Enum.ModelStreamingMode.Persistent
			scenery.Parent = boundary
			reseed(606)
			for _, item in ipairs(BACKDROP) do
				local out = dir(item.Angle)
				local face = -out -- toward the map
				local at = out * item.Front
				local base = Vector3.new(at.X, groundY(at.X, at.Z) - (item.Sink or 0), at.Z)
				local target = CFrame.lookAt(base, base + face) * CFrame.Angles(0, math.rad(item.Turn or 0), 0)
				local model = placeAsset(item.Asset, target, scenery)
				if model then
					-- made big round its pivot (its bottom middle), then moved out until its nearest edge is Front away.
					-- (2026-10-03, "화산이나 설산도 더 가까이") nearest: the closer of two guesses that both fall short (the
					-- world box's nearest point, and its own turned box's face toward the middle); the world box alone
					-- left the pieces at a slant (the volcano, the mountains) some 300 studs farther than Front
					local lo, hi = worldBounds(model)
					model:ScaleTo(item.Height and item.Height / math.max(hi[2] - lo[2], 0.1) or item.Scale or 1)
					warnTooBig(model)
					for _ = 1, 3 do
						lo, hi = worldBounds(model)
						local nx = math.clamp(0, lo[1], hi[1])
						local nz = math.clamp(0, lo[3], hi[3])
						local box, size = model:GetBoundingBox()
						local face = box.Position:Dot(out) - (math.abs(box.RightVector:Dot(out)) * size.X
							+ math.abs(box.UpVector:Dot(out)) * size.Y + math.abs(box.LookVector:Dot(out)) * size.Z) / 2
						local nearest = math.max(math.sqrt(nx * nx + nz * nz), face)
						model:PivotTo(model:GetPivot() + out * (item.Front - nearest))
					end
					-- (2026-10-03, "하늘에 올라왔을때 배경 화석이 떠있는거 처럼 보임") set down on the lowest ground under it,
					-- not the ground at its middle (a hill there left the rest of a long piece standing on air)
					lo, hi = worldBounds(model)
					local low = math.huge
					for _, x in ipairs({ lo[1], (lo[1] + hi[1]) / 2, hi[1] }) do
						for _, z in ipairs({ lo[3], (lo[3] + hi[3]) / 2, hi[3] }) do
							low = math.min(low, groundY(x, z))
						end
					end
					model:PivotTo(model:GetPivot() + Vector3.new(0, low - (item.Sink or 0) - lo[2], 0))
					base = model:GetPivot().Position
					-- something standing in it (the arch's opening): a giant dino facing the map, trees at its feet
					local inside = item.Inside
					local guest = inside and placeAsset(inside.Asset,
						CFrame.lookAt(base, base + face) * CFrame.Angles(0, math.rad(inside.Turn or 0), 0), scenery)
					if guest then
						local glo, ghi = worldBounds(guest)
						guest:ScaleTo(inside.Height / math.max(ghi[2] - glo[2], 0.1))
						guest.Name = "Backdrop_" .. inside.Asset
						local across = face:Cross(Vector3.yAxis)
						glo, ghi = worldBounds(guest)
						local reach = math.max(ghi[1] - glo[1], ghi[3] - glo[3]) / 2
						for k = 1, inside.Trees or 0 do
							local side = k % 2 == 0 and 1 or -1
							local p = base + across * side * (reach * (0.6 + rand() * 0.4)) + face * ((rand() - 0.5) * reach)
							local s = (BACKDROP_TREE_SIZE[1] + rand() * (BACKDROP_TREE_SIZE[2] - BACKDROP_TREE_SIZE[1])) * BACKDROP_TREE_SCALE
							treeClump(scenery, Vector3.new(p.X, groundY(p.X, p.Z) - s, p.Z), s, rand() * 360, rand() >= 0.6)
						end
					end
					for _, d in ipairs(model:GetDescendants()) do
						if d:IsA("BasePart") then
							d.CanCollide, d.CanTouch, d.CanQuery, d.CastShadow = false, false, false, false
						end
					end
					model.Name = "Backdrop_" .. item.Asset
					lo, hi = worldBounds(model)
					local half = math.max(hi[1] - lo[1], hi[3] - lo[3]) / 2
					local planted = 0
					for _ = 1, (item.Trees or 0) * 6 do
						if planted >= (item.Trees or 0) then
							break
						end
						local a = rand() * 2 * math.pi
						local r = half * (BACKDROP_TREE_RING[1] + rand() * (BACKDROP_TREE_RING[2] - BACKDROP_TREE_RING[1]))
						local p = base + Vector3.new(math.cos(a) * r, 0, math.sin(a) * r)
						if Vector3.new(p.X, 0, p.Z).Magnitude < item.Front + 20 then
							continue -- (never in front of it, toward the wall: a wide piece's ring reaches round to the map)
						end
						planted += 1
						local s = (BACKDROP_TREE_SIZE[1] + rand() * (BACKDROP_TREE_SIZE[2] - BACKDROP_TREE_SIZE[1])) * BACKDROP_TREE_SCALE
						treeClump(scenery, Vector3.new(p.X, groundY(p.X, p.Z) - s, p.Z), s, rand() * 360, rand() >= 0.6)
					end
				end
			end
			-- the ground under it all past the baseplate (else the far pieces stand over nothing)
			local far = FAR_GROUND
			local span = far.Tiles * far.TileSize
			for ix = 0, far.Tiles - 1 do
				for iz = 0, far.Tiles - 1 do
					local cx = -span / 2 + (ix + 0.5) * far.TileSize
					local cz = -span / 2 + (iz + 0.5) * far.TileSize
					newPart({ Name = "FarGround", Size = Vector3.new(far.TileSize, 1, far.TileSize),
						CFrame = CFrame.new(cx, BASEPLATE_TOP - far.Below - 0.5, cz), Color = COLOR.grass or COLOR.leaf,
						Material = Enum.Material.SmoothPlastic, CanCollide = false, CanTouch = false, CanQuery = false,
						CastShadow = false, Parent = scenery })
				end
			end
			for _, d in ipairs(scenery:GetDescendants()) do -- (the trees too: far scenery, not fruit trees)
				if d:IsA("BasePart") then
					d.CanCollide, d.CanTouch, d.CanQuery = false, false, false
				elseif d:IsA("Model") and d.Name == "Tree" then
					d.Name = "BackdropTree"
				end
			end
		end
		section()
	end

	-- ---------------------------------------------------------------------------
	-- Report
	-- ---------------------------------------------------------------------------

	local partCount = 0
	for _, d in ipairs(map:GetDescendants()) do
		if d:IsA("BasePart") then
			partCount += 1
		end
	end
	print(string.format("[MapBuilder] 완료: 파트 %d개, 광물 지점 %d개, 깃발 %d개, 장식 %d개(연못 %d), 배틀필드 장식 %d개(화석 %d), 풀 %d포기, 언덕 %d개, 경계 나무 %d그루",
		partCount, #ores, #flagFolder:GetChildren(), #decor, #ponds, #field, #fossils, #tufts, #hills, #borderTrees))
	if #ores < ORE_COUNT then
		warn(string.format("[MapBuilder] 광물 지점을 %d개밖에 못 놓았습니다 (목표 %d)", #ores, ORE_COUNT))
	end
	if not assets then
		warn("[MapBuilder] ServerStorage에 Assets 폴더가 없어 블렌더 모델을 모두 건너뛰었습니다")
	end
	if #missing > 0 then
		warn(string.format("[MapBuilder] 없는 모델 %d개 (건너뜀): %s", #missing, table.concat(missing, ", ")))
		if assets then -- show what is there, e.g. a set imported as one merged mesh
			local inside = {}
			for _, c in ipairs(assets:GetChildren()) do
				local names = {}
				for _, d in ipairs(c:GetDescendants()) do
					if d:IsA("BasePart") then
						table.insert(names, d.Name)
					end
				end
				table.insert(inside, string.format("'%s'(%s: %s)", c.Name, c.ClassName, table.concat(names, " ")))
			end
			warn("[MapBuilder] 지금 Assets 안: " .. (#inside > 0 and table.concat(inside, ", ") or "비어 있음"))
		end
	else
		print("[MapBuilder] 블렌더 모델을 모두 배치했습니다")
	end
end
