--[[
LegoFloor.lua - checks and fixes the LEGO floor in Roblox Studio, without rebuilding the map.

How to use: in edit mode (not while playing), clear the Command Bar, paste this whole file and press
Enter. The Output window says what it found and what it did:

- removes the place template's grey Workspace.Baseplate (it covers the floor at the same height);
- makes sure the green stud baseplate (Map.Ground.Baseplate, 4 bricks) is there, top at 0.2 over
  the terrain grass, and puts it there if an older MapBuilder made the map;
- turns every floor part in Map.Ground into shiny plastic with studs on top.

The round floors made by an older MapBuilder are round cylinders, which cannot show studs: run the
latest roblox/MapBuilder.lua once to get them as LEGO brick rows too.
]]

do
	local Workspace = game:GetService("Workspace")
	local RunService = game:GetService("RunService")
	local BASEPLATE_R, BASEPLATE_TOP = 1500, 0.2
	local GREEN = Color3.fromRGB(88, 171, 65)
	local report = {}
	local function note(text)
		table.insert(report, text)
	end

	if RunService:IsRunning() then
		warn("[LegoFloor] 플레이 중에는 안 돼요. 플레이를 멈추고 편집 모드에서 다시 실행하세요.")
		return
	end
	for _, child in ipairs(Workspace:GetChildren()) do
		if child:IsA("BasePart") and child.Name == "Baseplate" then
			child:Destroy()
			note("템플릿 회색 바닥(Workspace.Baseplate)을 지웠어요")
		end
	end
	local map = Workspace:FindFirstChild("Map")
	if not map then
		warn("[LegoFloor] Workspace.Map이 없어요. roblox/MapBuilder.lua를 먼저 실행하세요.")
		return
	end
	local ground = map:FindFirstChild("Ground")
	if not ground then
		ground = Instance.new("Folder")
		ground.Name = "Ground"
		ground.Parent = map
	end

	local plates = {}
	for _, child in ipairs(ground:GetChildren()) do
		if child:IsA("BasePart") and child.Name == "Baseplate" then
			table.insert(plates, child)
		end
	end
	if #plates == 0 then
		note("레고 판이 없었어요 (예전 MapBuilder로 만든 맵): 4장을 새로 깔았어요")
		for _, sx in ipairs({ -1, 1 }) do
			for _, sz in ipairs({ -1, 1 }) do
				local p = Instance.new("Part")
				p.Name = "Baseplate"
				p.Anchored = true
				p.Size = Vector3.new(BASEPLATE_R, 2, BASEPLATE_R)
				p.CFrame = CFrame.new(sx * BASEPLATE_R / 2, BASEPLATE_TOP - 1, sz * BASEPLATE_R / 2)
				p.Color = GREEN
				p.Parent = ground
				table.insert(plates, p)
			end
		end
	else
		note(string.format("레고 판 %d장이 있어요: 높이를 풀밭 위(%.1f)로 맞췄어요", #plates, BASEPLATE_TOP))
		for _, p in ipairs(plates) do
			p.CFrame = CFrame.new(p.Position.X, BASEPLATE_TOP - p.Size.Y / 2, p.Position.Z)
			p.Color = GREEN
		end
	end

	local bricks, round = 0, 0
	for _, d in ipairs(ground:GetDescendants()) do
		if d:IsA("Part") then
			d.Material = Enum.Material.Plastic
			d.TopSurface = Enum.SurfaceType.Studs
			d.BottomSurface = Enum.SurfaceType.Smooth
			if d.Shape == Enum.PartType.Cylinder then
				round += 1
			else
				bricks += 1
			end
		end
	end
	note(string.format("바닥 파트 %d개를 레고 돌기 플라스틱으로 바꿨어요", bricks))
	if round > 0 then
		note(string.format("둥근 바닥 %d개는 원통이라 돌기가 안 보여요: 최신 MapBuilder.lua를 한 번 실행하면 레고 줄 블록으로 바뀌어요", round))
	end
	for _, line in ipairs(report) do
		print("[LegoFloor] " .. line)
	end
	print("[LegoFloor] 끝. 바닥이 반짝이는 초록 플라스틱이고 위에 동그란 돌기가 보이면 성공이에요.")
end
