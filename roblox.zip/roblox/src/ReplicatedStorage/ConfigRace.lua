--[[
ConfigRace: Config.Race, the dino races (2026-10-04: moved out, Config.lua must stay under Roblox's 200,000
characters a script). Config.lua puts it at Config.Race and freezes it with the rest. Read it as Config.Race, never
this module directly.
]]
return {
	-- the track: a ring around the map center, raced the way the compass angle goes up (clockwise
	-- seen from above), the finish line at FinishAngle (0 = north)
	Radius = 375,
	Width = 20,
	FinishAngle = 0,
	StartBack = 2.5, -- degrees behind the finish line: the two start boxes
	-- (2026-10-02, "결승선 통과했는데 바로 안 끝나는 문제") crossing the finish line ends the race once the lap
	-- counted is at most this many degrees short (bits ridden off the road or off the dino aren't counted). 임시값
	FinishSlack = 40,
	StartSide = 5, -- studs either side of the road's middle line for the two start boxes
	-- (2026-10-02, races at the same time: "충돌 있을 거 같은데") StartSlots rows of start boxes, each StartSlotGap
	-- degrees (13 studs) further back: a race starting while another one waits at the start takes the next row
	-- (a practice one box). All within ObstacleKeepOff of the line, and no pads there. 임시값
	StartSlots = 4,
	StartSlotGap = 2,
	-- (2026-10-02, "고의로 레이스 안 끝내는 사람 있으면 안 되잖아") a racer not getting any further for StallSeconds
	-- (road: no new ground on the lap; sky: no ring passed and not nearer the next one) loses (a practice ends);
	-- a warning after StallWarnSeconds. 임시값
	StallSeconds = 30,
	StallWarnSeconds = 20,
	OffTrack = 25, -- studs past the road's edges that still count as on the track (cutting across gains nothing)
	-- from the countdown on, a see-through barrier along both road edges keeps the two racers on the road
	-- (only they see and bump into it); a racer still found this far past an edge is put back on the road
	BarrierSlack = 3,
	ChallengeRange = 14, -- 임시값: studs to another player for the "레이스 신청" prompt
	ChallengeCooldown = 10, -- 임시값: seconds between one player's challenges
	InviteSeconds = 15, -- 임시값: time to answer a challenge
	-- (2026-10-04, "레이스도 방 열수 있게 하자 술래잡기처럼") race rooms in the 🎮 놀이방 window (Race service): a room is a
	-- 🏁 road race (walking dinos) or a 🦅 sky race (flying ones), 🏆 랭킹전 or 🎈 일반전; MinPlayers or more, all ready:
	-- StartSeconds later everyone is put on their own mount at the start. MaxPlayers fit the start boxes (StartSlots
	-- rows of two). A new room is told to the others at most once every RoomNoticeGap seconds a player. 임시값
	Rooms = { MinPlayers = 2, MaxPlayers = 6, MaxRooms = 4, StartSeconds = 3, RoomNoticeGap = 180, MountPickSeconds = 120 }, -- 임시값
	GatherSeconds = 60, -- 임시값: time for both to get on a (walking) dino at the start
	CountdownSeconds = 3,
	TimeLimit = 300, -- 임시값: seconds; then whoever is ahead wins
	TutorialDegrees = 90, -- 임시값
	TutorialSky = { Rings = 4, Radius = 26, High = 34, Low = 20 }, -- 임시값
	Speed = 48, -- 임시값: everyone rides at this speed in a race (16 × Ride.SpeedMultiplier), whatever their upgrades
	-- (× the weather's MoveSpeedMultiplier, the same for both, and a race pad's boost; 2026-10-01)
	-- (2026-10-01, "a race on flying dinos too") the sky race: challenged while riding a flying dino, both on
	-- flying dinos; the two start side by side in the air over the land outside the base fences, and fly
	-- through Rings yellow rings round the map (each racer sees only their own next one), then the red one
	-- where they started. Same course for both, new every race (Formulas.skyCourse). 임시값
	Sky = {
		Rings = 16, -- yellow ones; then the red one at the start (2026-10-01: was 9, "링도 늘려주고")
		-- (2026-10-01, "반경 더 크게 더 랜덤하게") over the bases too: from past the road race's track (375) ...
		InnerRadius = 460, -- 임시값 (was 575: only past the base fences' backs, 552)
		OuterRadius = 745, -- ... to inside the wall (760)
		MinHeight = 22, -- studs over what is below (the trees, a roof) ...
		MaxHeight = 140, -- ... at most; and never higher than Ride.FlyMaxHeight − SkyCeilingMargin in the world
		BaseClearRadius = 560, -- 임시값: a ring nearer the center than this (over the bases) ...
		BaseClearHeight = 60, -- ... is at least this high
		CeilingMargin = 15, -- studs under Ride.FlyMaxHeight the highest ring stays (its hole reachable)
		-- (2026-10-01, "훨씬 더 랜덤적인 좌우 상하 반경에", then "더 크게 더 랜덤하게") each ring at least this
		-- far from the one before, in or out (studs from the center) and up or down, by a random amount on
		-- top: a zigzag, not a smooth circle. 임시값
		MinRadiusStep = 70, -- (was 45)
		MinHeightStep = 40, -- (was 30)
		StartHeight = 40,
		StartSide = 8, -- studs either side of the start point for the two racers
		AngleJitter = 8, -- degrees a ring may stray from even spacing round the map (16 rings: 21° apart; was 7)
		RingRadius = 12, -- the ring's hole
		PassSlack = 4, -- studs past the hole that still count as through it (lag; the rider sits over the mount)
		TimeLimit = 240, -- then whoever passed more rings (then is nearer the next one) wins
		-- (2026-10-01) boost pads standing up on the way between the rings (Formulas.skyPads): flying
		-- through one boosts like a road pad (PadMultiplier / YellowMultiplier), once per pad and racer
		PadsPerLeg = { 1, 2 }, -- 임시값: pads between two rings (least, most)
		PadAlong = { 0.25, 0.8 }, -- 임시값: where along the way between them (0 = the ring before, 1 = the next)
		PadOffset = 9, -- 임시값: studs off the straight line at most, sideways and up or down (go a little out of the way)
		PadRadius = 6, -- 임시값: the pad's size; through within this counts
		PadSlack = 2, -- 임시값: studs past its edge that still count (lag)
		PadMinHeight = 15, -- 임시값: studs over the ground at least
		YellowChance = 0.2, -- 임시값: share of yellow (strong) pads
	},
	-- race pads (Formulas.raceLayout, new every race): only the two racers see and use them (each pad
	-- once per racer). Purple ones come in little runs here and there (was 72 spread evenly: too even and
	-- too many); a few strong yellow ones are the comeback chance.
	PadRadius = 3, -- studs, size and how close counts as stepping on it
	PurpleRuns = 8, -- 임시값: runs of purple pads at random places round the track ...
	PurplePerRun = { 2, 4 }, -- 임시값: ... each this many pads ...
	PurpleRunDegrees = 7, -- 임시값: ... within this many degrees
	PadMultiplier = 1.6, -- 임시값: purple: × the race speed ...
	PadBoostSeconds = 2.5, -- 임시값: ... for this long (MoveGuard.boost: a new pad starts the time over)
	YellowCount = 5, -- 임시값: single yellow pads at random places
	YellowMultiplier = 2.2, -- 임시값: yellow: × the race speed ...
	YellowBoostSeconds = 3.5, -- 임시값: ... for this long
	PadKeepOff = 5, -- degrees around the finish line without pads
	-- obstacles (only the two racers see and bump into them; gone when the race ends): crates, pillars and
	-- walls from one edge, at random places. Each leaves at least MinGap studs of road free across.
	ObstacleCount = 85, -- 임시값 (was 36, 40, 34, 60; 2026-10-01 "너무 순탄하다", "더 추가": 85 with the hurdles, about every 20 studs)
	-- 임시값 (2026-10-01, "riding you just walk over the obstacles"): standing within this many studs over an
	-- obstacle's top (not jumping) counts as hitting it (Formulas.raceObstacleHit)
	ObstacleStandSlack = 2.5,
	ObstacleGapDegrees = 2, -- 임시값: at least this far apart along the track (13 studs; was 2.5)
	ObstacleKeepOff = 9, -- degrees after the start boxes and before the finish line kept clear
	MinGap = 8, -- studs of road always left free beside an obstacle
	-- 임시값 (2026-10-01, "more varied, more in the way, and jump sections"): besides crates, pillars,
	-- walls, cones and barrels, moving ones (a hammer swinging across the road, a low bar spinning on it:
	-- jump it or time it), and jump sections: JumpHurdles low bars right across the road,
	-- JumpSpacingDegrees apart, to be jumped (Formulas.raceLayout)
	-- (2026-10-01, "one jump clears the whole jump section"): the hurdles further apart than a jump carries
	-- at race speed (a jump is about 0.55 s in the air: 26 studs at 48), so each takes its own jump, and the
	-- section's road is mud from MudLeadDegrees before its first hurdle to as far past its last: a pad's
	-- boost ends there (a boosted jump would carry over two). 임시값
	JumpSections = 3, -- (was 4: the sections are longer now)
	JumpHurdles = 4,
	JumpSpacingDegrees = 5.5, -- 36 studs at Radius 375 (was 3: 20 studs, two or three in one jump)
	HurdleHeight = 3.2, -- (was 2.5)
	MudLeadDegrees = 3,
	PadObstacleGap = 5, -- studs between a pad's edge and an obstacle
	PadClearDegrees = 1.5, -- 임시값 (2026-10-01): obstacles keep this far along the track from a pad's place
	-- the moving ones hit for real (2026-10-01, "the spinning bar and the hammer don't get in the way"): the
	-- server works out where they are (server time, Formulas.raceMoverAt) and a racer they touch bounces
	-- off: put back HitPushBack studs along the road and tossed up HitBounceUp studs a second, still on the
	-- dino (2026-10-01, "just bounce off, riding; obstacles never take you off the dino": no stun, as a stun
	-- dismounts); one mover hits a racer at most every HitCooldown seconds. 임시값
	-- (2026-10-01, "hit by it you should fly back") further and higher: HitPushBack 10 → 16, HitBounceUp 30 → 45
	HitPushBack = 16, -- (was 8 with a 1.3 s stop)
	-- (2026-10-04, "레이스 경우에 자꾸 장애물에 밀려나는게 조금 부자연 스럽고": was put back HitPushBack studs at once and
	-- tossed up 45 studs a second) flown back HitPushBack studs in an arc over HitBounceSeconds (the racer's own screen
	-- flies it, still riding; the server lets the move through)
	HitBounceSeconds = 0.6,
	-- (the same) the server puts a racer it sees in an obstacle out at its face only after this long in it (lag: the
	-- racer's screen, where the obstacles are solid, has already stopped them; it put them back at once, often wrongly)
	ObstacleGraceSeconds = 0.3,
	-- every race has at least this many of the moving ones (Formulas.raceLayout; the rest at random). 임시값
	MinMovers = { Spinner = 7, Swing = 6 }, -- (was 3 and 2, then 5 and 4)
	HitCooldown = 2,
	RacerRadius = 2, -- studs: how wide a racer on its dino counts, for the moving ones
	RacerHeight = 6, -- studs from the dino's feet up that a racer takes, for the moving ones
	-- seconds there and back, degrees either way, head size (across, up, along the road). (2026-10-01, "the
	-- pendulum harder to dodge": Period 2.6 → 1.8, Angle 68 → 78, Head 4.5×4.5×3 → 6.5×5×4.5) 임시값
	Swing = { Period = 1.8, Angle = 78, Head = { 6.5, 5, 4.5 } },
	Medals = { -- 임시값
		Road = {
			{ Id = "Bronze", Icon = "🥉", Seconds = 50, Reward = { Keys = 5 } },
			{ Id = "Silver", Icon = "🥈", Seconds = 44, Reward = { SpecialKeys = { Silver = 1 } } },
			{ Id = "Gold", Icon = "🥇", Seconds = 41, Reward = { SpecialKeys = { Gold = 1 } } },
			{ Id = "Diamond", Icon = "💎", Seconds = 38.5, Reward = { SpecialKeys = { Gold = 2 } } },
		},
		Sky = {
			{ Id = "Bronze", Icon = "🥉", Factor = 1, Reward = { Keys = 5 } },
			{ Id = "Silver", Icon = "🥈", Factor = 0.88, Reward = { SpecialKeys = { Silver = 1 } } },
			{ Id = "Gold", Icon = "🥇", Factor = 0.78, Reward = { SpecialKeys = { Gold = 1 } } },
			{ Id = "Diamond", Icon = "💎", Factor = 0.72, Reward = { SpecialKeys = { Gold = 2 } } },
		},
	},
	Spinner = { Speed = 110, Bar = 1.8, HitRadius = 0.5 }, -- degrees a second, the bar's thickness (2026-10-01: was 1.2, easy to miss) -- 임시값
}
