--[[
ConfigHideSeek: Config.HideSeek, 🙈 hide-and-seek (2026-10-04: moved out, Config.lua must stay under Roblox's 200,000
characters a script). Config.lua puts it at Config.HideSeek and freezes it with the rest. Read it as Config.HideSeek,
never this module directly. (The notes on it are over Config.HideSeek in Config.lua.)
]]
return {
	MinPlayers = 2,
	MaxPlayers = 8,
	MaxRooms = 4,
	-- (2026-10-04, "술래잡기 방 만들면 알림 가도 되게") a new room is told to the others at most once this many seconds a
	-- player (HideSeek). 임시값
	RoomNoticeGap = 180,
	-- (2026-10-04, "놀이방에서 내가 기다리고 있다는 것 같은 모집을 위한 알림을 날릴 수 있게 해줘 서버 안 사람들에게. 10초에
	-- 한 번씩", "방 만든 이후에 가능하게", "방장만 하는게 낫지") 📣 모집: the host of a waiting room tells everyone else in the server, at most
	-- once this many seconds a player (the race rooms too). 임시값
	RecruitGap = 10,
	-- (2026-10-04, "숨바꼭질 끝나고 원래 본인이 타고 있던 공룡을 되돌려주기도 하고") who rode their own dino when the game took
	-- them is put back on it after; on the battlefield (no riding there) as soon as they step out, for this long. 임시값
	MountBackSeconds = 120,
	-- (2026-10-04, "술래잡기 대기시간 좀 줄여": the seeker stood still 30 seconds) 임시값
	HideSeconds = 20,
	SeekSeconds = 300, -- 임시값
	-- (2026-10-04, "술래 이속을 기본으로, 튀는 사람을 술래 기본속도보다 빠르게.. 패드를 못쓰니까": was the seeker × 1.3) the
	-- seeker walks WalkSpeed, the hiders HiderSpeed times as fast all game (they can't use the pads while seeking; the
	-- seeker can, for short bursts) 임시값
	-- (2026-10-04, "그리고 숨는 사람도 스피드패드 쓸 수 있게. 하지만 술래가 기본 이속이 더 빨라서 숨는사람이 조금 불리하지":
	-- were 1 and 1.15, the hiders kept off the pads while seeking) everyone uses the pads, the seeker a little faster 임시값
	SeekerSpeed = 1.1, -- 임시값
	HiderSpeed = 1,
	SeekerReach = 1.3, -- (2026-10-04, "지금 술래에게 너무 유리해": was 1.5) 임시값
	-- (2026-10-03, "숨는 사람들이 종을 수없이 빈도높게 울리게 해줘. 이거 맵이 너무 넓어서..": was 20, 30, 15)
	-- (2026-10-04, "발판을 못쓰게 됐으니 튀어야하는 사람의 알림 빈도수를 줄여줘 밸런스 맞춰서" → "좀 더 밸런스 조절해봐": hiders
	-- can't use the speed pads while seeking (the seeker can), so a ring gives them away for longer) the gap follows
	-- the game (Formulas.hideSeekBellGap): BellEveryEarly in the first EarlySeconds of seeking (hiding pays off),
	-- BellEvery after, BellEveryLate in the last LateSeconds, BellEveryFinal in the last FinalSeconds; and with more
	-- hiders still in, longer (each ring shows them all): × (1 + BellPerHider × (hiders left − 1)), at most
	-- BellMaxFactor. (2026-10-04, "알림 간격 더 늘려 개빡세": was 15 / 15 for 60 s / 12 / 8 / 5, about 28 rings a game)
	BellFirst = 20, -- 임시값
	BellJitter = 0.2, -- 임시값
	BellBlurStill = 24, -- 임시값
	BellBlurMoving = 10, -- 임시값
	BellStillStuds = 8, -- 임시값
	BellFinalBlur = 0.5, -- 임시값
	-- (2026-10-04, the bigger map) a hider off the battlefield (the bases, the woods) rings this times as far apart as the
	-- game's gap: running far costs more than hiding on the battlefield (2026-10-04, "들판 밖에서 1.5배가 아니라 2배로해": was
	-- 0.67, about 1.5 times as often; now twice) 임시값
	OutsideBellFactor = 0.5,
	-- (2026-10-04) 📡 the seeker's radar: RadarFirst seconds into seeking, then every RadarEvery, the seeker's screen
	-- shows for RadarSeconds an arrow toward the nearest hider and how far (within RadarNear: 가까워요, RadarMid: 조금
	-- 멀어요, else 멀어요), never where exactly; that hider is told it caught them, the others that it went 임시값
	RadarFirst = 45, -- 임시값
	RadarEvery = 40, -- 임시값
	RadarSeconds = 3,
	RadarWarnSeconds = 3, -- 임시값
	RadarSampleSeconds = 1.5, -- 임시값
	RadarMoveStuds = 3, -- 임시값
	NearMissStuds = 14, -- 임시값
	NearMissClear = 30, -- 임시값
	RadarNear = 60,
	RadarMid = 150,
	BellEveryEarly = 16, -- 임시값
	EarlySeconds = 90,
	BellEvery = 14, -- 임시값
	BellEveryLate = 9, -- 임시값
	LateSeconds = 60,
	-- (2026-10-03, "마지막 30초는 더 많이 울리게") the last FinalSeconds: every BellEveryFinal seconds
	BellEveryFinal = 5, -- 임시값
	BellPerHider = 0,
	BellMaxFactor = 1.5,
	FinalSeconds = 30,
	StartSeconds = 3, -- the countdown once all are ready
	SeekerSpawnRadius = 16,
	SpawnRadius = { 90, 330 },
	SpawnGap = 40,
	EdgeMargin = 8,
	CheckEvery = 0.5,
	BoardAngle = 180,
	BoardOut = 40,
	BoardRange = 12, -- studs: how close the board's prompt works
	-- (2026-10-03, "지금 술래 스피드가 더 빠른거 맞지?") everyone in a game walks WalkSpeed, the seeker × SeekerSpeed
	-- while seeking: not their own upgrades or a speed potion (a hider with MoveSpeed bought up to 28 outran a new
	-- seeker's 16 × 1.3); the pads and the weather still count, for all alike. 임시값
	WalkSpeed = 20,
	-- (2026-10-03, "숨는 사람들이 조그만 함정 바닥에 설치해두고 그걸 술래가 밟으면 잠시 멈추게해줘. 함정은 총 3개 점프하면
	-- 피할 수 있을정도의 크기") 🕸️ traps: each hider puts down up to TrapCount a game at their feet (on the ground,
	-- TrapCooldown seconds apart, not within TrapSeekerGap studs of the seeker or TrapGap of another trap). The seeker
	-- stepping on one while seeking stops for TrapStunSeconds and then walks over traps for TrapImmuneSeconds (no
	-- chains of them). TrapSize: its width (Prop_HideTrap, tools/make_trap.py; half a stud high: a jump clears it);
	-- the hiders walk over them. Gone when the game ends. 임시값
	TrapCount = 3,
	TrapStunSeconds = 2.5,
	TrapImmuneSeconds = 4,
	TrapCooldown = 2,
	TrapGap = 6,
	TrapSeekerGap = 15,
	TrapSize = 3.4,
	-- (2026-10-07, "숨바꼭질에서 공룡으로 변신해서 그 사이에 숨을 수 있는 기능") 🦖 a hider turns into a wild-looking dino
	-- DisguiseCount times a game for DisguiseSeconds each, DisguiseCooldown apart; every screen draws one of
	-- DisguiseSpecies DisguiseHeight studs tall over them. 임시값
	DisguiseCount = 4, -- 임시값
	DisguiseSeconds = 40,
	DisguiseCooldown = 10,
	DisguiseHeight = 3.6,
	DisguiseSpecies = { "Parasaur", "Iguanodon", "Trike", "Stego", "Ankylo", "Pachy", "Edmonto", "Maia", "Raptor", "Dilopho" },
	DisguiseKinds = { -- 임시값
		{ Says = "🦖 공룡으로 변신!", Weight = 3 },
		{ Says = "⛰️ 바위로 변신!", Names = { "Rock" }, Weight = 3 },
		{ Says = "🌳 나무로 변신!", Names = { "Tree", "Prop_Tree_Pine", "Prop_Tree_Round", "Prop_Tree_Palm" }, Weight = 3 },
		{ Says = "🌿 덤불로 변신!", Names = { "Bush" }, Weight = 2 },
		{ Says = "🌲 통나무로 변신!", Names = { "Log" }, Weight = 1 },
		{ Says = "🍄 버섯으로 변신!", Names = { "Mushroom" }, Weight = 1 },
		{ Says = "🌱 풀숲으로 변신!", Names = { "Grass", "Prop_Grass_A", "Prop_Grass_B", "Prop_Grass_C" }, Weight = 1 },
		{ Says = "🐣 둥지로 변신!", Names = { "Prop_Nest" }, Weight = 1 },
		{ Says = "🕳️ 타르 웅덩이로 변신!", Names = { "Prop_TarPit" }, Weight = 1 },
		{ Says = "⛺ 발굴 캠프로 변신!", Names = { "Prop_DigCamp" }, Weight = 1 },
		{ Says = "🦴 거대 화석으로 변신!", Names = { "Fossil" }, Weight = 1 },
		{ Says = "🚩 깃발로 변신!", Names = { "Flag" }, Weight = 1 },
		{ Says = "💧 연못으로 변신!", Names = { "Pond" }, Weight = 1 },
		{ Says = "🚦 신호등으로 변신!", Names = { "Prop_TrafficLight" }, Weight = 1 },
	},
	-- (2026-10-04, "술래잡기가 다인이면 잡힌 사람은 관전자용 익룡 타고 배틀필드 공중에서 끝날때까지 구경하게") a hider caught
	-- while others still play rides this flying species (owned or not) over the battlefield, WatchHeight studs over the
	-- map's floor where caught, until the game ends; then home. 임시값
	WatchMount = "Pteranodon",
	WatchHeight = 45,
	WatchEdgeIn = 10, -- studs inside the battlefield flags a watcher is held (their screen) 임시값
}
