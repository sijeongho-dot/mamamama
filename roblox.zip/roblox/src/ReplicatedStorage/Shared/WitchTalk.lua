local ContentProvider = game:GetService("ContentProvider")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TextService = game:GetService("TextService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = script.Parent
local Lang = require(Shared:WaitForChild("Lang"))
local CocoVoice = require(Shared:WaitForChild("CocoVoice"))

local WitchTalk = {}

local DISPLAY_ORDER = 7
local FONT = Enum.Font.GothamBold
local WIDTH, MAX_WIDTH = 0.46, 520
local BOX_HEIGHT, MAX_BOX_HEIGHT = 0.27, 150
local BOX_BOTTOM = 0.035
local BOX_FILL = Color3.fromRGB(255, 251, 246)
local BOX_SEE = 0.08
local BOX_EDGE = Color3.fromRGB(236, 196, 186)
local BOX_CORNER = 12
local LINE_WIDTH = 2
local RULES = { 0.38, 0.59 }
local RULE_INSET = 0.02
local RULE_COLOR = Color3.fromRGB(236, 212, 206)
local RULE_SEE = 0.25
local MARGIN_AT = 0.075
local MARGIN_COLOR = Color3.fromRGB(238, 128, 116)
local MARGIN_SEE = 0.35
local RINGS = 3
local RING_HEIGHT = 0.08
local RING_SHAPE = 2.6
local RING_FILL = Color3.fromRGB(250, 248, 246)
local RING_EDGE = Color3.fromRGB(150, 140, 140)
local TAG_AT = 0.04
local TAG_HEIGHT, TAG_MAX_WIDTH = 0.22, 0.62
local TAG_PAD, TAG_SIDE = 0.14, 0.8
local TAG_FILL = Color3.fromRGB(240, 128, 112)
local TAG_TEXT = Color3.fromRGB(74, 36, 30)
local TAG_CORNER = 3
local TAG_MAX_TEXT = 18
local TEXT_LEFT, TEXT_RIGHT = 0.11, 0.05
local TEXT_TOP, TEXT_BOTTOM = 0.17, 0.1
local TEXT_SPLIT = 0.58
local TEXT_COLOR = Color3.fromRGB(62, 46, 46)
local TEXT_MAX, TEXT_MIN = 26, 10
local NOTE_TOP, NOTE_BOTTOM = 0.61, 0.06
local NOTE_FILL = Color3.fromRGB(255, 236, 196)
local NOTE_SEE = 0.05
local NOTE_TEXT = Color3.fromRGB(92, 60, 18)
local NOTE_PAD = 0.03
local NOTE_TEXT_SIZE = UDim2.fromScale(0.93, 0.86)
local NOTE_MAX, NOTE_MIN, NOTE_ONE_LINE = 18, 9, 11
local NOTE_SLACK = 4
local NOTE_STEP, NOTE_TRIES = 0.05, 10
local PICTURE_AT = 0.97
local PICTURE_HEIGHT = 0.52
local PICTURE_MAX = 290
local PICTURE_ABOVE = 0.6
local PICTURE_TOP = 0.2
local HUD_GUI = "BagBar"
local HUD_GAP = 6
local HUD_LOOK = 0.5
local STAND_IN = "🧙"
local STAND_IN_SIZE = 0.5
local STAND_IN_UP = 0.72
local REVEAL_RATE = 30
local HOLD_MIN, HOLD_PER_CHAR, HOLD_MAX = 3, 0.08, 10
local SLOT_HOLD = 2.5
local FADE_SECONDS = 0.25
local QUEUE_MAX = 3
local QUEUE_STALE = 20
local DEFAULT_FACE = "Smile"
local MOODS = { Angry = "Angry", Cry = "Sad", Giggle = "Happy", Laugh = "Happy", Peace = "Happy" }

local gui, root, box, words, nameTag, nameWords, note, noteWords, picture, standIn = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
local looks = {}
local talk = nil
local loop = nil
local preloaded = false
local waiting = {}
local nextWaiting = nil

local function look(object, property, base)
	table.insert(looks, { object, property, base })
end

local function paint(see)
	for _, l in ipairs(looks) do
		l[1][l[2]] = l[3] + (1 - l[3]) * see
	end
end

local function frame(parent, props)
	local f = Instance.new("Frame")
	f.BorderSizePixel = 0
	for k, v in pairs(props) do
		f[k] = v
	end
	f.Parent = parent
	return f
end

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = radius
	c.Parent = parent
end

local function edge(parent, color)
	local s = Instance.new("UIStroke")
	s.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	s.Color = color
	s.Thickness = LINE_WIDTH
	s.Parent = parent
	look(s, "Transparency", 0)
end

local function label(parent, props)
	local l = Instance.new("TextLabel")
	l.Text = ""
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextScaled = true
	for k, v in pairs(props) do
		l[k] = v
	end
	l.Parent = parent
	return l
end

local function sizeLimit(parent, maxSize, minSize)
	local c = Instance.new("UITextSizeConstraint")
	c.MaxTextSize = maxSize
	c.MinTextSize = minSize or TEXT_MIN
	c.Parent = parent
end

local function fitNote()
	local text = noteWords and noteWords.Text or ""
	local pill = text ~= "" and note.AbsoluteSize or Vector2.zero
	if pill.X <= 0 or pill.Y <= 0 then
		return
	end
	local area = Vector2.new(pill.X * NOTE_TEXT_SIZE.X.Scale - NOTE_SLACK, pill.Y * NOTE_TEXT_SIZE.Y.Scale)
	local room = Vector2.new(math.huge, math.huge)
	noteWords.Size = NOTE_TEXT_SIZE
	for size = NOTE_MAX, NOTE_ONE_LINE, -1 do
		local one = TextService:GetTextSize(text, size, FONT, room)
		if one.X <= area.X and one.Y <= area.Y then
			noteWords.TextScaled = false
			noteWords.TextSize = size
			return
		end
	end
	local function fits(size, width)
		local bounds = TextService:GetTextSize(text, size, FONT, Vector2.new(width, math.huge))
		return bounds.X <= width and bounds.Y <= area.Y
	end
	for size = NOTE_MAX, NOTE_MIN, -1 do
		if fits(size, area.X) then
			local half = TextService:GetTextSize(text, size, FONT, room).X / 2
			local width = area.X
			for _ = 1, NOTE_TRIES do
				local narrower = math.max(half, width - area.X * NOTE_STEP)
				if narrower >= width or not fits(size, narrower) then
					break
				end
				width = narrower
			end
			noteWords.TextScaled = false
			noteWords.TextSize = size
			noteWords.Size = UDim2.new(0, math.ceil(width + NOTE_SLACK), NOTE_TEXT_SIZE.Y.Scale, 0)
			return
		end
	end
	noteWords.TextScaled = true
end

local function fitTag()
	local text = nameWords and nameWords.Text or ""
	local frameSize = text ~= "" and nameTag.Parent.AbsoluteSize or Vector2.zero
	if frameSize.X <= 0 or frameSize.Y <= 0 then
		return
	end
	local height = frameSize.Y * TAG_HEIGHT
	local size = math.clamp(math.floor(height * (1 - 2 * TAG_PAD)), TEXT_MIN, TAG_MAX_TEXT)
	local width = TextService:GetTextSize(text, size, FONT, Vector2.new(math.huge, math.huge)).X + height * TAG_SIDE
	local widest = frameSize.X * TAG_MAX_WIDTH
	nameWords.TextScaled = width > widest
	nameWords.TextSize = size
	nameTag.Size = UDim2.new(0, math.min(width, widest), TAG_HEIGHT, 0)
end

local function placePicture()
	local boxHeight = box and box.AbsoluteSize.Y or 0
	local height = picture and picture.AbsoluteSize.Y or 0
	if boxHeight <= 0 or height <= 0 then
		return
	end
	picture.Position = UDim2.new(PICTURE_AT, 0, 1 - BOX_BOTTOM, -math.max(0, boxHeight - (1 - PICTURE_ABOVE) * height))
end

local function hudHeight()
	local playerGui = Players.LocalPlayer:FindFirstChild("PlayerGui")
	local hud = playerGui and playerGui:FindFirstChild(HUD_GUI)
	local bar = hud and hud:IsA("ScreenGui") and hud.Enabled and hud:FindFirstChildWhichIsA("Frame")
	if not bar or not bar.Visible or bar.AbsoluteSize.Y <= 0 then
		return 0
	end
	local top = bar.AbsolutePosition.Y
	for _, d in ipairs(bar:GetChildren()) do
		if d:IsA("TextLabel") and d.Visible and d.Text ~= "" and d.AbsoluteSize.Y > 0 then
			top = math.min(top, d.AbsolutePosition.Y)
		end
	end
	return math.max(0, hud.AbsolutePosition.Y + hud.AbsoluteSize.Y - top)
end

local function place(lift)
	local height = gui and gui.AbsoluteSize.Y or 0
	if height <= 0 then
		root.Position = UDim2.fromScale(0.5, 1 - lift)
		picture.Size = UDim2.fromScale(1, PICTURE_HEIGHT - lift)
		return
	end
	local raise = math.max(0, math.ceil(hudHeight() + HUD_GAP - (BOX_BOTTOM + lift) * height))
	local boxTop = (1 - BOX_BOTTOM - lift) * height - raise - math.min(BOX_HEIGHT * height, MAX_BOX_HEIGHT)
	local natural = math.min((PICTURE_HEIGHT - lift) * height, PICTURE_MAX)
	local shrink = math.max(0, math.ceil(natural - (boxTop - PICTURE_TOP * height) / PICTURE_ABOVE))
	root.Position = UDim2.new(0.5, 0, 1 - lift, -raise)
	picture.Size = UDim2.new(1, 0, PICTURE_HEIGHT - lift, -shrink)
end

local function build()
	if gui then
		return
	end
	gui = Instance.new("ScreenGui")
	gui.Name = "WitchTalk"
	gui.ResetOnSpawn = false
	gui.IgnoreGuiInset = true
	gui.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
	gui.DisplayOrder = DISPLAY_ORDER
	gui.Enabled = false
	root = frame(gui, { Name = "Talk", AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.fromScale(0.5, 1),
		Size = UDim2.fromScale(WIDTH, 1), BackgroundTransparency = 1 })
	local wide = Instance.new("UISizeConstraint")
	wide.MaxSize = Vector2.new(MAX_WIDTH, math.huge)
	wide.Parent = root

	picture = Instance.new("ImageLabel")
	picture.Name = "Witch"
	picture.AnchorPoint = Vector2.new(0.5, 1)
	picture.Position = UDim2.fromScale(PICTURE_AT, 1 - BOX_BOTTOM)
	picture.Size = UDim2.fromScale(1, PICTURE_HEIGHT)
	picture.BackgroundTransparency = 1
	picture.ScaleType = Enum.ScaleType.Fit
	picture.ZIndex = 1
	picture.Parent = root
	local square = Instance.new("UIAspectRatioConstraint")
	square.AspectRatio = 1
	square.DominantAxis = Enum.DominantAxis.Height
	square.Parent = picture
	local tallest = Instance.new("UISizeConstraint")
	tallest.MaxSize = Vector2.new(PICTURE_MAX, PICTURE_MAX)
	tallest.Parent = picture
	look(picture, "ImageTransparency", 0)
	standIn = label(picture, { AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.fromScale(0.5, STAND_IN_UP),
		Size = UDim2.fromScale(STAND_IN_SIZE, STAND_IN_SIZE), Text = STAND_IN, Visible = false, ZIndex = 1 })
	look(standIn, "TextTransparency", 0)

	box = frame(root, { Name = "Box", AnchorPoint = Vector2.new(0, 1), Position = UDim2.fromScale(0, 1 - BOX_BOTTOM),
		Size = UDim2.fromScale(1, BOX_HEIGHT), BackgroundColor3 = BOX_FILL, ZIndex = 2 })
	look(box, "BackgroundTransparency", BOX_SEE)
	local tall = Instance.new("UISizeConstraint")
	tall.MaxSize = Vector2.new(math.huge, MAX_BOX_HEIGHT)
	tall.Parent = box
	corner(box, UDim.new(0, BOX_CORNER))
	edge(box, BOX_EDGE)
	for _, y in ipairs(RULES) do
		local rule = frame(box, { AnchorPoint = Vector2.new(0, 0.5), Position = UDim2.fromScale(RULE_INSET, y),
			Size = UDim2.new(1 - 2 * RULE_INSET, 0, 0, LINE_WIDTH), BackgroundColor3 = RULE_COLOR, ZIndex = 2 })
		look(rule, "BackgroundTransparency", RULE_SEE)
	end
	local margin = frame(box, { AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.fromScale(MARGIN_AT, 0),
		Size = UDim2.new(0, LINE_WIDTH, 1, 0), BackgroundColor3 = MARGIN_COLOR, ZIndex = 2 })
	look(margin, "BackgroundTransparency", MARGIN_SEE)
	for i = 1, RINGS do
		local ring = frame(box, { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0, i / (RINGS + 1)),
			Size = UDim2.fromScale(1, RING_HEIGHT), BackgroundColor3 = RING_FILL, ZIndex = 3 })
		local shape = Instance.new("UIAspectRatioConstraint")
		shape.AspectRatio = RING_SHAPE
		shape.DominantAxis = Enum.DominantAxis.Height
		shape.Parent = ring
		corner(ring, UDim.new(0.5, 0))
		edge(ring, RING_EDGE)
		look(ring, "BackgroundTransparency", 0)
	end
	words = label(box, { Name = "Line", Position = UDim2.fromScale(TEXT_LEFT, TEXT_TOP),
		Size = UDim2.fromScale(1 - TEXT_LEFT - TEXT_RIGHT, 1 - TEXT_TOP - TEXT_BOTTOM), TextColor3 = TEXT_COLOR,
		TextWrapped = true, TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Center,
		ZIndex = 4 })
	sizeLimit(words, TEXT_MAX)
	look(words, "TextTransparency", 0)
	note = frame(box, { Name = "Note", Position = UDim2.fromScale(TEXT_LEFT - NOTE_PAD, NOTE_TOP),
		Size = UDim2.fromScale(1 - TEXT_LEFT - TEXT_RIGHT + 2 * NOTE_PAD, 1 - NOTE_TOP - NOTE_BOTTOM),
		BackgroundColor3 = NOTE_FILL, Visible = false, ZIndex = 4 })
	corner(note, UDim.new(0.5, 0))
	look(note, "BackgroundTransparency", NOTE_SEE)
	noteWords = label(note, { Name = "Text", AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5),
		Size = NOTE_TEXT_SIZE, TextColor3 = NOTE_TEXT, TextWrapped = true, ZIndex = 5 })
	sizeLimit(noteWords, NOTE_MAX, NOTE_MIN)
	look(noteWords, "TextTransparency", 0)
	note:GetPropertyChangedSignal("AbsoluteSize"):Connect(fitNote)
	box:GetPropertyChangedSignal("AbsoluteSize"):Connect(fitTag)
	box:GetPropertyChangedSignal("AbsoluteSize"):Connect(placePicture)
	picture:GetPropertyChangedSignal("AbsoluteSize"):Connect(placePicture)
	nameTag = frame(box, { Name = "Name", AnchorPoint = Vector2.new(0, 0.5), Position = UDim2.fromScale(TAG_AT, 0),
		Size = UDim2.fromScale(TAG_MAX_WIDTH, TAG_HEIGHT), BackgroundColor3 = TAG_FILL, ZIndex = 4 })
	corner(nameTag, UDim.new(0, TAG_CORNER))
	look(nameTag, "BackgroundTransparency", 0)
	nameWords = label(nameTag, { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5),
		Size = UDim2.fromScale(1, 1 - 2 * TAG_PAD), TextColor3 = TAG_TEXT, ZIndex = 5 })
	sizeLimit(nameWords, TAG_MAX_TEXT)
	look(nameWords, "TextTransparency", 0)
	paint(1)
	gui.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")
end

local function contentOf(item)
	local id = nil
	if item and item:IsA("Decal") then
		id = item.Texture
	elseif item and (item:IsA("ImageLabel") or item:IsA("ImageButton")) then
		id = item.Image
	elseif item and item:IsA("StringValue") then
		id = item.Value
	end
	if type(id) ~= "string" or id == "" then
		return nil
	end
	return string.match(id, "^%d+$") and ("rbxassetid://" .. id) or id
end

function WitchTalk.picture(face)
	local name = Config.Story.Pictures[face] or Config.Story.Pictures[DEFAULT_FACE]
	local folder = ReplicatedStorage:FindFirstChild("TutorialModels")
	return contentOf(folder and folder:FindFirstChild(name))
end

function WitchTalk.faceFor(id, n)
	local story = Config.Story
	local face = id == "Rebirth" and story.RebirthFaces[n] or story.Faces[id]
	return story.Pictures[face] and face or DEFAULT_FACE
end

function WitchTalk.preload()
	if preloaded then
		return
	end
	preloaded = true
	task.spawn(function()
		local list = {}
		for face in pairs(Config.Story.Pictures) do
			local id = WitchTalk.picture(face)
			if id then
				table.insert(list, id)
			end
		end
		if #list == 0 then
			preloaded = false
			return
		end
		pcall(function()
			ContentProvider:PreloadAsync(list)
		end)
	end)
end

local function holdFor(count)
	return math.min(HOLD_MAX, math.max(HOLD_MIN, count * HOLD_PER_CHAR))
end

local function setNote(explain)
	local shown = explain and explain ~= "" and Lang.t(explain) or ""
	note.Visible = shown ~= ""
	noteWords.Text = shown
	fitNote()
	local bottom = shown ~= "" and 1 - TEXT_SPLIT or TEXT_BOTTOM
	words.Size = UDim2.fromScale(1 - TEXT_LEFT - TEXT_RIGHT, 1 - TEXT_TOP - bottom)
	return utf8.len(shown) or #shown
end

local function stop()
	talk = nil
	if loop then
		loop:Disconnect()
		loop = nil
	end
	if gui then
		paint(1)
		gui.Enabled = false
	end
	task.defer(nextWaiting)
end

local function step()
	local t = talk
	if not t then
		stop()
		return
	end
	local now = os.clock()
	if now - t.looked >= HUD_LOOK then
		t.looked = now
		place(t.lift)
	end
	local see
	if t.closing then
		see = math.min(1, (now - t.closing) / FADE_SECONDS)
		if see >= 1 then
			stop()
			return
		end
	else
		see = 1 - math.min(1, (now - t.born) / FADE_SECONDS)
		if now - t.started >= t.total then
			t.closing = now
		end
	end
	local shown = math.floor((now - t.started) * REVEAL_RATE)
	words.MaxVisibleGraphemes = shown >= t.count and -1 or shown
	paint(see)
end

function WitchTalk.say(text, face, options)
	text = tostring(text or "")
	if text == "" then
		return
	end
	options = options or {}
	build()
	local now = os.clock()
	if options.slot and talk and not talk.closing and talk.slot == options.slot and talk.text == text then
		local extra = setNote(options.explain)
		talk.total = math.max(talk.total, now - talk.started + math.max(SLOT_HOLD, holdFor(extra)))
		return
	end
	if options.queue and talk and not talk.closing and talk.slot ~= options.slot then
		table.insert(waiting, { text = text, face = face, options = options, at = now })
		while #waiting > QUEUE_MAX do
			table.remove(waiting, 1)
		end
		return
	end
	face = Config.Story.Pictures[face] and face or DEFAULT_FACE
	local shown = Lang.t(text)
	words.Text = shown
	nameWords.Text = Lang.t(Config.Story.Title)
	local extra = setNote(options.explain)
	local image = WitchTalk.picture(face)
	picture.Image = image or ""
	standIn.Visible = image == nil
	local lift = options.lift or 0
	place(lift)
	local born = now
	if talk and talk.closing then
		born = now - (1 - math.min(1, (now - talk.closing) / FADE_SECONDS)) * FADE_SECONDS
	elseif talk then
		born = now - FADE_SECONDS
	end
	local count = utf8.len(shown) or #shown
	talk = { born = born, started = now, count = count, text = text, slot = options.slot, lift = lift, looked = now - HUD_LOOK,
		total = options.seconds or (count / REVEAL_RATE + holdFor(count + extra)) }
	words.MaxVisibleGraphemes = 0
	gui.Enabled = true
	fitNote()
	fitTag()
	placePicture()
	if not loop then
		loop = RunService.RenderStepped:Connect(step)
	end
	step()
	if options.voice ~= false then
		CocoVoice.witch(text, nil, MOODS[face])
	end
	WitchTalk.preload()
end

nextWaiting = function()
	if talk then
		return
	end
	local now = os.clock()
	while #waiting > 0 do
		local w = table.remove(waiting, 1)
		if now - w.at <= QUEUE_STALE then
			local options = table.clone(w.options)
			options.queue = nil
			WitchTalk.say(w.text, w.face, options)
			return
		end
	end
end

function WitchTalk.close(now)
	if now then
		table.clear(waiting)
	end
	if not talk then
		return
	end
	if now then
		stop()
	elseif not talk.closing then
		talk.closing = os.clock()
	end
end

function WitchTalk.showing()
	return talk ~= nil and not talk.closing
end

return WitchTalk
