local Players = game:GetService("Players")

local Shared = script.Parent
local Lang = require(Shared:WaitForChild("Lang"))
local TopBar = require(Shared:WaitForChild("TopBar"))
local SideButtons = require(Shared:WaitForChild("SideButtons"))

local FoldHint = {}

local TIP_SIZE = UDim2.fromOffset(150, 26)
local TIP_GAP = 8
local TIP_TEXT = 13
local TIP_BACK = Color3.fromRGB(30, 30, 45)
local TIP_COLOR = Color3.fromRGB(255, 225, 110)
local TIP_EDGE = Color3.fromRGB(255, 225, 110)
local DIM_COLOR = Color3.new(0, 0, 0)
local DIM_TRANSPARENCY = 0.5
local DIM_SECONDS = 5
local DIM_FADE = 1
local PAD = 5
local DISPLAY_ORDER = 9
local TIP_WORDS = "📂 눌러서 펼쳐요"

local gui, tip = nil, nil
local dims = {}
local shownFor, since = nil, 0

local function build()
	if gui then
		return
	end
	gui = Instance.new("ScreenGui")
	gui.Name = "FoldHint"
	gui.ResetOnSpawn = false
	gui.DisplayOrder = DISPLAY_ORDER
	gui.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")
	for i = 1, 4 do
		local d = Instance.new("Frame")
		d.BackgroundColor3 = DIM_COLOR
		d.BorderSizePixel = 0
		d.Active = false
		d.Visible = false
		d.Parent = gui
		dims[i] = d
	end
	tip = Instance.new("TextLabel")
	tip.Size = TIP_SIZE
	tip.BackgroundColor3 = TIP_BACK
	tip.BackgroundTransparency = 0.1
	tip.Font = Enum.Font.GothamBold
	tip.TextSize = TIP_TEXT
	tip.TextColor3 = TIP_COLOR
	tip.Text = TIP_WORDS
	tip.Visible = false
	tip.Parent = gui
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = tip
	local edge = Instance.new("UIStroke")
	edge.Color = TIP_EDGE
	edge.Thickness = 2
	edge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	edge.Parent = tip
	Lang.set(tip, TIP_WORDS)
end

local function matcher(text, exact)
	return function(b)
		local source = Lang.source(b)
		if exact then
			return source == text
		end
		return string.find(source, text, 1, true) ~= nil
	end
end

function FoldHint.holderFor(text, exact)
	if type(text) ~= "string" or text == "" then
		return nil
	end
	local match = matcher(text, exact)
	local top = TopBar.isFolded() and TopBar.find(match)
	if top and not top.Visible then
		return TopBar.foldButton()
	end
	if SideButtons.isFolded() and SideButtons.find(match) then
		return SideButtons.toggleButton()
	end
	return nil
end

function FoldHint.show(button, withDim)
	if not button or not button.Parent then
		if gui then
			tip.Visible = false
			for _, d in ipairs(dims) do
				d.Visible = false
			end
		end
		shownFor = nil
		return
	end
	build()
	if shownFor ~= button then
		shownFor, since = button, os.clock()
	end
	local origin = gui.AbsolutePosition
	local p, s = button.AbsolutePosition - origin, button.AbsoluteSize
	local size = gui.AbsoluteSize
	local x0, y0 = p.X - PAD, p.Y - PAD
	local x1, y1 = p.X + s.X + PAD, p.Y + s.Y + PAD
	local age = os.clock() - since
	local shade = age < DIM_SECONDS and DIM_TRANSPARENCY
		or DIM_TRANSPARENCY + (1 - DIM_TRANSPARENCY) * math.min(1, (age - DIM_SECONDS) / DIM_FADE)
	local rects = { { 0, -size.Y, size.X, y0 + size.Y }, { 0, y1, size.X, size.Y * 2 }, { -size.X, y0, x0 + size.X, y1 - y0 },
		{ x1, y0, size.X * 2, y1 - y0 } }
	for i, d in ipairs(dims) do
		local r = rects[i]
		d.Position = UDim2.fromOffset(r[1], r[2])
		d.Size = UDim2.fromOffset(math.max(0, r[3]), math.max(0, r[4]))
		d.BackgroundTransparency = shade
		d.Visible = withDim and shade < 1
	end
	local w = TIP_SIZE.X.Offset
	if x0 - TIP_GAP - w >= 0 then
		tip.AnchorPoint = Vector2.new(1, 0.5)
		tip.Position = UDim2.fromOffset(x0 - TIP_GAP, (y0 + y1) / 2)
	else
		tip.AnchorPoint = Vector2.new(0.5, 0)
		tip.Position = UDim2.fromOffset((x0 + x1) / 2, y1 + TIP_GAP)
	end
	tip.Visible = true
end

return FoldHint
