local Coach = {}

local SCROLL_AGAIN = 10
local SCROLL_MARGIN = 6
local PRUNE_EVERY = 400

local marked = {}
local byName = {}
local scrolledAt = {}
local adds = 0

local function shown(obj)
	local node = obj
	while node do
		if node:IsA("GuiObject") then
			if not node.Visible then
				return false
			end
		elseif node:IsA("LayerCollector") then
			return node.Enabled
		end
		node = node.Parent
	end
	return false
end

local function inView(obj)
	local p, s = obj.AbsolutePosition, obj.AbsoluteSize
	local x, y = p.X + s.X / 2, p.Y + s.Y / 2
	local node = obj.Parent
	while node and not node:IsA("LayerCollector") do
		if node:IsA("ScrollingFrame") then
			local a, b = node.AbsolutePosition, node.AbsoluteSize
			if x < a.X or x > a.X + b.X or y < a.Y or y > a.Y + b.Y then
				return false
			end
		end
		node = node.Parent
	end
	return true
end

local function inWorld(obj)
	local node = obj.Parent
	while node and not node:IsA("LayerCollector") do
		node = node.Parent
	end
	return node ~= nil and not node:IsA("ScreenGui")
end

local function prune()
	for obj, name in pairs(marked) do
		if obj.Parent == nil then
			if byName[name] then
				byName[name][obj] = nil
			end
			marked[obj] = nil
		end
	end
	for frame in pairs(scrolledAt) do
		if frame.Parent == nil then
			scrolledAt[frame] = nil
		end
	end
end

function Coach.mark(obj, name)
	local old = marked[obj]
	if old == name then
		return
	end
	if old and byName[old] then
		byName[old][obj] = nil
	end
	marked[obj] = name
	if name then
		byName[name] = byName[name] or {}
		byName[name][obj] = true
		adds += 1
		if adds % PRUNE_EVERY == 0 then
			prune()
		end
	end
end

function Coach.nameOf(obj)
	return marked[obj]
end

function Coach.visible(obj)
	return obj ~= nil and obj.Parent ~= nil and marked[obj] ~= nil and obj.AbsoluteSize.X > 0 and shown(obj) and inView(obj)
end

local function scrollerOf(obj)
	local node = obj.Parent
	while node and not node:IsA("LayerCollector") do
		if node:IsA("ScrollingFrame") then
			return node
		end
		node = node.Parent
	end
	return nil
end

local function bringIntoView(obj)
	local frame = scrollerOf(obj)
	if not frame or frame.CanvasPosition.Y >= 1 or os.clock() - (scrolledAt[frame] or -math.huge) < SCROLL_AGAIN then
		return
	end
	scrolledAt[frame] = os.clock()
	local a, b = frame.AbsolutePosition, frame.AbsoluteSize
	local p, s = obj.AbsolutePosition, obj.AbsoluteSize
	local down = math.max(0, p.Y + s.Y - (a.Y + b.Y) + SCROLL_MARGIN)
	frame.CanvasPosition = Vector2.new(frame.CanvasPosition.X, frame.CanvasPosition.Y + down)
end

function Coach.find(name)
	local set = byName[name]
	if not set then
		return nil
	end
	local best, bestY, bestX = nil, math.huge, math.huge
	local hidden, hiddenY = nil, math.huge
	local world = nil
	for obj in pairs(set) do
		if obj.Parent == nil then
			set[obj] = nil
			marked[obj] = nil
		elseif obj:IsA("GuiObject") and obj.AbsoluteSize.X > 0 and shown(obj) then
			local p = obj.AbsolutePosition
			if inWorld(obj) then
				world = world or obj
			elseif not inView(obj) then
				if p.Y < hiddenY then
					hidden, hiddenY = obj, p.Y
				end
			elseif p.Y < bestY - 2 or (p.Y <= bestY + 2 and p.X < bestX) then
				best, bestY, bestX = obj, p.Y, p.X
			end
		end
	end
	if not best and hidden then
		bringIntoView(hidden)
	end
	return best or (not hidden and world or nil), not best and hidden or nil
end

function Coach.first(list)
	local lost, lostKey = nil, nil
	for i = #list, 1, -1 do
		for name in string.gmatch(list[i], "[^|]+") do
			local found, hidden = Coach.find(name)
			if found then
				return found, list[i]
			end
			if hidden and not lost then
				lost, lostKey = hidden, list[i]
			end
		end
	end
	return nil, nil, lost, lostKey
end

function Coach.swipeFor(obj)
	local frame = obj and obj.Parent and scrollerOf(obj)
	if not frame then
		return nil, nil
	end
	local a, b = frame.AbsolutePosition, frame.AbsoluteSize
	local p, s = obj.AbsolutePosition, obj.AbsoluteSize
	local x, y = p.X + s.X / 2, p.Y + s.Y / 2
	if y > a.Y + b.Y then
		return frame, "Up"
	elseif y < a.Y then
		return frame, "Down"
	elseif x > a.X + b.X then
		return frame, "Left"
	elseif x < a.X then
		return frame, "Right"
	end
	return frame, nil
end

return Coach
