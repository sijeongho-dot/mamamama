--[[
DinoVoices: which voice each dino species growls with, and how high (display only, clients).

There are seven voices (sounds made by tools/make_sounds.py, played through Shared/Sfx): a big
meat-eater's roar, a plant-eater's bellow, a crested duckbill's honk, a small hunter's hiss and chirp,
an armored dino's grunt, a flyer's screech and a sea reptile's groan. Each species picks one and a
pitch, and bigger dinos sound lower:

	local name, pitch = DinoVoices.voice("TRex", footprint)   -- footprint: the unit's radius (studs), optional
	Sfx.play(name, position, pitch)
	local name, pitch = DinoVoices.roar("TRex")               -- the big roar of a ridden dino (울부짖기)
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))

local DinoVoices = {}

-- display only
local BY_THEME = { -- the voice of a species not listed below
	Carnivore = { "VoiceRoar", 1 }, Herbivore = { "VoiceBellow", 1 }, Armored = { "VoiceGrunt", 1 },
	Sky = { "VoiceScreech", 1 }, Sea = { "VoiceSea", 1 },
}
local SPECIES = { -- [species] = { voice, pitch }
	TRex = { "VoiceRoar", 0.85 }, Spino = { "VoiceRoar", 0.78 }, IceRex = { "VoiceRoar", 0.92 },
	FlameSpino = { "VoiceRoar", 0.8 }, Raptor = { "VoiceChirp", 1 }, RoboRaptor = { "VoiceChirp", 1.25 },
	Dilopho = { "VoiceChirp", 0.85 }, Microraptor = { "VoiceChirp", 1.35 },
	Trike = { "VoiceBellow", 1 }, MagmaTrike = { "VoiceBellow", 0.9 }, Iguanodon = { "VoiceBellow", 1.12 },
	Brachio = { "VoiceBellow", 0.7 }, Parasaur = { "VoiceHonk", 1 },
	Ankylo = { "VoiceGrunt", 0.95 }, Pachy = { "VoiceGrunt", 1.18 }, Stego = { "VoiceGrunt", 1 },
	Kentro = { "VoiceGrunt", 1.06 },
	Pteranodon = { "VoiceScreech", 1 }, Rhampho = { "VoiceScreech", 1.2 }, Quetzal = { "VoiceScreech", 0.82 },
	Mosa = { "VoiceSea", 0.92 }, Plesio = { "VoiceSea", 1.1 }, Krono = { "VoiceSea", 0.82 }, Shoni = { "VoiceSea", 0.72 },
	Allo = { "VoiceRoar", 0.95 }, Therizino = { "VoiceHonk", 0.85 }, Nodo = { "VoiceGrunt", 0.9 },
	Dimorpho = { "VoiceScreech", 1.3 }, Ichthyo = { "VoiceSea", 1.25 }, ThunderStego = { "VoiceGrunt", 0.88 },
	-- (2026-10-01) the rest of the 60
	Utahraptor = { "VoiceChirp", 0.9 }, Giganoto = { "VoiceRoar", 0.72 }, Carno = { "VoiceRoar", 1.0 },
	Cerato = { "VoiceRoar", 1.05 }, Baryonyx = { "VoiceRoar", 0.92 }, PoisonDilopho = { "VoiceChirp", 0.8 },
	Edmonto = { "VoiceHonk", 0.9 }, Maia = { "VoiceHonk", 1.08 }, Styraco = { "VoiceBellow", 1.05 },
	Diplo = { "VoiceBellow", 0.68 }, Argentino = { "VoiceBellow", 0.62 }, ClockBrachio = { "VoiceBellow", 0.8 },
	Euoplo = { "VoiceGrunt", 0.9 }, Saichania = { "VoiceGrunt", 0.85 }, Gastonia = { "VoiceGrunt", 1.05 },
	Huayango = { "VoiceGrunt", 1.12 }, Stegoceras = { "VoiceGrunt", 1.25 }, GemStego = { "VoiceGrunt", 1.1 },
	CyberAnkylo = { "VoiceGrunt", 0.8 },
	Pterodac = { "VoiceScreech", 1.25 }, Tupux = { "VoiceScreech", 0.95 }, Ornitho = { "VoiceScreech", 0.9 },
	Anurog = { "VoiceScreech", 1.45 }, Hatzego = { "VoiceScreech", 0.72 },
	Elasmo = { "VoiceSea", 1.05 }, Notho = { "VoiceSea", 1.2 }, Tylo = { "VoiceSea", 0.88 },
	Archelon = { "VoiceSea", 0.78 }, Liopleuro = { "VoiceSea", 0.68 }, CosmoMosa = { "VoiceSea", 0.95 },
	WildRaptor = { "VoiceChirp", 1.1 }, -- (the wild packs, StarterPlayerScripts/Wildlife)
	-- (2026-10-02) the awakened variants
	AuroraParasaur = { "VoiceHonk", 1.05 }, StormQuetzal = { "VoiceScreech", 0.85 }, SolarAllo = { "VoiceRoar", 0.9 },
}
local SIZE_PITCH_BASE = 2 -- a unit this wide (footprint radius, studs) keeps the species' pitch
local SIZE_PITCH_POWER = 0.25 -- bigger ones lower, smaller ones higher, gently
local PITCH_MIN, PITCH_MAX = 0.6, 1.5

function DinoVoices.voice(speciesId, footprint)
	local entry = SPECIES[speciesId]
	if not entry then
		local species = Formulas.species(speciesId)
		local theme = species and (species.BaseTheme or species.Theme)
		entry = BY_THEME[theme] or BY_THEME.Carnivore
	end
	local pitch = entry[2]
	if footprint and footprint > 0 then
		pitch *= (SIZE_PITCH_BASE / footprint) ^ SIZE_PITCH_POWER
	end
	return entry[1], math.clamp(pitch * (0.95 + math.random() * 0.1), PITCH_MIN, PITCH_MAX)
end

-- the ridden dino's big roar: the long version of its voice (a meat-eater's roar, a plant-eater's
-- bellow, a duckbill's honk, a small hunter's shriek, an armored dino's grunts), at the species' pitch
local ROARS = { VoiceRoar = "MountRoar", VoiceBellow = "MountBellow", VoiceHonk = "MountHonk",
	VoiceChirp = "MountChirp", VoiceGrunt = "MountGrunt" }

function DinoVoices.roar(speciesId)
	local name, pitch = DinoVoices.voice(speciesId)
	return ROARS[name] or "MountRoar", pitch
end

return DinoVoices
