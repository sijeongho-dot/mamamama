--[[
Formulas: the game's calculations from Config, shared by the server (which decides), the client
(which only displays) and the tests (tools/tests/formulas_test.lua, where `game` does not exist and
the Config comes from the global CONFIG).

No function here changes anything or reads a service.
]]

local Config = if game then require(game:GetService("ReplicatedStorage"):WaitForChild("Config")) else CONFIG

local Formulas = {}

local DRAWN_SCALE = 1.3
local DRAWN_POWER = 0.85
local SHORT_FROM = 10000
local SHORT_MAX_TENTHS = 9999
local SHORT_UNITS = { "K", "M", "B", "T" }
local SHORT_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

local function index(list)
	local byId = {}
	for i, item in ipairs(list) do
		byId[item.Id] = item
		byId[item.Id .. "#"] = i
	end
	return byId
end
local GRADES = index(Config.Minerals.Grades)
GRADES[Config.Minerals.Special.Id] = Config.Minerals.Special
GRADES[Config.Minerals.Special.Id .. "#"] = Config.Minerals.Special.Number
local SIZES = index(Config.Minerals.Sizes)

function Formulas.grade(id)
	return GRADES[id]
end

function Formulas.drawnScale(stats)
	return DRAWN_SCALE * (stats.Look or stats.Scale) ^ DRAWN_POWER
end

function Formulas.size(id)
	return SIZES[id]
end

local function shortUnit(unit)
	if unit <= #SHORT_UNITS then
		return SHORT_UNITS[unit]
	end
	local i = unit - #SHORT_UNITS - 1
	local first, second = i // #SHORT_LETTERS + 1, i % #SHORT_LETTERS + 1
	return string.sub(SHORT_LETTERS, first, first) .. string.sub(SHORT_LETTERS, second, second)
end

function Formulas.shortNumber(n)
	n = tonumber(n) or 0
	if n ~= n then
		n = 0
	end
	local sign = n < 0 and "-" or ""
	n = math.floor(math.abs(n))
	if n < SHORT_FROM then
		local text, count = tostring(n), 1
		while count > 0 do
			text, count = string.gsub(text, "^(%d+)(%d%d%d)", "%1,%2")
		end
		return sign .. text
	end
	local unit = 1
	while n >= 1000 ^ (unit + 1) and 1000 ^ (unit + 1) < math.huge do
		unit += 1
	end
	local tenths = math.min(math.floor(n / (1000 ^ unit / 10)), SHORT_MAX_TENTHS)
	local text = if tenths % 10 == 0 then tostring(tenths // 10)
		else string.format("%d.%d", tenths // 10, tenths % 10)
	return sign .. text .. shortUnit(unit)
end

function Formulas.gradeNumber(id) -- 1 = Droplet ... 6 = Starlight
	return GRADES[id .. "#"]
end

-- ---------------------------------------------------------------------------
-- Pickaxe
-- ---------------------------------------------------------------------------

-- one hit's power: tier power × (1 + 5% per power step)
function Formulas.pickaxePower(tier, powerSteps)
	return Config.Pickaxe.Tiers[tier].Power * (1 + powerSteps * Config.Pickaxe.PowerPerStep)
end

-- (2026-10-04) a track's gain at a level: per a level up to the old top, perAfter a level past it
local function stepped(level, oldTop, per, perAfter)
	local past = math.max(0, level - (oldTop or level))
	if type(perAfter) == "table" then
		past = perAfter.Gain * (math.min(past, perAfter.Levels) / perAfter.Levels) ^ perAfter.Power
	else
		past *= perAfter or per
	end
	return math.min(level, oldTop or level) * per + past
end
Formulas.stepped = stepped

function Formulas.frontLevel(level, first, oldTop)
	local f = Config.Training.FrontLoad
	local x, top = level - first, oldTop - first
	if x >= top then
		return level
	end
	local early = top * f.Share
	local rest = (1 - f.Share * f.Boost) / (1 - f.Share)
	return first + math.min(x, early) * f.Boost + math.max(0, x - early) * rest
end

function Formulas.tableAt(t, level)
	local lo = math.clamp(math.floor(level), 1, #t)
	local hi = math.min(lo + 1, #t)
	return t[lo] + (t[hi] - t[lo]) * math.clamp(level - lo, 0, 1)
end

function Formulas.pickaxeSpeed(tier, speedLevel)
	local p = Config.Pickaxe
	local u = p.SpeedUpgrade
	return p.Tiers[tier].Speed * (1 + stepped(Formulas.frontLevel(speedLevel, 0, u.OldTop), u.OldTop, u.PerLevel, u.PerLevelAfter))
end

-- seconds of one mining turn (swing + loading bar):
-- max(MinTurnSeconds, TurnSeconds × (hardness ÷ power)^HardnessExponent) ÷ speed.
-- Tier 1 takes 4 s even on droplets and forever on hard grades; each tier up is a big relief, and
-- speed always helps (it divides after the minimum).
function Formulas.mineSeconds(tier, powerSteps, speedLevel, gradeId)
	local power = Formulas.pickaxePower(tier, powerSteps)
	local speed = Formulas.pickaxeSpeed(tier, speedLevel)
	local m = Config.Mining
	return math.max(GRADES[gradeId].MinTurnSeconds or m.MinTurnSeconds, m.TurnSeconds * (GRADES[gradeId].Hardness / power) ^ m.HardnessExponent) / speed
end

-- (2026-10-04) one of the game's developers (Config.Developers, by user name, any case): never ranked
function Formulas.isDeveloper(name)
	if type(name) ~= "string" then
		return false
	end
	for _, n in ipairs(Config.Developers.Names) do
		if string.lower(n) == string.lower(name) then
			return true
		end
	end
	return false
end

-- (2026-10-04) a mineral too hard for this pickaxe to start: a turn longer than Config.Mining.LockSeconds (the pickaxe
-- alone: no weather, night or boost) is 🔒 (the button, the server, auto mining)
function Formulas.mineLocked(tier, powerSteps, speedLevel, gradeId)
	return tier < Formulas.minTier(gradeId) -- (2026-10-04) below the grade's lowest tier
		or Formulas.mineSeconds(tier, powerSteps, speedLevel, gradeId) > Config.Mining.LockSeconds
end

-- (2026-10-04) the lowest pickaxe tier that may mine a grade (Config.Minerals.Grades MinTier; the 🔒 button shows it)
function Formulas.minTier(gradeId)
	local g = GRADES[gradeId]
	return g and (g.MinTier or 1) or 1
end

-- (2026-10-04) 🐣 the rookie buff (Config.Mining.Rookie): how many times as fast a mining turn goes after playSeconds of
-- play, and the seconds of it left (1, 0 once over; nil play time counts as over)
function Formulas.rookieSpeed(playSeconds)
	local r = Config.Mining.Rookie
	local left = r.Minutes * 60 - (playSeconds or math.huge)
	if left > 0 then
		return r.Speed, left
	end
	return 1, 0
end

-- "4초", "10분", "32시간" for notices
function Formulas.durationText(seconds)
	if seconds < 60 then
		return string.format("%d초", math.ceil(seconds))
	elseif seconds < 3600 then
		return string.format("%d분", math.ceil(seconds / 60))
	elseif seconds < 86400 then
		return string.format("%d시간", math.ceil(seconds / 3600))
	end
	return string.format("%d일", math.ceil(seconds / 86400))
end

function Formulas.recommendedTier(gradeId)
	return GRADES[gradeId].RecommendedTier
end

-- mining turns a node holds: its size's Hits × its own scale (bigger node, more minerals), at least 1
function Formulas.nodeTurns(sizeId, scale)
	return math.max(1, math.floor(SIZES[sizeId].Hits * scale + 0.5))
end

function Formulas.yieldPerTurn(tier, gradeId, sizeId)
	if GRADES[gradeId].FixedYield then
		return GRADES[gradeId].FixedYield
	end
	local size = sizeId and SIZES[sizeId]
	return Config.Pickaxe.Tiers[tier].Yield * (size and size.YieldMultiplier or 1)
end

function Formulas.mineRate(tier, steps, speedLevel)
	local top, id = 0, nil
	for _, g in ipairs(Config.Minerals.Grades) do
		if not Formulas.mineLocked(tier, steps, speedLevel, g.Id) then
			local rate = g.Value * Config.Pickaxe.Tiers[tier].Yield / Formulas.mineSeconds(tier, steps, speedLevel, g.Id)
			if rate > top then
				top, id = rate, g.Id
			end
		end
	end
	return top, id
end

function Formulas.nextPickaxeGain(tier, steps, speedLevel)
	if tier >= #Config.Pickaxe.Tiers then
		return nil, nil
	end
	local opens = nil
	for _, g in ipairs(Config.Minerals.Grades) do
		if Formulas.minTier(g.Id) == tier + 1 then
			opens = g.Id
		end
	end
	return Formulas.mineRate(tier + 1, 0, speedLevel) / math.max(Formulas.mineRate(tier, steps, speedLevel), 1e-9), opens
end

function Formulas.turnFloor(seconds)
	local shortest = Config.Mining.ShortestTurn
	if seconds >= shortest then
		return seconds, 1
	end
	return shortest, shortest / math.max(seconds, 1e-6)
end

-- price of the next pickaxe tier, or nil at the top (including the current stage's limit)
-- the late-game price rise of a shop upgrade track: × (1 + LatePriceGrowth × progress^LatePriceCurve),
-- progress = how far along its track the upgrade is (0 the first, 1 the last): early prices barely
-- change, the last ones cost (1 + LatePriceGrowth) times as much
function Formulas.latePriceMultiplier(progress)
	local e = Config.Economy
	return 1 + e.LatePriceGrowth * math.clamp(progress or 0, 0, 1) ^ e.LatePriceCurve
end

-- every upgrade price (pickaxe, power, speed, bag, slap, move speed, slots, rebirth) × Config.Economy
-- .UpgradePriceScale (and the shop tracks × latePriceMultiplier(progress)), kept to two significant
-- digits like the design's tables
function Formulas.upgradePrice(price, progress, scale)
	if price == nil or price <= 0 then
		return price
	end
	local x = price * (scale or Config.Economy.UpgradePriceScale) * Formulas.latePriceMultiplier(progress)
	if x < 100 then
		return math.floor(x + 0.5)
	end
	local unit = 10 ^ (math.floor(math.log10(x)) - 1)
	return math.floor(x / unit + 0.5) * unit
end

function Formulas.nextPickaxePrice(tier, level)
	local nextTier = tier + 1
	if nextTier > #Config.Pickaxe.Tiers or nextTier > Config.Stage.PickaxeMaxTier then
		return nil
	end
	return Formulas.upgradePrice(Config.Pickaxe.Tiers[nextTier].Price * Formulas.levelIndex(level))
end

function Formulas.pickaxeNeedLevel(tier)
	return Config.Pickaxe.NeedLevel and Config.Pickaxe.NeedLevel[tier] or nil
end

function Formulas.pickaxeOpen(tier, defenseLevel)
	local need = Formulas.pickaxeNeedLevel(tier)
	return need == nil or (defenseLevel or 1) >= need
end

-- may the next tier be bought with this many power steps done?
function Formulas.powerStepsNeed(tier)
	local need = Config.Pickaxe.NeedPowerSteps and Config.Pickaxe.NeedPowerSteps[(tier or 1) + 1]
	if need then
		return math.min(need, Config.Pickaxe.PowerSteps)
	end
	return Config.Pickaxe.NextTierNeedsAllPowerSteps and Config.Pickaxe.PowerSteps or 0
end

function Formulas.powerStepsCap(tier)
	local need = Formulas.powerStepsNeed(tier)
	return need > 0 and need or Config.Pickaxe.PowerSteps
end

function Formulas.powerStepsDone(powerSteps, tier)
	return (powerSteps or 0) >= Formulas.powerStepsNeed(tier)
end

function Formulas.powerShown(tier, powerSteps)
	return Formulas.trainShownOf("Power", ((tier or 1) - 1) * Config.Pickaxe.PowerSteps + (powerSteps or 0))
end

-- cost of the next power step of this tier, or nil when all are done
function Formulas.nextPowerStepCost(tier, powerSteps)
	if powerSteps >= Config.Pickaxe.PowerSteps then
		return nil
	end
	return Formulas.upgradePrice(Config.Pickaxe.PowerStepCost[tier][powerSteps + 1],
		(tier - 1 + powerSteps / Config.Pickaxe.PowerSteps) / #Config.Pickaxe.Tiers)
end

-- cost of the next speed level, or nil at the top
function Formulas.nextSpeedCost(speedLevel)
	local costs = Config.Pickaxe.SpeedUpgrade.Cost
	return Formulas.upgradePrice(costs[speedLevel + 1], speedLevel / (#costs - 1))
end

-- ---------------------------------------------------------------------------
-- Bag (carried minerals: a table { ["Grade/Size"] = count })
-- ---------------------------------------------------------------------------

function Formulas.bagCapacity(level, doubleBag)
	local capacity = math.floor(Formulas.tableAt(Config.Bag.Capacity, level))
	if doubleBag then
		capacity *= Config.GamePasses.DoubleBag.CapacityMultiplier
	end
	return capacity
end

-- cost of the next bag level, or nil at the top
function Formulas.nextBagCost(level)
	return Formulas.upgradePrice(Config.Bag.Cost[level + 1], (level - 1) / (#Config.Bag.Cost - 2))
end

function Formulas.carryKey(gradeId, sizeId)
	return gradeId .. "/" .. sizeId
end

function Formulas.splitCarryKey(key)
	local gradeId, sizeId = string.match(key, "^(.-)/(.+)$")
	return gradeId, sizeId
end

function Formulas.treasureSlots()
	return Config.Minerals.Special.BagSlots
end

function Formulas.bagSlots(gradeId, sizeId)
	local grade = gradeId and GRADES[gradeId]
	if grade and grade.BagSlots then
		return tonumber(sizeId) or grade.BagSlots
	end
	return Config.Minerals.BagSlotsPerMineral
end

function Formulas.carryCount(carry)
	local total = 0
	for key, count in pairs(carry) do
		total += count * Formulas.bagSlots(Formulas.splitCarryKey(key))
	end
	return total
end

-- a mineral's worth at this defense level over its listed value (Config.Minerals.LevelValueGrowth)
function Formulas.mineralLevelMultiplier(level)
	local m = Config.Minerals
	local after = m.LevelValueGrowthAfter
	level = math.max(level or 1, 1)
	local early = math.min(level, after.FromLevel) - 1
	return m.LevelValueGrowth ^ early * after.Growth ^ math.max(0, level - after.FromLevel)
end

function Formulas.levelIndex(level)
	return Config.Economy.LevelGrowth ^ (math.max(level or 1, 1) - 1)
end

function Formulas.rewardIndex(level)
	local steps = Config.Economy.RewardGrowth
	level = math.max(level or 1, 1)
	local index = 1
	for i, step in ipairs(steps) do
		local upTo = steps[i + 1] and steps[i + 1].FromLevel or math.huge
		local levels = math.min(level, upTo) - step.FromLevel
		if levels > 0 then
			index *= step.Growth ^ levels
		end
	end
	return index
end

-- game money for depositing the bag at this defense level (nil: LV 1): each mineral = grade value × size
-- multiplier × the level multiplier, total rounded
function Formulas.carryValue(carry, level)
	local total, special = 0, 0
	for key, count in pairs(carry) do
		local gradeId, sizeId = Formulas.splitCarryKey(key)
		local grade, size = GRADES[gradeId], SIZES[sizeId]
		if grade and grade.UnitMoney then
			special += count
		elseif grade and size then
			total += count * grade.Value * size.ValueMultiplier
		end
	end
	return math.floor(total * Formulas.mineralLevelMultiplier(level) + special * Formulas.treasureUnitMoney(level) + 0.5)
end

function Formulas.treasureUnitMoney(level)
	return Config.Minerals.Special.UnitMoney * Formulas.rewardIndex(level)
end

-- ---------------------------------------------------------------------------
-- Random picks (r is a random number in [0, 1), so tests can pass fixed values)
-- ---------------------------------------------------------------------------

-- picks one item of list by its weight field, only among items allowed(item) returns true for;
-- scale(i), when given, multiplies the i-th item's weight
function Formulas.pickWeighted(list, weightField, r, allowed, scale)
	local total = 0
	for i, item in ipairs(list) do
		if not allowed or allowed(item) then
			total += item[weightField] * (scale and scale(i) or 1)
		end
	end
	if total <= 0 then
		return nil
	end
	local target = r * total
	local last = nil
	for i, item in ipairs(list) do
		if not allowed or allowed(item) then
			last = item
			target -= item[weightField] * (scale and scale(i) or 1)
			if target < 0 then
				return item
			end
		end
	end
	return last
end

-- how deep into the mineral ring a spot is: 0 at its inner edge (by the key zone), 1 at the flags
function Formulas.mineralDepth(x, z)
	local m = Config.Map
	return math.clamp((math.sqrt(x * x + z * z) - m.MineralRingInner) / (m.MineralRingOuter - m.MineralRingInner), 0, 1)
end

-- (2026-10-01, "rarer and bigger minerals more often further in, but still some outside"): the i-th of n
-- grades (or sizes) weighs bias^((i-1)/(n-1) × (Center - depth)) times its chance: the commonest stays,
-- the rarest is bias times as likely at the inner edge as at the flags; Center keeps the average over
-- the whole ring (the spawn points are spread evenly, so more of them lie outside) what it was
local function depthScale(bias, n, depth)
	if depth == nil or n < 2 then
		return nil
	end
	local center = Config.Minerals.InnerBias.Center
	return function(i)
		return bias ^ ((i - 1) / (n - 1) * (center - depth))
	end
end

-- the grade of a new mineral: only the grades open in this stage, and not a grade already at its
-- MaxOnServer (counts: { [gradeId] = number on the server now }); depth (Formulas.mineralDepth, optional):
-- rarer grades likelier further in
function Formulas.rollGrade(r, counts, depth)
	local grades = Config.Minerals.Grades
	return Formulas.pickWeighted(grades, "ChancePercent", r, function(grade)
		if not table.find(Config.Stage.MineralGrades, grade.Id) then
			return false
		end
		-- (2026-10-04) each grade in its own belt of the ring (Band)
		if depth ~= nil and grade.Band and (depth < grade.Band[1] or depth > grade.Band[2]) then
			return false
		end
		return not grade.MaxOnServer or (counts[grade.Id] or 0) < grade.MaxOnServer
	end, depthScale(Config.Minerals.InnerBias.Grade, #grades, depth))
end

-- depth (optional): bigger sizes likelier further in
function Formulas.rollSize(r, depth)
	local sizes = Config.Minerals.Sizes
	return Formulas.pickWeighted(sizes, "WeightPercent", r, nil, depthScale(Config.Minerals.InnerBias.Size, #sizes, depth))
end

-- worth announcing to the whole server (and marking with a light beam)?
function Formulas.isJackpot(gradeId, sizeId)
	return Formulas.gradeNumber(gradeId) >= Config.Minerals.AnnounceFromGrade or sizeId == Config.Minerals.AnnounceSize
end

-- ---------------------------------------------------------------------------
-- Defense: monsters, rewards, placement, units
-- ---------------------------------------------------------------------------

local SPECIES = index(Config.Species)
for _, s in ipairs(Config.RebirthSpecies) do -- the rebirth-only dinos: looked up like any species, never drawn
	SPECIES[s.Id] = s
end
local GIFT_SPECIES = {} -- [id] = true
for _, s in ipairs(Config.GiftSpecies or {}) do -- (2026-10-04) the gift-only dinos (the launch gift), never drawn
	SPECIES[s.Id] = s
	GIFT_SPECIES[s.Id] = true
end
local THEMES = index(Config.Themes)
local RARITIES = index(Config.Rarities)
local RARITY_PLACE = {} -- [rarity id] = 1 for common, 2 for uncommon, ...
for i, r in ipairs(Config.Rarities) do
	RARITY_PLACE[r.Id] = i
end
for _, r in ipairs(Config.SpecialRarities or {}) do -- (2026-10-04) the given-only ones (⭐ 특별): looked up like any, at their Place
	RARITIES[r.Id] = r
	RARITIES[r.Id .. "#"] = r.Place
	RARITY_PLACE[r.Id] = r.Place
end
local DINO_SIZES = index(Config.Sizes)
local MUTATIONS = index(Config.Mutations.Types)

function Formulas.species(id)
	return SPECIES[id]
end

-- the theme a species rides as: its own, a variant's (Theme "Variant") that of its BaseTheme
local function rideTheme(species)
	return species and (species.Theme == "Variant" and species.BaseTheme or species.Theme)
end

-- can this species be ridden (Config.Ride.NoThemes: the sea dinos don't walk or fly). (2026-10-03, "막아 바다종은
-- 나중에 수영대회같은 업데이트로 열거야": 우주 모사사우루스, a variant of the sea theme, could be ridden on land) by
-- its ride theme, as flies
function Formulas.rideable(speciesId)
	local species = Formulas.species(speciesId)
	return species ~= nil and not table.find(Config.Ride.NoThemes, rideTheme(species))
end

-- a species that flies when ridden (Config.Ride.FlyThemes). (2026-10-03, "변종 익룡도 날 수 있게 고쳐": a variant,
-- Theme "Variant", was looked at by that and never flew, 폭풍 케찰코아틀루스 walked) a variant by its BaseTheme
function Formulas.flies(speciesId)
	local theme = rideTheme(Formulas.species(speciesId))
	return theme ~= nil and table.find(Config.Ride.FlyThemes, theme) ~= nil
end

-- compass angle in degrees (0 = north / -Z, 90 = east / +X) of a point seen from the map center
function Formulas.compassAngle(x, z)
	return math.deg(math.atan2(x, -z)) % 360
end

-- signed change in degrees from angle a to angle b, the short way round (-180..180)
function Formulas.angleStep(a, b)
	return (b - a + 180) % 360 - 180
end

-- (2026-10-02) has a racer finished the lap: all of it counted, or the finish line crossed going forward
-- (from compass angle prev to angle) with at most FinishSlack degrees of the lap not counted
function Formulas.raceFinished(degrees, prev, angle, startBack) -- startBack: the start row's (default StartBack)
	local c = Config.Race
	local lap = 360 + (startBack or c.StartBack)
	if degrees >= lap then
		return true
	end
	if not prev or degrees < lap - c.FinishSlack then
		return false
	end
	local step = Formulas.angleStep(prev, angle)
	local toLine = Formulas.angleStep(prev, c.FinishAngle)
	return step > 0 and toLine > 0 and toLine <= step
end

function Formulas.raceMedalTarget(kind, i, ideal)
	local m = Config.Race.Medals[kind] and Config.Race.Medals[kind][i]
	if not m then
		return nil
	end
	return m.Seconds or (ideal or 0) * m.Factor
end

function Formulas.raceMedal(kind, seconds, ideal)
	local best = 0
	for i in ipairs(Config.Race.Medals[kind] or {}) do
		if seconds <= Formulas.raceMedalTarget(kind, i, ideal) then
			best = i
		end
	end
	return best
end

-- a race lap's progress (0..1) from the degrees gone round since the start box
function Formulas.raceProgress(degrees, startBack)
	local c = Config.Race
	return math.clamp(degrees / (360 + (startBack or c.StartBack)), 0, 1)
end

-- a point on the track: compass angle a (degrees), `across` studs outward from the road's middle line
local function trackPoint(a, across)
	local r, rad = Config.Race.Radius + across, math.rad(a)
	return math.sin(rad) * r, -math.cos(rad) * r
end

-- (2026-10-01) the sky race's course (Config.Race.Sky): from a start point at a random angle round the map,
-- Rings yellow rings about evenly round it (each a little off, at a random distance from the center and
-- height over the ground), then the red one back at the start. rand() gives 0..1. Returns { Start = { x, z,
-- h }, Rings = { { x, z, h }, ... } } (h: studs over the ground, the server finds the ground)
function Formulas.skyCourse(rand)
	local s = Config.Race.Sky
	local function at(angle, r, h)
		local rad = math.rad(angle)
		return { math.sin(rad) * r, -math.cos(rad) * r, h }
	end
	local a0 = rand() * 360
	local startR = (s.InnerRadius + s.OuterRadius) / 2
	local step = 360 / (s.Rings + 1)
	local rings = {}
	-- (2026-10-01) a zigzag: each ring at least MinRadiusStep in or out and MinHeightStep up or down from the
	-- one before, the way picked at random (the other way when there is no room)
	local function away(from, lo, hi, least)
		local up = rand() < 0.5
		if up and from + least > hi then
			up = false
		elseif not up and from - least < lo then
			up = true
		end
		if up then
			return math.min(hi, from + least + rand() * math.max(0, hi - from - least))
		end
		return math.max(lo, from - least - rand() * math.max(0, from - least - lo))
	end
	local r, h = startR, s.StartHeight
	for k = 1, s.Rings do
		local a = a0 + step * k + (rand() * 2 - 1) * s.AngleJitter
		r = away(r, s.InnerRadius, s.OuterRadius, s.MinRadiusStep)
		-- (over the bases: high enough to clear them)
		h = away(h, r < s.BaseClearRadius and s.BaseClearHeight or s.MinHeight, s.MaxHeight, s.MinHeightStep)
		table.insert(rings, at(a, r, h))
	end
	table.insert(rings, at(a0, startR, s.StartHeight)) -- the red one: back where they started
	return { Start = at(a0, startR, s.StartHeight), Rings = rings }
end

function Formulas.skyLoop(rand, cx, cz)
	local s, t = Config.Race.Sky, Config.Race.TutorialSky
	local a0 = rand() * 360
	local function at(angle, h)
		local rad = math.rad(angle)
		return { cx + math.sin(rad) * t.Radius, cz - math.cos(rad) * t.Radius, h }
	end
	local rings = {}
	for k = 1, t.Rings do
		table.insert(rings, at(a0 + 360 * k / (t.Rings + 1), k % 2 == 1 and t.High or t.Low))
	end
	table.insert(rings, at(a0, s.StartHeight))
	return { Start = at(a0, s.StartHeight), Rings = rings }
end

-- (2026-10-01, "속도 발판 ... 세워서 가야하는 경로에 랜덤적으로") the sky race's boost pads: standing up
-- across the way between the course's points (points = { {x, y, z}, ... }: the start, then each ring, in
-- the world), Sky.PadsPerLeg on each leg, somewhere along it (Sky.PadAlong of the way) and up to
-- Sky.PadOffset studs off the straight line (sideways and up or down), some yellow (Sky.YellowChance).
-- Returns { { x, y, z, "Purple" | "Yellow", dx, dy, dz }, ... }: (dx, dy, dz) the leg's way, the way the
-- pad faces. rand() gives 0..1.
function Formulas.skyPads(rand, points)
	local s = Config.Race.Sky
	local pads = {}
	for k = 2, #points do
		local a, b = points[k - 1], points[k]
		local dx, dy, dz = b[1] - a[1], b[2] - a[2], b[3] - a[3]
		local len = math.sqrt(dx * dx + dy * dy + dz * dz)
		local flatLen = math.sqrt(dx * dx + dz * dz)
		if len > 0 and flatLen > 0 then
			dx, dy, dz = dx / len, dy / len, dz / len
			local sx, sz = -dz * len / flatLen, dx * len / flatLen -- sideways (flat, square to the way)
			local count = s.PadsPerLeg[1] + math.floor(rand() * (s.PadsPerLeg[2] - s.PadsPerLeg[1] + 1))
			count = math.min(count, s.PadsPerLeg[2])
			for n = 1, count do
				-- each pad in its own share of the leg's middle part, so two on one leg don't sit together
				local lo = s.PadAlong[1] + (s.PadAlong[2] - s.PadAlong[1]) * (n - 1) / count
				local hi = s.PadAlong[1] + (s.PadAlong[2] - s.PadAlong[1]) * n / count
				local t = lo + rand() * (hi - lo)
				local side = (rand() * 2 - 1) * s.PadOffset
				local up = (rand() * 2 - 1) * s.PadOffset
				table.insert(pads, {
					a[1] + (b[1] - a[1]) * t + sx * side,
					a[2] + (b[2] - a[2]) * t + up,
					a[3] + (b[3] - a[3]) * t + sz * side,
					rand() < s.YellowChance and "Yellow" or "Purple",
					dx, dy, dz,
				})
			end
		end
	end
	return pads
end

-- obstacle shapes: across (studs across the road), along (studs along it), height, and where across
-- the road it may stand ("edge": against one edge, "any", "full": the whole road). Moving ones swing or
-- spin on the racers' screens (the server does not hold racers out of them: being hit is the penalty)
local OBSTACLES = {
	{ Kind = "Crate", Across = 6, Along = 6, Height = 8, Place = "any" },
	{ Kind = "Pillar", Across = 5, Along = 5, Height = 14, Place = "any" },
	{ Kind = "Wall", Across = 12, Along = 2, Height = 10, Place = "edge" },
	{ Kind = "Cones", Across = 10, Along = 2.5, Height = 8, Place = "edge" },
	{ Kind = "Barrels", Across = 9, Along = 5, Height = 4, Place = "any" }, -- a heap of barrels
	{ Kind = "Swing", Across = 20, Along = 3, Height = 14, Place = "full", Moving = true }, -- a hammer swinging across
	{ Kind = "Spinner", Across = 16, Along = 16, Height = 2.2, Place = "full", Moving = true }, -- a low bar turning: jump it
}
-- the jump sections' hurdles: a low bar right across the road, jumped over (no way round)
local HURDLE = { Kind = "Hurdle", Across = 20, Along = 1.5, Height = Config.Race.HurdleHeight, Place = "full" }
Formulas.RACE_OBSTACLES = OBSTACLES
Formulas.RACE_HURDLE = HURDLE

-- one race's layout: pads { { x, z, "Purple" | "Yellow" }, ... }, obstacles
-- { { x, z, kind, across, along, height, angle, moving }, ... } and the jump sections' mud
-- { { fromAngle, toAngle }, ... } (degrees, from < to, may pass 360), at random (rand() gives 0..1). Obstacles keep clear
-- of the start and finish, stay ObstacleGapDegrees apart and leave MinGap of road free; pads keep clear of
-- the finish line and of obstacles; purple pads come in short runs, yellow ones alone.
-- (2026-10-01) is (x, z) within margin studs of obstacle o? A standing one by its box along and across the
-- road (o[7] its angle), a moving one by the circle it sweeps
function Formulas.raceNearObstacle(o, x, z, margin)
	local dx, dz = x - o[1], z - o[2]
	if o[8] then
		local reach = math.max(o[4], o[5]) / 2 + margin
		return dx * dx + dz * dz < reach * reach
	end
	local a = math.rad(o[7])
	local tx, tz = math.cos(a), math.sin(a) -- along the road (the compass angle going up)
	local along = math.abs(dx * tx + dz * tz)
	local across = math.abs(dx * tz - dz * tx)
	return along < o[5] / 2 + margin and across < o[4] / 2 + margin
end

function Formulas.raceLayout(rand)
	local c = Config.Race
	local half = c.Width / 2
	local obstacles = {}
	local used = {} -- angles of the obstacles placed
	local first, last = c.FinishAngle - c.StartBack + c.ObstacleKeepOff, c.FinishAngle + 360 - c.ObstacleKeepOff
	-- jump sections first (long: the rest fit round them): a few hurdles in a row right across the road
	local sections, sectionTries = 0, 0
	local mud = {}
	local span = (c.JumpHurdles - 1) * c.JumpSpacingDegrees
	while sections < c.JumpSections and sectionTries < c.JumpSections * 30 do
		sectionTries += 1
		local a = first + rand() * (last - first - span)
		local clear = true
		for _, b in ipairs(used) do
			local d = Formulas.angleStep(a, b)
			if d > -c.ObstacleGapDegrees and d < span + c.ObstacleGapDegrees then
				clear = false
				break
			end
		end
		if clear then
			sections += 1
			table.insert(mud, { a - c.MudLeadDegrees, a + span + c.MudLeadDegrees })
			for k = 0, c.JumpHurdles - 1 do
				local at = a + k * c.JumpSpacingDegrees
				local x, z = trackPoint(at, 0)
				table.insert(obstacles, { x, z, HURDLE.Kind, c.Width, HURDLE.Along, HURDLE.Height, at % 360, false })
				table.insert(used, at)
			end
		end
	end
	local function offMud(span) -- a random angle whose next span degrees keep off the mud
		local a = rand() * 360
		for _ = 1, 10 do
			if not Formulas.inRaceMud(mud, a) and not Formulas.inRaceMud(mud, a + span) then
				break
			end
			a = rand() * 360
		end
		return a
	end
	-- (2026-10-01, "장애물 더 추가": with obstacles every 20 studs no room was left for pads) the pads'
	-- places first; obstacles keep PadClearDegrees off them
	local padAngles = {} -- { { angle, kind }, ... }
	for _ = 1, c.PurpleRuns do
		local start = offMud(c.PurpleRunDegrees)
		local n = c.PurplePerRun[1] + math.floor(rand() * (c.PurplePerRun[2] - c.PurplePerRun[1] + 1))
		for k = 0, n - 1 do
			table.insert(padAngles, { start + (n > 1 and k / (n - 1) or 0) * c.PurpleRunDegrees, "Purple" })
		end
	end
	for _ = 1, c.YellowCount do
		table.insert(padAngles, { offMud(0), "Yellow" })
	end
	-- (2026-10-01, "where did the spinning one go") the moving ones first, at least MinMovers of each, so every
	-- race has them; the rest at random
	local forced = {}
	for _, kind in ipairs({ "Spinner", "Swing" }) do
		for _ = 1, (c.MinMovers and c.MinMovers[kind]) or 0 do
			for _, shape in ipairs(OBSTACLES) do
				if shape.Kind == kind then
					table.insert(forced, shape)
				end
			end
		end
	end
	local tries = 0
	while #obstacles < c.ObstacleCount and tries < c.ObstacleCount * 20 do
		tries += 1
		local a = first + rand() * (last - first)
		local clear = not Formulas.inRaceMud(mud, a) -- (the jump sections hold only their hurdles)
		for _, pad in ipairs(padAngles) do
			if math.abs(Formulas.angleStep(a, pad[1])) < c.PadClearDegrees then
				clear = false
			end
		end
		for _, b in ipairs(used) do
			if math.abs(Formulas.angleStep(a, b)) < c.ObstacleGapDegrees then
				clear = false
				break
			end
		end
		if clear then
			local shape = forced[1] or OBSTACLES[math.min(#OBSTACLES, math.floor(rand() * #OBSTACLES) + 1)]
			local across = shape.Place == "full" and math.min(shape.Across, c.Width) or math.min(shape.Across, c.Width - c.MinGap)
			local center
			if shape.Place == "full" then -- right in the middle: no lane round it
				center = 0
			elseif shape.Place == "edge" then -- against the inner or the outer edge
				center = (rand() < 0.5 and -1 or 1) * (half - across / 2)
			else -- anywhere, as long as the wider side keeps a MinGap lane free
				local hi = half - across / 2
				local lo = math.clamp(c.MinGap - hi, 0, hi)
				center = (rand() < 0.5 and -1 or 1) * (lo + rand() * (hi - lo))
			end
			local x, z = trackPoint(a, center)
			table.insert(obstacles, { x, z, shape.Kind, across, shape.Along, shape.Height, a % 360, shape.Moving == true })
			table.insert(used, a)
			if forced[1] == shape then
				table.remove(forced, 1)
			end
		end
	end
	local pads = {}
	local function free(x, z)
		for _, o in ipairs(obstacles) do
			if Formulas.raceNearObstacle(o, x, z, c.PadRadius + c.PadObstacleGap) then
				return false
			end
		end
		return true
	end
	local function addPad(a, kind)
		-- (none by the line, nor behind it where the start rows are: StartSlots, 2026-10-02)
		local fromLine = Formulas.angleStep(c.FinishAngle, a)
		local behind = math.max(c.PadKeepOff, c.StartBack + (c.StartSlots - 1) * c.StartSlotGap + 1)
		if (fromLine <= c.PadKeepOff and fromLine >= -behind) or Formulas.inRaceMud(mud, a) then
			return
		end
		for _ = 1, 6 do -- a few spots across the road, the first one clear of the obstacles
			local x, z = trackPoint(a, (rand() * 2 - 1) * (half - c.PadRadius - 1))
			if free(x, z) then
				table.insert(pads, { x, z, kind })
				return
			end
		end
	end
	for _, pad in ipairs(padAngles) do
		addPad(pad[1], pad[2])
	end
	return pads, obstacles, mud
end

-- is this compass angle (degrees) in one of the jump sections' mud (Formulas.raceLayout)?
function Formulas.inRaceMud(mud, angle)
	for _, m in ipairs(mud or {}) do
		local from = Formulas.angleStep(m[1], angle)
		if from >= 0 and from <= m[2] - m[1] then
			return true
		end
	end
	return false
end

-- the moving race obstacles at server time t, the same on the server (hits) and the racers' screens:
-- a hammer's swing (radians either way of straight down, across the road) and a spinner's turn (radians)
function Formulas.raceSwingAngle(o, t)
	local s = Config.Race.Swing
	return math.sin(t / s.Period * 2 * math.pi + o[7] * 0.37) * math.rad(s.Angle) -- each to its own beat
end

function Formulas.raceSpinAngle(o, t)
	-- kept within one turn (2026-10-01, "the spinning one doesn't spin"): server time is about 1.7 billion
	-- seconds, and a CFrame keeps its angle in single precision, which at billions of radians only moves in
	-- steps of hundreds: the bar stood still on the screens while the server's turned
	return (t * math.rad(Config.Race.Spinner.Speed) + math.rad(o[7])) % (2 * math.pi)
end

-- which moving obstacle (index), if any, touches a racer at server time t: pos the racer's flat position,
-- feet the height of their dino's feet. A hammer: its head, hanging from its beam at the obstacle's
-- height; a spinner: its bar turning flat just under the obstacle's height (jumped over, it misses).
function Formulas.raceMoverHit(list, pos, feet, roadTop, t)
	local c = Config.Race
	local r, tall = c.RacerRadius, c.RacerHeight
	for i, o in ipairs(list or {}) do
		if o[8] then
			local a = math.rad(o[7])
			local dx, dz = pos.X - o[1], pos.Z - o[2]
			local lat, along = -dx * math.sin(a) + dz * math.cos(a), dx * math.cos(a) + dz * math.sin(a)
			if o[3] == "Swing" then
				local head = c.Swing.Head
				local reach = o[6] - 0.9 -- the beam down to the head's middle
				local swing = Formulas.raceSwingAngle(o, t)
				local headLat, headY = reach * math.sin(swing), roadTop + o[6] - reach * math.cos(swing)
				if math.abs(lat - headLat) < head[1] / 2 + r and math.abs(along) < head[3] / 2 + r
					and feet < headY + head[2] / 2 and feet + tall > headY - head[2] / 2 then
					return i
				end
			elseif o[3] == "Spinner" then
				local turn = Formulas.raceSpinAngle(o, t)
				local cosT, sinT = math.cos(turn), math.sin(turn)
				local onBar = lat * cosT + along * sinT
				local offBar = math.abs(-lat * sinT + along * cosT)
				local near = c.Spinner.HitRadius
				if math.abs(onBar) < o[4] / 2 + near and offBar < c.Spinner.Bar / 2 + near and feet < roadTop + o[6] then
					return i
				end
			end
		end
	end
	return nil
end

function Formulas.theme(id)
	return THEMES[id]
end

function Formulas.rarity(id)
	return RARITIES[id]
end

-- a given-only rarity (Config.SpecialRarities: ⭐ 특별): never drawn, merged or collected
function Formulas.specialRarity(id)
	local r = RARITIES[id]
	return r ~= nil and r.Place ~= nil
end

-- is this rarity in the draw at this real defense level? its awakenings (UnlockRebirths) done: the level's tier
-- (2026-10-02, "각 각성마다 등급이 해금되게하자 각성 레벨제한꺼지 두지말고": was a level each)
function Formulas.rarityOpen(r, level)
	return Formulas.tierOfLevel(level) >= (r.UnlockRebirths or 0)
end

-- how much of its chance a rarity has at this level: the awakenings since the one that opened it pick
-- Config.Gacha.NewRarityScale (the one that opened it: [1], the next: [2], ...), 1 after the list and for
-- the rarities open from the start (2026-10-02, "각 각성 등급에 맞게 조절해 높은 급의 공룡 확률도")
function Formulas.newRarityScale(r, level)
	local n = r.UnlockRebirths or 0
	if n <= 0 then
		return 1
	end
	return Config.Gacha.NewRarityScale[Formulas.tierOfLevel(level) - n + 1] or 1
end

-- when a rarity opens, in words: "처음부터", or the awakening with its mark ("🟢각성 1회", "🔵각성 2회")
function Formulas.rarityCondition(r)
	local n = r.UnlockRebirths or 0
	if n <= 0 then
		return "처음부터"
	end
	return string.format("%s환생 %d번", Formulas.rebirthMark(n), n)
end

function Formulas.rebirthMark(n)
	local marks = Config.Rebirth.TierMarks
	return marks[math.clamp((n or 0) + 1, 1, #marks)]
end

-- (2026-10-02, "이 표를 명시해놔야지 나도 햇갈리네 뽑기할 때 명시되게 도감에도") every rarity with when it opens
-- for the draw: { Id, Name, Open (at this real defense level), Condition (Formulas.rarityCondition), Scale
-- (its share of its chance now, Formulas.newRarityScale) }, the
-- commonest first; and the next one still locked (or nil)
function Formulas.rarityUnlocks(level)
	local list, nextLocked = {}, nil
	for _, r in ipairs(Config.Rarities) do
		local open = Formulas.rarityOpen(r, level)
		table.insert(list, { Id = r.Id, Name = r.Name, Open = open, Condition = Formulas.rarityCondition(r),
			Scale = open and Formulas.newRarityScale(r, level) or 1 })
		if not open and not nextLocked then
			nextLocked = list[#list]
		end
	end
	return list, nextLocked
end

-- one rarity's line in the tables: "✅ 황금 · 🟢각성 1회 · 지금 확률 ×2%"
function Formulas.rarityUnlockLine(u)
	local line = string.format("%s %s · %s", u.Open and "✅" or "🔒", u.Name, u.Condition)
	if u.Open and u.Scale < 1 then
		line ..= string.format(" · 지금 확률 ×%g%%", math.floor(u.Scale * 1000 + 0.5) / 10)
	end
	return line
end

-- the share rule in words (Config.Gacha.NewRarityScale)
function Formulas.newRarityRuleText()
	local s = Config.Gacha.NewRarityScale
	return string.format("🆕 막 열린 등급은 처음엔 드물어요: 이번 환생 ×%g%% → 다음 ×%g%% → 그 뒤 100%%",
		math.floor((s[1] or 1) * 1000 + 0.5) / 10, math.floor((s[2] or 1) * 1000 + 0.5) / 10)
end

-- the rarities a rebirth into this many awakenings opens (their names), the commonest first
function Formulas.raritiesOpenedBy(rebirths)
	local names = {}
	for _, r in ipairs(Config.Rarities) do
		if (r.UnlockRebirths or 0) == rebirths then
			table.insert(names, r.Name)
		end
	end
	return names
end

-- (2026-10-02) the species an awakening opens for the draw (their names)
function Formulas.speciesOpenedBy(rebirths)
	local names = {}
	for _, s in ipairs(Config.Species) do
		if s.UnlockRebirths == rebirths then
			table.insert(names, s.Name)
		end
	end
	return names
end

-- a rarity's place from the commonest (1 = Common), 0 when unknown
function Formulas.rarityRank(id)
	return RARITIES[tostring(id) .. "#"] or 0
end

function Formulas.chatFind(id)
	return Formulas.rarityRank(id) >= Formulas.rarityRank(Config.Gacha.ChatFromRarity)
end

function Formulas.dinoSize(id)
	return DINO_SIZES[id]
end

function Formulas.dinoSizeRank(id)
	return DINO_SIZES[tostring(id) .. "#"] or 0
end

function Formulas.mutation(id)
	return MUTATIONS[id]
end

-- key price = 50 × 1.035^(LV − 1)
function Formulas.keyPrice(level)
	return Config.Keys.PriceBase * Config.Keys.PriceGrowth ^ (level - 1)
end

-- the promotion boss's health, × a normal monster's at that level: HealthMultiplier at LV 1, then
-- HealthMultiplierPerLevel more each level, at most HealthMultiplierMax (harder the higher you go)
-- (2026-10-01, "just reset the fossils' level on a rebirth, so players understand") the fossils go by the level
-- within the tier (a reborn LV 1 meets LV 1 fossils), × Config.Rebirth.MonsterHealthPerTier for each tier;
-- rewards, keys and rarity unlocks still go by the real level. A real level always tells its tier.
-- the rebirth tiers (Config.Rebirth): the first FirstTierLevels long, the rest LevelsPerTier each
local function tierStart(tier) -- the real level a tier starts at
	local r = Config.Rebirth
	return tier <= 0 and 1 or r.FirstTierLevels + (tier - 1) * r.LevelsPerTier + 1
end
local function tierOf(level) -- the tier a real level is in
	local r = Config.Rebirth
	return level <= r.FirstTierLevels and 0 or 1 + (level - r.FirstTierLevels - 1) // r.LevelsPerTier
end
Formulas.tierStart = tierStart

local function fossilLevel(level)
	local tier = tierOf(math.max(level, 1))
	return level - tierStart(tier) + 1, tier
end

function Formulas.bossHealthMultiplier(level)
	local b = Config.Defense.Boss
	level = fossilLevel(level)
	return math.min(b.HealthMultiplierMax, b.HealthMultiplier + b.HealthMultiplierPerLevel * (math.max(level, 1) - 1))
end

-- monster health = HealthBase × 1.035^(LV − 1), × HealthGrowthAfter a level past HealthGrowthAfterLevel,
-- × HardGrowth from HardFromLevel to HardUntilLevel; by the level within the tier, × MonsterHealthPerTier a tier
function Formulas.monsterHealth(realLevel)
	local m = Config.Monsters
	local level, tier = fossilLevel(realLevel)
	local upTo = math.min(level, m.HealthGrowthAfterLevel)
	local health = m.HealthBase * m.HealthGrowth ^ (upTo - 1)
	if level > m.HealthGrowthAfterLevel then
		health *= m.HealthGrowthAfter ^ (level - m.HealthGrowthAfterLevel)
	end
	if level >= m.HardFromLevel then -- tougher again from the middle levels (the farm helps here)
		health *= m.HardGrowth ^ (math.min(level, m.HardUntilLevel) - m.HardFromLevel + 1)
	end
	return health * Formulas.tierHealthMultiplier(tier)
end

-- (2026-10-02) ♾️ 무한 도전: a fossil's health in this wave (Config.Defense.Challenge)
function Formulas.challengeHealth(wave)
	local c = Config.Defense.Challenge
	return c.HealthStart * c.HealthGrowth ^ (math.max(1, wave) - 1)
end

-- (2026-10-02) this week's ♾️ challenge rule (Config.Defense.Challenge.Rules; week: RewardLogic.weekNumber)
function Formulas.challengeRule(week)
	local rules = Config.Defense.Challenge.Rules
	return rules[week % #rules + 1]
end

function Formulas.challengeRuleById(id)
	for _, r in ipairs(Config.Defense.Challenge.Rules) do
		if r.Id == id then
			return r
		end
	end
	return nil
end

-- a fossil kind (Config.Defense.Kinds) by its Id
function Formulas.fossilKind(id)
	for _, k in ipairs(Config.Defense.Kinds) do
		if k.Id == id then
			return k
		end
	end
	return nil
end

local MAPS = index(Config.Defense.Maps)
local PATHS = {}
local CORNER_STEPS = 6
local COVER_STEP = 2.5
local COVER_CELL = 8
local NO_SAMPLES = {}
local GRID_STEP = 2

function Formulas.defenseMap(id)
	return MAPS[id] or Config.Defense.Maps[1]
end

function Formulas.mapUnlockLevel(map)
	return Formulas.tierStart(map.Rebirths) + (map.Level or 1) - 1
end

local function mapIsOpen(m, rebirths, level)
	return (rebirths or 0) >= m.Rebirths and (level or 1) >= Formulas.mapUnlockLevel(m)
end

function Formulas.mapsOpen(rebirths, level)
	local list = {}
	for _, m in ipairs(Config.Defense.Maps) do
		if mapIsOpen(m, rebirths, level) then
			table.insert(list, m)
		end
	end
	return list
end

function Formulas.newestMap(rebirths)
	local newest = Config.Defense.Maps[1]
	for _, m in ipairs(Config.Defense.Maps) do
		if not m.Level and (rebirths or 0) >= m.Rebirths then
			newest = m
		end
	end
	return newest
end

function Formulas.mapOpen(id, rebirths, level)
	local m = MAPS[id]
	return m ~= nil and mapIsOpen(m, rebirths, level)
end

function Formulas.mapFirstWin(map)
	local prize = nil
	for _, row in ipairs(Config.Defense.MapFirstWin) do
		if map.Rebirths >= row.Rebirths then
			prize = row
		end
	end
	return prize
end

function Formulas.mapsOpenedAt(level)
	local list = {}
	for _, m in ipairs(Config.Defense.Maps) do
		if m.Level and Formulas.mapUnlockLevel(m) == level then
			table.insert(list, m)
		end
	end
	return list
end

local function roundedPoints(map)
	local pts = map.Points
	local out = { { pts[1][1], pts[1][2] } }
	for i = 2, #pts - 1 do
		local p0, p1, p2 = pts[i - 1], pts[i], pts[i + 1]
		local ax, az = p1[1] - p0[1], p1[2] - p0[2]
		local bx, bz = p2[1] - p1[1], p2[2] - p1[2]
		local la, lb = math.sqrt(ax * ax + az * az), math.sqrt(bx * bx + bz * bz)
		local c = math.min(map.Corner or 0, la / 2, lb / 2)
		local sx, sz = p1[1] - ax / la * c, p1[2] - az / la * c
		local ex, ez = p1[1] + bx / lb * c, p1[2] + bz / lb * c
		for k = 0, CORNER_STEPS do
			local t = k / CORNER_STEPS
			local u = 1 - t
			table.insert(out, { u * u * sx + 2 * u * t * p1[1] + t * t * ex, u * u * sz + 2 * u * t * p1[2] + t * t * ez })
		end
	end
	table.insert(out, { pts[#pts][1], pts[#pts][2] })
	return out
end

function Formulas.lanePath(id)
	local map = Formulas.defenseMap(id)
	local cached = PATHS[map.Id]
	if cached then
		return cached
	end
	local raw = roundedPoints(map)
	local path = { Id = map.Id, map = map, x = {}, z = {}, s = {}, length = 0 }
	for i, p in ipairs(raw) do
		if i > 1 then
			local dx, dz = p[1] - path.x[#path.x], p[2] - path.z[#path.z]
			local d = math.sqrt(dx * dx + dz * dz)
			if d > 1e-6 then
				path.length += d
				table.insert(path.x, p[1])
				table.insert(path.z, p[2])
				table.insert(path.s, path.length)
			end
		else
			table.insert(path.x, p[1])
			table.insert(path.z, p[2])
			table.insert(path.s, 0)
		end
	end
	PATHS[map.Id] = path
	return path
end

function Formulas.lanePoint(path, s, offset)
	local n = #path.s
	s = math.clamp(s, 0, path.length)
	local lo, hi = 1, n
	while hi - lo > 1 do
		local mid = (lo + hi) // 2
		if path.s[mid] <= s then
			lo = mid
		else
			hi = mid
		end
	end
	local x0, z0, x1, z1 = path.x[lo], path.z[lo], path.x[hi], path.z[hi]
	local len = path.s[hi] - path.s[lo]
	local t = len > 0 and (s - path.s[lo]) / len or 0
	local tx, tz = (x1 - x0) / math.max(len, 1e-6), (z1 - z0) / math.max(len, 1e-6)
	local o = offset or 0
	return x0 + (x1 - x0) * t + tz * o, z0 + (z1 - z0) * t - tx * o, tx, tz
end

function Formulas.lanePointNear(path, s, offset, hint)
	local ps = path.s
	local n = #ps
	s = math.clamp(s, 0, path.length)
	local lo = math.clamp(hint or 1, 1, n - 1)
	while lo > 1 and ps[lo] > s do
		lo -= 1
	end
	while lo < n - 1 and ps[lo + 1] <= s do
		lo += 1
	end
	local hi = lo + 1
	local x0, z0, x1, z1 = path.x[lo], path.z[lo], path.x[hi], path.z[hi]
	local len = ps[hi] - ps[lo]
	local t = len > 0 and (s - ps[lo]) / len or 0
	local tx, tz = (x1 - x0) / math.max(len, 1e-6), (z1 - z0) / math.max(len, 1e-6)
	local o = offset or 0
	return x0 + (x1 - x0) * t + tz * o, z0 + (z1 - z0) * t - tx * o, lo
end

function Formulas.laneDistance(path, x, z)
	local best, bestS = math.huge, 0
	for i = 1, #path.s - 1 do
		local x0, z0 = path.x[i], path.z[i]
		local dx, dz = path.x[i + 1] - x0, path.z[i + 1] - z0
		local len2 = dx * dx + dz * dz
		local t = len2 > 0 and math.clamp(((x - x0) * dx + (z - z0) * dz) / len2, 0, 1) or 0
		local px, pz = x0 + dx * t - x, z0 + dz * t - z
		local d = px * px + pz * pz
		if d < best then
			best, bestS = d, path.s[i] + (path.s[i + 1] - path.s[i]) * t
		end
	end
	return math.sqrt(best), bestS
end

function Formulas.bossPathLength()
	local D = Config.Defense
	return D.BossSpeed * (D.Promotion.Duration - D.Promotion.BossAppearsAt)
end

function Formulas.speedUp(level, boss)
	local s = Config.Defense.SpeedUp
	level = fossilLevel(level)
	local ramp = if boss then math.clamp((level - s.BossFromLevel) / s.BossLevels, 0, 1)
		else math.clamp((level - s.FromLevel) / s.Levels, 0, 1)
	return 1 + ((boss and s.Boss or s.Fossils) - 1) * ramp
end

function Formulas.bossSpeed(level)
	return Config.Defense.BossSpeed * Formulas.speedUp(level, true)
end

local COVER = {}
local function coverSamples(path)
	local list = COVER[path.Id]
	if list then
		return list
	end
	list = { cells = {} }
	local n = math.max(1, math.floor(path.length / COVER_STEP))
	local bossLength = Formulas.bossPathLength()
	for i = 0, n - 1 do
		local s = (i + 0.5) / n * path.length
		local x, z = Formulas.lanePoint(path, s, 0)
		local p = { x, z, s <= bossLength, (i + 0.5) / n }
		table.insert(list, p)
		local key = math.floor(x / COVER_CELL) * 1000 + math.floor(z / COVER_CELL)
		list.cells[key] = list.cells[key] or {}
		table.insert(list.cells[key], p)
	end
	list.boss = 0
	for _, p in ipairs(list) do
		list.boss += p[3] and 1 or 0
	end
	COVER[path.Id] = list
	return list
end

-- (2026-10-02, "디펜스 전략의 재미" → 배치 도움; 2026-10-06 the map's road) a dino at (x, z) of an arena's flat frame with
-- this reach: the share of the road it reaches (0-1), and the share of the promotion boss's way it reaches
function Formulas.trackCoverage(x, z, reach, mapId)
	local samples = coverSamples(Formulas.lanePath(mapId))
	local r = reach + Config.Defense.MonsterRadius
	local limit = r * r
	local track, boss = 0, 0
	for cx = math.floor((x - r) / COVER_CELL), math.floor((x + r) / COVER_CELL) do
		for cz = math.floor((z - r) / COVER_CELL), math.floor((z + r) / COVER_CELL) do
			for _, p in ipairs(samples.cells[cx * 1000 + cz] or NO_SAMPLES) do
				local dx, dz = p[1] - x, p[2] - z
				if dx * dx + dz * dz <= limit then
					track += 1
					boss += p[3] and 1 or 0
				end
			end
		end
	end
	return track / math.max(1, #samples), boss / math.max(1, samples.boss)
end

local function roadWeight(mapId)
	return Formulas.defenseMap(mapId).RoadWeight or Config.Recommend.EndWeight
end

local function roadValue(x, z, reach, mapId)
	local samples = coverSamples(Formulas.lanePath(mapId))
	local r = reach + Config.Defense.MonsterRadius
	local limit = r * r
	local weight = roadWeight(mapId)
	local total = 0
	for cx = math.floor((x - r) / COVER_CELL), math.floor((x + r) / COVER_CELL) do
		for cz = math.floor((z - r) / COVER_CELL), math.floor((z + r) / COVER_CELL) do
			for _, p in ipairs(samples.cells[cx * 1000 + cz] or NO_SAMPLES) do
				local dx, dz = p[1] - x, p[2] - z
				if dx * dx + dz * dz <= limit then
					total += 1 + weight * p[4]
				end
			end
		end
	end
	return total / math.max(1, #samples)
end
Formulas.roadValue = roadValue

-- every grid point of the field with its distance to the road and to the nearer gate, once a map
local GRIDS = {}
local function fieldGrid(mapId)
	local grid = GRIDS[mapId]
	if grid then
		return grid
	end
	grid = {}
	local b = Config.Defense.MapBounds
	local path = Formulas.lanePath(mapId)
	local n = #path.x
	for x = -b.X, b.X, GRID_STEP do
		for z = b.ZFront, b.ZBack, GRID_STEP do
			local gate = math.huge
			for _, i in ipairs({ 1, n }) do
				local dx, dz = x - path.x[i], z - path.z[i]
				gate = math.min(gate, math.sqrt(dx * dx + dz * dz))
			end
			table.insert(grid, { x, z, (Formulas.laneDistance(path, x, z)), gate })
		end
	end
	GRIDS[mapId] = grid
	return grid
end

local SPOTS = {}
function Formulas.layoutSpots(mapId, reach, footprint)
	local map = Formulas.defenseMap(mapId)
	local key = map.Id .. ":" .. math.floor(reach * 4 + 0.5) .. ":" .. math.floor(footprint * 4 + 0.5)
	local list = SPOTS[key]
	if list then
		return list
	end
	list = {}
	local D = Config.Defense
	local b = D.MapBounds
	local near, gateClear = D.TrackHalfWidth + footprint, D.GateClear + D.TrackHalfWidth + footprint
	local nestReach = reach * (1 + D.Rocks.Nest.ReachBonus)
	for _, g in ipairs(fieldGrid(map.Id)) do
		local x, z = g[1], g[2]
		local here = Formulas.nestAt(map.Id, x, z, footprint) and nestReach or reach
		if g[3] >= near and g[3] <= here + D.MonsterRadius and g[4] >= gateClear and math.abs(x) + footprint <= b.X
			and z - footprint >= b.ZFront and z + footprint <= b.ZBack and not Formulas.pondAt(map.Id, x, z, footprint)
			and not Formulas.rockAt(map.Id, x, z, footprint) then
			local track, boss = Formulas.trackCoverage(x, z, here, map.Id)
			if track > 0 then
				table.insert(list, { x, z, track + boss, track })
			end
		end
	end
	table.sort(list, function(a, b2)
		return a[3] > b2[3]
	end)
	if map.Perches then
		local kept = {}
		for _, p in ipairs(list) do
			if not Formulas.perchAt(map.Id, p[1], p[2], footprint) then
				table.insert(kept, p)
			end
		end
		list = kept
	end
	SPOTS[key] = list
	return list
end

-- the placing window's "efficiency": the road this spot reaches against the best spot on this map for the same dino, 0-1
local BEST_VALUE = {}
function Formulas.spotEfficiency(x, z, reach, footprint, mapId)
	local key = Formulas.defenseMap(mapId).Id .. ":" .. math.floor(reach * 4 + 0.5) .. ":" .. math.floor(footprint * 4 + 0.5)
	local best = BEST_VALUE[key]
	if not best then
		best = 0
		for _, p in ipairs(Formulas.layoutSpots(mapId, reach, footprint)) do
			best = math.max(best, roadValue(p[1], p[2], reach, mapId))
		end
		BEST_VALUE[key] = best
	end
	return best > 0 and math.min(1, roadValue(x, z, reach, mapId) / best) or 0
end

function Formulas.pickTeam(ranked, slots, mapId)
	local team, sea = {}, 0
	local ponds = #(Formulas.defenseMap(mapId).Ponds or {})
	for _, u in ipairs(ranked) do
		if #team >= slots then
			break
		end
		if not Formulas.isSea(u.Stats) then
			table.insert(team, u)
		elseif sea < ponds then
			sea += 1
			table.insert(team, u)
		end
	end
	if sea == 0 and ponds > 0 and #team >= slots then
		for _, u in ipairs(ranked) do
			if Formulas.isSea(u.Stats) then
				team[#team] = u
				break
			end
		end
	end
	return team
end

function Formulas.autoLayout(units, mapId, taken)
	local D = Config.Defense
	local placed, others = {}, table.clone(taken or {})
	local order = table.clone(units)
	table.sort(order, function(a, b2)
		return a.Stats.Damage > b2.Stats.Damage
	end)
	local bound = (1 + math.max(roadWeight(mapId), 0)) * 1.25
	local function put(u, x, z)
		placed[u.Id] = { X = x, Z = z }
		table.insert(others, { X = x, Z = z, Footprint = u.Stats.Footprint })
	end
	for _, u in ipairs(order) do
		local st = u.Stats
		if Formulas.isSky(st) then
			local best, bestValue = nil, -1
			local reach = st.Reach * (1 + D.Perch.ReachBonus)
			for _, p in ipairs(Formulas.defenseMap(mapId).Perches or {}) do
				local value = roadValue(p[1], p[2], reach, mapId)
				if value > bestValue and Formulas.placementFits(p[1], p[2], st.Footprint, others, mapId, false, true) then
					best, bestValue = p, value
				end
			end
			if best then
				put(u, best[1], best[2])
				continue
			end
		end
		if Formulas.isSea(st) then
			local best, bestValue = nil, -1
			for _, p in ipairs(Formulas.defenseMap(mapId).Ponds or {}) do
				local value = roadValue(p[1], p[2], st.Reach, mapId)
				if value > bestValue and Formulas.placementFits(p[1], p[2], st.Footprint, others, mapId, true) then
					best, bestValue = p, value
				end
			end
			if best then
				put(u, best[1], best[2])
			end
			continue
		end
		local best, bestValue = nil, -1
		for _, p in ipairs(Formulas.layoutSpots(mapId, st.Reach, st.Footprint)) do
			if p[4] * bound > bestValue then
				local x, z = p[1], p[2]
				local nest = Formulas.nestAt(mapId, x, z, st.Footprint) ~= nil
				if nest then
					x, z = Formulas.nestSnap(mapId, x, z, st.Footprint)
				end
				local value = roadValue(x, z, nest and st.Reach * (1 + D.Rocks.Nest.ReachBonus) or st.Reach, mapId)
				if value > bestValue and Formulas.placementFits(x, z, st.Footprint, others, mapId) then
					best, bestValue = { x, z }, value
				end
			end
		end
		if best then
			put(u, best[1], best[2])
		end
	end
	return placed
end

local GROUP_KINDS = index(Config.Defense.Groups.Kinds)

function Formulas.groupKind(id)
	return GROUP_KINDS[id]
end

local function groupRolls(seed)
	local h = (seed * 7919 + 13) % 2147483647
	return function()
		h = (h * 48271) % 2147483647
		return h / 2147483647
	end
end

local function lastRow(rows, level, field)
	local value = 0
	for _, row in ipairs(rows) do
		if level >= row.Level then
			value = row[field]
		end
	end
	return value
end

local function rollGroup(level, roll, time)
	local G = Config.Defense.Groups
	local open, total = {}, 0
	for _, k in ipairs(G.Kinds) do
		if level >= k.FromLevel then
			table.insert(open, k)
			total += k.Weight
		end
	end
	local r = roll() * total
	local kind = open[#open]
	for _, k in ipairs(open) do
		if r < k.Weight then
			kind = k
			break
		end
		r -= k.Weight
	end
	local element = G.Elements[1 + math.floor(roll() * #G.Elements)]
	return { Time = time, Kind = kind.Id, Element = kind.Id == "Element" and element or nil,
		Count = lastRow(G.Members, level, "Count") }
end

function Formulas.fightGroups(level)
	local G = Config.Defense.Groups
	local roll = groupRolls(level)
	local list = {}
	for i = 1, math.min(lastRow(G.Count, level, "Groups"), #G.Times) do
		table.insert(list, rollGroup(level, roll, G.Times[i]))
	end
	return list
end

function Formulas.challengeGroup(wave)
	local G = Config.Defense.Groups
	if wave < G.ChallengeFromWave or (wave - G.ChallengeFromWave) % G.ChallengeEvery ~= 0 then
		return nil
	end
	return rollGroup(wave * G.ChallengeLevelPerWave, groupRolls(wave + 100000), 0)
end

function Formulas.groupIcon(g)
	local kind = GROUP_KINDS[g.Kind]
	return g.Element and Config.Attributes[g.Element] and Config.Attributes[g.Element].Icon or kind.Icon or "🚩"
end

-- how much tougher a tier's fossils are: 1, then Config.Rebirth.MonsterHealthTiers, then × MonsterHealthPerTier a tier
function Formulas.tierHealthMultiplier(tier)
	local r = Config.Rebirth
	if tier <= 0 then
		return 1
	end
	local list = r.MonsterHealthTiers
	return list[tier] or list[#list] * r.MonsterHealthPerTier ^ (tier - #list)
end

-- the promotion boss's attribute: it changes every AttributeChangeEveryLevels levels (Boss.AttributeOrder)
-- what an attribute does, in one short line a child gets (the 🧪 attribute board; 2026-10-04, "공룡 속성 등도 간략화
-- 그림으로", "봐도 모를만하게 그림만 막 교체하지 말고 최적화 하라는거야 아이들 기준": was its numbers, "피해 70%, 3칸
-- 폭발: 모두 3초 화상(초당 10%)")
local ATTRIBUTE_LINES = {
	Fire = "💥 펑 터져서 옆 화석까지 불붙여요",
	Ice = "🧊 옆 화석까지 꽁꽁 얼려서 멈춰요",
	Electric = "⚡ 옆 화석들로 번개가 찌릿 튀어요",
	Poison = "🟢 바닥에 독 웅덩이를 남겨요",
	Earth = "⛰️ 화석을 뒤로 쾅 밀쳐요",
	Water = "🌊 물벼락으로 적셔요 (그다음 ⚡·❄️가 더 세져요)",
	Neutral = "💪 그냥 세요! 👑 보스한테 더 아파요",
}
function Formulas.attributeText(id)
	return ATTRIBUTE_LINES[id] or ""
end

-- (2026-10-03) the attribute a boss of this attribute is weak to (Config.Defense.Boss.Weakness)
function Formulas.bossWeakness(attribute)
	return attribute and Config.Defense.Boss.Weakness[attribute]
end

function Formulas.bossAttribute(level)
	local b = Config.Defense.Boss
	level = fossilLevel(level) -- (the tier's own LV: a reborn LV 1 boss is fire again)
	return b.AttributeOrder[((level - 1) // b.AttributeChangeEveryLevels) % #b.AttributeOrder + 1]
end

-- mining at night (Config.DayNight): yield and speed multipliers, 1 by day
function Formulas.nightMining(isNight)
	local d = Config.DayNight
	if isNight then
		return d.NightMiningYield, d.NightMiningSpeed
	end
	return 1, 1
end

-- a treasure chest's money for an opener at this defense level; r in [0, 1) picks the spread
-- a 대박 광물's money (Config.Mining.Jackpot): MoneyChests treasure chests' worth at this level
function Formulas.jackpotMoney(level, r)
	return Formulas.treasureMoney(level, r) * Config.Mining.Jackpot.MoneyChests
end

function Formulas.treasureMoney(level, r)
	local t = Config.Treasure
	return math.floor(t.MoneyBase * Formulas.rewardIndex(level) * (1 + t.MoneySpread * (2 * r - 1)) + 0.5)
end

function Formulas.killReward(level)
	return Config.Monsters.KillRewardBase * Formulas.rewardIndex(level)
end

-- placement slots: StartSlots + the bonus (bought, rebirths, collection, game pass); the defense level
-- adds none (2026-10-01)
function Formulas.placementSlots(bonusSlots)
	return Config.Placement.StartSlots + (bonusSlots or 0)
end

-- the next bought slot's price (bought = slots bought so far), nil when all are bought
function Formulas.nextSlotCost(bought, level)
	local cost = Config.Placement.SlotUpgrade.Cost[bought + 1]
	return cost and Formulas.upgradePrice(cost * Formulas.levelIndex(level)) or nil
end

function Formulas.footprintRadius(scale)
	return scale * Config.Placement.FootprintRadiusPerScale
end

-- bigger dinos reach a little farther: +10% per 1 of scale above 1
function Formulas.rangeMultiplier(scale)
	return 1 + Config.Placement.RangeBonusPerScale * (scale - 1)
end

-- (2026-10-03) how strong a dino's attribute effect is (1 = a legendary young dino's: Config.Attributes' numbers), by
-- its rarity and size (Config.Attributes.Growth)
function Formulas.effectStrength(rarityId, sizeId)
	local g = Config.Attributes.Growth
	local size = DINO_SIZES[sizeId] or DINO_SIZES.Young
	local strength = (g.Base + g.PerRarity * ((RARITY_PLACE[rarityId] or 1) - 1)) * (1 + g.PerSizeScale * (size.Scale - 1))
	return math.max(g.Min, strength)
end

-- the effect areas (blast, pool, push) grow only AreaShare as fast as the strength
function Formulas.effectArea(strength)
	local share = Config.Attributes.Growth.AreaShare
	return 1 - share + share * strength
end

-- the hit's damage share an effect of that strength costs: the attribute's DamageMultiplier is a legendary's price, a
-- weaker effect pays that much less of it (a stronger one no more)
function Formulas.effectPrice(damageMultiplier, strength)
	if damageMultiplier >= 1 then
		return damageMultiplier
	end
	return 1 - (1 - damageMultiplier) * math.min(strength, 1)
end

-- the chain's targets for that strength: rounded, at least 1
function Formulas.chainTargets(strength)
	return math.max(1, math.floor(Config.Attributes.Electric.ChainTargets * strength + 0.5))
end

function Formulas.speciesReach(speciesId)
	return Config.Defense.SpeciesReach[speciesId] or 1
end

function Formulas.isSniper(speciesId)
	return Config.Defense.Snipers[speciesId] == true
end

function Formulas.unitStrength(unit)
	local s = Formulas.unitStats(unit)
	local reach = Formulas.isSniper(unit.Species) and Config.Defense.Sniper.StrengthReach or Formulas.speciesReach(unit.Species)
	return s.Damage / s.Interval * reach ^ Config.Defense.ReachDamageExponent
end

-- everything a placed unit needs for fighting, from its saved record { Species, Rarity, Size, Mutation }.
-- Reach is measured from the unit's center to a monster's center (plus the monster's size).
function Formulas.unitStats(unit)
	local species = SPECIES[unit.Species]
	local theme = THEMES[species.Theme]
	local damageMultiplier = 1
	if theme.Attack == "BaseTheme" then -- variants attack like their original theme, harder: more for a better key
		damageMultiplier = species.VariantPower or Config.VariantPowerByKey[species.MinKey or ""] or theme.DamageMultiplier
		theme = THEMES[species.BaseTheme]
	end
	local size = DINO_SIZES[unit.Size] or DINO_SIZES.Young
	local rarity = RARITIES[unit.Rarity] or RARITIES.Common
	local mutation = unit.Mutation and MUTATIONS[unit.Mutation]
	local p = Config.Placement
	local footprint = Formulas.footprintRadius(size.Scale)
	local sniper = Formulas.isSniper(unit.Species) and Config.Defense.Sniper
	local reachScale = sniper and 1 or Formulas.speciesReach(unit.Species)
	damageMultiplier *= reachScale ^ -Config.Defense.ReachDamageExponent
	local reach
	if sniper then
		reach = sniper.Range * Formulas.rangeMultiplier(size.Scale) * (theme.Id == "Sea" and Config.Defense.Pond.Reach or 1)
	elseif theme.Range == "Melee" then -- the track's inner edge within MeleeReachFromTrack of the unit's edge
		reach = footprint + (p.MeleeReachFromTrack * Formulas.rangeMultiplier(size.Scale)
			+ Config.Defense.TrackHalfWidth) * reachScale
	else
		reach = theme.Range * Formulas.rangeMultiplier(size.Scale) * reachScale
		if theme.Id == "Sea" then
			reach *= Config.Defense.Pond.Reach
		end
	end
	return {
		Theme = theme.Id,
		Attack = sniper and "SingleTarget" or theme.Attack,
		Sniper = sniper and true or nil,
		Attribute = species.Attribute,
		Damage = (sniper and sniper.Damage or theme.Damage) * damageMultiplier * (species.DamageMultiplier or 1) * rarity.Power * size.Power * (mutation and mutation.Power or 1)
			* Formulas.levelPower(unit),
		Interval = sniper and sniper.Interval or theme.Interval,
		AreaRadius = not sniper and theme.AreaRadius or nil,
		SlowAura = not sniper and theme.SlowAura or nil,
		PierceMax = theme.PierceMax,
		PierceWidth = theme.PierceWidth,
		Reach = reach,
		Scale = size.Scale,
		Look = size.Look or size.Scale, -- how big it is drawn
		Footprint = footprint,
		Effect = Formulas.effectStrength(unit.Rarity, unit.Size), -- (2026-10-03) its attribute effect's strength
		Species = unit.Species,
	}
end

-- (2026-10-05, "이번에 어떤 점이 가장 부족했는지 평가해서") a lost promotion fight's weakest point, the first that fits:
-- "Placement" (dinos too far from the track: they never attack), "Slots" (empty dino places), then by why it was lost:
-- "Area" (fossils piled up and too few dinos hit many at once), "Matchup" (the boss lived: none of its weakness's
-- attribute, or many of its own), else "Power". info: { reason = "crowd" | "time", units = { { Attack, Attribute,
-- active } }, slots, bossAttribute, weakAttribute }. Returns the kind and the counts (far, area, weak, same, empty, placed)
local AREA_ATTACKS = { AreaAround = true, PiercingLine = true, Splash = true }
function Formulas.promoWeakness(info)
	local A = Config.Defense.Promotion.Advice
	local c = { far = 0, area = 0, weak = 0, same = 0, placed = #info.units, rest = 0, sea = 0, blocked = 0 }
	local hidden, immune = nil, nil
	for id in pairs(info.leakedKinds or {}) do
		local k = Formulas.fossilKind(id)
		if k and k.Hidden then
			hidden = k
		elseif k and (k.ImmuneAttack or k.ImmuneAttribute) then
			immune = immune or k
		end
	end
	for _, u in ipairs(info.units) do
		c.rest += u.Rest and 1 or 0
		c.far += (u.active == false and not u.Rest) and 1 or 0
		c.area += (u.active ~= false and not u.Rest and AREA_ATTACKS[u.Attack]) and 1 or 0
		c.weak += (u.active ~= false and not u.Rest and info.weakAttribute and u.Attribute == info.weakAttribute) and 1 or 0
		c.same += (info.bossAttribute and u.Attribute == info.bossAttribute) and 1 or 0
		c.sea += (u.Theme == "Sea" and u.active ~= false and not u.Rest) and 1 or 0
		if immune and ((immune.ImmuneAttack and immune.ImmuneAttack == u.Attack)
			or (immune.ImmuneAttribute and immune.ImmuneAttribute == u.Attribute)) then
			c.blocked += 1
		end
	end
	c.empty = math.max(0, (info.slots or c.placed) - c.placed)
	c.crowd = info.crowd or 0
	if c.far > 0 then
		return "Placement", c
	elseif info.twist and c.rest > 0 then
		return "Twist", c
	elseif c.empty > 0 then
		return "Slots", c
	elseif hidden and c.sea == 0 then
		c.kind = hidden.Id
		return "Hidden", c
	elseif immune and c.placed > 0 and c.blocked / c.placed >= A.ImmuneShareBad then
		c.kind = immune.Id
		return "Immune", c
	elseif info.reason == "leak" and info.moreSlots and c.placed > 0 and c.crowd > A.CrowdPerDino * c.placed then
		return "Few", c
	elseif info.reason == "leak" then
		return (c.placed == 0 or c.area / c.placed < A.AreaShareGood) and "Area" or "Power", c
	elseif info.weakAttribute
		and (c.weak == 0 or (c.placed > 0 and c.same / c.placed >= A.SameShareBad)) then
		return "Matchup", c
	end
	return "Power", c
end

-- ---------------------------------------------------------------------------
-- Dino enhancement (Config.Enhance): feed a dino others of its species for experience
-- ---------------------------------------------------------------------------

function Formulas.unitLevel(unit)
	return unit.Level or 1
end

-- attack multiplier from the dino's level: +PowerPerLevel a level above 1, +LatePowerPerLevel from LatePowerFrom
function Formulas.levelPower(unit)
	local e = Config.Enhance
	local level = Formulas.unitLevel(unit)
	local early = math.min(level, e.LatePowerFrom - 1) - 1
	local late = math.max(0, level - (e.LatePowerFrom - 1))
	return 1 + early * e.PowerPerLevel + late * e.LatePowerPerLevel
end

-- how many times the first level's experience the step from level to level + 1 costs (Enhance.LevelBands)
local function levelCurve(level)
	local m = 1
	for reached = 2, level do
		local growth = 1
		for _, band in ipairs(Config.Enhance.LevelBands) do
			if reached >= band.From then
				growth = band.Growth
			end
		end
		m *= growth
	end
	return m
end

-- experience the dino needs from its level to the next, nil at MaxLevel
function Formulas.enhanceNeed(unit)
	local e = Config.Enhance
	local level = Formulas.unitLevel(unit)
	if level >= e.MaxLevel then
		return nil
	end
	local rarityStep = (RARITIES[unit.Rarity .. "#"] or 1) - 1
	return math.floor(e.ExpBase * e.RarityGrowth ^ rarityStep * levelCurve(level) + 0.5)
end

-- experience one fodder dino gives: by its size, more for a better rarity, OtherSpeciesShare of it
-- when it is another species than the target (no target: as its own species)
function Formulas.fodderExp(fodder, target)
	local e = Config.Enhance
	local exp = (e.SizeExp[fodder.Size] or e.SizeExp.Young) * e.FodderRarityGrowth ^ ((RARITIES[fodder.Rarity .. "#"] or 1) - 1)
	if target and fodder.Species ~= target.Species then
		exp *= e.OtherSpeciesShare
	end
	return math.floor(exp + 0.5)
end

function Formulas.bossMatchup(attribute, level)
	local B = Config.Defense.Boss
	local boss = Formulas.bossAttribute(level)
	local m = attribute == boss and B.SameAttributeDamageMultiplier
		or attribute == Formulas.bossWeakness(boss) and B.WeaknessDamageMultiplier or 1
	return 1 + (m - 1) * Config.Recommend.BossShare
end

function Formulas.recommendStrength(unit, level)
	local species = SPECIES[unit.Species]
	return Formulas.unitStrength(unit) * Formulas.bossMatchup(species and species.Attribute, level)
end

function Formulas.recommendTeam(units, slots, level, mapId, skip, twist)
	local ranked = {}
	for _, u in ipairs(units) do
		if not (skip and skip[u.Id]) then
			table.insert(ranked, { Id = u.Id, Stats = Formulas.unitStats(u), Strength = Formulas.recommendStrength(u, level) })
		end
	end
	local bench = twist and twist.Id ~= "Ace" and Formulas.twistBench(twist, ranked, level) or {}
	table.sort(ranked, function(a, b)
		if (bench[a.Id] == true) ~= (bench[b.Id] == true) then
			return not bench[a.Id]
		end
		if a.Strength ~= b.Strength then
			return a.Strength > b.Strength
		end
		return tostring(a.Id) < tostring(b.Id)
	end)
	return Formulas.pickTeam(ranked, slots, mapId)
end

function Formulas.enhancePick(units, placed, level)
	local any = next(placed or {}) ~= nil
	local best, bestScore = nil, 0
	for _, u in ipairs(units) do
		local need = Formulas.enhanceNeed(u)
		if need and (not any or placed[u.Id]) then
			local up = table.clone(u)
			up.Level = Formulas.unitLevel(u) + 1
			local score = (Formulas.recommendStrength(up, level) - Formulas.recommendStrength(u, level))
				/ math.max(1, need - (u.Exp or 0))
			if score > bestScore then
				best, bestScore = u.Id, score
			end
		end
	end
	return best
end

function Formulas.fodderPlan(target, pool, keep)
	local R = Config.Recommend
	local need = Formulas.enhanceNeed(target)
	if not need then
		return {}, 0
	end
	local cap = math.min(RARITIES[target.Rarity .. "#"] or 1, RARITIES[R.FodderMaxRarity .. "#"] or 1)
	local sizeCap = DINO_SIZES[R.FodderSizeBelow .. "#"] or math.huge
	local list = {}
	for _, u in ipairs(pool) do
		if u.Id ~= target.Id and Formulas.unitLevel(u) == 1 and not u.Fed and not (keep and keep[u.Id])
			and (RARITIES[u.Rarity .. "#"] or 1) <= cap and (DINO_SIZES[u.Size .. "#"] or 1) < sizeCap then
			table.insert(list, u)
		end
	end
	table.sort(list, function(a, b)
		local ra, rb = RARITIES[a.Rarity .. "#"] or 1, RARITIES[b.Rarity .. "#"] or 1
		if ra ~= rb then
			return ra < rb
		end
		local sa, sb = a.Species == target.Species, b.Species == target.Species
		if sa ~= sb then
			return sa
		end
		local ea, eb = Formulas.fodderExp(a, target), Formulas.fodderExp(b, target)
		if ea ~= eb then
			return ea < eb
		end
		return tostring(a.Id) < tostring(b.Id)
	end)
	local left = need - (target.Exp or 0)
	local picks, exp = {}, 0
	for _, u in ipairs(list) do
		if exp >= left or #picks >= Config.Enhance.MaxFodder then
			break
		end
		table.insert(picks, u)
		exp += Formulas.fodderExp(u, target)
	end
	local ids = {}
	for _, u in ipairs(picks) do
		table.insert(ids, u.Id)
	end
	return ids, exp
end

-- can these dinos feed that one? ok, or false and why. fodderIds: list of unit Ids
function Formulas.canEnhance(profile, targetId, fodderIds)
	local byId = {}
	for _, u in ipairs(profile.Units) do
		byId[u.Id] = u
	end
	local target = byId[targetId]
	if not target then
		return false, "없는 공룡이에요"
	elseif not Formulas.enhanceNeed(target) then
		return false, "이미 최고 레벨이에요"
	elseif #fodderIds == 0 then
		return false, "👆 재료 공룡을 골라 주세요"
	elseif #fodderIds > Config.Enhance.MaxFodder then
		return false, string.format("한 번에 %d마리까지예요", Config.Enhance.MaxFodder)
	end
	local seen = {}
	for _, id in ipairs(fodderIds) do
		local f = byId[id]
		if not f or seen[id] or id == targetId then
			return false, "재료가 잘못됐어요"
		elseif profile.Placed[id] or (profile.Farm or {})[id] then
			return false, "🚫 아레나·농장에 있는 공룡은 재료로 못 써요"
		end
		seen[id] = true
	end
	return true
end

-- 합성 (Config.Merge): may these dinos (ids, Merge.Count of them) be merged, keeping keepId's species,
-- at this defense level? ok and the result's rarity Id, or false and why. All at least at Merge.Level, the
-- same rarity, neither placed nor on the farm; the next rarity must exist, be open at this level and
-- not above Merge.MaxResultRarity.
function Formulas.canMerge(profile, ids, keepId, level)
	local m = Config.Merge
	if #ids ~= m.Count then
		return false, string.format("👆 최고 레벨 공룡 %d마리를 골라 주세요", m.Count)
	end
	local byId = {}
	for _, u in ipairs(profile.Units) do
		byId[u.Id] = u
	end
	local seen, rarity, keep = {}, nil, false
	for _, id in ipairs(ids) do
		local u = byId[id]
		if not u or seen[id] then
			return false, "재료가 잘못됐어요"
		elseif Formulas.unitLevel(u) < Config.Merge.Level then
			return false, string.format("⬆️ 레벨 %d 이상인 공룡만 합성할 수 있어요", Config.Merge.Level)
		elseif profile.Placed[id] or (profile.Farm or {})[id] then
			return false, "🚫 아레나·농장에 있는 공룡은 합성 못 해요"
		elseif rarity and u.Rarity ~= rarity then
			return false, "🎨 같은 등급끼리만 합성할 수 있어요"
		end
		rarity = u.Rarity
		seen[id] = true
		keep = keep or id == keepId
	end
	if not keep then
		return false, "남길 종을 골라 주세요"
	end
	if Formulas.specialRarity(rarity) then
		return false, "⭐ 특별 등급은 합성할 수 없어요"
	end
	local index = RARITIES[rarity .. "#"]
	local next = Config.Rarities[index + 1]
	if not next or index + 1 > RARITIES[m.MaxResultRarity .. "#"] then
		return false, "🔝 이 등급은 더 합성할 수 없어요 (그 위는 뽑기로만)"
	elseif not Formulas.rarityOpen(next, level) then
		return false, string.format("%s 등급은 %s부터 열려요", next.Name, Formulas.rarityCondition(next))
	end
	return true, next.Id
end

-- the dino a merge makes (2026-10-02, Config.Merge PowerShare / TopSize): keepId's species and mutation, the next
-- rarity; its size the three's average size step × (TopSize's step / the biggest step), rounded; its level the
-- highest whose attack (level power × size power) stays within PowerShare of the three's average attack, at
-- least 1. Three at the top level and the biggest size make TopSize at about level 76: about 2/3 of the best.
-- (the caller gives it an Id)
function Formulas.mergeResult(units, keepId, rarityId)
	local m = Config.Merge
	local keep, steps, attack = nil, 0, 0
	for _, u in ipairs(units) do
		if u.Id == keepId then
			keep = u
		end
		local size = DINO_SIZES[u.Size] or DINO_SIZES.Young
		steps += DINO_SIZES[size.Id .. "#"]
		attack += Formulas.levelPower(u) * size.Power
	end
	local n = math.max(#units, 1)
	local share = DINO_SIZES[m.TopSize .. "#"] / #Config.Sizes
	local step = math.clamp(math.floor(steps / n * share + 0.5), 1, #Config.Sizes)
	local size = Config.Sizes[step]
	local want = attack / n * m.PowerShare
	local level = 1
	for l = 2, Config.Enhance.MaxLevel do
		if Formulas.levelPower({ Level = l }) * size.Power > want then
			break
		end
		level = l
	end
	return { Species = keep.Species, Rarity = rarityId, Size = size.Id, Level = level, Exp = 0, Mutation = keep.Mutation,
		Limited = keep.Limited, Attend = keep.Attend, Season = keep.Season } -- (a limited, attendance or season dino kept stays marked, 2026-10-02)
end

-- add experience to a dino (in place): levels up while it can; experience past MaxLevel is lost.
-- Returns the levels gained.
function Formulas.addExp(unit, exp)
	local gained = 0
	unit.Exp = (unit.Exp or 0) + exp
	local need = Formulas.enhanceNeed(unit)
	while need and unit.Exp >= need do
		unit.Exp -= need
		unit.Level = Formulas.unitLevel(unit) + 1
		gained += 1
		need = Formulas.enhanceNeed(unit)
	end
	if not need then
		unit.Exp = 0
	end
	return gained
end

-- can a unit of this footprint stand at local (x, z) of this map (nil: the first map), clear of the others?
-- others: list of { X, Z, Footprint }
function Formulas.pondAt(mapId, x, z, extra)
	local map = Formulas.defenseMap(mapId)
	local r = Config.Defense.Pond.Radius + (extra or 0)
	for i, p in ipairs(map.Ponds or {}) do
		local dx, dz = x - p[1], z - p[2]
		if dx * dx + dz * dz <= r * r then
			return i, p
		end
	end
	return nil
end

function Formulas.starterChapter(step, total)
	local list = Config.StarterMissions.Missions
	local m = list[math.clamp(step or 1, 1, math.max(1, math.min(total or #list, #list)))]
	local chapter = m and m.Ch or 1
	local first, size = nil, 0
	for i, x in ipairs(list) do
		if (x.Ch or 1) == chapter and (x.Comeback == true) == (m ~= nil and m.Comeback == true) then
			first = first or i
			size += 1
		end
	end
	return chapter, (step or 1) - (first or 1) + 1, size
end

function Formulas.starterChapterInfo(chapter)
	if chapter == 0 then
		return { Name = Config.StarterMissions.ComebackName }
	end
	return Config.StarterMissions.Chapters[chapter] or { Name = "" }
end

function Formulas.stageOf(name)
	for _, m in ipairs(Config.StarterMissions.Missions) do
		if m.Show and table.find(m.Show, name) then
			return m.Goal or m.Event
		end
	end
	return nil
end

function Formulas.isSea(stats)
	return stats.Theme == "Sea"
end

function Formulas.isSky(stats)
	return stats.Theme == "Sky"
end

function Formulas.perchAt(mapId, x, z, extra)
	local map = Formulas.defenseMap(mapId)
	local r = Config.Defense.Perch.Radius + (extra or 0)
	for i, p in ipairs(map.Perches or {}) do
		local dx, dz = x - p[1], z - p[2]
		if dx * dx + dz * dz <= r * r then
			return i, p
		end
	end
	return nil
end

function Formulas.twistRule(level)
	local T = Config.Defense.Twists
	local at, tier = fossilLevel(level)
	if tier < T.FromTier or at < T.FromLevel or (at - T.FromLevel) % T.Every ~= 0 then
		return nil
	end
	return T.Rules[((at - T.FromLevel) // T.Every + tier - T.FromTier) % #T.Rules + 1]
end

function Formulas.twistText(rule, level)
	if rule.Id == "Element" then
		local a = Config.Attributes[Formulas.bossAttribute(level)]
		return string.format("🚫 %s %s 공룡은 쉬어요 (보스와 같은 속성)", a.Icon, a.Name)
	end
	return rule.Text
end

function Formulas.twistBench(rule, units, level)
	local bench = {}
	if not rule then
		return bench
	end
	if rule.Id == "Ace" or rule.Id == "Unique" then
		local order = table.clone(units)
		table.sort(order, function(a, b)
			if a.Stats.Damage ~= b.Stats.Damage then
				return a.Stats.Damage > b.Stats.Damage
			end
			return tostring(a.Id) < tostring(b.Id)
		end)
		if rule.Id == "Ace" then
			for i = 1, math.min(rule.Count, #order) do
				bench[order[i].Id] = true
			end
			return bench
		end
		local seen = {}
		for _, u in ipairs(order) do
			local species = u.Stats.Species or u.Id
			if seen[species] then
				bench[u.Id] = true
			end
			seen[species] = true
		end
		return bench
	end
	local boss = rule.Id == "Element" and Formulas.bossAttribute(level)
	for _, u in ipairs(units) do
		local st = u.Stats
		local rest
		if rule.Id == "Land" then
			rest = Formulas.isSky(st) or Formulas.isSea(st)
		elseif rule.Id == "Sky" then
			rest = not Formulas.isSky(st)
		elseif rule.Id == "Sea" then
			rest = not Formulas.isSea(st)
		elseif rule.Id == "Element" then
			rest = st.Attribute == boss
		end
		if rest then
			bench[u.Id] = true
		end
	end
	return bench
end

function Formulas.teamSynergies(units)
	local kinds = {}
	for _, u in ipairs(units) do
		if not u.Rest and u.active ~= false and u.Species then
			local theme = u.Stats.Theme
			kinds[theme] = kinds[theme] or {}
			kinds[theme][u.Species] = true
		end
	end
	local carnivores = 0
	for _ in pairs(kinds.Carnivore or {}) do
		carnivores += 1
	end
	return { Predator = carnivores >= 2, Guardian = kinds.Herbivore ~= nil and kinds.Armored ~= nil,
		Sky = kinds.Sky ~= nil and carnivores >= 1 }
end

function Formulas.activeTwist(profile, level)
	local rule = Formulas.twistRule(level)
	if not rule then
		return nil
	end
	local streak = profile.PromoAssist
	if streak and streak.Level == level and (streak.Losses or 0) >= Config.Defense.Twists.EaseAfterLosses then
		return nil, rule, "Losses"
	end
	local units = {}
	for _, u in ipairs(profile.Units or {}) do
		table.insert(units, { Id = u.Id, Stats = Formulas.unitStats(u) })
	end
	local benched = 0
	for _ in pairs(Formulas.twistBench(rule, units, level)) do
		benched += 1
	end
	if #units - benched < 1 then
		return nil, rule, "Owned"
	end
	return rule
end

function Formulas.twistBonusKeys(level)
	return math.max(1, math.floor(Formulas.promotionBaseKeys(level) * Config.Defense.Twists.BonusKeyShare + 0.5))
end

function Formulas.perchSnap(mapId, x, z)
	local snap = Config.Defense.Perch.Snap
	for _, p in ipairs(Formulas.defenseMap(mapId).Perches or {}) do
		local dx, dz = x - p[1], z - p[2]
		if dx * dx + dz * dz <= snap * snap then
			return p[1], p[2]
		end
	end
	return x, z
end

local ROCKS = {}
function Formulas.mapRocks(mapId)
	local map = Formulas.defenseMap(mapId)
	local list = ROCKS[map.Id]
	if list then
		return list
	end
	list = {}
	local R = Config.Defense.Rocks
	for _, p in ipairs(map.Rocks or {}) do
		table.insert(list, { p[1], p[2] })
	end
	local ring = R.Nest.Pocket + R.Radius
	for i, n in ipairs(map.Nests or {}) do
		for k = 1, R.Nest.Count do
			local a = (k - 1) / R.Nest.Count * 2 * math.pi + math.pi / 2
			table.insert(list, { n[1] + math.cos(a) * ring, n[2] + math.sin(a) * ring, i })
		end
	end
	ROCKS[map.Id] = list
	return list
end

function Formulas.rockAt(mapId, x, z, extra)
	local r = Config.Defense.Rocks.Radius + (extra or 0)
	for _, p in ipairs(Formulas.mapRocks(mapId)) do
		local dx, dz = x - p[1], z - p[2]
		if dx * dx + dz * dz < r * r - 1e-6 then
			return p
		end
	end
	return nil
end

function Formulas.nestAt(mapId, x, z, footprint)
	local N = Config.Defense.Rocks.Nest
	if footprint and footprint > N.Pocket + 1e-6 then
		return nil
	end
	for i, n in ipairs(Formulas.defenseMap(mapId).Nests or {}) do
		local dx, dz = x - n[1], z - n[2]
		if dx * dx + dz * dz <= N.Pocket * N.Pocket then
			return i, n
		end
	end
	return nil
end

function Formulas.nestSnap(mapId, x, z, footprint)
	local N = Config.Defense.Rocks.Nest
	if footprint > N.Pocket + 1e-6 then
		return x, z
	end
	for _, n in ipairs(Formulas.defenseMap(mapId).Nests or {}) do
		local dx, dz = x - n[1], z - n[2]
		if dx * dx + dz * dz <= N.Snap * N.Snap then
			return n[1], n[2]
		end
	end
	return x, z
end

function Formulas.placedStats(stats, mapId, x, z)
	if Formulas.isSky(stats) and Formulas.perchAt(mapId, x, z) then
		local P = Config.Defense.Perch
		local out = table.clone(stats)
		out.Reach *= 1 + P.ReachBonus
		out.PierceMax = out.PierceMax and out.PierceMax + P.PierceBonus
		out.Perch = true
		return out
	end
	if Formulas.isSea(stats) or not Formulas.nestAt(mapId, x, z, stats.Footprint) then
		return stats
	end
	local out = table.clone(stats)
	out.Reach *= 1 + Config.Defense.Rocks.Nest.ReachBonus
	out.Nest = true
	return out
end

function Formulas.placementFits(x, z, footprint, others, mapId, sea, sky)
	local map = Formulas.defenseMap(mapId)
	local D = Config.Defense
	if sea then
		local _, pond = Formulas.pondAt(map.Id, x, z, D.Pond.Snap)
		if not pond then
			return false, "🌊 바다 공룡은 연못에만 놓을 수 있어요"
		end
		for _, o in ipairs(others) do
			local dx, dz = pond[1] - o.X, pond[2] - o.Z
			if math.sqrt(dx * dx + dz * dz) < D.Pond.Radius + o.Footprint then
				return false, "연못에 벌써 공룡이 있어요"
			end
		end
		return true
	end
	if Formulas.pondAt(map.Id, x, z, footprint) then
		return false, "🌊 연못에는 바다 공룡만 놓을 수 있어요"
	end
	local perch, spot = Formulas.perchAt(map.Id, x, z, footprint)
	if perch then
		if not sky then
			return false, "🏔️ 하늘 바위엔 🦅 하늘 공룡만 앉아요"
		end
		if math.abs(x - spot[1]) > 0.05 or math.abs(z - spot[2]) > 0.05 then
			return false, "🏔️ 하늘 바위 한가운데에 놓아요"
		end
		for _, o in ipairs(others) do
			if Formulas.perchAt(map.Id, o.X, o.Z) == perch then
				return false, "🏔️ 하늘 바위엔 한 마리만 앉아요"
			end
		end
		return true
	end
	local nest = Formulas.nestAt(map.Id, x, z, footprint)
	if nest then
		for _, o in ipairs(others) do
			if Formulas.nestAt(map.Id, o.X, o.Z) == nest then
				return false, "🐣 둥지엔 공룡 한 마리만 들어가요"
			end
		end
	end
	local rock = Formulas.rockAt(map.Id, x, z, footprint)
	if rock then
		if rock[3] then
			return false, "🐣 둥지 바위에 걸려요! 둥지 한가운데에 놓아요"
		end
		return false, "🚫 바위에 걸려요! 작은 공룡은 틈에 쏙"
	end
	local b = D.MapBounds
	if math.abs(x) + footprint > b.X or z - footprint < b.ZFront or z + footprint > b.ZBack then
		return false, "놓는 곳 밖이에요"
	end
	local path = Formulas.lanePath(map.Id)
	if Formulas.laneDistance(path, x, z) < D.TrackHalfWidth + footprint then
		return false, "길 위에는 놓을 수 없어요"
	end
	local n = #path.x
	for _, i in ipairs({ 1, n }) do
		local dx, dz = x - path.x[i], z - path.z[i]
		if math.sqrt(dx * dx + dz * dz) < D.GateClear + D.TrackHalfWidth + footprint then
			return false, "게이트 앞에는 놓을 수 없어요"
		end
	end
	for _, o in ipairs(others) do
		local dx, dz = x - o.X, z - o.Z
		if math.sqrt(dx * dx + dz * dz) < footprint + o.Footprint then
			return false, "다른 공룡과 겹쳐요"
		end
	end
	return true
end

-- ---------------------------------------------------------------------------
-- 공룡 사육 (Config.Fruit, 2026-10-02): fruit from the trees, food that grows a dino one size at a time
-- ---------------------------------------------------------------------------

local FRUIT_SIZES = index(Config.Fruit.Sizes)

function Formulas.fruitSize(id)
	return FRUIT_SIZES[id]
end

-- a fruit size by its WeightPercent; roll in [0, 1)
function Formulas.rollFruitSize(roll)
	local at = roll * 100
	for _, f in ipairs(Config.Fruit.Sizes) do
		at -= f.WeightPercent
		if at < 0 then
			return f
		end
	end
	return Config.Fruit.Sizes[#Config.Fruit.Sizes]
end

-- food to grow this dino one size bigger, nil at the biggest size
function Formulas.feedCost(unit)
	local f = Config.Fruit
	local step = DINO_SIZES[(unit.Size or "Young") .. "#"] or DINO_SIZES["Young#"]
	if step >= #Config.Sizes then
		return nil
	end
	local rarityStep = (RARITIES[(unit.Rarity or "Common") .. "#"] or 1) - 1
	return math.floor(f.FeedBase * f.FeedGrowth ^ (step - 1) * f.FeedRarityGrowth ^ rarityStep + 0.5)
end

-- the size one step bigger, nil at the biggest
function Formulas.nextDinoSize(sizeId)
	local step = DINO_SIZES[(sizeId or "Young") .. "#"] or DINO_SIZES["Young#"]
	return Config.Sizes[step + 1]
end

function Formulas.feedNeed(unit)
	local cost = Formulas.feedCost(unit)
	return cost and math.max(cost - (unit.Fed or 0), 0)
end

-- may this dino be fed now? ok and the food it takes, or false and why. A dino on the
-- defense platform must still fit there once bigger (else: take it off first).
function Formulas.canFeed(profile, unitId, amount)
	local byId = {}
	for _, u in ipairs(profile.Units) do
		byId[u.Id] = u
	end
	local unit = byId[unitId]
	if not unit then
		return false, "없는 공룡이에요"
	end
	local need = Formulas.feedNeed(unit)
	if not need then
		return false, "이미 가장 큰 크기예요"
	end
	local give = math.min(profile.Fruit or 0, need, math.max(1, math.floor(amount or math.huge)))
	if give <= 0 and need > 0 then
		return false, "🍎 먹이가 없어요! 🌳 나무를 찰싹 쳐 봐요"
	end
	local at = profile.Placed[unitId]
	if at and give >= need then
		local bigger = Formulas.unitStats({ Species = unit.Species, Rarity = unit.Rarity, Mutation = unit.Mutation,
			Size = Formulas.nextDinoSize(unit.Size).Id, Level = unit.Level })
		local others = {}
		for id, pos in pairs(profile.Placed) do
			if id ~= unitId and byId[id] then
				table.insert(others, { X = pos.X, Z = pos.Z, Footprint = Formulas.unitStats(byId[id]).Footprint })
			end
		end
		if not Formulas.placementFits(at.X, at.Z, bigger.Footprint, others, profile.DefenseMap, Formulas.isSea(bigger),
			Formulas.isSky(bigger)) then
			return false, "📏 커지면 자리가 좁아요! 옮기거나 빼고 먹여요"
		end
	end
	return true, give
end

-- feed it (in place, inside PlayerData.update, after canFeed)
function Formulas.feed(profile, unitId, give)
	for _, u in ipairs(profile.Units) do
		if u.Id == unitId then
			local need = Formulas.feedNeed(u)
			if not need then
				return nil
			end
			give = math.min(give, profile.Fruit or 0, need)
			if give < 0 or (give == 0 and need > 0) then
				return nil
			end
			profile.Fruit = (profile.Fruit or 0) - give
			local fed = (u.Fed or 0) + give
			local cost = Formulas.feedCost(u)
			local grew = fed >= cost
			if grew then
				u.Size = Formulas.nextDinoSize(u.Size).Id
				fed -= cost
			end
			u.Fed = fed > 0 and fed or nil
			return u, grew
		end
	end
	return nil
end

-- are there Config.Merge.Count dinos of one rarity at Merge.Level or more, neither placed nor on the farm (Coco's 🧬 tip)
function Formulas.mergeReady(profile)
	local count = {}
	for _, u in ipairs(profile.Units) do
		if Formulas.unitLevel(u) >= Config.Merge.Level and not profile.Placed[u.Id] and not (profile.Farm or {})[u.Id] then
			count[u.Rarity] = (count[u.Rarity] or 0) + 1
			if count[u.Rarity] >= Config.Merge.Count then
				return true
			end
		end
	end
	return false
end

-- ---------------------------------------------------------------------------
-- Farm, collection and rebirth bonuses (design 2.8, 12 기간을 늘리는 장치)
-- ---------------------------------------------------------------------------

function Formulas.collectionKey(unit)
	return unit.Species .. "/" .. unit.Rarity
end

-- remember a new dino in the collection (call inside PlayerData.update)
function Formulas.recordCollection(profile, unit)
	profile.Collection = profile.Collection or {}
	local species = SPECIES[unit.Species]
	-- the rebirth-only and gift-only dinos and the given-only rarities (⭐ 특별) are not in the collection
	if (species and species.Rebirth) or GIFT_SPECIES[unit.Species] or Formulas.specialRarity(unit.Rarity) then
		return
	end
	profile.Collection[Formulas.collectionKey(unit)] = true
end

-- (2026-10-02, Config.Collection) every pair there is: species × rarities
function Formulas.collectionTotal()
	return #Config.Species * #Config.Rarities
end

local DEX_SPECIES = {}
for _, s in ipairs(Config.Species) do
	DEX_SPECIES[s.Id] = true
end

function Formulas.dexSpecies(profile)
	local seen, n = {}, 0
	for key in pairs(profile.Collection or {}) do
		local id = string.match(key, "^([^/]+)/")
		if id and DEX_SPECIES[id] and not seen[id] then
			seen[id] = true
			n += 1
		end
	end
	return n
end

function Formulas.dexSpeciesTotal()
	return #Config.Species
end

-- (2026-10-04) the share of every pair collected, as the screens write it (the % after it): one decimal under 10% so
-- each new pair shows ("0.4", "2.1"; at least "0.1" once there is one), whole numbers from there ("12"), never "100"
-- before it is all
function Formulas.collectionPercentText(count)
	local share = count / Formulas.collectionTotal() * 100
	if share >= 10 then
		return tostring(math.floor(share))
	end
	local tenths = math.floor(share * 10)
	if count > 0 and tenths < 1 then
		tenths = 1
	end
	return string.format("%d.%d", tenths // 10, tenths % 10)
end

-- a milestone's count ("All" = every pair)
function Formulas.milestoneCount(m)
	return m.Count == "All" and Formulas.collectionTotal() or m.Count
end

-- the best collection title reached at this count (nil before the first), and its milestone's index
function Formulas.collectionTitle(count)
	local title, index = nil, 0
	for i, m in ipairs(Config.Collection.Milestones) do
		if count >= Formulas.milestoneCount(m) then
			title, index = m.Title, i
		end
	end
	return title, index
end

-- how many plain species (not variants) of each rarity were collected: { [rarity Id] = n }
function Formulas.collectionRows(profile)
	local rows = {}
	for key in pairs(profile.Collection or {}) do
		local speciesId, rarityId = string.match(key, "^([^/]+)/(.+)$")
		local species = speciesId and SPECIES[speciesId]
		if species and species.Theme ~= "Variant" then
			rows[rarityId] = (rows[rarityId] or 0) + 1
		end
	end
	return rows
end

-- a reward (Config.Rewards' kinds) in short words for the windows: "🔑 열쇠 3개 · 🔑 루비 열쇠 1개 · 💰 보물상자 1개만큼 돈"
function Formulas.rewardShortText(reward, level)
	local parts = {}
	-- (2026-10-04) KeyHours: that many hours of Products.KeysPerHour keys at the level (the night boss's reward)
	local keys = (reward.Keys or 0) + ((reward.KeyHours or 0) > 0 and Formulas.keyPackKeys(level or 1, reward.KeyHours) or 0)
	if keys > 0 then
		table.insert(parts, string.format("🔑 열쇠 %s개", Formulas.shortNumber(keys)))
	end
	for _, t in ipairs(Config.Keys.Types) do
		local n = reward.SpecialKeys and reward.SpecialKeys[t.Id] or 0
		if n > 0 then
			table.insert(parts, string.format("🔑 %s %d개", t.Name, n))
		end
	end
	if (reward.MoneyChests or 0) > 0 then
		table.insert(parts, string.format("💰 보물상자 %d개만큼 돈", reward.MoneyChests))
	end
	return table.concat(parts, " · ")
end

-- (2026-10-04, "숨는 사람 종 간격 좀 더 밸런스 조절해봐") seconds until the hiders' bells ring again: by the part of
-- the game (seeked = seconds since seeking began, left = seconds to its end) and how many hiders are still in
function Formulas.hideSeekBellGap(seeked, left, hidersLeft)
	local C = Config.HideSeek
	local gap = left <= C.FinalSeconds and C.BellEveryFinal
		or left <= C.LateSeconds and C.BellEveryLate
		or seeked < C.EarlySeconds and C.BellEveryEarly
		or C.BellEvery
	local factor = math.min(1 + C.BellPerHider * math.max((hidersLeft or 1) - 1, 0), C.BellMaxFactor)
	return gap * factor
end

-- (2026-10-04) training (Config.Training): the seconds of standing at a station from this level to the next of a track
-- (Power: level = the power steps over every tier, (tier − 1) × PowerSteps + step), nil at the top
-- a track's top level (Power: the power steps over every tier)
function Formulas.trainTop(track)
	return track == "Power" and #Config.Pickaxe.Tiers * Config.Pickaxe.PowerSteps
		or track == "Speed" and Config.Pickaxe.SpeedUpgrade.Levels
		or track == "Slap" and #Config.Slap.Cost
		or track == "MoveSpeed" and Config.MoveSpeed.Levels
		or track == "Bag" and #Config.Bag.Cost
		or 1
end

-- (2026-10-04, "훈련도에 따라서 해당 부위에 이펙트") a track's look on the body at this level: 0, or the last of
-- Config.Training.LookShares of its top level the level reaches (1 to 5)
function Formulas.trainLookGrade(track, level)
	local share = (level or 0) / ((Config.Training.LookTop or {})[track] or Formulas.trainTop(track))
	local grade = 0
	for i, s in ipairs(Config.Training.LookShares) do
		if share >= s - 1e-9 then
			grade = i
		end
	end
	return grade
end

function Formulas.trainSeconds(track, level)
	local t = Config.Training.Tracks[track]
	if not t then
		return nil
	end
	local top = Formulas.trainTop(track)
	-- (slap and bag start at level 1, move speed, the speed track and the power steps at 0)
	local from = (track == "Slap" or track == "Bag") and level - 1 or level
	if level >= top then
		return nil
	end
	return math.min(t.First * t.Growth ^ from, Config.Training.CapSeconds) / (t.Pace or 1)
end

local function trainFirst(track)
	return (track == "Slap" or track == "Bag") and 1 or 0
end

local function trainBefore(track, done)
	local steps = Formulas.trainTop(track) - trainFirst(track)
	return math.floor(math.clamp(done, 0, steps) * (Config.Training.TopLevel - 1) / steps)
end

function Formulas.trainSubLevels(track, level)
	local first = trainFirst(track)
	if level == nil then
		return math.floor((Config.Training.TopLevel - 1) / (Formulas.trainTop(track) - first))
	end
	local done = math.floor(level) - first
	return math.max(1, trainBefore(track, done + 1) - trainBefore(track, done))
end

function Formulas.trainReal(track, level, xp)
	local need = Formulas.trainSeconds(track, level)
	if not need then
		return level
	end
	local n = Formulas.trainSubLevels(track, level)
	return level + math.clamp(math.floor((xp or 0) / (need / n)), 0, n - 1) / n
end

function Formulas.trained(upgrades, training)
	local t = training or {}
	local out = table.clone(upgrades)
	local steps = Config.Pickaxe.PowerSteps
	local before = (upgrades.PickaxeTier - 1) * steps
	out.PickaxePower = upgrades.PickaxePower < Formulas.powerStepsCap(upgrades.PickaxeTier)
		and Formulas.trainReal("Power", before + upgrades.PickaxePower, t.Power) - before or upgrades.PickaxePower
	out.PickaxeSpeed = Formulas.trainReal("Speed", upgrades.PickaxeSpeed, t.Speed)
	out.Slap = Formulas.trainReal("Slap", upgrades.Slap, t.Slap)
	out.MoveSpeed = Formulas.trainReal("MoveSpeed", upgrades.MoveSpeed, t.MoveSpeed)
	out.Bag = Formulas.trainReal("Bag", upgrades.Bag, t.Bag)
	return out
end

function Formulas.trainShownOf(track, real)
	local first = trainFirst(track)
	local steps = Formulas.trainTop(track) - first
	local done = math.floor(real - first + 1e-9)
	if done >= steps then
		return Config.Training.TopLevel
	end
	local n = Formulas.trainSubLevels(track, first + done)
	return trainBefore(track, done) + math.floor((real - first - done) * n + 0.5) + 1
end

function Formulas.trainRealOf(track, shown)
	local first = trainFirst(track)
	local steps = Formulas.trainTop(track) - first
	local k = math.clamp(shown - 1, 0, Config.Training.TopLevel - 1)
	local done = math.floor(k * steps / (Config.Training.TopLevel - 1))
	while done < steps and trainBefore(track, done + 1) <= k do
		done += 1
	end
	while done > 0 and trainBefore(track, done) > k do
		done -= 1
	end
	if done >= steps then
		return first + steps
	end
	return first + done + (k - trainBefore(track, done)) / Formulas.trainSubLevels(track, first + done)
end

function Formulas.trainValueText(track, real, short)
	if track == "MoveSpeed" then
		local v = Formulas.moveSpeed(real)
		if short then
			return string.format("🏃 %.2f", v)
		end
		return string.format("🏃 %.2f (+%.1f%%)", v, (v / Config.MoveSpeed.Base - 1) * 100)
	elseif track == "Speed" then
		local u = Config.Pickaxe.SpeedUpgrade
		return string.format("+%.1f%%", stepped(Formulas.frontLevel(real, 0, u.OldTop), u.OldTop, u.PerLevel, u.PerLevelAfter) * 100)
	elseif track == "Power" then
		return string.format("+%.1f%%", real * Config.Pickaxe.PowerPerStep * 100)
	elseif track == "Slap" then
		local targets = Formulas.slapFossilTargets(real)
		if short then
			return string.format("💨 %.1f · 🦴×%d · 👊%s", Formulas.slapKnockback(real), targets,
				Formulas.shortNumber(Formulas.slapFossilDamage(real)))
		end
		return string.format("💨 %.1f · 🦴 화석 %d마리 · 👊 %s", Formulas.slapKnockback(real), targets,
			Formulas.shortNumber(Formulas.slapFossilDamage(real)))
	end
	return string.format("💎 %s", Formulas.shortNumber(Formulas.bagCapacity(real, false)))
end

-- (2026-10-04, "훈련레벨을 아주아주 많이 늘리고") the training level shown for a track at this step (Formulas.trainLevel)
-- with xp seconds toward the next: every track goes to Config.Training.TopLevel, its steps sharing the levels evenly and a
-- step's seconds in equal parts. Returns the level (from 1), how far into it (0..1) and the top training level
function Formulas.trainShown(track, level, xp)
	local n = Formulas.trainSubLevels(track, level)
	local top = Config.Training.TopLevel
	local done = level - trainFirst(track)
	local need = Formulas.trainSeconds(track, level)
	if not need then
		return math.min(trainBefore(track, done) + 1, top), 1, top
	end
	local part = need / n
	local sub = math.clamp(math.floor((xp or 0) / part), 0, n - 1)
	return trainBefore(track, done) + sub + 1, math.clamp(((xp or 0) - sub * part) / part, 0, 1), top
end

-- a profile's level on a track (Power: over every tier) and whether it can go up now (power: not past the tier's steps)
function Formulas.trainLevel(upgrades, track)
	if track == "Power" then
		return (upgrades.PickaxeTier - 1) * Config.Pickaxe.PowerSteps + upgrades.PickaxePower,
			upgrades.PickaxePower < Formulas.powerStepsCap(upgrades.PickaxeTier)
	elseif track == "Speed" then
		return upgrades.PickaxeSpeed, true
	elseif track == "Slap" then
		return upgrades.Slap, true
	elseif track == "MoveSpeed" then
		return upgrades.MoveSpeed, true
	end
	return upgrades.Bag, true
end

-- the training boost's price at a defense level
function Formulas.trainBoostPrice(defenseLevel)
	local t = Config.Training
	return Formulas.upgradePrice(t.BoostBase * t.BoostGrowth ^ ((defenseLevel or 1) - 1), nil, 1)
end

-- (2026-10-04) 🔧 a training station's next gear level's price from this level, nil at the top
function Formulas.trainGearPrice(level, defenseLevel)
	local g = Config.Training.Gear
	level = level or 0
	if level >= g.Levels then
		return nil
	end
	return Formulas.upgradePrice(g.Base * g.Growth ^ level * Formulas.levelIndex(defenseLevel), nil, 1)
end

-- (2026-10-04) how fast training goes: × the station's gear, the boost and a friend near (seconds of training a second)
function Formulas.trainRate(gearLevel, boosted, withFriend)
	local t = Config.Training
	return (1 + t.Gear.PerLevel * (gearLevel or 0)) * (boosted and t.BoostMultiplier or 1)
		* (withFriend and 1 + t.FriendBonus or 1)
end

-- (2026-10-04) a beginner mission's reward in words (Config.StarterMissions; the board, the 🎁 window's 📋 tab and
-- the server's notice: StarterLogic.rewardText)
function Formulas.starterRewardText(reward)
	local parts = {}
	if (reward.Keys or 0) > 0 then
		table.insert(parts, string.format("🔑 열쇠 %d개", reward.Keys))
	end
	for _, t in ipairs(Config.Keys.Types) do
		local n = reward.SpecialKeys and reward.SpecialKeys[t.Id] or 0
		if n > 0 then
			table.insert(parts, string.format("🔑 %s %d개", t.Name, n))
		end
	end
	if (reward.KeyMoney or 0) > 0 then
		table.insert(parts, string.format("💰 열쇠 %d개 살 돈", reward.KeyMoney))
	end
	if (reward.LuckMinutes or 0) > 0 then
		table.insert(parts, string.format("🍀 뽑기 행운 ×%g %d분", Config.StarterMissions.LuckMultiplier, reward.LuckMinutes))
	end
	if (reward.SlapLevels or 0) > 0 then
		table.insert(parts, string.format("🖐️ 손바닥 +%d Lv", reward.SlapLevels * Formulas.trainSubLevels("Slap")))
	end
	if reward.GuaranteedRarity then
		local name = reward.GuaranteedRarity
		for _, r in ipairs(Config.Rarities) do
			if r.Id == name then
				name = r.Name
			end
		end
		table.insert(parts, string.format("✨ %s 이상 확정 뽑기 1번", name))
	end
	return table.concat(parts, " · ")
end

-- a row step's reward: the rarity's RowReward × the step's Times
function Formulas.rowReward(rarityId, step)
	local base = Config.Collection.Rows.RowReward[rarityId] or {}
	local out = { Keys = base.Keys and base.Keys * step.Times or nil, MoneyChests = base.MoneyChests and base.MoneyChests * step.Times or nil }
	if base.SpecialKeys then
		out.SpecialKeys = {}
		for id, n in pairs(base.SpecialKeys) do
			out.SpecialKeys[id] = n * step.Times
		end
	end
	return out
end

-- the collection milestones and row steps reached and not paid yet: { Kind = "Milestone" | "Row", Key, Reward,
-- Count (the milestone's) | Rarity, Species (the row step's) }; the service pays them and marks them (markCollectionPaid)
function Formulas.collectionDue(profile)
	local paid = profile.CollectionPaid or { Milestones = {}, Rows = {} }
	local count = 0
	for _ in pairs(profile.Collection or {}) do
		count += 1
	end
	local due = {}
	for _, m in ipairs(Config.Collection.Milestones) do
		local need = Formulas.milestoneCount(m)
		if count >= need and not paid.Milestones[tostring(need)] then
			table.insert(due, { Kind = "Milestone", Key = tostring(need), Reward = m.Reward, Count = need, Title = m.Title })
		end
	end
	local rows = Formulas.collectionRows(profile)
	for _, r in ipairs(Config.Rarities) do
		for _, step in ipairs(Config.Collection.Rows.Steps) do
			local key = r.Id .. ":" .. step.Species
			if (rows[r.Id] or 0) >= step.Species and not paid.Rows[key] then
				table.insert(due, { Kind = "Row", Key = key, Reward = Formulas.rowReward(r.Id, step), Rarity = r.Id,
					Species = step.Species })
			end
		end
	end
	return due
end

function Formulas.markCollectionPaid(profile, item)
	profile.CollectionPaid = profile.CollectionPaid or { Milestones = {}, Rows = {} }
	local list = item.Kind == "Milestone" and profile.CollectionPaid.Milestones or profile.CollectionPaid.Rows
	list[item.Key] = true
end

-- a registered dino's farm buff: its theme's kind and amount (Farm.BuffPerUnitByKind × rarity coefficient × size power)
function Formulas.farmBuff(unit)
	local species = SPECIES[unit.Species]
	local theme = THEMES[species.Theme]
	local rarity = RARITIES[unit.Rarity] or RARITIES.Common
	local size = DINO_SIZES[unit.Size] or DINO_SIZES.Young
	local amount = (Config.Farm.BuffPerUnitByKind[theme.FarmBuff] or Config.Farm.BuffPerUnit) * rarity.FarmCoefficient * size.Power
	if species.Theme == "Variant" then
		amount *= Config.Farm.VariantMultiplier
	end
	return theme.FarmBuff, amount
end

-- (2026-10-02) each farm bonus's cap; the farm slots pass raises them all (Farm.PassCapMultiplier: what was paid
-- for always adds, "현질엔 확실히 이득")
function Formulas.farmCaps(profile)
	local f = Config.Farm
	local m = profile and profile.Passes and profile.Passes.FarmSlots and f.PassCapMultiplier or 1
	return { UnitPower = f.UnitPowerCap * m, Money = f.MoneyCap * m, Mining = f.MiningCap * m,
		RareChance = f.RareChanceCap * m, MonsterSlow = m > 1 and math.min(f.MonsterSlowCap * m, f.PassSlowCapMax) or f.MonsterSlowCap }
end

-- every lasting bonus of a profile:
--   UnitPower (≤ Farm.UnitPowerCap), Money (≤ Farm.MoneyCap), MonsterSlow (≤ Farm.MonsterSlowCap), RareChance (≤ Farm.RareChanceCap), Mining (≤ Farm.MiningCap):
--     fractions added on top (0.1 = +10%); Slots: extra placement slots;
--   Collection: species × rarity pairs owned; ThemesComplete: { [theme Id] = true } (all its species owned)
function Formulas.bonuses(profile)
	local b = { UnitPower = 0, Money = 0, MonsterSlow = 0, RareChance = 0, Mining = 0, Slots = 0, Collection = 0,
		ThemesComplete = {} }
	local units = {}
	for _, u in ipairs(profile.Units or {}) do
		units[u.Id] = u
	end
	for id in pairs(profile.Farm or {}) do
		local u = units[id]
		if u and SPECIES[u.Species] then
			local kind, amount = Formulas.farmBuff(u)
			b[kind] += amount
		end
	end
	local speciesSeen = {}
	for key in pairs(profile.Collection or {}) do
		b.Collection += 1
		speciesSeen[string.match(key, "^([^/]+)")] = true
	end
	for _, reward in ipairs(Config.Farm.CollectionRewards) do
		if b.Collection >= reward.Count then
			if reward.Reward == "PlacementSlots" then
				b.Slots += reward.Amount
			else
				b[reward.Reward] += reward.Amount
			end
		end
	end
	for _, theme in ipairs(Config.Themes) do
		local all, any = true, false
		for _, s in ipairs(Config.Species) do
			if s.Theme == theme.Id and not s.MinRebirths and not s.HighRebirth then -- (the awakened variants: not needed, 2026-10-02)
				any = true
				all = all and speciesSeen[s.Id] == true
			end
		end
		if any and all then
			b.ThemesComplete[theme.Id] = true
		end
	end
	local caps = Formulas.farmCaps(profile)
	for kind, cap in pairs(caps) do
		b[kind] = math.min(b[kind], cap)
	end
	local rb = Formulas.rebirthBonuses(profile.Rebirths)
	b.Money += rb.Money
	b.UnitPower += rb.UnitPower -- rebirth's own, on top of the farm's caps
	b.RareChance += rb.RareChance
	b.Slots += rb.Slots
	return b
end

-- farm slots: StartSlots (the game pass and later rewards add up to MaxSlots)
-- farm slots: StartSlots + the slots bought at the farm sign (profile.Upgrades.FarmSlots), at most MaxSlots
function Formulas.farmSlots(profile)
	local bought = profile and profile.Upgrades and profile.Upgrades.FarmSlots or 0
	local pass = profile and profile.Passes and profile.Passes.FarmSlots and Config.GamePasses.FarmSlots.Slots or 0
	return math.min(Config.Farm.StartSlots + bought, Config.Farm.MaxSlots) + pass -- (the pass on top of the cap)
end

-- the next farm slot's price (bought = slots bought so far), nil when the farm is as big as it gets
function Formulas.nextFarmSlotCost(bought, level)
	local f = Config.Farm
	if f.StartSlots + bought >= f.MaxSlots then
		return nil
	end
	return Formulas.upgradePrice(f.SlotUpgrade.BaseCost * f.SlotUpgrade.Growth ^ bought * Formulas.levelIndex(level))
end

function Formulas.farmCount(profile)
	local n = 0
	for _ in pairs(profile.Farm or {}) do
		n += 1
	end
	return n
end

-- can this dino go to the farm? ok, or false and why (the server checks, the client shows)
function Formulas.canFarm(profile, unitId)
	local owned = false
	for _, u in ipairs(profile.Units) do
		owned = owned or u.Id == unitId
	end
	if not owned then
		return false, "없는 공룡이에요"
	elseif (profile.Farm or {})[unitId] then
		return false, "이미 농장에 있어요"
	elseif profile.Placed[unitId] then
		return false, "배치를 먼저 빼 주세요"
	elseif Formulas.farmCount(profile) >= Formulas.farmSlots(profile) then
		return false, string.format("🌾 농장이 꽉 찼어요 (%d칸)! ➕ 농장 표지판에서 늘려요", Formulas.farmSlots(profile))
	end
	return true
end

function Formulas.bestFarm(profile, keep)
	local f = Config.Farm
	local caps = Formulas.farmCaps(profile)
	local base = Formulas.bonuses(setmetatable({ Farm = {} }, { __index = profile }))
	local rebirth = Formulas.rebirthBonuses(profile.Rebirths)
	local used = {}
	local pool = {}
	local picked = {}
	for _, u in ipairs(profile.Units) do
		local kind, amount = Formulas.farmBuff(u)
		if keep and keep[u.Id] then
			used[kind] = (used[kind] or 0) + amount
			table.insert(picked, u.Id)
		elseif not profile.Placed[u.Id] then
			table.insert(pool, { Id = u.Id, Kind = kind, Amount = amount })
		end
	end
	table.sort(pool, function(a, b)
		if a.Amount ~= b.Amount then
			return a.Amount > b.Amount
		end
		return a.Id < b.Id
	end)
	for _ = #picked + 1, Formulas.farmSlots(profile) do
		local best, bestValue = nil, 0
		for i, c in ipairs(pool) do
			local room = (caps[c.Kind] or 0) - ((base[c.Kind] or 0) - (rebirth[c.Kind] or 0)) - (used[c.Kind] or 0)
			local value = math.min(c.Amount, math.max(0, room)) * (f.AutoWeights[c.Kind] or 0)
			if value > bestValue + 1e-12 then
				best, bestValue = i, value
			end
		end
		if not best then
			break
		end
		local c = table.remove(pool, best)
		used[c.Kind] = (used[c.Kind] or 0) + c.Amount
		table.insert(picked, c.Id)
	end
	return picked
end

-- placement slots of a profile: the start, bought on the sign, from rebirths and the collection
function Formulas.profileSlots(profile, bonuses)
	bonuses = bonuses or Formulas.bonuses(profile)
	local pass = profile.Passes and profile.Passes.PlacementSlot and Config.GamePasses.PlacementSlot.Slots or 0
	return Formulas.placementSlots(profile.Upgrades.Slots + bonuses.Slots + pass)
end

-- Robux key packs, the starter pack and VIP's daily keys: hours of the buyer's own key income at this level
-- (Config.Products.KeysPerHour × what a key brought home counts), whole keys
function Formulas.keyPackKeys(level, hours, hourly)
	local perHour = Config.Products.KeysPerHour * Formulas.homeKeyMultiplier(level)
	if hourly and hourly > 0 then
		perHour = math.max(perHour, hourly * Config.Products.KeyPackIncomeShare / Formulas.keyShopPrice(level))
	end
	return math.max(1, math.floor(perHour * hours + 0.5))
end

function Formulas.miniGameKeys(level, won)
	local c = Config.Ranked.PlayKeys
	return Formulas.keyPackKeys(level, (won and c.WinMinutes or c.Minutes) / 60)
end

-- (2026-10-02) a Robux key pack of these hours at this level: normal keys and gold keys, KeyPackGoldShare of
-- its worth in gold keys (at least one; a gold key is worth PriceMultiplier normal ones), the rest normal
function Formulas.keyPackSplit(level, hours, hourly)
	local total = Formulas.keyPackKeys(level, hours, hourly)
	local price = Formulas.keyType("Gold").PriceMultiplier -- (KEY_TYPES is made further down)
	local gold = math.max(1, math.floor(total * Config.Monetization.KeyPackGoldShare / price + 0.5))
	return math.max(0, total - gold * price), gold
end

-- the first key or money pack's extra hours (Config.Monetization): FirstPurchaseMultiplier times, at most
-- FirstPurchaseMaxBonusHours more (2026-10-02)
function Formulas.firstPurchaseBonusHours(hours)
	local m = Config.Monetization
	return math.min(hours * (m.FirstPurchaseMultiplier - 1), m.FirstPurchaseMaxBonusHours)
end

-- Robux money packs: hours of the buyer's own income (hourly: money earned an hour by playing)
function Formulas.moneyPackMoney(level, hourly, hours)
	local floor = Formulas.keyPackKeys(level, 1) * Config.Products.MoneyPackKeyShare * Formulas.keyShopPrice(level)
	return math.floor(math.max(hourly or 0, floor) * hours + 0.5)
end

-- minerals a turn gives with the mining bonus: base × (1 + bonus), the fraction as a chance (r in [0, 1))
function Formulas.bonusYield(base, mining, r)
	return math.floor(base * (1 + mining) + r)
end

-- a slap skin by Id (Config.Slap.Skins), or nil
function Formulas.skin(id)
	for _, s in ipairs(Config.Slap.Skins) do
		if s.Id == id then
			return s
		end
	end
	return nil
end

-- the skin drawn with this model (the player attribute SlapSkin is its model's name), or nil
function Formulas.skinByModel(model)
	for _, s in ipairs(Config.Slap.Skins) do
		if s.Model == model then
			return s
		end
	end
	return nil
end

-- how a slap skin is had, in words (the inventory's skin tab)
function Formulas.skinHowTo(skin)
	if skin.Theme then
		return string.format("%s 테마 완성", Formulas.theme(skin.Theme).Name)
	elseif skin.Collection then
		return string.format("도감 %d", skin.Collection)
	elseif skin.Rebirth then
		return string.format("환생 %d회", skin.Rebirth)
	elseif skin.Season then -- (2026-10-02) the season pass of that theme
		return string.format("%s 시즌 패스", Config.Season.Themes[skin.Season].Name)
	elseif skin.Event then -- (2026-10-04) every mission of that event (Config.LaunchEvent)
		return "🎉 이벤트 임무 모두"
	end
	return string.format("상점 %d R$", skin.Robux or 0)
end

-- collection skins earned but not unlocked yet: a theme with every species collected, or the collection
-- count reached (Config.Slap.Skins Theme / Collection); returns their Ids
function Formulas.newSkins(profile, bonuses)
	bonuses = bonuses or Formulas.bonuses(profile)
	local owned = profile.Skins or {}
	local list = {}
	for _, s in ipairs(Config.Slap.Skins) do
		local earned = (s.Theme and bonuses.ThemesComplete[s.Theme]) or (s.Collection and bonuses.Collection >= s.Collection)
			or (s.Rebirth and (profile.Rebirths or 0) >= s.Rebirth)
		if earned and not owned[s.Id] then
			table.insert(list, s.Id)
		end
	end
	return list
end

-- what this many rebirths give for good (Config.Rebirth, added up; slots at most MaxSlotsFromRebirth)
function Formulas.rebirthBonuses(rebirths)
	local r, n = Config.Rebirth, rebirths or 0
	return { Money = n * r.MoneyBonusPerRebirth, UnitPower = n * r.UnitPowerPerRebirth,
		RareChance = n * r.RareChancePerRebirth, Slots = math.min(n * r.SlotsPerRebirth, r.MaxSlotsFromRebirth) }
end

-- the keys the nth rebirth gives at once ({ [grade] = count }; the last row again after the list)
function Formulas.rebirthKeys(n)
	local list = Config.Rebirth.RewardKeys
	return list[math.clamp(n, 1, #list)]
end

function Formulas.rebirthSureRarities(n)
	local list = {}
	for _, r in ipairs(Config.Rarities) do
		if (r.UnlockRebirths or 0) == n and n > 0 then
			table.insert(list, r.Id)
		end
	end
	return list
end

-- the rebirth-only dino the nth rebirth gives (a Config.RebirthSpecies entry), or nil: each one at its
-- own rebirth, then one at random (random(k) in 1..k) every SpecialDinoEvery-th rebirth past the last
function Formulas.rebirthDino(n, random)
	local last = 0
	for _, s in ipairs(Config.RebirthSpecies) do
		if s.Rebirth == n then
			return s
		end
		last = math.max(last, s.Rebirth)
	end
	if n > last and n % Config.Rebirth.SpecialDinoEvery == 0 then
		return Config.RebirthSpecies[random(#Config.RebirthSpecies)]
	end
	return nil
end

-- its rarity: the best open at this level, SpecialRarityBelowTop grades down (at least the first)
function Formulas.rebirthDinoRarity(level)
	local best = 1
	for i, r in ipairs(Config.Rarities) do
		if Formulas.rarityOpen(r, level) then
			best = i
		end
	end
	return Config.Rarities[math.max(1, best - Config.Rebirth.SpecialRarityBelowTop)].Id
end

-- (2026-10-02, 점검) the best rarity drawn at its full chance at this level: open, and no longer at a share of
-- its chance (Gacha.NewRarityScale; a rarity just opened by an awakening is drawn far less at first). Its
-- number in Config.Rarities. The paid limited dino and the season dino are measured from it, so neither hands
-- out a rarity the draws still give only rarely.
function Formulas.fullTopRarity(level)
	local top = 1
	for i, r in ipairs(Config.Rarities) do
		if Formulas.rarityOpen(r, level) and Formulas.newRarityScale(r, level) >= 1 then
			top = i
		end
	end
	return top
end

function Formulas.sureRarity(level, belowTop, minRarity)
	local floor = RARITIES[minRarity .. "#"] or 1
	return Config.Rarities[math.max(floor, Formulas.fullTopRarity(level) - belowTop)].Id
end

-- the limited dino product's rarity at this level: the best rarity drawn at its full chance
-- (Formulas.fullTopRarity) RarityBelowTop grades down, at least MinRarity
function Formulas.limitedDinoRarity(level)
	local d = Config.Products.LimitedDino
	return Formulas.sureRarity(level, d.RarityBelowTop, d.MinRarity)
end

function Formulas.starterSureRarity(level)
	local s = Config.Products.StarterPack
	return Formulas.sureRarity(level, s.SureBelowTop, s.SureMinRarity)
end

-- rebirth n (0 = the first) costs 1M × 2.5^n
function Formulas.rebirthCost(rebirths, level)
	local r = Config.Rebirth
	return Formulas.upgradePrice(r.CostBase * r.CostGrowth ^ (rebirths or 0) * Formulas.levelIndex(level), nil,
		Config.Economy.RebirthPriceScale)
end

-- the highest real defense level with this many rebirths: the top of the tier (the next tier's start − 1)
function Formulas.maxDefenseLevel(rebirths)
	return tierStart((rebirths or 0) + 1) - 1
end

-- the level shown to players: it starts again at 1 in every tier (the real level goes on)
function Formulas.promotionSpawnRate(level)
	local P = Config.Defense.Promotion
	return math.clamp(P.SpawnRamp.First + (level - 2) * P.SpawnRamp.PerLevel, P.SpawnRamp.First, P.SpawnPerSecond)
end

function Formulas.shownLevel(level, rebirths)
	return math.max(1, level - tierStart(rebirths or 0) + 1)
end

-- the rebirth tier a real level is in (0 for LV 1-30, 1 for 31-130, ...): for players seen only by level
function Formulas.tierOfLevel(level)
	return tierOf(math.max(level, 1))
end

-- "LV 7" with the tier's mark and its 각성 ("🟢각성 LV 7" after one rebirth, "🔵2각성 LV 7" after two), so a
-- tier-2 LV 7 never looks like a first LV 7 (2026-10-01, "각성 12레벨이면 42레벨이 아니라 각성12레벨").
-- Every defense level shown anywhere goes through here (unlock levels too).
-- (2026-10-01, "37 here, 7 there: one way everywhere") the tier comes from the real level itself (a real
-- level always tells its tier), so a missing or late rebirth count can never show the real "LV 37";
-- the second argument is no longer needed
function Formulas.levelText(level)
	local marks = Config.Rebirth.TierMarks
	local tier = tierOf(math.max(level or 1, 1))
	local awakened = tier == 0 and "" or tier == 1 and "환생 " or (tier .. "환생 ")
	return marks[math.min(#marks, tier + 1)] .. awakened .. "LV " .. Formulas.shownLevel(level, tier)
end

-- can this profile rebirth now (at the top of its tier)? ok, or false and why (money is checked when paid)
function Formulas.canRebirth(profile)
	if profile.DefenseLevel < Formulas.maxDefenseLevel(profile.Rebirths) then
		return false, string.format("🔄 디펜스 최대 레벨 %s에서 환생할 수 있어요",
			Formulas.levelText(Formulas.maxDefenseLevel(profile.Rebirths)))
	end
	return true
end

-- a rebirth after paying: the next tier opens and the shown level starts at LV 1 (the real level goes
-- one up, past the tier's top); pickaxe, bag, slap, move speed stay; the bonuses grow (rebirthBonuses).
-- The rewards at once: the keys (rebirthKeys) and maybe a rebirth-only dino (rebirthDino, random(k) in
-- 1..k). Returns the new dino's record or nil
function Formulas.applyRebirth(profile, random)
	profile.Rebirths = (profile.Rebirths or 0) + 1
	profile.DefenseLevel = math.max(profile.DefenseLevel, tierStart(profile.Rebirths))
	for grade, count in pairs(Formulas.rebirthKeys(profile.Rebirths)) do
		Formulas.addSavedKeys(profile, grade, count)
	end
	for _, id in ipairs(Formulas.rebirthSureRarities(profile.Rebirths)) do
		profile.GuaranteedDraws = profile.GuaranteedDraws or {}
		profile.GuaranteedDraws[id] = (profile.GuaranteedDraws[id] or 0) + 1
	end
	local species = Formulas.rebirthDino(profile.Rebirths, random or function(k)
		return k
	end)
	if not species then
		return nil
	end
	local unit = { Id = "U" .. profile.NextUnitId, Species = species.Id,
		Rarity = Formulas.rebirthDinoRarity(profile.DefenseLevel), Size = Config.Rebirth.SpecialSize }
	profile.NextUnitId += 1
	table.insert(profile.Units, unit)
	profile.RebirthGifts = profile.RebirthGifts or {}
	profile.RebirthGifts[species.Id] = true
	return unit
end

function Formulas.missedRebirthDinos(profile)
	local list = {}
	local given = profile.RebirthGifts or {}
	for _, s in ipairs(Config.RebirthSpecies) do
		if s.CatchUp and s.Rebirth <= (profile.Rebirths or 0) and not given[s.Id] then
			local owned = false
			for _, u in ipairs(profile.Units or {}) do
				owned = owned or u.Species == s.Id
			end
			if not owned then
				table.insert(list, s)
			end
		end
	end
	return list
end

function Formulas.giveMissedRebirthDinos(profile)
	local units = {}
	for _, s in ipairs(Formulas.missedRebirthDinos(profile)) do
		local unit = { Id = "U" .. profile.NextUnitId, Species = s.Id,
			Rarity = Formulas.rebirthDinoRarity(tierStart(s.Rebirth)), Size = Config.Rebirth.SpecialSize }
		profile.NextUnitId += 1
		table.insert(profile.Units, unit)
		table.insert(units, unit)
	end
	profile.RebirthGifts = profile.RebirthGifts or {}
	for _, s in ipairs(Config.RebirthSpecies) do
		if s.Rebirth <= (profile.Rebirths or 0) then
			profile.RebirthGifts[s.Id] = true
		end
	end
	return units
end

-- ---------------------------------------------------------------------------
-- PvP: the battlefield, slaps, central keys (design 2.5-2.7, 7)
-- ---------------------------------------------------------------------------

-- how far a hit throws the target (studs), by the slapper's level
function Formulas.slapKnockback(level)
	local s = Config.Slap
	return math.floor(Formulas.tableAt(s.Knockback, Formulas.frontLevel(level, 1, s.OldTop)) * 10 + 0.5) / 10
end

-- fossils one slap hits at this slap level (nearest first)
function Formulas.slapFossilTargets(slapLevel)
	local s = Config.Slap
	local top = s.OldTop or math.huge
	local before = s.FossilTargetsBase + math.floor((math.min(slapLevel, top) - 1) / s.FossilTargetsEveryLevels)
	local after = math.floor(math.max(0, slapLevel - top) / (s.FossilTargetsEveryLevelsAfter or s.FossilTargetsEveryLevels))
	return math.min(s.FossilTargetsMax or math.huge, before + after)
end

function Formulas.slapFossilDamage(slapLevel)
	local s = Config.Slap
	return math.floor(s.FossilDamage * s.FossilDamageGrowth ^ (math.max(slapLevel, 1) - 1) + 0.5)
end

function Formulas.helpSlapLevel(helperLevel, ownerLevel)
	return math.max(1, math.min(helperLevel or 1, ownerLevel or 1))
end

-- the night's boss zombie (design 2.12): its stage for this many players, a slap's damage by slap level
function Formulas.bossStage(players)
	local stage = Config.Zombies.Boss.Stages[1]
	for _, s in ipairs(Config.Zombies.Boss.Stages) do
		if players >= s.MinPlayers then
			stage = s
		end
	end
	return stage
end

-- (2026-10-04, "보스들 인원수에 맞춰서 … 혼자인데 보스를 잡을 수가 없네 … 그만큼 보상도 적어지고") the night boss's
-- health and the share of each hitter's reward, with this many players on the server
function Formulas.bossPower(slapLevel)
	return Formulas.bossSlapDamage(slapLevel or 1) ^ Config.Zombies.Boss.PowerExponent
end

function Formulas.bossHealth(players, power)
	return Config.Zombies.Boss.HealthPerPlayer * math.max(1, power or players)
end

function Formulas.bossChests()
	return Config.Zombies.Boss.Chests
end

function Formulas.bossRewardShare(players)
	return math.min(1, math.max(1, players) / Config.Zombies.Boss.RewardFullPlayers)
end

-- a reward table (RewardLogic) × share: money chests and key hours as they come, keys and special keys rounded
-- (plain keys at least 1 when it had some)
function Formulas.scaleReward(reward, share)
	local out = {}
	for k, v in pairs(reward) do
		if k == "SpecialKeys" then
			local keys = {}
			for id, n in pairs(v) do
				local m = math.floor(n * share + 0.5)
				if m > 0 then
					keys[id] = m
				end
			end
			out[k] = next(keys) and keys or nil
		elseif k == "Keys" then
			out[k] = v > 0 and math.max(1, math.floor(v * share + 0.5)) or v
		elseif k == "MoneyChests" or k == "KeyHours" then
			out[k] = v * share
		else
			out[k] = v
		end
	end
	return out
end

-- the boss kind with this Id (Config.Zombies.Boss.Kinds), the first one if unknown
function Formulas.bossKind(id)
	for _, kind in ipairs(Config.Zombies.Boss.Kinds) do
		if kind.Id == id then
			return kind
		end
	end
	return Config.Zombies.Boss.Kinds[1]
end

-- (2026-10-04, the night boss's ②) the 🦴 bone dino of that boss kind (Config.GiftSpecies with that BossKind), nil if none
function Formulas.boneDino(kindId)
	for _, s in ipairs(Config.GiftSpecies or {}) do
		if s.BossKind == kindId then
			return s
		end
	end
	return nil
end

-- (2026-10-04, the night boss's ③) the hunt title reached with this many hunts (Config.Zombies.Boss.HuntTitles, the best
-- row; nil before the first) and the next row (nil after the last)
function Formulas.huntTitle(hunts)
	local title, nextRow = nil, nil
	for _, row in ipairs(Config.Zombies.Boss.HuntTitles) do
		if hunts >= row.Hunts then
			title = row
		elseif not nextRow then
			nextRow = row
		end
	end
	return title, nextRow
end

-- tonight's boss kind: a random one (r in [0, 1)), never the same as last night's
function Formulas.pickBossKind(lastId, r)
	local list = {}
	for _, kind in ipairs(Config.Zombies.Boss.Kinds) do
		if kind.Id ~= lastId then
			table.insert(list, kind)
		end
	end
	if #list == 0 then
		list = Config.Zombies.Boss.Kinds
	end
	return list[math.min(#list, math.floor(r * #list) + 1)]
end

-- the day buff's multiplier for this effect ("Money", "Defense", "Mining"): its Multiplier while the
-- active buff (ReplicatedStorage attribute DayBuff) is that one, else 1
function Formulas.dayBuff(active, effect)
	local buff = active == effect and Config.DayBuffs[effect]
	return buff and buff.Multiplier or 1
end

-- a key chest's keys at this defense level
function Formulas.bossKeyChest(level)
	local k = Config.Zombies.Boss.KeyChest
	return math.min(k.Max, k.Base + math.floor((level - 1) / k.PerLevels))
end

-- a mineral chest: the best grade this pickaxe tier mines well (its RecommendedTier at most the tier),
-- the smallest size, and how many make `money` worth at this defense level (at least 1)
function Formulas.bossMineralChest(tier, money, level)
	local best = Config.Minerals.Grades[1]
	for _, grade in ipairs(Config.Minerals.Grades) do
		if grade.RecommendedTier <= tier then
			best = grade
		end
	end
	local size = Config.Minerals.Sizes[1]
	return best.Id, size.Id, math.max(1, math.floor(money / (best.Value * size.ValueMultiplier * Formulas.mineralLevelMultiplier(level)) + 0.5))
end

-- a bomb kind (Config.Bombs.Kinds) by Id
function Formulas.bombKind(id)
	for _, k in ipairs(Config.Bombs.Kinds) do
		if k.Id == id then
			return k
		end
	end
	return nil
end

-- one bomb's price at this defense level: PriceShopKeyMultiplier × the shop's normal key (whole money)
function Formulas.bombPrice(level, id)
	local k = Formulas.bombKind(id)
	return k and math.floor(Formulas.keyShopPrice(level) * k.PriceShopKeyMultiplier + 0.5) or nil
end

function Formulas.bossSlapDamage(level)
	local per, top = Config.Zombies.Boss.DamagePerLevel, Config.Slap.OldTop
	return 1 + stepped(level - 1, top and top - 1, per, per * (Config.Slap.BossDamageAfterShare or 1))
end

-- what a bomb of this kind takes from a boss, thrown at this slap level (0 for a kind that doesn't hurt)
function Formulas.bombBossDamage(slapLevel, id)
	local k = Formulas.bombKind(id)
	return k and k.BossDamageMultiplier and Formulas.bossSlapDamage(slapLevel) * k.BossDamageMultiplier or 0
end

-- money for taking `damage` of a boss's health, at the hitter's defense level (before money boosts)
function Formulas.bossHitMoney(defenseLevel, damage, multiplier)
	return math.floor(damage * Config.Zombies.Boss.MoneyPerDamage * (multiplier or 1)
		* Formulas.treasureMoney(defenseLevel, 0.5) + 0.5)
end

-- the money buff for Roblox friends on the same server (Config.Friends): 1 + BoostPerFriend × friends, capped
function Formulas.friendBoost(friends)
	local f = Config.Friends
	return 1 + f.BoostPerFriend * math.clamp(friends or 0, 0, f.MaxFriends)
end

-- keys found in `amount` minerals of this grade and size mined at this defense level
-- (Config.Mining.KeyFindShare), with random() in [0, 1)
function Formulas.treasureKey(bagLevel, r)
	local list = Config.Minerals.Special.BagKeys
	for i = #list, 1, -1 do
		local k = list[i]
		if (bagLevel or 1) >= k.Step then
			if r * 100 < k.Percent then
				return k.Key
			end
			r -= k.Percent / 100
			if r < 0 then
				return nil
			end
		end
	end
	return nil
end

function Formulas.bagKeyMultiplier(bagLevel)
	return 1 + Config.Mining.BagKeyBonus * math.max(0, (bagLevel or 1) - 1)
end

function Formulas.mineKeyChance(gradeId, sizeId, level, bagLevel)
	local value = Formulas.grade(gradeId).Value * Formulas.size(sizeId).ValueMultiplier
	return math.min(1, value * Config.Mining.KeyFindShare / Formulas.keyShopPrice(level, "Normal")
		* Formulas.bagKeyMultiplier(bagLevel) * Formulas.homeKeyMultiplier(level))
end

function Formulas.mineKeys(amount, gradeId, sizeId, level, random, bagLevel)
	local chance = Formulas.mineKeyChance(gradeId, sizeId, level, bagLevel)
	local found = 0
	for _ = 1, amount do
		if random() < chance then
			found += 1
		end
	end
	return found
end

-- the keys a won promotion to `level` pays: { Normal = n, [better grade] = 1 at a milestone level }
function Formulas.promoKillsNeeded(level)
	local g = Config.Defense.Promotion.Gauge
	local shown = level - tierStart(Formulas.tierOfLevel(level)) + 1
	return math.min(g.KillsMax, g.KillsBase + g.KillsPerLevel * math.max(0, shown - 2))
end

function Formulas.bossAirships(level)
	local n = 0
	for _, row in ipairs(Config.Defense.Airships.Times) do
		if level >= row.Level then
			n += 1
		end
	end
	return n
end

function Formulas.bossCrowdCount(level)
	local g = Config.Defense.Promotion.Gauge
	local c = g.Crowd
	return math.max(c.Base, math.min(c.Max, c.Base + c.PerLevel * math.max(0, level - 2)) - g.AirshipBudget * Formulas.bossAirships(level))
end

function Formulas.bossAirshipHealth(level)
	local h = Config.Defense.Promotion.Gauge.AirshipHealth
	local first = Config.Defense.Airships.Times[1].Level
	return h.From + (h.To - h.From) * math.clamp((level - first) / h.Levels, 0, 1)
end

function Formulas.promotionBaseKeys(level)
	local p = Config.Defense.Promotion
	return p.KeysBase + math.floor(level / p.KeysEveryLevels)
end

function Formulas.promotionKeys(level)
	return { Normal = math.max(Formulas.promotionBaseKeys(level) - Config.Defense.Promotion.RoadKeys, 0) }
end

function Formulas.promotionBox(level)
	local at = fossilLevel(level)
	for _, m in ipairs(Config.Defense.Promotion.Milestones) do
		if at % m.Every == 0 then
			return m.Grade
		end
	end
	return "Normal"
end

function Formulas.promotionBoxName(grade)
	local names = Config.Defense.Promotion.BoxNames
	return names[grade] or names.Normal
end

function Formulas.promotionFirstWin(level)
	for _, w in ipairs(Config.Defense.Promotion.FirstWins or {}) do
		if w.Level == level then
			return w
		end
	end
	return nil
end

function Formulas.promotionPrizeParts(level)
	local parts = { Formulas.promotionBoxName(Formulas.promotionBox(level)) }
	local keys = Formulas.promotionKeys(level)
	local w = Formulas.promotionFirstWin(level) or {}
	if w.GuaranteedRarity then
		table.insert(parts, string.format("🎰 %s 확정 뽑기", Formulas.rarity(w.GuaranteedRarity).Name))
	end
	for i = #Config.Keys.Types, 1, -1 do
		local t = Config.Keys.Types[i]
		local n = t.Id ~= "Normal" and (keys[t.Id] or 0) + ((w.SpecialKeys or {})[t.Id] or 0) or 0
		if n > 0 then
			table.insert(parts, string.format("🔑 %s %d개", t.Name, n))
		end
	end
	local species = 0
	for _, s in ipairs(Config.Species) do
		if s.UnlockLevel == level then
			species += 1
		end
	end
	if species > 0 then
		table.insert(parts, string.format("🦖 새 공룡 %d종", species))
	end
	if #Formulas.mapsOpenedAt(level) > 0 then
		table.insert(parts, "🗺️ 새 맵")
	end
	if w.LuckMinutes then
		table.insert(parts, string.format("🍀 행운 %d분", w.LuckMinutes))
	end
	local plain = (keys.Normal or 0) + (w.Keys or 0)
	if plain > 0 then
		table.insert(parts, string.format("🔑 열쇠 %d개", plain))
	end
	return parts
end

-- may this slapper get the bounty money now? bounty = profile.Bounty { Day, Money, LastMoney (os.time) },
-- day = today's number. At most Config.Keys.BountyMoneyPerDay a day, BountyMoneyCooldown apart (saved, so
-- leaving and coming back or changing servers doesn't start them over)
function Formulas.bountyMoneyReady(bounty, now, day)
	local k = Config.Keys
	local today = bounty.Day == day and bounty.Money or 0
	return today < k.BountyMoneyPerDay and now - (bounty.LastMoney or 0) >= k.BountyMoneyCooldown
end

function Formulas.slapScale(level)
	local s = Config.Slap
	return Formulas.tableAt(s.Scale, Formulas.frontLevel(level, 1, s.OldTop))
end

function Formulas.slapReach(level)
	return Config.Slap.ReachBase + Config.Slap.ReachPerScale * (Formulas.slapScale(level) - 1)
end

-- character upgrades (design 6, 7): the price of the next level, nil at the top
function Formulas.nextSlapCost(level)
	return Formulas.upgradePrice(Config.Slap.Cost[level + 1], (level - 1) / (#Config.Slap.Cost - 2))
end

local function roundPrice(x) -- two significant digits, like the design's tables
	if x < 100 then
		return math.floor(x + 0.5)
	end
	local unit = 10 ^ (math.floor(math.log10(x)) - 1)
	return math.floor(x / unit + 0.5) * unit
end

-- move speed level n costs CostBase × CostGrowth^(n − 1) (× the upgrade price scale and the late rise)
function Formulas.nextMoveSpeedCost(level)
	local m = Config.MoveSpeed
	return level < m.Levels and Formulas.upgradePrice(roundPrice(m.CostBase * m.CostGrowth ^ level), level / (m.Levels - 1)) or nil
end

function Formulas.moveSpeed(level)
	local m = Config.MoveSpeed
	return m.Base + stepped(Formulas.frontLevel(level, 0, m.OldTop), m.OldTop, m.PerLevel, m.PerLevelAfter)
end

-- weather (Config.Weather): its type by Id (Clear when unknown), and the roll with r in [0, 1)
local WEATHER = index(Config.Weather.Types)
function Formulas.weather(id)
	return WEATHER[id or "Clear"] or WEATHER.Clear
end

-- the weather a usual roll brings (r in [0, 1)); a night-only one (the aurora) is rolled at nightfall
-- instead (Formulas.rollNightWeather), so here it stays clear
function Formulas.rollWeather(r)
	local w = Formulas.pickWeighted(Config.Weather.Types, "ChancePercent", r)
	return w.NightOnly and "Clear" or w.Id
end

-- the night-only weather nightfall brings (r in [0, 1)), or nil: each at its ChancePercent
function Formulas.rollNightWeather(r)
	local edge = 0
	for _, w in ipairs(Config.Weather.Types) do
		if w.NightOnly then
			edge += w.ChancePercent / 100
			if r < edge then
				return w.Id
			end
		end
	end
	return nil
end

-- the aurora boss's health with this many players on the server
function Formulas.auroraBossHealth(players, power)
	return Config.Zombies.AuroraBoss.HealthPerPlayer * math.max(1, power or players)
end

function Formulas.auroraChests()
	local out = {}
	for kind, n in pairs(Config.Zombies.AuroraBoss.Chests) do
		out[kind] = n
	end
	return out
end

-- how long a speed pad's boost lasts: longer while carrying keys
function Formulas.speedPadSeconds(carrying)
	local c = Config.SpeedPads
	return carrying and c.CarryBoostSeconds or c.BoostSeconds
end

-- seconds between central keys: slower when few players are on the server
function Formulas.keySpawnInterval(playerCount)
	local k = Config.Keys
	return playerCount <= Config.Server.LowPopulationMaxPlayers and k.LowPopulationSpawnInterval or k.SpawnInterval
end

function Formulas.carrySpeed(walkSpeed, multiplier)
	return walkSpeed * math.clamp(multiplier or 1, Config.AltarBoxes.CarrySpeedMin, 1)
end

function Formulas.boxCarrySpeed(sizes)
	local a = Config.AltarBoxes
	local slow = 0
	for _, sizeId in ipairs(sizes) do
		slow += a.CarrySlowPerBox + a.CarrySlowPerSize * (math.max(Formulas.dinoSizeRank(sizeId), 1) - 1)
	end
	return math.max(a.CarrySpeedMin, 1 - slow)
end

function Formulas.guardianCount(players, tutorial)
	return tutorial and 0 or math.max(0, math.floor(players))
end

function Formulas.guardianSpeed(rarityId, sizeId)
	local g = Config.Zombies.Guardians
	local rank = math.max(Formulas.rarityRank(rarityId), 1)
	local hard = Formulas.rarityRank(g.HardFrom)
	local speed = rank >= hard and g.HardBase * g.HardGrowth ^ (rank - hard) or g.ChaseBase + g.ChasePerRarity * (rank - 1)
	speed *= 1 + g.ChasePerSize * (math.max(Formulas.dinoSizeRank(sizeId), 1) - 1)
	return math.min(speed, g.ChaseMax)
end

function Formulas.guardianEscapeLevel(rarityId, sizeId, carrySlow)
	local need = Formulas.guardianSpeed(rarityId, sizeId) / math.clamp(carrySlow or 1, Config.AltarBoxes.CarrySpeedMin, 1)
	local top = Formulas.trainTop("MoveSpeed")
	if Formulas.moveSpeed(0) > need then
		return 0
	elseif Formulas.moveSpeed(top) <= need then
		return nil
	end
	local lo, hi = 0, top
	for _ = 1, 40 do
		local mid = (lo + hi) / 2
		if Formulas.moveSpeed(mid) > need then
			hi = mid
		else
			lo = mid
		end
	end
	return Formulas.trainShownOf("MoveSpeed", hi)
end

function Formulas.boxChase(box)
	if box.King then
		local k = Config.AltarBoxes.KingChase
		return k.Rarity, k.Size
	end
	return box.Rarity, box.Size
end

function Formulas.altarBoxRoll(level, grade, random, luck, luckCap)
	local up = Formulas.nextKeyType(grade)
	if up and random() < Formulas.homeUpgradeChance(level) then
		grade = up.Id
	end
	local odds = Formulas.gachaOdds(level, { keyType = grade, luck = luck or 1, luckCap = luckCap })
	local draw = Formulas.rollDraw(odds, random(), random(), random(), random(), random())
	return { Rarity = draw.Rarity, Size = draw.Size, Mutation = draw.Mutation, Grade = grade }
end

function Formulas.boxPickable(box, level)
	if box.King then
		return true
	end
	local r = RARITIES[box.Rarity]
	return r ~= nil and Formulas.rarityOpen(r, Formulas.keyRarityLevel(level, box.Grade))
end

function Formulas.boxLockRebirths(box)
	local r = not box.King and RARITIES[box.Rarity]
	local n = r and r.UnlockRebirths or 0
	local t = Formulas.keyType(box.Grade or "Normal")
	local shop = t and t.ShopRebirths or 0
	return n > shop and n or 0
end

-- ---------------------------------------------------------------------------
-- Keys and draws (design 4.3-4.6; the odds window shows exactly these numbers)
-- ---------------------------------------------------------------------------

local KEY_TYPES = index(Config.Keys.Types)
-- (2026-10-01) the king key: on the ground and carried like a grade (its look and name), never saved as one
KEY_TYPES.King = Config.Keys.King
KEY_TYPES["King#"] = Config.Keys.King.Size

function Formulas.keyType(id)
	return KEY_TYPES[id]
end

-- saved keys of a grade: normal keys are profile.Keys (the leaderboard's), the others SpecialKeys
function Formulas.savedKeys(profile, typeId)
	if typeId == nil or typeId == "Normal" then
		return profile.Keys
	end
	return profile.SpecialKeys and profile.SpecialKeys[typeId] or 0
end

function Formulas.addSavedKeys(profile, typeId, count)
	if typeId == nil or typeId == "Normal" then
		profile.Keys += count
	else
		profile.SpecialKeys[typeId] = (profile.SpecialKeys[typeId] or 0) + count
	end
end

-- bringing carried keys home (Config.Keys): each counts this many saved keys at this defense level
function Formulas.homeKeyMultiplier(level)
	local k = Config.Keys
	return k.HomeValue * (1 + k.HomeValuePerLevel * (level - 1))
end

-- the chance each key brought home comes up one grade, at this defense level
function Formulas.homeUpgradeChance(level)
	local k = Config.Keys
	return math.min(k.HomeUpgradeMax, k.HomeUpgradePerLevel * (level - 1))
end

-- what carried keys { [grade] = n } become at home: a king key turns into King.Value normal keys first;
-- each may go one grade up (homeUpgradeChance). random() -> [0, 1). Returns saved { [grade] = n }, how many went up.
function Formulas.bankKeys(counts, level, random)
	local chance = Formulas.homeUpgradeChance(level)
	local kept, upgraded = {}, 0
	counts = table.clone(counts)
	if counts.King then
		counts.Normal = (counts.Normal or 0) + counts.King * Config.Keys.King.Value
		counts.King = nil
	end
	for id, n in pairs(counts) do
		local up = Formulas.nextKeyType(id)
		for _ = 1, n do
			if up and random() < chance then
				kept[up.Id] = (kept[up.Id] or 0) + 1
				upgraded += 1
			else
				kept[id] = (kept[id] or 0) + 1
			end
		end
	end
	return kept, upgraded
end

-- the next key grade up from this one (Config.Keys.Types order), nil for the best
function Formulas.nextKeyType(typeId)
	for i, t in ipairs(Config.Keys.Types) do
		if t.Id == typeId then
			return Config.Keys.Types[i + 1]
		end
	end
	return nil
end

-- what a key grade's draw is, in words: "기본 확률" or "은 열쇠 50번 중 최고" (keyPicks)
function Formulas.keyDrawText(typeId)
	local prev = nil
	for _, t in ipairs(Config.Keys.Types) do
		if t.Id == typeId then
			break
		end
		prev = t
	end
	local t = KEY_TYPES[typeId]
	local cap = t and t.MaxRarity and (" · " .. RARITIES[t.MaxRarity].Name .. "까지") or ""
	if t and t.FloorRarity then -- (2026-10-02) never below it
		cap = " · " .. string.format("%s 이상", RARITIES[t.FloorRarity].Name) .. cap
	end
	if not prev then
		return "기본 확률" .. cap
	end
	return string.format("%s %d번 중 최고%s", prev.Name, Formulas.exchangeRate(prev.Id), cap)
end

-- what a key grade gives at this level, for the key shop (2026-10-01): the best rarity it can bring now
-- and how often, whether that is no better than the grade below's (its extra picks then go to the size),
-- and its mutation chance
function Formulas.keyOutlook(level, typeId)
	local function top(id)
		local odds = Formulas.gachaOdds(level, { keyType = id })
		local best, percent = nil, 0
		for _, r in ipairs(odds.Rarities) do
			if r.Percent > 0 then
				best, percent = r.Id, r.Percent
			end
		end
		return best, percent, odds.MutationPercent
	end
	local best, percent, mutation = top(typeId)
	local below = nil
	for _, t in ipairs(Config.Keys.Types) do
		if t.Id == typeId then
			break
		end
		below = t.Id
	end
	local same = false
	if below then
		local belowBest, belowPercent = top(below)
		same = belowBest == best and belowPercent >= 99.9
	end
	return { Rarity = best, Percent = percent, SameAsBelow = same, Mutation = mutation }
end

-- the key stall's exchange: up to `times` × ExchangeRate keys of fromId become as many of the next
-- grade up; returns how many were made (0 when there are not enough or no grade above)
-- how many keys of a grade the exchange takes for one of the next grade up (Config.Keys.ExchangeRates)
function Formulas.exchangeRate(fromId)
	local k = Config.Keys
	return k.ExchangeRates and k.ExchangeRates[fromId] or k.ExchangeRate
end

function Formulas.exchangeKeys(profile, fromId, times)
	local up = Formulas.nextKeyType(fromId)
	local rate = Formulas.exchangeRate(fromId)
	if not up or not KEY_TYPES[fromId] or not Formulas.keyShopOpen(up.Id, profile.Rebirths) then
		return 0
	end
	local n = math.min(math.floor(times), Config.Keys.ExchangeMaxAtOnce, Formulas.savedKeys(profile, fromId) // rate)
	if n <= 0 then
		return 0
	end
	Formulas.addSavedKeys(profile, fromId, -n * rate)
	Formulas.addSavedKeys(profile, up.Id, n)
	return n
end

-- may a player with this many awakenings buy this key grade at the stall, or exchange into it?
-- (Config.Keys.Types ShopRebirths; 2026-10-02) and the awakening it opens with, in words
function Formulas.keyShopOpen(typeId, rebirths)
	local t = KEY_TYPES[typeId or "Normal"]
	return t ~= nil and (rebirths or 0) >= (t.ShopRebirths or 0)
end
function Formulas.keyShopCondition(typeId)
	local t = KEY_TYPES[typeId or "Normal"]
	return Formulas.rarityCondition({ UnlockRebirths = t and t.ShopRebirths or 0 })
end

-- the price of one key of this grade in the shop (default: normal), in whole game money
function Formulas.keyShopPrice(level, typeId)
	local t = KEY_TYPES[typeId or "Normal"]
	return math.floor(Formulas.keyPrice(level) * Config.Keys.ShopPriceMultiplier * t.PriceMultiplier + 0.5)
end

function Formulas.keyBuyPrice(level, typeId, count)
	local off = Config.Gacha.KeyBulkDiscount[count] or 0
	return math.floor(Formulas.keyShopPrice(level, typeId) * count * (1 - off) + 0.5)
end

function Formulas.keyBulkOff(count)
	return Config.Gacha.KeyBulkDiscount[count] or 0
end

-- is a racer blocked by a race obstacle (Formulas.raceLayout's list: { x, z, kind, across, along, height,
-- angle, moving })? pos: the racer's flat position; feet: the height of their feet (the mount's, riding);
-- airborne: jumping or falling; shrink: studs inside the obstacle's sides that count (lag). Inside an
-- obstacle below its top, or standing on top of one (not in the air): a rider's character floats at the
-- mount's height and steps up onto anything lower, so walking over a crate or a hurdle has to count as
-- hitting it; a hurdle is passed by jumping. Moving ones (swing, spinner) only count on the racer's screen.
function Formulas.raceObstacleHit(list, pos, feet, airborne, roadTop, shrink)
	local onTop = Config.Race.ObstacleStandSlack
	for i, o in ipairs(list or {}) do
		if not o[8] then
			local a = math.rad(o[7])
			local ahead, out = Vector3.new(math.cos(a), 0, math.sin(a)), Vector3.new(math.sin(a), 0, -math.cos(a))
			local d = Vector3.new(pos.X - o[1], 0, pos.Z - o[2])
			local top = roadTop + o[6]
			if math.abs(d:Dot(out)) < o[4] / 2 - shrink and math.abs(d:Dot(ahead)) < o[5] / 2 - shrink
				and (feet < top - 1 or (not airborne and feet < top + onTop)) then
				return i
			end
		end
	end
	return nil
end

-- (2026-10-04, "레이스 경우에 자꾸 장애물에 밀려나는게 조금 부자연 스럽고") the farthest point on the way from `from`
-- (clear) to `to` (blocked) that is still clear of every obstacle (Formulas.raceObstacleHit): a racer run into one stops
-- at its face, like hitting a wall (it was put back to its last clear spot, often studs back: a jump backwards)
function Formulas.raceClearPoint(list, from, to, feet, airborne, roadTop, shrink)
	local lo, hi = 0, 1 -- (lo clear, hi blocked)
	for _ = 1, 8 do
		local mid = (lo + hi) / 2
		if Formulas.raceObstacleHit(list, from:Lerp(to, mid), feet, airborne, roadTop, shrink) then
			hi = mid
		else
			lo = mid
		end
	end
	return from:Lerp(to, lo)
end

-- take one of the profile's guaranteed draws (profile.GuaranteedDraws { [rarity Id] = n }), the best
-- rarity first: that rarity's Id, or nil when there is none
function Formulas.takeGuaranteedDraw(profile)
	local best, bestRank = nil, 0
	for id, n in pairs(profile.GuaranteedDraws or {}) do
		local rank = RARITIES[id .. "#"]
		if n > 0 and rank and rank > bestRank then
			best, bestRank = id, rank
		end
	end
	if best then
		profile.GuaranteedDraws[best] -= 1
		if profile.GuaranteedDraws[best] <= 0 then
			profile.GuaranteedDraws[best] = nil
		end
	end
	return best
end

-- the bulk draw button: all the keys of the grade up to Gacha.MaxDrawCount (at least 2, or it is the
-- 1-draw button's job; with fewer keys it shows MaxDrawCount and cannot be pressed)
function Formulas.bulkDrawCount(keys)
	local max = Config.Gacha.MaxDrawCount
	return keys >= 2 and math.min(keys, max) or max
end

-- one central drop: how many keys, and which of them (if any) is a better grade.
-- r1, r2 in [0, 1). Returns count, special type Id or nil (the rarest grade that hits wins).
function Formulas.centralDrop(r1, r2)
	local k = Config.Keys
	local count, sum = #k.DropCountPercent, 0
	for n, percent in ipairs(k.DropCountPercent) do -- 1 key most often, 10 keys rarely
		sum += percent / 100
		if r1 < sum then
			count = n
			break
		end
	end
	local special = nil
	local threshold = 0
	for i = #k.Types, 1, -1 do -- rarest first: 0.1% diamond, then 1% gold, stacked
		local t = k.Types[i]
		if t.DropChancePercent then
			threshold += t.DropChancePercent / 100
			if not special and r2 < threshold then
				special = t.Id
			end
		end
	end
	return count, special
end

-- every result of one draw and its chance in percent, for a player at this defense level.
-- options: { luck = multiplier (1), keyType = Id ("Normal"), limitedSpecies = Id or nil, limitedPotion = bool,
--            mutationEvent = bool }
-- Steps (each adds up to 100%):
--   Species:  this week's limited dino gets LimitedChancePercent (LimitedPotionChancePercent with the
--             potion), the rest is split evenly between the unlocked species (variants: only from their MinKey and better keys,
--             Gacha.VariantWeight); with no limited dino
--             this week everything goes to the unlocked species.
--   Rarities: locked ones are 0 and their chance goes to Common; the player's luck multiplies
--             Legendary and up (at most LuckMaxMultiplier) and the extra comes out of Common; then a
--             better key takes the best of keyPicks draws of that (Formulas.bestOf).
--   Sizes:    the size weights, the biggest of keySizePicks (by level) for a better key.
--   Mutation: during a mutation event EventChancePercent split evenly between the types, else 0.
-- how many draws of plain odds a key of this grade takes the best of: (2026-10-02, "완전 상위 공룡 쪽도 뽑기
--어려운 거 맞지 후반컨텐츠에서도" → 둘 다 손보기) just what the exchange takes to make it (silver 10, gold 10 × 7,
-- ... rainbow 24,010 normal draws; before: 12 per grade, 248,832, ten times its cost at the top). An exchanged key
-- still beats the keys it was made of: its FloorRarity, bigger sizes (keySizePicks) and its mutation chance.
function Formulas.keyPicks(typeId)
	local picks = 1
	for _, t in ipairs(Config.Keys.Types) do
		if t.Id == (typeId or "Normal") then
			break
		end
		picks *= Formulas.exchangeRate(t.Id)
	end
	return picks
end
-- the best rarity a key grade (its index in Config.Keys.Types) can give at this level: the best one
-- fully open, at most the grade's MaxRarity
local function keyTopRarity(grade, level)
	local top = 1
	for i, r in ipairs(Config.Rarities) do
		-- (2026-10-02) a rarity still at a share of its chance (Formulas.newRarityScale) doesn't count yet: the
		-- key's step up then still takes the bigger sizes
		if Formulas.rarityOpen(r, level) and Formulas.newRarityScale(r, level) >= 1 then
			top = i
		end
	end
	local cap = Config.Keys.Types[grade].MaxRarity
	return cap and math.min(top, RARITIES[cap .. "#"]) or top
end

-- sizes: UpgradeSizePicks for each grade above the normal key, but LockedSizePicks for a step up that
-- brings no better rarity at this level (2026-10-01; no level: as if every rarity were open)
function Formulas.keySizePicks(typeId, level)
	local g = Config.Gacha
	local grade = KEY_TYPES[(typeId or "Normal") .. "#"]
	local picks = 1
	for i = 2, grade do
		local same = level and keyTopRarity(i, level) == keyTopRarity(i - 1, level)
		picks *= same and g.LockedSizePicks or g.UpgradeSizePicks
	end
	return picks
end

-- turns a list of { Percent } (worst to best, adding up to 100) into the odds of the best of n draws:
-- the chance of at most the k-th is (chance of at most the k-th)^n
function Formulas.bestOf(list, n)
	if n <= 1 then
		return list
	end
	local total = 0
	for _, item in ipairs(list) do
		total += item.Percent / 100
	end
	if total <= 0 then
		return list
	end
	-- (divided by the total: the last one is exactly 1, so rounding can't leave a draw of 248,832 short of 100%)
	local cumulative, before = 0, 0
	for _, item in ipairs(list) do
		cumulative += item.Percent / 100
		local now = math.min(1, cumulative / total) ^ n
		item.Percent = (now - before) * 100
		before = now
	end
	return list
end

-- (2026-10-01, "사용자가 자기가 다 뽑을 수는 없다는 걸 알고 뽑기를") how many species keys can give at
-- this real level, how many there are, and the next unlock: its level and how many open then (nil at the end)
-- (the variants are left out: better keys give them, at any level; Formulas.variantKey)
function Formulas.speciesOutlook(level)
	local open, all, nextLevel, nextCount, nextRebirths = 0, 0, nil, 0, nil
	for _, s in ipairs(Config.Species) do
		if s.Theme == "Variant" then
			continue
		end
		all += 1
		if s.UnlockLevel <= level then
			open += 1
		elseif not nextLevel or s.UnlockLevel < nextLevel then
			nextLevel, nextCount, nextRebirths = s.UnlockLevel, 1, s.UnlockRebirths
		elseif s.UnlockLevel == nextLevel then
			nextCount += 1
		end
	end
	return open, all, nextLevel, nextCount, nextRebirths
end

-- (2026-10-01, "특수 개체들만 상위 등급에서") can this key give variants (변종)? Gacha.VariantMinKey and better
function Formulas.variantKey(keyId)
	local rank = KEY_TYPES[(keyId or "Normal") .. "#"]
	return rank ~= nil and rank >= KEY_TYPES[Config.Gacha.VariantMinKey .. "#"]
end

-- how many variants there are (the collection's line, the odds window's)
function Formulas.variantCount()
	local n = 0
	for _, s in ipairs(Config.Species) do
		n += (s.Theme == "Variant" and not s.MinRebirths) and 1 or 0 -- (the awakened ones: awakenedVariants)
	end
	return n
end

-- (2026-10-02, "금열쇠 + 루비열쇠+ 종류들도 구분해줘") the worst key a variant comes from: its own MinKey
function Formulas.variantMinKey(species)
	return species.MinKey or Config.Gacha.VariantMinKey
end

-- can this key give this variant (its MinKey or a better key; an awakened one also MinRebirths, 2026-10-02)?
-- (a plain species: always)
function Formulas.variantOpen(species, keyId, rebirths)
	if species.Theme ~= "Variant" then
		return true
	end
	if (rebirths or 0) < (species.MinRebirths or 0) then
		return false
	end
	local rank = KEY_TYPES[(keyId or "Normal") .. "#"]
	return rank ~= nil and rank >= KEY_TYPES[Formulas.variantMinKey(species) .. "#"]
end

-- (2026-10-02) the awakened variants (MinRebirths and MinKey), fewest rebirths first
function Formulas.awakenedVariants()
	local list = {}
	for _, s in ipairs(Config.Species) do
		if s.MinRebirths then
			table.insert(list, s)
		end
	end
	table.sort(list, function(a, b)
		return a.MinRebirths < b.MinRebirths
	end)
	return list
end

-- one line of them: "각성 1 + 다이아 열쇠+ · 각성 2 + 다이아 열쇠+ · ..."
function Formulas.awakenedVariantsText()
	local parts = {}
	for _, s in ipairs(Formulas.awakenedVariants()) do
		table.insert(parts, string.format("환생 %d + %s+", s.MinRebirths, Formulas.keyType(s.MinKey).Name))
	end
	return table.concat(parts, " · ")
end

-- the variants by the key they start from, worst key first: { { Key = Id, Count = n }, ... }
function Formulas.variantTiers()
	local tiers = {}
	for _, t in ipairs(Config.Keys.Types) do
		local n = 0
		for _, s in ipairs(Config.Species) do -- (the awakened ones on their own line: awakenedVariantsText)
			n += (s.Theme == "Variant" and not s.MinRebirths and Formulas.variantMinKey(s) == t.Id) and 1 or 0
		end
		if n > 0 then
			table.insert(tiers, { Key = t.Id, Count = n })
		end
	end
	return tiers
end

-- one line of them: "은 열쇠+ 3종 · 황금 열쇠+ 3종 · ..."
function Formulas.variantTiersText()
	local parts = {}
	for _, t in ipairs(Formulas.variantTiers()) do
		table.insert(parts, string.format("%s+ %d종", Formulas.keyType(t.Key).Name, t.Count))
	end
	return table.concat(parts, " · ")
end

-- ---------------------------------------------------------------------------
-- The weekly limited dino (2026-10-02, Config.Limited)
-- ---------------------------------------------------------------------------

local LIMITED_MARK = "🎖️" -- a dino drawn from the limited share (display: names in windows)
local ATTEND_MARK = "🗓️" -- this month's attendance dino (2026-10-02)
local SEASON_MARK = "🏆" -- a season pass dino (2026-10-02)
local LAUNCH_MARK = "🎉" -- the launch gift dino (2026-10-04, Config.LaunchGift)
local DAY_SECONDS = 86400
local SATURDAY = 2 -- days after a Thursday (the Unix epoch's day)

-- days since 1970-01-01 of a calendar date (no os.time: the same on every machine)
local function civilDay(y, m, d)
	y = m <= 2 and y - 1 or y
	local era = math.floor(y / 400)
	local yoe = y - era * 400
	local doy = math.floor((153 * (m + (m > 2 and -3 or 9)) + 2) / 5) + d - 1
	local doe = yoe * 365 + math.floor(yoe / 4) - math.floor(yoe / 100) + doy
	return era * 146097 + doe - 719468
end

-- the limited week at time now (a week from Saturday's day turn to the next)
function Formulas.limitedWeek(now)
	local day = math.floor((now + Config.Rewards.ResetOffsetHours * 3600) / DAY_SECONDS)
	return math.floor((day - SATURDAY) / 7)
end

-- when that week ends (os.time)
function Formulas.limitedEndsAt(now)
	local week = Formulas.limitedWeek(now)
	return ((week + 1) * 7 + SATURDAY) * DAY_SECONDS - Config.Rewards.ResetOffsetHours * 3600
end

-- the species Id limited in that week, or nil (off, or no roster)
function Formulas.limitedSpecies(week)
	local c = Config.Limited
	if not c.Enabled or #c.Roster == 0 then
		return nil
	end
	local first = math.floor((civilDay(c.StartDate[1], c.StartDate[2], c.StartDate[3]) - SATURDAY) / 7)
	return c.Roster[(week - first) % #c.Roster + 1]
end

-- a unit's name in windows: its species, 🎖️ first when it came from a limited share
function Formulas.unitName(unit)
	local s = SPECIES[unit.Species]
	return (unit.Limited and LIMITED_MARK or "") .. (unit.Attend and ATTEND_MARK or "") .. (unit.Season and SEASON_MARK or "")
		.. (unit.Launch and LAUNCH_MARK or "")
		.. (s and s.Name or tostring(unit.Species))
end

function Formulas.damageRows(units, top, idle)
	local hitters, still = {}, {}
	for _, u in ipairs(units or {}) do
		if (u.D or 0) <= 0 and (u.F or u.Q) then
			table.insert(still, u)
		else
			table.insert(hitters, u)
		end
	end
	table.sort(hitters, function(a, b)
		if (a.D or 0) ~= (b.D or 0) then
			return (a.D or 0) > (b.D or 0)
		end
		return tostring(a.I) < tostring(b.I)
	end)
	table.sort(still, function(a, b)
		if (a.F ~= nil) ~= (b.F ~= nil) then
			return a.F ~= nil
		end
		return tostring(a.I) < tostring(b.I)
	end)
	local idleShown = math.min(#still, idle)
	local hitShown = math.min(#hitters, top + idle - idleShown)
	local rows = {}
	for i = 1, hitShown do
		table.insert(rows, hitters[i])
	end
	for i = 1, idleShown do
		table.insert(rows, still[i])
	end
	return rows, #hitters + #still - #rows
end

-- the luck cap: LuckMaxMultiplier, or Gacha.PaidLuckMax while a paid luck (a potion's Luck, a server boost) is on
function Formulas.luckCap(potionLuck, serverLuck)
	local g = Config.Gacha
	return ((potionLuck or 1) > 1 or (serverLuck or 1) > 1) and g.PaidLuckMax or g.LuckMaxMultiplier
end

-- (2026-10-02, "루비열쇠로 열 수 있는 상품을 가질 수 있게 해줘. 돈 쓴거잖아") the level a key grade draws its
-- rarities at: a grade the key stall opens with an awakening (Config.Keys.Types ShopRebirths: ruby 1, diamond 2,
-- rainbow 3) always draws as if the player had at least that many awakenings, so a ruby key bought or found
-- before the first awakening still brings the first awakening's rarities. Species stay the player's own.
function Formulas.keyRarityLevel(level, keyId)
	local n = KEY_TYPES[keyId or "Normal"] and KEY_TYPES[keyId or "Normal"].ShopRebirths or 0
	return n > 0 and math.max(level, Formulas.tierStart(n)) or level
end

-- (2026-10-02, "완전 상위 공룡 쪽도 뽑기 어려운 거 맞지" → 둘 다 손보기) the top Gacha.TopLuck.Rarities rarities open at
-- this (key's) level get only Share of the luck above ×1: the index the first of them has
function Formulas.topLuckFrom(level)
	local top = 1
	for i, r in ipairs(Config.Rarities) do
		if Formulas.rarityOpen(r, level) then
			top = i
		end
	end
	return math.max(RARITIES[Config.Gacha.LuckFromRarity .. "#"], top - Config.Gacha.TopLuck.Rarities + 1)
end

-- the luck those top rarities get
function Formulas.topLuck(luck)
	return 1 + (luck - 1) * Config.Gacha.TopLuck.Share
end

function Formulas.gachaOdds(level, options)
	options = options or {}
	local g = Config.Gacha
	local odds = { Species = {}, Rarities = {}, Sizes = {}, Mutations = {}, MutationPercent = 0 }

	local unlocked = {}
	local variants = Formulas.variantKey(options.keyType) and (g.VariantWeight[options.keyType] or 0) > 0
	for _, s in ipairs(Config.Species) do
		if s.UnlockLevel <= level and (s.Theme ~= "Variant" or variants and Formulas.variantOpen(s, options.keyType, options.rebirths)) then
			table.insert(unlocked, s)
		end
	end
	local limited = options.limitedSpecies and SPECIES[options.limitedSpecies]
	local limitedPercent = limited and (options.limitedPotion and g.LimitedPotionChancePercent or g.LimitedChancePercent) or 0
	-- evenly, a variant its key's VariantWeight as likely (2026-10-01)
	local function weight(s)
		return s.Theme == "Variant" and (g.VariantWeight[options.keyType or "Normal"] or 0) or 1
	end
	local totalWeight = 0
	for _, s in ipairs(unlocked) do
		totalWeight += weight(s)
	end
	for _, s in ipairs(unlocked) do
		local each = (100 - limitedPercent) * weight(s) / totalWeight
		table.insert(odds.Species, { Id = s.Id, Percent = each })
	end
	if limited then -- (its own line, even when it is in the pool too: a dino from it is marked limited, 2026-10-02)
		table.insert(odds.Species, { Id = limited.Id, Percent = limitedPercent, Limited = true })
	end
	odds.LimitedSpecies = limited and limited.Id

	local keyId = options.keyType or "Normal"
	local rarityLevel = Formulas.keyRarityLevel(level, keyId) -- (a better key's own awakening tier, at least)
	local luck = math.clamp(options.luck or 1, 1, options.luckCap or g.LuckMaxMultiplier)
	local luckFrom = RARITIES[g.LuckFromRarity .. "#"]
	local topLuckFrom = Formulas.topLuckFrom(rarityLevel)
	local common = 0
	for i, r in ipairs(Config.Rarities) do
		local open = Formulas.rarityOpen(r, rarityLevel)
		local percent = 0
		if not open then
			common += r.ChancePercent
		elseif i >= luckFrom then
			local luck = i >= topLuckFrom and Formulas.topLuck(luck) or luck
			-- (2026-10-02, "각 각성 등급에 맞게 조절해 높은 급의 공룡 확률도") a rarity its awakening only just opened
			-- is rarer at first (Formulas.newRarityScale), the rest of its chance goes to Common
			local base = r.ChancePercent * Formulas.newRarityScale(r, rarityLevel)
			common += r.ChancePercent - base
			percent = base * luck
			common -= base * (luck - 1)
		end
		table.insert(odds.Rarities, { Id = r.Id, Percent = percent, Locked = not open, UnlockRebirths = r.UnlockRebirths or 0 })
	end
	for i, r in ipairs(Config.Rarities) do
		if Formulas.rarityOpen(r, rarityLevel) and i < luckFrom then
			odds.Rarities[i].Percent = r.ChancePercent + (i == 1 and common or 0)
		end
	end
	Formulas.bestOf(odds.Rarities, Formulas.keyPicks(keyId))
	-- nothing past the key's MaxRarity: that chance goes to the MaxRarity itself
	-- (options.noCap: the plain table before the key's limit, for checks)
	local cap = not options.noCap and KEY_TYPES[keyId] and KEY_TYPES[keyId].MaxRarity
		and RARITIES[KEY_TYPES[keyId].MaxRarity .. "#"]
	if cap then
		for i = cap + 1, #odds.Rarities do
			odds.Rarities[cap].Percent += odds.Rarities[i].Percent
			odds.Rarities[i].Percent = 0
		end
	end

	-- (2026-10-02) nothing below the key's FloorRarity: that chance goes to the floor itself (when it is open)
	local floor = KEY_TYPES[keyId] and KEY_TYPES[keyId].FloorRarity and RARITIES[KEY_TYPES[keyId].FloorRarity .. "#"]
	if floor and not odds.Rarities[floor].Locked then
		for i = 1, floor - 1 do
			odds.Rarities[floor].Percent += odds.Rarities[i].Percent
			odds.Rarities[i].Percent = 0
		end
	end

	for _, size in ipairs(Config.Sizes) do
		table.insert(odds.Sizes, { Id = size.Id, Percent = size.WeightPercent })
	end
	Formulas.bestOf(odds.Sizes, Formulas.keySizePicks(keyId, rarityLevel))

	-- a mutation: the key grade's own chance (2026-10-01) plus a mutation event's
	odds.MutationPercent = math.min(100, (KEY_TYPES[keyId] and KEY_TYPES[keyId].MutationPercent or 0)
		+ (options.mutationEvent and Config.Mutations.EventChancePercent or 0))
	if odds.MutationPercent > 0 then
		for _, m in ipairs(Config.Mutations.Types) do
			table.insert(odds.Mutations, { Id = m.Id, Percent = odds.MutationPercent / #Config.Mutations.Types })
		end
	end
	return odds
end

-- one draw from gachaOdds with five random numbers in [0, 1): { Species, Rarity, Size, Mutation? }
-- (2026-10-02) 뽑기 천장 (Config.Gacha.Pity): count one drawn dino (in place, inside PlayerData.update). A dino
-- of Pity.Rarity or better starts the count again; the Pity.Draws-th one in a row below it is raised to a
-- rarity of at least Pity.Rarity, picked by the odds' own shares of those rarities (roll in [0, 1)).
-- Returns true when the pity raised it.
function Formulas.applyPity(profile, unit, odds, roll)
	local p = Config.Gacha.Pity
	local floor = RARITIES[p.Rarity .. "#"]
	if (RARITIES[unit.Rarity .. "#"] or 0) >= floor then
		profile.PityCount = 0
		return false
	end
	profile.PityCount = (profile.PityCount or 0) + 1
	if profile.PityCount < p.Draws then
		return false
	end
	profile.PityCount = 0
	local options = {}
	for _, r in ipairs(odds.Rarities) do
		if (RARITIES[r.Id .. "#"] or 0) >= floor and r.Percent > 0 then
			table.insert(options, r)
		end
	end
	unit.Rarity = #options > 0 and Formulas.pickWeighted(options, "Percent", roll).Id or p.Rarity
	return true
end

-- draws left until the pity (the gacha window shows it)
function Formulas.pityLeft(profile)
	return math.max(1, Config.Gacha.Pity.Draws - (profile.PityCount or 0))
end

function Formulas.rollDraw(odds, r1, r2, r3, r4, r5)
	local species = Formulas.pickWeighted(odds.Species, "Percent", r1)
	local draw = {
		Species = species.Id,
		Limited = species.Limited or nil, -- (from this week's limited share: marked for good)
		Rarity = Formulas.pickWeighted(odds.Rarities, "Percent", r2).Id,
		Size = Formulas.pickWeighted(odds.Sizes, "Percent", r3).Id,
	}
	if odds.MutationPercent > 0 and r4 * 100 < odds.MutationPercent then
		draw.Mutation = Formulas.pickWeighted(odds.Mutations, "Percent", r5).Id
	end
	return draw
end

function Formulas.boxSizeMultiplier(sizeId)
	return Config.Boxes.SizeMultiplier[sizeId] or 1
end

function Formulas.boxSeconds(rarityId, sizeId, cap)
	local b = Config.Boxes
	local base = b.RaritySeconds[rarityId] or b.RaritySeconds.Common
	local multiplier = Formulas.boxSizeMultiplier(sizeId)
	local seconds = base * multiplier
	if cap then
		seconds = math.min(seconds, cap * multiplier)
	end
	return math.clamp(math.floor(seconds + 0.5), b.MinSeconds, b.MaxSeconds)
end

function Formulas.boxGrowth(box, now)
	local made = box.MadeAt or (box.ReadyAt - Formulas.boxSeconds(box.Rarity, box.Size))
	local span = box.ReadyAt - made
	if span <= 0 then
		return 1
	end
	return math.clamp((now - made) / span, 0, 1)
end

function Formulas.boxScale(box, now)
	local from = Config.Boxes.GrowFrom
	return from + (1 - from) * Formulas.boxGrowth(box, now)
end

function Formulas.boxStatus(boxes, now)
	local ready, waiting, nextAt = 0, 0, nil
	for _, b in ipairs(boxes or {}) do
		if (b.ReadyAt or 0) <= now then
			ready += 1
		else
			waiting += 1
			nextAt = math.min(nextAt or math.huge, b.ReadyAt)
		end
	end
	return ready, waiting, nextAt
end

function Formulas.boxRushTier(need)
	for i, rush in ipairs(Config.Boxes.Rush) do
		if need <= rush.Seconds then
			return i
		end
	end
	return nil
end

function Formulas.boxRushPick(boxes, now, which, credit)
	credit = credit or 0
	local waiting = {}
	for _, b in ipairs(boxes or {}) do
		if (b.ReadyAt or 0) > now and (which == "All" or which == b.Id) then
			table.insert(waiting, b)
		end
	end
	table.sort(waiting, function(a, b)
		return a.ReadyAt < b.ReadyAt
	end)
	local most = Config.Boxes.Rush[#Config.Boxes.Rush].Seconds + credit
	local ids, total = {}, 0
	for _, b in ipairs(waiting) do
		local left = b.ReadyAt - now
		if total + left > most then
			break
		end
		total += left
		table.insert(ids, b.Id)
	end
	local need = total - credit
	return ids, total, need > 0 and Formulas.boxRushTier(need) or nil
end

function Formulas.unlockOf(id)
	for _, u in ipairs(Config.Unlocks) do
		if u.Id == id then
			return u
		end
	end
	return nil
end

function Formulas.cinematicUnlock()
	for _, u in ipairs(Config.Unlocks) do
		if u.Cinematic then
			return u
		end
	end
	return nil
end

function Formulas.gateUnlock()
	for _, u in ipairs(Config.Unlocks) do
		if u.Gate then
			return u
		end
	end
	return nil
end

function Formulas.unlockedByPass(u, passes)
	return u.Pass ~= nil and passes ~= nil and passes[u.Pass] == true
end

function Formulas.unlockIndex(id)
	for i, u in ipairs(Config.Unlocks) do
		if u.Id == id then
			return i
		end
	end
	return nil
end

function Formulas.unlockNeed(u, level, passes, open, chapter)
	if Formulas.unlockedByPass(u, passes) then
		return nil
	end
	local prev = Config.Unlocks[(Formulas.unlockIndex(u.Id) or 1) - 1]
	if prev and not (type(open) == "table" and open[prev.Id] == true) then
		return "Prev", prev
	end
	if (chapter or 1) <= (u.After or 0) then
		return "Chapter"
	end
	if u.Level and (level or 1) < u.Level then
		return "Level"
	end
	return nil
end

function Formulas.unlockState(id, level, passes, open, chapter)
	local u = Formulas.unlockOf(id)
	if not u then
		return "Open"
	end
	local o = type(open) == "table" and open[id] or nil
	if o == true then
		return "Open"
	elseif type(o) == "table" then
		return "Learning"
	end
	return Formulas.unlockNeed(u, level, passes, open, chapter) == nil and "Ready" or "Locked"
end

function Formulas.unlockOpen(unlocks, id)
	return Formulas.unlockOf(id) == nil
		or (type(unlocks) == "table" and type(unlocks.Open) == "table" and unlocks.Open[id] == true)
end

function Formulas.unlockUsable(unlocks, id)
	if type(unlocks) ~= "table" or type(unlocks.Open) ~= "table" then
		return true
	end
	return Formulas.unlockOf(id) == nil or unlocks.Open[id] ~= nil
end

function Formulas.nextUnlock(open)
	for _, u in ipairs(Config.Unlocks) do
		if not (type(open) == "table" and open[u.Id] == true) then
			return u
		end
	end
	return nil
end

function Formulas.fieldOpenFrom(open)
	local from = Config.Battlefield.Radius
	for _, u in ipairs(Config.Unlocks) do
		if u.Zone and type(open) == "table" and open[u.Id] ~= nil then
			from = math.min(from, u.Zone.To)
		end
	end
	return from
end

function Formulas.fieldClosed(position, openFrom)
	local d = Vector3.new(position.X, 0, position.Z).Magnitude
	return d <= Config.Battlefield.Radius and d < (openFrom or 0)
end

function Formulas.openRects(hx, hz, d, reach, tree)
	local o = Config.OpenArea
	local rects = { { -hx, hx, -hz, hz } }
	if reach then
		local z1 = d - reach + (reach <= 0 and o.AltarPast or 0)
		table.insert(rects, { -o.StripHalfWidth, o.StripHalfWidth, hz - o.Overlap, math.max(z1, hz) })
	end
	if tree then
		local front = hz + o.CorridorOut
		table.insert(rects, { math.min(0, tree.X) - o.CorridorHalf, math.max(0, tree.X) + o.CorridorHalf, hz - o.Overlap, front })
		table.insert(rects, { tree.X - o.WildHalf, tree.X + o.WildHalf, math.min(tree.Z - o.WildHalf, hz - o.Overlap),
			math.max(tree.Z + o.WildHalf, front) })
	end
	return rects
end

function Formulas.inRects(rects, x, z, inset)
	local k = inset or 0
	for _, r in ipairs(rects) do
		if x >= r[1] + k and x <= r[2] - k and z >= r[3] + k and z <= r[4] - k then
			return true
		end
	end
	return false
end

function Formulas.intoRects(rects, x, z, inset)
	local k = inset or 0
	local bestX, bestZ, bestD = x, z, math.huge
	for _, r in ipairs(rects) do
		local x0, x1, z0, z1 = r[1] + k, r[2] - k, r[3] + k, r[4] - k
		if x0 <= x1 and z0 <= z1 then
			local cx, cz = math.clamp(x, x0, x1), math.clamp(z, z0, z1)
			local d = (cx - x) ^ 2 + (cz - z) ^ 2
			if d < bestD then
				bestX, bestZ, bestD = cx, cz, d
			end
		end
	end
	return bestX, bestZ
end

function Formulas.rectsText(rects)
	local parts = {}
	for _, r in ipairs(rects) do
		table.insert(parts, string.format("%.1f,%.1f,%.1f,%.1f", r[1], r[2], r[3], r[4]))
	end
	return table.concat(parts, ";")
end

function Formulas.rectsOf(text)
	if type(text) ~= "string" or text == "" then
		return nil
	end
	local rects = {}
	for chunk in string.gmatch(text, "[^;]+") do
		local r = {}
		for n in string.gmatch(chunk, "[^,]+") do
			table.insert(r, tonumber(n))
		end
		if #r == 4 then
			table.insert(rects, r)
		end
	end
	return #rects > 0 and rects or nil
end

function Formulas.zoneUnlockAt(openFrom)
	for _, u in ipairs(Config.Unlocks) do
		if u.Zone and u.Zone.From == openFrom then
			return u
		end
	end
	return nil
end

function Formulas.unlockStep(id, step)
	local u = Formulas.unlockOf(id)
	return u and u.Steps[step] or nil
end

function Formulas.clockText(seconds)
	seconds = math.max(0, math.ceil(seconds))
	local h, m, sec = seconds // 3600, seconds % 3600 // 60, seconds % 60
	if h > 0 then
		return string.format("%d:%02d:%02d", h, m, sec)
	end
	return string.format("%d:%02d", m, sec)
end

return Formulas
