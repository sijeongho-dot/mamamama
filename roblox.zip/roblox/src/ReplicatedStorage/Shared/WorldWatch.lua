local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local WorldWatch = {}

local listeners = {}
local byClass = {}
local connected = false

local function wants(l, d)
	for _, class in ipairs(l.classes) do
		if d:IsA(class) then
			return true
		end
	end
	return false
end

local function call(l, d, existing)
	local ok, err = pcall(l.handler, d, existing)
	if not ok then
		warn("[WorldWatch] " .. tostring(err))
	end
end

local function route(d)
	local class = d.ClassName
	local list = byClass[class]
	if list == nil then
		list = {}
		for _, l in ipairs(listeners) do
			if wants(l, d) then
				table.insert(list, l)
			end
		end
		byClass[class] = list
	end
	for i = 1, #list do
		local l = list[i]
		local scanned = l.scanned
		if not (scanned and scanned[d]) then
			call(l, d, false)
		end
	end
end

function WorldWatch.listen(classes, handler)
	local l = { classes = classes, handler = handler, scanned = setmetatable({}, { __mode = "k" }) }
	if not connected then
		connected = true
		Workspace.DescendantAdded:Connect(route)
	end
	local known = {}
	for _, d in ipairs(Workspace:GetDescendants()) do
		local class = d.ClassName
		local yes = known[class]
		if yes == nil then
			yes = wants(l, d)
			known[class] = yes
		end
		if yes then
			l.scanned[d] = true
			call(l, d, true)
		end
	end
	table.insert(listeners, l)
	table.clear(byClass)
	task.spawn(function()
		RunService.Heartbeat:Wait()
		RunService.Heartbeat:Wait()
		l.scanned = nil
	end)
end

return WorldWatch
