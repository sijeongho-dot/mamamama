--[[
SideButtons: the column of buttons at the right middle of the screen (보기 설정, 기지로, 타기, 보상,
인벤토리) can be folded away with one small button beside the key drop timer, so a phone's screen
is not full of buttons (display only, clients).

	SideButtons.register(button)   -- the button moves into the shared column (its spot on the screen stays)

Folded, the whole column hides ("◀ 메뉴" brings it back); the scripts still show and hide their own
buttons as before.
]]

local Players = game:GetService("Players")

local SideButtons = {}

-- display only
local TOGGLE_SIZE = UDim2.fromOffset(68, 26)
local TOGGLE_POS = UDim2.new(1, -12 - 68 - 10, 0, 58) -- its bottom right: left of the key drop timer (Hud)
local COLOR_TOGGLE = Color3.fromRGB(60, 64, 80)
local TEXT_OPEN, TEXT_FOLDED = "접기 ▶", "◀ 메뉴"
local DOT_SIZE = 12
local COLOR_DOT = Color3.fromRGB(235, 50, 60)
local DOT_ATTRIBUTES = { "RewardsReady", "RewardsReadyAttendance", "SeasonReady", "StarterReady" }

local column = nil
local toggleButton = nil
local folded = true
local refreshDot = function() end

local function getColumn()
	if column then
		return column
	end
	local gui = Instance.new("ScreenGui")
	gui.Name = "SideButtons"
	gui.ResetOnSpawn = false
	gui.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")
	column = Instance.new("Frame")
	column.Name = "Column"
	column.Size = UDim2.fromScale(1, 1)
	column.BackgroundTransparency = 1
	column.Active = false
	column.Visible = not folded
	column.Parent = gui
	local toggle = Instance.new("TextButton")
	toggle.Name = "FoldSide"
	toggle.AnchorPoint = Vector2.new(1, 1)
	toggle.Size = TOGGLE_SIZE
	toggle.Position = TOGGLE_POS
	toggle.BackgroundColor3 = COLOR_TOGGLE
	toggle.BackgroundTransparency = 0.2
	toggle.Font = Enum.Font.GothamBold
	toggle.TextSize = 12
	toggle.TextColor3 = Color3.new(1, 1, 1)
	toggle.Text = folded and TEXT_FOLDED or TEXT_OPEN
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 8)
	c.Parent = toggle
	toggle.Parent = gui
	toggleButton = toggle
	local dot = Instance.new("Frame")
	dot.Name = "Attention"
	dot.AnchorPoint = Vector2.new(0.5, 0.5)
	dot.Position = UDim2.fromScale(0, 0)
	dot.Size = UDim2.fromOffset(DOT_SIZE, DOT_SIZE)
	dot.BackgroundColor3 = COLOR_DOT
	dot.Visible = false
	dot.Parent = toggle
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = dot
	local player = Players.LocalPlayer
	refreshDot = function()
		local any = false
		for _, name in ipairs(DOT_ATTRIBUTES) do
			local v = player:GetAttribute(name)
			any = any or (type(v) == "number" and v > 0) or v == true
		end
		dot.Visible = folded and any
	end
	for _, name in ipairs(DOT_ATTRIBUTES) do
		player:GetAttributeChangedSignal(name):Connect(refreshDot)
	end
	refreshDot()
	toggle.Activated:Connect(function()
		SideButtons.setFolded(not folded)
	end)
	return column
end

function SideButtons.setFolded(on)
	getColumn()
	folded = on
	column.Visible = not folded
	toggleButton.Text = folded and TEXT_FOLDED or TEXT_OPEN
	refreshDot()
end

function SideButtons.isFolded()
	return folded
end

function SideButtons.toggleButton()
	getColumn()
	return toggleButton
end

function SideButtons.find(match)
	for _, b in ipairs(getColumn():GetDescendants()) do
		if b:IsA("GuiButton") and b.Visible and match(b) then
			return b
		end
	end
	return nil
end

function SideButtons.register(button)
	button.Parent = getColumn()
	return button
end

return SideButtons
