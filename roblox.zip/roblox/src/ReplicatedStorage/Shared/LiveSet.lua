local LiveSet = {}
LiveSet.__index = LiveSet

local PRUNE_EVERY = 64

function LiveSet.new()
	return setmetatable({ items = {}, added = 0 }, LiveSet)
end

function LiveSet:prune()
	for inst in pairs(self.items) do
		if not inst.Parent then
			self.items[inst] = nil
		end
	end
end

function LiveSet:add(inst)
	if self.items[inst] then
		return
	end
	self.added += 1
	if self.added % PRUNE_EVERY == 0 then
		self:prune()
	end
	self.items[inst] = true
end

function LiveSet:each(fn)
	for inst in pairs(self.items) do
		if inst.Parent then
			fn(inst)
		else
			self.items[inst] = nil
		end
	end
end

return LiveSet
