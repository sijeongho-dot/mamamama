--[[
Sfx: the game's sounds on the clients (display only).

	Sfx.play("SlapHit")               -- heard as is (2D)
	Sfx.play("SlapHit", position)     -- from that spot in the world (3D, fades with distance)
	Sfx.play("FlyWhoosh", rootPart)   -- from a part (or attachment), going along with it
	Sfx.play("HeartThump", nil, 1.1, 0.5) -- a little higher and half as loud (pitch, gain)
	local s = Sfx.play("WindGust")    -- (the Sound, to stop it early; nil for a sound of notes or none)
	local rain = Sfx.loop("RainLoop") -- a looping Sound at volume 0 (fade it in and out), or nil

The game's own sounds are made by tools/make_sounds.py (exports/sounds/<Name>.wav). Once uploaded to
Roblox they are used first, found in this order:
	1. a Sound named <Name> in SoundService.GameSounds (import the wav files in Studio and drag them there)
	2. an audio id in UPLOADED below
Until then each sound falls back to one of Roblox's built-in sounds (rbxasset://sounds/...; some are a
list of notes played one after another, Speed = pitch). The rain and storm loops have no stand-in.
]]

local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Sfx = {}

-- display only: what each game moment sounds like
local PING = "rbxasset://sounds/electronicpingshort.wav"
local SOUNDS = {
	SlapSwing = { Id = "rbxasset://sounds/swordslash.wav", Volume = 0.5, Speed = 1.2 },
	SlapHit = { Id = "rbxasset://sounds/splat.wav", Volume = 0.8 },
	KnockOut = { Volume = 0.5 }, -- (made by tools/make_sounds.py; silent until uploaded)
	-- the ONLY use of Roblox's death sound: the player a slap throws (CombatFx). Nothing else borrows it.
	Oof = { Id = "rbxasset://sounds/uuhhh.mp3", Volume = 0.8 },
	MineHit = { Id = "rbxasset://sounds/unsheath.wav", Volume = 0.35, Speed = 1.8 },
	-- (2026-10-04, "본게임에서 광질 조금 하다 가던데") a mineral into my bag: a light two-note "띠링" (MiningFx, every finished
	-- turn); a high short ping stands in until uploaded
	MinePop = { Id = PING, Volume = 0.25, Speed = 2.3, Cut = 0.15 },
	KeyPickup = { Id = PING, Volume = 0.5, Speed = 2 },
	KeyDrop = { Id = PING, Volume = 0.4, Speed = 0.8 },
	SpecialKey = { Notes = { 1, 1.25, 1.5, 2 }, Id = PING, Volume = 0.5, Gap = 0.08 },
	Deposit = { Notes = { 1.4, 1.7, 2.1 }, Id = PING, Volume = 0.45, Gap = 0.06 },
	GachaCard = { Id = "rbxasset://sounds/button.wav", Volume = 0.6 },
	GachaBig = { Notes = { 1, 1.26, 1.5, 2, 2.52 }, Id = PING, Volume = 0.55, Gap = 0.09 },
	-- the unique rarities' draw reveals (Gacha client): the wait before the card, then one per band of
	-- rarities, bigger and bigger; built-in stand-ins (rising pings) until our own are uploaded
	GachaSuspense = { Notes = { 0.6, 0.7, 0.8, 0.9, 1, 1.12, 1.25 }, Id = PING, Volume = 0.35, Gap = 0.13 },
	GachaLegend = { Notes = { 1, 1.26, 1.5, 2, 2.52, 3 }, Id = PING, Volume = 0.6, Gap = 0.08 },
	GachaRainbow = { Notes = { 1, 1.12, 1.26, 1.5, 1.68, 2, 2.52, 3 }, Id = PING, Volume = 0.6, Gap = 0.06 },
	GachaDark = { Id = "rbxasset://sounds/Launching rocket.wav", Volume = 0.8, Speed = 0.4, Cut = 2.5 },
	GachaHeaven = { Notes = { 2, 1.5, 2, 2.52, 3, 4 }, Id = PING, Volume = 0.55, Gap = 0.14 },
	GachaCosmic = { Notes = { 0.5, 0.75, 1, 1.5, 2, 3, 4 }, Id = PING, Volume = 0.65, Gap = 0.12 },
	-- someone's rebirth show (RebirthFx): up, spin, land; a rising stand-in until our own is uploaded
	Rebirth = { Notes = { 0.6, 0.75, 0.9, 1.1, 1.3, 1.6, 2, 1.5, 2 }, Id = PING, Volume = 0.6, Gap = 0.35 },
	Promotion = { Notes = { 1, 1.26, 1.5, 2 }, Id = PING, Volume = 0.6, Gap = 0.12 },
	PromotionFail = { Id = "rbxasset://sounds/collide.wav", Volume = 0.2, Speed = 0.6 },
	LevelUp = { Notes = { 1.2, 1.5, 1.8 }, Id = PING, Volume = 0.5, Gap = 0.08 },
	-- (2026-10-03) a game's end (hide-and-seek): won, lost
	Victory = { Notes = { 1, 1, 1, 1.26, 1.5, 2 }, Id = PING, Volume = 0.6, Gap = 0.12 },
	-- (2026-10-04, "패배시 소리가 좀 크네": was 0.7)
	Defeat = { Id = "rbxasset://sounds/collide.wav", Volume = 0.4, Speed = 0.5 },
	-- (2026-10-03) hide-and-seek: a hider's heartbeat as the seeker comes near (a low double thud until our own is
	-- uploaded), a trap put down, a trap snapping shut on the seeker
	-- (2026-10-03, "술래잡기 심장박동소리도 … 단단하고 안 늘어지게": "Heartbeat", and its stand-in played at a third of its
	-- speed, broke up and dragged) a new short, solid one; the stand-in at nearly its own speed, cut short
	HeartThump = { Notes = { 0.85, 0.95 }, Id = "rbxasset://sounds/collide.wav", Volume = 0.5, Gap = 0.13, Cut = 0.1 },
	TrapSet = { Id = "rbxasset://sounds/switch.wav", Volume = 0.6, Speed = 0.8 },
	TrapSnap = { Notes = { 1.9, 1.3 }, Id = "rbxasset://sounds/collide.wav", Volume = 0.42, Gap = 0.05 }, -- (clack-clack;
	-- 2026-10-04, "함정에 걸리면 소리가 너무 크게나": was 0.9, then 0.55 → "조금만 더 낮춰")
	-- (2026-10-04, "속도발판 소리 조금 줄이자": was 0.5; "발판 소리아직도 크고": 0.3 → 0.15)
	SpeedPad = { Id = "rbxasset://sounds/Rocket whoosh 01.wav", Volume = 0.15, Speed = 1.6, Cut = 0.35 },
	Thunder = { Id = "rbxasset://sounds/Launching rocket.wav", Volume = 0.7, Speed = 0.35 },
	Weather = { Id = "rbxasset://sounds/impact_water.mp3", Volume = 0.7 },
	Buy = { Id = "rbxasset://sounds/switch.wav", Volume = 0.5 },
	Splat = { Id = "rbxasset://sounds/splat.wav", Volume = 0.6 }, -- a pterosaur dropping lands
	-- (2026-10-01) bombs, the chest shaking, trees slapped: stand-ins until our own are uploaded
	BombBoom = { Id = "rbxasset://sounds/Launching rocket.wav", Volume = 0.8, Speed = 0.5, Cut = 1.2 },
	BombSplat = { Id = "rbxasset://sounds/splat.wav", Volume = 0.8, Speed = 0.7 },
	ChestRattle = { Id = "rbxasset://sounds/collide.wav", Volume = 0.35, Speed = 1.6 },
	-- (2026-10-01: 0.25 → 0.08 → 0.03 "too loud" (the fruit's thump and the far trees' bug were in it too) → 0.15:
	-- now the hit's only sound, the fruit falls quietly)
	TreeRustle = { Id = "rbxasset://sounds/Rocket whoosh 01.wav", Volume = 0.15, Speed = 2, Cut = 0.6 },
	FruitThud = { Id = "rbxasset://sounds/collide.wav", Volume = 0.25, Speed = 0.8 },
	RainLoop = { Volume = 0.45 }, -- no built-in stand-in: silent until uploaded
	StormLoop = { Volume = 0.55 },
	-- 자박자박 on dirt (Footsteps); until uploaded Roblox's own running sound stays. (2026-10-03, "발소리 높히고",
	-- "발소리가 거의 안들려서": was 0.3; heard from the camera, a dozen studs behind, it was a third of that)
	Footstep = { Volume = 0.9 },
	-- (2026-10-04, "뛸때 훈련 발자국 소리 넣어줘야 뛰는 속도에맞춰서", "작게라도") a quick "탁" on the treadmill's rubber
	-- belt, every foot of the training run (TrainingFx); a built-in knock, high and short, stands in until uploaded
	TreadStep = { Id = "rbxasset://sounds/collide.wav", Volume = 0.04, Speed = 2.1, Cut = 0.06 }, -- ("트레드밀 발소리 너무 크다": was 0.35, then 0.14, 0.07; "아직도 너무 커", "존나 크다고")
	-- the defense fight (DefenseView); the attacks have built-in stand-ins (never the death sound) until
	-- our own are uploaded, the bones are silent until then
	DinoBite = { Id = "rbxasset://sounds/swordslash.wav", Volume = 0.45, Speed = 0.7 }, -- a meat-eater's attack
	DinoStomp = { Id = "rbxasset://sounds/collide.wav", Volume = 0.38, Speed = 0.5 }, -- a plant-eater's or armored dino's area attack
	DinoSwoop = { Id = "rbxasset://sounds/Rocket whoosh 01.wav", Volume = 0.4, Speed = 1.8, Cut = 0.3 }, -- a flyer's dive
	DinoSplash = { Id = "rbxasset://sounds/impact_water.mp3", Volume = 0.3, Speed = 1.2, Cut = 0.5 }, -- a sea dino's water attack
	-- (2026-10-04, "번개는 소리도 안나네 속성공격", "사운드너무 크게 넣지말고") a ⚡ electric dino's hit: a soft crackle under its bite or
	-- stomp; three quick high pings stand in until uploaded
	ElecZap = { Notes = { 2.8, 2.2, 2.6 }, Id = PING, Volume = 0.3, Gap = 0.03 }, -- (× 0.6 in DefenseView: under the bite)
	-- (2026-10-04, "모든 속성 공격사운드 다존재하나?") every attribute its own soft sound over the attack: 🔥 a flame puff, ❄️ an
	-- ice crack, 💧 a drop, ☠️ bubbles, ⛰️ a rock thud (silent until uploaded; ⚪ Neutral none)
	FireWhoosh = { Volume = 0.35 },
	IceCrack = { Volume = 0.35 },
	WaterDrop = { Volume = 0.35 },
	PoisonBubble = { Volume = 0.35 },
	EarthThud = { Volume = 0.35 },
	BoneHit = { Volume = 0.35 }, -- a fossil hit
	BoneBreak = { Volume = 0.45 }, -- a fossil falling apart
	BoneStep = { Volume = 0.16 }, -- fossils rattling as they walk
	BossRoar = { Volume = 0.7 }, -- the promotion boss comes
	-- dino voices (Shared/DinoVoices picks one per species): our own sounds only, silent until uploaded
	VoiceRoar = { Volume = 0.5 },
	VoiceBellow = { Volume = 0.45 },
	VoiceHonk = { Volume = 0.45 },
	VoiceChirp = { Volume = 0.4 },
	VoiceGrunt = { Volume = 0.45 },
	VoiceScreech = { Volume = 0.4 },
	VoiceSea = { Volume = 0.4 },
	-- the ridden dino's big roar (울부짖기, Ride; DinoVoices.roar picks one by the species' voice). Loud and
	-- long; built-in stand-ins (a low rumble, a whoosh, a slash, a thud) until our own are uploaded
	MountRoar = { Id = "rbxasset://sounds/Launching rocket.wav", Volume = 0.85, Speed = 0.45, Cut = 1.6, Always = true },
	MountBellow = { Id = "rbxasset://sounds/Launching rocket.wav", Volume = 0.75, Speed = 0.33, Cut = 1.7, Always = true },
	MountHonk = { Id = "rbxasset://sounds/Rocket whoosh 01.wav", Volume = 0.7, Speed = 0.55, Cut = 1.3, Always = true },
	MountChirp = { Id = "rbxasset://sounds/swordslash.wav", Volume = 0.7, Speed = 1.5, Always = true },
	MountGrunt = { Id = "rbxasset://sounds/collide.wav", Volume = 0.8, Speed = 0.35, Always = true },
	-- flying high on a sky dino: a gust of wind now and then ("휘이익")
	-- (2026-10-04, "공중 바람소리 아직도 크고": the gusts 0.3 → 0.15, the steady wind 0.5 → 0.25)
	WindGust = { Id = "rbxasset://sounds/Rocket whoosh 01.wav", Volume = 0.15, Speed = 0.45 },
	-- every button press (UiSounds), and a countdown's numbers and its end (기지로, races)
	UiClick = { Id = PING, Volume = 0.18, Speed = 2.2 },
	CountTick = { Id = PING, Volume = 0.45, Speed = 1.0 },
	CountGo = { Id = PING, Volume = 0.6, Speed = 1.5 },
	-- keys brought home (Keys, Net push KeysHome): a jingle and a rising chime
	KeysHome = { Id = "rbxasset://sounds/electronicpingshort.wav", Volume = 0.7, Speed = 0.8 },
	-- someone rang their bell to show where they are (Bell): a hand bell, three swings
	BellRing = { Notes = { 1, 0.94, 1 }, Id = PING, Volume = 0.6, Gap = 0.3 },
	NpcHello = { Notes = { 1.5, 1.9 }, Id = PING, Volume = 0.4, Gap = 0.1 }, -- a shopkeeper dino greets
	NpcGrowl = { Volume = 0.45 }, -- a low, friendly growl
	-- the night's zombie dinos (Zombies): a sleepy silly moan, the ground cracking as one climbs out,
	-- sinking back in, a soft bonk when one hits; built-in stand-ins until our own are uploaded
	ZombieGroan = { Volume = 0.45 },
	ZombieRise = { Id = "rbxasset://sounds/collide.wav", Volume = 0.55, Speed = 0.4 },
	ZombieSink = { Id = "rbxasset://sounds/collide.wav", Volume = 0.45, Speed = 0.3 },
	ZombieHit = { Id = "rbxasset://sounds/splat.wav", Volume = 0.6, Speed = 0.8 },
	-- (2026-10-02, "찰싹 맞을때 비명울음 짧게 … 거대공룡은 크르릉") slapped: a little wild dino's or a zombie's short
	-- squeal, a giant long-neck's deep rolling growl (silent until uploaded, like the dino voices)
	DinoYelp = { Volume = 0.55 },
	GiantGrowl = { Volume = 0.65 },
	-- (2026-10-03, "공룡 발걸음 소리나 익룡 파닥거릴때 소리도 넣어", "그리고 모든 공룡과 익룡들에게 적용해") every walking
	-- dino's footfalls and every flying pterosaur's wingbeats (Shared/DinoMotion). (2026-10-03, "탈것 타는 중에 소리가
	-- 다 그냥 발소리잖아": silent until uploaded, so riding only the person's running was heard) built-in stand-ins
	-- until then: a deep thump, a short whoosh
	-- (2026-10-03, "공룡 발자국 소리 존나 깨지고 늘어지네 … 새로운 음을 쓰던가. 단단하고 안 늘어지게. 그리고 소리도 너무커":
	-- "DinoStep" was a deep boom, and its stand-in played at 0.6 speed or slower) a new short, solid knock, quieter;
	-- the stand-in at nearly its own speed, cut short
	DinoFoot = { Id = "rbxasset://sounds/collide.wav", Volume = 0.12, Speed = 0.9, Cut = 0.12 }, -- ("공룡 발자국 소리들 더 줄여": was 0.35, then 0.2, "너무 커"; 0.1, then 2026-10-04 "육지공룡 발자국 소리 아주조금 올려도": 0.12)
	WingFlap = { Id = "rbxasset://sounds/Rocket whoosh 01.wav", Volume = 1.1, -- (2026-10-04, "익룡 날개소리 조금 키워봐": was 0.45,
		-- then 0.6; "날갯짓 소리도 살짝 올려줘도": 0.75; "익룡 날개소리 조금 올려도 될듯": 0.9; "익룡 날개소리 작다": 1.1)
		Speed = 1.6, Cut = 0.25 }, -- (stand-in was 2.2: shrill)
	-- (2026-10-03, "하늘높이가면 바람소리") flying a pterosaur: a steady wind, louder the higher (Ride.client); a loop,
	-- so nothing until uploaded (the gusts, WindGust, have a stand-in)
	WindLoop = { Volume = 0.25 },
	-- (2026-10-03, "야생공룡이 유저를 떨쳐낼때 소리이펙트 넣고 유저날아갈때도 소리이펙트 넣어") a wild dino bucking its
	-- rider off, and anyone thrown through the air (Net push FlyFx, CombatFx), on the flier
	BuckOff = { Id = "rbxasset://sounds/collide.wav", Volume = 0.5, Speed = 0.7 },
	FlyWhoosh = { Id = "rbxasset://sounds/Rocket whoosh 01.wav", Volume = 0.35, Speed = 1.1, Cut = 0.9 },
	CocoBabbleA = { Id = PING, Volume = 0.6, Speed = 2.4, Cut = 0.07 },
	CocoBabbleI = { Id = PING, Volume = 0.6, Speed = 2.8, Cut = 0.07 },
	CocoBabbleU = { Id = PING, Volume = 0.6, Speed = 2.1, Cut = 0.07 },
	CocoBabbleO = { Id = PING, Volume = 0.6, Speed = 2.25, Cut = 0.07 },
	CocoHappy = { Notes = { 2, 2.5 }, Id = PING, Volume = 0.7, Gap = 0.12 },
	WitchBabbleA = { Id = PING, Volume = 0.55, Speed = 1.75, Cut = 0.08 },
	WitchBabbleI = { Id = PING, Volume = 0.55, Speed = 2.05, Cut = 0.08 },
	WitchBabbleE = { Id = PING, Volume = 0.55, Speed = 1.9, Cut = 0.08 },
	WitchBabbleO = { Id = PING, Volume = 0.55, Speed = 1.6, Cut = 0.08 },
	WitchGiggle = { Notes = { 2.3, 2.6, 2.9, 2.7 }, Id = PING, Volume = 0.6, Gap = 0.075 },
	WitchHuff = { Notes = { 1.3, 1.05 }, Id = PING, Volume = 0.55, Gap = 0.09 },
	WitchCry = { Notes = { 1.9, 1.75, 1.6, 1.45 }, Id = PING, Volume = 0.55, Gap = 0.15 },
}
-- (Cut = seconds: the sound is faded out and stopped then, for a stand-in that runs too long)

-- uploaded audio ids by name (0 = not uploaded); a Sound in SoundService.GameSounds wins over these
local UPLOADED = {
	SlapSwing = 0, SlapHit = 0, KnockOut = 0, MineHit = 0, KeyPickup = 0, KeyDrop = 0, SpecialKey = 0,
	Deposit = 0, Buy = 0, GachaCard = 0, GachaBig = 0, Promotion = 0, PromotionFail = 0, LevelUp = 0, Victory = 0, Defeat = 0,
	SpeedPad = 0, Thunder = 0, Weather = 0, RainLoop = 0, StormLoop = 0, NpcHello = 0, NpcGrowl = 0,
	Splat = 0, Footstep = 0, TreadStep = 0, MinePop = 0,
	DinoBite = 0, DinoStomp = 0, DinoSwoop = 0, DinoSplash = 0, ElecZap = 0, FireWhoosh = 0, IceCrack = 0, WaterDrop = 0, PoisonBubble = 0, EarthThud = 0, BoneHit = 0, BoneBreak = 0, BoneStep = 0,
	BossRoar = 0, VoiceRoar = 0, VoiceBellow = 0, VoiceHonk = 0, VoiceChirp = 0, VoiceGrunt = 0,
	VoiceScreech = 0, VoiceSea = 0,
	MountRoar = 0, MountBellow = 0, MountHonk = 0, MountChirp = 0, MountGrunt = 0, WindGust = 0, UiClick = 0, CountTick = 0, CountGo = 0, KeysHome = 0, BellRing = 0,
	ZombieGroan = 0, ZombieRise = 0, ZombieSink = 0, ZombieHit = 0,
	GachaSuspense = 0, GachaLegend = 0, GachaRainbow = 0, GachaDark = 0, GachaHeaven = 0, GachaCosmic = 0,
	Rebirth = 0, BombBoom = 0, BombSplat = 0, ChestRattle = 0, TreeRustle = 0, FruitThud = 0,
	DinoYelp = 0, GiantGrowl = 0, HeartThump = 0, TrapSet = 0, TrapSnap = 0,
	DinoFoot = 0, WingFlap = 0, BuckOff = 0, FlyWhoosh = 0, WindLoop = 0,
	CocoBabbleA = 0, CocoBabbleI = 0, CocoBabbleU = 0, CocoBabbleO = 0, CocoHappy = 0,
	WitchBabbleA = 0, WitchBabbleI = 0, WitchBabbleE = 0, WitchBabbleO = 0, WitchGiggle = 0, WitchHuff = 0, WitchCry = 0,
}
local ROLL_OFF_MAX = 120 -- studs: 3D sounds fade out by then
local LONGEST_SECONDS = 12 -- a sound that never loads or ends still goes away after this
local MAX_PLAYING = 40
local MAX_SAME = 5
local SAME_GAP = 0.035
local playing, playingOf, lastAt = 0, {}, {}

local anchor = nil
-- (2026-10-03, "배틀필드 내에서 렉": every step and every hit made a new Part in the Workspace, a few dozen a second with
-- several players running about) an Attachment on the Terrain instead: a place for the sound, nothing for physics
local function worldSound(position)
	local spot = Instance.new("Attachment")
	spot.Name = "SfxSpot"
	spot.Position = position -- (the Terrain sits at the origin: its attachments' positions are world positions)
	spot.Parent = Workspace.Terrain
	return spot
end

local CUT_FADE = 0.08 -- seconds to fade out a cut sound
local OWN_PRELOAD_DELAY = 12
local OWN_PRELOAD_BATCH = 8
local OWN_PRELOAD_GAP = 1.5
local OWN_PRELOAD_FIRST = "Mount"

local function playOne(id, volume, speed, position, cut, name, always)
	if not always and (playing >= MAX_PLAYING or (playingOf[name] or 0) >= MAX_SAME) then
		return nil
	end
	playing += 1
	playingOf[name] = (playingOf[name] or 0) + 1
	local released = false
	local function release()
		if not released then
			released = true
			playing -= 1
			playingOf[name] -= 1
		end
	end
	local sound = Instance.new("Sound")
	sound.Destroying:Connect(release)
	sound.SoundId = id
	sound.Volume = volume
	sound.PlaybackSpeed = speed or 1
	sound.RollOffMaxDistance = ROLL_OFF_MAX
	local parent
	local onPart = typeof(position) == "Instance" -- (a part or attachment: the sound goes along with it)
	if onPart then
		parent = position
	elseif position then
		parent = worldSound(position)
	else
		anchor = anchor or SoundService
		parent = anchor
	end
	sound.Parent = parent
	sound:Play()
	if cut then -- a short version of a long sound: fade out and stop, counted from when it really starts
		task.spawn(function()
			local waited = 0
			while not sound.IsLoaded and sound.Parent and waited < LONGEST_SECONDS - cut do
				waited += task.wait()
			end
			task.wait(cut)
			if sound.Parent then
				TweenService:Create(sound, TweenInfo.new(CUT_FADE), { Volume = 0 }):Play()
				task.delay(CUT_FADE, function()
					sound:Destroy()
				end)
			end
		end)
	end
	sound.Ended:Connect(function()
		sound:Destroy()
		if position and not onPart then
			parent:Destroy()
		end
	end)
	task.delay(LONGEST_SECONDS, function() -- a sound that never loads still goes away
		release()
		if sound.Parent then
			sound:Destroy()
		end
		if position and not onPart and parent.Parent then
			parent:Destroy()
		end
	end)
	return sound
end

-- the uploaded sound for name ("rbxassetid://..."), or nil
local function uploaded(name)
	local folder = SoundService:FindFirstChild("GameSounds")
	local sound = folder and folder:FindFirstChild(name)
	if sound and sound:IsA("Sound") and sound.SoundId ~= "" then
		return sound.SoundId
	end
	local id = UPLOADED[name]
	return id and id ~= 0 and ("rbxassetid://" .. id) or nil
end

-- (gain: × its usual loudness, 1 when left out)
function Sfx.play(name, position, pitch, gain)
	local s = SOUNDS[name]
	if not s then
		return
	end
	local now = os.clock()
	if now - (lastAt[name] or -math.huge) < SAME_GAP then
		return nil
	end
	lastAt[name] = now
	local volume = s.Volume * (gain or 1)
	local own = uploaded(name)
	if own then
		return playOne(own, volume, pitch or 1, position, nil, name, s.Always)
	elseif not s.Id then
		return nil -- nothing to stand in for it
	elseif s.Notes then
		task.spawn(function()
			for _, note in ipairs(s.Notes) do
				playOne(s.Id, volume, note * (pitch or 1), position, s.Cut, name, s.Always)
				task.wait(s.Gap)
			end
		end)
		return nil
	end
	return playOne(s.Id, volume, (s.Speed or 1) * (pitch or 1), position, s.Cut, name, s.Always)
end

-- a looping sound (rain, storm) at volume 0, playing; nil when it has no sound yet
function Sfx.loop(name)
	local s = SOUNDS[name]
	local id = s and (uploaded(name) or s.Id)
	if not id then
		return nil
	end
	local sound = Instance.new("Sound")
	sound.Name = name
	sound.SoundId = id
	sound.Looped = true
	sound.Volume = 0
	sound.Parent = SoundService
	sound:Play()
	return sound
end

-- has this sound been uploaded (so the game's own version plays)?
function Sfx.hasOwn(name)
	return uploaded(name) ~= nil
end

-- how loud a sound is meant to be (for fading loops in)
function Sfx.volume(name)
	local s = SOUNDS[name]
	return s and s.Volume or 0.5
end

-- load the built-in stand-ins once at the start, so the first play of each isn't late (or cut off)
task.spawn(function()
	local ids, seen = {}, {}
	for _, s in pairs(SOUNDS) do
		if s.Id and not seen[s.Id] then
			seen[s.Id] = true
			table.insert(ids, s.Id)
		end
	end
	pcall(function()
		game:GetService("ContentProvider"):PreloadAsync(ids)
	end)
	task.wait(OWN_PRELOAD_DELAY)
	local folder = SoundService:FindFirstChild("GameSounds")
	local own, names = {}, {}
	for _, child in ipairs(folder and folder:GetChildren() or {}) do
		if child:IsA("Sound") and child.SoundId ~= "" and SOUNDS[child.Name] then
			table.insert(own, child)
			names[child.SoundId] = child.Name
		end
	end
	table.sort(own, function(a, b)
		local fa, fb = a.Name:sub(1, #OWN_PRELOAD_FIRST) == OWN_PRELOAD_FIRST, b.Name:sub(1, #OWN_PRELOAD_FIRST) == OWN_PRELOAD_FIRST
		if fa ~= fb then
			return fa
		end
		return a.Name < b.Name
	end)
	local failed = {}
	for from = 1, #own, OWN_PRELOAD_BATCH do
		local batch = table.move(own, from, math.min(#own, from + OWN_PRELOAD_BATCH - 1), 1, {})
		pcall(function()
			game:GetService("ContentProvider"):PreloadAsync(batch, function(contentId, status)
				if status == Enum.AssetFetchStatus.Failure then
					table.insert(failed, names[contentId] or contentId)
				end
			end)
		end)
		task.wait(OWN_PRELOAD_GAP)
	end
	if #failed > 0 and game:GetService("RunService"):IsStudio() then
		table.sort(failed)
		print(string.format("[Sfx] GameSounds에서 못 불러온 소리 %d개 (무음): %s", #failed, table.concat(failed, ", ")))
	end
end)

-- (2026-10-03, "아직 다 똑같잖아 뭘 고쳤다는 거야") in Studio, once: which of the game's sounds have no uploaded
-- file (SoundService.GameSounds) and play a built-in stand-in, or nothing; and which files there the game no
-- longer uses (an old name)
if game:GetService("RunService"):IsStudio() and game:GetService("RunService"):IsClient() then
	task.delay(3, function()
		local missing, unused = {}, {}
		for name in pairs(SOUNDS) do
			if not uploaded(name) then
				table.insert(missing, name)
			end
		end
		local folder = SoundService:FindFirstChild("GameSounds")
		for _, child in ipairs(folder and folder:GetChildren() or {}) do
			if child:IsA("Sound") and not SOUNDS[child.Name] then
				table.insert(unused, child.Name)
			end
		end
		table.sort(missing)
		table.sort(unused)
		print(string.format("[Sfx] 파일이 안 올라간 소리 %d개 (기본 대신 소리나 무음): %s", #missing, table.concat(missing, ", ")))
		if #unused > 0 then
			print("[Sfx] GameSounds에 있지만 안 쓰는 옛 이름: " .. table.concat(unused, ", "))
		end
	end)
end

return Sfx
