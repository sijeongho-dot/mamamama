local Sfx = require(script.Parent:WaitForChild("Sfx"))

local CocoVoice = {}

local VOWELS = { "CocoBabbleA", "CocoBabbleI", "CocoBabbleU", "CocoBabbleO" }
local CHARS_PER_BLIP = 3
local BLIPS_MIN, BLIPS_MAX = 3, 10
local GAP = 0.085
local PITCH_LOW, PITCH_HIGH = 0.92, 1.14
local GAIN = 1

local WITCH_VOWELS = { "WitchBabbleA", "WitchBabbleI", "WitchBabbleE", "WitchBabbleO" }
local WITCH_GAP = 0.075
local WITCH_PITCH = 1
local WITCH_SWING = 0.1
local WITCH_JITTER = 0.04
local WITCH_FALL = 0.12
local WITCH_ANGRY_PITCH, WITCH_ANGRY_GAP = 0.9, 0.06
local WITCH_SAD_PITCH, WITCH_SAD_GAP = 0.95, 0.1
local WITCH_GAIN = 1
local WITCH_MOODS = { Angry = "WitchHuff", Sad = "WitchCry", Happy = "WitchGiggle" }
local WITCH_FIRST = { Angry = true }
local WITCH_SIGNS = { { "💢", "Angry" }, { "😤", "Angry" }, { "😭", "Sad" } }

local talking = 0

function CocoVoice.babble(text, at)
	text = tostring(text or "")
	local length = utf8.len(text) or #text
	local blips = math.clamp(math.floor(length / CHARS_PER_BLIP), BLIPS_MIN, BLIPS_MAX)
	talking += 1
	local mine = talking
	for i = 0, blips - 1 do
		task.delay(i * GAP, function()
			if talking == mine then
				Sfx.play(VOWELS[math.random(1, #VOWELS)], at, PITCH_LOW + math.random() * (PITCH_HIGH - PITCH_LOW), GAIN)
			end
		end)
	end
	if string.find(text, "!") then
		task.delay(blips * GAP, function()
			if talking == mine then
				Sfx.play("CocoHappy", at, 1, GAIN)
			end
		end)
	end
end

local witchTalking = 0

function CocoVoice.witch(text, at, mood)
	text = tostring(text or "")
	if not mood then
		for _, sign in ipairs(WITCH_SIGNS) do
			if string.find(text, sign[1], 1, true) then
				mood = sign[2]
				break
			end
		end
	end
	mood = mood or (string.find(text, "!") and "Happy" or nil)
	local length = utf8.len(text) or #text
	local blips = math.clamp(math.floor(length / CHARS_PER_BLIP), BLIPS_MIN, BLIPS_MAX)
	local base = mood == "Angry" and WITCH_ANGRY_PITCH or mood == "Sad" and WITCH_SAD_PITCH or WITCH_PITCH
	local gap = mood == "Angry" and WITCH_ANGRY_GAP or mood == "Sad" and WITCH_SAD_GAP or WITCH_GAP
	witchTalking += 1
	local mine = witchTalking
	local start = 0
	local cue = mood and WITCH_MOODS[mood]
	if cue and WITCH_FIRST[mood] then
		Sfx.play(cue, at, 1, WITCH_GAIN)
		start = gap * 2
	end
	for i = 0, blips - 1 do
		local up = (i % 2 == 0) and WITCH_SWING or -WITCH_SWING
		local pitch = base + up - WITCH_FALL * i / blips + (math.random() * 2 - 1) * WITCH_JITTER
		task.delay(start + i * gap, function()
			if witchTalking == mine then
				Sfx.play(WITCH_VOWELS[math.random(1, #WITCH_VOWELS)], at, pitch, WITCH_GAIN)
			end
		end)
	end
	if cue and not WITCH_FIRST[mood] then
		task.delay(start + blips * gap, function()
			if witchTalking == mine then
				Sfx.play(cue, at, 1, WITCH_GAIN)
			end
		end)
	end
end

return CocoVoice
