--[[
TopBar: one row of small buttons at the top right of the screen, next to Roblox's own top bar,
so the bottom left stays free for the phone's move stick (display only, clients).

Every client script adds its buttons here; LayoutOrder sets their order from the left. A small "▶"
at the right end folds the row away (only "◀" stays) and brings it back.

	local button = TopBar.button("뽑기", 2, Color3.fromRGB(240, 120, 60))
]]

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local FrameMeter = require(script.Parent:WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)

local TopBar = {}

-- display only
local BUTTON_SIZE = UDim2.fromOffset(64, 34) -- narrow: the row stays short on phones
local GAP = 6
local TOP = 6 -- inside the strip of Roblox's top bar (the gui ignores its inset)
local RIGHT = 8
local TEXT_SIZE = 13
local FOLD_SIZE = UDim2.fromOffset(26, 34)
local FOLD_ORDER = 1000 -- the rightmost
local COLOR_FOLD = Color3.fromRGB(60, 64, 80)
local LEFT_ROOM = 12 -- pixels kept free right of the button the row stays right of (a badge on the first button sticks out)
local MIN_SCALE = 0.55 -- the row never shrinks below this

local DOT_SIZE = 12
local COLOR_DOT = Color3.fromRGB(235, 50, 60)
local DOT_ATTRIBUTES = { "BoxesReady" }

local row = nil
local keepRight = nil -- the GuiObject the row stays right of (TopBar.keepRightOf)
local folded = true
local pinned = setmetatable({}, { __mode = "k" })
local hidden = setmetatable({}, { __mode = "k" })
local foldButton = nil
local dot = nil

local function getRow()
	if row then
		return row
	end
	local gui = Instance.new("ScreenGui")
	gui.Name = "TopBar"
	gui.ResetOnSpawn = false
	gui.IgnoreGuiInset = true
	gui.DisplayOrder = 5
	gui.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")
	row = Instance.new("Frame")
	row.AnchorPoint = Vector2.new(1, 0)
	row.Position = UDim2.new(1, -RIGHT, 0, TOP)
	row.Size = UDim2.fromOffset(0, BUTTON_SIZE.Y.Offset)
	row.AutomaticSize = Enum.AutomaticSize.X
	row.BackgroundTransparency = 1
	row.Parent = gui
	local layout = Instance.new("UIListLayout")
	layout.FillDirection = Enum.FillDirection.Horizontal
	layout.HorizontalAlignment = Enum.HorizontalAlignment.Right
	layout.SortOrder = Enum.SortOrder.LayoutOrder
	layout.Padding = UDim.new(0, GAP)
	layout.Parent = row
	local fold = Instance.new("TextButton")
	fold.Name = "FoldTop"
	fold.LayoutOrder = FOLD_ORDER
	fold.Size = FOLD_SIZE
	fold.BackgroundColor3 = COLOR_FOLD
	fold.BackgroundTransparency = 0.2
	fold.Font = Enum.Font.GothamBold
	fold.TextSize = TEXT_SIZE
	fold.TextColor3 = Color3.new(1, 1, 1)
	fold.Text = folded and "◀" or "▶"
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 8)
	c.Parent = fold
	fold.Parent = row
	foldButton = fold
	dot = Instance.new("Frame")
	dot.Name = "Attention"
	dot.AnchorPoint = Vector2.new(0.5, 0.5)
	dot.Position = UDim2.fromScale(0, 0)
	dot.Size = UDim2.fromOffset(DOT_SIZE, DOT_SIZE)
	dot.BackgroundColor3 = COLOR_DOT
	dot.Visible = false
	dot.Parent = fold
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = dot
	local function refreshDot()
		local any = false
		for _, name in ipairs(DOT_ATTRIBUTES) do
			local v = Players.LocalPlayer:GetAttribute(name)
			any = any or (type(v) == "number" and v > 0) or v == true
		end
		dot.Visible = folded and any
	end
	for _, name in ipairs(DOT_ATTRIBUTES) do
		Players.LocalPlayer:GetAttributeChangedSignal(name):Connect(refreshDot)
	end
	refreshDot()
	-- (2026-10-02, "아이폰에서 ui 겹침 사태 발생") the row shrinks (UIScale, kept at the right) to fit right of
	-- the defense line at the top middle
	local scale = Instance.new("UIScale")
	scale.Parent = row
	-- worked out from the screens' sizes and the buttons' own sizes (not what was last drawn)
	RunService.Heartbeat:Connect(FrameMeter.wrap("TopBar", function()
		local other = keepRight
		local otherGui = other and other.Parent
		if not other or not otherGui or not otherGui:IsA("ScreenGui") or not other.Visible then
			if scale.Scale ~= 1 then
				scale.Scale = 1
			end
			return
		end
		local width, count = 0, 0
		for _, b in ipairs(row:GetChildren()) do
			if b:IsA("GuiObject") and b.Visible then
				width += b.Size.X.Offset
				count += 1
			end
		end
		width += GAP * math.max(0, count - 1)
		local otherRight = otherGui.AbsolutePosition.X + otherGui.AbsoluteSize.X * other.Position.X.Scale
			+ other.Position.X.Offset + (1 - other.AnchorPoint.X) * other.Size.X.Offset
		local rowRight = gui.AbsolutePosition.X + gui.AbsoluteSize.X - RIGHT
		if width <= 0 then
			return
		end
		local want = math.clamp((rowRight - otherRight - LEFT_ROOM) / width, MIN_SCALE, 1)
		if math.abs(want - scale.Scale) > 0.005 then
			scale.Scale = want
		end
	end))
	fold.Activated:Connect(function()
		TopBar.setFolded(not folded)
	end)
	TopBar.refreshDot = refreshDot
	return row
end

function TopBar.setFolded(on)
	getRow()
	folded = on
	foldButton.Text = folded and "◀" or "▶"
	for _, b in ipairs(row:GetChildren()) do
		if b:IsA("GuiButton") and b ~= foldButton then
			b.Visible = not hidden[b] and (not folded or pinned[b] == true)
		end
	end
	TopBar.refreshDot()
end

function TopBar.pin(button)
	pinned[button] = true
	button.Visible = not hidden[button]
end

function TopBar.setHidden(button, on)
	if (hidden[button] == true) == on then
		return
	end
	hidden[button] = on or nil
	button.Visible = not on and (not folded or pinned[button] == true)
end

function TopBar.isFolded()
	return folded
end

function TopBar.foldButton()
	getRow()
	return foldButton
end

function TopBar.find(match)
	for _, b in ipairs(getRow():GetChildren()) do
		if b:IsA("GuiButton") and b ~= foldButton and match(b) then
			return b
		end
	end
	return nil
end

-- the bottom of the bar in screen pixels (for windows that open under it)
TopBar.BOTTOM = TOP + BUTTON_SIZE.Y.Offset

-- the row keeps to the right of this (the defense line at the top middle), shrinking to fit
function TopBar.keepRightOf(other)
	keepRight = other
	getRow()
end

function TopBar.button(text, order, color)
	local b = Instance.new("TextButton")
	b.Name = text
	b.LayoutOrder = order
	b.Size = BUTTON_SIZE
	b.BackgroundColor3 = color
	b.Font = Enum.Font.GothamBold
	b.TextSize = TEXT_SIZE
	b.TextColor3 = Color3.new(1, 1, 1)
	b.TextWrapped = true
	b.Text = text
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 8)
	c.Parent = b
	b.Visible = not folded
	b.Parent = getRow()
	return b
end

return TopBar
