--[[
Notices: the small stack of notices at the left middle of the screen (display only, clients), clear of
the phone's move stick below and the buttons on the right. The server's notices (Net push Notice, Client)
and, since 2026-10-02, the announcements that were big banners across the middle of the screen (key drops,
the King Key, the weather, "열쇠를 집으로 가져가요!": CombatFx; "자막도 어떻게 좀 해봐 화면 다 가리네 가독성은
잃지말고 … 왼쪽에 편성하든가 다른 알림들처럼") come here.

	Notices.show(title, text)                          -- a plain notice (title in gold, text in white)
	Notices.show(nil, text, { color = c, big = true }) -- an announcement: its text in its color, a bit bigger,
	                                                   -- a thin outline in its color
	Notices.show(nil, text, { key = "Countdown" })     -- the one with that key is updated in place (its text
	                                                   -- changes, it stays up longer): a countdown "3…2…1"
	Notices.show(title, text, { key = "BossWave" })    -- the same with a new title: the card changes over
	Notices.show(title, text, { key = k, pin = true }) -- pinned on top (not counted in MAX_SHOWN) until Notices.hide(k)
The same notice again just stays up longer; (2026-10-07, "중복 되는 내용도 같이 있는 거 아니오. 좀 정리해서 줄여")
a newer one with the same title takes the older one's card. At most MAX_SHOWN at once, the oldest goes first.
(2026-10-04, "알림창 더더욱 눈에 띄게") a bright card (warm orange to pink; an announcement in its own color), its
picture big in a round badge at its left (the notice's first emoji, taken off the words; 📢 without one), white
words with a dark edge, a bouncy pop and a wiggle as it comes, a glowing white edge, and a bar along its
bottom running down while it stays up. The words are put in the player's language here (Shared/Lang) so the
emoji can come off them.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Lang = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Lang"))

local Notices = {}

-- display only
local FONT = Enum.Font.GothamBold
local STACK_WIDTH = 205 -- (was 300, text 18, then 240, 210, 185: took much of a phone's screen; 2026-10-02 "이 창들도 크기 조금 줄이고",
-- "왼쪽 알림창 가로폭 줄이고"; 2026-10-04 205 with the picture badge)
local TITLE_TEXT, BODY_TEXT, BIG_TEXT = 14, 15, 17 -- (were 12, 14, 16, then 11, 12, 14; 2026-10-04 "왼쪽 알림칸 폰트가 너무 작은거 같기도"
-- → 13, 14, 16; "왼쪽 알림 더 눈에 띄게 하고" → 14, 15, 17)
local STACK_POS = UDim2.new(0, 12, 0.52, 0) -- left middle (2026-10-04: was 0.45; the taller cards reached the mission card)
-- (2026-10-04, "왼쪽 알림 원위치해": the stack stays where it was, its middle at 0.52; "왼쪽 알림들이 많이 뜨면 밑 ui까지
-- 가리는데": the oldest cards go while it would reach down to the 🔔 button (Bell: 30 + 48 from the bottom) and the bag bar)
local STACK_BOTTOM_FREE = 84 -- pixels from the screen's bottom the stack never reaches
local PIN_ORDER = -1 -- (2026-10-07, "이번 맵 정보 뜨는건 라운드 끝날때까지 놔둬. 다른 알림 뜨면 그 밑에") a pinned card: on top, until hidden
local MAX_SHOWN = 2 -- (3 before the announcements came here, then 4; 2026-10-07 "왼쪽에 뜨는 알림 너무 많은데" → 2; fewer when the screen is short)
local GAP = 6
local FADE_SECONDS = 0.3
local OUTLINE = 3 -- pixels: the glowing edge (was 1.5, 2.5)
-- (2026-10-04, "왼쪽 알림 더 눈에 띄게 하고" → "알림창 더더욱 눈에 띄게") a new notice pops in (a moment much bigger, then
-- its size, with a wiggle) and flashes white
local POP_SCALE = 1.35
local POP_SECONDS = 0.35
local WIGGLE_DEGREES = 7
local WIGGLE_SECONDS = 0.7
local FLASH_SECONDS = 0.5
-- (2026-10-04, "왼쪽 알림도 조금씩 반짝여서 존재감은 알리고") every notice's edge glows on and off while it is up
local SHINE_COLOR = Color3.fromRGB(255, 255, 255)
local SHINE_SECONDS = 0.7 -- one glow up (and as long back down)
local SHINE_FROM, SHINE_TO = 0.55, 0 -- the edge's transparency at its faintest and brightest
-- the card: a warm gradient (an announcement: its color, lighter to darker)
local CARD_FROM, CARD_TO = Color3.fromRGB(255, 150, 40), Color3.fromRGB(235, 70, 150)
local CARD_SEE_THROUGH = 0.3 -- (2026-10-04, "왼쪽 알림 다 좋은데 투명도만 조금 올려주자": was 0.05)
local COLOR_TITLE = Color3.fromRGB(255, 248, 170)
local TEXT_EDGE = 0.25 -- the words' dark edge (see-through)
local BADGE = 32 -- pixels: the round picture at the left
local BADGE_TEXT = 22
local BADGE_SEE_THROUGH = 0.3 -- (2026-10-04: was 0.1, with the card)
local BADGE_GAP = 6
local PICTURE = 48
local DEFAULT_ICON = "📢"
local BAR_HEIGHT = 3 -- the time-left bar along the bottom
local BAR_SEE_THROUGH = 0.25
local DISPLAY_ORDER = 4

local stack = nil
local shown = {} -- oldest first: { frame, key, body, ends, title, text (the Korean), titleLabel }
local order = 0

local fit

local function getStack()
	if stack then
		return stack
	end
	local gui = Instance.new("ScreenGui")
	gui.Name = "Notices"
	gui.ResetOnSpawn = false
	gui.DisplayOrder = DISPLAY_ORDER
	local me = Players.LocalPlayer
	local function followTopView()
		gui.Enabled = not me:GetAttribute("TopView")
		if gui.Enabled and fit then
			task.defer(fit)
		end
	end
	followTopView()
	me:GetAttributeChangedSignal("TopView"):Connect(followTopView)
	gui.Parent = me:WaitForChild("PlayerGui")
	stack = Instance.new("Frame")
	stack.AnchorPoint = Vector2.new(0, 0.5)
	stack.Position = STACK_POS
	stack.Size = UDim2.fromOffset(STACK_WIDTH, 0)
	stack.AutomaticSize = Enum.AutomaticSize.Y
	stack.BackgroundTransparency = 1
	stack.Parent = gui
	local layout = Instance.new("UIListLayout")
	layout.SortOrder = Enum.SortOrder.LayoutOrder
	layout.Padding = UDim.new(0, GAP)
	layout.Parent = stack
	return stack
end

local function oldestLoose()
	for _, entry in ipairs(shown) do
		if not entry.pinned then
			return entry
		end
	end
	return nil
end

local function loose()
	local n = 0
	for _, entry in ipairs(shown) do
		if not entry.pinned then
			n += 1
		end
	end
	return n
end

local function pin(entry)
	entry.pinned = true
	entry.frame.LayoutOrder = PIN_ORDER
end

local function remove(entry, now)
	local index = table.find(shown, entry)
	if not index then
		return
	end
	table.remove(shown, index)
	if entry.shine then
		entry.shine:Cancel()
	end
	if now then -- (no room: gone at once, so its space is free for the new one)
		entry.frame:Destroy()
		return
	end
	for _, child in ipairs(entry.frame:GetDescendants()) do
		if child:IsA("TextLabel") then
			TweenService:Create(child, TweenInfo.new(FADE_SECONDS), { TextTransparency = 1, TextStrokeTransparency = 1,
				BackgroundTransparency = 1 }):Play()
		elseif child:IsA("Frame") then
			TweenService:Create(child, TweenInfo.new(FADE_SECONDS), { BackgroundTransparency = 1 }):Play()
		elseif child:IsA("UIStroke") then
			TweenService:Create(child, TweenInfo.new(FADE_SECONDS), { Transparency = 1 }):Play()
		end
	end
	TweenService:Create(entry.frame, TweenInfo.new(FADE_SECONDS), { BackgroundTransparency = 1 }):Play()
	task.delay(FADE_SECONDS, function()
		entry.frame:Destroy()
	end)
end

-- the oldest cards go while the stack (grown both ways from its middle) would reach down past STACK_BOTTOM_FREE
-- (always one stays); a card's size without its pop
fit = function()
	local gui = stack and stack.Parent
	if not gui or not gui:IsA("ScreenGui") then
		return
	end
	local function heightOf(entry)
		local pop = entry.frame:FindFirstChildOfClass("UIScale")
		return entry.frame.AbsoluteSize.Y / (pop and pop.Scale or 1) + GAP
	end
	local middle = gui.AbsoluteSize.Y * STACK_POS.Y.Scale
	local room = 2 * (gui.AbsoluteSize.Y - middle - STACK_BOTTOM_FREE)
	-- and not up over the training panel while it shows (Training.client, at the top middle)
	local training = gui.Parent and gui.Parent:FindFirstChild("Training")
	local panel = training and training:FindFirstChildOfClass("Frame")
	if panel and panel.Visible then
		local below = panel.AbsolutePosition.Y + panel.AbsoluteSize.Y + GAP - gui.AbsolutePosition.Y
		room = math.min(room, 2 * (middle - below))
	end
	-- (2026-10-04) nor up over the beginner mission board and the row under it (StarterMissions.client, top left)
	local board = gui.Parent and gui.Parent:FindFirstChild("StarterMissions")
	if board and board:IsA("ScreenGui") and board.Enabled then
		local bottom = nil
		for _, child in ipairs(board:GetChildren()) do
			if child:IsA("GuiObject") and child.Visible then
				local y = child.AbsolutePosition.Y + child.AbsoluteSize.Y
				bottom = bottom and math.max(bottom, y) or y
			end
		end
		if bottom then
			room = math.min(room, 2 * (middle - (bottom + GAP - gui.AbsolutePosition.Y)))
		end
	end
	local height = 0
	for _, entry in ipairs(shown) do
		height += heightOf(entry)
	end
	while height > room do
		local oldest = oldestLoose()
		if not oldest or oldest == shown[#shown] then
			break
		end
		height -= heightOf(oldest)
		remove(oldest, true)
	end
end

local function line(parent, text, size, color, layoutOrder)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextSize = size
	l.TextColor3 = color
	l.TextWrapped = true
	l.TextStrokeColor3 = Color3.new(0, 0, 0)
	l.TextStrokeTransparency = TEXT_EDGE -- (readable on the bright card)
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.Size = UDim2.new(1, 0, 0, 0)
	l.AutomaticSize = Enum.AutomaticSize.Y
	l.Text = text
	l.LayoutOrder = layoutOrder
	l.Parent = parent
	return l
end

-- the emoji a text starts with (one picture, with its joiners and variation marks) and the words after it; nil when it
-- starts with words
local function isPictureCode(c)
	if c == 0x200D or c == 0xFE0F or c == 0x20E3 or (c >= 0x1F3FB and c <= 0x1F3FF) then
		return true -- (joiners, the emoji form, keycaps, skin tones: parts of one picture)
	end
	if c >= 0x1100 and c <= 0x11FF or c >= 0x3130 and c <= 0x318F or c >= 0xAC00 and c <= 0xD7A3
		or c >= 0x3000 and c <= 0x9FFF then
		return false -- (Korean and the CJK range)
	end
	return c >= 0x2190
end
local function leadingPicture(text)
	if type(text) ~= "string" or text == "" then
		return nil, text
	end
	local stop = nil
	for at, c in utf8.codes(text) do
		if not isPictureCode(c) then
			stop = at
			break
		end
	end
	if stop == 1 then
		return nil, text
	end
	local picture = stop and string.sub(text, 1, stop - 1) or text
	local rest = stop and string.sub(text, stop) or ""
	if rest ~= "" and string.sub(rest, 1, 1) ~= " " then
		return nil, text -- (an emoji glued to a word: left as it is)
	end
	return picture, (string.gsub(rest, "^%s+", ""))
end

-- the words for this player (Shared/Lang) and the picture they start with
local function prepared(title, text)
	local code = Lang.code(Players.LocalPlayer)
	local shownTitle = title and title ~= "" and Lang.t(tostring(title), code) or nil
	local shownText = Lang.t(tostring(text or ""), code)
	local icon, rest = leadingPicture(shownText)
	if icon then
		shownText = rest
	elseif shownTitle then
		icon, rest = leadingPicture(shownTitle)
		if icon then
			shownTitle = rest ~= "" and rest or nil
		end
	end
	return shownTitle, shownText, icon or DEFAULT_ICON
end

-- keep it up for `seconds` more from now (the bar along the bottom starts again)
local function keepUp(entry, seconds)
	if entry.pinned then
		entry.ends = math.huge
		if entry.bar then
			entry.bar.Visible = false
		end
		return
	end
	entry.ends = os.clock() + seconds
	if entry.bar then
		entry.bar.Size = UDim2.new(1, 0, 0, BAR_HEIGHT)
		if entry.barTween then
			entry.barTween:Cancel()
		end
		entry.barTween = TweenService:Create(entry.bar, TweenInfo.new(seconds, Enum.EasingStyle.Linear),
			{ Size = UDim2.new(0, 0, 0, BAR_HEIGHT) })
		entry.barTween:Play()
	end
	task.delay(seconds, function()
		if os.clock() >= entry.ends - 0.05 then
			remove(entry)
		end
	end)
end

local function popAgain(entry)
	local pop = entry.frame:FindFirstChildOfClass("UIScale")
	if pop then
		pop.Scale = POP_SCALE
		TweenService:Create(pop, TweenInfo.new(POP_SECONDS, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
	end
end

local function rewrite(entry, title, text)
	local shownTitle, words, icon = prepared(title, text)
	entry.body.Text = words
	entry.text = text
	if title and title ~= entry.title then
		entry.title = title
		if entry.titleLabel then
			entry.titleLabel.Text = shownTitle or ""
		end
		entry.badge.Text = entry.picture and "" or icon
		popAgain(entry)
	end
end

function Notices.show(title, text, options)
	local me = Players.LocalPlayer
	options = options or {}
	if me and me:GetAttribute("HideNotices") then
		if options.picture then
			options.picture:Destroy()
		end
		return
	end
	local seconds = options.seconds or Config.UI.NoticeSeconds
	if options.key then -- updated in place
		for _, entry in ipairs(shown) do
			if entry.key == options.key then
				if options.picture then
					options.picture:Destroy()
				end
				rewrite(entry, title, text)
				if options.pin then
					pin(entry)
				end
				keepUp(entry, seconds)
				task.defer(fit)
				return
			end
		end
	end
	local key = options.key or (tostring(title) .. "\n" .. tostring(text))
	if title and not options.key then -- (2026-10-07) one card a title: a newer notice of the same title takes its place
		for _, entry in ipairs(shown) do
			if entry.title == title and entry.key ~= key and not entry.pinned and (entry.picture or options.picture) then
				remove(entry, true)
				break
			elseif entry.title == title and entry.key ~= key and not entry.pinned then
				order += 1
				entry.key = key
				entry.frame.LayoutOrder = order
				table.remove(shown, table.find(shown, entry))
				table.insert(shown, entry)
				rewrite(entry, title, text)
				popAgain(entry)
				keepUp(entry, seconds)
				task.defer(fit)
				return
			end
		end
	end
	for _, entry in ipairs(shown) do -- the same notice again just stays up longer
		if entry.key == key then
			remove(entry)
			break
		end
	end
	order += 1
	local shownTitle, shownText, icon = prepared(title, text)
	local accent = options.color or CARD_FROM
	local frame = Instance.new("Frame")
	frame.Size = UDim2.new(1, 0, 0, 0)
	frame.AutomaticSize = Enum.AutomaticSize.Y
	frame.BackgroundColor3 = Color3.new(1, 1, 1) -- (the gradient gives the colors)
	frame.BackgroundTransparency = CARD_SEE_THROUGH
	frame.LayoutOrder = order
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 12)
	c.Parent = frame
	local gradient = Instance.new("UIGradient")
	gradient.Rotation = 20
	if options.color then
		local h, sat, v = options.color:ToHSV()
		gradient.Color = ColorSequence.new(Color3.fromHSV(h, sat * 0.85, math.min(1, v * 1.1)),
			Color3.fromHSV(h, math.min(1, sat * 1.1), v * 0.6))
	else
		gradient.Color = ColorSequence.new(CARD_FROM, CARD_TO)
	end
	gradient.Parent = frame
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, 6), UDim.new(0, 8)
	pad.PaddingTop, pad.PaddingBottom = UDim.new(0, 5), UDim.new(0, 5)
	pad.Parent = frame
	-- the edge glows white on and off while it is up
	local edge = Instance.new("UIStroke")
	edge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	edge.Color = SHINE_COLOR
	edge.Thickness = OUTLINE
	edge.Transparency = SHINE_FROM
	edge.Parent = frame
	local shine = TweenService:Create(edge, TweenInfo.new(SHINE_SECONDS, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
		{ Transparency = SHINE_TO })
	-- the picture, big and round at the left
	local badgeSize = options.picture and PICTURE or BADGE
	local badge = Instance.new("TextLabel")
	badge.Size = UDim2.fromOffset(badgeSize, badgeSize)
	badge.BackgroundColor3 = Color3.new(1, 1, 1)
	badge.BackgroundTransparency = BADGE_SEE_THROUGH
	badge.Font = FONT
	badge.TextSize = BADGE_TEXT
	badge.Text = icon
	badge:SetAttribute("KeepText", true) -- (a picture: nothing to translate)
	badge.Parent = frame
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = badge
	local ring = Instance.new("UIStroke")
	ring.Color = accent
	ring.Thickness = 2
	ring.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	ring.Parent = badge
	if options.picture then
		badge.Text = ""
		options.picture.Size = UDim2.fromScale(1, 1)
		options.picture.Parent = badge
	end
	-- the words beside it
	local words = Instance.new("Frame")
	words.BackgroundTransparency = 1
	words.Position = UDim2.fromOffset(badgeSize + BADGE_GAP, 0)
	words.Size = UDim2.new(1, -(badgeSize + BADGE_GAP), 0, 0)
	words.AutomaticSize = Enum.AutomaticSize.Y
	words.Parent = frame
	local list = Instance.new("UIListLayout")
	list.SortOrder = Enum.SortOrder.LayoutOrder
	list.VerticalAlignment = Enum.VerticalAlignment.Center
	list.Padding = UDim.new(0, 2)
	list.Parent = words
	local minHeight = Instance.new("UISizeConstraint") -- (as tall as the picture at least)
	minHeight.MinSize = Vector2.new(0, badgeSize)
	minHeight.Parent = words
	local titleLabel = nil
	if shownTitle and shownTitle ~= "" then
		titleLabel = line(words, shownTitle, TITLE_TEXT, COLOR_TITLE, 1)
	end
	local body = line(words, shownText or "", options.big and BIG_TEXT or BODY_TEXT, Color3.new(1, 1, 1), 2)
	-- the bar under the words: how long it stays
	local bar = Instance.new("Frame")
	bar.Size = UDim2.new(1, 0, 0, BAR_HEIGHT)
	bar.BackgroundColor3 = Color3.new(1, 1, 1)
	bar.BackgroundTransparency = BAR_SEE_THROUGH
	bar.BorderSizePixel = 0
	bar.LayoutOrder = 3
	bar.Parent = words
	-- the pop, the wiggle and the flash
	local pop = Instance.new("UIScale")
	pop.Scale = POP_SCALE
	pop.Parent = frame
	frame.Rotation = -WIGGLE_DEGREES
	frame.BackgroundTransparency = 0
	gradient.Enabled = false
	frame.Parent = getStack()
	TweenService:Create(pop, TweenInfo.new(POP_SECONDS, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
	TweenService:Create(frame, TweenInfo.new(WIGGLE_SECONDS, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out),
		{ Rotation = 0 }):Play()
	task.delay(FLASH_SECONDS * 0.4, function() -- (white, then its colors)
		if frame.Parent then
			gradient.Enabled = true
			frame.BackgroundTransparency = CARD_SEE_THROUGH
		end
	end)
	shine:Play()
	local entry = { frame = frame, key = key, body = body, shine = shine, bar = bar, title = title, text = text,
		titleLabel = titleLabel, badge = badge, picture = options.picture }
	table.insert(shown, entry)
	if options.pin then
		pin(entry)
	end
	while loose() > MAX_SHOWN do
		remove(oldestLoose())
	end
	keepUp(entry, seconds)
	task.defer(fit)
end

-- (2026-10-04, "이거 한국언데 왜 영어로 뜨냐": a notice that came right after joining, before the saved language was
-- read (English until then, Lang.code), stayed in English; the words are put in at show time, so Translate can't
-- switch them) the language changing puts every notice still up in the new one, from the Korean kept on it
local function relanguage()
	for _, entry in ipairs(shown) do
		if entry.frame.Parent then
			local shownTitle, shownText = prepared(entry.title, entry.text)
			entry.body.Text = shownText or ""
			if entry.titleLabel then
				entry.titleLabel.Text = shownTitle or ""
			end
		end
	end
	task.defer(fit)
end
local function hideAll()
	if not Players.LocalPlayer:GetAttribute("HideNotices") then
		return
	end
	for i = #shown, 1, -1 do
		remove(shown[i])
	end
end
if Players.LocalPlayer then -- (a screen's: required only there)
	Players.LocalPlayer:GetAttributeChangedSignal("Language"):Connect(relanguage)
	Players.LocalPlayer:GetAttributeChangedSignal("HideNotices"):Connect(hideAll)
end

-- take the one with that key away now (e.g. the weather's countdown when the weather comes)
function Notices.hide(key)
	for _, entry in ipairs(shown) do
		if entry.key == key then
			remove(entry)
			return
		end
	end
end

return Notices
