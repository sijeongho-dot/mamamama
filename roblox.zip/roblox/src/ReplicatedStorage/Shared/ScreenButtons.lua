local Players = game:GetService("Players")

local ScreenButtons = {}

local MIN_OBSTACLE = 20
local CHECK_EVERY = 0.25
local MIN_GAP = 0.5
local SAFETY_EVERY = 5

local boxes = {}
local version = 0
local signature = ""
local dirty = true
local walkedAt = -math.huge
local listeners = {}
local started = false
local hooked = setmetatable({}, { __mode = "k" })

local function walkAll(playerGui)
	local list, parts = {}, {}
	local function walk(inst, sg)
		for _, d in ipairs(inst:GetChildren()) do
			if d:IsA("GuiObject") then
				if d.Visible then
					if d:IsA("GuiButton") and d.AbsoluteSize.X >= MIN_OBSTACLE and d.AbsoluteSize.Y >= MIN_OBSTACLE then
						local a = d.AbsolutePosition
						local b = a + d.AbsoluteSize
						table.insert(list, { a, b, sg })
						table.insert(parts, string.format("%d,%d,%d,%d", a.X, a.Y, b.X, b.Y))
					end
					walk(d, sg)
				end
			elseif d:IsA("Folder") then
				walk(d, sg)
			end
		end
	end
	for _, sg in ipairs(playerGui:GetChildren()) do
		if sg:IsA("ScreenGui") and sg.Enabled and sg.Name ~= "TouchGui" then
			walk(sg, sg)
		end
	end
	return list, table.concat(parts, ";")
end

local function markDirty()
	dirty = true
end

local function hook(inst)
	if hooked[inst] then
		return
	end
	if inst:IsA("ScreenGui") then
		hooked[inst] = true
		inst:GetPropertyChangedSignal("Enabled"):Connect(markDirty)
	elseif (inst:IsA("GuiButton") or inst:IsA("Frame") or inst:IsA("ScrollingFrame"))
		and inst:FindFirstAncestorOfClass("ScreenGui") and not inst:FindFirstAncestor("TouchGui") then
		hooked[inst] = true
		inst:GetPropertyChangedSignal("Visible"):Connect(markDirty)
		if inst:IsA("GuiButton") then
			markDirty()
		end
	end
end

local function start()
	if started then
		return
	end
	started = true
	local playerGui = Players.LocalPlayer:WaitForChild("PlayerGui")
	for _, d in ipairs(playerGui:GetDescendants()) do
		hook(d)
	end
	playerGui.DescendantAdded:Connect(hook)
	playerGui.DescendantRemoving:Connect(function(d)
		if d:IsA("GuiButton") or d:IsA("ScreenGui") then
			dirty = true
		end
	end)
	task.spawn(function()
		while true do
			local now = os.clock()
			if (dirty and now - walkedAt >= MIN_GAP) or now - walkedAt >= SAFETY_EVERY then
				dirty = false
				walkedAt = now
				local list, sig = walkAll(playerGui)
				boxes = list
				if sig ~= signature then
					signature = sig
					version += 1
					for _, fn in ipairs(listeners) do
						task.spawn(fn)
					end
				end
			end
			task.wait(CHECK_EVERY)
		end
	end)
end

function ScreenButtons.boxes(exceptGui, gap)
	start()
	local out = {}
	for _, box in ipairs(boxes) do
		if box[3] ~= exceptGui then
			table.insert(out, { box[1], box[2], gap })
		end
	end
	return out
end

function ScreenButtons.version()
	start()
	return version
end

function ScreenButtons.onChange(fn)
	start()
	table.insert(listeners, fn)
end

function ScreenButtons.moved()
	dirty = true
end

function ScreenButtons.find(match)
	local playerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local function walk(inst)
		for _, d in ipairs(inst:GetChildren()) do
			if d:IsA("GuiObject") then
				if d.Visible then
					if d:IsA("TextButton") and d.AbsoluteSize.X > 0 and match(d) then
						return d
					end
					local found = walk(d)
					if found then
						return found
					end
				end
			elseif d:IsA("Folder") then
				local found = walk(d)
				if found then
					return found
				end
			end
		end
		return nil
	end
	for _, sg in ipairs(playerGui and playerGui:GetChildren() or {}) do
		if sg:IsA("ScreenGui") and sg.Enabled and sg.Name ~= "TouchGui" then
			local found = walk(sg)
			if found then
				return found
			end
		end
	end
	return nil
end

return ScreenButtons
