--[[
HoldButton: a button that acts only after it is held down for a moment (Config.UI.HoldSeconds), so a
stray tap on a phone doesn't spend money. While held, a light bar fills the button from the left;
letting go early cancels.

	HoldButton.connect(button, fn)   -- fn() once the hold is complete (instead of button.Activated)
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(script.Parent:WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local UserInputService = game:GetService("UserInputService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))

local HoldButton = {}

-- display only
local FILL_COLOR = Color3.new(1, 1, 1)
local FILL_TRANSPARENCY = 0.55

-- the same press: the same touch, or the mouse button (a touch's InputObject stays the same while it lasts)
local function same(input, holding)
	return input == holding or (input.UserInputType == Enum.UserInputType.MouseButton1
		and holding.UserInputType == Enum.UserInputType.MouseButton1)
end

local function pressing(input)
	return input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch
end

function HoldButton.connect(button, fn)
	local fill = Instance.new("Frame")
	fill.Name = "HoldFill"
	fill.BackgroundColor3 = FILL_COLOR
	fill.BackgroundTransparency = FILL_TRANSPARENCY
	fill.BorderSizePixel = 0
	fill.Size = UDim2.fromScale(0, 1)
	fill.Active = false
	fill.Parent = button
	local corner = button:FindFirstChildOfClass("UICorner")
	if corner then
		corner:Clone().Parent = fill
	end
	local holding, stepping = nil, nil
	local function stop()
		holding = nil
		fill.Size = UDim2.fromScale(0, 1)
		if stepping then
			stepping:Disconnect()
			stepping = nil
		end
	end
	button.InputBegan:Connect(function(input)
		if not pressing(input) or holding then
			return
		end
		holding = input
		local start = os.clock()
		stepping = RunService.RenderStepped:Connect(FrameMeter.wrap("HoldButton", function()
			local done = (os.clock() - start) / Config.UI.HoldSeconds
			fill.Size = UDim2.fromScale(math.clamp(done, 0, 1), 1)
			if done >= 1 then
				stop()
				fn()
			end
		end))
	end)
	-- only the finger (or mouse button) that started the hold ends it (2026-10-01: on phones any finger
	-- lifting anywhere, and the touch's own MouseLeave, cancelled every hold, so the key exchange and the
	-- shop's held buttons never went through)
	button.InputEnded:Connect(function(input)
		if holding and same(input, holding) then
			stop()
		end
	end)
	button.MouseLeave:Connect(function()
		if holding and holding.UserInputType == Enum.UserInputType.MouseButton1 then
			stop()
		end
	end)
	UserInputService.InputEnded:Connect(function(input) -- let go anywhere (a finger slid off)
		if holding and same(input, holding) then
			stop()
		end
	end)
end

return HoldButton
