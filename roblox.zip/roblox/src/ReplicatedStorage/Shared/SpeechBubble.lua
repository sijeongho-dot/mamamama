--[[
SpeechBubble: a short line in a white rounded bubble with a little tail under it, its edge in the
speaker's color, as wide as its words (display only; the zombies' bubble, StarterPlayerScripts/Zombies,
2026-10-01). Used by the wild dinos (StarterPlayerScripts/Wildlife, 2026-10-02).

	SpeechBubble.say(owner, part, above, words, options)
	  owner: a table that keeps the speaker's bubble (owner.bubble): one at a time, the old one goes
	  part: the BasePart it hangs on; above: studs over the part's middle where the tail's tip sits
	  options: { edge = Color3, textSize = n, distance = studs, seconds = n } (all optional)
]]

local TextService = game:GetService("TextService")
local TweenService = game:GetService("TweenService")

local SpeechBubble = {}

-- display only
local TEXT_SIZE = 15
local PAD = Vector2.new(14, 8) -- inside the bubble, round the words
local MAX_WIDTH = 220 -- longer lines wrap
local TAIL = 10 -- the tail's size (pixels)
local DISTANCE = 90
local SECONDS = 1.6
local FILL = Color3.fromRGB(255, 255, 255)
local INK = Color3.fromRGB(35, 35, 50)
local EDGE = Color3.fromRGB(120, 200, 110)
local POP = 0.18 -- seconds to pop up

function SpeechBubble.say(owner, part, above, words, options)
	if not part or not words then
		return nil
	end
	options = options or {}
	if owner.bubble then
		owner.bubble:Destroy()
	end
	local textSize = options.textSize or TEXT_SIZE
	local edge = options.edge or EDGE
	local bounds = TextService:GetTextSize(words, textSize, Enum.Font.GothamBold, Vector2.new(MAX_WIDTH, 1000))
	local w, h = bounds.X + PAD.X * 2, bounds.Y + PAD.Y * 2
	local bubble = Instance.new("BillboardGui")
	bubble.Size = UDim2.fromOffset(w + 4, h + TAIL + 4)
	bubble.SizeOffset = Vector2.new(0, 0.5) -- (its bottom, the tail's tip, sits on the spot)
	bubble.StudsOffsetWorldSpace = Vector3.new(0, above, 0)
	bubble.AlwaysOnTop = true
	bubble.MaxDistance = options.distance or DISTANCE
	bubble.Adornee = part
	local holder = Instance.new("Frame") -- (scaled for the pop, about the tail's tip)
	holder.BackgroundTransparency = 1
	holder.AnchorPoint = Vector2.new(0.5, 1)
	holder.Position = UDim2.fromScale(0.5, 1)
	holder.Size = UDim2.fromScale(1, 1)
	holder.Parent = bubble
	local scale = Instance.new("UIScale")
	scale.Scale = 0.4
	scale.Parent = holder
	local tail = Instance.new("Frame") -- a turned square under the box: its lower half shows
	tail.AnchorPoint = Vector2.new(0.5, 0.5)
	tail.Size = UDim2.fromOffset(TAIL * 1.4, TAIL * 1.4)
	tail.Position = UDim2.new(0.5, 0, 0, h + 2)
	tail.Rotation = 45
	tail.BackgroundColor3 = FILL
	tail.BorderSizePixel = 0
	tail.Parent = holder
	local tailEdge = Instance.new("UIStroke")
	tailEdge.Color = edge
	tailEdge.Thickness = 2
	tailEdge.Parent = tail
	local box = Instance.new("TextLabel")
	box.Position = UDim2.fromOffset(2, 2)
	box.Size = UDim2.fromOffset(w, h)
	box.BackgroundColor3 = FILL
	box.Font = Enum.Font.GothamBold
	box.TextSize = textSize
	box.TextWrapped = true
	box.TextColor3 = INK
	box.Text = words
	box.ZIndex = 2 -- (over the tail's top half)
	box.Parent = holder
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 12)
	round.Parent = box
	local boxEdge = Instance.new("UIStroke")
	boxEdge.Color = edge
	boxEdge.Thickness = 2
	boxEdge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	boxEdge.Parent = box
	bubble.Parent = part
	TweenService:Create(scale, TweenInfo.new(POP, Enum.EasingStyle.Back), { Scale = 1 }):Play()
	owner.bubble = bubble
	task.delay(options.seconds or SECONDS, function()
		if owner.bubble == bubble then
			owner.bubble = nil
		end
		bubble:Destroy()
	end)
	return bubble
end

return SpeechBubble
