local MarketplaceService = game:GetService("MarketplaceService")

local RETRY_SECONDS = 60
local REFRESH_DELAY = 0.3

local Prices = {}

local cache = {}
local listeners = {}
local pending = false

local function changed()
	if pending then
		return
	end
	pending = true
	task.delay(REFRESH_DELAY, function()
		pending = false
		for _, fn in ipairs(listeners) do
			task.spawn(fn)
		end
	end)
end

function Prices.onChanged(fn)
	table.insert(listeners, fn)
end

function Prices.get(id, isPass, fallback)
	if type(id) ~= "number" or id <= 0 then
		return fallback
	end
	local key = (isPass and "Pass" or "Product") .. id
	local entry = cache[key]
	if not entry or (not entry.busy and not entry.value and os.clock() - entry.at > RETRY_SECONDS) then
		entry = { busy = true, at = os.clock(), value = entry and entry.value }
		cache[key] = entry
		task.spawn(function()
			local ok, info = pcall(MarketplaceService.GetProductInfo, MarketplaceService, id,
				isPass and Enum.InfoType.GamePass or Enum.InfoType.Product)
			local value = ok and type(info) == "table" and tonumber(info.PriceInRobux) or nil
			entry.busy, entry.at = false, os.clock()
			if value and value > 0 and value ~= entry.value then
				entry.value = value
				changed()
			end
		end)
	end
	return entry.value or fallback
end

return Prices
