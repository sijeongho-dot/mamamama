--[[
Lod: how often a far animated model is moved (display only, clients; 2026-10-01, "8 players: optimize").
Every client moved every drawn dino (platform and farm dinos, zombies, wild dinos, NPCs) every frame; on a
phone with eight bases that is a lot of PivotTo and bone work. Near the camera a model still moves every
frame; farther away every 2nd, then every 3rd (very far every 4th) frame, with the time that passed added up so it moves just
as far.

	local due, dt = Lod.due(state, distance, frameDt) -- state: any table kept per model
	if due then model:PivotTo(... DinoMotion.step(rig, dt, speed)) end
]]

local Lod = {}

-- display only
local NEAR = 110 -- studs: every frame
local MID = 220 -- studs: every 2nd frame; farther: every 3rd
local FAR = 340

function Lod.every(distance)
	return distance <= NEAR and 1 or distance <= MID and 2 or distance <= FAR and 3 or 4
end

function Lod.due(state, distance, dt)
	local every = Lod.every(distance)
	state.lodDt = (state.lodDt or 0) + dt
	state.lodN = (state.lodN or math.random(0, 3)) + 1 -- (a random start spreads the far ones over frames)
	if state.lodN % every ~= 0 then
		return false, 0
	end
	local total = state.lodDt
	state.lodDt = 0
	return true, total
end

return Lod
