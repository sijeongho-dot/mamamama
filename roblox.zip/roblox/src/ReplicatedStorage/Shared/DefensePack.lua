local DefensePack = {}

local TAG = { H = 1, M = 2, D = 3, A = 4 }
local COMBOS = { "Shock", "Freeze" }
local COMBO_CODE = { Shock = 1, Freeze = 2 }
local MAX_ID = 4294967295
local MAX_COUNT = 65535
local MAX_NAME = 255
local HP_STEPS = 255

local function whole(v)
	return type(v) == "number" and v >= 0 and v <= MAX_ID and v % 1 == 0
end

local function ids(list)
	if type(list) ~= "table" or #list > MAX_COUNT then
		return false
	end
	for _, v in ipairs(list) do
		if not whole(v) then
			return false
		end
	end
	return true
end

local function size(e)
	local kind = e[1]
	if kind == "H" then
		local pairsCount = (#e - 1) / 2
		if pairsCount % 1 ~= 0 or pairsCount > MAX_COUNT then
			return nil
		end
		for i = 2, #e - 1, 2 do
			local hp = e[i + 1]
			if not whole(e[i]) or type(hp) ~= "number" or hp ~= hp then
				return nil
			end
		end
		return 3 + pairsCount * 5
	elseif kind == "M" then
		return #e == 4 and whole(e[2]) and type(e[3]) == "number" and type(e[4]) == "number" and 13 or nil
	elseif kind == "D" then
		return #e == 2 and whole(e[2]) and 5 or nil
	elseif kind == "A" then
		local id = e[2]
		if type(id) ~= "string" or #id > MAX_NAME or not ids(e[3]) or not ids(e[4])
			or (e[5] ~= nil and not COMBO_CODE[e[5]]) then
			return nil
		end
		return 2 + #id + 2 + #e[3] * 4 + 2 + #e[4] * 4 + 1
	end
	return nil
end

local function writeIds(b, at, list)
	buffer.writeu16(b, at, #list)
	at += 2
	for _, v in ipairs(list) do
		buffer.writeu32(b, at, v)
		at += 4
	end
	return at
end

local function write(b, at, e)
	local kind = e[1]
	buffer.writeu8(b, at, TAG[kind])
	at += 1
	if kind == "H" then
		buffer.writeu16(b, at, (#e - 1) / 2)
		at += 2
		for i = 2, #e - 1, 2 do
			buffer.writeu32(b, at, e[i])
			buffer.writeu8(b, at + 4, math.clamp(math.ceil(e[i + 1] * HP_STEPS), 0, HP_STEPS))
			at += 5
		end
	elseif kind == "M" then
		buffer.writeu32(b, at, e[2])
		buffer.writef32(b, at + 4, e[3])
		buffer.writef32(b, at + 8, e[4])
		at += 12
	elseif kind == "D" then
		buffer.writeu32(b, at, e[2])
		at += 4
	else
		buffer.writeu8(b, at, #e[2])
		buffer.writestring(b, at + 1, e[2])
		at = writeIds(b, at + 1 + #e[2], e[3])
		at = writeIds(b, at, e[4])
		buffer.writeu8(b, at, COMBO_CODE[e[5]] or 0)
		at += 1
	end
	return at
end

function DefensePack.pack(events)
	local out, run, runSize = {}, {}, 0
	local function flush()
		if #run == 0 then
			return
		end
		local b = buffer.create(runSize)
		local at = 0
		for _, e in ipairs(run) do
			at = write(b, at, e)
		end
		table.insert(out, b)
		run, runSize = {}, 0
	end
	for _, e in ipairs(events) do
		local n = size(e)
		if n then
			table.insert(run, e)
			runSize += n
		else
			flush()
			table.insert(out, e)
		end
	end
	flush()
	return out
end

local function readIds(b, at)
	local count = buffer.readu16(b, at)
	at += 2
	local list = table.create(count)
	for i = 1, count do
		list[i] = buffer.readu32(b, at)
		at += 4
	end
	return list, at
end

local function read(b, out)
	local at, n = 0, buffer.len(b)
	while at < n do
		local tag = buffer.readu8(b, at)
		at += 1
		if tag == TAG.H then
			local count = buffer.readu16(b, at)
			at += 2
			local e = table.create(1 + count * 2)
			e[1] = "H"
			for i = 1, count do
				e[i * 2] = buffer.readu32(b, at)
				e[i * 2 + 1] = buffer.readu8(b, at + 4) / HP_STEPS
				at += 5
			end
			table.insert(out, e)
		elseif tag == TAG.M then
			table.insert(out, { "M", buffer.readu32(b, at), buffer.readf32(b, at + 4), buffer.readf32(b, at + 8) })
			at += 12
		elseif tag == TAG.D then
			table.insert(out, { "D", buffer.readu32(b, at) })
			at += 4
		elseif tag == TAG.A then
			local len = buffer.readu8(b, at)
			local id = buffer.readstring(b, at + 1, len)
			local hits, chain
			hits, at = readIds(b, at + 1 + len)
			chain, at = readIds(b, at)
			local combo = COMBOS[buffer.readu8(b, at)]
			at += 1
			table.insert(out, { "A", id, hits, chain, combo })
		else
			return
		end
	end
end

function DefensePack.unpack(events)
	local out = {}
	for _, e in ipairs(events) do
		if type(e) == "buffer" then
			read(e, out)
		else
			table.insert(out, e)
		end
	end
	return out
end

return DefensePack
