local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Lang = require(script.Parent:WaitForChild("Lang"))
local Net = require(script.Parent:WaitForChild("Net"))

local PILL_SIZE = UDim2.fromOffset(230, 46)
local PILL_POSITION = UDim2.fromScale(0.5, 0.72)
local PILL_COLOR = Color3.fromRGB(255, 105, 160)
local PILL_STROKE = Color3.fromRGB(255, 235, 245)
local PILL_TEXT = Color3.new(1, 1, 1)
local PILL_DISPLAY_ORDER = 40
local PILL_PULSE = 1.06
local PILL_PULSE_SPEED = 5

local ShareMoment = {}

local busy = false
local pill = nil
local pillToken = nil

local function service()
	local ok, capture = pcall(game.GetService, game, "CaptureService")
	return ok and capture or nil
end

function ShareMoment.allowed()
	local player = Players.LocalPlayer
	return player ~= nil and player:GetAttribute("CanShare") == true and service() ~= nil
end

local function show(list, on)
	for _, gui in ipairs(list) do
		if gui.Parent then
			gui.Visible = on
		end
	end
end

function ShareMoment.share(kind, hide)
	local capture = service()
	if busy or not capture or not ShareMoment.allowed() then
		return
	end
	busy = true
	hide = hide or {}
	show(hide, false)
	RunService.RenderStepped:Wait()
	local data = Config.Notify.SharePrefix .. Players.LocalPlayer.UserId
	local function done()
		show(hide, true)
		busy = false
	end
	local function prompt(content)
		pcall(capture.PromptShareCapture, capture, content, data, function()
			Net.request("ShareDone", kind)
		end, function() end)
		done()
	end
	local ok = pcall(function()
		capture:TakeScreenshotCaptureAsync(function(result, shot)
			if result == Enum.ScreenshotCaptureResult.Success and shot then
				prompt(Content.fromObject(shot))
			else
				done()
			end
		end, { UICaptureMode = Enum.UICaptureMode.All })
	end)
	if not ok then
		ok = pcall(capture.CaptureScreenshot, capture, prompt)
	end
	if not ok then
		done()
	end
end

local function makePill()
	local gui = Instance.new("ScreenGui")
	gui.Name = "ShareMoment"
	gui.ResetOnSpawn = false
	gui.DisplayOrder = PILL_DISPLAY_ORDER
	gui.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")
	local b = Instance.new("TextButton")
	b.Name = "SharePill"
	b.AnchorPoint = Vector2.new(0.5, 0.5)
	b.Position = PILL_POSITION
	b.Size = PILL_SIZE
	b.BackgroundColor3 = PILL_COLOR
	b.TextColor3 = PILL_TEXT
	b.Font = Enum.Font.GothamBlack
	b.TextScaled = true
	b.Visible = false
	b.Parent = gui
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0.5, 0)
	corner.Parent = b
	local stroke = Instance.new("UIStroke")
	stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	stroke.Color = PILL_STROKE
	stroke.Thickness = 2
	stroke.Parent = b
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, 12), UDim.new(0, 12)
	pad.PaddingTop, pad.PaddingBottom = UDim.new(0, 6), UDim.new(0, 6)
	pad.Parent = b
	local scale = Instance.new("UIScale")
	scale.Parent = b
	RunService.Heartbeat:Connect(function()
		if b.Visible then
			scale.Scale = 1 + (PILL_PULSE - 1) * (0.5 + 0.5 * math.sin(os.clock() * PILL_PULSE_SPEED))
		end
	end)
	b.Activated:Connect(function()
		pillToken = nil
		b.Visible = false
		ShareMoment.share(b:GetAttribute("Kind"), {})
	end)
	return b
end

function ShareMoment.offer(kind, text)
	if not ShareMoment.allowed() then
		return
	end
	pill = pill or makePill()
	pill:SetAttribute("Kind", kind)
	Lang.set(pill, text)
	pill.Visible = true
	local token = {}
	pillToken = token
	task.delay(Config.Share.PillSeconds, function()
		if pillToken == token then
			pill.Visible = false
		end
	end)
end

return ShareMoment
