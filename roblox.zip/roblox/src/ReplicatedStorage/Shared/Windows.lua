--[[
Windows: closing any open window with the keyboard or a gamepad (display only, clients).

Every client script registers its windows here. Esc, Backspace or the gamepad's B button closes the
window opened last that is still open (then the one before, and so on). Each window also keeps its
own X / 취소 / ← button; a window without an X gets a small one in its top-right corner.

	Windows.register(frame)                     -- closing hides it
	Windows.register(frame, function() ... end) -- or closes it this way (e.g. stop placing)
	Windows.register(frame, nil, { Keep = true }) -- no X and no closing by key: only its own buttons close it
	                                            -- (the tutorial's card: 2026-10-03, "X버튼 잘못누르면 골때리니까")
	Windows.fit(frame)
	local x, y, w, h = Windows.freeArea(gui)    -- that free part (e.g. for banners)

Every registered window can be dragged by its top strip (DRAG_STRIP pixels: the title's row, not its
buttons) with a finger or the mouse, and stays inside the screen (2026-10-02, "모든 창들이 드래그로 옮겨지게
해줘 화면내"). A fitted window keeps where it was dragged when the screen turns or it is opened again.
]]

local GuiService = game:GetService("GuiService")
local UserInputService = game:GetService("UserInputService")

local Windows = {}

local CLOSE_KEYS = { [Enum.KeyCode.Escape] = true, [Enum.KeyCode.Backspace] = true, [Enum.KeyCode.ButtonB] = true }

local open = {} -- windows in the order they were opened: { frame, close }
local CLOSE_SIZE, CLOSE_MARGIN = 28, 6 -- display only: every window's small X in its top-right corner
local CLOSE_COLOR = Color3.fromRGB(235, 70, 80)
local WINDOW_ORDER = 5 -- a ScreenGui holding a window draws over the HUD's info lines (bag bar, compass,
-- weather line: DisplayOrder 0-4)
local listening = false
local DRAG_STRIP = 44 -- pixels at the top of a window that drag it (its title row)
local DRAG_START = 6 -- pixels a finger moves before it counts as a drag (a tap stays a tap)

local fitted = {} -- [frame] = its fit function (Windows.fit): a dragged one moves by its offset
local dragOffset = setmetatable({}, { __mode = "k" }) -- [frame] = Vector2 moved from where fit puts it

local function remove(frame)
	for i = #open, 1, -1 do
		if open[i].frame == frame then
			table.remove(open, i)
		end
	end
end

local function typing()
	return UserInputService:GetFocusedTextBox() ~= nil
end

-- the screen's size for a window (its ScreenGui's, else the camera's)
local function screenSize(frame)
	local gui = frame:FindFirstAncestorWhichIsA("ScreenGui")
	local size = gui and gui.AbsoluteSize
	if not size or size.X < 1 then
		local camera = workspace.CurrentCamera
		size = camera and camera.ViewportSize or Vector2.new(1920, 1080)
	end
	return size
end

-- the move that keeps the window inside the screen: delta cut so its whole box stays on it
local function clampMove(frame, startAbs, delta)
	local size, screen = frame.AbsoluteSize, screenSize(frame)
	local x = math.clamp(startAbs.X + delta.X, 0, math.max(0, screen.X - size.X))
	local y = math.clamp(startAbs.Y + delta.Y, 0, math.max(0, screen.Y - size.Y))
	return Vector2.new(x - startAbs.X, y - startAbs.Y)
end

-- the open window whose top strip is under this point, the last opened first; nil over one of its buttons
local function windowAt(point)
	local playerGui = game:GetService("Players").LocalPlayer:FindFirstChildOfClass("PlayerGui")
	for i = #open, 1, -1 do
		local frame = open[i].frame
		local at, size = frame.AbsolutePosition, frame.AbsoluteSize
		local shrink = frame.Size.Y.Offset > 0 and size.Y / frame.Size.Y.Offset or 1 -- (a fitted window's UIScale)
		if frame.Parent and frame.Visible and point.X >= at.X and point.X <= at.X + size.X and point.Y >= at.Y
			and point.Y <= at.Y + math.min(size.Y, DRAG_STRIP * shrink) then
			for _, hit in ipairs(playerGui and playerGui:GetGuiObjectsAtPosition(point.X, point.Y) or {}) do
				if (hit:IsA("GuiButton") or hit:IsA("TextBox")) and hit:IsDescendantOf(frame) then
					return nil -- (its X, a tab: a press, not a drag)
				end
			end
			return frame
		elseif frame.Parent and frame.Visible and point.X >= at.X and point.X <= at.X + size.X and point.Y >= at.Y
			and point.Y <= at.Y + size.Y then
			return nil -- (on a window above, not its strip: nothing under it moves)
		end
	end
	return nil
end

local dragging = nil -- { frame, input, start (point), startAbs, startPos, startOffset, moved }

local function drag(input)
	local d = dragging
	local delta = Vector2.new(input.Position.X, input.Position.Y) - d.start
	if not d.moved and delta.Magnitude < DRAG_START then
		return
	end
	d.moved = true
	delta = clampMove(d.frame, d.startAbs, delta)
	if fitted[d.frame] then
		dragOffset[d.frame] = d.startOffset + delta
		fitted[d.frame]()
	else
		d.frame.Position = d.startPos + UDim2.fromOffset(delta.X, delta.Y)
	end
end

local function listenDrag()
	UserInputService.InputBegan:Connect(function(input)
		if dragging or (input.UserInputType ~= Enum.UserInputType.MouseButton1
			and input.UserInputType ~= Enum.UserInputType.Touch) then
			return
		end
		local point = Vector2.new(input.Position.X, input.Position.Y)
		local frame = windowAt(point)
		if frame then
			dragging = { frame = frame, input = input, start = point, startAbs = frame.AbsolutePosition,
				startPos = frame.Position, startOffset = dragOffset[frame] or Vector2.zero, moved = false }
		end
	end)
	UserInputService.InputChanged:Connect(function(input)
		if not dragging then
			return
		end
		if input == dragging.input or (dragging.input.UserInputType == Enum.UserInputType.MouseButton1
			and input.UserInputType == Enum.UserInputType.MouseMovement) then
			drag(input)
		end
	end)
	UserInputService.InputEnded:Connect(function(input)
		if dragging and (input == dragging.input or input.UserInputType == dragging.input.UserInputType) then
			dragging = nil
		end
	end)
end

local function listen()
	if listening then
		return
	end
	listening = true
	listenDrag()
	UserInputService.InputBegan:Connect(function(input)
		if not CLOSE_KEYS[input.KeyCode] or typing() then
			return
		end
		for i = #open, 1, -1 do
			local w = open[i]
			if w.frame.Parent and w.frame.Visible then
				if not w.keep then
					w.close()
					return
				end
			else
				table.remove(open, i)
			end
		end
	end)
end

-- a small X in the window's top-right corner, unless it already has one
local function addCloseButton(frame, close)
	if not frame:IsA("Frame") and not frame:IsA("ScrollingFrame") then
		return
	end
	for _, child in ipairs(frame:GetChildren()) do
		if child:IsA("TextButton") and (child.Text == "X" or child.Name == "CloseX") then
			return
		end
	end
	local x = Instance.new("TextButton")
	x.Name = "CloseX"
	x.AnchorPoint = Vector2.new(1, 0)
	x.Position = UDim2.new(1, -CLOSE_MARGIN, 0, CLOSE_MARGIN)
	x.Size = UDim2.fromOffset(CLOSE_SIZE, CLOSE_SIZE)
	x.BackgroundColor3 = CLOSE_COLOR
	x.Font = Enum.Font.GothamBold
	x.TextSize = 16
	x.TextColor3 = Color3.new(1, 1, 1)
	x.Text = "X"
	x.ZIndex = frame.ZIndex + 5
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 8)
	round.Parent = x
	x.Parent = frame
	x.Activated:Connect(close)
end

function Windows.register(frame, close, options)
	listen()
	local keep = options ~= nil and options.Keep == true
	local gui = frame:FindFirstAncestorWhichIsA("ScreenGui")
	if gui and gui.DisplayOrder < WINDOW_ORDER then
		gui.DisplayOrder = WINDOW_ORDER
	end
	local entry = { frame = frame, keep = keep, close = close or function()
		frame.Visible = false
	end }
	if frame:IsA("GuiObject") then
		frame.Active = true -- (a press on it is the window's, not the world's: dragging it never turns the camera)
	end
	if not keep then
		addCloseButton(frame, entry.close)
	end
	frame:GetPropertyChangedSignal("Visible"):Connect(function()
		remove(frame)
		if frame.Visible then
			entry.at = os.clock()
			table.insert(open, entry)
		end
	end)
	if frame.Visible then
		entry.at = os.clock()
		table.insert(open, entry)
	end
end

function Windows.closeAll()
	local list = table.clone(open)
	for i = #list, 1, -1 do
		local w = list[i]
		if not w.keep and w.frame.Parent and w.frame.Visible then
			pcall(w.close)
		end
	end
end

-- is any registered window open now (but except)? (the tutorial's skip button steps aside meanwhile)
-- (2026-10-03) a frame with the attribute LeavesButtons (Coco's tutorial card) doesn't count: the buttons it points
-- at stay (the bombs while it says to throw one)
local function shown(frame)
	local node = frame
	while node do
		if node:IsA("GuiObject") and not node.Visible then
			return false
		elseif node:IsA("LayerCollector") then
			return node.Enabled
		end
		node = node.Parent
	end
	return false
end

function Windows.anyOpen(except)
	for _, entry in ipairs(open) do
		if entry.frame ~= except and not entry.frame:GetAttribute("LeavesButtons") and shown(entry.frame) then
			return true
		end
	end
	return false
end

-- display only: the free part of the screen (Windows.freeArea), from its ScreenGui's edges: the
-- right edge's button columns (기지로, 타기, 인벤토리, ...) and the slap button next to the phone's jump
-- button stay uncovered
local FIT_LEFT, FIT_RIGHT, FIT_TOP, FIT_BOTTOM = 12, 204, 8, 52 -- (bottom: the bag bar stays in sight)
local FIT_MIN_SCALE = 0.4
local FIT_MARGIN = 8
local FIT_EPSILON = 0.005
local OPEN_ORDER = 10
local OPEN_ORDER_STEPS = 9
local COVER_FILL_MIN_SCALE = 0.8
local COVER_SHADE = 0.5
local COVER_SHADE_COLOR = Color3.fromRGB(10, 10, 20)
local COVER_EXTRA = 120
local COVER_BLUR = 16

local covers = {}
local shades = {}
local blur = nil
local raised = {}
local coverSeq = 0
local coverSeenAt = -math.huge
local coverOpen = false

local function shownNow(frame)
	local a = frame
	while a and not a:IsA("ScreenGui") do
		if not a:IsA("GuiObject") or not a.Visible then
			return false
		end
		a = a.Parent
	end
	return a ~= nil and a.Enabled
end

local function refreshCover()
	local wanted = {}
	local lifted = {}
	local any = false
	for frame in pairs(covers) do
		if frame.Parent and shownNow(frame) then
			local gui = frame:FindFirstAncestorWhichIsA("ScreenGui")
			lifted[gui] = true
			if frame:GetAttribute("Cover") then
				wanted[gui] = math.min(wanted[gui] or math.huge, frame.ZIndex)
				any = true
			end
		end
	end
	for gui, shade in pairs(shades) do
		if not wanted[gui] then
			shade.Visible = false
		end
	end
	for gui, before in pairs(raised) do
		if not lifted[gui] then
			gui.DisplayOrder = before
			raised[gui] = nil
		end
	end
	if any or coverOpen then
		coverSeenAt = os.clock()
	end
	coverOpen = any
	if next(raised) == nil then
		coverSeq = 0
	end
	for gui in pairs(lifted) do
		if raised[gui] == nil then
			raised[gui] = gui.DisplayOrder
			coverSeq += 1
			gui.DisplayOrder = OPEN_ORDER + math.min(coverSeq, OPEN_ORDER_STEPS)
		end
	end
	for gui, z in pairs(wanted) do
		local shade = shades[gui]
		if not shade or not shade.Parent then
			shade = Instance.new("Frame")
			shade.Name = "CoverShade"
			shade.BackgroundColor3 = COVER_SHADE_COLOR
			shade.BackgroundTransparency = COVER_SHADE
			shade.BorderSizePixel = 0
			shade.Position = UDim2.fromOffset(-COVER_EXTRA, -COVER_EXTRA)
			shade.Size = UDim2.new(1, COVER_EXTRA * 2, 1, COVER_EXTRA * 2)
			shade.Active = true
			shade.Parent = gui
			shades[gui] = shade
		end
		shade.ZIndex = z - 1
		shade.Visible = true
	end
	local camera = workspace.CurrentCamera
	local me = game:GetService("Players").LocalPlayer
	local light = me:GetAttribute("LightMode") or me:GetAttribute("LowDetail")
	if any and not light and camera then
		if not blur or not blur.Parent then
			blur = Instance.new("BlurEffect")
			blur.Name = "WindowCoverBlur"
			blur.Size = COVER_BLUR
		end
		blur.Parent = camera
		blur.Enabled = true
	elseif blur then
		blur.Enabled = false
	end
end

local function watchCover(frame)
	if covers[frame] then
		return
	end
	covers[frame] = true
	frame:GetPropertyChangedSignal("Visible"):Connect(refreshCover)
	frame.AncestryChanged:Connect(refreshCover)
	local a = frame.Parent
	while a and a:IsA("GuiObject") do
		a:GetPropertyChangedSignal("Visible"):Connect(refreshCover)
		a = a.Parent
	end
end

local function screenArea(gui)
	local area = gui and gui.AbsoluteSize
	if not area or area.X < 1 then
		local camera = workspace.CurrentCamera
		area = camera and camera.ViewportSize or Vector2.new(1920, 1080)
	end
	local top = gui and gui.IgnoreGuiInset and GuiService:GetGuiInset().Y or 0
	return area, top
end

local function fillFit(frame, scale, gui, base)
	local area, top = screenArea(gui)
	local w, h = area.X - FIT_MARGIN * 2, area.Y - top - FIT_MARGIN * 2
	local s = math.max(COVER_FILL_MIN_SCALE, h / math.max(base.Y, 1))
	frame.AnchorPoint = Vector2.new(0.5, 0.5)
	scale.Scale = s
	frame.Size = UDim2.fromOffset(math.floor(w / s), math.floor(h / s))
	frame.Position = UDim2.fromOffset(area.X / 2, top + (area.Y - top) / 2)
end

local function fullFit(frame, scale, gui, base, share)
	local area, top = screenArea(gui)
	local w, h = area.X - FIT_MARGIN * 2, area.Y - top - FIT_MARGIN * 2
	local s = math.min(w / math.max(base.X, 1), h / math.max(base.Y, 1))
	if share then
		s = math.min(s, math.max(share * h / math.max(base.Y, 1), 1))
	end
	s = math.max(FIT_MIN_SCALE, s)
	if math.abs(scale.Scale - s) > FIT_EPSILON then
		scale.Scale = s
	end
	s = scale.Scale
	frame.AnchorPoint = Vector2.new(0.5, 0.5)
	local cx, cy = area.X / 2, top + (area.Y - top) / 2
	local offset = dragOffset[frame] or Vector2.zero
	if offset ~= Vector2.zero then
		local half = base * s / 2
		local x = math.clamp(cx + offset.X, half.X, math.max(half.X, area.X - half.X))
		local y = math.clamp(cy + offset.Y, top + half.Y, math.max(top + half.Y, area.Y - half.Y))
		offset = Vector2.new(x - cx, y - cy)
		dragOffset[frame] = offset
	end
	frame.Position = UDim2.fromOffset(cx + offset.X, cy + offset.Y)
end

-- the free part of a ScreenGui (x, y, w, h in its own pixels): clear of the right edge's buttons
function Windows.freeArea(gui)
	local area = gui and gui.AbsoluteSize
	if not area or area.X < 1 then
		local camera = workspace.CurrentCamera
		area = camera and camera.ViewportSize or Vector2.new(1920, 1080)
	end
	local w = math.max(1, area.X - FIT_LEFT - FIT_RIGHT)
	local h = math.max(1, area.Y - FIT_TOP - FIT_BOTTOM)
	return FIT_LEFT, FIT_TOP, w, h
end

function Windows.fit(frame, options)
	local scale = Instance.new("UIScale")
	scale.Parent = frame
	local camera = workspace.CurrentCamera
	local watched = nil
	local base = Vector2.new(frame.Size.X.Offset, frame.Size.Y.Offset)
	local resizing = false
	if options and options.Cover then
		frame:SetAttribute("Cover", options.Cover)
	end
	local function natural()
		if frame.AutomaticSize == Enum.AutomaticSize.None or scale.Scale <= 0 then
			return base
		end
		local real = frame.AbsoluteSize / scale.Scale
		return Vector2.new(math.max(base.X, real.X), math.max(base.Y, real.Y))
	end
	local function fit()
		if resizing then
			return
		end
		local gui = frame:FindFirstAncestorWhichIsA("ScreenGui")
		watchCover(frame)
		resizing = true
		if frame:GetAttribute("Cover") == "Fill" then
			fillFit(frame, scale, gui, base)
		else
			if frame.Size ~= UDim2.fromOffset(base.X, base.Y) then
				frame.Size = UDim2.fromOffset(base.X, base.Y)
			end
			fullFit(frame, scale, gui, natural(), options and options.Share)
		end
		resizing = false
		if gui and gui ~= watched then
			watched = gui
			gui:GetPropertyChangedSignal("AbsoluteSize"):Connect(fit)
		end
	end
	fit()
	fitted[frame] = fit
	if camera then
		camera:GetPropertyChangedSignal("ViewportSize"):Connect(fit)
	end
	frame:GetPropertyChangedSignal("Size"):Connect(function()
		if not resizing and frame:GetAttribute("Cover") ~= "Fill" then
			base = Vector2.new(frame.Size.X.Offset, frame.Size.Y.Offset)
		end
		fit()
	end)
	frame.AncestryChanged:Connect(fit)
	if frame.AutomaticSize ~= Enum.AutomaticSize.None then
		frame:GetPropertyChangedSignal("AbsoluteSize"):Connect(fit)
	end
	frame:GetAttributeChangedSignal("Cover"):Connect(function()
		fit()
		refreshCover()
	end)
	refreshCover()
	return scale
end

Windows.ABOVE_WINDOWS = OPEN_ORDER + OPEN_ORDER_STEPS + 1

function Windows.covered(obj, x, y)
	local own = 0
	for i, entry in ipairs(open) do
		if entry.frame == obj or entry.frame:IsAncestorOf(obj) then
			own = i
		end
	end
	for i = own + 1, #open do
		local f = open[i].frame
		if f.Parent and not f:GetAttribute("LeavesButtons") and shown(f) then
			if f:GetAttribute("Cover") then
				return true
			end
			local a, b = f.AbsolutePosition, f.AbsoluteSize
			if x >= a.X and x <= a.X + b.X and y >= a.Y and y <= a.Y + b.Y then
				return true
			end
		end
	end
	return false
end

local function closeOf(frame)
	for _, child in ipairs(frame:GetChildren()) do
		if child:IsA("TextButton") and (child.Text == "X" or child.Name == "CloseX") then
			return child
		end
	end
	for _, d in ipairs(frame:GetDescendants()) do
		if d:IsA("TextButton") and d.Text == "X" then
			return d
		end
	end
	return nil
end

function Windows.top()
	for i = #open, 1, -1 do
		local w = open[i]
		if w.frame.Parent and not w.frame:GetAttribute("LeavesButtons") and shown(w.frame) then
			if w.keep or w.frame:GetAttribute("NoCloseHint") then
				return nil
			end
			if not w.x or not w.x.Parent then
				w.x = closeOf(w.frame)
			end
			return w.frame, w.x, w.at or 0
		end
	end
	return nil
end

function Windows.coverBusy(seconds)
	return coverOpen or os.clock() - coverSeenAt < (seconds or 0)
end

function Windows.cover(frame, mode)
	if frame:GetAttribute("Cover") ~= mode then
		frame:SetAttribute("Cover", mode)
	end
end

return Windows
