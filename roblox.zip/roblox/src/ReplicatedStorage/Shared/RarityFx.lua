--[[
RarityFx: how a dino's rarity shows on its model (design 4.4 레어도 12단계, display only).

	RarityFx.apply(model, rarityId, footprint)   -- once, on a dino model standing at its pivot

Every rarity above common wears twinkles inside the body (more
and brighter at every rarity up, rising and swaying together), and its own particles, a different kind for every rarity so
they tell apart at a glance (a little fainter and brighter since 2026-10-01; no ring on the ground: it looked
cheap; Highlights are not used, they stop drawing past 31 on a screen):
	고급 green leaves drifting up · 희귀 blue bubbles rising · 영웅 purple mist swirling round
	전설 orange glow + sparks shooting up · 신화 red flames + embers · 초월 pink petals falling
	무지개 rainbow motes spiraling up and a color-cycling halo (clients cycle parts with the Rainbow attribute)
	황금 a gold light pillar + glitter · 오닉스 dark smoke + purple crackles · 천상 a halo + stars + glow
	시크릿 rainbow, flames, crackles, halo and stars, bigger · 우주 nebula clouds, stars and orbiting sparks
	태초 amber flames, embers, glitter and a light pillar · 신 golden rays, rainbow sparkles, stars, a glow,
	a rainbow halo and a light pillar
The particles grow with the dino. Effects are parented under the
model's "RarityFx" folder so hiding a dino, or the view setting "오라" (HideAuras), turns them off.
]]

local RunService = game:GetService("RunService")
local FrameMeter = require(script.Parent:WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)

local RarityFx = {}

-- display only
local SIZE_REFERENCE = 6 -- studs: a dino this long gets the particle sizes below as they are
local SIZE_SCALE_MIN, SIZE_SCALE_MAX = 0.6, 4
local SPARKLE = "rbxasset://textures/particles/sparkles_main.dds"
-- the twinkles inside the body: more, bigger and brighter at every rarity up
local TIER_ORDER = { "Uncommon", "Rare", "Epic", "Legendary", "Mythic", "Transcendent", "Rainbow", "Golden", "Onyx",
	"Celestial", "Secret", "Cosmic", "Primeval", "Divine" }
local TIERS = {}
for i, id in ipairs(TIER_ORDER) do
	TIERS[id] = i
end
local INNER_RATE_PER_TIER = 2.5 -- a second, × the tier (고급 2.5 … 신 35; fewer than before as each is bigger and lives longer)
local INNER_SIZE = { 1, 2.7 } -- studs at their brightest, 고급 … 신, for a SIZE_REFERENCE-long dino (0.35 … 1.1 →
-- 0.8 … 2.2: "bigger and more beautiful" → 1 … 2.7: "a little bigger")
local INNER_BRIGHTNESS_PER_TIER = 0.35 -- (신: 5.9 times as bright as plain)
local INNER_LIFETIME = { 1.1, 2 } -- seconds: long enough to twinkle twice on the way up (was 0.7 … 1.4)
-- (2026-10-01, "the sparkles shimmer as they rise") they float up through the body, slowing, and the whole
-- swarm sways side to side together (every emitter's sideways pull swung by one slow loop below)
local INNER_RISE_SPEED = { 0.8, 1.6 } -- studs a second up at the start, for a SIZE_REFERENCE-long dino
local INNER_RISE_SPREAD = 25 -- degrees off straight up
local INNER_DRAG = 1.2 -- slows them, so they drift rather than shoot
local INNER_LIFT = 0.6 -- studs a second² keeping them rising as they slow
local INNER_SWAY = 2.2 -- studs a second²: the sideways pull at its strongest
local INNER_SWAY_PERIOD = { 1.7, 2.6 } -- seconds a sway takes (two, for a wandering path)
local INNER_SWAY_EVERY = 0.1 -- seconds between updates of the pull
local SMOKE = "rbxasset://textures/particles/smoke_main.dds"
local FLAME = "rbxasset://textures/particles/fire_main.dds"
local RAINBOW = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 70, 70)), ColorSequenceKeypoint.new(0.2, Color3.fromRGB(255, 170, 60)),
	ColorSequenceKeypoint.new(0.4, Color3.fromRGB(255, 240, 80)), ColorSequenceKeypoint.new(0.6, Color3.fromRGB(90, 220, 110)),
	ColorSequenceKeypoint.new(0.8, Color3.fromRGB(70, 160, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(170, 90, 230)),
})
local HALO_THICKNESS = 0.25
local HALO_ABOVE = 0.6 -- studs over the top of the dino
local HALO_SEGMENTS = 16
local HALO_BAND = 0.22
local HALO_BAND_MIN = 0.15
local HALO_OVERLAP = 1.22
local PILLAR_TRANSPARENCY = 0.75
local PARTICLE_FAINTER = 0.15 -- every aura particle this much more see-through at its start
local PARTICLE_BRIGHTER = 0.3 -- and glowing this much more (LightEmission, at most 1)
local SOFT_RATE = 0.25
local SOFT_LIGHT = 0.4
local SOFT_BRIGHTNESS = 1.2
local SOFT_PILLAR = 0.88
local LITE_RATE = 0.5
local BURN_FROM = 4
local BURN_RATE = 10
local BURN_WHITE = 0.45
local BURN_SOFT_RATE = 0.6
local BURN_SOFT_LIGHT = 0.8
local BURN_ONLY_RATE = { 0.45, 1.1 }
local BURN_ONLY_SIZE = { 0.8, 1.35 }
local BURN_ONLY_SPECIAL_TIER = 5
local TRAIL_RATE = { 14, 90 }
local TRAIL_SIZE = { 0.75, 2.3 }
local TRAIL_LIFE = { 0.45, 1.7 }
local TRAIL_SCALE_MAX = 5
local TRAIL_BRIGHTNESS = { 1.4, 3.6 }
local TRAIL_WHITE = 0.2
local TRAIL_FADE = 0.18
local TRAIL_CORE_FADE = 0.05
local TRAIL_LIGHT_PER_LENGTH = 0.8
local TRAIL_LIGHT_RANGE = { 12, 40 }
local TRAIL_LIGHT_BRIGHTNESS = { 1.5, 3 }
local TRAIL_SPARKS_FROM = 4
local TRAIL_SPARKS_RATE = { 8, 40 }
local TRAIL_CORE_FROM = 6
local TRAIL_CORE_RATE = { 12, 30 }
local TRAIL_CORE_SIZE = 0.6
local lite = false

-- aura kinds (names used in LOOKS[...].auras), each one or two particle emitters (see `auraKinds`)
local LOOKS = {
	Common = nil,
	Uncommon = { color = Color3.fromRGB(90, 220, 110), auras = { "leaves" } },
	Rare = { color = Color3.fromRGB(80, 150, 255), light = 6, auras = { "bubbles" } },
	Epic = { color = Color3.fromRGB(170, 90, 255), light = 8, auras = { "mist" } },
	Legendary = { color = Color3.fromRGB(255, 150, 40), light = 10, auras = { "glow", "sparks" } },
	Mythic = { color = Color3.fromRGB(255, 60, 50), light = 10, auras = { "flames", "embers" } },
	Transcendent = { color = Color3.fromRGB(255, 90, 200), light = 12, auras = { "petals" }, shell = true },
	Rainbow = { color = Color3.fromRGB(255, 255, 255), light = 12, auras = { "spiral" }, rainbow = true, halo = true },
	Golden = { color = Color3.fromRGB(255, 205, 60), light = 12, auras = { "glitter" }, pillar = true },
	Onyx = { color = Color3.fromRGB(35, 30, 45), light = 10, lightColor = Color3.fromRGB(170, 90, 255),
		auras = { "smoke", "crackles" } },
	Celestial = { color = Color3.fromRGB(255, 255, 255), light = 16, auras = { "stars", "glow" }, halo = true },
	Secret = { color = Color3.fromRGB(255, 255, 255), light = 20, auras = { "spiral", "flames", "crackles", "stars" },
		halo = true, rainbow = true, big = true },
	-- (2026-10-01) the three above Secret
	Cosmic = { color = Color3.fromRGB(90, 70, 220), light = 22, lightColor = Color3.fromRGB(150, 120, 255),
		auras = { "nebula", "stars", "orbit" }, big = true },
	Primeval = { color = Color3.fromRGB(255, 160, 40), light = 24, auras = { "flames", "embers", "glitter" }, pillar = true,
		big = true },
	Divine = { color = Color3.fromRGB(255, 245, 200), light = 28, auras = { "rays", "spiral", "stars", "glow" }, halo = true,
		rainbow = true, pillar = true, big = true },
	-- (2026-10-04) ⭐ 특별 (Config.SpecialRarities, the launch gift's): violet with gold stars and glitter
	Special = { color = Color3.fromRGB(150, 95, 255), light = 12, lightColor = Color3.fromRGB(255, 205, 60),
		auras = { "stars", "glitter" }, halo = true },
}

local function burnColors(look)
	if look.rainbow then
		return RAINBOW
	end
	local c = look.lightColor or look.color
	return ColorSequence.new(c:Lerp(Color3.new(1, 1, 1), BURN_WHITE), c)
end

-- a rarity's color (nil for common)
function RarityFx.color(rarityId)
	local look = LOOKS[rarityId]
	return look and look.color
end

-- a particle emitter on the core (the invisible part through the body); o: its settings, sizes in
-- studs for a SIZE_REFERENCE-long dino (× k)
local function emitter(core, k, o)
	local e = Instance.new("ParticleEmitter")
	e.Color = o.colors or ColorSequence.new(o.color)
	e.Rate = o.rate
	e.Speed = NumberRange.new(o.speed[1] * k, o.speed[2] * k)
	e.Lifetime = NumberRange.new(o.life[1], o.life[2])
	e.Size = NumberSequence.new(o.size[1] * k, o.size[2] * k)
	-- (2026-10-01, "a bit more see-through and more sparkly") every aura particle starts a little fainter and
	-- glows brighter
	e.Transparency = NumberSequence.new(math.min(0.95, (o.fade and o.fade[1] or 0.2) + PARTICLE_FAINTER),
		o.fade and o.fade[2] or 1)
	e.LightEmission = math.min(1, (o.light or 0.6) + PARTICLE_BRIGHTER)
	e.SpreadAngle = Vector2.new(o.spread or 25, o.spread or 25)
	e.EmissionDirection = o.direction or Enum.NormalId.Top
	e.Acceleration = (o.accel or Vector3.zero) * k
	e.Drag = o.drag or 0
	e.RotSpeed = NumberRange.new(-(o.spin or 0), o.spin or 0)
	e.Rotation = NumberRange.new(0, 360)
	e.LockedToPart = o.locked == true
	if o.texture then
		e.Texture = o.texture
	end
	if o.box then
		e.Shape = Enum.ParticleEmitterShape.Box
	end
	e.Parent = core
	return e
end

-- what each aura kind looks like, in the rarity's color c
local auraKinds = {
	leaves = function(core, k, c, n)
		emitter(core, k, { color = c, rate = 3 * n, speed = { 0.6, 1.2 }, life = { 2, 3 }, size = { 0.5, 0.1 }, box = true,
			spin = 120, accel = Vector3.new(0, 0.4, 0), fade = { 0.3, 1 }, light = 0.3, spread = 60 })
	end,
	bubbles = function(core, k, c, n)
		emitter(core, k, { color = c, rate = 5 * n, speed = { 1.5, 2.5 }, life = { 1.4, 2.2 }, size = { 0.25, 0.7 }, box = true,
			accel = Vector3.new(0, 1, 0), fade = { 0.35, 1 }, light = 0.4, spread = 15 })
	end,
	mist = function(core, k, c, n)
		emitter(core, k, { color = c, rate = 6 * n, speed = { 0.3, 0.7 }, life = { 1.8, 2.6 }, size = { 1.6, 2.8 }, box = true,
			texture = SMOKE, spin = 160, fade = { 0.55, 1 }, light = 0.7, spread = 180, locked = true })
	end,
	glow = function(core, k, c, n)
		emitter(core, k, { color = c, rate = 3 * n, speed = { 0.2, 0.5 }, life = { 1.5, 2 }, size = { 2.4, 3.4 }, box = true,
			fade = { 0.7, 1 }, light = 1, spread = 180, locked = true })
	end,
	sparks = function(core, k, c, n)
		emitter(core, k, { color = c, rate = 8 * n, speed = { 6, 10 }, life = { 0.5, 0.9 }, size = { 0.35, 0 },
			texture = SPARKLE, accel = Vector3.new(0, -6, 0), light = 1, spread = 30 })
	end,
	flames = function(core, k, c, n)
		emitter(core, k, { colors = ColorSequence.new(Color3.fromRGB(255, 200, 60), c), rate = 16 * n, speed = { 1.5, 3 },
			life = { 0.6, 1 }, size = { 1.6, 0.3 }, box = true, texture = FLAME, spin = 40, accel = Vector3.new(0, 2.5, 0),
			fade = { 0.35, 1 }, light = 0.8, spread = 12 })
	end,
	embers = function(core, k, c, n)
		emitter(core, k, { colors = ColorSequence.new(Color3.fromRGB(255, 200, 80), c), rate = 10 * n, speed = { 1, 2 },
			life = { 1.2, 2 }, size = { 0.2, 0 }, box = true, accel = Vector3.new(0, 3, 0), light = 1, spread = 40 })
	end,
	petals = function(core, k, c, n)
		emitter(core, k, { colors = ColorSequence.new(c, Color3.fromRGB(255, 220, 240)), rate = 6 * n, speed = { 0.5, 1 },
			life = { 2.2, 3 }, size = { 0.45, 0.3 }, box = true, texture = SPARKLE, spin = 200,
			accel = Vector3.new(0, -1.2, 0), direction = Enum.NormalId.Top, fade = { 0.1, 1 }, light = 0.5, spread = 90 })
	end,
	spiral = function(core, k, c, n)
		emitter(core, k, { colors = RAINBOW, rate = 12 * n, speed = { 2, 3.5 }, life = { 1.2, 1.8 }, size = { 0.5, 0 },
			box = true, texture = SPARKLE, spin = 300, accel = Vector3.new(0, 1.5, 0), light = 1, spread = 50 })
	end,
	glitter = function(core, k, c, n)
		emitter(core, k, { colors = ColorSequence.new(Color3.fromRGB(255, 245, 190), c), rate = 14 * n, speed = { 0.2, 0.6 },
			life = { 0.6, 1.1 }, size = { 0.45, 0 }, box = true, texture = SPARKLE, light = 1, spread = 180 })
	end,
	smoke = function(core, k, c, n)
		emitter(core, k, { color = Color3.fromRGB(25, 20, 35), rate = 5 * n, speed = { 0.4, 0.9 }, life = { 2, 3 },
			size = { 1.4, 2.6 }, box = true, texture = SMOKE, spin = 60, fade = { 0.45, 1 }, light = 0, spread = 40 })
	end,
	crackles = function(core, k, c, n)
		emitter(core, k, { color = Color3.fromRGB(190, 110, 255), rate = 16 * n, speed = { 8, 14 }, life = { 0.12, 0.25 },
			size = { 0.3, 0.05 }, box = true, light = 1, spread = 180, fade = { 0, 1 } })
	end,
	nebula = function(core, k, c, n) -- violet and deep-blue clouds drifting round the body
		emitter(core, k, { colors = ColorSequence.new(c, Color3.fromRGB(40, 20, 90)), rate = 7 * n, speed = { 0.3, 0.8 },
			life = { 2.5, 3.5 }, size = { 2, 3.2 }, box = true, texture = SMOKE, spin = 40, fade = { 0.5, 1 }, light = 0.8,
			spread = 180, locked = true })
	end,
	orbit = function(core, k, c, n) -- little bright planets circling (sparkles swept round)
		emitter(core, k, { colors = ColorSequence.new(Color3.fromRGB(150, 220, 255), Color3.fromRGB(255, 200, 120)),
			rate = 6 * n, speed = { 3, 4 }, life = { 1, 1.4 }, size = { 0.5, 0.2 }, texture = SPARKLE, light = 1,
			spread = 180, accel = Vector3.new(0, 0, 0), drag = 2 })
	end,
	rays = function(core, k, c, n) -- long golden rays shooting up
		emitter(core, k, { colors = ColorSequence.new(Color3.fromRGB(255, 250, 220), Color3.fromRGB(255, 210, 90)),
			rate = 5 * n, speed = { 8, 12 }, life = { 0.6, 0.9 }, size = { 0.7, 0.1 }, light = 1, spread = 15 })
	end,
	stars = function(core, k, c, n)
		emitter(core, k, { color = Color3.new(1, 1, 1), rate = 10 * n, speed = { 1.5, 3 }, life = { 1.2, 1.6 },
			size = { 0.6, 0 }, texture = SPARKLE, spin = 90, light = 1, spread = 60 })
	end,
}

local function fxPart(name, folder)
	local p = Instance.new("Part")
	p.Name = name
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
	p.Parent = folder
	return p
end

-- the inner sparkles' sway: one loop swings every emitter's sideways pull (weak keys: gone with the dino)
local swaying = setmetatable({}, { __mode = "k" })
local swayClock = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("RarityFx", function(dt)
	swayClock += dt
	if swayClock < INNER_SWAY_EVERY then
		return
	end
	swayClock = 0
	local t = os.clock()
	local x = math.sin(t * 2 * math.pi / INNER_SWAY_PERIOD[1]) * INNER_SWAY
	local z = math.cos(t * 2 * math.pi / INNER_SWAY_PERIOD[2]) * INNER_SWAY
	for emitter in pairs(swaying) do
		if emitter.Parent then
			local k = emitter:GetAttribute("SwayScale") or 1
			emitter.Acceleration = Vector3.new(x * k, INNER_LIFT * k, z * k)
		end
	end
end))

-- opts (optional): particleScale multiplies the particles' size and speed (a ridden dino is drawn much bigger
-- than one on the track: its aura stays the size of theirs), locked keeps the particles with the moving model
function RarityFx.apply(model, rarityId, footprint, opts)
	local look = LOOKS[rarityId]
	local old = model:FindFirstChild("RarityFx")
	while old do
		old:Destroy()
		old = model:FindFirstChild("RarityFx")
	end
	if not look then
		return
	end
	local folder = Instance.new("Folder")
	folder.Name = "RarityFx"
	folder.Parent = model
	local base = model:GetPivot()
	local _, size = model:GetBoundingBox()
	if opts and opts.size then
		size = opts.size
	end
	local n = look.big and 1.4 or 1
	local k = math.clamp(math.max(size.X, size.Z) / SIZE_REFERENCE, SIZE_SCALE_MIN, SIZE_SCALE_MAX) * n
		* (opts and opts.particleScale or 1)
	if opts and opts.burnOnly then
		local core = fxPart("RarityCore", folder)
		core.Transparency = 1
		core.Size = Vector3.new(math.max(size.X, 1), math.max(size.Y, 1), math.max(size.Z, 1)) * 0.8
		core.CFrame = base * CFrame.new(0, size.Y / 2, 0)
		local t = ((TIERS[rarityId] or BURN_ONLY_SPECIAL_TIER) - 1) / (#TIER_ORDER - 1)
		local kb = math.clamp(math.max(size.X, size.Z) / SIZE_REFERENCE, SIZE_SCALE_MIN, SIZE_SCALE_MAX) * n
			* opts.burnOnly * (BURN_ONLY_SIZE[1] + (BURN_ONLY_SIZE[2] - BURN_ONLY_SIZE[1]) * t)
		local burn = emitter(core, kb, { colors = burnColors(look),
			rate = BURN_RATE * n * (BURN_ONLY_RATE[1] + (BURN_ONLY_RATE[2] - BURN_ONLY_RATE[1]) * t), speed = { 1.2, 2.4 },
			life = { 0.5, 0.9 }, size = { 1.6, 0.3 }, box = true, texture = FLAME, spin = 40, accel = Vector3.new(0, 2.5, 0),
			fade = { 0.3, 1 }, light = 0.8, spread = 12, locked = opts.locked })
		burn.Name = "Burn"
		burn.LightEmission *= BURN_SOFT_LIGHT
		model:SetAttribute("Rarity", rarityId)
		if lite then
			RarityFx.setVisible(model, true)
		end
		return
	end

	-- an invisible part through the dino's body carries the lights and particles
	local core = fxPart("RarityCore", folder)
	core.Transparency = 1
	core.Size = Vector3.new(math.max(size.X, 1), math.max(size.Y, 1), math.max(size.Z, 1)) * 0.8
	core.CFrame = base * CFrame.new(0, size.Y / 2, 0)

	local trail = opts and opts.trail
	local t = ((TIERS[rarityId] or BURN_ONLY_SPECIAL_TIER) - 1) / (#TIER_ORDER - 1)
	local function lerp(range)
		return range[1] + (range[2] - range[1]) * t
	end
	if look.light or trail then
		local light = Instance.new("PointLight")
		light.Color = look.lightColor or look.color
		light.Range = (look.light or 0) * n
		light.Brightness = 1.5
		if trail then
			light.Range = math.clamp(math.max(size.X, size.Z) * TRAIL_LIGHT_PER_LENGTH, TRAIL_LIGHT_RANGE[1], TRAIL_LIGHT_RANGE[2])
			light.Brightness = lerp(TRAIL_LIGHT_BRIGHTNESS)
			light:SetAttribute("Signature", true)
		end
		light.Parent = core
	end
	do -- (2026-10-01, "sparkling inside the dino, more dazzling the higher the rarity, in its color") twinkles all
		-- through the body: more, bigger and brighter at every rarity up (TIERS)
		local tier = TIERS[rarityId] or 1
		local inner = Instance.new("ParticleEmitter")
		inner.Name = "InnerSparkles"
		inner.Shape = Enum.ParticleEmitterShape.Sphere
		inner.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
		inner.Texture = SPARKLE
		-- each one flashes white, settles into the rarity color, twinkles a second time and fades
		inner.Color = look.rainbow and RAINBOW or ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)),
			ColorSequenceKeypoint.new(0.35, look.color), ColorSequenceKeypoint.new(1, look.color) })
		inner.LightEmission = 1
		inner.Brightness = 1 + INNER_BRIGHTNESS_PER_TIER * tier
		local peak = (INNER_SIZE[1] + (INNER_SIZE[2] - INNER_SIZE[1]) * (tier - 1) / (#TIER_ORDER - 1)) * k
		inner.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.2, peak),
			NumberSequenceKeypoint.new(0.45, peak * 0.45), NumberSequenceKeypoint.new(0.7, peak * 0.85),
			NumberSequenceKeypoint.new(1, 0) })
		inner.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(0.2, 0),
			NumberSequenceKeypoint.new(0.7, 0.1), NumberSequenceKeypoint.new(1, 1) })
		inner.Lifetime = NumberRange.new(INNER_LIFETIME[1], INNER_LIFETIME[2])
		inner.Rate = INNER_RATE_PER_TIER * tier * n
		inner.EmissionDirection = Enum.NormalId.Top
		inner.Speed = NumberRange.new(INNER_RISE_SPEED[1] * k, INNER_RISE_SPEED[2] * k)
		inner.SpreadAngle = Vector2.new(INNER_RISE_SPREAD, INNER_RISE_SPREAD)
		inner.Drag = INNER_DRAG
		inner.Acceleration = Vector3.new(0, INNER_LIFT * k, 0)
		inner:SetAttribute("SwayScale", k)
		swaying[inner] = true
		inner.RotSpeed = NumberRange.new(-90, 90)
		inner.Rotation = NumberRange.new(0, 360)
		inner.LockedToPart = true
		inner.Parent = core
	end
	local burning = opts and opts.burn and (trail or (TIERS[rarityId] or 0) >= BURN_FROM)
	for _, kind in ipairs(look.auras or {}) do
		if not (burning and kind == "flames") then
			auraKinds[kind](core, k, look.color, n, size)
		end
	end
	if burning and trail then
		local tier = TIERS[rarityId] or BURN_ONLY_SPECIAL_TIER
		local kt = math.clamp(math.max(size.X, size.Z) / SIZE_REFERENCE, SIZE_SCALE_MIN, TRAIL_SCALE_MAX) * n * opts.burn
			* lerp(TRAIL_SIZE)
		local life = lerp(TRAIL_LIFE)
		local hot = look.lightColor or look.color
		local colors = look.rainbow and RAINBOW or ColorSequence.new(hot:Lerp(Color3.new(1, 1, 1), TRAIL_WHITE), hot)
		local burn = emitter(core, kt, { colors = colors, rate = lerp(TRAIL_RATE) * n, speed = { 1.2, 2.4 },
			life = { life * 0.7, life }, size = { 1.6, 0.3 }, box = true, texture = FLAME, spin = 40,
			accel = Vector3.new(0, 2.5, 0), fade = { TRAIL_FADE, 1 }, light = 0.8, spread = 12 })
		burn.Name = "Burn"
		burn.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
		burn.Brightness = lerp(TRAIL_BRIGHTNESS)
		burn:SetAttribute("Trailing", true)
		burn:SetAttribute("Signature", true)
		if tier >= TRAIL_CORE_FROM then
			local inner = emitter(core, kt * TRAIL_CORE_SIZE, { colors = ColorSequence.new(Color3.new(1, 1, 1), hot),
				rate = lerp(TRAIL_CORE_RATE) * n, speed = { 1, 2 }, life = { life * 0.5, life * 0.7 }, size = { 1.4, 0.2 },
				box = true, texture = FLAME, spin = 60, accel = Vector3.new(0, 3, 0), fade = { TRAIL_CORE_FADE, 1 }, light = 1,
				spread = 8 })
			inner.Name = "BurnCore"
			inner.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
			inner.Brightness = lerp(TRAIL_BRIGHTNESS)
			inner:SetAttribute("Trailing", true)
			inner:SetAttribute("Signature", true)
		end
		if tier >= TRAIL_SPARKS_FROM then
			local sparks = emitter(core, kt, { colors = look.rainbow and RAINBOW or ColorSequence.new(Color3.new(1, 1, 1), hot),
				rate = lerp(TRAIL_SPARKS_RATE) * n, speed = { 3, 6 }, life = { 0.5, 0.9 }, size = { 0.45, 0 },
				texture = SPARKLE, accel = Vector3.new(0, -4, 0), light = 1, spread = 60 })
			sparks.Name = "BurnSparks"
			sparks:SetAttribute("Trailing", true)
			sparks:SetAttribute("Signature", true)
		end
	elseif burning then
		local kb = math.clamp(math.max(size.X, size.Z) / SIZE_REFERENCE, SIZE_SCALE_MIN, SIZE_SCALE_MAX) * n * opts.burn
		local burn = emitter(core, kb, { colors = burnColors(look), rate = BURN_RATE * n, speed = { 1.2, 2.4 },
			life = { 0.5, 0.9 }, size = { 1.6, 0.3 }, box = true, texture = FLAME, spin = 40, accel = Vector3.new(0, 2.5, 0),
			fade = { 0.3, 1 }, light = 0.8, spread = 12 })
		burn.Name = "Burn"
	end
	if look.pillar then -- a soft column of gold light standing through the dino
		local pillar = fxPart("RarityPillar", folder)
		pillar.Shape = Enum.PartType.Cylinder
		pillar.Material = Enum.Material.Neon
		pillar.Color = look.color
		pillar.Transparency = PILLAR_TRANSPARENCY
		local height = size.Y * 2.2
		pillar.Size = Vector3.new(height, footprint * 1.2, footprint * 1.2)
		pillar.CFrame = base * CFrame.new(0, height / 2, 0) * CFrame.Angles(0, 0, math.rad(90))
	end
	if look.halo then -- a glowing ring floating over the head
		local halo = fxPart("RarityHalo", folder)
		halo.Transparency = 1
		local color = look.rainbow and Color3.fromRGB(255, 240, 160) or look.color
		halo.Color = color
		local d = math.max(1.2, math.min(size.X, size.Z) * 0.45)
		halo.Size = Vector3.new(d, HALO_THICKNESS, d)
		halo.CFrame = base * CFrame.new(0, size.Y + HALO_ABOVE + (opts and opts.haloLift or 0), 0)
		local band = math.max(HALO_BAND_MIN, d / 2 * HALO_BAND)
		local mid = (d - band) / 2
		local length = 2 * math.pi * mid / HALO_SEGMENTS * HALO_OVERLAP
		for i = 1, HALO_SEGMENTS do
			local a = 2 * math.pi * i / HALO_SEGMENTS
			local piece = fxPart("HaloPiece", halo)
			piece.Material = Enum.Material.Neon
			piece.Color = color
			piece.Size = Vector3.new(band, HALO_THICKNESS, length)
			local at = halo.CFrame * Vector3.new(mid * math.cos(a), 0, mid * math.sin(a))
			local along = halo.CFrame:VectorToWorldSpace(Vector3.new(-math.sin(a), 0, math.cos(a)))
			piece.CFrame = CFrame.lookAt(at, at + along, halo.CFrame.UpVector)
		end
		if look.rainbow then
			halo:SetAttribute("Rainbow", true)
		end
	end
	if opts and opts.soft then
		for _, d in ipairs(folder:GetDescendants()) do
			if d:IsA("ParticleEmitter") and d.Name == "Burn" then
				d.Rate *= BURN_SOFT_RATE
				d.LightEmission *= BURN_SOFT_LIGHT
			elseif d:IsA("ParticleEmitter") then
				d.Rate *= SOFT_RATE
				d.LightEmission *= SOFT_LIGHT
				d.Brightness = math.min(d.Brightness, SOFT_BRIGHTNESS)
				if d.Name == "InnerSparkles" and not look.rainbow then
					d.Color = ColorSequence.new(look.color)
				end
			elseif d:IsA("PointLight") then
				d:Destroy()
			elseif d:IsA("BasePart") and d.Name == "RarityPillar" then
				d.Transparency = math.max(d.Transparency, SOFT_PILLAR)
			end
		end
	end
	if opts and opts.locked then -- the particles go with the model instead of trailing behind it
		for _, d in ipairs(folder:GetDescendants()) do
			if d:IsA("ParticleEmitter") and not d:GetAttribute("Trailing") then
				d.LockedToPart = true
			end
		end
	end
	model:SetAttribute("Rarity", rarityId)
	if lite then
		RarityFx.setVisible(model, true)
	end
end

function RarityFx.tint(part, color)
	part.Color = color
	for _, d in ipairs(part:GetChildren()) do
		if d:IsA("BasePart") then
			d.Color = color
		end
	end
end

function RarityFx.setLite(on)
	lite = on == true
end

-- turn a model's rarity effects on or off (the view settings hide dinos on one screen only)
function RarityFx.setVisible(model, visible)
	local folder = model:FindFirstChild("RarityFx")
	if not folder then
		return
	end
	for _, d in ipairs(folder:GetDescendants()) do
		if d:IsA("ParticleEmitter") then
			d.Enabled = visible
			local base = d:GetAttribute("BaseRate")
			if not base then
				base = d.Rate
				d:SetAttribute("BaseRate", base)
			end
			d.Rate = lite and not d:GetAttribute("Signature") and base * LITE_RATE or base
		elseif d:IsA("Light") then
			d.Enabled = visible and (not lite or d:GetAttribute("Signature") == true)
		elseif d:IsA("BasePart") then
			d.LocalTransparencyModifier = visible and 0 or 1
		end
	end
end

return RarityFx
