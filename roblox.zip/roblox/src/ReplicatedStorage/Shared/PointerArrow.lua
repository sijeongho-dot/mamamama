--[[
PointerArrow: the arrow over my head that points somewhere (display only, on my screen): first the sky
race's next ring (StarterPlayerScripts/Race, 2026-10-01), then my base while I carry keys
(StarterPlayerScripts/KeyArrow, 2026-10-02, "공중 레이스때 사용하는 화살표를 열쇠주웠을때 기지쪽으로 향하는
시스템으로 똑같이"). A shaft and a head (two wedges, back to back), lying flat: its head spreads left and right.

	local arrow = PointerArrow.make(color)            -- a new arrow Model in the Workspace
	PointerArrow.point(arrow, at, target, sizes)      -- at `at`, looking at `target`, sized by how far it is:
	                                                  -- sizes = { near, far, big, small } (studs, studs, ×, ×)
	arrow:Destroy()
]]

local Workspace = game:GetService("Workspace")

local PointerArrow = {}

-- display only
local SHAFT = Vector3.new(0.5, 0.5, 2.6) -- studs at size 1: the shaft ...
local HEAD = Vector3.new(0.35, 1.1, 1.6) -- ... and each half of the head (a wedge; two make a triangle)

function PointerArrow.make(color)
	local model = Instance.new("Model")
	model.Name = "PointerArrow"
	local center = Instance.new("Part")
	center.Name = "Center"
	center.Size = Vector3.new(0.2, 0.2, 0.2)
	center.Transparency = 1
	center.CFrame = CFrame.new()
	center.Parent = model
	model.PrimaryPart = center
	local function piece(cls, size, cf)
		local p = Instance.new(cls)
		p.Size = size
		p.CFrame = cf
		p.Color = color
		p.Material = Enum.Material.SmoothPlastic -- (not Neon: no glow, "번쩍이는 효과 없애")
		p.Parent = model
	end
	-- (2026-10-02: was twice, crossed, "십자가 모양 … 위아래 일자를 빼서 좌우 일자만 남기자")
	local turn = CFrame.Angles(0, 0, math.pi / 2)
	-- (-Z points at the target: the shaft behind, the head's point in front)
	piece("Part", SHAFT, turn * CFrame.new(0, 0, SHAFT.Z / 2))
	piece("WedgePart", HEAD, turn * CFrame.new(0, HEAD.Y / 2, -HEAD.Z / 2))
	piece("WedgePart", HEAD, turn * CFrame.new(0, -HEAD.Y / 2, -HEAD.Z / 2) * CFrame.Angles(0, 0, math.pi))
	for _, p in ipairs(model:GetDescendants()) do
		if p:IsA("BasePart") then
			p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
		end
	end
	model.Parent = Workspace
	return model
end

-- big at sizes[1] studs or nearer, down to small at sizes[2] or farther
function PointerArrow.point(arrow, at, target, sizes)
	local near, far, big, small = sizes[1], sizes[2], sizes[3], sizes[4]
	local d = (target - at).Magnitude
	local k = math.clamp((d - near) / (far - near), 0, 1)
	arrow:ScaleTo(big + (small - big) * k)
	if d > 0.5 then
		arrow:PivotTo(CFrame.lookAt(at, target))
	end
end

return PointerArrow
