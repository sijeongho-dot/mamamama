--[[
BetaWindows: the closed beta's two windows on this client (2026-10-02, design 17; the server's BetaLog
keeps what they send). Display only; ViewSettings (설정) has a button for each, StarterPlayerScripts/News
opens the news when the server says so.

	BetaWindows.openNews(fromServer, tab)  -- 📰 업데이트 소식 (tab 1 ✨ new, 2 🔧 fixed) (Config.Beta.News); its 확인 sends NewsSeen when the
	                                  -- server opened it (the attendance window comes after)
	BetaWindows.openReport()          -- 🐞 버그 신고: a kind (Config.Beta.ReportKinds), a text box, 보내기
	                                  -- (Net request BugReport; the server checks the length and how often)

Both are sized in pixels and fitted to the screen's free part (Shared/Windows: smaller on phones).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer
local B = Config.Beta

local BetaWindows = {}

-- display only
local FONT = Enum.Font.GothamBold
local NEWS_SIZE = UDim2.fromOffset(420, 330)
local REPORT_SIZE = UDim2.fromOffset(420, 300)
local ROW_HEIGHT = 44
local TAB_HEIGHT = 30
local TAB_WIDTH = 140
local DATE_WIDTH = 90
local COLOR_HEADER = Color3.fromRGB(255, 215, 110)
local COLOR_THANKS = Color3.fromRGB(110, 80, 40)
local ICON_WIDTH = 36
local KIND_HEIGHT = 32
local BOX_HEIGHT = 120
local BUTTON_HEIGHT = 38
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_ROW = Color3.fromRGB(45, 50, 68)
local COLOR_SOFT = Color3.fromRGB(190, 190, 200)
local COLOR_OK = Color3.fromRGB(70, 180, 90)
local COLOR_REPORT = Color3.fromRGB(200, 110, 60)
local COLOR_KIND_ON = Color3.fromRGB(90, 110, 170)
local COLOR_KIND_OFF = Color3.fromRGB(60, 64, 80)
local COLOR_BOX = Color3.fromRGB(240, 240, 245)
local COLOR_BOX_TEXT = Color3.fromRGB(30, 30, 40)
local COLOR_OVER = Color3.fromRGB(255, 120, 120)

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.TextWrapped = true
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 15
	b.TextColor3 = Color3.new(1, 1, 1)
	b.TextWrapped = true
	b.Text = text
	b.BackgroundColor3 = color
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 10)
	return b
end

local gui = nil
local function screen()
	if not gui then
		gui = Instance.new("ScreenGui")
		gui.Name = "BetaWindows"
		gui.ResetOnSpawn = false
		gui.Parent = player:WaitForChild("PlayerGui")
	end
	return gui
end

local function window(size, titleText, cover)
	local w = Instance.new("Frame")
	w.Size = size
	w.BackgroundColor3 = COLOR_BG
	w.Visible = false
	w.Parent = screen()
	corner(w, 14)
	local title = label(w, titleText, UDim2.new(1, -60, 0, 34), UDim2.fromOffset(14, 6), 19)
	title.TextXAlignment = Enum.TextXAlignment.Left
	Windows.fit(w, cover and { Cover = cover } or nil)
	return w
end

-- ---------------------------------------------------------------------------
-- 📰 the update news
-- ---------------------------------------------------------------------------

local news, newsFromServer, newsTab = nil, false, nil

local function closeNews()
	news.Visible = false
	if newsFromServer then
		newsFromServer = false
		Net.request("NewsSeen", B.News.Version)
	end
end

local function buildNews()
	news = window(NEWS_SIZE, "📰 업데이트 소식", "Fill")
	require(Shared:WaitForChild("DinoPortrait")).backdrop(news, "Pteranodon")
	local tabsAt = 40
	local date = label(news, B.News.Version, UDim2.new(0, DATE_WIDTH, 0, TAB_HEIGHT), UDim2.new(1, -DATE_WIDTH - 14, 0, tabsAt), 12)
	date.TextXAlignment = Enum.TextXAlignment.Right
	date.TextColor3 = COLOR_SOFT
	local listTop = tabsAt + TAB_HEIGHT + 8
	local function makeList()
		local list = Instance.new("ScrollingFrame")
		list.Position = UDim2.fromOffset(10, listTop)
		list.Size = UDim2.new(1, -20, 1, -listTop - BUTTON_HEIGHT - 18)
		list.BackgroundTransparency = 1
		list.ScrollBarThickness = 6
		list.AutomaticCanvasSize = Enum.AutomaticSize.Y
		list.CanvasSize = UDim2.new()
		list.Parent = news
		local layout = Instance.new("UIListLayout")
		layout.Padding = UDim.new(0, 5)
		layout.SortOrder = Enum.SortOrder.LayoutOrder
		layout.Parent = list
		return list
	end
	local order = 0
	local function row(list, icon, text, color)
		order += 1
		local r = Instance.new("Frame")
		r.LayoutOrder = order
		r.Size = UDim2.new(1, -8, 0, ROW_HEIGHT)
		r.BackgroundColor3 = color
		r.Parent = list
		corner(r, 8)
		label(r, icon, UDim2.fromOffset(ICON_WIDTH, ROW_HEIGHT), UDim2.fromOffset(4, 0), 22)
		local t = label(r, text, UDim2.new(1, -ICON_WIDTH - 14, 1, -4), UDim2.fromOffset(ICON_WIDTH + 6, 2), 13)
		t.TextXAlignment = Enum.TextXAlignment.Left
	end
	local function thanks(list)
		order += 1
		local t = label(list, B.News.Thanks, UDim2.new(1, -8, 0, ROW_HEIGHT), UDim2.new(), 14)
		t.LayoutOrder = order
		t.BackgroundTransparency = 0
		t.BackgroundColor3 = COLOR_THANKS
		t.TextColor3 = COLOR_HEADER
		corner(t, 8)
	end
	local newList = makeList()
	for _, item in ipairs(B.News.Items) do
		row(newList, item.Icon, item.Text, COLOR_ROW)
	end
	local fixList = nil
	if B.News.Fixes or B.News.Thanks then
		fixList = makeList()
		if B.News.Thanks then
			thanks(fixList)
		end
		for _, item in ipairs(B.News.Fixes or {}) do
			row(fixList, item.Icon, item.Text, COLOR_ROW)
		end
	end
	local tabs = {}
	local function show(which)
		which = fixList and which or 1
		newList.Visible = which == 1
		if fixList then
			fixList.Visible = which == 2
		end
		for i, b in ipairs(tabs) do
			b.BackgroundColor3 = i == which and COLOR_KIND_ON or COLOR_KIND_OFF
		end
	end
	newsTab = show
	local tabCount = fixList and 2 or 1
	local names = { "✨ 새로 생긴 것", "🔧 고친 것" }
	for i = 1, tabCount do
		local b = button(news, names[i], COLOR_KIND_OFF, UDim2.fromOffset(TAB_WIDTH, TAB_HEIGHT),
			UDim2.fromOffset(10 + (i - 1) * (TAB_WIDTH + 6), tabsAt))
		b.TextSize = 14
		b.Activated:Connect(function()
			show(i)
		end)
		tabs[i] = b
	end
	show(1)
	local report = button(news, "🐞 버그 신고", COLOR_REPORT, UDim2.new(0.5, -15, 0, BUTTON_HEIGHT),
		UDim2.new(0, 10, 1, -BUTTON_HEIGHT - 10))
	local ok = button(news, "✅ 확인", COLOR_OK, UDim2.new(0.5, -15, 0, BUTTON_HEIGHT),
		UDim2.new(0.5, 5, 1, -BUTTON_HEIGHT - 10))
	report.Activated:Connect(function()
		closeNews()
		BetaWindows.openReport()
	end)
	ok.Activated:Connect(closeNews)
	Windows.register(news, closeNews)
end

function BetaWindows.openNews(fromServer, tab)
	newsFromServer = newsFromServer or fromServer == true
	if tab or not news.Visible then
		newsTab(tab or 1)
	end
	news.Visible = true
end

-- ---------------------------------------------------------------------------
-- 🐞 the bug report
-- ---------------------------------------------------------------------------

local reportWindow = nil

local function buildReport()
	reportWindow = window(REPORT_SIZE, "🐞 버그 신고")
	local hint = label(reportWindow, "🐞 무엇이 이상했나요? 개발자만 봐요", UDim2.new(1, -28, 0, 18), UDim2.fromOffset(14, 38), 13)
	hint.TextXAlignment = Enum.TextXAlignment.Left
	hint.TextColor3 = COLOR_SOFT
	local kinds, chosen = {}, B.ReportKinds[1].Id
	local width = (REPORT_SIZE.X.Offset - 20 - 8 * (#B.ReportKinds - 1)) / #B.ReportKinds
	local function showKinds()
		for id, b in pairs(kinds) do
			b.BackgroundColor3 = id == chosen and COLOR_KIND_ON or COLOR_KIND_OFF
		end
	end
	for i, k in ipairs(B.ReportKinds) do
		local b = button(reportWindow, k.Name, COLOR_KIND_OFF, UDim2.fromOffset(width, KIND_HEIGHT),
			UDim2.fromOffset(10 + (i - 1) * (width + 8), 62))
		b.TextSize = 14
		kinds[k.Id] = b
		b.Activated:Connect(function()
			chosen = k.Id
			showKinds()
		end)
	end
	showKinds()
	local box = Instance.new("TextBox")
	box.Position = UDim2.fromOffset(10, 62 + KIND_HEIGHT + 8)
	box.Size = UDim2.new(1, -20, 0, BOX_HEIGHT)
	box.BackgroundColor3 = COLOR_BOX
	box.TextColor3 = COLOR_BOX_TEXT
	box.PlaceholderText = "예) 상자를 열었는데 돈이 안 들어왔어요"
	box.PlaceholderColor3 = COLOR_SOFT
	box.Font = Enum.Font.Gotham
	box.TextSize = 15
	box.Text = ""
	box.MultiLine = true
	box.TextWrapped = true
	box.ClearTextOnFocus = false
	box.TextXAlignment = Enum.TextXAlignment.Left
	box.TextYAlignment = Enum.TextYAlignment.Top
	box.Parent = reportWindow
	corner(box, 8)
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, 8), UDim.new(0, 8)
	pad.PaddingTop, pad.PaddingBottom = UDim.new(0, 6), UDim.new(0, 6)
	pad.Parent = box
	local count = label(reportWindow, "", UDim2.fromOffset(120, BUTTON_HEIGHT), UDim2.new(0, 14, 1, -BUTTON_HEIGHT - 10), 13)
	count.TextXAlignment = Enum.TextXAlignment.Left
	local function showCount()
		local n = utf8.len(box.Text) or #box.Text
		count.Text = string.format("%d / %d자", n, B.ReportMaxLength)
		count.TextColor3 = (n > B.ReportMaxLength or #box.Text > Config.Net.MaxStringLength) and COLOR_OVER or COLOR_SOFT
	end
	box:GetPropertyChangedSignal("Text"):Connect(showCount)
	showCount()
	local send = button(reportWindow, "📨 보내기", COLOR_OK, UDim2.fromOffset(150, BUTTON_HEIGHT),
		UDim2.new(1, -160, 1, -BUTTON_HEIGHT - 10))
	send.Activated:Connect(function()
		local text = box.Text
		if (utf8.len(text) or #text) > B.ReportMaxLength or #text > Config.Net.MaxStringLength then
			return -- (the count shows red: shorten it first)
		end
		Net.request("BugReport", chosen, text)
		box.Text = ""
		reportWindow.Visible = false
	end)
	Windows.register(reportWindow)
end

function BetaWindows.openReport()
	reportWindow.Visible = true
end

-- built hidden straight away (registered with Shared/Windows like every other window; tools/check_phone_ui.py
-- opens each on the phone sizes)
buildNews()
buildReport()

return BetaWindows
