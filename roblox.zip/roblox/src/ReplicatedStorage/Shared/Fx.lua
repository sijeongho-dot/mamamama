--[[
Fx: one-shot particle bursts for the clients (display only): the slap hit, keys scattering, a level
up. A small invisible anchored part emits once and cleans itself up.

	Fx.burst(position, { color, color2 }, count, speed, size, lifetime)
	Fx.confetti(position)   -- many colors, for a promotion
]]

local Workspace = game:GetService("Workspace")

local Fx = {}

-- display only
local CONFETTI = { Color3.fromRGB(255, 90, 90), Color3.fromRGB(255, 210, 60), Color3.fromRGB(90, 220, 110),
	Color3.fromRGB(80, 160, 255), Color3.fromRGB(200, 110, 255) }

local folder = nil
local function holder()
	if not folder or not folder.Parent then
		folder = Instance.new("Folder")
		folder.Name = "Fx"
		folder.Parent = Workspace
	end
	return folder
end

local POOL_MAX = 24
local pool = {}

local function emitterPart()
	local part = Instance.new("Part")
	part.Anchored, part.CanCollide, part.CanQuery, part.CanTouch, part.CastShadow = true, false, false, false, false
	part.Transparency = 1
	part.Size = Vector3.one * 0.2
	local e = Instance.new("ParticleEmitter")
	e.Rate = 0
	e.SpreadAngle = Vector2.new(180, 180)
	e.Transparency = NumberSequence.new(0, 1)
	e.LightEmission = 0.8
	e.RotSpeed = NumberRange.new(-180, 180)
	e.Parent = part
	part.Parent = holder()
	return { part = part, emitter = e, freeAt = 0 }
end

local function freeSlot(now)
	for i = #pool, 1, -1 do
		local slot = pool[i]
		if not slot.part.Parent then
			table.remove(pool, i)
		elseif slot.freeAt <= now then
			return slot, false
		end
	end
	if #pool < POOL_MAX then
		local slot = emitterPart()
		table.insert(pool, slot)
		return slot, false
	end
	return emitterPart(), true
end

function Fx.burst(position, colors, count, speed, size, lifetime)
	local now = os.clock()
	local slot, temporary = freeSlot(now)
	local e = slot.emitter
	slot.part.CFrame = CFrame.new(position)
	e.Speed = NumberRange.new(speed * 0.5, speed)
	e.Lifetime = NumberRange.new(lifetime * 0.6, lifetime)
	e.Size = NumberSequence.new(size, 0)
	e.Acceleration = Vector3.new(0, -speed, 0)
	for _, color in ipairs(colors) do
		e.Color = ColorSequence.new(color)
		e:Emit(math.max(1, math.floor(count / #colors)))
	end
	slot.freeAt = now + lifetime + 0.2
	if temporary then
		task.delay(lifetime + 0.2, function()
			slot.part:Destroy()
		end)
	end
end

function Fx.confetti(position)
	Fx.burst(position, CONFETTI, 60, 22, 0.6, 1.6)
end

return Fx
