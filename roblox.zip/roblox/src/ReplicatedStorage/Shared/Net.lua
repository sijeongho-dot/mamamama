--[[
Net: every message between clients and the server goes through here.

Kinds:
	Request - client -> server: "I want to do this" (a RemoteEvent). The server decides everything.
	Ask     - client -> server, with an answer (a RemoteFunction), e.g. reading the player's own data.
	Push    - server -> client (a RemoteEvent), e.g. a notice to show.

The server checks every Request and Ask before the handler runs: the argument types (numbers must
be finite, strings at most Config.Net.MaxStringLength, tables at most MaxTableItems plain values, no
tables in tables), a rate limit per player and message (Config.Net; Config.Net.Limits for the asks with big
answers), and whether the player's data is
loaded. Anything else a client sends (prices, amounts, results) is never trusted: handlers work
it out again from server data.

Server:  Net.init()  Net.onRequest(name, argTypes, handler)  Net.onAsk(name, argTypes, handler)
         Net.push(player, name, ...)  Net.pushAll(name, ...)  Net.setReadyCheck(fn)
Client:  Net.request(name, ...)  Net.ask(name, ...)  Net.onPush(name, handler)
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Config = require(ReplicatedStorage:WaitForChild("Config"))

local Net = {}

-- every message and its kind; add new ones here
Net.Messages = {
	GetMyData = "Ask",
	GetReports = "Ask", -- (days back): the developer's 📬 bug report inbox (BetaLog; nil for anyone else)
	Ping = "Ask", -- the client checks the server still answers (Watchdog: a "server is slow" banner)
	ClientError = "Request", -- (message, trace): a script error on a player's screen, written to the server's log
	PerfReport = "Request",
	LoadReport = "Request",
	BugReport = "Request", -- (kind Id, text): a tester's bug report from the 🐞 window (BetaLog keeps it by the day)
	NewsSeen = "Request", -- (news version): the update news window was closed (BetaLog)
	OpenNews = "Push", -- (): show the update news (BetaLog, on joining with news not seen yet)
	CocoCard = "Push",
	Survey = "Push",
	SurveyAnswer = "Request",
	LikeAsk = "Request",
	GetSeason = "Ask", -- the 🏆 season pass window: the season, XP, both tracks (Season service)
	ClaimSeason = "Request", -- (track "Free" | "Paid" | "All", tier): take a season reward that is ready (All: every one)
	GetRewards = "Ask", -- the 🎁 window: playtime gifts, daily missions, the weekly key challenge
	ClaimReward = "Request", -- (kind "Playtime" | "PlaytimeAll" | "Daily" | "DailyAll" | "Weekly" | "WeeklyChallenge", index or challenge kind): take a reward that is ready
	GetInventory = "Ask", -- everything the player owns (the 인벤토리 window): money, keys, bag, upgrades, dinos
	Notice = "Push",
	WitchShow = "Push",
	BigFind = "Push",
	ChestMine = "Push",
	RebirthFx = "Push", -- (userId, rebirths): that player just reborn: they float up, spin and land (StarterPlayerScripts/RebirthFx)
	GachaPreview = "Push", -- (rarity Id): Studio's ;gachafx: the draw screen shows that rarity's reveal (no dino given)
	KeyFound = "Push", -- (n): n keys found in the minerals just mined (they ride in the bag)
	Mined = "Push", -- (n, grade Id, money): n minerals of that grade just went into my bag, worth that at the deposit bin
	FossilSlap = "Push",
	MineLocked = "Push", -- (grade Id): that mineral is too hard for my pickaxe to start (Formulas.mineLocked)
	GradeOpened = "Push",
	Jackpot = "Push", -- (userId, position, money): that player mined a 대박 광물 there (a burst for every screen)
	BuyPickaxe = "Request", -- next pickaxe tier at the player's own shop (all power steps done)
	UpgradePower = "Request", -- next power step of the current pickaxe
	UpgradeSpeed = "Request", -- next level of the pickaxe speed track
	UpgradeBag = "Request", -- next bag level at the player's own shop
	UpgradeCharacter = "Request", -- ("Slap" | "MoveSpeed"): the next level at the player's own shop
	BuyKeys = "Request", -- (count, grade): keys at the player's own shop, Gacha.KeyBuyCounts of a Keys.Types grade
	ExchangeKeys = "Request", -- (grade, times): Keys.ExchangeRate keys of a grade -> one of the next grade, at the key stall
	Draw = "Ask", -- (count, grade): spend that many keys of the grade on draws; answers { Boxes = { box, ... } } or { Error }
	GetBoxes = "Ask",
	OpenBoxes = "Ask",
	BoxRush = "Ask",
	BoxFreeSkip = "Ask",
	OpenRewards = "Push", -- (tab) open the 🎁 window on that tab (the attendance after joining; Rewards)
	HideAdToday = "Request", -- (kind "Event" | "Offer", 2026-10-04): that join pop-up not again today (Rewards)
	OfferSeen = "Request", -- () the starter pack's join offer is on the screen: saved, never again on this account (Monetization)
	EventAd = "Push", -- () 🎉 the launch event's pop-up on joining (Rewards; StarterPlayerScripts/EventAd)
	Banner = "Push", -- (text, key grade Id, slot?) a message at the top of everyone's screen, e.g. a key drop; with a slot, it replaces that slot's banner text (the weather countdown)
	BuyTrainBoost = "Request", -- (): the training boost, at the own shop (Training)
	LaunchGift = "Push", -- (species, rarity, size) 🎉 the launch gift's celebration window (LaunchGift)
	BuyTrainGear = "Request", -- (station Id): 🔧 the station's next gear level, standing at it (Training)
	DropKeys = "Request", -- (kind?, count?): put every carried key down around the player, or count of one kind
	Slap = "Request", -- (my position, my facing on my screen): swing the slap toy; the server finds who is hit
	SlapFx = "Push", -- (slapperUserId, { hit player UserIds }, slap level, { Vector3 where fossils/zombies were hit }) a swing, for everyone's screen
	Knockback = "Push", -- (dirX, dirZ, studs) push this player's own character away
	-- (2026-10-03) (userId, flightSeconds, kind) to everyone: that player is thrown through the air (a whoosh on
	-- them; kind "Buck" / "BuckBig": a little / giant wild dino bucked them off its back)
	FlyFx = "Push",
	TrainLevelFx = "Push", -- (userId, track, training level, a whole step too): a training level-up, for everyone near (2026-10-04)
	TeleportHome = "Request", -- go to the player's own base in HomeTeleport.Delay seconds
	PlaceUnit = "Request", -- (unitId, x, z): put or move one of the player's dinos on their own platform
	RemoveUnit = "Request", -- (unitId): take a dino off the platform
	AutoArrange = "Request",
	ApplyDeckAdvice = "Request",
	AutoFarm = "Request",
	SetTargeting = "Request", -- (unitId, mode): whom a placed dino hits first (Config.Defense.Targets; Defense)
	SetDefenseMap = "Request", -- (map Id): play on another opened defense map (Config.Defense.Maps; Defense)
	TopViewUsed = "Request",
	OpenPlacement = "Push", -- (farm): the 🦖 / 🌾 board beside the slot signs was pressed by its owner (PlaceBoards)
	OpenMaps = "Push", -- (): the defense sign's 🗺️ prompt opens the map window (DefenseMaps)
	SetSetting = "Request", -- (name, on): a screen setting (Settings in the profile), e.g. HideOtherFossils
	AutoDeposit = "Request", -- (): the ⛏️ auto mining pass empties the bag at the player's own deposit bin (Deposit)
	SetLanguage = "Request", -- (code): the game's language, "en" / "ko" / "es" (Settings, Shared/Lang)
	TutorialStepDone = "Request", -- (step Id): a tutorial step the client ends (the hatching, pressing a button; Tutorial)
	HintSeen = "Request", -- (tip Id): one of Coco's tips was shown, never again (Config.Hints; Tutorial)
	TutorialSkip = "Request", -- (): the tutorial's skip button, held down
	DevGiftSeen = "Request", -- (): the developer's gift window was confirmed (player attribute DevGift; Monetization)
	ReplayIntro = "Request",
	CocoIntroDone = "Request",
	DevRestart = "Request",
	DamageLook = "Request",
	ShareDone = "Request",
	WelcomeHome = "Request",
	ClaimComeback = "Request",
	TutorialChoice = "Request", -- (2026-10-04) (yes): the first join's "튜토리얼 할까요?" answer (TutorialAsk; Tutorial)
	TutorialReplay = "Request", -- (part?): 설정's "📖 코코에게 배우기" (nil: the whole; a Config.Tutorial.Parts Id; a lesson too)
	LessonOffered = "Request", -- (2026-10-03) (part Id): Coco asked me about this lesson (StarterPlayerScripts/Lessons)
	ClaimStarter = "Request", -- (): take the reached beginner mission's reward (StarterMissions)
	StarterPass = "Request", -- (): pass the optional beginner mission by (held down)
	SetVolume = "Request", -- (name, 0..1): a sound bar in 보기 설정, MusicVolume or MasterVolume (Settings)
	StartPromotion = "Request", -- start the promotion fight (승급전) on the player's own track
	CancelPromotion = "Request", -- give up the running promotion fight (counts as a failure: retry wait)
	-- (2026-10-04) a promotion won with fewer than three stars: asked before the level goes up (Defense)
	StartChallenge = "Request", -- (2026-10-02) start ♾️ 무한 도전 on the player's own track (Defense)
	CancelChallenge = "Request", -- end the running ♾️ 무한 도전 now (the waves cleared count)
	GetMyUnits = "Ask", -- the player's dinos, placements and slots (for the placement screen)
	GetDefense = "Ask", -- every running defense field now (for a player who just joined)
	DefenseEvents = "Push", -- (serverTime, { { base, events } }) what happened on the tracks this tick
	RegisterFarm = "Request", -- (unitId): put one of the player's dinos on the farm (its theme's buff)
	UnregisterFarm = "Request", -- (unitId): take a dino off the farm
	FarmLock = "Request",
	GetCollection = "Ask", -- the 도감 window: collection keys, skins, bonuses, farm count
	Rebirth = "Request", -- rebirth at the player's own shop (top of the level tier, pays Formulas.rebirthCost)
	Mine = "Request", -- (node model): start mining it, or stop if already (the "캐기!" button; tapping works too)
	Poop = "Push", -- (x, y, z, fallSeconds, height, approachSeconds, heading): a pterosaur flies in and drops one there
	Lightning = "Push", -- (x, y, z, warnSeconds, radius): a storm bolt lands there after warnSeconds (Lightning service)
	Ride = "Request", -- (on): get on the player's dino (only in the safe land) or off it
	Roar = "Request", -- the dino I ride roars (Config.Ride.RoarCooldown)
	RoarFx = "Push", -- (userId): that rider's dino roars, for everyone's screen
	SetMount = "Request", -- (speciesId, rarityId, sizeId): the dino to ride and the rarity whose aura it wears, chosen at the base's mount pedestal
	Enhance = "Ask", -- (targetId, { fodderId, ... }): feed a dino others of its species; { Level, Exp, Gained } or { Error }
	Merge = "Ask", -- ({ id, id, id }, keepId): 합성 of top-level dinos into one of the next rarity; { Unit } or { Error }
	Feed = "Ask", -- (unitId, amount): 🍎 put up to amount of my food into one of my dinos (it adds up to the next size), at my enhance stall; { Unit, Fruit, Grew, Put } or { Error }
	FruitDrop = "Push", -- ({ { Id, Kind, Size, At, Top, Life, BlockedUser, BlockedUntil } }): fruit on the ground, for everyone (Fruits)
	PickFruit = "Request", -- (fruit Id): I walked over a fruit (anyone's)
	FruitGone = "Push", -- (fruit Id, picker's UserId): someone picked it up (player attribute CarriedFruit / CarriedFood)
	FruitStored = "Push", -- (food): my carried fruit became food in my base (player attribute Fruit: the food saved)
	DropFruit = "Request", -- (count): put that many of my carried fruit down for anyone
	ClaimCommunity = "Request", -- take the community (group) reward at my base's sign, after joining (Community)
	CommunityJoin = "Push", -- (groupId): I'm not in the group yet: show Roblox's join prompt
	StudioBuy = "Request", -- (product or pass key): Studio only, a product or pass without its id yet is granted at once
	Offer = "Push", -- ("StarterPack", moment): pop the starter pack up (Monetization)
	PurchaseDone = "Push", -- (key): a Robux purchase was granted (the client's thank-you)
	BuyBombs = "Request", -- (kind, count): bombs at my base's bomb stall (Bombs service)
	ThrowBomb = "Request", -- (kind, aim Vector3): throw one toward aim (at most Config.Bombs.ThrowRange)
	BombFx = "Push", -- (userId, kind, from, to, seconds): a bomb flying to where it lands
	BombBlast = "Push", -- (kind, at, hit userIds, spots, on the battlefield, reach): it went off
	RingBell = "Request", -- ring my bell: everyone hears it and sees a mark where I am (cooldown on the server)
	BellPing = "Push", -- (userId, position, slot, area): someone rang their bell there (slot: their bell's own look)
	EquipSkin = "Request", -- (skin Id or ""): wear an unlocked slap skin ("" = the level's own look)
	WildRide = "Request", -- (giant) I climbed onto a wild dino in the safe land: it throws me off a moment later
	WildKick = "Request", -- (dx, dz) a giant wild dino I slapped kicks me away that way (Wildlife: a slap of mine just before)
	WildCounter = "Request", -- (dx, dz) a little wild dino I slapped caught me and slaps back: thrown that way
	KeysHome = "Push", -- (userId): that player just brought keys home (a sound and a sparkle)
	BossHitMoney = "Push", -- (amount, at): my hit on a boss paid this much (Zombies), "+n원" over it
	MoneyPop = "Push", -- (userId, amount): that player picked up their pile of money from time away
	BossFx = "Push", -- (kind, x, z, a, b, bossName): a boss's big attack for every screen ("Roar" at x,z radius a,
	-- windup b; "Charge" from x,z toward a,b; "Bomb" falling on x,z, radius a, fall seconds b); bossName: its
	-- Configuration in Workspace.Zombies ("Boss", "AuroraBoss")
	-- (2026-10-04) 🧟 my night boss hunts (Zombies): { Hunts (ever), Week (this week's), Bones = { [boss kind Id] = n } }
	GetBossHunt = "Ask",
	-- (2026-10-03) 🙈 hide-and-seek (HideSeek service)
	GetHideSeek = "Ask", -- the rooms (and mine), my record
	HideSeekRooms = "Push", -- (rooms): the room list changed; the window redraws
	HideSeekCreate = "Request", -- (ranked boolean, 2026-10-04: 🏆 랭킹전 or 🎈 일반전; stake grade Id, 2026-10-06): open a room
	HideSeekJoin = "Request", -- (room id)
	HideSeekLeave = "Request", -- leave my room (in a game: give up)
	HideSeekReady = "Request", -- (ready boolean)
	HideSeekRecruit = "Request", -- (2026-10-04) 📣 모집: tell everyone else here my waiting room wants players
	HideSeekRadar = "Push", -- (2026-10-04) 📡 ("Seeker", dx, dz, band "Near" | "Mid" | "Far") to the seeker: the nearest
	-- moving hider's way, ("Seeker") when nobody moved; ("Hider", "Caught" | "Moved" | "Still") to the hiders
	HideSeekRadarWarn = "Push",
	HideSeekNearMiss = "Push",
	RoomCallFx = "Push", -- (2026-10-04) a room opened / 📣 모집 notice came: the 🎮 놀이방 corner button flashes (GameRooms)
	HideSeekResult = "Push", -- (2026-10-03) (outcome "Win" | "Lose", why): my game ended; 🏆 승리! / 😢 패배!
	HideSeekTrap = "Request", -- (2026-10-03) 🕸️ put a trap down at my feet (a hider in a game)
	HideSeekDisguise = "Request",
	PromoShot = "Push",
	PromoReviveOffer = "Push",
	PromoReviveNo = "Request",
	PromoReviveFree = "Request",
	CinemaFocus = "Request",
	CinemaFocusAt = "Request",
	WildFeed = "Request",
	WildFed = "Push",
	HideSeekTrapFx = "Push", -- (kind "Set" | "Snap", position, caught userId, owner userId): a trap was put down /
	-- snapped shut on the seeker there (its sound, "🕸️ 철컥!" over it)
	RaceChallenge = "Request", -- (userId): challenge that nearby player to a race
	-- (2026-10-04) 🏁 race rooms (Race service; the 🎮 놀이방 window's 🏁 tab, StarterPlayerScripts/GameRooms)
	RaceRoomCreate = "Request", -- (kind "Road" | "Sky", ranked boolean, stake grade Id): open a race room
	RaceRoomJoin = "Request", -- (room id)
	RaceRoomLeave = "Request", -- leave my race room (racing: as giving up)
	RaceRoomReady = "Request", -- (ready boolean)
	RaceRoomRecruit = "Request", -- (2026-10-04) 📣 모집: tell everyone else here my waiting race room wants players
	RaceMountPick = "Push",
	SetRaceMount = "Request",
	RaceRooms = "Push", -- (rooms): the race room list changed; the window redraws
	GetRaceRooms = "Ask", -- { Rooms, WeekWins (my counted ranked race wins this week) }
	RaceInvite = "Push", -- (userId, name, seconds, kind "Road" | "Sky"): that player challenges me
	SkyRings = "Push", -- ({ Vector3, ... }, ringRadius): my sky race's rings (only I see them; the last, red one wins)
	SkyPads = "Push", -- ({ { Vector3, "Purple" | "Yellow", facing Vector3 }, ... }): my sky race's upright boost pads (RacePadHit dims one)
	RaceAnswer = "Request", -- (userId, accept): answer that player's challenge
	RacePractice = "Request", -- (kind "Road" | "Sky"): race alone on my registered mount, same rules, no record (Race service)
	RaceQuit = "Request", -- give up the race I am in
	RacePads = "Push", -- ({ { x, z, "Purple" | "Yellow" }, ... }): my race's pads (only racers see them)
	RaceObstacles = "Push", -- ({ { x, z, kind, across, along, height, angle, moving }, ... }, mud { { from, to }, ... }): my race's obstacles (only racers)
	RacePadHit = "Push", -- (index): I used that pad
	RaceHit = "Push", -- (kind): a moving obstacle (Swing / Spinner) hit me: bounced back, still riding
	RaceResult = "Push", -- ({ Outcome, Why, Opponent, Seconds, Mine, Theirs, Pads, Hits, Wins, Losses }): my race's result screen
	UnlockStart = "Request",
	UnlockReady = "Push",
	UnlockStarted = "Push",
	UnlockDone = "Push",
	IslandCinematic = "Push",
	KeysBought = "Push",
	KeysTraded = "Push",
}

local FOLDER_NAME = "Remotes"
local IS_SERVER = RunService:IsServer()
local remotes = {}

local function folder()
	if IS_SERVER then
		local f = ReplicatedStorage:FindFirstChild(FOLDER_NAME)
		if not f then
			f = Instance.new("Folder")
			f.Name = FOLDER_NAME
			f.Parent = ReplicatedStorage
		end
		return f
	end
	return ReplicatedStorage:WaitForChild(FOLDER_NAME)
end

local function remote(name)
	local kind = Net.Messages[name]
	assert(kind, "Net: unknown message " .. tostring(name))
	if remotes[name] then
		return remotes[name]
	end
	local f = folder()
	local r
	if IS_SERVER then
		r = f:FindFirstChild(name)
		if not r then
			r = Instance.new(kind == "Ask" and "RemoteFunction" or "RemoteEvent")
			r.Name = name
			r.Parent = f
		end
	else
		r = f:WaitForChild(name)
	end
	remotes[name] = r
	return r
end

-- ---------------------------------------------------------------------------
-- Server side
-- ---------------------------------------------------------------------------

local readyCheck = function()
	return true
end
-- measuring (the Watchdog service sets it): meter(kind, name, seconds) after each handler, and
-- meter("send", name, 0, receivers) for each push
local meter = nil
function Net.setMeter(fn)
	meter = fn
end
local buckets = {} -- [player][name] = { tokens, time }

local function allowRate(player, name)
	local perPlayer = buckets[player]
	if not perPlayer then
		perPlayer = {}
		buckets[player] = perPlayer
	end
	local now = os.clock()
	local limit = Config.Net.Limits[name] -- (the big answers: slower, 2026-10-02)
	local perSecond = limit and limit[1] or Config.Net.RateLimitPerSecond
	local burst = limit and limit[2] or Config.Net.RateLimitBurst
	local b = perPlayer[name]
	if not b then
		b = { tokens = burst, time = now }
		perPlayer[name] = b
	end
	b.tokens = math.min(burst, b.tokens + (now - b.time) * perSecond)
	b.time = now
	if b.tokens < 1 then
		return false
	end
	b.tokens -= 1
	return true
end

-- (2026-10-02) not too big: a string's length, a table's size (plain values only, no tables in it)
local function sizeOk(v)
	local kind = type(v)
	if kind == "string" then
		return #v <= Config.Net.MaxStringLength
	elseif kind == "table" then
		local n = 0
		for _, item in pairs(v) do
			n += 1
			if n > Config.Net.MaxTableItems or type(item) == "table" or (type(item) == "string"
				and #item > Config.Net.MaxStringLength) then
				return false
			end
		end
	end
	return true
end

-- argTypes: a list like { "number", "string" }; "any" skips the type check (never the size check). Extra
-- arguments are rejected.
local function argsOk(argTypes, args)
	if args.n > #argTypes then
		return false
	end
	for i, expected in ipairs(argTypes) do
		local v = args[i]
		if not sizeOk(v) then
			return false
		end
		if expected ~= "any" then
			if typeof(v) ~= expected then
				return false
			end
			if expected == "number" and (v ~= v or v == math.huge or v == -math.huge) then
				return false
			end
		end
	end
	return true
end

local function guard(player, name, argTypes, args)
	if not readyCheck(player) then
		return false, "not ready"
	end
	if not allowRate(player, name) then
		return false, "too many requests"
	end
	if not argsOk(argTypes, args) then
		warn(string.format("[Net] %s sent bad arguments for %s", player.Name, name))
		return false, "bad arguments"
	end
	return true
end

function Net.init()
	assert(IS_SERVER, "Net.init is for the server")
	for name in pairs(Net.Messages) do
		remote(name)
	end
	game:GetService("Players").PlayerRemoving:Connect(function(player)
		buckets[player] = nil
	end)
end

-- fn(player) -> true when the player's data is loaded and requests may run
function Net.setReadyCheck(fn)
	readyCheck = fn
end

function Net.onRequest(name, argTypes, handler)
	assert(IS_SERVER and Net.Messages[name] == "Request", "Net.onRequest: " .. name .. " is not a Request")
	remote(name).OnServerEvent:Connect(function(player, ...)
		local args = table.pack(...)
		if guard(player, name, argTypes, args) then
			local started = os.clock()
			local ok, err = pcall(handler, player, table.unpack(args, 1, args.n))
			if meter then
				meter("handle", name, os.clock() - started)
			end
			if not ok then
				warn(string.format("[Net] %s from %s failed: %s", name, player.Name, tostring(err)))
			end
		end
	end)
end

function Net.onAsk(name, argTypes, handler)
	assert(IS_SERVER and Net.Messages[name] == "Ask", "Net.onAsk: " .. name .. " is not an Ask")
	remote(name).OnServerInvoke = function(player, ...)
		local args = table.pack(...)
		local allowed, reason = guard(player, name, argTypes, args)
		if not allowed then
			return nil, reason
		end
		local started = os.clock()
		local ok, result = pcall(handler, player, table.unpack(args, 1, args.n))
		if meter then
			meter("handle", name, os.clock() - started)
		end
		if not ok then
			warn(string.format("[Net] %s from %s failed: %s", name, player.Name, tostring(result)))
			return nil, "error"
		end
		return result
	end
end

function Net.push(player, name, ...)
	assert(IS_SERVER and Net.Messages[name] == "Push", "Net.push: " .. name .. " is not a Push")
	remote(name):FireClient(player, ...)
	if meter then
		meter("send", name, 0, 1)
	end
end

function Net.pushAll(name, ...)
	assert(IS_SERVER and Net.Messages[name] == "Push", "Net.pushAll: " .. name .. " is not a Push")
	remote(name):FireAllClients(...)
	if meter then
		meter("send", name, 0, #game:GetService("Players"):GetPlayers())
	end
end

-- ---------------------------------------------------------------------------
-- Client side
-- ---------------------------------------------------------------------------

function Net.request(name, ...)
	assert(not IS_SERVER and Net.Messages[name] == "Request", "Net.request: " .. name .. " is not a Request")
	remote(name):FireServer(...)
end

local askReport = { count = 0, total = 0, worst = 0, worstName = nil }

function Net.ask(name, ...)
	assert(not IS_SERVER and Net.Messages[name] == "Ask", "Net.ask: " .. name .. " is not an Ask")
	local started = os.clock()
	local result = table.pack(remote(name):InvokeServer(...))
	local spent = os.clock() - started
	askReport.count += 1
	askReport.total += spent
	if spent > askReport.worst then
		askReport.worst, askReport.worstName = spent, name
	end
	return table.unpack(result, 1, result.n)
end

function Net.takeAskReport()
	local out = askReport
	askReport = { count = 0, total = 0, worst = 0, worstName = nil }
	return out
end

function Net.onPush(name, handler)
	assert(not IS_SERVER and Net.Messages[name] == "Push", "Net.onPush: " .. name .. " is not a Push")
	return remote(name).OnClientEvent:Connect(handler)
end

return Net
