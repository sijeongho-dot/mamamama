local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")

local ShowCrowd = {}

local SHIRTS = { Color3.fromRGB(13, 105, 172), Color3.fromRGB(196, 40, 28), Color3.fromRGB(75, 151, 75),
	Color3.fromRGB(245, 205, 48), Color3.fromRGB(107, 50, 124), Color3.fromRGB(218, 133, 65), Color3.fromRGB(4, 175, 236) }
local PANTS = { Color3.fromRGB(27, 42, 53), Color3.fromRGB(39, 70, 45), Color3.fromRGB(99, 95, 98),
	Color3.fromRGB(33, 84, 185), Color3.fromRGB(91, 93, 105) }
local MOVES = { "cheer", "wave", "dance", "dance2", "dance3", "laugh", "point" }
local ARMS_AND_TORSO = { "Torso", "UpperTorso", "LowerTorso", "Left Arm", "Right Arm", "LeftUpperArm", "LeftLowerArm",
	"RightUpperArm", "RightLowerArm" }
local LEGS = { "Left Leg", "Right Leg", "LeftUpperLeg", "LeftLowerLeg", "LeftFoot", "RightUpperLeg", "RightLowerLeg",
	"RightFoot" }

local function moveIds(character)
	local animate = character:FindFirstChild("Animate")
	local ids = {}
	for _, name in ipairs(MOVES) do
		local folder = animate and animate:FindFirstChild(name)
		local anim = folder and folder:FindFirstChildOfClass("Animation")
		if anim and anim.AnimationId ~= "" then
			table.insert(ids, anim.AnimationId)
		end
	end
	return ids
end

local function ground(x, z, y, ignore)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = ignore
	local hit = Workspace:Raycast(Vector3.new(x, y + 60, z), Vector3.new(0, -160, 0), params)
	return hit and hit.Position.Y or y
end

local function dress(model, rng)
	local shirt = SHIRTS[rng:NextInteger(1, #SHIRTS)]
	local pants = PANTS[rng:NextInteger(1, #PANTS)]
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("Shirt") or d:IsA("Pants") or d:IsA("ShirtGraphic") or d:IsA("BodyColors") then
			d:Destroy()
		elseif d:IsA("Accessory") and rng:NextNumber() < 0.5 then
			d:Destroy()
		end
	end
	for _, name in ipairs(ARMS_AND_TORSO) do
		local part = model:FindFirstChild(name)
		if part and part:IsA("BasePart") then
			part.Color = shirt
		end
	end
	for _, name in ipairs(LEGS) do
		local part = model:FindFirstChild(name)
		if part and part:IsA("BasePart") then
			part.Color = pants
		end
	end
end

function ShowCrowd.spawn(center, lookAt, count, radius, spread)
	local character = Players.LocalPlayer.Character
	if not character or not character:FindFirstChildOfClass("Humanoid") then
		return nil
	end
	local folder = Instance.new("Folder")
	folder.Name = "ShowCrowd"
	folder.Parent = Workspace
	local was = character.Archivable
	character.Archivable = true
	local template = character:Clone()
	character.Archivable = was
	if not template then
		folder:Destroy()
		return nil
	end
	for _, d in ipairs(template:GetDescendants()) do
		if d:IsA("Script") or d:IsA("LocalScript") or d:IsA("BillboardGui") or d:IsA("Highlight") or d:IsA("Tool") then
			d:Destroy()
		elseif d:IsA("BasePart") then
			d.CanCollide, d.CanQuery, d.CanTouch = false, false, false
			d.Anchored = d.Name == "HumanoidRootPart"
			d.LocalTransparencyModifier = 0
		elseif d:IsA("Decal") then
			d.LocalTransparencyModifier = 0
		end
	end
	local ids = moveIds(character)
	local rng = Random.new()
	local away = Vector3.new(center.X - lookAt.X, 0, center.Z - lookAt.Z)
	away = away.Magnitude > 0.1 and away.Unit or Vector3.zAxis
	local side = away:Cross(Vector3.yAxis)
	for i = 1, count do
		local model = template:Clone()
		model.Name = "Fan"
		dress(model, rng)
		local humanoid = model:FindFirstChildOfClass("Humanoid")
		local root = model:FindFirstChild("HumanoidRootPart")
		if humanoid and root then
			humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
			humanoid.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
			local across = ((i - 1) / math.max(1, count - 1) - 0.5) * spread + rng:NextNumber(-1, 1)
			local spot = center + away * (radius + rng:NextNumber(-2, 2)) + side * across
			local y = ground(spot.X, spot.Z, center.Y, { folder, character })
			local hip = humanoid.HipHeight + root.Size.Y / 2
			local at = Vector3.new(spot.X, y + hip, spot.Z)
			model.Parent = folder
			root.CFrame = CFrame.lookAt(at, Vector3.new(lookAt.X, at.Y, lookAt.Z))
			local animator = humanoid:FindFirstChildOfClass("Animator")
			if not animator then
				animator = Instance.new("Animator")
				animator.Parent = humanoid
			end
			if #ids > 0 then
				local anim = Instance.new("Animation")
				anim.AnimationId = ids[(i - 1) % #ids + 1]
				local ok, track = pcall(function()
					return animator:LoadAnimation(anim)
				end)
				if ok and track then
					track.Looped = true
					track:Play(0.2, 1, rng:NextNumber(0.9, 1.15))
				end
			end
		end
	end
	template:Destroy()
	return folder
end

return ShowCrowd
