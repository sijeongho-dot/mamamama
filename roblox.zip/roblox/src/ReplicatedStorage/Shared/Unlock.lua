local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(script.Parent:WaitForChild("Formulas"))

local Unlock = {}

local WATCHED = { "DefenseLevel", "FieldOpen", "OpenArea", "InTutorial" }
for _, u in ipairs(Config.Unlocks) do
	table.insert(WATCHED, "Facility" .. u.Id)
	table.insert(WATCHED, "FacilityWhy" .. u.Id)
end
for _, m in ipairs(Config.StarterMissions.Missions) do
	if m.Show then
		table.insert(WATCHED, "Staged" .. (m.Goal or m.Event))
	end
end

function Unlock.state(id)
	local player = Players.LocalPlayer
	if not player or ReplicatedStorage:GetAttribute("TutorialField") or not Formulas.unlockOf(id) then
		return "Open"
	end
	return player:GetAttribute("Facility" .. id) or "Locked"
end

function Unlock.has(id)
	return Unlock.state(id) == "Open"
end

function Unlock.usable(id)
	local s = Unlock.state(id)
	return s == "Open" or s == "Learning"
end

function Unlock.ready(id)
	return Unlock.state(id) == "Ready"
end

function Unlock.shown(name, who)
	local player = who or Players.LocalPlayer
	local key = Formulas.stageOf(name)
	return not (player and key and player:GetAttribute("Staged" .. key))
end

function Unlock.whyText(u)
	local player = Players.LocalPlayer
	local why = player and player:GetAttribute("FacilityWhy" .. u.Id)
	if why == "Prev" then
		local prev = Config.Unlocks[(Formulas.unlockIndex(u.Id) or 1) - 1]
		return prev and string.format("🔓 먼저 %s 열기", prev.Name) or ""
	elseif why == "Chapter" then
		return string.format("📋 초보 미션 %d장 끝내기", u.After)
	elseif u.Level then
		return string.format("⚔️ 디펜스 %s부터", Formulas.levelText(u.Level))
	end
	return ""
end

function Unlock.watch(fn)
	local player = Players.LocalPlayer
	if not player then
		return
	end
	for _, name in ipairs(WATCHED) do
		player:GetAttributeChangedSignal(name):Connect(fn)
	end
	ReplicatedStorage:GetAttributeChangedSignal("TutorialField"):Connect(fn)
end

function Unlock.nextOne()
	local player = Players.LocalPlayer
	if not player or ReplicatedStorage:GetAttribute("TutorialField") then
		return nil
	end
	for _, u in ipairs(Config.Unlocks) do
		if Unlock.state(u.Id) ~= "Open" then
			return u
		end
	end
	return nil
end

function Unlock.openFrom()
	local player = Players.LocalPlayer
	return player and player:GetAttribute("FieldOpen") or Config.Battlefield.Radius
end

local areaText, areaRects = nil, nil

function Unlock.reachable(position)
	if Formulas.fieldClosed(position, Unlock.openFrom()) then
		return false
	end
	local player = Players.LocalPlayer
	local text = player and not ReplicatedStorage:GetAttribute("TutorialField") and player:GetAttribute("OpenArea")
	if not text then
		return true
	end
	if text ~= areaText then
		areaText, areaRects = text, Formulas.rectsOf(text)
	end
	local map = Workspace:FindFirstChild("Map")
	local base = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	local zone = base and base:FindFirstChild("SafeZone")
	if not areaRects or not zone then
		return true
	end
	local p = zone.CFrame:PointToObjectSpace(position)
	return Formulas.inRects(areaRects, p.X, p.Z)
end

function Unlock.mineable(model)
	local home = model:GetAttribute("Home")
	if home ~= nil then
		local player = Players.LocalPlayer
		return player ~= nil and home == player:GetAttribute("Base")
	end
	return Unlock.reachable(model:GetPivot().Position)
end

function Unlock.ask(id)
	require(script.Parent:WaitForChild("Net")).request("UnlockStart", id)
end

return Unlock
