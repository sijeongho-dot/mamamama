local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))

local Pictures = {}

local DRAW_SCALE = 1.3
local STATUS_REF_HEIGHT = 3
local WEAR_LIFTS = { Kind_Shell = 0.18, Kind_Stone = 0.36, Kind_Frost = 0.388, Kind_Lava = 0.28, Prop_FossilFlag = 0.55,
	Kind_Doll = 0.05, Kind_Sprinter = 0.343 }
local BALLOON_GAP = 1.5
local PLAIN_COLOR = Color3.fromRGB(110, 190, 90)
local BOSS_COLOR = Color3.fromRGB(220, 60, 60)
local FOLDERS = { Dino = "DinoModels", Item = "ItemModels", Key = "KeyModels", Slap = "SlapModels", Fossil = "DefenseModels",
	Tutorial = "TutorialModels" }

local function find(folderName, name)
	local folder = folderName and ReplicatedStorage:FindFirstChild(folderName)
	return folder and name and folder:FindFirstChild(name) or nil
end

local function standing(source)
	local model = Instance.new("Model")
	source:Clone().Parent = model
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
		end
	end
	model.WorldPivot = CFrame.new(model:GetBoundingBox().Position)
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
	model:PivotTo(CFrame.new())
	return model
end

local function paint(model, color)
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Color = color
		end
	end
end

local function wear(model, name, height, color)
	local source = find(FOLDERS.Fossil, name)
	if not source then
		return
	end
	local look = standing(source)
	look:ScaleTo(math.max(height / STATUS_REF_HEIGHT, 0.2))
	look:PivotTo(CFrame.new(0, (WEAR_LIFTS[name] or 0) * height, 0))
	if color then
		paint(look, color)
	end
	look.Parent = model
end

function Pictures.fossil(what)
	local body = find(FOLDERS.Fossil, Config.Monsters.Models[1])
	if not body then
		return nil
	end
	local kind = what and Formulas.fossilKind(what)
	local model = standing(body)
	local biggest, volume = nil, 0
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") and d.Size.X * d.Size.Y * d.Size.Z > volume then
			biggest, volume = d, d.Size.X * d.Size.Y * d.Size.Z
		end
	end
	if biggest then
		biggest.Color = kind and Color3.fromRGB(table.unpack(kind.Rgb)) or what == "Boss" and BOSS_COLOR or PLAIN_COLOR
	end
	if kind and kind.Ghost then
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") then
				d.Transparency = math.max(d.Transparency, kind.Ghost)
			end
		end
	end
	model:ScaleTo(DRAW_SCALE * (kind and kind.Scale or 1))
	local height = select(2, model:GetBoundingBox()).Y
	if kind and kind.Look then
		wear(model, kind.Look, height, kind.LookTint and Color3.fromRGB(table.unpack(kind.Rgb)) or nil)
	end
	if what == "Group" then
		wear(model, Config.Defense.Groups.FlagModel, height)
	end
	local crown = what == "Boss" and find(FOLDERS.Fossil, Config.Monsters.BossCrown)
	if crown then
		local worn = standing(crown)
		worn:PivotTo(CFrame.new(0, height, 0))
		worn.Parent = model
	end
	local balloon = kind and kind.Balloon and find(FOLDERS.Fossil, kind.Balloon)
	if balloon then
		local worn = standing(balloon)
		worn:PivotTo(CFrame.new(0, height + BALLOON_GAP, 0))
		worn.Parent = model
	end
	return model
end

function Pictures.of(spec, size)
	if type(spec) ~= "table" then
		return nil
	end
	local model
	if spec[1] == "Fossil" then
		model = Pictures.fossil(spec[2])
	else
		local source = find(FOLDERS[spec[1]], spec[2])
		model = source and standing(source)
	end
	if not model then
		return nil
	end
	local frame = DinoPortrait.ofModel(model, size, { spin = true })
	model:Destroy()
	return frame
end

return Pictures
