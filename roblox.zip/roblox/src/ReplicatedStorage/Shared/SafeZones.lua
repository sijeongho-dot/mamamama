--[[
SafeZones: where attacks do not count (server and clients use the same check).

Only the battlefield is dangerous: the land inside the orange band and flags around the center
(Config.Battlefield.Radius), with the key zone and the mineral ring. The bases (each base plot's
SafeZone box, Workspace.Map.Base<n>, built by roblox/MapBuilder.lua) and all the land outside the
flags, between and around the bases, are safe; dinos can be ridden there (Ride service).

	SafeZones.baseAt(position) -> base number or nil (inside that base's fence)
	SafeZones.isSafe(position) -> true in a base or outside the battlefield flags
	SafeZones.inSky(player, position) -> true for a player on a flying dino over the battlefield (2026-10-04)
]]

local Workspace = game:GetService("Workspace")

local Config = require(game:GetService("ReplicatedStorage"):WaitForChild("Config"))

local SafeZones = {}

local function inside(zone, position)
	local p = zone.CFrame:PointToObjectSpace(position)
	return math.abs(p.X) <= zone.Size.X / 2 and math.abs(p.Z) <= zone.Size.Z / 2 and math.abs(p.Y) <= zone.Size.Y / 2
end

function SafeZones.baseAt(position)
	local map = Workspace:FindFirstChild("Map")
	if not map then
		return nil
	end
	for index = 1, Config.Map.BaseCount do
		local base = map:FindFirstChild("Base" .. index)
		local zone = base and base:FindFirstChild("SafeZone")
		if zone and inside(zone, position) then
			return index
		end
	end
	return nil
end

function SafeZones.isSafe(position)
	if Vector3.new(position.X, 0, position.Z).Magnitude > Config.Battlefield.Radius then
		return true
	end
	return SafeZones.baseAt(position) ~= nil
end

-- (2026-10-04, "익룡타고 배틀필드도 날아보고 싶은데.. 날기만 … 아무것도 상호작용 안 되게 유저들이랑도 찰싹 상호작용 같은거도
-- 없고") a player riding a flying dino (player attribute Flying, Ride service) over the battlefield is there only to fly
-- and look: nothing on the battlefield hits them, and they slap, throw, mine, open and pick up nothing
function SafeZones.inSky(player, position)
	return player:GetAttribute("Flying") == true and not SafeZones.isSafe(position)
end

return SafeZones
