local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Sfx = require(script.Parent:WaitForChild("Sfx"))

local MeteorShow = {}

local FALL_SECONDS = 3.2
local BOOM_GAIN = 2.1
local FALL_EASE = 1.7
local FROM_BACK, FROM_SIDE, FROM_UP = 300, 90, 340
local SPINS = 2.5
local MODEL_SIZE = 30
local GLOW_SCALE = 1.35
local GLOW_TRANSPARENCY = 0.6
local PURPLE = Color3.fromRGB(170, 90, 255)
local PINK = Color3.fromRGB(255, 200, 255)
local WHITE = Color3.fromRGB(255, 255, 255)
local DARK = Color3.fromRGB(58, 42, 70)
local ROCK = Color3.fromRGB(110, 92, 80)
local CHASE_BACK, CHASE_SIDE, CHASE_UP, CHASE_LEAD = 70, 28, 18, 25
local WATCH_OUT, WATCH_SIDE, WATCH_UP = 90, -35, 34
local WATCH_FROM, WATCH_TO = 0.5, 0.9
local PUSH_IN = 0.18
local PUSH_SECONDS = 6
local SINK = 0.35
local CRATER = 34
local RIM_ROCKS = 12
local DEBRIS = 16
local SHARDS = 14
local GLOW_FADE = 0.5
local DEBRIS_UP = { 40, 75 }
local DEBRIS_OUT = { 20, 55 }
local GRAVITY = 110
local WAVE_SECONDS = 0.9
local WAVE_SIZE = 220
local FLASH_SECONDS = 0.8
local SHAKE_SECONDS = 1.1
local SHAKE_ANGLE = math.rad(2.4)
local WHOOSH_BEFORE = 0.9
local LIGHT_RANGE = 60
local ZINDEX = 25
local GROUND_WIDTH = 40
local GROUND_TRIES = 25
local REFINE_AT = 0.75
local VIEW_TRIES = 16
local VIEW_CHECKS = { { 90, -35, 34 }, { 70, -25, 30 }, { 55, -20, 22 }, { 38, -12, 14 } }
local SEE_THROUGH = 0.5

local function part(props)
	local p = Instance.new("Part")
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch = true, false, false, false
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	for k, v in pairs(props) do
		p[k] = v
	end
	return p
end

local function emitter(parent, props)
	local e = Instance.new("ParticleEmitter")
	e.LightEmission = 0.8
	e.Rate = 0
	for k, v in pairs(props) do
		e[k] = v
	end
	e.Parent = parent
	return e
end

local function smooth(x)
	x = math.clamp(x, 0, 1)
	return x * x * (3 - 2 * x)
end

local function isGround(hit)
	local p = hit.Instance
	if p:IsA("Terrain") then
		return true
	end
	if not p.CanCollide or p.Transparency >= 0.5 then
		return false
	end
	local size = p.Size
	local dims = { size.X, size.Y, size.Z }
	table.sort(dims)
	return dims[2] >= GROUND_WIDTH
end

local function groundY(at, skip)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	local list = { skip }
	for _, p in ipairs(Players:GetPlayers()) do
		table.insert(list, p.Character)
	end
	for _ = 1, GROUND_TRIES do
		params.FilterDescendantsInstances = list
		local hit = Workspace:Raycast(at + Vector3.new(0, 300, 0), Vector3.new(0, -700, 0), params)
		if not hit then
			return at.Y
		end
		if isGround(hit) then
			return hit.Position.Y
		end
		table.insert(list, hit.Instance)
	end
	return at.Y
end

local function starModel(source, folder)
	local star
	if source then
		star = Instance.new("Model")
		source:Clone().Parent = star
		for _, d in ipairs(star:GetDescendants()) do
			if d:IsA("BasePart") then
				d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
			end
		end
		local _, extent = star:GetBoundingBox()
		star:ScaleTo(MODEL_SIZE / math.max(extent.X, extent.Y, extent.Z, 0.1))
	else
		star = Instance.new("Model")
		part({ Shape = Enum.PartType.Ball, Size = Vector3.one * MODEL_SIZE * 0.7, Color = PURPLE,
			Material = Enum.Material.Neon }).Parent = star
	end
	star.Parent = folder
	return star
end

local function clearView(from, to, skip)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	local list = { skip }
	for _, p in ipairs(Players:GetPlayers()) do
		table.insert(list, p.Character)
	end
	for _ = 1, 8 do
		params.FilterDescendantsInstances = list
		local hit = Workspace:Raycast(from, to - from, params)
		if not hit then
			return true
		end
		if hit.Instance:IsA("Terrain") or hit.Instance.Transparency < SEE_THROUGH then
			return false
		end
		table.insert(list, hit.Instance)
	end
	return true
end

local function openSide(impact, toward, skip)
	local start = math.atan2(toward.Z, toward.X)
	local best, bestScore = nil, -1
	for i = 0, VIEW_TRIES - 1 do
		local a = start + i / VIEW_TRIES * 2 * math.pi
		local out = Vector3.new(math.cos(a), 0, math.sin(a))
		local side = out:Cross(Vector3.yAxis)
		local look = impact + Vector3.yAxis * 4
		local score = 0
		for _, v in ipairs(VIEW_CHECKS) do
			if clearView(look, impact + out * v[1] + side * v[2] + Vector3.yAxis * v[3], skip) then
				score += 1
			end
		end
		if score > bestScore then
			best, bestScore = out, score
		end
	end
	return best
end

function MeteorShow.play(parentGui, source, impact, toward)
	local camera = Workspace.CurrentCamera
	local folder = Instance.new("Folder")
	folder.Name = "IntroMeteor"
	folder.Parent = Workspace
	task.spawn(pcall, function()
		Players.LocalPlayer:RequestStreamAroundAsync(impact)
	end)
	impact = Vector3.new(impact.X, groundY(impact, folder), impact.Z)
	local out = Vector3.new(toward.X, 0, toward.Z)
	out = openSide(impact, out.Magnitude > 0.01 and out.Unit or Vector3.xAxis, folder)
	folder:SetAttribute("Out", out)
	local side = out:Cross(Vector3.yAxis)
	local up = Vector3.yAxis
	local from = impact - out * FROM_BACK + side * FROM_SIDE + up * FROM_UP
	local v = (impact - from).Unit

	local star = starModel(source, folder)
	local glow = part({ Shape = Enum.PartType.Ball, Size = Vector3.one * MODEL_SIZE * GLOW_SCALE, Color = PURPLE,
		Material = Enum.Material.Neon, Transparency = GLOW_TRANSPARENCY, CastShadow = false })
	glow.Parent = folder
	local light = Instance.new("PointLight")
	light.Color, light.Range, light.Brightness = PURPLE, LIGHT_RANGE, 4
	light.Parent = glow
	local tail = Instance.new("Attachment")
	tail.Parent = glow
	emitter(tail, { Rate = 220, Color = ColorSequence.new(PURPLE, PINK), Lifetime = NumberRange.new(0.7, 1.1),
		Size = NumberSequence.new(MODEL_SIZE * 0.35, 0), Speed = NumberRange.new(0, 2),
		Transparency = NumberSequence.new(0.1, 1), SpreadAngle = Vector2.new(25, 25) })
	emitter(tail, { Rate = 120, Color = ColorSequence.new(WHITE), Lifetime = NumberRange.new(0.4, 0.8),
		Size = NumberSequence.new(MODEL_SIZE * 0.18, 0), Speed = NumberRange.new(4, 10), LightEmission = 1,
		SpreadAngle = Vector2.new(180, 180) })

	local flash = Instance.new("Frame")
	flash.Size = UDim2.fromScale(1, 1)
	flash.BackgroundColor3 = PINK
	flash.BackgroundTransparency = 1
	flash.BorderSizePixel = 0
	flash.ZIndex = ZINDEX
	flash.Parent = parentGui
	folder.Destroying:Connect(function()
		flash:Destroy()
	end)

	local watchEye = impact + out * WATCH_OUT + side * WATCH_SIDE + up * WATCH_UP
	local watchLook = impact + up * 6
	local debris = {}
	local landedAt = nil
	local refined = false
	local t0 = os.clock()
	local name = "MeteorShow" .. tostring(t0)

	Sfx.play("WindGust", nil, 0.6, 2.5)
	task.delay(FALL_SECONDS - WHOOSH_BEFORE, function()
		if folder.Parent then
			Sfx.play("FireWhoosh", nil, 0.5, 3)
		end
	end)

	local function land()
		landedAt = os.clock()
		folder:SetAttribute("Impact", impact)
		star:Destroy()
		glow.CFrame = CFrame.new(impact + up * MODEL_SIZE * SINK)
		tail:ClearAllChildren()
		TweenService:Create(glow, TweenInfo.new(GLOW_FADE, Enum.EasingStyle.Quad),
			{ Size = Vector3.one * MODEL_SIZE * GLOW_SCALE * 2, Transparency = 1 }):Play()
		Sfx.play("BombBoom", nil, 0.45, BOOM_GAIN)
		Sfx.play("Thunder", nil, 0.8, 2)
		flash.BackgroundTransparency = 0
		TweenService:Create(flash, TweenInfo.new(FLASH_SECONDS, Enum.EasingStyle.Quad), { BackgroundTransparency = 1 }):Play()
		local flat = CFrame.new(impact) * CFrame.Angles(0, 0, math.pi / 2)
		local crater = part({ Shape = Enum.PartType.Cylinder, Size = Vector3.new(0.6, 2, 2), Color = DARK,
			Material = Enum.Material.Slate, CFrame = flat + up * 0.15 })
		crater.Parent = folder
		TweenService:Create(crater, TweenInfo.new(0.35, Enum.EasingStyle.Quad), { Size = Vector3.new(0.6, CRATER, CRATER) }):Play()
		local pool = part({ Shape = Enum.PartType.Cylinder, Size = Vector3.new(0.3, CRATER * 0.7, CRATER * 0.7), Color = PURPLE,
			Material = Enum.Material.Neon, Transparency = 0.45, CFrame = flat + up * 0.35, CastShadow = false })
		pool.Parent = folder
		light.Parent = pool
		TweenService:Create(pool, TweenInfo.new(1.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
			{ Transparency = 0.8 }):Play()
		for i = 1, RIM_ROCKS do
			local a = i / RIM_ROCKS * 2 * math.pi + math.random() * 0.3
			local size = Vector3.new(4 + math.random() * 4, 3 + math.random() * 4, 4 + math.random() * 4)
			local at = impact + Vector3.new(math.cos(a), 0, math.sin(a)) * CRATER * 0.5
			local rock = part({ Size = size, Color = ROCK, Material = Enum.Material.Slate,
				CFrame = CFrame.new(at - up * size.Y) * CFrame.Angles(math.random() * 0.6, a, math.random() * 0.6) })
			rock.Parent = folder
			TweenService:Create(rock, TweenInfo.new(0.3, Enum.EasingStyle.Back), { CFrame = rock.CFrame + up * size.Y * 0.8 }):Play()
		end
		local wave = part({ Shape = Enum.PartType.Cylinder, Size = Vector3.new(0.4, 4, 4), Color = PURPLE,
			Material = Enum.Material.Neon, Transparency = 0.15, CFrame = flat + up * 0.6, CastShadow = false })
		wave.Parent = folder
		TweenService:Create(wave, TweenInfo.new(WAVE_SECONDS, Enum.EasingStyle.Quad),
			{ Size = Vector3.new(0.4, WAVE_SIZE, WAVE_SIZE), Transparency = 1 }):Play()
		local burst = Instance.new("Attachment")
		burst.WorldPosition = impact + up * 2
		burst.Parent = Workspace.Terrain
		folder.Destroying:Connect(function()
			burst:Destroy()
		end)
		local dust = emitter(burst, { Color = ColorSequence.new(Color3.fromRGB(150, 120, 110), Color3.fromRGB(120, 80, 150)),
			Lifetime = NumberRange.new(1.6, 2.6), Size = NumberSequence.new(8, 18), Speed = NumberRange.new(25, 55),
			Transparency = NumberSequence.new(0.2, 1), SpreadAngle = Vector2.new(75, 75), Drag = 2.5, LightEmission = 0,
			Acceleration = Vector3.new(0, -6, 0), EmissionDirection = Enum.NormalId.Top })
		dust:Emit(45)
		local sparks = emitter(burst, { Color = ColorSequence.new(PURPLE, WHITE), Lifetime = NumberRange.new(0.8, 1.6),
			Size = NumberSequence.new(1.6, 0), Speed = NumberRange.new(50, 95), LightEmission = 1, Drag = 1.5,
			SpreadAngle = Vector2.new(70, 70), Acceleration = Vector3.new(0, -40, 0), EmissionDirection = Enum.NormalId.Top })
		sparks:Emit(90)
		emitter(burst, { Rate = 18, Color = ColorSequence.new(PURPLE, PINK), Lifetime = NumberRange.new(1.5, 2.5),
			Size = NumberSequence.new(1.2, 0), Speed = NumberRange.new(3, 8), LightEmission = 1,
			SpreadAngle = Vector2.new(40, 40), EmissionDirection = Enum.NormalId.Top })
		for i = 1, DEBRIS + SHARDS do
			local shard = i > DEBRIS
			local a = math.random() * 2 * math.pi
			local dir = Vector3.new(math.cos(a), 0, math.sin(a))
			local size = shard and Vector3.new(1, 3 + math.random() * 3, 1) or Vector3.one * (1.5 + math.random() * 2.5)
			local rock = part({ Size = size, Color = shard and (math.random() < 0.5 and PURPLE or PINK) or ROCK,
				Material = shard and Enum.Material.Neon or Enum.Material.Slate, CFrame = CFrame.new(impact + up * 2) })
			rock.Parent = folder
			table.insert(debris, { part = rock, at = impact + up * 2,
				vel = dir * math.random(DEBRIS_OUT[1], DEBRIS_OUT[2]) + up * math.random(DEBRIS_UP[1], DEBRIS_UP[2]),
				spin = CFrame.Angles(math.random() * 0.3, math.random() * 0.3, math.random() * 0.3) })
		end
	end

	RunService:BindToRenderStep(name, Enum.RenderPriority.Camera.Value + 3, function(dt)
		if not folder.Parent or folder:GetAttribute("Drive") == false then
			RunService:UnbindFromRenderStep(name)
			return
		end
		local now = os.clock()
		local q = math.min(1, (now - t0) / FALL_SECONDS)
		local eye, look
		if not landedAt and not refined and q >= REFINE_AT then
			refined = true
			impact = Vector3.new(impact.X, groundY(impact, folder), impact.Z)
			watchEye = impact + out * WATCH_OUT + side * WATCH_SIDE + up * WATCH_UP
			watchLook = impact + up * 6
		end
		if not landedAt then
			local pos = from:Lerp(impact, q ^ FALL_EASE)
			star:PivotTo(CFrame.new(pos) * CFrame.Angles(q * SPINS * math.pi, q * SPINS * 2 * math.pi, 0))
			glow.CFrame = CFrame.new(pos)
			local w = smooth((q - WATCH_FROM) / (WATCH_TO - WATCH_FROM))
			eye = (pos - v * CHASE_BACK + side * CHASE_SIDE + up * CHASE_UP):Lerp(watchEye, w)
			look = (pos + v * CHASE_LEAD):Lerp(watchLook, w)
			if q >= 1 then
				land()
			end
		else
			local after = now - landedAt
			eye = watchEye:Lerp(watchLook, PUSH_IN * smooth(after / PUSH_SECONDS))
			look = watchLook
			light.Brightness = 3 + math.sin(after * 4)
		end
		local cf = CFrame.lookAt(eye, look)
		if landedAt then
			local left = 1 - (now - landedAt) / SHAKE_SECONDS
			if left > 0 then
				local a = SHAKE_ANGLE * left
				cf *= CFrame.Angles((math.random() * 2 - 1) * a, (math.random() * 2 - 1) * a, (math.random() * 2 - 1) * a * 0.5)
			end
		end
		camera.CFrame = cf
		for i = #debris, 1, -1 do
			local d = debris[i]
			d.vel -= up * GRAVITY * dt
			d.at += d.vel * dt
			if d.at.Y <= impact.Y + d.part.Size.Y / 2 and d.vel.Y < 0 then
				d.part.CFrame = CFrame.new(d.at.X, impact.Y + d.part.Size.Y / 2, d.at.Z) * d.part.CFrame.Rotation
				table.remove(debris, i)
			else
				d.part.CFrame = (CFrame.new(d.at) * d.part.CFrame.Rotation) * d.spin
			end
		end
	end)
	return folder
end

return MeteorShow
