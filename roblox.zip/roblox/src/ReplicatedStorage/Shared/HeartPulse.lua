local TweenService = game:GetService("TweenService")

local Sfx = require(script.Parent:WaitForChild("Sfx"))

local RANGE = 90
local SLOW = 1.1
local FAST = 0.38
local QUIET, LOUD = 0.5, 1.6
local PITCH = 0.12
local POP_SECONDS = 0.3

local HeartPulse = {}

function HeartPulse.nearness(distance)
	if distance == nil or distance >= RANGE then
		return nil
	end
	return 1 - distance / RANGE
end

function HeartPulse.beater(scale, pop)
	local lastBeat = -math.huge
	return function(near)
		local every = near and SLOW + (FAST - SLOW) * near
		if not every or os.clock() - lastBeat < every then
			return
		end
		lastBeat = os.clock()
		Sfx.play("HeartThump", nil, 1 + PITCH * near, QUIET + (LOUD - QUIET) * near)
		scale.Scale = pop
		TweenService:Create(scale, TweenInfo.new(math.min(POP_SECONDS, every * 0.6)), { Scale = 1 }):Play()
	end
end

return HeartPulse
