--[[
FrameMeter (2026-10-04, "버벅임이 좀 있는거 같은데"): how long each screen script's per-frame work takes on this
screen, so a slow phone names what makes it stutter (the server's own is Watchdog's "server is slow" banner).
Display only.

	FrameMeter.wrap(name, fn)   -- fn timed under name (every RunService connection of the screen scripts goes
	                            -- through it: Heartbeat, RenderStepped, Stepped, BindToRenderStep)
	FrameMeter.take()           -- { [name] = seconds } since the last take, and empties it
	FrameMeter.frame()          -- { [name] = seconds } in the frame now ending, and empties it (the hitch's cause)

StarterPlayerScripts/PerfCheck shows it when the screen gets slow.
]]

local FrameMeter = {}

local total = {} -- [name] = seconds since the last take
local thisFrame = {} -- [name] = seconds this frame
local reportTotal = {}
local reportFrame = {}

function FrameMeter.wrap(name, fn)
	return function(...)
		local started = os.clock()
		fn(...)
		local spent = os.clock() - started
		total[name] = (total[name] or 0) + spent
		thisFrame[name] = (thisFrame[name] or 0) + spent
		reportTotal[name] = (reportTotal[name] or 0) + spent
		reportFrame[name] = (reportFrame[name] or 0) + spent
	end
end

function FrameMeter.take()
	local out = total
	total = {}
	return out
end

function FrameMeter.frame()
	local out = thisFrame
	thisFrame = {}
	return out
end

function FrameMeter.takeReport()
	local out = reportTotal
	reportTotal = {}
	return out
end

function FrameMeter.frameReport()
	local out = reportFrame
	reportFrame = {}
	return out
end

return FrameMeter
