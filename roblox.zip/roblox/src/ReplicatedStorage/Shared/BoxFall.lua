local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Shared = script.Parent
local Fx = require(Shared:WaitForChild("Fx"))
local Sfx = require(Shared:WaitForChild("Sfx"))

local BoxFall = {}

local FALL_SECONDS = 1.4
local FALL_EASE = 1.8
local ARC_SIDE = 0.12
local SPIN = math.rad(300)
local TILT, TILT_SPEEDS = math.rad(14), { 9, 7 }
local TRAIL_EVERY = 0.07
local TRAIL_COLORS = { Color3.fromRGB(190, 120, 255), Color3.fromRGB(255, 210, 255), Color3.fromRGB(255, 255, 255) }
local TRAIL = { count = 6, speed = 1, size = 0.25, life = 0.6 }
local DUST_COLORS = { Color3.fromRGB(215, 195, 160), Color3.fromRGB(255, 255, 255) }
local DUST = { count = 24, speed = 3, size = 0.5, life = 0.8 }
local BOUNCE_SECONDS, BOUNCE_UP = 0.3, 0.25
local MAX_FALLS = 16
local BOX_BODY, BOX_LID, BOX_LID_WIDER, BOX_RIBBON, RIBBON_OVER = 0.78, 0.22, 1.08, 0.22, 0.1
local LID_DARKEN = 0.25
local RIBBON_COLOR = Color3.fromRGB(255, 240, 120)

local active = 0

local function quiet(model)
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
			d.LocalTransparencyModifier = 0
		elseif d:IsA("BillboardGui") or d:IsA("Light") or d:IsA("Sparkles") or d:IsA("ParticleEmitter") then
			d:Destroy()
		end
	end
end

local function part(model, size, cf, color)
	local p = Instance.new("Part")
	p.Size, p.CFrame, p.Color = size, cf, color
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Parent = model
	return p
end

function BoxFall.box(color, edge)
	local model = Instance.new("Model")
	model.Name = "GiftBox"
	local body, lid = edge * BOX_BODY, edge * BOX_LID
	local h = body + lid
	local wide = edge * BOX_LID_WIDER
	part(model, Vector3.new(edge, body, edge), CFrame.new(0, body / 2, 0), color)
	part(model, Vector3.new(wide, lid, wide), CFrame.new(0, body + lid / 2, 0), color:Lerp(Color3.new(), LID_DARKEN))
	part(model, Vector3.new(wide + RIBBON_OVER, h + RIBBON_OVER, edge * BOX_RIBBON), CFrame.new(0, h / 2, 0), RIBBON_COLOR)
	part(model, Vector3.new(edge * BOX_RIBBON, h + RIBBON_OVER, wide + RIBBON_OVER), CFrame.new(0, h / 2, 0), RIBBON_COLOR)
	quiet(model)
	model.WorldPivot = CFrame.new()
	return model
end

local function puff(at, colors, look, edge)
	Fx.burst(at, colors, look.count, look.speed * edge, look.size * edge, look.life)
end

function BoxFall.fall(source, land, from, onLanded)
	if active >= MAX_FALLS then
		if onLanded then
			onLanded()
		end
		return nil
	end
	active += 1
	local box = source:Clone()
	quiet(box)
	local _, size = box:GetBoundingBox()
	local edge, height = math.max(size.X, size.Z), size.Y
	box:PivotTo(CFrame.new(from))
	box.Parent = Workspace
	local flat = Vector3.new(land.Position.X - from.X, 0, land.Position.Z - from.Z)
	local ahead = flat.Magnitude > 0.1 and flat.Unit or Vector3.zAxis
	local side = ahead:Cross(Vector3.yAxis)
	local reach = (land.Position - from).Magnitude
	local turnTo = CFrame.lookAt(Vector3.zero, ahead)
	local t0, lastTrail, falling = os.clock(), 0, true
	local connection
	connection = RunService.RenderStepped:Connect(function()
		local t = os.clock() - t0
		if falling then
			local q = math.min(1, t / FALL_SECONDS)
			local k = q ^ FALL_EASE
			local pos = from:Lerp(land.Position, k) + side * math.sin(math.pi * q) * reach * ARC_SIDE
			local tumble = CFrame.Angles(0, SPIN * (1 - k), 0)
				* CFrame.Angles(TILT * math.sin(t * TILT_SPEEDS[1]), 0, TILT * math.cos(t * TILT_SPEEDS[2]))
			box:PivotTo(land.Rotation:Lerp((turnTo * tumble).Rotation, 1 - k) + pos)
			if t - lastTrail >= TRAIL_EVERY then
				lastTrail = t
				puff(pos + Vector3.new(0, height / 2, 0), TRAIL_COLORS, TRAIL, edge)
			end
			if q >= 1 then
				falling, t0 = false, os.clock()
				puff(land.Position, DUST_COLORS, DUST, edge)
				Sfx.play("FruitThud", land.Position)
			end
			return
		end
		local bounce = math.sin(math.pi * math.min(1, t / BOUNCE_SECONDS)) * BOUNCE_UP * edge
		box:PivotTo(land + Vector3.new(0, bounce, 0))
		if t >= BOUNCE_SECONDS then
			connection:Disconnect()
			if onLanded then
				onLanded()
			end
			box:Destroy()
			active -= 1
		end
	end)
	return box
end

return BoxFall
