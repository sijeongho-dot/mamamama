--[[
GachaFx: the unique rarities' reveal in the draw (display only; StarterPlayerScripts/Gacha). Legendary
and up each have their own show, bigger and longer the rarer:

	GachaFx.has(rarityId)                         -- does this rarity have a show?
	GachaFx.suspense(rarityId, color)             -- yields: the wait before the card (a glowing orb
	                                                 pulling sparkles in, a drumroll), from Mythic up
	GachaFx.burst(rarityId, color, shakeTarget)   -- the reveal, does not yield: a flash, spinning light
	                                                 rays, flying emoji, and per rarity a dark sky with
	                                                 lightning, a halo ring, a light pillar, rainbow
	                                                 colors or a shaking window; and its sound

Sounds (Shared/Sfx, made by tools/make_sounds.py): GachaSuspense before, then GachaLegend /
GachaRainbow / GachaDark / GachaHeaven / GachaCosmic by band. Everything is drawn on its own screen
over the windows and cleans itself up.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(script.Parent:WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TweenService = game:GetService("TweenService")

local Sfx = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Sfx"))

local GachaFx = {}

-- display only. Per rarity: Sound (the reveal), Suspense (seconds of the wait before the card; none
-- below Mythic), Rays (spinning light rays), Particles / Extra = { emoji, how many, "burst" | "rise" |
-- "fall" }, Dim (how dark the screen goes), Lightning (flashes), Halo, Pillar, RainbowRays,
-- RainbowParticles, Shake (pixels the results window shakes), Life (seconds the show lasts)
local FX = {
	Legendary = { Sound = "GachaLegend", Rays = 8, Particles = { "✨", 14, "burst" }, Life = 1.6 },
	Mythic = { Sound = "GachaLegend", Suspense = 0.7, Rays = 10, Particles = { "🔥", 16, "rise" }, Life = 1.8 },
	Transcendent = { Sound = "GachaLegend", Suspense = 0.8, Rays = 12, Particles = { "🌸", 18, "fall" }, Life = 2.0 },
	Rainbow = { Sound = "GachaRainbow", Suspense = 0.9, Rays = 12, RainbowRays = true, Particles = { "★", 22, "burst" },
		RainbowParticles = true, Life = 2.2 },
	Golden = { Sound = "GachaRainbow", Suspense = 1.0, Rays = 14, Particles = { "💰", 26, "fall" }, Extra = { "✨", 10, "burst" },
		Life = 2.3 },
	Onyx = { Sound = "GachaDark", Suspense = 1.1, Dim = 0.55, Lightning = 4, Rays = 8, Particles = { "⚡", 12, "burst" },
		Shake = 6, Life = 2.5 },
	Celestial = { Sound = "GachaHeaven", Suspense = 1.2, Halo = true, Pillar = true, Rays = 16, Particles = { "⭐", 24, "fall" },
		Life = 2.7 },
	Secret = { Sound = "GachaHeaven", Suspense = 1.4, Halo = true, Pillar = true, RainbowRays = true, Rays = 18,
		Particles = { "🌟", 30, "burst" }, Extra = { "💎", 8, "fall" }, Shake = 8, Life = 3.0 },
	Cosmic = { Sound = "GachaCosmic", Suspense = 1.5, Dim = 0.6, Halo = true, Rays = 18, Particles = { "🪐", 8, "burst" },
		Extra = { "✦", 28, "burst" }, Shake = 8, Life = 3.2 },
	Primeval = { Sound = "GachaCosmic", Suspense = 1.6, Pillar = true, Rays = 18, Particles = { "🔥", 30, "rise" },
		Extra = { "✨", 16, "burst" }, Shake = 10, Life = 3.3 },
	Divine = { Sound = "GachaCosmic", Suspense = 1.8, Halo = true, Pillar = true, RainbowRays = true, Rays = 24,
		Particles = { "👑", 6, "burst" }, Extra = { "✨", 32, "fall" }, RainbowParticles = true, Shake = 12, Life = 3.6 },
}
local FLASH_START = 0.25 -- the flash's transparency at its brightest
local FLASH_SECONDS = 0.6
local RAY_WIDTH = 16
local RAY_START = 0.45 -- the rays' transparency at their brightest
local RAY_SPIN = 25 -- degrees a second
local PARTICLE_SIZE = { 26, 42 } -- pixels, smallest and biggest
local PARTICLE_SECONDS = { 1.0, 1.8 }
local ORB_SIZE = 46
local ORB_GROW = 1.6 -- how much bigger the orb gets by the end of the wait
local ORB_PULSE = 9 -- pulses a second
local SUCK_EVERY = 0.06 -- seconds between sparkles pulled into the orb
local HALO_FROM, HALO_TO = 60, 460 -- pixels
local HALO_STROKE = 7
local PILLAR_WIDTH = 140
local LIGHTNING_FLASH = 0.06 -- seconds a lightning flash lasts
local SHAKE_SECONDS = 0.6
local SHAKE_HZ = 30

local player = Players.LocalPlayer
local gui = nil

local function screen()
	if gui and gui.Parent then
		return gui
	end
	gui = Instance.new("ScreenGui")
	gui.Name = "GachaFx"
	gui.ResetOnSpawn = false
	gui.IgnoreGuiInset = true
	gui.DisplayOrder = 26 -- over the windows and the notices
	gui.Parent = player:WaitForChild("PlayerGui")
	return gui
end

local function tween(object, seconds, goal, style, direction)
	local t = TweenService:Create(object, TweenInfo.new(seconds, style or Enum.EasingStyle.Quad,
		direction or Enum.EasingDirection.Out), goal)
	t:Play()
	return t
end

local function full(parent, color, transparency)
	local f = Instance.new("Frame")
	f.Size = UDim2.fromScale(1, 1)
	f.BorderSizePixel = 0
	f.BackgroundColor3 = color
	f.BackgroundTransparency = transparency
	f.Parent = parent
	return f
end

local function circle(parent, size, color)
	local c = Instance.new("Frame")
	c.AnchorPoint = Vector2.new(0.5, 0.5)
	c.Position = UDim2.fromScale(0.5, 0.5)
	c.Size = UDim2.fromOffset(size, size)
	c.BorderSizePixel = 0
	c.BackgroundColor3 = color
	c.Parent = parent
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0.5, 0)
	corner.Parent = c
	return c
end

local function hue(t)
	return Color3.fromHSV(t % 1, 0.75, 1)
end

-- an emoji flying: "burst" out of the middle, "rise" up from below, "fall" down from above
local function particle(parent, emoji, motion, color, rainbow)
	local l = Instance.new("TextLabel")
	local size = math.random(PARTICLE_SIZE[1], PARTICLE_SIZE[2])
	l.AnchorPoint = Vector2.new(0.5, 0.5)
	l.Size = UDim2.fromOffset(size, size)
	l.BackgroundTransparency = 1
	l.Text = emoji
	l.TextScaled = true
	l.Font = Enum.Font.GothamBold
	l.TextColor3 = rainbow and hue(math.random()) or color
	l.Rotation = math.random(-30, 30)
	local from, to
	if motion == "rise" then
		local x = math.random() * 0.8 + 0.1
		from, to = UDim2.fromScale(x, 1.05), UDim2.fromScale(x + (math.random() - 0.5) * 0.2, math.random() * 0.4)
	elseif motion == "fall" then
		local x = math.random()
		from, to = UDim2.fromScale(x, -0.05), UDim2.fromScale(x + (math.random() - 0.5) * 0.15, 0.7 + math.random() * 0.4)
	else
		local angle = math.random() * math.pi * 2
		local reach = 0.25 + math.random() * 0.35
		from = UDim2.fromScale(0.5, 0.5)
		to = UDim2.fromScale(0.5 + math.cos(angle) * reach, 0.5 + math.sin(angle) * reach * 1.4)
	end
	l.Position = from
	l.Parent = parent
	local seconds = PARTICLE_SECONDS[1] + math.random() * (PARTICLE_SECONDS[2] - PARTICLE_SECONDS[1])
	local delay = motion == "burst" and 0 or math.random() * 0.5
	task.delay(delay, function()
		if l.Parent then
			tween(l, seconds, { Position = to, Rotation = l.Rotation + math.random(-120, 120) })
			tween(l, seconds, { TextTransparency = 1 }, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		end
	end)
end

function GachaFx.has(rarityId)
	return FX[rarityId] ~= nil
end

-- the wait before a unique card: an orb in the middle pulsing brighter and bigger, sparkles pulled in
function GachaFx.suspense(rarityId, color)
	local fx = FX[rarityId]
	if not fx or not fx.Suspense then
		return
	end
	local layer = Instance.new("Frame")
	layer.Size = UDim2.fromScale(1, 1)
	layer.BackgroundTransparency = 1
	layer.Parent = screen()
	local orb = circle(layer, ORB_SIZE, Color3.new(1, 1, 1))
	local scale = Instance.new("UIScale")
	scale.Parent = orb
	Sfx.play("GachaSuspense")
	local start = os.clock()
	local nextSuck = 0
	while os.clock() - start < fx.Suspense do
		local k = (os.clock() - start) / fx.Suspense
		scale.Scale = (1 + (ORB_GROW - 1) * k) * (1 + 0.12 * math.sin((os.clock() - start) * ORB_PULSE * math.pi * 2))
		orb.BackgroundColor3 = Color3.new(1, 1, 1):Lerp(color, k)
		if os.clock() >= nextSuck then -- a sparkle from the edge into the orb
			nextSuck = os.clock() + SUCK_EVERY
			local s = Instance.new("TextLabel")
			local angle = math.random() * math.pi * 2
			s.AnchorPoint = Vector2.new(0.5, 0.5)
			s.Size = UDim2.fromOffset(20, 20)
			s.BackgroundTransparency = 1
			s.Text = "✦"
			s.TextScaled = true
			s.TextColor3 = color
			s.Position = UDim2.fromScale(0.5 + math.cos(angle) * 0.45, 0.5 + math.sin(angle) * 0.6)
			s.Parent = layer
			tween(s, 0.35, { Position = UDim2.fromScale(0.5, 0.5), TextTransparency = 0.6 }, Enum.EasingStyle.Quad,
				Enum.EasingDirection.In)
			task.delay(0.36, function()
				s:Destroy()
			end)
		end
		RunService.RenderStepped:Wait()
	end
	tween(orb, 0.15, { Size = UDim2.fromOffset(ORB_SIZE * 8, ORB_SIZE * 8), BackgroundTransparency = 1 })
	task.delay(0.2, function()
		layer:Destroy()
	end)
end

local function shake(target, pixels)
	if not target or not target.Parent then
		return
	end
	local home = target.Position
	local start = os.clock()
	task.spawn(function()
		while os.clock() - start < SHAKE_SECONDS and target.Parent do
			local fade = 1 - (os.clock() - start) / SHAKE_SECONDS
			target.Position = home + UDim2.fromOffset(math.random(-pixels, pixels) * fade, math.random(-pixels, pixels) * fade)
			task.wait(1 / SHAKE_HZ)
		end
		target.Position = home
	end)
end

-- the reveal: does not yield; everything goes away after the rarity's Life seconds
function GachaFx.burst(rarityId, color, shakeTarget)
	local fx = FX[rarityId]
	if not fx then
		return
	end
	local layer = Instance.new("Frame")
	layer.Size = UDim2.fromScale(1, 1)
	layer.BackgroundTransparency = 1
	layer.ClipsDescendants = true
	layer.Parent = screen()
	Sfx.play(fx.Sound)

	if fx.Dim then -- the sky goes dark
		local dim = full(layer, Color3.new(0, 0, 0), 1)
		tween(dim, 0.25, { BackgroundTransparency = 1 - fx.Dim })
		task.delay(fx.Life - 0.5, function()
			if dim.Parent then
				tween(dim, 0.5, { BackgroundTransparency = 1 })
			end
		end)
	end
	local flash = full(layer, color:Lerp(Color3.new(1, 1, 1), 0.5), FLASH_START)
	tween(flash, FLASH_SECONDS, { BackgroundTransparency = 1 })

	-- light rays through the middle, spinning
	local rays = {}
	local length = math.max(layer.AbsoluteSize.X, layer.AbsoluteSize.Y) * 1.5
	for i = 1, math.ceil((fx.Rays or 0) / 2) do
		local ray = Instance.new("Frame")
		ray.AnchorPoint = Vector2.new(0.5, 0.5)
		ray.Position = UDim2.fromScale(0.5, 0.5)
		ray.Size = UDim2.fromOffset(RAY_WIDTH, length)
		ray.BorderSizePixel = 0
		ray.BackgroundColor3 = fx.RainbowRays and hue(i / fx.Rays) or color
		ray.BackgroundTransparency = RAY_START
		ray.Rotation = (i - 1) * 360 / fx.Rays
		local gradient = Instance.new("UIGradient")
		gradient.Rotation = 90
		gradient.Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0), NumberSequenceKeypoint.new(1, 1) })
		gradient.Parent = ray
		ray.Parent = layer
		table.insert(rays, { frame = ray, base = ray.Rotation, index = i })
		tween(ray, fx.Life, { BackgroundTransparency = 1 }, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	end
	local start = os.clock()
	local conn = RunService.RenderStepped:Connect(FrameMeter.wrap("GachaFx", function()
		local t = os.clock() - start
		for _, r in ipairs(rays) do
			r.frame.Rotation = r.base + t * RAY_SPIN
			if fx.RainbowRays then
				r.frame.BackgroundColor3 = hue(r.index / #rays / 2 + t * 0.5)
			end
		end
	end))

	if fx.Halo then -- a ring of light opening out
		local halo = circle(layer, HALO_FROM, color)
		halo.BackgroundTransparency = 1
		local stroke = Instance.new("UIStroke")
		stroke.Thickness = HALO_STROKE
		stroke.Color = color:Lerp(Color3.new(1, 1, 1), 0.4)
		stroke.Parent = halo
		tween(halo, fx.Life * 0.6, { Size = UDim2.fromOffset(HALO_TO, HALO_TO) })
		tween(stroke, fx.Life * 0.6, { Transparency = 1 })
	end
	if fx.Pillar then -- a column of light from top to bottom
		local pillar = Instance.new("Frame")
		pillar.AnchorPoint = Vector2.new(0.5, 0.5)
		pillar.Position = UDim2.fromScale(0.5, 0.5)
		pillar.Size = UDim2.new(0, PILLAR_WIDTH * 0.2, 1, 0)
		pillar.BorderSizePixel = 0
		pillar.BackgroundColor3 = color:Lerp(Color3.new(1, 1, 1), 0.6)
		pillar.BackgroundTransparency = 0.3
		local gradient = Instance.new("UIGradient")
		gradient.Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0), NumberSequenceKeypoint.new(1, 1) })
		gradient.Parent = pillar
		pillar.Parent = layer
		tween(pillar, 0.4, { Size = UDim2.new(0, PILLAR_WIDTH, 1, 0) }, Enum.EasingStyle.Back)
		tween(pillar, fx.Life, { BackgroundTransparency = 1 }, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	end
	if fx.Lightning then -- white flashes and bolts here and there
		task.spawn(function()
			for _ = 1, fx.Lightning do
				task.wait(0.1 + math.random() * 0.35)
				if not layer.Parent then
					return
				end
				local bolt = full(layer, Color3.new(1, 1, 1), 0.35)
				local mark = Instance.new("TextLabel")
				mark.AnchorPoint = Vector2.new(0.5, 0.5)
				mark.Size = UDim2.fromOffset(90, 90)
				mark.Position = UDim2.fromScale(0.15 + math.random() * 0.7, 0.2 + math.random() * 0.5)
				mark.BackgroundTransparency = 1
				mark.Text = "⚡"
				mark.TextScaled = true
				mark.Parent = layer
				task.wait(LIGHTNING_FLASH)
				bolt:Destroy()
				tween(mark, 0.3, { TextTransparency = 1 })
			end
		end)
	end
	if fx.Particles then
		for _ = 1, fx.Particles[2] do
			particle(layer, fx.Particles[1], fx.Particles[3], color, fx.RainbowParticles)
		end
	end
	if fx.Extra then
		for _ = 1, fx.Extra[2] do
			particle(layer, fx.Extra[1], fx.Extra[3], color:Lerp(Color3.new(1, 1, 1), 0.5), fx.RainbowParticles)
		end
	end
	if fx.Shake then
		shake(shakeTarget, fx.Shake)
	end
	task.delay(fx.Life, function()
		conn:Disconnect()
		layer:Destroy()
	end)
end

-- how long a rarity's show runs (the client keeps its banner up that long)
function GachaFx.life(rarityId)
	return FX[rarityId] and FX[rarityId].Life or 0
end

return GachaFx
