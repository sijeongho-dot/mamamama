--[[
PoopPile: the pile of poop someone (or something) stands buried in while stuck (display only, clients).
A player hit by a dropping or a poop bomb (WeatherFx) and, since 2026-10-02 ("몬스터나 보스에게 똥 폭탄을
맞추면 그들도 유저가 똥에 맞듯이 똥에 감싸이게"), a zombie or boss held by a poop bomb (Zombies).

	PoopPile.make(ground, parent, scale) -- a pile standing on `ground` (Vector3), `scale` × the player's size
]]

local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Shared")
local Fx = require(Shared:WaitForChild("Fx"))

local PoopPile = {}

-- display only
local POOP_COLOR = Color3.fromRGB(110, 70, 35)
local POOP_LIGHT = Color3.fromRGB(130, 85, 45)
local BALLS = { { 4.6, 1.0 }, { 3.6, 2.3 }, { 2.5, 3.4 }, { 1.3, 4.2 } } -- a player's pile: ball size, height
local STINK_COLOR = Color3.fromRGB(150, 190, 90)

function PoopPile.make(ground, parent, scale)
	scale = scale or 1
	local model = Instance.new("Model")
	model.Name = "PoopPile"
	for i, b in ipairs(BALLS) do
		local ball = Instance.new("Part")
		ball.Name = "Pile" .. i
		ball.Shape = Enum.PartType.Ball
		ball.Anchored, ball.CanCollide, ball.CanQuery, ball.CanTouch, ball.CastShadow = true, false, false, false, false
		ball.Material = Enum.Material.SmoothPlastic
		ball.Color = i % 2 == 0 and POOP_LIGHT or POOP_COLOR
		ball.Size = Vector3.one * b[1] * scale
		ball.CFrame = CFrame.new(ground + Vector3.new(0, b[2] * scale, 0))
		ball.Parent = model
		if i == #BALLS then -- flies and a smell over the top
			local stink = Instance.new("ParticleEmitter")
			stink.Rate = 6
			stink.Lifetime = NumberRange.new(1, 1.6)
			stink.Speed = NumberRange.new(1, 2)
			stink.SpreadAngle = Vector2.new(30, 30)
			stink.Size = NumberSequence.new(0.8 * scale, 1.6 * scale)
			stink.Transparency = NumberSequence.new(0.5, 1)
			stink.Color = ColorSequence.new(STINK_COLOR)
			stink.Parent = ball
		end
	end
	model.Parent = parent
	Fx.burst(ground + Vector3.new(0, scale, 0), { POOP_COLOR, Color3.fromRGB(150, 100, 60) }, 20, 14 * scale, 0.6 * scale, 0.6)
	return model
end

return PoopPile
