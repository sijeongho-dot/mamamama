--[[
Lang: the English version (2026-10-02, "영어 버전 번역본을 만들어서 넣을 거야", "자동 번역은 질이 안 좋더라.
번역본들도 기존 말풍선이나 틀에 벗어나지 않게") and the Spanish one (2026-10-02, "스페인어 제작후 설정에 English 누르면
한국어 누르면 Español"). The game is written in Korean; every Korean string it shows has a hand-made line in
each language: Shared/LangEn, Shared/LangEs ({ [korean] = its words }), short enough for the same box
(tools/lang/make.py). StarterPlayerScripts/Translate puts them on the screen as the Korean comes (the code
keeps writing Korean), in this player's language.

	Lang.code(player)       -- this player's language: "en" / "ko" / "es" (player attribute Language, saved in
	                        -- the settings; English until the player picks another)
	Lang.translated(player) -- not 한국어?
	Lang.t(text, code)      -- a Korean text in that language (this player's when not given), numbers filled
	                        -- in; text without Korean comes back as it is
	Lang.LANGUAGES, Lang.NAMES -- the settings button's order, each name in its own language
	Lang.remember(obj, ko)  -- the Korean a label held (Translate), and Lang.source(obj): what the code wrote

How a text is matched, first that works:
1. the whole text is a string in the language's table;
2. the whole text fits a string.format template in it ("LV %d · 트랙 %d/%d"): its words, with the
   numbers and names put back (a name in Korean is translated too). %s, %d, %.1f, ... in the words
   take the values in order; {2} takes the 2nd;
3. a whole string or template with a part without Korean after or before it at a space ("  ℹ️"), that part kept;
   then emoji and numbers at the start or end kept, the Korean between translated (when it is a string or template);
4. the text cut at its separators (a new line, " · ", " | ", " + ", " / "), each part on its own;
5. the Korean pieces left replaced one by one (longest first), and counters ("3개", "5초") turned.
Results are kept (the same text is not worked out twice).
]]

local Players = if game then game:GetService("Players") else nil

local EN = if game then require(script.Parent:WaitForChild("LangEn")) else LOAD("ReplicatedStorage/Shared/LangEn")

local Lang = {}

local HANGUL = "[\234-\237][\128-\191][\128-\191]" -- (a Hangul syllable's UTF-8; also a few other scripts')
local SPEC = "%%[%-%+ #0]*%d*%.?%d*[dsfgiqx]"
local SEPARATORS = { "\n", "  |  ", " | ", ": ", " · ", " + ", " / ", ", " } -- (the coarsest first: whole lines before their parts; ": " early: a label and its text, the text cut after)
local CACHE_MAX = 4000
local SHAPE_TOKEN = "7%03d7"
local SHAPE_FIND = "7(%d%d%d)7"
local SHAPE_MAX_VALUES = 999
local keep = {}

local function hasHangul(s)
	return type(s) == "string" and string.find(s, HANGUL) ~= nil
end
Lang.hasHangul = hasHangul

local function escape(s)
	return (string.gsub(s, "[%^%$%(%)%%%.%[%]%*%+%-%?]", "%%%0"))
end

-- a string.format template -> an anchored Lua pattern with a capture per value, and its longest plain part
local function compile(ko)
	local parts, anchor = {}, ""
	local glued, n, lastText = {}, 0, nil -- (value pairs written side by side, "%s%s": their numbers)
	local i = 1
	while i <= #ko do
		local s, e = string.find(ko, SPEC, i)
		local pct = string.find(ko, "%%%%", i)
		if pct and (not s or pct < s) then -- a literal %
			local lit = string.sub(ko, i, pct - 1)
			table.insert(parts, escape(lit) .. "%%")
			if #lit > #anchor then
				anchor = lit
			end
			i = pct + 2
		elseif s then
			local lit = string.sub(ko, i, s - 1)
			table.insert(parts, escape(lit))
			if #lit > #anchor then
				anchor = lit
			end
			local kind = string.sub(ko, e, e)
			n += 1
			if lit == "" and lastText == n - 1 and (kind == "s" or kind == "q") then
				table.insert(glued, n - 1)
			end
			if kind == "s" or kind == "q" then
				lastText = n
				table.insert(parts, "(.-)")
			elseif kind == "x" then
				table.insert(parts, "(%x+)")
			else
				table.insert(parts, "([%-%+]?[%d,]*%.?%d+%a?%a?)")
			end
			i = e + 1
		else
			local lit = string.sub(ko, i)
			table.insert(parts, escape(lit))
			if #lit > #anchor then
				anchor = lit
			end
			break
		end
	end
	return "^" .. table.concat(parts) .. "$", anchor, glued
end

local function isTemplate(ko)
	local stripped = string.gsub(ko, "%%%%", "")
	return string.find(stripped, SPEC) ~= nil
end

-- a number and a Korean counter word left over (the last step), each language its own way
local COUNTERS = {
	en = {
		{ "(%d[%d,%.]*%a?%a?)개", "%1" }, { "(%d[%d,%.]*%a?%a?)마리", "%1" }, { "(%d[%d,%.]*%a?%a?)명", "%1" }, { "(%d[%d,%.]*%a?%a?)종", "%1 species" },
		{ "(%d[%d,%.]*%a?%a?)번", "%1x" }, { "(%d[%d,%.]*%a?%a?)회", "%1x" }, { "(%d[%d,%.]*%a?%a?)초", "%1s" }, { "(%d[%d,%.]*%a?%a?)분", "%1m" },
		{ "(%d[%d,%.]*%a?%a?)시간", "%1h" }, { "(%d[%d,%.]*%a?%a?)일", "%1d" }, { "(%d[%d,%.]*%a?%a?)원", "$%1" }, { "(%d[%d,%.]*%a?%a?)단계", "Lv %1" },
		{ "(%d[%d,%.]*%a?%a?)칸", "%1 slots" }, { "(%d[%d,%.]*%a?%a?)층", "F%1" }, { "(%d[%d,%.]*%a?%a?)위", "#%1" }, { "(%d[%d,%.]*%a?%a?)등", "#%1" },
	},
	es = {
		{ "(%d[%d,%.]*%a?%a?)개", "%1" }, { "(%d[%d,%.]*%a?%a?)마리", "%1" }, { "(%d[%d,%.]*%a?%a?)명", "%1" }, { "(%d[%d,%.]*%a?%a?)종", "%1 especies" },
		{ "(%d[%d,%.]*%a?%a?)번", "%1x" }, { "(%d[%d,%.]*%a?%a?)회", "%1x" }, { "(%d[%d,%.]*%a?%a?)초", "%1 s" }, { "(%d[%d,%.]*%a?%a?)분", "%1 min" },
		{ "(%d[%d,%.]*%a?%a?)시간", "%1 h" }, { "(%d[%d,%.]*%a?%a?)일", "%1 d" }, { "(%d[%d,%.]*%a?%a?)원", "$%1" }, { "(%d[%d,%.]*%a?%a?)단계", "Nv %1" },
		{ "(%d[%d,%.]*%a?%a?)칸", "%1 espacios" }, { "(%d[%d,%.]*%a?%a?)층", "P%1" }, { "(%d[%d,%.]*%a?%a?)위", "#%1" }, { "(%d[%d,%.]*%a?%a?)등", "#%1" },
	},
	ro = {
		{ "(%d[%d,%.]*%a?%a?)개", "%1" }, { "(%d[%d,%.]*%a?%a?)마리", "%1" }, { "(%d[%d,%.]*%a?%a?)명", "%1" }, { "(%d[%d,%.]*%a?%a?)종", "%1 specii" },
		{ "(%d[%d,%.]*%a?%a?)번", "%1x" }, { "(%d[%d,%.]*%a?%a?)회", "%1x" }, { "(%d[%d,%.]*%a?%a?)초", "%1 s" }, { "(%d[%d,%.]*%a?%a?)분", "%1 min" },
		{ "(%d[%d,%.]*%a?%a?)시간", "%1 h" }, { "(%d[%d,%.]*%a?%a?)일", "%1 z" }, { "(%d[%d,%.]*%a?%a?)원", "$%1" }, { "(%d[%d,%.]*%a?%a?)단계", "Nv %1" },
		{ "(%d[%d,%.]*%a?%a?)칸", "%1 locuri" }, { "(%d[%d,%.]*%a?%a?)층", "E%1" }, { "(%d[%d,%.]*%a?%a?)위", "#%1" }, { "(%d[%d,%.]*%a?%a?)등", "#%1" },
	},
	fr = {
		{ "(%d[%d,%.]*%a?%a?)개", "%1" }, { "(%d[%d,%.]*%a?%a?)마리", "%1" }, { "(%d[%d,%.]*%a?%a?)명", "%1" }, { "(%d[%d,%.]*%a?%a?)종", "%1 espèces" },
		{ "(%d[%d,%.]*%a?%a?)번", "%1x" }, { "(%d[%d,%.]*%a?%a?)회", "%1x" }, { "(%d[%d,%.]*%a?%a?)초", "%1 s" }, { "(%d[%d,%.]*%a?%a?)분", "%1 min" },
		{ "(%d[%d,%.]*%a?%a?)시간", "%1 h" }, { "(%d[%d,%.]*%a?%a?)일", "%1 j" }, { "(%d[%d,%.]*%a?%a?)원", "$%1" }, { "(%d[%d,%.]*%a?%a?)단계", "Nv %1" },
		{ "(%d[%d,%.]*%a?%a?)칸", "%1 places" }, { "(%d[%d,%.]*%a?%a?)층", "É%1" }, { "(%d[%d,%.]*%a?%a?)위", "#%1" }, { "(%d[%d,%.]*%a?%a?)등", "#%1" },
	},
	de = {
		{ "(%d[%d,%.]*%a?%a?)개", "%1" }, { "(%d[%d,%.]*%a?%a?)마리", "%1" }, { "(%d[%d,%.]*%a?%a?)명", "%1" }, { "(%d[%d,%.]*%a?%a?)종", "%1 Arten" },
		{ "(%d[%d,%.]*%a?%a?)번", "%1x" }, { "(%d[%d,%.]*%a?%a?)회", "%1x" }, { "(%d[%d,%.]*%a?%a?)초", "%1 s" }, { "(%d[%d,%.]*%a?%a?)분", "%1 min" },
		{ "(%d[%d,%.]*%a?%a?)시간", "%1 h" }, { "(%d[%d,%.]*%a?%a?)일", "%1 T" }, { "(%d[%d,%.]*%a?%a?)원", "$%1" }, { "(%d[%d,%.]*%a?%a?)단계", "Lv %1" },
		{ "(%d[%d,%.]*%a?%a?)칸", "%1 Plätze" }, { "(%d[%d,%.]*%a?%a?)층", "E%1" }, { "(%d[%d,%.]*%a?%a?)위", "#%1" }, { "(%d[%d,%.]*%a?%a?)등", "#%1" },
	},
	ru = {
		{ "(%d[%d,%.]*%a?%a?)개", "%1" }, { "(%d[%d,%.]*%a?%a?)마리", "%1" }, { "(%d[%d,%.]*%a?%a?)명", "%1" }, { "(%d[%d,%.]*%a?%a?)종", "%1 видов" },
		{ "(%d[%d,%.]*%a?%a?)번", "%1x" }, { "(%d[%d,%.]*%a?%a?)회", "%1x" }, { "(%d[%d,%.]*%a?%a?)초", "%1 с" }, { "(%d[%d,%.]*%a?%a?)분", "%1 мин" },
		{ "(%d[%d,%.]*%a?%a?)시간", "%1 ч" }, { "(%d[%d,%.]*%a?%a?)일", "%1 д" }, { "(%d[%d,%.]*%a?%a?)원", "$%1" }, { "(%d[%d,%.]*%a?%a?)단계", "Ур %1" },
		{ "(%d[%d,%.]*%a?%a?)칸", "%1 мест" }, { "(%d[%d,%.]*%a?%a?)층", "Э%1" }, { "(%d[%d,%.]*%a?%a?)위", "#%1" }, { "(%d[%d,%.]*%a?%a?)등", "#%1" },
	},
	pt = {
		{ "(%d[%d,%.]*%a?%a?)개", "%1" }, { "(%d[%d,%.]*%a?%a?)마리", "%1" }, { "(%d[%d,%.]*%a?%a?)명", "%1" }, { "(%d[%d,%.]*%a?%a?)종", "%1 espécies" },
		{ "(%d[%d,%.]*%a?%a?)번", "%1x" }, { "(%d[%d,%.]*%a?%a?)회", "%1x" }, { "(%d[%d,%.]*%a?%a?)초", "%1 s" }, { "(%d[%d,%.]*%a?%a?)분", "%1 min" },
		{ "(%d[%d,%.]*%a?%a?)시간", "%1 h" }, { "(%d[%d,%.]*%a?%a?)일", "%1 d" }, { "(%d[%d,%.]*%a?%a?)원", "$%1" }, { "(%d[%d,%.]*%a?%a?)단계", "Nv %1" },
		{ "(%d[%d,%.]*%a?%a?)칸", "%1 vagas" }, { "(%d[%d,%.]*%a?%a?)층", "A%1" }, { "(%d[%d,%.]*%a?%a?)위", "#%1" }, { "(%d[%d,%.]*%a?%a?)등", "#%1" },
	},
	tr = {
		{ "(%d[%d,%.]*%a?%a?)개", "%1" }, { "(%d[%d,%.]*%a?%a?)마리", "%1" }, { "(%d[%d,%.]*%a?%a?)명", "%1" }, { "(%d[%d,%.]*%a?%a?)종", "%1 tür" },
		{ "(%d[%d,%.]*%a?%a?)번", "%1x" }, { "(%d[%d,%.]*%a?%a?)회", "%1x" }, { "(%d[%d,%.]*%a?%a?)초", "%1 sn" }, { "(%d[%d,%.]*%a?%a?)분", "%1 dk" },
		{ "(%d[%d,%.]*%a?%a?)시간", "%1 sa" }, { "(%d[%d,%.]*%a?%a?)일", "%1 g" }, { "(%d[%d,%.]*%a?%a?)원", "$%1" }, { "(%d[%d,%.]*%a?%a?)단계", "Sv %1" },
		{ "(%d[%d,%.]*%a?%a?)칸", "%1 yer" }, { "(%d[%d,%.]*%a?%a?)층", "K%1" }, { "(%d[%d,%.]*%a?%a?)위", "#%1" }, { "(%d[%d,%.]*%a?%a?)등", "#%1" },
	},
	pl = {
		{ "(%d[%d,%.]*%a?%a?)개", "%1" }, { "(%d[%d,%.]*%a?%a?)마리", "%1" }, { "(%d[%d,%.]*%a?%a?)명", "%1" }, { "(%d[%d,%.]*%a?%a?)종", "%1 gat." },
		{ "(%d[%d,%.]*%a?%a?)번", "%1x" }, { "(%d[%d,%.]*%a?%a?)회", "%1x" }, { "(%d[%d,%.]*%a?%a?)초", "%1 s" }, { "(%d[%d,%.]*%a?%a?)분", "%1 min" },
		{ "(%d[%d,%.]*%a?%a?)시간", "%1 h" }, { "(%d[%d,%.]*%a?%a?)일", "%1 d" }, { "(%d[%d,%.]*%a?%a?)원", "$%1" }, { "(%d[%d,%.]*%a?%a?)단계", "Poz %1" },
		{ "(%d[%d,%.]*%a?%a?)칸", "%1 miejsc" }, { "(%d[%d,%.]*%a?%a?)층", "P%1" }, { "(%d[%d,%.]*%a?%a?)위", "#%1" }, { "(%d[%d,%.]*%a?%a?)등", "#%1" },
	},
	ja = {
		{ "(%d[%d,%.]*%a?%a?)개", "%1個" }, { "(%d[%d,%.]*%a?%a?)마리", "%1匹" }, { "(%d[%d,%.]*%a?%a?)명", "%1人" }, { "(%d[%d,%.]*%a?%a?)종", "%1種" },
		{ "(%d[%d,%.]*%a?%a?)번", "%1回" }, { "(%d[%d,%.]*%a?%a?)회", "%1回" }, { "(%d[%d,%.]*%a?%a?)초", "%1秒" }, { "(%d[%d,%.]*%a?%a?)분", "%1分" },
		{ "(%d[%d,%.]*%a?%a?)시간", "%1時間" }, { "(%d[%d,%.]*%a?%a?)일", "%1日" }, { "(%d[%d,%.]*%a?%a?)원", "$%1" }, { "(%d[%d,%.]*%a?%a?)단계", "Lv %1" },
		{ "(%d[%d,%.]*%a?%a?)칸", "%1枠" }, { "(%d[%d,%.]*%a?%a?)층", "%1F" }, { "(%d[%d,%.]*%a?%a?)위", "%1位" }, { "(%d[%d,%.]*%a?%a?)등", "%1位" },
	},
	id = {
		{ "(%d[%d,%.]*%a?%a?)개", "%1" }, { "(%d[%d,%.]*%a?%a?)마리", "%1" }, { "(%d[%d,%.]*%a?%a?)명", "%1" }, { "(%d[%d,%.]*%a?%a?)종", "%1 spesies" },
		{ "(%d[%d,%.]*%a?%a?)번", "%1x" }, { "(%d[%d,%.]*%a?%a?)회", "%1x" }, { "(%d[%d,%.]*%a?%a?)초", "%1 dtk" }, { "(%d[%d,%.]*%a?%a?)분", "%1 mnt" },
		{ "(%d[%d,%.]*%a?%a?)시간", "%1 jam" }, { "(%d[%d,%.]*%a?%a?)일", "%1 hr" }, { "(%d[%d,%.]*%a?%a?)원", "$%1" }, { "(%d[%d,%.]*%a?%a?)단계", "Lv %1" },
		{ "(%d[%d,%.]*%a?%a?)칸", "%1 slot" }, { "(%d[%d,%.]*%a?%a?)층", "L%1" }, { "(%d[%d,%.]*%a?%a?)위", "#%1" }, { "(%d[%d,%.]*%a?%a?)등", "#%1" },
	},
}

-- one language's translator: DICT = { [korean] = its words } (LangEn, LangEs), built the first time it is
-- needed (Lang.t); returns translate(text)
local function hangulLeft(s)
	if not hasHangul(s) then
		return false
	end
	for name in pairs(keep) do
		if hasHangul(name) then
			s = string.gsub(s, string.gsub(name, "%p", "%%%0"), "")
		end
	end
	return hasHangul(s)
end

local function newTranslator(DICT, COUNTERS)
	local exact = {} -- korean -> english (no format specifiers)
	local templates = {} -- { pattern, anchor, english, literal }
	local pieces = {} -- { korean, english }: exact strings with Korean, longest first (step 5)

	for ko, en in pairs(DICT) do
		if isTemplate(ko) then
			local pattern, anchor, glued = compile(ko)
			if anchor ~= "" then
				table.insert(templates, { pattern = pattern, anchor = anchor, english = en, size = #ko, glued = glued, ko = ko })
			end
		else
			exact[ko] = en
			if hasHangul(ko) then
				table.insert(pieces, { ko, en })
			end
		end
	end
	-- a string written with spaces around it is found without them too (" 확정" for "확정"), when nothing else is
	for ko, en in pairs(DICT) do
		local k = string.match(ko, "^%s*(.-)%s*$")
		if k ~= ko and k ~= "" and exact[k] == nil and not isTemplate(ko) then
			exact[k] = string.match(en, "^%s*(.-)%s*$")
		end
	end
	-- (the more specific first: longer templates, longer pieces)
	table.sort(templates, function(a, b)
		return a.size > b.size
	end)
	table.sort(pieces, function(a, b)
		return #a[1] > #b[1]
	end)
	local function bucketed(list, keyOf)
		local freq = {}
		for _, item in ipairs(list) do
			for syl in string.gmatch(keyOf(item), HANGUL) do
				freq[syl] = (freq[syl] or 0) + 1
			end
		end
		local buckets, always = {}, {}
		for i, item in ipairs(list) do
			local best, bestCount = nil, math.huge
			for syl in string.gmatch(keyOf(item), HANGUL) do
				if freq[syl] < bestCount then
					best, bestCount = syl, freq[syl]
				end
			end
			local entry = { i, item }
			if best then
				buckets[best] = buckets[best] or {}
				table.insert(buckets[best], entry)
			else
				table.insert(always, entry)
			end
		end
		return function(text)
			local found, seen = table.clone(always), {}
			for syl in string.gmatch(text, HANGUL) do
				if not seen[syl] then
					seen[syl] = true
					local b = buckets[syl]
					if b then
						table.move(b, 1, #b, #found + 1, found)
					end
				end
			end
			table.sort(found, function(a, b)
				return a[1] < b[1]
			end)
			for k, entry in ipairs(found) do
				found[k] = entry[2]
			end
			return found
		end
	end
	local templatesIn = bucketed(templates, function(t)
		return t.anchor
	end)
	local piecesIn = bucketed(pieces, function(p)
		return p[1]
	end)
	-- (2026-10-02, the once-a-second stop: a long text of several lines put together, the rebirth window's with
	-- the money in it, was matched run by run against every template, ~90 ms each time the money changed) the
	-- templates holding each separator: a run of pieces joined by it can only be one of those
	local templatesWith = {}
	for _, sep in ipairs(SEPARATORS) do
		local list = {}
		for _, t in ipairs(templates) do
			if string.find(t.ko, sep, 1, true) then
				table.insert(list, t)
			end
		end
		templatesWith[sep] = list
	end

	local translate -- (recursive)

	-- the English template with the captured values put in
	local function fill(english, values)
		local n = 0
		local out = string.gsub(english, "{(%d)}", function(k)
			local v = values[tonumber(k)]
			return v and translate(v) or ""
		end)
		out = string.gsub(out, "%%%%", "\1") -- (a literal % kept aside)
		out = string.gsub(out, SPEC, function()
			n += 1
			local v = values[n]
			return v and translate(v) or ""
		end)
		return (string.gsub(out, "\1", "%%"))
	end

	-- (2026-10-02) every template that fits is tried: the first that leaves no Korean wins ("%d레벨마다 %s 1개"
	-- over a shorter one that fits too and leaves "레벨마다"), else the first that fits
	-- (2026-10-02, "모든 언어 정상이야?") two values side by side ("%s%s": "무지개" .. "가 떴어요", "해골 손" ..
	-- " · 획득") are split by the pattern at the first place that fits, often the wrong one: every other place
	-- between their letters is tried, the first that leaves no Korean wins
	local function regrouped(t, values)
		for _, k in ipairs(t.glued) do
			local both = values[k] .. values[k + 1]
			for at = 0, #both do
				local byte = string.byte(both, at + 1)
				if at ~= #values[k] and (not byte or byte < 0x80 or byte >= 0xC0) then -- (a letter's start)
					local tried = table.clone(values)
					tried[k], tried[k + 1] = string.sub(both, 1, at), string.sub(both, at + 1)
					local out = fill(t.english, tried)
					if not hasHangul(out) then
						return out
					end
				end
			end
		end
		return nil
	end

	local function byTemplate(text, cleanOnly, among)
		local first = nil
		for _, t in ipairs(among or templatesIn(text)) do
			if string.find(text, t.anchor, 1, true) then
				local values = table.pack(string.match(text, t.pattern))
				if values[1] ~= nil then
					local out = fill(t.english, values)
					if not hasHangul(out) then
						return out
					end
					if #t.glued > 0 then
						local better = regrouped(t, values)
						if better then
							return better
						end
					end
					first = first or out
				end
			end
		end
		return not cleanOnly and first or nil
	end

	-- (2026-10-02, "번역 다 안됐잖아" → "비슷한 경우 싹다 검토해": "🌙 밤 · 채굴 x1.3 · 좀비 조심 · 0:12  |  👑 보스 버프 · …"
	-- was cut at every " · ", through the middle of each line) lines put together from several strings: for each
	-- separator, the cut into the fewest whole strings that leaves no Korean (each run of pieces between two cuts
	-- tried whole first: a string may hold the separator itself); else the first cut that changed anything
	local function bySeparators(text)
		local first = nil
		for _, sep in ipairs(SEPARATORS) do
			local got = nil
			if string.find(text, sep, 1, true) then
				if sep == ": " then -- (a label and its text: the text may hold ": " itself, "불: 3초 화상: …")
					local s, e = string.find(text, sep, 1, true)
					local part, rest = string.sub(text, 1, s - 1), string.sub(text, e + 1)
					local a, b = translate(part), translate(rest)
					if a ~= part or b ~= rest then
						got = a .. sep .. b
					end
				else
					local segs, start = {}, 1
					while true do
						local s, e = string.find(text, sep, start, true)
						if not s then
							table.insert(segs, string.sub(text, start))
							break
						end
						table.insert(segs, string.sub(text, start, s - 1))
						start = e + 1
					end
					-- done[i]: the first i pieces turned into clean English (from[i]: where its last run starts)
					-- (2026-10-02) a run may also take the separator before it, for a string written with it at its
					-- front ("\n\n돈이 %s원 더 필요해요" after a line): then no separator is put back before its English
					local done, from, words, glued = { [0] = true }, {}, {}, {}
					local among = templatesWith[sep]
					for i = 1, #segs do
						for j = 0, i - 1 do -- (the longest run first)
							if done[j] then
								local run = table.concat(segs, sep, j + 1, i)
								-- (a run of several pieces: only a whole string or a template holding the separator)
								local en = (j == i - 1) and translate(run) or exact[run] or byTemplate(run, true, among)
								local withSep = false
								if (not en or hasHangul(en)) and j > 0 then
									local led = sep .. run
									en = exact[led] or byTemplate(led, true, among)
									withSep = en ~= nil
								end
								if en and not hasHangul(en) then
									done[i], from[i], words[i], glued[i] = true, j, en, withSep
									break
								end
							end
						end
					end
					if done[#segs] then
						local out, i = {}, #segs
						while i > 0 do
							local j = from[i]
							table.insert(out, 1, (j > 0 and not glued[i] and sep or "") .. words[i])
							i = j
						end
						return table.concat(out)
					end
					local out, changed = {}, false
					for _, part in ipairs(segs) do
						local t = translate(part)
						changed = changed or t ~= part
						table.insert(out, t)
					end
					if changed then
						got = table.concat(out, sep)
					end
				end
			end
			if got then
				if not hasHangul(got) then
					return got
				end
				first = first or got
			end
		end
		return first
	end

	-- (2026-10-02, "번역 안 된 부분도 보이네") a whole line with something without Korean put after it or before
	-- it at a space ("가방 2배 + 빠른 채굴  ℹ️", "▶ 🔑 열쇠"): that line's English, the rest kept as it is
	local function byMark(text)
		local spaces = {}
		for at in string.gmatch(text, "()%s") do
			table.insert(spaces, at)
		end
		for k = #spaces, 1, -1 do -- (the shortest tail first)
			local at = spaces[k]
			local tail = string.sub(text, at)
			if hasHangul(tail) then
				break
			end
			local head = string.sub(text, 1, at - 1)
			local en = not string.find(head, "%s$") and (exact[head] or byTemplate(head, true)) -- (the tail keeps every space)
			if en then
				return en .. tail
			end
		end
		for _, at in ipairs(spaces) do
			local head = string.sub(text, 1, at)
			if hasHangul(head) then
				break
			end
			local rest = string.sub(text, at + 1)
			local en = not string.find(rest, "^%s") and (exact[rest] or byTemplate(rest, true))
			if en then
				return head .. en
			end
		end
		return nil
	end

	-- the Korean in the middle, with what is around it (emoji, numbers, brackets) kept
	local function byCore(text)
		local first = string.find(text, HANGUL)
		if not first then
			return nil
		end
		local last = first
		local i = first
		while true do
			local s, e = string.find(text, HANGUL, i)
			if not s then
				break
			end
			last, i = e, e + 1
		end
		local before, core, after = string.sub(text, 1, first - 1), string.sub(text, first, last), string.sub(text, last + 1)
		if before == "" and after == "" then
			return nil
		end
		local t = exact[core] or byTemplate(core, true) -- (only a whole translation: else the separators may do better)
		return t and (before .. t .. after) or nil
	end


	-- (2026-10-02, "이것들은 왜 한글임": "신 (🔴5각성 LV 70에 열림)", a name with a string glued on after it) a text
	-- ending in a whole string or template written with a space before it (" (%s에 열림)"): its head and that
	-- tail each, when both come out without Korean
	-- (only a tail in brackets on one line: each try reads every template, a long text has many spaces)
	local function byTail(text)
		if string.find(text, "\n", 1, true) then
			return nil
		end
		for at in string.gmatch(text, "() [%(%[]") do
			if at > 1 then
				local tail = string.sub(text, at)
				local en = hasHangul(tail) and (exact[tail] or byTemplate(tail, true))
				if en and not hasHangul(en) then
					local head = translate(string.sub(text, 1, at - 1))
					if not hasHangul(head) then
						return head .. en
					end
				end
			end
		end
		return nil
	end

	-- a piece is replaced only where a word starts (not "물" inside "광물"), and only pieces of 2+ syllables
	local function startsWord(text, at)
		if at == 1 or not string.find(string.sub(text, at, at + 2), "^" .. HANGUL) then
			return true -- (the start, or a piece starting with a space or a sign: " 확정")
		end
		local before = string.sub(text, math.max(1, at - 3), at - 1)
		return not (#before == 3 and string.find(before, "^" .. HANGUL .. "$"))
	end

	local function aloneWord(text, s, e)
		local before = s == 1 or string.find(string.sub(text, s - 1, s - 1), "^%s") ~= nil
		local after = e == #text or not string.find(string.sub(text, e + 1, e + 3), "^" .. HANGUL)
		return before and after
	end

	local function byPieces(text)
		local out = text
		for _, p in ipairs(piecesIn(text)) do
			local ko, en = p[1], p[2]
			if #ko >= 3 and string.find(out, ko, 1, true) then
				local i, parts = 1, {}
				while true do
					local s, e = string.find(out, ko, i, true)
					if not s then
						table.insert(parts, string.sub(out, i))
						break
					end
					table.insert(parts, string.sub(out, i, s - 1))
					local fits = if #ko >= 6 then startsWord(out, s) else aloneWord(out, s, e)
					table.insert(parts, fits and en or ko)
					i = e + 1
				end
				out = table.concat(parts)
				if not hasHangul(out) then
					break
				end
			end
		end
		for _, c in ipairs(COUNTERS) do
			out = string.gsub(out, c[1], c[2])
		end
		return out
	end

	local cache, cached = {}, 0

	function translate(text)
		if not hasHangul(text) or keep[text] then
			return text
		end
		local hit = cache[text]
		if hit then
			return hit
		end
		local lead, body, trail = string.match(text, "^(%s*)(.-)(%s*)$")
		if not exact[text] and (lead ~= "" or trail ~= "") then -- (spaces around kept: most strings are written without them)
			-- (2026-10-02, "모든 언어 정상이야?") a template written with its spaces or new lines around it
			-- (" · %s보스 %d초 뒤", "\n\n돈이 %s원 더 필요해요") first, as it is; else the text without them
			local out = byTemplate(text, true) or (lead .. translate(body) .. trail)
			cache[text] = out
			return out
		end
		-- (2026-10-02: the core before the separators, so "가방 2배 + 빠른 채굴  ℹ️" is that whole name, not "+"-split
		-- pieces; the core only answers when it has its own English)
		-- (2026-10-02) a template match that leaves Korean in ("디펜스 %s" over "디펜스 필드  ℹ️") waits behind the
		-- other ways: they may find the whole line
		local template = byTemplate(text)
		local clean = template and not hangulLeft(template) and template or nil
		local out = exact[text] or clean or byMark(text) or byCore(text) or byTail(text) or bySeparators(text) or template
			or byPieces(text)
		if cached >= CACHE_MAX then
			cache, cached = {}, 0
		end
		cache[text] = out
		cached += 1
		return out
	end

	local shapes, shaped = {}, 0
	local function translateTop(text)
		if not hasHangul(text) or keep[text] or cache[text] or exact[text] then
			return translate(text)
		end
		local values = {}
		local shape = string.gsub(text, "%d+", function(run)
			table.insert(values, run)
			return string.format(SHAPE_TOKEN, #values)
		end)
		if #values == 0 or #values > SHAPE_MAX_VALUES then
			return translate(text)
		end
		local function back(out)
			return (string.gsub(out, SHAPE_FIND, function(k)
				return values[tonumber(k)] or k
			end))
		end
		local known = shapes[shape]
		if known then
			return back(known)
		end
		local out = translate(text)
		if known == nil then
			if shaped >= CACHE_MAX then
				shapes, shaped = {}, 0
			end
			local general = translate(shape)
			shapes[shape] = back(general) == out and general or false
			shaped += 1
		end
		return out
	end

	return translateTop
end


-- the languages, in the order the settings button goes round (2026-10-02, Spanish: "설정에 English 누르면
-- 한국어 누르면 Español"), each name in its own language. ko is the game's own: nothing to translate
Lang.LANGUAGES = { "en", "ko", "es", "ro", "fr", "de", "ru", "pt", "tr", "pl", "ja", "id" }
Lang.NAMES = {
	en = "English", ko = "한국어", es = "Español", ro = "Română", fr = "Français", de = "Deutsch",
	ru = "Русский", pt = "Português", tr = "Türkçe", pl = "Polski", ja = "日本語", id = "Bahasa Indonesia",
}
local MODULES = {
	es = "LangEs", ro = "LangRo", fr = "LangFr", de = "LangDe", ru = "LangRu", pt = "LangPt", tr = "LangTr", pl = "LangPl",
	ja = "LangJa", id = "LangId",
}
local DICTS = {
	en = function()
		return EN
	end,
}
for code, name in pairs(MODULES) do
	DICTS[code] = function()
		return if game then require(script.Parent:WaitForChild(name)) else LOAD("ReplicatedStorage/Shared/" .. name)
	end
end
local translators = {}

-- this player's language: player attribute Language ("en" / "ko" / "es", saved in the settings); English
-- until the player picks another ("언어는 기본 영어로 해놓자")
function Lang.code(player)
	player = player or (Players and Players.LocalPlayer)
	if not player then
		return "en"
	end
	local code = player:GetAttribute("Language")
	return Lang.NAMES[code] and code or "en"
end

function Lang.deviceCode(player)
	player = player or (Players and Players.LocalPlayer)
	local code = player and string.lower(string.sub(tostring(player.LocaleId or ""), 1, 2))
	return Lang.NAMES[code] and code or "en"
end

-- is this player's screen translated (not 한국어)?
function Lang.translated(player)
	return Lang.code(player) ~= "ko"
end

-- a Korean text in a language (this player's when code is not given); text without Korean as it is
function Lang.t(text, code)
	code = code or Lang.code()
	if code == "ko" or not DICTS[code] then
		return text
	end
	local translate = translators[code]
	if not translate then
		translate = newTranslator(DICTS[code](), COUNTERS[code])
		translators[code] = translate
	end
	return translate(text)
end

-- the Korean the code wrote into a label, kept while it shows English (Translate); Lang.source(obj)
local sources = setmetatable({}, { __mode = "k" })
function Lang.keep(name)
	if type(name) == "string" and name ~= "" then
		keep[name] = true
	end
end

function Lang.remember(obj, korean)
	sources[obj] = korean
end
function Lang.source(obj)
	return sources[obj] or obj.Text
end

-- (2026-10-03, "울트라코드 모드로 다시 확인해보자 왜 렉걸리는가") a label's text set only when it changes: code that set
-- the same Korean every frame (the mining bar, the carried keys line, the promotion button…) had it put back in
-- English every frame too (Translate), two text changes and a new layout a frame for each such label
function Lang.set(obj, text)
	if obj.Text ~= text and sources[obj] ~= text then
		obj.Text = text
	end
end

return Lang
