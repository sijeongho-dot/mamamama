--[[
DinoPortrait: a small picture of a dino for lists and cards (display only, clients).

A ViewportFrame with a copy of the species' model (ReplicatedStorage.DinoModels, shared by the
Defense service from ServerStorage.Assets) seen from the front three-quarter, framed to its size.
Without the model it shows a round badge in the theme's color with the name's first letter.

	local picture = DinoPortrait.new("TRex", UDim2.fromOffset(44, 44))
	picture.Parent = row
	DinoPortrait.new("TRex", size, { hidden = true }) -- a shadow of it (not collected yet, 도감)
	DinoPortrait.ofModel(model, size)                 -- the same kind of picture of any model
	DinoPortrait.key("Gold", size)                    -- a key grade's picture (a 🔑 until the model arrives)
	DinoPortrait.border(row, "Epic")                  -- a border in the grade's color on any window thing:
	                                                  -- a dino's rarity, a key grade, "Money"
	DinoPortrait.backdrop(window, "TRex")             -- (2026-10-02) a big, nearly see-through dino behind a
	                                                  -- window's contents, at its bottom right
Every dino or item shown in a window carries such a border, so its grade reads at a glance; key
pictures get theirs by themselves. The rainbow grades' borders run through every color.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local FrameMeter = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("FrameMeter"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))
local RarityFx = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("RarityFx"))
local Lang = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Lang"))
local Players = game:GetService("Players")

local DinoPortrait = {}

-- display only
local TURN = math.rad(-35) -- the model turned so the camera sees its front three-quarter
local FIELD_OF_VIEW = 30
local MARGIN = 1.1 -- a little room around the model
local LOOK_DOWN = 0.12 -- the camera a bit above the middle, × height
local SPIN_SPEED = math.rad(40)
local KEY_NORMAL_COLOR = Color3.fromRGB(255, 205, 60) -- a normal key's badge
local KEY_BADGE_TRANSPARENCY = 0.45
local HIDDEN_SHADE = 0.55 -- a hidden dino: its black shadow this see-through (grey on a light card)
local BORDER_THICKNESS = 2
local BORDER_COMMON = Color3.fromRGB(150, 150, 160) -- common dinos
local BORDER_MONEY = Color3.fromRGB(240, 190, 60)
local BORDER_OVERRIDE = { Onyx = Color3.fromRGB(120, 90, 170) } -- (onyx's own near-black is lost on a dark window)
local BORDER_RAINBOW = { Rainbow = true, Secret = true, Divine = true } -- these borders run through every color
local RAINBOW = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 80, 80)), ColorSequenceKeypoint.new(0.2, Color3.fromRGB(255, 200, 60)),
	ColorSequenceKeypoint.new(0.4, Color3.fromRGB(90, 220, 110)), ColorSequenceKeypoint.new(0.6, Color3.fromRGB(80, 170, 255)),
	ColorSequenceKeypoint.new(0.8, Color3.fromRGB(180, 90, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 80, 80)),
})
local PAINT_TWO_TONES = {
	Golden = { Color3.fromRGB(255, 245, 170), Color3.fromRGB(230, 160, 30) },
	Onyx = { Color3.fromRGB(170, 110, 240), Color3.fromRGB(40, 25, 70) },
	Celestial = { Color3.fromRGB(255, 255, 255), Color3.fromRGB(160, 215, 255) },
	Cosmic = { Color3.fromRGB(170, 140, 255), Color3.fromRGB(50, 35, 140) },
	Primeval = { Color3.fromRGB(255, 215, 100), Color3.fromRGB(200, 85, 20) },
}
local PAINT_SHADE = Color3.fromRGB(185, 185, 185)
local THEME_COLORS = {
	Carnivore = Color3.fromRGB(200, 70, 60), Herbivore = Color3.fromRGB(90, 170, 80),
	Armored = Color3.fromRGB(150, 120, 80), Sky = Color3.fromRGB(110, 170, 230),
	Sea = Color3.fromRGB(60, 110, 200), Variant = Color3.fromRGB(170, 90, 200),
}

-- the color of a grade: a dino rarity, a key grade ("Normal", "Silver", ...) or "Money"
function DinoPortrait.gradeColor(gradeId)
	if BORDER_OVERRIDE[gradeId] then
		return BORDER_OVERRIDE[gradeId]
	elseif gradeId == "Money" then
		return BORDER_MONEY
	elseif Formulas.rarity(gradeId) then
		return RarityFx.color(gradeId) or BORDER_COMMON
	end
	local t = Formulas.keyType(gradeId)
	return t and t.Rgb and Color3.fromRGB(table.unpack(t.Rgb)) or KEY_NORMAL_COLOR
end

-- a border in the grade's color around a window thing (a row, a card, a picture)
function DinoPortrait.border(gui, gradeId, thickness)
	local old = gui:FindFirstChild("GradeBorder")
	if old then
		old:Destroy()
	end
	local stroke = Instance.new("UIStroke")
	stroke.Name = "GradeBorder"
	stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	stroke.Thickness = thickness or BORDER_THICKNESS
	stroke.Color = DinoPortrait.gradeColor(gradeId)
	if BORDER_RAINBOW[gradeId] then
		stroke.Color = Color3.new(1, 1, 1)
		local gradient = Instance.new("UIGradient")
		gradient.Color = RAINBOW
		gradient.Parent = stroke
	end
	stroke.Parent = gui
	return stroke
end

function DinoPortrait.paint(gui, gradeId)
	local old = gui:FindFirstChild("GradePaint")
	if old then
		old:Destroy()
	end
	local gradient = Instance.new("UIGradient")
	gradient.Name = "GradePaint"
	gradient.Rotation = 90
	local two = PAINT_TWO_TONES[gradeId]
	local rainbow = BORDER_RAINBOW[gradeId] == true
	if rainbow then
		gradient.Color = RAINBOW
		gradient.Rotation = 0
	elseif two then
		gradient.Color = ColorSequence.new(two[1], two[2])
	else
		gradient.Color = ColorSequence.new(Color3.new(1, 1, 1), PAINT_SHADE)
	end
	local color = (rainbow or two) and Color3.new(1, 1, 1) or DinoPortrait.gradeColor(gradeId)
	if gui:IsA("TextLabel") or gui:IsA("TextButton") then
		gui.TextColor3 = color
	else
		gui.BackgroundColor3 = color
	end
	gradient.Parent = gui
	return gradient, rainbow
end

local function badge(speciesId, size)
	local species = Formulas.species(speciesId)
	local b = Instance.new("TextLabel")
	b.Size = size
	b.BackgroundColor3 = species and THEME_COLORS[species.Theme] or Color3.fromRGB(120, 120, 120)
	b.Font = Enum.Font.GothamBold
	b.TextScaled = true
	b.TextColor3 = Color3.new(1, 1, 1)
	-- its name's first letter, in the player's language (2026-10-02, the English version)
	local function letter()
		local name = species and Lang.t(species.Name)
		b.Text = name and utf8.char(utf8.codepoint(name, 1)) or "?"
	end
	letter()
	local me = Players.LocalPlayer
	if me then
		local conn
		conn = me:GetAttributeChangedSignal("Language"):Connect(function()
			if b.Parent then
				letter()
			else
				conn:Disconnect()
			end
		end)
	end
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0.5, 0)
	c.Parent = b
	return b
end

function DinoPortrait.new(speciesId, size, options)
	local hidden = options and options.hidden
	local folder = ReplicatedStorage:FindFirstChild("DinoModels")
	local source = folder and folder:FindFirstChild("Dino_" .. speciesId)
	if not source then
		local b = badge(speciesId, size)
		if hidden then
			b.BackgroundColor3 = Color3.fromRGB(150, 150, 155)
			b.Text = "?"
		end
		return b
	end
	return DinoPortrait.ofModel(source, size, options)
end

-- the same picture of any model (e.g. a key from ReplicatedStorage.KeyModels)
function DinoPortrait.ofModel(source, size, options)
	local hidden = options and options.hidden
	-- wrapped in a fresh model with an upright pivot: an imported model's own pivot can be turned
	-- (the FBX axes), and turning that pivot would tip the dino over
	local model = Instance.new("Model")
	source:Clone().Parent = model
	local center = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(center.Position)
	model:PivotTo(CFrame.Angles(0, TURN, 0)) -- faces -Z, so the camera below sees it looking front-left
	local cf, extent = model:GetBoundingBox()

	local frame = Instance.new("ViewportFrame")
	frame.Size = size
	frame.BackgroundTransparency = 1
	frame.Ambient = Color3.fromRGB(170, 170, 170)
	frame.LightColor = Color3.new(1, 1, 1)
	frame.LightDirection = Vector3.new(-0.5, -1, 0.6)
	if hidden then -- no light at all: a flat shadow, made grey by showing the card through it
		frame.Ambient = Color3.new(0, 0, 0)
		frame.LightColor = Color3.new(0, 0, 0)
		frame.ImageTransparency = HIDDEN_SHADE
	end
	model.Parent = frame

	local camera = Instance.new("Camera")
	camera.FieldOfView = FIELD_OF_VIEW
	local radius = extent.Magnitude / 2 * MARGIN
	local distance = radius / math.tan(math.rad(FIELD_OF_VIEW / 2))
	local target = cf.Position
	camera.CFrame = CFrame.lookAt(target + Vector3.new(0, extent.Y * LOOK_DOWN, -distance), target)
	camera.Parent = frame
	frame.CurrentCamera = camera
	if options and options.spin then
		local started = os.clock()
		local spin = RunService.Heartbeat:Connect(FrameMeter.wrap("DinoPortrait", function()
			if frame.Visible and frame:IsDescendantOf(game) then
				model:PivotTo(CFrame.Angles(0, TURN + (os.clock() - started) * SPIN_SPEED, 0))
			end
		end))
		frame.Destroying:Connect(function()
			spin:Disconnect()
		end)
	end
	return frame
end

-- (2026-10-02, "이런 창은 공룡 그림이 거의 투명하게 배경에 깔려있다거나") a big faint dino behind a window's
-- contents: its model in a ViewportFrame at the window's bottom right, BACKDROP_HEIGHT of its height, nearly
-- see-through and under everything else in it (presses go through). Once the models have arrived.
local BACKDROP_HEIGHT = 0.95
local BACKDROP_TRANSPARENCY = 0.86
local BACKDROP_WAIT = 20 -- seconds to wait for the dino models after joining
function DinoPortrait.backdrop(window, speciesId, transparency)
	task.defer(function() -- (after the caller has put the window in place: as DinoPortrait.key)
		local folder = ReplicatedStorage:WaitForChild("DinoModels", BACKDROP_WAIT)
		local source = folder and folder:WaitForChild("Dino_" .. speciesId, BACKDROP_WAIT)
		if not source or not window.Parent then
			return
		end
		local picture = DinoPortrait.ofModel(source, UDim2.fromScale(BACKDROP_HEIGHT, BACKDROP_HEIGHT))
		picture.Name = "Backdrop"
		picture.AnchorPoint = Vector2.new(1, 1)
		picture.Position = UDim2.fromScale(1, 1)
		picture.ImageTransparency = transparency or BACKDROP_TRANSPARENCY
		picture.ZIndex = 0 -- (under its siblings; a Global-order gui would draw 0 under the window itself)
		local gui = window:FindFirstAncestorWhichIsA("ScreenGui")
		if gui and gui.ZIndexBehavior == Enum.ZIndexBehavior.Global then
			picture.ZIndex = window.ZIndex
		end
		picture.Active = false
		local square = Instance.new("UIAspectRatioConstraint")
		square.DominantAxis = Enum.DominantAxis.Height
		square.Parent = picture
		picture.Parent = window
	end)
end

-- a key grade's picture: its finished key from ReplicatedStorage.KeyModels (the Keys service shares
-- them), a 🔑 in the grade's color until it arrives
function DinoPortrait.key(gradeId, size)
	local t = Formulas.keyType(gradeId)
	local color = t and t.Rgb and Color3.fromRGB(table.unpack(t.Rgb)) or KEY_NORMAL_COLOR
	local holder = Instance.new("TextLabel")
	holder.Size = size
	holder.Font = Enum.Font.GothamBold
	holder.TextScaled = true
	holder.Text = "🔑"
	holder.TextColor3 = color
	-- a round badge in the grade's color behind the key, so every grade reads apart at a glance
	holder.BackgroundColor3 = color
	holder.BackgroundTransparency = KEY_BADGE_TRANSPARENCY
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = holder
	if t and t.Rainbow then
		holder.BackgroundColor3 = Color3.new(1, 1, 1)
		local rainbow = Instance.new("UIGradient")
		rainbow.Color = ColorSequence.new({
			ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 90, 90)), ColorSequenceKeypoint.new(0.25, Color3.fromRGB(255, 220, 80)),
			ColorSequenceKeypoint.new(0.5, Color3.fromRGB(90, 230, 120)), ColorSequenceKeypoint.new(0.75, Color3.fromRGB(90, 160, 255)),
			ColorSequenceKeypoint.new(1, Color3.fromRGB(220, 110, 255)),
		})
		rainbow.Rotation = 45
		rainbow.Parent = holder
	end
	DinoPortrait.border(holder, gradeId)
	-- (2026-10-04, "열쇠 렌더링은 어디감": the models already there, this ran before the caller put the badge in its
	-- window, found it nowhere yet and gave up: every key stayed a 🔑) after the caller has placed it
	task.defer(function()
		local models = ReplicatedStorage:WaitForChild("KeyModels", 60)
		local model = models and models:WaitForChild("Key_" .. gradeId, 10)
		if model and holder.Parent then
			local view = DinoPortrait.ofModel(model, UDim2.fromScale(1, 1))
			view.ZIndex = holder.ZIndex + 1
			view.Parent = holder
			holder.Text = ""
		end
	end)
	return holder
end

return DinoPortrait
