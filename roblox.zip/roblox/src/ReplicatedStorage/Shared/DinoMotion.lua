--[[
DinoMotion: lively motion for the dinos and fossil monsters, drawn on each client (display only).

The FBX models from tools/make_dino.py and tools/make_monster.py are skinned to named bones:
Root, Hips, Spine, Neck, Head, Jaw, Tail1..3, UpperLeg/LowerLeg/Foot_<L|R|FL|FR|BL|BR>,
UpperWing/LowerWing/WingTip_<L|R>, UpperFlipper/LowerFlipper/FlipperTip_<FL|FR|BL|BR>.
This module turns those bones every frame (Bone.Transform, which only this client sees):

	walking  legs swing in a gait (bipeds left/right, four legs diagonal pairs), knees bend,
	         hips roll, the body twists, bobs and rocks, the neck bobs with the steps like a
	         walking bird (the head kept nearly level), the tail swings and bounces
	always   breathing, the neck dips slowly, the head looks around and tilts, the tail sways,
	         wings and flippers move
	attack   the neck lunges down with the jaw open (DinoMotion.attack)
	roar     rears up, the neck and head thrown back, the jaw wide open and trembling (DinoMotion.roar)
	graze    eating grass: the neck and head go down to the ground, the head bobs and the jaw chews,
	         for as long as it is on (DinoMotion.graze); it blends in and out

Models without bones (older imports, grey boxes) get the body bob, a waddle and the lunge instead.

	local rig = DinoMotion.new(model)          -- once, with the model at rest
	local offset = DinoMotion.step(rig, dt, speed)  -- every frame; speed in studs per second
	model:PivotTo(place * offset)               -- the caller puts the model where it stands
	DinoMotion.attack(rig)                      -- when it attacks
	DinoMotion.roar(rig)                        -- a big roar (the ridden dino, on the rider's word)
	DinoMotion.graze(rig, true / false)         -- start / stop eating grass (farm dinos, wandering herds)
	local offset = DinoMotion.fly(rig, dt)      -- instead of step, for a pterosaur in the sky

Flying: strong wingbeats (the tips trailing) for a few seconds, then a glide with the wings held out,
over and over; legs tucked back, the body rising on each downstroke and pitching a little. The body
motion shows even on a model without bones.

Sounds (2026-10-03, "공룡 발걸음 소리나 익룡 파닥거릴때 소리도 넣어", "그리고 모든 공룡과 익룡들에게 적용해"): every
dino moved by step knocks as its feet come down (two footfalls a step cycle; Shared/Sfx "DinoFoot", short
and solid: 2026-10-03, "단단하고 안 늘어지게"), every pterosaur moved by fly flaps once a wingbeat while flapping (not gliding;
"WingFlap"), on this screen, from where it stands: the platform and farm dinos, the wild ones, the NPCs,
the ridden dinos, the zombies, the flyers in the sky. Bigger ones deeper and louder. Only within
SOUND_HEARD (+ its height × SOUND_HEARD_PER_HEIGHT) of the camera, and SOUNDS_PER_SECOND at most in all (a
herd going by is a patter, not a din). A sea dino (flippers and no legs) makes no steps; a rig with
silent set makes none at all (the fossils: their bones rattle instead, DefenseView). A pterosaur (wing
bones) never makes footfalls: only its wingbeats, flying or walking with its wings flapping. soundGain
makes one quieter (the platform and farm dinos, DefenseView) or louder; a ridden dino (Ride.client) also
sets priority (never held back by SOUNDS_PER_SECOND), stepPitch (deeper), stompFrom (stomps from that height)
minStepGap (at most one footfall sound that often), flapGain and flapPitch (its wingbeats' own loudness and pitch).
	rig.silent = true
	rig.soundGain = 0.5
]]

local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local DinoMotion = {}

-- tuning (display only), angles in radians
local STRIDE_PER_HEIGHT = 1.2 -- studs walked per step cycle, × the model's height
local FULL_WALK_SPEED = 4 -- at this speed and faster the gait is at full size
local LEG_SWING = 0.6
local KNEE_BEND = 0.7
local FOOT_FOLLOW = 0.6
local HIP_ROLL = 0.1
local BODY_BOB = 0.07 -- × height
local BODY_ROCK = 0.04 -- the body pitching forward and back with each step
local NECK_NOD = 0.32 -- the neck bobbing with the steps, like a walking bird
local HEAD_KEEP = 0.55 -- the head turns back this share of the nod, so it stays nearly level
local SPINE_SWAY = 0.07 -- the body twisting a little with the steps
local IDLE_NOD, IDLE_NOD_SPEED = 0.1, 0.9 -- standing: the neck dips and rises slowly
local HEAD_TILT = 0.12 -- standing: the head tilts, curious
local HEAD_LOOK = 0.35
local HEAD_LOOK_SPEED = 0.6
local TAIL_SWAY = 0.4
local TAIL_WAVE = 0.8 -- phase lag per tail bone
local TAIL_LIFT = 0.12 -- the tail bouncing up and down with the steps
local BREATH = 0.035
local BREATH_SPEED = 2
local WING_FLAP, WING_FLAP_SPEED = 0.7, 7
local WING_IDLE, WING_IDLE_SPEED = 0.12, 1.5
local FLIPPER_PADDLE, FLIPPER_SPEED = 0.45, 3
local ATTACK_SECONDS = 0.35
local ATTACK_NECK, ATTACK_HEAD, ATTACK_JAW = 0.3, 0.1, 0.5
local ATTACK_LUNGE = 0.12 -- × height, forward (was 0.2)
-- studs: the most a lunge goes, whatever the size (the biggest dinos lunged 4-5 studs, off their spot
-- on the platform and back, every attack)
local ATTACK_LUNGE_MAX = 0.8
local NO_BONES_WADDLE, NO_BONES_ATTACK_TILT = 0.08, 0.2
local ROAR_SECONDS = 1.4
local ROAR_NECK, ROAR_HEAD, ROAR_JAW = 0.55, 0.35, 0.75 -- thrown back and wide open
local ROAR_REAR = 0.14 -- the body rears up (radians, nose up)
local ROAR_TREMBLE, ROAR_TREMBLE_SPEED = 0.08, 38
local FLY_FLAP, FLY_FLAP_SPEED = 0.95, 7 -- wingbeat angle and speed (radians per second of the beat)
local FLY_TIP_LAG = 0.7 -- each wing segment follows the one before it this much later (phase)
local FLY_TIP_GAIN = 0.35 -- and swings this much further
local FLY_GLIDE_WINGS = 0.12 -- wings held a little up while gliding
local FLY_FLAP_SECONDS, FLY_GLIDE_SECONDS = { 2, 4 }, { 1.5, 3 }
local FLY_MIX_RATE = 2.5 -- how fast it goes between flapping and gliding
local FLY_BOB = 0.08 -- × height, the body up and down with the beat
local FLY_PITCH = 0.08
local FLY_ROLL_NO_BONES = 0.12 -- a model without bones rocks side to side with the beat instead
local FLY_LEG_TUCK, FLY_KNEE_TUCK = -1.0, 0.5
local GRAZE_NECK, GRAZE_HEAD = 0.75, 0.45 -- down to the grass
local GRAZE_BOB, GRAZE_BOB_SPEED = 0.08, 5 -- the head bobbing as it pulls at the grass
local GRAZE_JAW, GRAZE_CHEW_SPEED = 0.28, 9
local GRAZE_RATE = 3 -- how fast it goes down and comes up again
local GRAZE_TILT_NO_BONES = 0.18 -- a model without bones tips forward instead
-- the sounds (see the top)
local SOUND_HEARD, SOUND_HEARD_PER_HEIGHT = 40, 2 -- studs from the camera
local SOUNDS_PER_SECOND = 8 -- footfalls and wingbeats in all, at most
local STEP_MIN_SPEED = 0.6 -- studs a second: slower is shuffling on the spot (no footfalls)
-- (2026-10-03, "공룡 발자국은 더 육중한 발자국 소리가 나게 해") heavier: even the small ones not much above the sound's
-- own pitch (was up to 1.5, a patter), the big ones' stomps from 9 studs tall (was 15), all a little louder
-- (2026-10-03, "깨지고 늘어지네 … 단단하고 안 늘어지게. 그리고 소리도 너무커") barely lower for the big ones (slowing a
-- sound down drags it out), barely louder; no stomps (DinoStomp is the long area attack)
local STEP_SIZE_PITCH = 0.15 -- pitch = (3 / height) ^ this: a 3-stud dino at 1, bigger a little lower
local STEP_PITCH_RANGE = { 0.85, 1.05 }
local STEP_SIZE_GAIN = 0.3 -- gain = (height / 3) ^ this
local STEP_GAIN_RANGE = { 0.7, 1.3 }
local STOMP_HEIGHT = math.huge -- studs tall and taller: its steps are stomps (none now)
local FLAP_PITCH_RANGE = { 0.5, 1.5 } -- (wingbeats keep the wider range)
local STOMP_GAIN = 0.75
local STOMP_PITCH_RANGE = { 0.7, 1.1 }
local FLAP_MIN_MIX = 0.5 -- flapping, not gliding
local FLAP_MIN_WALK = 0.4 -- a pterosaur walking: its wings flap big enough to be heard
local SOUND_SPREAD = 0.08 -- each footfall or wingbeat a little higher or lower

local LEG_PHASE = { L = 0, R = math.pi, FL = 0, BR = 0, FR = math.pi, BL = math.pi }
local LIMBS = { -- bone name before "_" -> limb and segment (1 = upper)
	UpperLeg = { "Leg", 1 }, LowerLeg = { "Leg", 2 }, Foot = { "Leg", 3 },
	UpperWing = { "Wing", 1 }, LowerWing = { "Wing", 2 }, WingTip = { "Wing", 3 },
	UpperFlipper = { "Flipper", 1 }, LowerFlipper = { "Flipper", 2 }, FlipperTip = { "Flipper", 3 },
}

-- the dino's own height: its parts only, not the rarity effects (RarityFx's glowing shell is wider than
-- the dino is tall, which made big dinos bob and lunge far too much)
local function bodyHeight(model)
	local fx = model:FindFirstChild("RarityFx")
	local low, high = math.huge, -math.huge
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") and not (fx and d:IsDescendantOf(fx)) then
			local up = d.CFrame:VectorToObjectSpace(Vector3.yAxis) -- how the part's axes lie against world up
			local half = (math.abs(up.X) * d.Size.X + math.abs(up.Y) * d.Size.Y + math.abs(up.Z) * d.Size.Z) / 2
			low = math.min(low, d.Position.Y - half)
			high = math.max(high, d.Position.Y + half)
		end
	end
	return high > low and math.max(high - low, 0.5) or 0.5
end

-- at (optional): where the model's parts stand now, when it was moved without PivotTo (its WorldPivot not following)
function DinoMotion.new(model, at)
	local rig = { model = model, t = math.random() * 10, phase = 0, attackLeft = 0, seed = math.random() * 2 * math.pi,
		bones = {} }
	local pivot = at or model:GetPivot()
	rig.height = bodyHeight(model)
	local found = {}
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("Bone") then
			d.Transform = CFrame.identity
			table.insert(found, d)
		end
	end
	for _, bone in ipairs(found) do
		-- the model's axes (X right, Y up, Z back) seen from the bone at rest
		local rest = pivot:ToObjectSpace(bone.WorldCFrame)
		local e = {
			bone = bone,
			name = bone.Name,
			x = rest:VectorToObjectSpace(Vector3.xAxis),
			y = rest:VectorToObjectSpace(Vector3.yAxis),
			z = rest:VectorToObjectSpace(Vector3.zAxis),
			side = rest.Position.X >= 0 and 1 or -1,
		}
		local base, suffix = string.match(bone.Name, "^(%a+)_(%a+)$")
		local limb = base and LIMBS[base]
		if limb then
			e.limb, e.segment, e.suffix = limb[1], limb[2], suffix
		end
		e.tail = tonumber(string.match(bone.Name, "^Tail(%d+)$"))
		table.insert(rig.bones, e)
	end
	rig.hasBones = #rig.bones > 0
	local legs, flippers = false, false
	for _, e in ipairs(rig.bones) do
		legs = legs or e.limb == "Leg"
		flippers = flippers or e.limb == "Flipper"
	end
	rig.noFeet = flippers and not legs -- (a sea dino: no footfalls)
	-- (2026-10-03, "나는 공룡은 모션에 맞춰서 펄럭이는 소리만 나게, 지금 왜 익룡이 발자국 소리가나는지 모르겠다") a pterosaur
	-- (wing bones) makes no footfalls at all: walking, its wings flap and each downstroke is a wingbeat sound
	local wings = false
	for _, e in ipairs(rig.bones) do
		wings = wings or e.limb == "Wing"
	end
	rig.winged = wings
	return rig
end

function DinoMotion.attack(rig)
	rig.attackLeft = ATTACK_SECONDS
end

function DinoMotion.roar(rig)
	rig.roarLeft = ROAR_SECONDS
end

function DinoMotion.graze(rig, on)
	rig.grazing = on and true or false
end

local function turn(axis, angle)
	return CFrame.fromAxisAngle(axis, angle)
end

-- a footfall or wingbeat to play now? (near enough, and within this second's share): where from
local IS_CLIENT = RunService:IsClient()
local Sfx = nil -- (Shared/Sfx, once the first sound plays)
local budget, budgetAt = SOUNDS_PER_SECOND, os.clock()
local function soundSpot(rig)
	if not IS_CLIENT or rig.silent or not rig.model.Parent then
		return nil
	end
	local camera = Workspace.CurrentCamera
	local at = rig.model:GetPivot().Position
	if not camera or (at - camera.CFrame.Position).Magnitude > SOUND_HEARD + rig.height * SOUND_HEARD_PER_HEIGHT then
		return nil
	end
	local now = os.clock()
	budget = math.min(SOUNDS_PER_SECOND, budget + (now - budgetAt) * SOUNDS_PER_SECOND)
	budgetAt = now
	if not rig.priority then -- (a priority rig, the dino I ride, never waits its turn)
		if budget < 1 then
			return nil
		end
		budget -= 1
	end
	Sfx = Sfx or require(script.Parent:WaitForChild("Sfx"))
	return at
end

local function spread()
	return 1 - SOUND_SPREAD + 2 * SOUND_SPREAD * math.random()
end

local function footfall(rig)
	-- (rig.minStepGap: at most one footfall sound this often; a ridden dino's legs cycle fast)
	if rig.minStepGap and os.clock() - (rig.lastStep or -math.huge) < rig.minStepGap then
		return
	end
	local at = soundSpot(rig)
	if not at then
		return
	end
	rig.lastStep = os.clock()
	local h = rig.height
	local pitch = (rig.stepPitch or 1) * spread() -- (rig.stepPitch: deeper for a ridden dino)
	if h >= (rig.stompFrom or STOMP_HEIGHT) then -- (rig.stompFrom: a ridden dino stomps from a smaller size)
		Sfx.play("DinoStomp", at, math.clamp((STOMP_HEIGHT / h) ^ STEP_SIZE_PITCH, STOMP_PITCH_RANGE[1],
			STOMP_PITCH_RANGE[2]) * pitch, STOMP_GAIN * (rig.soundGain or 1))
	else
		Sfx.play("DinoFoot", at, math.clamp((3 / h) ^ STEP_SIZE_PITCH, STEP_PITCH_RANGE[1], STEP_PITCH_RANGE[2]) * pitch,
			math.clamp((h / 3) ^ STEP_SIZE_GAIN, STEP_GAIN_RANGE[1], STEP_GAIN_RANGE[2]) * (rig.soundGain or 1))
	end
end

local function wingbeat(rig)
	local at = soundSpot(rig)
	if at then
		local h = rig.height
		Sfx.play("WingFlap", at, math.clamp((3 / h) ^ 0.35, FLAP_PITCH_RANGE[1], FLAP_PITCH_RANGE[2]) * spread()
			* (rig.flapPitch or 1),
			math.clamp((h / 3) ^ STEP_SIZE_GAIN, STEP_GAIN_RANGE[1], STEP_GAIN_RANGE[2]) * (rig.flapGain or rig.soundGain or 1))
	end
end

-- poses the bones; returns the body offset to put on top of where the model stands
function DinoMotion.step(rig, dt, speed)
	rig.t += dt
	local walk = math.clamp(speed / FULL_WALK_SPEED, 0, 1)
	local before = rig.phase
	local advance = speed * dt / (rig.height * STRIDE_PER_HEIGHT) * 2 * math.pi
	-- (2026-10-04, "지상공룡 타고다닐때 발자국 소리가 공룡 발에 따라서 안 나고 지맘대로 나": a ridden dino's legs cycled
	-- faster than its footfalls may sound (minStepGap), so the sounds skipped steps at random) with minStepGap the legs
	-- take longer strides instead of quicker ones: never more than one footfall each minStepGap, every one heard
	if rig.minStepGap then
		advance = math.min(advance, math.pi * dt / rig.minStepGap)
	end
	rig.phase = (rig.phase + advance) % (2 * math.pi)
	-- a foot comes down twice a cycle: where its swing is furthest forward (sin = 1 at a quarter past, see the Leg
	-- bones below; 2026-10-04: was at the cycle's start and middle, the legs passing each other, a quarter early)
	local QUARTER = math.pi / 2
	if speed >= STEP_MIN_SPEED and not rig.noFeet and not rig.winged
		and math.floor((before - QUARTER) / math.pi) ~= math.floor((before + advance - QUARTER) / math.pi) then -- (unwrapped)
		footfall(rig)
	end
	rig.attackLeft = math.max(0, rig.attackLeft - dt)
	local a = rig.attackLeft > 0 and math.sin(math.pi * (1 - rig.attackLeft / ATTACK_SECONDS)) or 0
	-- the roar: up fast, held, down again; the jaw trembles while it lasts
	rig.roarLeft = math.max(0, (rig.roarLeft or 0) - dt)
	local rp = 1 - rig.roarLeft / ROAR_SECONDS
	local r = rig.roarLeft > 0 and math.min(1, rp * 5) * math.min(1, (1 - rp) * 4) or 0
	local tremble = r * ROAR_TREMBLE * math.sin(rig.t * ROAR_TREMBLE_SPEED)
	-- grazing: blends in and out
	rig.grazeMix = (rig.grazeMix or 0) + ((rig.grazing and 1 or 0) - (rig.grazeMix or 0)) * math.min(1, dt * GRAZE_RATE)
	local g = rig.grazeMix
	local p, t = rig.phase, rig.t
	if rig.winged then -- its wings' downstroke (see the Wing bones below): a wingbeat while they really flap
		local flapAt = walk > 0 and t * WING_FLAP_SPEED or nil
		if flapAt and walk >= FLAP_MIN_WALK and rig.flapAt
			and math.floor((rig.flapAt - math.pi / 2) / (2 * math.pi)) ~= math.floor((flapAt - math.pi / 2) / (2 * math.pi)) then
			wingbeat(rig)
		end
		rig.flapAt = flapAt
	end
	local grazeBob = g * GRAZE_BOB * math.sin(t * GRAZE_BOB_SPEED + rig.seed)
	-- (2026-10-04, "야생 초거대 공룡은 꼬리가 나무에 걸리는건가 엄청흔드는데": the sway was sin(t × (2 + 2 × walk)), so
	-- every change in the walking speed moved it by t × that change - minutes into its life, a wild whip back and forth
	-- each step) the tail's own phase, going on at the speed of the moment
	rig.tailPhase = ((rig.tailPhase or 0) + dt * (2 + 2 * walk)) % (2 * math.pi)

	for _, e in ipairs(rig.bones) do
		local cf = CFrame.identity
		local name = e.name
		if e.limb == "Leg" then
			local ph = p + (LEG_PHASE[e.suffix] or 0)
			local swing = walk * LEG_SWING * math.sin(ph) -- + = the foot goes forward
			local knee = -walk * KNEE_BEND * math.max(0, math.cos(ph)) -- bends (lower leg back) while swinging forward
			if e.segment == 1 then
				cf = turn(e.x, swing)
			elseif e.segment == 2 then
				cf = turn(e.x, knee)
			else
				cf = turn(e.x, -FOOT_FOLLOW * (swing + knee)) -- keeps the foot nearly flat
			end
		elseif e.limb == "Wing" then
			local amp = walk > 0 and WING_FLAP * walk or WING_IDLE
			local speedFlap = walk > 0 and WING_FLAP_SPEED or WING_IDLE_SPEED
			cf = turn(e.z, e.side * amp * math.sin(t * speedFlap - (e.segment - 1) * 0.6))
		elseif e.limb == "Flipper" then
			cf = turn(e.x, FLIPPER_PADDLE * math.sin(t * FLIPPER_SPEED + (LEG_PHASE[e.suffix] or 0) - (e.segment - 1) * 0.5))
		elseif e.tail then
			local amp = TAIL_SWAY * (0.5 + 0.5 * walk)
			cf = turn(e.y, amp * math.sin(rig.tailPhase - e.tail * TAIL_WAVE))
				* turn(e.x, walk * TAIL_LIFT * math.sin(2 * p - e.tail * TAIL_WAVE))
		elseif name == "Hips" then
			cf = turn(e.z, walk * HIP_ROLL * math.sin(p))
		elseif name == "Spine" then
			cf = turn(e.x, BREATH * math.sin(t * BREATH_SPEED)) * turn(e.y, walk * SPINE_SWAY * math.sin(p))
		elseif name == "Neck" then
			local nod = walk * NECK_NOD * math.sin(2 * p + 0.6)
				+ (1 - walk) * IDLE_NOD * math.sin(t * IDLE_NOD_SPEED + rig.seed)
			rig.nod = nod
			cf = turn(e.x, nod - ATTACK_NECK * a + ROAR_NECK * r - GRAZE_NECK * g)
		elseif name == "Head" then
			local idle = 1 - 0.7 * walk
			cf = turn(e.y, HEAD_LOOK * idle * math.sin(t * HEAD_LOOK_SPEED + rig.seed))
				* turn(e.z, HEAD_TILT * idle * math.sin(t * 0.5 + rig.seed * 2))
				* turn(e.x, -HEAD_KEEP * (rig.nod or 0) - ATTACK_HEAD * a + ROAR_HEAD * r + tremble - GRAZE_HEAD * g + grazeBob)
		elseif name == "Jaw" then
			cf = turn(e.x, -ATTACK_JAW * a - ROAR_JAW * r - tremble - 0.05 * math.max(0, math.sin(t * 1.3 + rig.seed))
				- g * GRAZE_JAW * (0.5 + 0.5 * math.sin(t * GRAZE_CHEW_SPEED)))
		end
		e.bone.Transform = cf
	end

	local bob = BODY_BOB * rig.height * walk * math.abs(math.sin(p))
	local offset = CFrame.new(0, bob, -math.min(ATTACK_LUNGE * rig.height, ATTACK_LUNGE_MAX) * a)
		* CFrame.Angles(BODY_ROCK * walk * math.sin(2 * p) + ROAR_REAR * r, 0, 0)
	if not rig.hasBones then -- a waddle and a forward tilt stand in for the bones
		offset *= CFrame.Angles(-NO_BONES_ATTACK_TILT * a + ROAR_REAR * r + tremble - GRAZE_TILT_NO_BONES * g - grazeBob, 0,
			NO_BONES_WADDLE * walk * math.sin(p))
	end
	return offset
end

-- a pterosaur in the sky (see the top); returns the body offset like step
function DinoMotion.fly(rig, dt)
	rig.t += dt
	if not rig.flyUntil then
		rig.flying, rig.flyMix, rig.beat = true, 1, rig.seed
		rig.flyUntil = rig.t + FLY_FLAP_SECONDS[1] + math.random() * (FLY_FLAP_SECONDS[2] - FLY_FLAP_SECONDS[1])
	end
	if rig.t >= rig.flyUntil then -- flap <-> glide
		rig.flying = not rig.flying
		local range = rig.flying and FLY_FLAP_SECONDS or FLY_GLIDE_SECONDS
		rig.flyUntil = rig.t + range[1] + math.random() * (range[2] - range[1])
	end
	local want = rig.flying and 1 or 0
	rig.flyMix += (want - rig.flyMix) * math.min(1, dt * FLY_MIX_RATE)
	local mix = rig.flyMix
	local before = rig.beat
	rig.beat += dt * FLY_FLAP_SPEED * (0.4 + 0.6 * mix) -- the beat slows as it settles into a glide
	local beat = rig.beat
	-- (once a beat, as the wings start down: sin(beat) at its top)
	if mix >= FLAP_MIN_MIX
		and math.floor((before - math.pi / 2) / (2 * math.pi)) ~= math.floor((beat - math.pi / 2) / (2 * math.pi)) then
		wingbeat(rig)
	end

	for _, e in ipairs(rig.bones) do
		local cf = CFrame.identity
		local name = e.name
		if e.limb == "Wing" then
			local lag = (e.segment - 1) * FLY_TIP_LAG
			local amp = FLY_FLAP * (1 + (e.segment - 1) * FLY_TIP_GAIN) * mix
			local held = e.segment == 1 and FLY_GLIDE_WINGS * (1 - mix) or 0
			cf = turn(e.z, e.side * (amp * math.sin(beat - lag) + held))
		elseif e.limb == "Leg" then
			cf = turn(e.x, e.segment == 1 and FLY_LEG_TUCK or e.segment == 2 and FLY_KNEE_TUCK or 0)
		elseif e.tail then
			cf = turn(e.x, 0.08 * math.sin(beat - e.tail * TAIL_WAVE))
		elseif name == "Neck" then
			cf = turn(e.x, -0.06 * mix * math.sin(beat + 0.5))
		elseif name == "Head" then
			cf = turn(e.y, 0.25 * math.sin(rig.t * HEAD_LOOK_SPEED + rig.seed))
		elseif name == "Jaw" then
			cf = turn(e.x, -0.05 * math.max(0, math.sin(rig.t * 1.3 + rig.seed)))
		end
		e.bone.Transform = cf
	end

	-- the body rises as the wings come down (sin falling) and dips as they go up
	local offset = CFrame.new(0, -FLY_BOB * rig.height * math.sin(beat) * mix, 0)
		* CFrame.Angles(FLY_PITCH * math.cos(beat) * mix, 0, 0)
	if not rig.hasBones then
		offset *= CFrame.Angles(0, 0, FLY_ROLL_NO_BONES * math.sin(beat) * mix)
	end
	return offset
end

return DinoMotion
