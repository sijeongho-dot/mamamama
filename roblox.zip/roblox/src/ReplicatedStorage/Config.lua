--[[
Config: every number of the game, taken from docs/design.md. Game code never writes a number
itself; it reads it from here (see CLAUDE.md). The section names follow the design doc.

Units: money = game money, time = seconds, distance = studs, Robux prices are the design's drafts.
Chances: fields named ...Percent are percentages (12.5 = 12.5%); other chances, multipliers and
bonuses are fractions (0.3 = 30%). Level tables are arrays indexed by level (index 1 = level 1).
The whole table is frozen at the end, so nothing can change it at runtime.

Values the design does not give are marked "-- 임시값" (a placeholder until the design decides).
]]

local Config = {}

-- ---------------------------------------------------------------------------
-- Game overview, map
-- ---------------------------------------------------------------------------

Config.Server = {
	MaxPlayers = 8,
	LowPopulationMaxPlayers = 3, -- at or below this, central keys spawn slower (Keys.LowPopulationSpawnInterval)
}

Config.Map = { -- 1.5 times the first layout (roblox/MapBuilder.lua builds this)
	Radius = 760, -- (was 960) the wall; bases pulled in, so less empty land behind them
	KeyZoneRadius = 30,
	MineralRingInner = 45,
	MineralRingOuter = 360,
	BaseCount = 8,
	BaseDistance = 470, -- (was 690) the base fronts close to the battlefield edge again (about 20 studs of grass)
	PlotWidth = 210,
	PlotDepth = 165,
	EntranceWidth = 15, -- the gap in a plot's front fence (roblox/MapBuilder.lua ENTRANCE_W)
	DefenseTrackDiameter = 80, -- about
	FarmFieldWidth = 90,
	FarmFieldDepth = 66,
}

-- ---------------------------------------------------------------------------
-- Defense
-- ---------------------------------------------------------------------------

Config.Defense = {
	Idle = { -- auto hunting while online; time away pays a share of it (Config.Rewards.Offline)
		-- (2026-10-01: 6 a second and up to 60 filled the arenas with fossils; every one is drawn and sent
		-- to the phones nearby, and they stalled. Now fewer, each paying 3 times as much: the same money)
		-- (then 4 and 40, half the money each: "fewer fossils are less fun to watch"; the phones only get
		-- the nearby bases' events now and move far models less often)
		SpawnPerSecond = 4,
		MaxOnTrack = 40, -- spawning pauses when full, no penalty
		-- 임시값 (2026-10-01, "at LV 100 the fossils hardly die, the fun cools"): idle fossils have this
		-- share of the level's health (Formulas.monsterHealth); the promotion fight keeps all of it. LV 100
		-- with 8 mythic dinos (big, Lv 5, farm +100%): about 1 kill a minute → about 90 (the track spawns 240)
		HealthShare = 0.2,
	},
	Promotion = { -- 승급전
		Duration = 60,
		SpawnPerSecond = 6, -- 임시값 (2026-10-01: was 5, too easy)
		SpawnRamp = { First = 1, PerLevel = 1 }, -- 임시값
		BossAppearsAt = 40, -- seconds after the start; it must die in the remaining 20 seconds
		-- (2026-10-06, "길 처음 게이트에서 화석 나오고 끝 게이트에서 사라지고, 못잡고 사라진 애들이 승급전에 또 실패요소") 임시값
		Lives = 20,
		LeakLives = 2, -- 임시값
		FossilHealth = 0.6, -- × a fossil's health in a fight (not the boss's): one pass by the dinos, not lap after lap. 임시값
		Gauge = { KillsBase = 20, KillsPerLevel = 3, KillsMax = 300, RetryShare = 1, SaveEvery = 5,
			Crowd = { Base = 3, PerLevel = 2, Max = 40, PerSecond = 6, Speed = 1.35, SpeedRampLevels = 5, SprinterEvery = 3, SprinterFrom = 3, SprinterRamp = false },
			WarnSeconds = 3, NearMiss = { Crowd = 3, Boss = 0.2 }, AirshipBudget = 6, AirshipOffset = 2.5, AirshipHealth = { From = 0.15, To = 0.45, Levels = 20 }, AirshipSplit = { Count = 3 } }, -- 임시값
		RetryCooldown = 3, -- after a failure (2026-10-01: was 180, "retry after a minute"; 2026-10-05: 60 → 10, the friction pass)
		-- a won promotion pays keys straight into the save: KeysBase + 1 per KeysEveryLevels levels − RoadKeys, and a
		-- 🎁 box of the first Milestones grade that fits (the arena feeds the draws too, not only the altar). 임시값
		KeysBase = 3,
		KeysEveryLevels = 10,
		RoadKeys = 1, -- 임시값
		Milestones = { { Every = 50, Grade = "Gold" }, { Every = 10, Grade = "Silver" } }, -- the first that fits
		BoxNames = { Normal = "🎁 공룡 상자", Silver = "🎁 은 상자", Gold = "🎁 황금 상자" },
		FirstWins = { -- 임시값
			{ Level = 3, GuaranteedRarity = "Rare" },
			{ Level = 4, SpecialKeys = { Silver = 1 } },
			{ Level = 5, SpecialKeys = { Silver = 2 } },
			{ Level = 6, Keys = 5, LuckMinutes = 10 },
			{ Level = 7, Keys = 6, LuckMinutes = 10 },
			{ Level = 8, Keys = 7, LuckMinutes = 10 },
			{ Level = 9, Keys = 8, LuckMinutes = 10 },
			{ Level = 10, SpecialKeys = { Gold = 1 } },
		},
		-- (2026-10-05, "이번에 어떤 점이 가장 부족했는지 평가해서 거기 통과할때까지 올려주는거야") a lost fight's weakest
		-- point (Formulas.promoWeakness, on the 🩺 board): "crowd" lost with fewer than AreaShareGood of the dinos hitting
		-- many at once → 범위 공격; lost to the boss with none of its weakness, or SameShareBad or more of its own attribute
		-- → 상성. 임시값
		Advice = { RequestCooldown = 1, CandidateLimit = 8, MinRoleStrengthShare = 0.25, AreaShareGood = 0.4, SameShareBad = 0.5, ImmuneShareBad = 0.5, CrowdPerDino = 13 }, -- 임시값
	},
	-- (2026-10-02, "전체적인 난이도가 과금유저에게도 게임을 즐기고 싶게 만드는가" → "무한 도전 + 주간 랭킹") ♾️ 무한 도전:
	-- on the player's own defense field, fossils come in waves of WaveSeconds, SpawnPerSecond of them, each
	-- wave HealthGrowth times as tough as the last (wave 1: HealthStart), until more than FailMonsterCount
	-- are on the track. The score is the waves cleared; it never changes the defense level and pays no kill
	-- money (Formulas.challengeHealth; DefenseLogic.startChallenge). No waiting: try again any time. 임시값
	-- Tuned (DefenseLogic sim): 3 young rare Lv5 ~ wave 3, 8 big legendary Lv20 (+100%) ~ 28, 16 primordial golden
	-- Lv100 (+500%) ~ 65 (each wave 6 s: about 6-7 minutes at the top).
	LiveDamageEvery = 0.5,
	Synergies = { Predator = 0.05, Guardian = 0.05, Sky = 0.05 },
	Challenge = {
		WaveSeconds = 6,
		SpawnPerSecond = 5,
		Lives = 40, -- 임시값
		HealthStart = 100,
		HealthGrowth = 1.15,
		-- this week's best reaching these waves pays at once, once a week (Config.Rewards' reward
		-- format: Keys, SpecialKeys, MoneyChests); 임시값
		Milestones = {
			{ Wave = 5, Reward = { Keys = 3 } },
			{ Wave = 10, Reward = { SpecialKeys = { Silver = 2 } } },
			{ Wave = 20, Reward = { SpecialKeys = { Gold = 1 }, MoneyChests = 1 } },
			{ Wave = 30, Reward = { SpecialKeys = { Gold = 2 } } },
			{ Wave = 45, Reward = { SpecialKeys = { Ruby = 1 } } },
			{ Wave = 60, Reward = { SpecialKeys = { Diamond = 1 } } },
		},
		-- last week's all-server rank pays when the player comes back in the new week (the first that fits); 임시값
		RankRewards = {
			{ Top = 1, Reward = { SpecialKeys = { Rainbow = 1 } } },
			{ Top = 3, Reward = { SpecialKeys = { Diamond = 2 } } },
			{ Top = 10, Reward = { SpecialKeys = { Diamond = 1 } } },
			{ Top = 100, Reward = { SpecialKeys = { Ruby = 1 } } },
		},
		-- (2026-10-04, "주간 랭킹 보상도 있어야겠지 주 새로시작할때마다") everyone else who cleared a wave last week
		-- (outside the rows above) gets this when the new week starts. 임시값
		PlayReward = { SpecialKeys = { Silver = 1 } },
		-- (2026-10-02, "디펜스 전략의 재미" → 주간 도전 규칙) one rule a week, the same on every server (Rules[week %
		-- #Rules + 1], RewardLogic.weekNumber): KindChance × a fossil kind's chance (Defense.Kinds); Resist: every
		-- fossil carries that attribute, so that attribute's dinos do half (like the boss's own). Text: the window's line. 임시값
		Rules = {
			{ Id = "Fast", Name = "💨 빠른 화석 주간", Text = "빠른 화석이 3배 자주, 더 일찍 나와요", KindChance = { Fast = 3 } },
			{ Id = "Fire", Name = "🔥 불 화석 주간", Text = "이번 주 화석은 모두 🔥 불! 🔥 공룡은 약해져요", Resist = "Fire" },
			{ Id = "Armored", Name = "🛡️ 단단한 화석 주간", Icon = "🛡️", Text = "단단한 화석이 3배 자주, 더 일찍 나와요", KindChance = { Armored = 3 } },
			{ Id = "Water", Name = "💧 물 화석 주간", Text = "이번 주 화석은 모두 💧 물! 💧 공룡은 약해져요", Resist = "Water" },
			{ Id = "Swarm", Name = "🐜 떼 화석 주간", Text = "떼 화석이 3배 자주, 더 일찍 나와요", KindChance = { Swarm = 3 } },
			{ Id = "Electric", Name = "⚡ 전기 화석 주간", Text = "이번 주 화석은 모두 ⚡ 전기! ⚡ 공룡은 약해져요", Resist = "Electric" },
			{ Id = "Ice", Name = "❄️ 얼음 화석 주간", Text = "이번 주 화석은 모두 ❄️ 얼음! ❄️ 공룡은 약해져요", Resist = "Ice" },
			{ Id = "Earth", Name = "⛰️ 대지 화석 주간", Text = "이번 주 화석은 모두 ⛰️ 대지! ⛰️ 공룡은 약해져요", Resist = "Earth" },
			{ Id = "Poison", Name = "☠️ 독 화석 주간", Text = "이번 주 화석은 모두 ☠️ 독! ☠️ 공룡은 약해져요", Resist = "Poison" },
		},
		StoreName = "ChallengeWeek_v5", -- OrderedDataStore per week: StoreName .. "_" .. week, UserId -> best waves
		Top = 10, -- how many the all-server list shows
		RankRead = 100, -- how far down last week's list is read for the rank rewards
	},
	Boss = {
		SizeMultiplier = 4.5, -- (was 2.5) drawn this many times as big as a normal fossil (display only)
		-- × a normal monster's health: HealthMultiplier at LV 1, + HealthMultiplierPerLevel a level, at most
		-- HealthMultiplierMax (Formulas.bossHealthMultiplier). 임시값 (2026-10-01: was 6 at every level; three
		-- common dinos still get to LV 5, rare ones to LV 11, tools/tests/defense_logic_test.lua)
		-- (2026-10-03 balance check: was 6 + 0.35 a level; only 27% of three-common teams and 13% of the teams a new
		-- player has after the tutorial (rare water + ice + one more) beat the LV 1 boss in its 20 seconds — most of them
		-- without a carnivore never could. Now 86% and 78% (LV 2: 67%, LV 4: 38%); the most from LV 23, 4 levels sooner)
		-- (2026-10-04, "디펜스 초반이 좀 쉬운거 같은데" → ②: were 2 and 0.6, the max reached at LV 21; with the Welcome Rex a
		-- size smaller every early team stops 1-2 levels sooner: three common dinos LV 6, an epic and two common LV 10)
		HealthMultiplier = 3,
		HealthMultiplierPerLevel = 0.8,
		HealthMultiplierMax = 15, -- reached at LV 16 (2026-10-03: was LV 27; 2026-10-01: was 20; the promotions past LV 60 ended on the boss's timer)
		-- (2026-10-03, "속성에 맞춰서 디펜스 난이도가 도전욕구를 자극시키는지" → "알아서해": was 10; before the first rebirth
		-- (LV 1-30) only fire, ice and electric bosses came, and one team did for 10 levels) six bosses before a rebirth
		AttributeChangeEveryLevels = 5,
		-- 임시값: the boss's attribute by 10-level block (LV 1-10 the first, 11-20 the second, ...), then again
		AttributeOrder = { "Fire", "Ice", "Electric", "Water", "Earth", "Poison", "Neutral" },
		SameAttributeDamageMultiplier = 0.5, -- attacks of the boss's own attribute (and none of their effect)
		-- (2026-10-03, same request) every boss has a weakness: that attribute's hits do WeaknessDamageMultiplier and its
		-- effects come in full (not EffectShare; it still never freezes). Each attribute is one boss's weakness: water puts
		-- out fire, fire melts ice, earth grounds electric, electric shocks water, ice freezes earth, a plain hit beats
		-- poison and poison eats into the plain one. Something to look for in the draws, not only to leave out. 임시값
		Weakness = { Fire = "Water", Ice = "Fire", Electric = "Earth", Water = "Electric", Earth = "Ice", Poison = "Neutral",
			Neutral = "Poison" },
		WeaknessDamageMultiplier = 1.5,
		-- (2026-10-03, "보스의 경우나 저항력이 발생해서 100퍼로 발현이 안되거나 면역") the other attributes' effects on a boss
		-- at this share: burn, poison, wet time (slow and push: Attributes.Ice.BossSlowMultiplier, Earth.BossPushMultiplier);
		-- it never freezes (Ice.BossFreezeImmune). 임시값
		EffectShare = 0.5,
	},
	MonsterSpeed = 9,
	BossSpeed = 4,
	SpeedUp = { Fossils = 4 / 3, FromLevel = 2, Levels = 10, Boss = 2, BossFromLevel = 13, BossLevels = 18 }, -- 임시값
	LaneSpread = 3, -- 임시값: monsters walk up to this far either side of the road's middle, so a crowd fills the road
	-- (2026-10-01) spawned in turn in this many rows across the track (not at random), so the ones that
	-- come out close together walk side by side instead of on top of each other. 임시값
	Lanes = 5,
	LaneJitter = 0.3, -- studs of randomness within a row
	MonsterRadius = 1.5, -- 임시값: how far from its center a monster can be hit
	TickSeconds = 0.1, -- 임시값: the server moves monsters and runs attacks this often
	-- (2026-10-01) a player gets a base's fight events (DefenseEvents) only while within EventRange of
	-- its arena (or owns it), and stops past EventLeaveRange: every base's events to every screen ten
	-- times a second backed a phone's connection up until its buttons stopped answering. Clients draw
	-- monsters within 300 studs of the camera (DefenseView DRAW_DISTANCE). 임시값
	EventRange = 360,
	EventLeaveRange = 400,
}
-- (2026-10-06) the defense maps and the 🚩 fossil groups: ReplicatedStorage/ConfigMaps (Config.lua must stay under Roblox's
-- 200,000 characters a script), put into Config.Defense
for key, value in pairs(require(script.Parent:WaitForChild("ConfigMaps"))) do
	Config.Defense[key] = value
end

Config.Placement = {
	StartSlots = 4,
	-- (2026-10-01) no more slots from defense levels (was +1 every 25 levels, up to 15 at LV 300: "a
	-- reward that hands things out for nothing"): slots are bought, or come from rebirths, the collection
	-- and the game pass
	CollectionBonusSlots = 1, -- collection reward at 120 pairs (Farm.CollectionRewards)
	GamePassBonusSlots = 1, -- GamePasses.PlacementSlot
	MaxSlots = 36, -- 4 to start + 25 bought + 1 collection + 1 game pass + 5 from rebirths
	SignRange = 12, -- 임시값: studs from the defense sign for its "➕ 공룡 자리 늘리기" prompt
	SlotUpgrade = { -- extra slots bought with game money at the defense sign; kept on rebirth
		Cost = { -- 임시값
			80000, 92000, 106000, 122000, 140000, 161000, 185000, 213000, 245000, 281000, 324000, 372000, 428000,
			492000, 566000, 651000, 749000, 861000, 990000, 1140000, 1310000, 1510000, 1730000, 1990000, 2290000,
		},
	},
	FootprintRadiusPerScale = 1.2, -- (was 0.8) footprint radius = size scale × 1.2, no overlaps (the dinos are drawn bigger)
	RangeBonusPerScale = 0.10, -- +10% range per 1 of size scale
	MeleeReachFromTrack = 4.5, -- carnivore, herbivore, armored
	RangedRange = 18, -- sky, sea
	PresetCount = 3,
	-- a unit's reach from its own center: melee = the road's edge is within MeleeReachFromTrack of the unit's edge;
	-- ranged = RangedRange. Both × (1 + RangeBonusPerScale × (scale − 1)).
	EditRange = 80, -- 임시값: studs from the arena center within which the owner can place and remove dinos
}

-- ---------------------------------------------------------------------------
-- Minerals
-- ---------------------------------------------------------------------------

Config.Minerals = {
	-- (was 190, then 570 on 750 spawn points; 2026-10-02, "배틀필드에는 알록달록하게 미네랄 더 채워놔봐 … 너무
	-- 휑해": 880 on 1,100 points, and the grades a little more even below: about 1.7 times as many purple and red ones
	-- out, each node worth about the same on average (+2%), tools/income_sim.py). 임시값
	MaxOnServer = 880,
	RespawnDelay = 2, -- (was 5) seconds before a mined-out node comes back somewhere
	-- 임시값 (2026-10-01, "crystals come back over time and go too", "a tester mined out the minerals they
	-- wanted and can't find more"): a node nobody is mining goes after Lifetime seconds (a random time in
	-- the range) and a new one is rolled somewhere, so the ring keeps changing; and a mined-out node's
	-- replacement comes within NearRespawnRadius studs of it when there is room (about the same depth: about the same
	-- odds of rare grades and big sizes), so the part of the ring a player works stays stocked
	Lifetime = { 300, 600 },
	NearRespawnRadius = 120,
	Home = { Grade = "Droplet", Size = "Chunk", Count = 3, RespawnSeconds = 8, -- 임시값
		Spots = { { -84, 47 }, { -70, 51 }, { -56, 47 }, { -86, 56 }, { -62, 56 }, { -46, 52 }, { -78, 40 } } },
	Grades = { -- 임시값
		{ Id = "Droplet", Icon = "💧", Name = "물방울석", Color = "파랑", Rgb = { 70, 150, 255 }, Value = 25, RecommendedTier = 1, MinTier = 1, Hardness = 10,
			ChancePercent = 43, Band = { 0.5, 1 }, Where = "바깥" },
		{ Id = "Sprout", Icon = "🌱", Name = "새싹석", Color = "초록", Rgb = { 90, 200, 90 }, Value = 55, RecommendedTier = 3, MinTier = 3, Hardness = 17,
			ChancePercent = 30, Band = { 0.4, 0.8 }, Where = "바깥" },
		{ Id = "Grape", Icon = "🍇", Name = "포도석", Color = "보라", Rgb = { 150, 90, 220 }, Value = 120, RecommendedTier = 5, MinTier = 5, Hardness = 29,
			ChancePercent = 15, Band = { 0.22, 0.75 }, Where = "가운데" },
		{ Id = "Strawberry", Icon = "🍓", Name = "딸기석", Color = "빨강", Rgb = { 235, 70, 80 }, Value = 250, RecommendedTier = 7, MinTier = 7, Hardness = 48,
			ChancePercent = 7.5, Band = { 0.08, 0.5 }, Where = "안쪽" },
		{ Id = "Sunlight", Icon = "☀️", Name = "햇빛석", Color = "노랑", Rgb = { 255, 215, 60 }, Value = 730, RecommendedTier = 10, MinTier = 10, Hardness = 106,
			ChancePercent = 3.5, Band = { 0, 0.3 }, Where = "제단 가까이" },
		{ Id = "Starlight", Icon = "✨", Name = "별빛석", Color = "색순환", Rgb = { 255, 255, 255 }, Value = 2100, RecommendedTier = 13, MinTier = 13, Hardness = 233,
			ChancePercent = 1, MaxOnServer = 4, Band = { 0, 0.15 }, Where = "제단 가까이" },
	},
	LevelValueGrowth = 1.008, -- 임시값
	LevelValueGrowthAfter = { FromLevel = 480, Growth = 1.0165 }, -- 임시값
	-- deposit value = grade value × ValueMultiplier × the level multiplier; Hits = mining turns a node of scale 1 holds.
	-- ModelHeight is the design's height; nodes show DisplayScale times bigger.
	Sizes = {
		-- YieldMultiplier, WeightPercent (임시값): bigger nodes give more minerals a turn
		{ Id = "Shard", Name = "조각", ValueMultiplier = 1, Hits = 5, WeightPercent = 40, ModelHeight = 1.5, Model = "Ore_Shard",
			YieldMultiplier = 1 },
		{ Id = "Chunk", Name = "덩어리", ValueMultiplier = 1.5, Hits = 10, WeightPercent = 32, ModelHeight = 3, Model = "Ore_Chunk",
			YieldMultiplier = 1.5 },
		{ Id = "Boulder", Name = "바위", ValueMultiplier = 2.5, Hits = 20, WeightPercent = 20, ModelHeight = 5, Model = "Ore_Boulder",
			YieldMultiplier = 2 },
		{ Id = "Vein", Name = "거대 광맥", ValueMultiplier = 5, Hits = 40, WeightPercent = 8, ModelHeight = 7, Model = "Ore_Vein",
			YieldMultiplier = 3 },
	},
	-- 임시값 (2026-10-01, "rarer and bigger minerals more often further in, not none outside"): by how deep a
	-- node stands in the ring (0 by the key zone, 1 at the flags; Formulas.rollGrade / rollSize), the rarest
	-- grade is Grade times and the biggest size Size times as likely at the inner edge as at the flags
	-- (sunlight 7.5% inside, 2.5% outside; giant veins 5.7% / 1.9%). Center: the depth where the chances are
	-- the listed ones; 0.6 keeps the ring's average value as before (more spawn points lie outside)
	-- (2026-10-02, "중앙일수록 큰 광물이 많게": Size 4 → 15; by the key zone about 21% shards, 28% chunks, 30% boulders,
	-- 21% giant veins; at the flags 54 / 30 / 13 / 4)
	-- (2026-10-04: the grades keep to their Band now; Grade 6 → 1, no more lean inside a belt)
	InnerBias = { Grade = 1, Size = 15, Center = 0.6 },
	-- server-wide announcement and light beam from this grade, or for this size
	AnnounceFromGrade = 5,
	AnnounceSize = "Vein",
	DisplayScale = 2.6, -- 임시값: nodes are this much bigger than ModelHeight (2026-10-02, "광물들 모델링 자체를 좀 키워서 빽빽해보이게": was 2)
	RandomScaleMin = 0.8, -- 임시값: each node's own size within its size class ...
	RandomScaleMax = 1.25, -- 임시값: ... and its turns grow with it (Hits × scale)
	Gap = 1, -- 임시값: studs kept free between neighboring nodes (2026-10-02: was 2, packed closer)
	PlayerClear = 6, -- 임시값: a new node never comes up within this many studs past its edge of a player (or their mount) (2026-10-02, "크리스탈이 생성될때 유저가 거기있으면 끼는 문제")
	BagSlotsPerMineral = 1, -- any grade takes one bag slot
	Special = { Id = "Treasure", Name = "특급석", Rgb = { 255, 140, 40 }, Value = 0, RecommendedTier = 1, MinTier = 1, -- 임시값
		Hardness = 0.01, YieldDivisor = 1, MinTurnSeconds = 0.5, Number = 6, BagSlots = 50, FixedYield = 1,
		MaxUnits = 50, -- (2026-10-05, the bag up to about 50,000 now: at most this many from one, was bag ÷ 400 = 33 at most)
		BagKeys = { { Step = 10, Key = "Silver", Percent = 3 }, { Step = 20, Key = "Gold", Percent = 1 },
			{ Step = 30, Key = "Ruby", Percent = 0.3 }, { Step = 40, Key = "Diamond", Percent = 0.08 },
			{ Step = 50, Key = "Rainbow", Percent = 0.02 } },
		UnitMoney = 1500, -- 임시값
		Size = "Boulder", EverySeconds = { 2700, 4500 }, FirstSeconds = 900, LifeSeconds = 240 },
}

Config.Economy = {
	-- every upgrade price (the tables below, move speed, slots, rebirth) × this, through
	-- Formulas.upgradePrice. The tables were made for mining alone taking about 450 hours
	-- (tools/economy_sim.py); since then mining got better (value, speed, night) and chests and more
	-- arena money (which the tables never counted) came: about 2.5 times the money an hour
	-- (tools/income_sim.py). ×2.5 (all of it) felt far too dear to a player who mostly mines: ×1.5
	-- keeps a miner's waits near the plan and makes the other sources feel like a real speed-up
	-- (base content about 270 hours; 2026-09-30, 임시값)
	-- (2026-10-01: 1.5 → 1.7 with the minerals worth ×1.5: earning got easier; then 2.5: a tester had
	-- everything far too soon, "shop and slot prices too low") 임시값
	-- (2026-10-04, "상점 가격들 너무 싼거 있으면 가격 조정해봐": tools/income_sim.py had the base content at 276 hours of
	-- the plan's 450) 2.5 → 4 with LatePriceGrowth 4.5 → 2.6: the first and middle prices up (×1.6, ×1.25), the last
	-- the same (×14.4, was ×13.75); 276 → about 320 hours, the longest wait for one upgrade still 2.3 hours
	-- (2026-10-04, "돈 벌기 조금 쉬운거 같기도?": earning is ×11.8 the plan's against prices ×4) 4 → 5 with LatePriceGrowth
	-- 2.6 → 2.0: the first prices ×1.25, the middle ×1.14, the last about the same (×15); 320 → about 351 hours, the
	-- longest wait for one upgrade still 2.3 hours
	UpgradePriceScale = 5,
	RebirthPriceScale = 0.625,
	-- 임시값 (2026-10-01, "later prices should climb more, not impossibly"): the shop's tracks (pickaxe,
	-- power, speed, bag, slap, move speed) cost more the further along: × (1 + LatePriceGrowth ×
	-- progress^LatePriceCurve): the first ones as before, the middle ×2.1, the last ×5.5 (the longest wait
	-- for one upgrade stays under the design's 2.5 hours, tools/income_sim.py)
	-- (Formulas.latePriceMultiplier). Slots and rebirth keep their own tables
	LatePriceGrowth = 2.0, -- (2026-10-01: was 2, "the base content got short, make the mid-late game take longer"; 2026-10-04: 4.5 → 2.6 → 2.0)
	LatePriceCurve = 2,
	LevelGrowth = 1.0165, -- 임시값
	RewardGrowth = { -- 임시값
		{ FromLevel = 1, Growth = 1.0262 },
		{ FromLevel = 130, Growth = 1.0175 },
		{ FromLevel = 530, Growth = 1.0231 },
		{ FromLevel = 730, Growth = 1.0165 },
	},
}

Config.Mining = {
	Range = 8, -- 임시값: studs from the node's edge to the player
	TurnSeconds = 1.6, -- 임시값
	HardnessExponent = 1, -- 임시값
	MinTurnSeconds = 0.25, -- 임시값
	ShortestTurn = 0.2, -- 임시값
	-- (2026-10-04, "본게임에서 광질 조금 하다 가던데": with the first pickaxe a green stone next to the blue ones took 45 s a
	-- turn, the button stood on whichever was nearest, and a notice that kids don't read said so) a turn longer than this
	-- (the pickaxe alone: Formulas.mineSeconds) can't be started: the button shows 🔒 and the recommended pickaxe, and
	-- points at a mineral that can be mined; the server says no too (Formulas.mineLocked). Was SlowNoticeSeconds: a
	-- notice, and the long turn went on. 임시값
	LockSeconds = 20,
	-- (2026-10-04, same) 🐣 a new player's first minutes in the game: every mining turn Speed times as fast while their
	-- play time (profile.PlaySeconds) is under Minutes (Formulas.rookieSpeed). Saves from before it had played. 임시값
	Rookie = { Minutes = 15, Speed = 3 },
	-- 임시값: each mineral mined may hold a key, the chance = its money value (at LV 1) × KeyFindShare ÷ the shop
	-- key's price at the player's level (so keys found are about KeyFindShare of the mined money's worth
	-- in keys at every level, pricier minerals more often). Found keys ride in the bag (safe: a slap
	-- doesn't spill them) and count at the deposit bin like keys brought home (Formulas.bankKeys: × the
	-- level's home value, maybe a better grade)
	-- (2026-10-01, "testers hardly mine") a 대박 광물 (jackpot): any finished turn may, ChancePercent, pay
	-- MoneyChests treasure chests' worth at once (Formulas.jackpotMoney, safe: straight into the money),
	-- Keys keys into the bag (counted at the deposit bin like found keys), and SilverChancePercent a
	-- silver key saved at once. Everyone nearby sees the burst. 임시값
	Jackpot = { ChancePercent = 0.3, MoneyChests = 6, Keys = 2, SilverChancePercent = 30 },
	BagKeyBonus = 0.012, -- 임시값
	KeyFindShare = 0.3, -- (2026-10-07: 0.225 → 0.3 with the minerals worth ×0.75: as many keys found as before; 0.45 → 0.225 when the minerals got worth ×2: as many keys found as before;
	-- the level multiplier is left out of the chance)
	-- (2026-10-01: 0.25 → 0.5, then 0.3 with the minerals worth ×1.5, then 0.36 when the altar's
	-- rare keys came twice as often: the altar 1.3-2.4 times mining's keys; 0.45 when the shop key doubled, 2026-10-01)
}

Config.Deposit = {
	Range = 12, -- 임시값: studs from the player's own deposit bin
	AutoCheckSeconds = 0.5, -- 임시값
}

Config.HomeTeleport = { -- the "기지로" button: from anywhere to the player's own base
	Delay = 1, -- seconds after pressing (2026-10-05: was 3)
	Cooldown = 5, -- 임시값: seconds between uses (2026-10-05: was 10)
}

Config.Shop = {
	Range = 15, -- 임시값: studs from the player's own shop
}

-- development stage limits (docs/design.md 개발 순서)
Config.Stage = {
	MineralGrades = { "Droplet", "Sprout", "Grape", "Strawberry", "Sunlight", "Starlight" }, -- all open
	PickaxeMaxTier = 15, -- all open
}

-- ---------------------------------------------------------------------------
-- Bag: capacity = 40 × (4096 / 40)^((level − 1) / 29) rounded (40 → 4,096): roomy from the start,
-- the last ones hold a long mining run; costs from tools/economy_sim.py (the base content takes about 450 play hours)
-- ---------------------------------------------------------------------------

Config.Bag = {
	LevelsPerLook = 5,
	Looks = { "Bag_Cloth", "Bag_Leather", "Bag_Miner", "Bag_DinoEgg", "Bag_RoboTank", "Bag_Dimension" },
	Capacity = {
		40, 47, 55, 65, 76, 89, 104, 122, 143, 168,
		197, 232, 272, 319, 374, 438, 514, 603, 708, 830,
		974, 1142, 1340, 1572, 1844, 2163, 2537, 2977, 3492, 4096,
	},
	Cost = { -- cost to reach that level; level 1 is given (tools/economy_sim.py)
		0, 170, 230, 790, 1500, 5900, 11000, 31000, 62000, 210000,
		220000, 240000, 250000, 380000, 390000, 410000, 420000, 460000, 480000, 500000,
		520000, 710000, 720000, 760000, 780000, 850000, 890000, 940000, 970000, 1100000,
	},
	ResetsOnRebirth = false, -- (2026-10-01: rebirth keeps the bag)
}

-- ---------------------------------------------------------------------------
-- Keys, battlefield, egg bomb
-- ---------------------------------------------------------------------------

Config.Keys = {
	HomeCheckInterval = 0.5, -- 임시값: seconds between checks for carried keys brought home
	-- (2026-10-07) a key brought home is one key (each has HomeUpgradePerLevel × (LV − 1) chance, at most HomeUpgradeMax,
	-- to come home one grade up); HomeValue × (1 + HomeValuePerLevel × (LV − 1)) is a key's worth for the key packs
	-- and the keys found in minerals. 임시값
	HomeValue = 1.5,
	HomeValuePerLevel = 0.006, -- (was 0.01: the altar outgrew everything at high levels)
	HomeUpgradePerLevel = 0.002,
	HomeUpgradeMax = 0.2, -- 임시값
	-- a key carrier can't go into another player's base: pushed back out this many studs past its edge
	-- (checked every HomeCheckInterval; the carrier's own screen also shows a solid barrier, 임시값)
	OtherBasePushOut = 4,
	-- the key stall's exchange: this many keys of a grade become one of the next grade up. (2026-10-01,
	-- "make the exchange something to want": was 10 for every grade, while the shop's grades are 6-6.7
	-- times apart above silver, so trading up lost a third against the shop) ExchangeRates per grade: just
	-- over the shop's step (never cheaper to buy low keys and trade them up than to buy the better key),
	-- ExchangeRate for any grade not listed. 임시값
	ExchangeRate = 10,
	ExchangeRates = { Normal = 10, Silver = 7, Gold = 7, Ruby = 7, Diamond = 7 },
	ExchangeMaxAtOnce = 100, -- exchanges in one press at most ("가능한 만큼")
	PriceBase = 50, -- key price = 50 × 1.014^(defense LV − 1)
	PriceGrowth = 1.0165, -- 임시값 (was 1.035, then 1.025, then 1.014: the shop key outgrew mining income; now it grows about as
	-- fast, so mining money buys about as many keys at every level; tools/income_sim.py)
	-- the shop sells keys at this many times the key price (kill rewards stay 5% of the key price);
	-- 임시값: raised a lot (2026-09-29 "열쇠상점 가격도 폭등", then ×1.5 so picking keys up earns more
	-- than mining, tools/income_sim.py): LV 1 normal key 750
	ShopPriceMultiplier = 30, -- (2026-10-01: was 15; also halves the keys found in minerals, Formulas.mineKeyChance)
	-- (2026-10-01, "경쟁 유도": fewer but bigger drops, the same keys an hour: 5 → 8 minutes, about 2 → 3.2
	-- keys a drop, at least 2, so even a plain drop is worth a fight; 임시값)
	-- (2026-10-03, "중앙 열쇠 드립량 충분한가" → "1번으로 바꿔": a plain drop was 2-3 minutes of mining, eight minutes
	-- apart; the fight over keys is the game's face, so it comes more often, each drop the same size)
	SpawnInterval = 300, -- (was 45, then 300, then 480) a central drop every 5 minutes
	LowPopulationSpawnInterval = 300, -- (was 600, then 300, then 480) the same on small servers
	-- every Every-th drop is a big one, announced WarnSeconds before to everyone ("⚡ 대박 드랍 30초 전!"),
	-- so players gather at the altar: Keys normal keys and one silver key for sure, besides the usual
	-- roll for a better grade (2026-10-01, 임시값; the drops' silver chance went down for it)
	BigDrop = { Every = 3, Keys = 12, WarnSeconds = 30 }, -- 임시값
	-- (2026-10-01, "more competition at the altar") 임시값:
	-- every central drop of 2 or more keys has one 👑 king key: its carrier wears a crown seen from anywhere
	-- on the map; brought home it counts Value normal keys (then as any key: × the home value). Not a draw
	-- grade (never saved as itself). (With it the drops a little smaller: DropCountPercent 45/25/13/7/4/3/1.5/1/0.5
	-- → 52/24/11/6/3/2/1/0.6/0.4 for 2-10 keys, BigDrop.Keys 5 → 4: the altar stays below mining,
	-- tools/income_sim.py; the carry bonus on top depends on play) ...
	King = { Id = "King", Name = "👑 왕 상자", Model = "Key_Gold", Rgb = { 255, 215, 0 }, Value = 5, Size = 4 },
	MeteorShower = { AtMinute = 0, Duration = 60, Keys = 40, Gold = 1, SpecialShare = 0.2, WarnSeconds = 30, DropGap = 120 }, -- 임시값
	-- (2026-10-03, "열쇠가진자가 너무 느려져서 튀기가 너무 힘들다": was 0.7) −15% while carrying keys. 임시값
	CarrySpeedMultiplier = 0.85,
	-- (2026-10-01, "carriers stepping on speed pads can't be caught") a speed pad gives a key carrier only
	-- this share of its extra speed, and a king key's carrier less (then "with no pads a king key can hardly
	-- be brought home": 0.3 / 0 → 0.5 / 0.35; a ×1.8 pad: ×1.4 / ×1.28, a chaser on it ×1.8). 임시값
	-- (2026-10-03: were 0.5 / 0.35, with the slower carry above) a ×1.8 pad: ×1.56 / ×1.4
	-- (2026-10-04, "열쇠 쟁탈도 지금 밸런스 괜찮은건지": with 850 pads out (was about 320 really) a chaser runs on one almost
	-- all the time: × 1.75 against a carrier's 0.85 × 1.525 = 1.30, 35% faster, more than the 18% with no pads at all) a
	-- carrier now 0.85 × 1.675 = 1.42 on a pad, the chaser about 23% faster; a king key's carrier 0.5 → 0.7 임시값
	CarrierPadShare = 0.9,
	KingCarrierPadShare = 0.7,
	-- after launch: if the top 20% of players take 60%+ of the keys, carrying slows by 40% instead
	CarrySpeedMultiplierStrict = 0.6,
	StrictTopPlayerShare = 0.2,
	StrictKeyShare = 0.6,
	BountyBonusKeys = 3, -- hitting the server's #1 moves 3 of the #1's saved keys to the slapper, one for one ...
	BountyPairCooldown = 600, -- 임시값: ... once per 10 minutes for the same slapper and #1 ...
	BountyMoneyChests = 1, -- 임시값: ... and pays the slapper a treasure chest's worth at the slapper's own level ...
	BountyMoneyCooldown = 600, -- 임시값: ... at most every 10 minutes per slapper (saved: also across servers) ...
	BountyMoneyPerDay = 3, -- 임시값: ... at most this many times a day per slapper (saved) ...
	BountyMoneyPerTopHour = 2, -- 임시값: ... and one #1 pays out at most this many slappers' money an hour
	-- Roblox friends get no bounty from each other at all (no keys, no money): friends could take turns
	BountyCooldown = 30, -- 임시값: seconds before the same #1 can drop bonus keys again (no farming with a friend)
	MaxOnGround = 60, -- 임시값: central keys stop spawning while this many lie around
	DroppedLifetime = 60, -- 임시값: seconds a dropped key lies on the ground before it disappears
	DropperPickupDelay = 1.5, -- 임시값: seconds before the one who dropped keys can pick them up again
	-- (2026-10-01, the cheat check) a touch only picks a key up when the character's middle is this close to it
	-- (a cheat can make the server see touches from anywhere). 임시값
	PickupReach = 10,
	ScatterRadius = 6, -- 임시값: dropped keys land this far around the spot at most
	PickupRadius = 3, -- 임시값: a key is picked up by touching its 3-stud pickup box
	-- key grades: each opens its own draw, at most its MaxRarity (better rarities only from better keys;
	-- no MaxRarity: no limit; 2026-10-01), the best of as many draws of the grade
	-- below as the exchange takes (Formulas.keyPicks, 2026-10-02; at first 50, then 12 a grade) (silver = the best of 50 normal draws, gold = the best of 50 silver draws, ...; 2026-10-01,
	-- before: luck and a lowest rarity, and one better key was worth less than the 10 it was made of),
	-- sells at PriceMultiplier × the key price and turns up in central drops at
	-- DropChancePercent per drop (one of the dropped keys becomes this grade). All 임시값. (2026-10-01: about
	-- 1.5× more often: silver 5 → 7, gold 1 → 1.5, ruby 0.2 → 0.35, diamond 0.04 → 0.07, rainbow 0.005 → 0.009;
	-- then about twice again so a player really meets them: silver 10, gold 3, ruby 0.7, diamond 0.15, rainbow 0.02;
	-- then about ×0.7 per drop as drops got fewer keys (about 2, was 3): per key still a little more often than before)
	-- caps raised (2026-10-01) for gold/ruby/diamond so the design's pace (month golden, 3 months celestial,
	-- 6 months secret) can be reached: before, golden/celestial/secret came only from rainbow keys (100,000 keys)
	-- (2026-10-01, "make the better keys something to want, and the exchange too") MutationPercent: a draw
	-- with that key is a mutation (Config.Mutations: power ×1.2-1.5, its name on the dino) this often, on top
	-- of a mutation event's: so a better key is always worth more, even where the level holds its rarity at
	-- the grade below's (then its picks go to the size, Gacha.LockedSizePicks). 임시값
	-- (2026-10-02, "상위 등급 열쇠는 하위 등급 공룡이 안 나오는거 맞지? 열쇠 업그레이드 하는게 의미가 있어야지") FloorRarity:
	-- the key never brings less (its share below goes to it); each was where the best-of picks already left well
	-- under 1% below (silver: common 0.06%, ruby: epic 0.35%, diamond: mythic 0.04%), so the odds barely move. 임시값
	-- (2026-10-02, "열쇠 교환도 각성 단계에 맞춰서 구매 교환가능하게 하자") ShopRebirths: the awakenings needed to buy
	-- this grade at the key stall or exchange into it; keys from drops and rewards, and drawing with them, are
	-- never held back. 임시값
	Types = {
		{ Id = "Normal", Name = "열쇠", Model = "Key_Normal", PriceMultiplier = 1, MaxRarity = "Legendary", MutationPercent = 0 },
		-- (2026-10-01: drops every 8 minutes, was 5: per drop silver 7 → 4 (the big drops bring one for sure),
		-- gold 2 → 2.8, ruby 0.45 → 0.55, diamond 0.1 → 0.12, rainbow 0.013 → 0.016: the altar's keys an hour worth
		-- about as much as before (tools/income_sim.py: 126 normal keys' worth, was 122), silver keys 3 times as often)
		{ Id = "Silver", Name = "은 열쇠", Model = "Key_Gold", FloorRarity = "Uncommon", PriceMultiplier = 10, MaxRarity = "Mythic", MutationPercent = 1,
			DropChancePercent = 4, Rgb = { 200, 210, 225 } },
		{ Id = "Gold", Name = "황금 열쇠", Model = "Key_Gold", FloorRarity = "Epic", PriceMultiplier = 60, MaxRarity = "Rainbow", MutationPercent = 3,
			DropChancePercent = 2.8, Rgb = { 255, 200, 50 } },
		{ Id = "Ruby", Name = "루비 열쇠", Model = "Key_Gold", FloorRarity = "Legendary", ShopRebirths = 1, PriceMultiplier = 400, MaxRarity = "Celestial", MutationPercent = 8,
			DropChancePercent = 0.55, Rgb = { 235, 50, 80 } },
		{ Id = "Diamond", Name = "다이아 열쇠", Model = "Key_Gold", FloorRarity = "Transcendent", ShopRebirths = 2, PriceMultiplier = 2500, MaxRarity = "Primeval", MutationPercent = 15,
			DropChancePercent = 0.12, Rgb = { 120, 225, 255 } },
		{ Id = "Rainbow", Name = "무지개 열쇠", Model = "Key_Gold", FloorRarity = "Onyx", ShopRebirths = 5, PriceMultiplier = 15000, MutationPercent = 30,
			DropChancePercent = 0.016, Rgb = { 255, 120, 220 }, Rainbow = true },
	},
	-- 임시값: keys in one central drop: DropCountPercent[n] = the chance (%) of n keys, adds up to 100.
	DropCountPercent = { 0, 0, 0, 0, 0, 28, 22, 16, 11, 8, 6, 4, 2.5, 1.5, 1 },
}

Config.AltarBoxes = {
	MaxCarry = 1, -- 임시값
	HoldSeconds = 1.7, -- 임시값
	CarrySlowPerBox = 0.03, -- 임시값
	CarrySlowPerSize = 0.005, -- 임시값
	CarrySpeedMin = 0.6, -- 임시값
	KingChase = { Rarity = "Legendary", Size = "Giant" }, -- 임시값
	KingRgb = { 255, 215, 0 },
	RareFrom = "Mythic",
	LockNoticeGap = 3,
	FullNoticeGap = 5,
	EscapeNoticeGap = 8,
}

-- Speed pads: one at a time they appear at random spots out in the open (outside the bases, between
-- the key zone and the base fronts); the first to step on one runs faster for a moment and it is
-- gone. A player already sped up does not take another one (it stays for someone else). 임시값
Config.SpeedPads = {
	SpawnInterval = 0.1, -- (was 0.1, then 0.06, then 0.036) seconds between new pads (about Lifetime / SpawnInterval pads out at once)
	MaxOnField = 850, -- (was 330, then 500; 2026-10-04 "속도발판 갯수 좀 더 좀 더 늘리자") 임시값
	Candidates = 12, -- random spots tried for each new pad; the one farthest from the others wins (even spread)
	Lifetime = 90, -- (was 26, then 32) seconds a pad waits for someone before it disappears
	MultiplierMin = 1.5, -- each pad's speed multiplier, random in between
	MultiplierMax = 2.0,
	BoostSeconds = 3.1, -- how long the speed lasts ... (was 1, then 1.8, then 2.3, then 2.8; 임시값)
	CarryBoostSeconds = 3.4, -- (was 2, then 3) ... and while carrying keys, still a little longer (the key race is what the pads are for)
	Radius = 3, -- studs, the pad's size and how close counts as stepping on it
	EdgeMargin = 8, -- studs kept from the key zone and from the battlefield's edge (pads only on the battlefield)
}

-- Weather: rare and short. Every CheckInterval seconds of clear sky a roll may bring rain or a
-- thunderstorm for about a minute (the whole server, announced like a key drop); about once an hour
-- or so. While it lasts, defense kills pay DefenseMoneyMultiplier times as much. 임시값
Config.Weather = {
	CheckInterval = 300,
	-- (2026-10-01, "날씨 변경되기 3초전부터 카운팅 … 어린애들 단어로") every change is counted down first:
	-- (2026-10-13) the fossil witch says it, her note counting "3초 뒤!", "2초 뒤!", "1초 뒤!"
	-- (Config.Story.Explains.WeatherSoon), then the weather
	CountdownSeconds = 3,
	Types = {
		-- MiningYieldMultiplier / MiningSpeedMultiplier: minerals a turn, and turns that much faster;
		-- MoveSpeedMultiplier: everyone walks that much faster (임시값, 2026-09-30)
		-- (2026-09-30) a little more often: rain 5 → 7%, storm 2 → 3%, and the rainbow sky, rarest (1%, ×3);
		-- then twice as often again: rain 14%, storm 6%, rainbow 2% (임시값)
		{ Id = "Clear", Name = "맑음", Icon = "☀️", ChancePercent = 73, DefenseMoneyMultiplier = 1,
			MiningYieldMultiplier = 1, MiningSpeedMultiplier = 1, MoveSpeedMultiplier = 1 },
		{ Id = "Rain", Name = "비", Icon = "🌧️", ChancePercent = 14, DefenseMoneyMultiplier = 1.5,
			MiningYieldMultiplier = 2, MiningSpeedMultiplier = 2, MoveSpeedMultiplier = 2,
			MinSeconds = 70, MaxSeconds = 90, Rgb = { 130, 190, 255 } },
		{ Id = "Storm", Name = "천둥번개", Icon = "⛈️", ChancePercent = 6, DefenseMoneyMultiplier = 2,
			MiningYieldMultiplier = 2, MiningSpeedMultiplier = 2, MoveSpeedMultiplier = 2,
			MinSeconds = 70, MaxSeconds = 90, Rgb = { 200, 170, 255 } },
		-- (the Id is not "Rainbow": that is a key grade, and banners tell the two apart by it)
		{ Id = "RainbowSky", Name = "무지개", Icon = "🌈", ChancePercent = 2, DefenseMoneyMultiplier = 3,
			MiningYieldMultiplier = 3, MiningSpeedMultiplier = 3, MoveSpeedMultiplier = 3,
			MinSeconds = 70, MaxSeconds = 90, Rgb = { 255, 150, 220 } },
		-- (2026-10-01) weather lasts twice as long: 50-70 → 100-140 seconds (임시값)
		-- the aurora: rolled once at each nightfall (ChancePercent: 2 → 5% on 2026-10-01, about one night in 20,
		-- every 3 hours or so of play; clear 76 → 73 so they still add up to 100; the usual rolls
		-- never bring it), it lasts the whole night and brings the aurora boss (Config.Zombies.AuroraBoss).
		-- MinSeconds: at least this long even if the night has less left (Studio tests). 임시값
		{ Id = "Aurora", Name = "오로라", Icon = "🌌", ChancePercent = 5, NightOnly = true, DefenseMoneyMultiplier = 2,
			MiningYieldMultiplier = 2, MiningSpeedMultiplier = 2, MoveSpeedMultiplier = 1.5,
			MinSeconds = 40, MaxSeconds = 40, Rgb = { 120, 255, 200 } },
	},
}

-- (2026-10-02, "천둥번개 날씨에 번개치는 곳에 사람이나 좀비공룡 농장공룡 야생공룡들이 있으면 약간 튕겨나게")
-- storm lightning (Lightning service): while the weather is Storm, a bolt lands near a random player now and
-- then; the spot crackles WarnSeconds first (it can be dodged), then everyone within Radius flies PlayerStuds
-- away (nothing drops, no groggy), zombies are thrown like a slap, farm and wild dinos hop away and yelp.
-- All 임시값
Config.Lightning = {
	EverySeconds = { 3, 7 }, -- between strikes while it storms (one at a time, over the whole server)
	NearPlayer = { 4, 35 }, -- studs from the picked player the bolt lands (now and then right beside them)
	WarnSeconds = 0.8, -- the spot crackles this long before the bolt
	Radius = 8, -- studs from the bolt: players, zombies and dinos within are knocked
	PlayerStuds = 12, -- a light throw (a slap is 20-30)
	PlayerFlightSeconds = 0.6,
}

-- Pterosaur droppings: now and then one falls at a random player out in the open (a shadow marks
-- where it will land, so it can be dodged). Only a direct hit counts: that player is stuck for
-- StunSeconds. Nothing stays on the ground. 임시값
Config.Poop = {
	Interval = 12, -- (was 15) seconds between rolls
	ChancePercent = 60, -- (was 42) chance a roll drops one by day: about 3 a minute; none at night (the pterosaurs sleep; 임시값)
	ApproachSeconds = 2.5, -- 임시값: a pterosaur flies in this long before it lets go (seen coming)
	FallSeconds = 2.2,
	Height = 90, -- studs above the ground it falls from (the pterosaur flies at this height)
	MaxLead = 20, -- 임시값: studs ahead of a running player it aims at, at most
	MissRadius = 7, -- aimed up to this far off the player (and where they are heading)
	HitRadius = 2.5, -- studs from where it lands that count as a hit
	StunSeconds = 3,
}

Config.Battlefield = { -- attacks count only inside this radius, the orange band and flags MapBuilder
	-- draws around the center; the bases and all the land outside the flags are safe (Shared/SafeZones)
	Radius = 360,
}

Config.OpenArea = { -- 임시값
	StripHalfWidth = 70,
	Overlap = 4,
	AltarPast = 40,
	WildHalf = 34,
	WildSearch = 240,
	WildFieldGap = 16,
	CorridorHalf = 10,
	CorridorOut = 18,
	PushIn = 4,
}

Config.DayNight = { -- the day and night (DayNight service). 임시값
	DaySeconds = 420, -- 7 minutes of day ...
	NightSeconds = 180, -- ... then 3 of night (zombie dinos come out)
	NightMiningYield = 1.3, -- (was 1.5) at night minerals give this many times as much a turn ...
	NightMiningSpeed = 1.3, -- (was 1.5) ... and turns go this many times as fast (with the weather's, multiplied)
}

Config.Zombies = require(script.Parent:WaitForChild("ConfigZombies")) -- zombie dinos at night, the bosses (2026-10-04: its own module)

-- the next day's buff for the whole server after the night's boss is slapped down (Zombies service,
-- ReplicatedStorage attributes DayBuff / DayBuffEndsAt): lasts that whole day. 임시값
Config.DayBuffs = {
	Money = { Name = "💰 번 돈", Multiplier = 1.2 }, -- deposits, defense kills and treasure chests
	Defense = { Name = "⚔️ 디펜스 처치 보상", Multiplier = 1.3 },
	Mining = { Name = "⛏️ 채굴 양·속도", Multiplier = 1.3 },
}

-- (2026-10-02, design 2.9 일일 접속 보상; 개발 순서 11) attendance: the 7-day streak (a missed day starts it over)
-- and the days this month (kept when the streak breaks; a new month starts over). Days turn with
-- Config.Rewards.ResetOffsetHours. Kinds: Keys / SpecialKeys, KeyPriceTimes (money: the player's key price ×
-- this), LuckMinutes (the draw luck boost), GuaranteedRarity (a draw whose first dino is at least that),
-- ServerLuckMinutes (the whole server's luck × ServerLuckMultiplier, the player's name on the banner),
-- MonthDino (this month's attendance dino: MonthDinos[month], MonthDinoRarity, MonthDinoSize)
Config.Attendance = {
	-- (2026-10-02, "보상들이 출석을 유도할 만한가?" → stronger: each day a better key than a day of play gives
	-- for a few minutes, the 7th a ruby key and a legendary draw) 임시값
	Streak = {
		{ Keys = 5 },
		{ SpecialKeys = { Silver = 1 } },
		{ KeyPriceTimes = 10 },
		{ LuckMinutes = 30 },
		{ SpecialKeys = { Gold = 1 } },
		{ SpecialKeys = { Silver = 3 } },
		{ GuaranteedRarity = "Legendary", SpecialKeys = { Ruby = 1 } },
	},
	-- missing this many days in a row keeps the streak where it was (the next day comes next); more starts it
	-- again from day 1 (2026-10-02: a single missed day started it over). 임시값
	GraceDays = 1,
	Monthly = {
		{ Days = 7, SpecialKeys = { Ruby = 1 } }, -- 임시값 (the design's 30% slap skin coupon: no skins sold yet)
		{ Days = 14, ServerLuckMinutes = 10, SpecialKeys = { Gold = 2 } },
		{ Days = 21, SpecialKeys = { Ruby = 2 } }, -- (2026-10-02: a diamond key was worth ~35 h of play, more than the Robux ruby pack's keys)
		{ Days = 28, MonthDino = true },
	},
	ServerLuckMultiplier = 2, -- 임시값
	ServerLuckCrownMinutes = 10, -- 임시값: the crown over the player's head meanwhile
	-- this month's dino: only from attendance, marked 🗓️ for good (2026-10-02: was 영웅 · 성체, "not worth 28 days")
	MonthDinoRarity = "Legendary", -- 임시값
	MonthDinoSize = "Giant", -- 임시값
	-- 임시값: the species by month (January first); any species, set again each year
	MonthDinos = { "Allo", "Edmonto", "Nodo", "Pterodac", "Ichthyo", "Carno", "Styraco", "Gastonia", "Ornitho", "Tylo",
		"Giganoto", "Archelon" },
	PopupDelay = 6, -- seconds after joining before the window opens on 출석 (when something waits there)
}

Config.Rewards = { -- the extra rewards that bring players back and keep them playing (Rewards service,
	-- RewardLogic). A reward: { Keys = n, SpecialKeys = { Silver = n, ... }, MoneyChests = n (money:
	-- n treasure chests' worth at the player's level) }. All 임시값
	-- 임시값 (2026-10-01, "the day starts by English-speaking kids' time": was 9, midnight Korean time): days
	-- and weeks turn at 08:00 UTC, while American kids sleep (midnight-1 AM Pacific, 3-4 AM Eastern) and
	-- before school in Britain (8-9 AM); weeks on Monday
	ResetOffsetHours = -8,
	-- playtime gifts: each once a day, after this many minutes of play that day (sessions add up; a new
	-- day starts over; was once a session, which rejoining could repeat)
	-- (2026-10-01) further apart: was 5 / 10 / 20 / 30 / 45 / 60 minutes
	-- (2026-10-01) twelve gifts (was six), and the long sessions pay better keys
	Playtime = {
		{ Minutes = 10, Reward = { Keys = 1 } },
		{ Minutes = 25, Reward = { MoneyChests = 1 } },
		{ Minutes = 45, Reward = { Keys = 2 } },
		{ Minutes = 70, Reward = { SpecialKeys = { Silver = 1 } } },
		{ Minutes = 100, Reward = { MoneyChests = 2 } },
		{ Minutes = 140, Reward = { SpecialKeys = { Gold = 1 } } },
		{ Minutes = 180, Reward = { Keys = 3, MoneyChests = 1 } },
		{ Minutes = 220, Reward = { SpecialKeys = { Silver = 2 } } },
		{ Minutes = 270, Reward = { MoneyChests = 4 } },
		{ Minutes = 330, Reward = { Keys = 5, SpecialKeys = { Gold = 1 } } },
		{ Minutes = 400, Reward = { MoneyChests = 6 } },
		{ Minutes = 480, Reward = { SpecialKeys = { Ruby = 1 } } },
	},
	-- away from the game: Share of what the arena earns idle, for at most MaxHours, if at least
	-- MinMinutes and some dino is placed
	-- time away pays a share of the arena's idle money, less and less the longer away, nothing past
	-- MaxHours (2026-10-01, "helpful, but a long time away isn't paid in full": was 2 hours at half).
	-- Tiers: up to Hours since leaving, Share of the idle money. A whole day is worth about 4 hours of
	-- the arena, a night's sleep (8 h) 2.5. What waits uncollected never grows past one MaxHours' worth.
	-- (2026-10-02, "오프라인 대기 보상이 머니팩 보상보다 적어야 하지 않을까": a day away was 4.1 hours of the
	-- arena at its fullest, 1-2 times the 79 R$ money pack (45 minutes of all income) → 1.5 hours: a day away
	-- 36-72% of that pack, a night 1.1 hours, an hour away 0.25.)
	-- (2026-10-03, "오프라인 동안 번 돈이 자기 지금 디펜스로 버는 양에 비례해야지 너무 많이주는데"): "the arena's idle
	-- money" was every fossil the track spawns killed (4 a second), far more than the dinos really kill. Now it is
	-- the player's own: the money their arena really made a second while idle (no rank-up or challenge fight),
	-- over about the last RateMemoryMinutes of play, kept in the profile (Stats.IdleMoneyRate) once at least
	-- MinRateMinutes were watched; the shares below are of that.
	-- 임시값
	Offline = { MinMinutes = 5, MaxHours = 24, RateMemoryMinutes = 10, MinRateMinutes = 1,
		-- (2026-10-04, "디펜스 돈 보상이 조금 과한가 싶기도 하고. 오프라인 보상이 짭잘해서" → A: was 0.25 / 0.1 / 0.025, a
		-- night away 1.1 hours of the arena and a day 1.5; now 0.6 and 0.84)
		-- (2026-10-04, "오프라인 보상 조금 많은 거 아닌가": a night away paid 0.6 hours of the arena, a day 0.84) 0.1 / 0.03 /
		-- 0.01: a night 0.38 hours, a day 0.54
		Tiers = { { Hours = 2, Share = 0.1 }, { Hours = 8, Share = 0.03 }, { Hours = 24, Share = 0.01 } } },
	Daily = {
		Count = 4, -- missions a day (was 3; the pool grew from 9 to 18 kinds on 2026-10-01)
		-- (2026-10-01, "testers hardly mine") at least one of the day's missions is a mining one (Mining = true)
		Reward = { Keys = 2 }, -- each finished mission
		AllReward = { SpecialKeys = { Silver = 1 }, MoneyChests = 1 }, -- all of today's
		-- MinTier: (2026-10-04) given only to a player whose pickaxe tier is at least this when the day's set is drawn
		Pool = {
			{ Kind = "Mine", Target = 150, Mining = true, Unlock = "FieldEdge", Name = "⛏️ 광물 %d개 캐기" },
			{ Kind = "NightMine", Target = 50, Mining = true, Unlock = "FieldEdge", Name = "🌙 밤에 광물 %d개 캐기" },
			{ Kind = "Chests", Target = 2, Unlock = "FieldEdge", Name = "💰 보물상자 %d개 열기" },
			{ Kind = "KeysHome", Target = 3, Unlock = "Altar", Name = "🎁 선물상자 %d개 집에 가져가기" },
			{ Kind = "Fossils", Target = 200, Name = "🦴 화석 %d마리 처치하기" }, -- (was 300, then 100; 2 a second fewer fossils than at first)
			{ Kind = "Draws", Target = 5, Name = "🎰 뽑기 %d번 하기" },
			{ Kind = "Slaps", Target = 3, Unlock = "FieldEdge", Name = "👋 찰싹으로 %d번 날리기" },
			{ Kind = "Pads", Target = 15, Unlock = "FieldEdge", Name = "⚡ 속도 발판 %d번 밟기" },
			{ Kind = "Boss", Target = 1, Unlock = "Altar", Name = "👑 밤의 보스 좀비 쓰러뜨리기 %d번" },
			{ Kind = "Deposit", Target = 5, Mining = true, Unlock = "FieldEdge", Name = "💰 입금통에 %d번 입금하기" },
			-- (2026-10-04) only for a pickaxe that mines them (Grape locked below that: Config.Mining.LockSeconds)
			{ Kind = "RareMine", Target = 30, Mining = true, MinTier = 5, Unlock = "FieldInner", Name = "💎 포도석이나 더 좋은 광물 %d개 캐기" },
			{ Kind = "Promotion", Target = 1, Name = "👑 보스 웨이브 %d번 깨기" },
			{ Kind = "Enhance", Target = 2, Unlock = "Enhance", Name = "⬆️ 공룡 강화 %d번 하기" },
			{ Kind = "Upgrade", Target = 3, Unlock = "Training", Name = "💪 강화 %d번 하기 (훈련·곡괭이)" }, -- (2026-10-04: training counts)
			{ Kind = "WildRide", Target = 3, Unlock = "Wild", Name = "🦕 야생 공룡 %d번 올라타기" },
			{ Kind = "ZombieSlap", Target = 5, Unlock = "FieldEdge", Name = "🧟 좀비 공룡 %d마리 찰싹 날리기" },
			{ Kind = "Bell", Target = 2, Unlock = "Bombs", Name = "🔔 종 %d번 울리기" },
			{ Kind = "BigMineral", Target = 3, Mining = true, Unlock = "FieldEdge", Name = "⛰️ 큰 바위 광물 %d개 끝까지 캐기" },
			{ Kind = "Jackpot", Target = 1, Mining = true, Unlock = "FieldEdge", Name = "🌟 대박 광물 %d번 캐기" },
			{ Kind = "TrainMinutes", Target = 15, Unlock = "Training", Name = "💪 훈련장에서 %d분 훈련하기" }, -- (2026-10-04) 임시값
		},
	},
	-- the weekly key challenge: carried keys brought home this week (Monday to Sunday)
	Weekly = {
		Milestones = {
			{ Keys = 10, Reward = { Keys = 5 } },
			{ Keys = 25, Reward = { SpecialKeys = { Silver = 2 } } },
			{ Keys = 50, Reward = { SpecialKeys = { Gold = 1 } } },
			{ Keys = 100, Reward = { SpecialKeys = { Ruby = 1 } } },
		},
		-- (2026-10-01) more weekly challenges beside the keys: each counts a kind all week (the same
		-- kinds as the daily missions) and pays at each of its steps, one after another
		Challenges = {
			{ Kind = "Mine", Name = "⛏️ 광물 %d개 캐기", Steps = {
				{ Target = 500, Reward = { Keys = 3 } },
				{ Target = 1500, Reward = { SpecialKeys = { Silver = 1 } } },
				{ Target = 4000, Reward = { SpecialKeys = { Gold = 1 } } } } },
			{ Kind = "Fossils", Name = "🦴 화석 %d마리 처치하기", Steps = {
				{ Target = 1400, Reward = { MoneyChests = 2 } }, -- (was 2,000 / 6,000 / 15,000, then a third, now two thirds)
				{ Target = 4000, Reward = { SpecialKeys = { Silver = 1 } } },
				{ Target = 10000, Reward = { SpecialKeys = { Gold = 1 } } } } },
			{ Kind = "Chests", Unlock = "FieldEdge", Name = "💰 보물상자 %d개 열기", Steps = {
				{ Target = 5, Reward = { MoneyChests = 2 } },
				{ Target = 15, Reward = { Keys = 5 } },
				{ Target = 30, Reward = { SpecialKeys = { Gold = 1 } } } } },
			{ Kind = "Draws", Name = "🎰 뽑기 %d번 하기", Steps = {
				{ Target = 20, Reward = { Keys = 3 } },
				{ Target = 60, Reward = { SpecialKeys = { Silver = 2 } } },
				{ Target = 150, Reward = { SpecialKeys = { Gold = 1 } } } } },
			{ Kind = "Boss", Unlock = "Altar", Name = "👑 밤의 보스 %d번 쓰러뜨리기", Steps = {
				{ Target = 1, Reward = { MoneyChests = 3 } },
				{ Target = 3, Reward = { SpecialKeys = { Silver = 2 } } },
				{ Target = 7, Reward = { SpecialKeys = { Ruby = 1 } } } } },
			{ Kind = "Slaps", Unlock = "FieldEdge", Name = "👋 찰싹으로 %d번 날리기", Steps = {
				{ Target = 20, Reward = { Keys = 3 } },
				{ Target = 60, Reward = { SpecialKeys = { Silver = 1 } } },
				{ Target = 150, Reward = { SpecialKeys = { Gold = 1 } } } } },
			{ Kind = "Promotion", Name = "👑 보스 웨이브 %d번 깨기", Steps = {
				{ Target = 3, Reward = { Keys = 5 } },
				{ Target = 10, Reward = { SpecialKeys = { Gold = 1 } } } } },
			{ Kind = "WildRide", Name = "🦕 야생 공룡 %d번 올라타기", Steps = {
				{ Target = 10, Reward = { Keys = 3 } },
				{ Target = 30, Reward = { SpecialKeys = { Silver = 2 } } } } },
			-- (2026-10-01, "testers hardly mine") more for mining
			{ Kind = "RareMine", Unlock = "FieldInner", Name = "💎 포도석이나 더 좋은 광물 %d개 캐기", Steps = {
				{ Target = 150, Reward = { Keys = 3 } },
				{ Target = 500, Reward = { SpecialKeys = { Silver = 2 } } },
				{ Target = 1500, Reward = { SpecialKeys = { Gold = 1 } } } } },
			{ Kind = "Jackpot", Name = "🌟 대박 광물 %d번 캐기", Steps = {
				{ Target = 3, Reward = { MoneyChests = 3 } },
				{ Target = 10, Reward = { SpecialKeys = { Gold = 1 } } },
				{ Target = 25, Reward = { SpecialKeys = { Ruby = 1 } } } } },
			{ Kind = "Deposit", Name = "💰 입금통에 %d번 입금하기", Steps = {
				{ Target = 20, Reward = { Keys = 3 } },
				{ Target = 60, Reward = { SpecialKeys = { Silver = 2 } } } } },
			-- (2026-10-04) minutes of standing at a training station (Training) 임시값
			{ Kind = "TrainMinutes", Unlock = "Training", Name = "💪 훈련장에서 %d분 훈련하기", Steps = {
				{ Target = 60, Reward = { Keys = 3 } },
				{ Target = 180, Reward = { SpecialKeys = { Silver = 2 } } },
				{ Target = 420, Reward = { SpecialKeys = { Gold = 1 } } } } },
		},
	},
}

-- (2026-10-02, design 2.15 "시즌 패스") the season pass (Season service, SeasonLogic): a season is Days days from
-- StartDay (Config.Rewards' days; Monday 2026-09-28 = day 20724), weeks on Monday as the weekly challenges.
-- Playing fills season XP (Xp: minutes played, up to PlayMinutesPerDay a day; each reward claimed in the 🎁 / 📆
-- windows by its kind; each promotion won); a season starts at tier 1 (its rewards free at once, "1레벨은 무료로"),
-- then every XpPerTier XP is a tier more, Tiers in all. Each tier has a free
-- reward (Free) for everyone and a pass reward (Paid) for those with the season's pass (Products.SeasonPass,
-- bought again each season). Rewards: { Keys, KeyHours (Products.KeysPerHour's hours at the player's level),
-- SpecialKeys, MoneyChests, LuckMinutes (draw luck ×StarterMissions.LuckMultiplier), Bombs (that many of each
-- kind, up to Bombs.MaxHeld), Skin = true (the theme's season slap skin), Dino = true (the theme's dino at the
-- best open rarity DinoRarityBelowTop grades down, at least DinoMinRarity, DinoSize; marked 🏆) }.
-- Rewards reached but not taken when a season ends are given then. Themes go round by season.
-- Pace (tools/tests/season_logic_test.lua checks it): about 780 XP an active hour-a-day (60 min 120, 4 missions 240 + all 100,
-- attendance 50, weekly steps ~120, gifts ~60, promotions ~90): the last tier on day ~23; three 40-minute days
-- a week (~170 XP a day on average) reach tier ~9; three hours a day finish in ~16 days.
-- Pass value: 5 hours of keys, 14 gold, 4 ruby and a diamond key, a skin and a dino over the month: about
-- 5 times its 249 R$ in packs, only by playing the month. 임시값
Config.Season = {
	StartDay = 20724,
	Days = 28,
	Tiers = 30,
	XpPerTier = 600,
	Xp = {
		PlayMinute = 2, PlayMinutesPerDay = 120,
		-- a reward claimed (Rewards' kinds)
		Playtime = 20, Daily = 60, DailyAll = 100, Weekly = 80, WeeklyChallenge = 80, Streak = 50, Monthly = 50,
		Promotion = 30, -- a promotion fight won
	},
	RepeatBuyKeyHours = 9, -- the pass bought again in the same season (Roblox charged it): this many hours of keys
	-- (2026-10-02, "과금 상품에 불만이 없을지": the paid pass's dino was 영웅·큰 for most players, weaker than the free
	-- attendance dino 전설·거대) at least Legendary, 거대
	DinoRarityBelowTop = 2, DinoMinRarity = "Legendary", DinoSize = "Giant",
	Themes = {
		{ Name = "🦖 쥬라기 축제", Skin = "Season:Jurassic", Dino = "TRex" },
		{ Name = "🌋 화산 탐험", Skin = "Season:Lava", Dino = "Spino" },
		{ Name = "🌊 바다 축제", Skin = "Season:Coral", Dino = "Mosa" },
		{ Name = "🌌 우주 공룡", Skin = "Season:Star", Dino = "Pteranodon" },
	},
	Free = {
		{ Keys = 3 }, { MoneyChests = 1 }, { SpecialKeys = { Silver = 1 } }, { Keys = 5 }, { LuckMinutes = 15 },
		{ MoneyChests = 2 }, { SpecialKeys = { Silver = 1 } }, { Keys = 5 }, { Bombs = 2 }, { SpecialKeys = { Gold = 1 } },
		{ MoneyChests = 2 }, { Keys = 8 }, { SpecialKeys = { Silver = 2 } }, { MoneyChests = 3 }, { SpecialKeys = { Gold = 1 } },
		{ Keys = 8 }, { LuckMinutes = 20 }, { MoneyChests = 3 }, { SpecialKeys = { Silver = 2 } }, { SpecialKeys = { Gold = 1 } },
		{ Keys = 10 }, { MoneyChests = 4 }, { Bombs = 3 }, { SpecialKeys = { Silver = 3 } }, { SpecialKeys = { Gold = 2 } },
		{ MoneyChests = 5 }, { Keys = 12 }, { LuckMinutes = 30 }, { SpecialKeys = { Gold = 2 } }, { SpecialKeys = { Ruby = 1 } },
	},
	-- (2026-10-02, "유료 아이템들 밸런스 검토": 4 ruby keys and a diamond key made the 249 R$ pass worth more than
	-- the 799 R$ five ruby keys, about 9 R$ an hour of play; now 2 rubies, the rest gold and keys: about 4 times
	-- the packs' worth for a month of play, tools/monetization_sim.py)
	Paid = {
		{ KeyHours = 1.5, SpecialKeys = { Silver = 2 } }, { MoneyChests = 3 }, { SpecialKeys = { Gold = 2 } },
		{ KeyHours = 1.5 }, { LuckMinutes = 30 }, { SpecialKeys = { Silver = 4 } }, { MoneyChests = 4 },
		{ SpecialKeys = { Gold = 2 } }, { KeyHours = 1.5 }, { Skin = true, SpecialKeys = { Gold = 2 } },
		{ MoneyChests = 5 }, { SpecialKeys = { Silver = 6 } }, { KeyHours = 1.5 }, { SpecialKeys = { Gold = 2 } },
		{ SpecialKeys = { Gold = 4 } }, { MoneyChests = 6 }, { LuckMinutes = 45 }, { KeyHours = 1.5 },
		{ SpecialKeys = { Gold = 4 } }, { SpecialKeys = { Ruby = 2 } }, { MoneyChests = 8 }, { SpecialKeys = { Silver = 8 } },
		{ KeyHours = 3 }, { SpecialKeys = { Gold = 4 } }, { SpecialKeys = { Gold = 4 } }, { MoneyChests = 10 },
		{ KeyHours = 3 }, { SpecialKeys = { Gold = 6 } }, { KeyHours = 3, SpecialKeys = { Gold = 4 } },
		{ Dino = true, SpecialKeys = { Ruby = 2 } },
	},
}

Config.Treasure = { -- treasure chests on the battlefield (Treasure service): money straight away. All 임시값
	SpawnInterval = 75, -- (was 40) seconds between new chests (while fewer than MaxOnField are out)
	MaxOnField = 2, -- (was 3)
	Lifetime = 150, -- seconds a chest waits to be opened before it goes
	OpenSeconds = 3, -- holding the prompt this long opens it (the chest shakes and sparkles meanwhile; 2026-10-05: was 5)
	OpenRange = 8, -- studs from the chest
	VanishSeconds = 2, -- after the money is taken, the open chest goes
	MoneyBase = 6000, -- (2026-10-06: was 1500, about 12 seconds of mining a chest; now about 50)
	MoneySpread = 0.3,
	EdgeMargin = 8, -- studs inside the key zone's edge and the battlefield's edge
}

Config.Friends = { -- playing on the same server as Roblox friends (Friends service). 임시값
	BoostPerFriend = 0.1, -- money earned by playing (deposits, arena kills, treasure chests) +10% a friend ...
	MaxFriends = 3, -- ... for at most this many friends (+30%)
}

-- (2026-10-02, design 13 주간 한정 공룡, 개발 순서 11 "한정 공룡 교체가 코드 수정 없이 설정값만으로") this week's
-- limited dino: a week starts on Saturday at the reward day's turn (Rewards.ResetOffsetHours). The week of
-- StartDate (a Saturday, { year, month, day }) has Roster[1], the next Roster[2], ... and round again. Its
-- share of every draw is Gacha.LimitedChancePercent at any level; a dino drawn from that share is marked
-- limited (🎖️) for good, and anyone who has one shows 🎖️ over their head. To change the line-up, edit
-- Roster (species Ids); Enabled = false turns it off. 임시값: no new models yet, so existing species
Config.Limited = {
	Enabled = true,
	StartDate = { 2026, 10, 3 },
	Roster = { "Spino", "Quetzal", "Krono", "Kentro", "Shoni", "Dilopho", "Brachio", "Microraptor" },
	CheckEvery = 30, -- seconds between looks for the week's turn (Limited service)
}

-- (2026-10-02, design 13 "친구와 같이 들어오면 둘 다 열쇠") two Roblox friends on the same server for a while
-- both get keys, once a day for each pair (Friends service; RewardLogic.friendBonus). 임시값
Config.Notify = require(script.Parent:WaitForChild("ConfigNotify"))

Config.FriendInvite = {
	Keys = 5, -- 🔑 normal keys each
	MinutesTogether = 2, -- on the same server this long first (not just a join and leave)
	PerDay = 3, -- a player gets it with at most this many friends a day
}

Config.Share = {
	FromRarity = "Legendary", -- 임시값
	PillSeconds = 12, -- 임시값
}

Config.Help = {
	MaxHelpers = 3, -- 임시값
	MinSlaps = 3, -- 임시값
	Keys = 1, -- 임시값
	PerDay = 3, -- 임시값
	FriendNoticeEvery = 600, -- 임시값
}

Config.Comeback = {
	Tiers = { -- 임시값
		{ Days = 3, Reward = { KeyHours = 0.5, SpecialKeys = { Silver = 2 } } },
		{ Days = 7, Reward = { KeyHours = 1, SpecialKeys = { Silver = 2, Gold = 1 } } },
		{ Days = 14, Reward = { KeyHours = 2, SpecialKeys = { Gold = 2, Ruby = 1 } } },
	},
}

Config.Ride = { -- riding a dino in the safe land (Ride service): the base plots and outside the flags; flying ones over
	-- the battlefield too, only to look
	-- (2026-10-05, "공룡 탈것도 속도 비례해서로 바꿔 배속": was a fixed 60 for a while) × the trained walk speed (and a pad's boost);
	-- the weather and the speed potion don't count ("날씨땜에 빠른거였네 왜느려졌냐") 임시값
	SpeedMultiplier = 3,
	MaxSpeed = 150, -- (2026-10-05) at most this, however fast the walk (the top walk × 3 would be 192) 임시값
	Cooldown = 2, -- 임시값: seconds between getting on and off
	DefaultSpecies = "Parasaur", -- 임시값: everyone can ride this one without owning it
	NoThemes = { "Sea" }, -- these species don't walk or fly, so they can't be ridden (Sky ones fly since 2026-10-01)
	-- flying mounts (FlyThemes): the rider flies with the move keys toward where the camera looks (looking
	-- up or down while going forward or back climbs or dives, for phones), Space / the jump button up,
	-- Shift down. (2026-10-04, "익룡타고 배틀필드도 날아보고 싶은데.. 날기만") over the battlefield too, only to look
	-- (Shared/SafeZones.inSky): never lower than FieldMinHeight there, and getting off there puts the rider down
	-- outside the flags at once. Carrying keys or racing, they are still held back at the flags.
	FlyThemes = { "Sky" },
	FlyClimbSpeed = 22, -- 임시값: studs a second up or down with Space / Shift
	FlyMaxHeight = 160, -- 임시값: studs above the ground at most
	FlyEdgeMargin = 3, -- 임시값: flyers with keys or racing are held back this far outside the battlefield flags
	FieldMinHeight = 30, -- 임시값: over the battlefield a flying dino's feet stay this many studs over the ground at least
	-- (over the tree trunks and the people) ...
	FieldRamp = 25, -- 임시값: ... rising to it over this many studs in from the flags (from the ground at the flags)
	FieldDropOut = 10, -- 임시값: off a flying dino over the battlefield: put down this far outside the flags, straight out
	PedestalRange = 10, -- 임시값: studs from the mount pedestal behind the rebirth sign for its prompt
	-- the mount's size and where the rider sits (the server lifts the rider, the clients draw the dino)
	MountHeight = 5.5, -- a player is about 5
	MountLength = 10, -- snout to tail at most
	BackHeight = 0.72, -- the rider sits this share of the mount's height up
	SeatForward = 0.08, -- and this share of its length behind the mount's middle (the neck in front)
	RoarCooldown = 3, -- 임시값: seconds between a rider's roars (everyone hears them)
}

-- Races (Race service, design 2.11.1): two players race their dinos one lap around the paved track
-- between the battlefield flags and the base fences (roblox/MapBuilder.lua builds it with the same
-- numbers). Just for fun: no reward.
-- (2026-10-03, "숨박꼭질 기능도 만들자 …") 🙈 hide-and-seek on the battlefield (HideSeek service, HideSeekLogic).
-- A room opens at the board by the key altar (BoardAngle: compass degrees, BoardOut studs from the middle); it
-- starts when MinPlayers or more are in it and all are ready. The seeker is picked at random and stands still at the
-- key altar (SeekerSpawnRadius from the middle) for HideSeconds while the others are put at random spots
-- (SpawnRadius, SpawnGap apart); then SeekSeconds to find and slap every hider. (2026-10-04, "술래잡기 최대 영역을 그냥
-- 맵 전체로 하자. 배틀필드 밖에선 기본공룡 제공으로 그것만 탈 수 있게") the game is played on the whole map (put back
-- EdgeMargin inside the map's wall), outside the battlefield on Config.Ride.DefaultSpecies only; nobody in a game can
-- use 기지로 or bombs; hiders can't slap; dying (a reset) gives up.
-- Records: profile HideSeek { Wins, Losses }. 임시값
-- (2026-10-03, "술래한테 이득을 좀 줘야 찾을 수 있겠는데 너무 어렵다", "일정시간마다 종울리기가 숨는자들에게 강제된다든지",
-- "3분은 맵크기에 비해 좀 적은거 같기도") the seeker runs SeekerSpeed times as fast and slaps SeekerReach times as far
-- while seeking; every hider's 🔔 bell rings by itself every BellEvery seconds of seeking (BellEveryLate in the last
-- LateSeconds), the first one BellFirst seconds in; SeekSeconds 180 → 300
-- (2026-10-04: moved out, Config.lua must stay under Roblox's 200,000 characters a script)
Config.HideSeek = require(script.Parent:WaitForChild("ConfigHideSeek"))

-- the dino races: ReplicatedStorage/ConfigRace (2026-10-04: moved out, Config.lua must stay under Roblox's
-- 200,000 characters a script)
Config.Race = require(script.Parent:WaitForChild("ConfigRace"))
-- 🏆 랭킹전 of hide-and-seek and the races, and its week's ranking rewards: ReplicatedStorage/ConfigRanked (2026-10-04)
Config.Ranked = require(script.Parent:WaitForChild("ConfigRanked"))

-- Bombs (Bombs service, 2026-10-01): bought at the bomb stall beside each base's shop, thrown where the
-- player aims (at most ThrowRange studs away). Only a blast on the battlefield does anything:
--   Egg  (💥 알 폭탄): a slap from the bomb itself, all round, with the thrower's slap reach and level:
--        players in reach drop their keys and are thrown, zombies are thrown, bosses take slap damage.
--   Poop (💩 똥 폭탄): like a pterosaur's dropping on everyone in reach (stuck Config.Poop.StunSeconds);
--        zombies and bosses in reach can't move for RootSeconds, but still hit whoever comes close.
-- Price: PriceShopKeyMultiplier × the shop's normal key at the buyer's level (Formulas.bombPrice): the egg
-- 3 (LV 20 about 5,900, LV 50 about 8,900: one or two minutes of mining), the poop 2. 임시값
Config.Bombs = {
	Kinds = {
		-- BossDamageMultiplier: on a boss it hits as hard as this many slaps (2026-10-01, with Zombies.Boss
		-- MoneyPerDamage: an egg on a boss pays back about twice its price) 임시값
		-- Short: what it does in the stall window, in pictures first (2026-10-04, "폭탄 상점 정보도 정리해줘": was a
		-- sentence of two lines)
		{ Id = "Egg", Name = "알 폭탄", Icon = "💥", Model = "Item_EggBomb", PriceShopKeyMultiplier = 3, BossDamageMultiplier = 7,
			Short = "💥 사방 찰싹 · 🔑 떨어뜨려요 · 👑 보스 ×7 · 🦴 화석도 펑!" },
		{ Id = "Poop", Name = "똥 폭탄", Icon = "💩", Model = "Item_PoopBomb", PriceShopKeyMultiplier = 2,
			Short = "💩 꼼짝 못 해요 · 👑 보스도 묶여요 · 🦴 화석도 멈춰요" },
	},
	MaxHeld = 20, -- of each kind (2026-10-01: was 5, "hold many more bombs") 임시값
	-- (2026-10-04, "처음 시작하면 똥폭탄이랑 일반 폭탄 3개씩 줘 인벤에 있어야 써보고 사지") a new player starts with this many of
	-- each (ProfileLogic.new; "게임 처음 시작하면 이야 폭탄 지급은": new players only) 임시값
	StarterCount = 3,
	Cooldown = 5, -- seconds between throws (either kind)
	ThrowRange = 50, -- studs, at most
	FlightSeconds = 0.9, -- in the air before it goes off
	RootSeconds = 4, -- a poop bomb holds zombies and bosses in place this long
	StallRange = 12, -- studs from the bomb stall for buying
	FossilDamageMultiplier = 4, -- 임시값
	FossilHoldSeconds = 3, -- 임시값
	FossilBossHoldSeconds = 1.5, -- 임시값
}

-- ---------------------------------------------------------------------------
-- Respawn (there is no health: a slap drops the keys and throws, it does not hurt. A character
-- still respawns after falling off the world or a reset.)
-- ---------------------------------------------------------------------------

Config.Respawn = {
	Delay = 2, -- 임시값: seconds before respawning at the player's base (was 12 with knock-outs, then 5)
	Invulnerability = 3, -- seconds after spawning
}

-- ---------------------------------------------------------------------------
-- Farm registration and collection
-- ---------------------------------------------------------------------------

Config.Farm = {
	BuffPerUnit = 0.002, -- +0.2% × rarity farm coefficient × size power multiplier (a kind not in BuffPerUnitByKind)
	-- 임시값 (2026-10-01, "the farm should be a way past the harder defense"): the defense buffs are much
	-- stronger: a common young carnivore +8% unit power, an armored one 4% slower monsters (× rarity ×
	-- size as above). A few early farm dinos (about +20% power, 15% slower) move the promotion wall of
	-- three common dinos from LV 6 to past LV 11 (tools/tests/farm_test.lua)
	-- (2026-10-04, "농장 효과 엄청 좋네 디펜스 난이도 올려야하지 않겠냐" → A: six early farm dinos, +28% power and 39%
	-- slower (the slow cap nearly reached), moved the promotion walls 5-8 levels: was 0.08 / 0.04 and a 40% slow cap)
	-- (2026-10-05, "농장 버프가 너무 눈에 안띄는거 같은데... 수치가 너무 낮다는 거지. 이게 밸런스 조절 잘 된건지") money, mining and
	-- rare chance were left at BuffPerUnit's +0.2% when the defense two went up (a common herbivore: +0.2% money, a
	-- legendary big one +1.4%; the +300% caps out of reach): +3% money / mining, +2% draw luck a common young one. 임시값
	BuffPerUnitByKind = { UnitPower = 0.05, MonsterSlow = 0.02, Money = 0.03, Mining = 0.03, RareChance = 0.02 },
	UnitPowerCap = 3.00, -- +300%
	MonsterSlowCap = 0.25,
	RareChanceCap = 2.00, -- +200%
	-- (2026-10-02, the same principle) with the farm slots pass every farm cap is this many times higher
	-- (Formulas.farmCaps; MonsterSlow: at most PassSlowCapMax). 임시값
	PassCapMultiplier = 1.5,
	PassSlowCapMax = 0.55,
	-- (2026-10-02, 점검: fed to 태고 a farm dino's buff is ×3, and money and mining had no cap; "각 +300% 상한")
	MoneyCap = 1.00, -- 임시값
	MiningCap = 1.00, -- 임시값
	-- (2026-10-01) farm slots start at 1 (was 20) and are bought one at a time with game money at the
	-- farm field's sign (the "농장 칸 늘리기" prompt): cost = BaseCost × Growth^(slots bought so far). 임시값
	StartSlots = 1,
	MaxSlots = 40,
	-- (2026-10-01: was 2000 × 1.4^n, "slot prices too low"; 2026-10-04, "농장 칸 늘리기가 좀 싼가": was 6000 × 1.45^n at
	-- × 2.5, the first ten 1.3M in all → 12000 × 1.42^n at × 4: the first 48K, the 10th 1.1M, the first ten 4.3M) 임시값
	SlotUpgrade = { BaseCost = 60000, Growth = 1.1 }, -- 임시값
	SignRange = 10, -- studs from the farm sign for its prompt
	-- (2026-10-01, "the collection was filled with silver keys alone": was 10/25/50/100; silver keys give
	-- at most mythic, 6 rarities × the species open, so the last steps need better keys) 임시값
	CollectionRewards = {
		{ Count = 20, Reward = "UnitPower", Amount = 0.05 },
		{ Count = 60, Reward = "Money", Amount = 0.10 },
		{ Count = 120, Reward = "PlacementSlots", Amount = 1 },
		{ Count = 250, Reward = "RareChance", Amount = 0.10 },
	},
	AutoWeights = { UnitPower = 1, MonsterSlow = 1, RareChance = 0.5, Money = 0.2, Mining = 0.2 }, -- 임시값
	BuffNames = { UnitPower = "전체 파워", Money = "돈 획득량", MonsterSlow = "화석 감속", RareChance = "레어 확률",
		Mining = "채취량" },
	ThemeCompleteReward = "SlapSkin", -- a theme's every species: its own slap skin
	VariantMultiplier = 2, -- 임시값: variants give the unit power buff this many times as much ("큰 폭")
	-- the collection counts the species × rarity pairs ever owned (임시값: the design gives no unit)
}

-- (2026-10-02, "할 게 점점 많아지면서 수집창고 보면서 뿌듯해하는 그런 감성" → 도감 보상 끝까지 · 도감 자랑하기) the collection
-- (species × rarity pairs, Config.Species × Config.Rarities = every one) beyond Farm.CollectionRewards' lasting buffs:
-- Milestones: each pays its Reward once (Config.Rewards' kinds: Keys, SpecialKeys, MoneyChests) and gives its Title; the
--   best title reached is worn over the head and on the board (Count = "All": every pair). Rows: a rarity's "row" is the
--   plain species (not variants) collected at that rarity; at each of Steps' Species counts it pays that rarity's
--   RowReward × the step's Times, once. Paid by the Farm service (profile.CollectionPaid). 임시값
Config.Collection = {
	Milestones = {
		{ Count = 20, Title = "🥚 새내기 수집가", Reward = { Keys = 5 } },
		{ Count = 60, Title = "🌱 꼬마 수집가", Reward = { SpecialKeys = { Silver = 1 } } },
		{ Count = 120, Title = "🔍 공룡 탐험가", Reward = { SpecialKeys = { Silver = 3 } } },
		{ Count = 200, Title = "🦴 화석 발굴가", Reward = { SpecialKeys = { Gold = 1 } } },
		{ Count = 280, Title = "📚 공룡 박물학자", Reward = { SpecialKeys = { Gold = 2 }, MoneyChests = 2 } },
		{ Count = 360, Title = "🏅 공룡 박사", Reward = { SpecialKeys = { Ruby = 1 } } },
		{ Count = 450, Title = "🏛️ 박물관장", Reward = { SpecialKeys = { Ruby = 2 } } },
		{ Count = 540, Title = "💎 보석 수집가", Reward = { SpecialKeys = { Diamond = 1 } } },
		{ Count = 630, Title = "🌟 별빛 수집가", Reward = { SpecialKeys = { Diamond = 2 } } },
		{ Count = 720, Title = "🌌 우주 수집가", Reward = { SpecialKeys = { Rainbow = 1 } } },
		{ Count = 820, Title = "🔥 태초의 수집가", Reward = { SpecialKeys = { Rainbow = 2 } } },
		{ Count = "All", Title = "👑 공룡 대백과", Reward = { SpecialKeys = { Rainbow = 5 } } },
	},
	King = { Title = "👑 공룡 왕", Reward = { SpecialKeys = { Rainbow = 3 } } }, -- 임시값
	Rows = {
		Steps = { { Species = 10, Times = 1 }, { Species = 30, Times = 2 }, { Species = 50, Times = 5 } },
		RowReward = {
			Common = { Keys = 3 }, Uncommon = { Keys = 6 }, Rare = { SpecialKeys = { Silver = 1 } },
			Epic = { SpecialKeys = { Silver = 2 } }, Legendary = { SpecialKeys = { Gold = 1 } }, Mythic = { SpecialKeys = { Gold = 2 } },
			Transcendent = { SpecialKeys = { Ruby = 1 } }, Rainbow = { SpecialKeys = { Ruby = 2 } }, Golden = { SpecialKeys = { Ruby = 3 } },
			Onyx = { SpecialKeys = { Diamond = 1 } }, Celestial = { SpecialKeys = { Diamond = 2 } }, Secret = { SpecialKeys = { Diamond = 3 } },
			Cosmic = { SpecialKeys = { Rainbow = 1 } }, Primeval = { SpecialKeys = { Rainbow = 2 } }, Divine = { SpecialKeys = { Rainbow = 3 } },
		},
	},
	StoreName = "DexRank_v5", -- OrderedDataStore: UserId -> collection count (the board's 📖 도감 순위, Leaderboards)
}

-- ---------------------------------------------------------------------------
-- Daily login rewards
-- ---------------------------------------------------------------------------

Config.Daily = {
	Streak = { -- 7-day cycle; a missed day restarts at day 1
		{ Keys = 3 },
		{ MoneyKeyPrices = 5 }, -- game money = current key price × 5
		{ Keys = 5 },
		{ LuckPotionMinutes = 15 },
		{ Keys = 8 },
		{ MoneyKeyPrices = 15 },
		{ GuaranteedRarity = "Legendary", Keys = 10 },
	},
	Cumulative = { -- resets every month
		{ Day = 7, SkinDiscount = 0.30 },
		{ Day = 14, ServerLuckBoostMinutes = 10 },
		{ Day = 21, Keys = 30 },
		{ Day = 28, MonthlyDino = { Rarity = "Epic", Size = "Adult" } },
	},
}

-- ---------------------------------------------------------------------------
-- Collectible units: themes, attributes, species, rarity, size, mutation
-- unit power = species base power × rarity power × size power × mutation power
-- ---------------------------------------------------------------------------

-- Every species of a theme attacks the same way; species differ by attribute. Icon: its picture in the windows
-- (2026-10-04, "공룡배치 창에서도 육식 전기 이따구로 적어놓지 말고 그림을 넣으라고")
-- Damage is the "species base power" of the unit power formula. Interval = seconds between attacks.
-- Range "Melee" = Placement.MeleeReachFromTrack from the track; a number = range in studs.
Config.Themes = {
	{ Id = "Carnivore", Name = "육식", Icon = "🍖", Attack = "SingleTarget", Damage = 30, Interval = 1.2, Range = "Melee",
		FarmBuff = "UnitPower" },
	{ Id = "Herbivore", Name = "초식", Icon = "🌿", Attack = "AreaAround", Damage = 12, Interval = 1.5, AreaRadius = 6, Range = "Melee",
		FarmBuff = "Money" },
	{ Id = "Armored", Name = "갑옷", Icon = "🛡️", Attack = "AreaAround", Damage = 6, Interval = 1.0, AreaRadius = 7.5, SlowAura = 0.20,
		Range = "Melee", FarmBuff = "MonsterSlow" },
	{ Id = "Sky", Name = "하늘", Icon = "🦅", Attack = "PiercingLine", Damage = 14, Interval = 1.3, PierceMax = 3, Range = 18,
		PierceWidth = 2.5, -- 임시값: how wide the piercing line is
		FarmBuff = "RareChance" },
	{ Id = "Sea", Name = "바다", Icon = "🌊", Attack = "Splash", Damage = 10, Interval = 1.6, AreaRadius = 4.5, Range = 18,
		FarmBuff = "Mining" },
	-- variants attack like their original theme (Species.BaseTheme) with its damage × 1.3; farm buff: unit power, larger
	{ Id = "Variant", Name = "변종", Icon = "🧬", Attack = "BaseTheme", DamageMultiplier = 1.3, FarmBuff = "UnitPower" },
}

-- Icon: shown before a dino's name over it and on the attribute board by every defense sign (2026-10-01)
Config.Attributes = {
	-- (2026-10-03, "빙속성공룡은 데미지가 낮은데신 디버프 확실히 걸어주는 이런 방향으로 가야지. 디버프는 확률이 아니라
	-- 100퍼 걸리게") ice hits for DamageMultiplier of the damage, but every hit slows for SlowDuration and freezes
	-- for FreezeDuration, sure (was a 10% chance) — then, once thawed, it can't freeze again for FreezeCooldown
	-- (or a few ice dinos would hold every fossil still); bosses are only slowed (half). 임시값
	Ice = { Name = "얼음", Icon = "❄️", DamageMultiplier = 0.6, SlowDuration = 3, Slow = 0.35, FreezeDuration = 1,
		FreezeCooldown = 3, BossSlowMultiplier = 0.5, BossFreezeImmune = true, Burst = 5, BurstDamage = 0.1 },
	-- (2026-10-03, "속성 공룡들의 속성은 100퍼 발현이야. 대신 데미지가 희생되는거고") every attribute's effect comes on
	-- every hit; DamageMultiplier: the hit's own damage, paid for it (the stronger the effect, the less; neutral, with
	-- no effect, gets +15% instead). 임시값
	-- (2026-10-03, "독속성은 바닥에 독을 설치 … 빙속성은 범위 공격 … 불은 범위공격에 불 상태이상 … 무속성은 보스에게 특히
	-- 효율이 좋은 그냥 일반 공격 … 조합을 짜게 만들라고 다 똑같은 공격방식취하지 말고") each attribute attacks its own way
	-- on top of the theme's: Burst = a blast round the main target (radius, studs) that gives every fossil in it the
	-- effect and BurstDamage of the hit (fire, ice, water); poison leaves a pool on the track (Pool*); electric chains;
	-- earth pushes the one it hits; neutral is a plain hit, BossDamageMultiplier on a boss. 임시값
	Fire = { Name = "불", Icon = "🔥", DamageMultiplier = 0.8, Duration = 3, DamagePerSecond = 0.15, -- of the attacker's power
		Burst = 5, BurstDamage = 0.25 },
	Electric = { Name = "전기", Icon = "⚡", DamageMultiplier = 0.85, ChainTargets = 3, ChainDamage = 0.50,
		ChainRadius = 6 }, -- ChainRadius 임시값
	-- poison: every hit leaves a pool on the track where the fossil was (PoolRadius studs, PoolSeconds); every fossil in
	-- it takes DamagePerSecond of the attacker's power a second; a dino keeps PoolsPerUnit pools (a new one, the oldest goes)
	Poison = { Name = "독", Icon = "☠️", DamageMultiplier = 0.8, PoolRadius = 5, PoolSeconds = 4, DamagePerSecond = 0.2,
		PoolsPerUnit = 1 },
	-- earth: every hit pushes back (was a 20% chance), each fossil at most once per PushCooldown seconds (or it would
	-- never get anywhere), a little less far
	-- (2026-10-03, balance: a shockwave pushing every fossil round the target back made the promotions harder, not
	-- easier — pushed fossils stay on the track longer and fill it — so earth keeps pushing just the one it hits)
	-- (2026-10-03 balance check: at 0.7 earth earned the least of every attribute and its carnivore was weakest on the
	-- boss too — pushing one fossil is a smaller effect than a blast, a pool or a chain — so it pays less for it)
	Earth = { Name = "대지", Icon = "⛰️", DamageMultiplier = 0.9, PushDistance = 3.5, PushCooldown = 2,
		BossPushMultiplier = 0.5 },
	Water = { Name = "물", Icon = "💧", DamageMultiplier = 0.85, WetDuration = 3, Burst = 5, BurstDamage = 0.1 },
	Neutral = { Name = "무속성", Icon = "⚪", DamageBonus = 0.05, BossDamageMultiplier = 1.3 },
	Combo = { WetElectricDamage = 1.5, WetFreezeMultiplier = 2 }, -- (wet: the freeze lasts this many times as long; was a 2× chance)
	-- (2026-10-03, "디펜스에서 빙결이나 독이나 여러가지 속성들 공룡 등급이란 크기가 높아질 수록 효과 대상이나 효과 지속시간이
	-- 강해지게 하자. 지금 초급부터 너무 센거같아 효과가") the numbers above are a legendary young dino's. A dino's effect
	-- strength: Base + PerRarity a rarity above common (common 0.5, rare 0.75, legendary 1, divine 2.25), × (1 +
	-- PerSizeScale × (its size's Scale − 1)) (hatchling ×0.9, giant ×1.25, primordial ×1.63), at least Min
	-- (Formulas.effectStrength). Times that: every effect's seconds (freeze, slow, burn, wet, the pool's); the areas
	-- (blasts, the pool, the push) grow AreaShare as fast; the chain's targets: rounded, at least 1. 임시값
	Growth = { Base = 0.5, PerRarity = 0.125, PerSizeScale = 0.25, Min = 0.3, AreaShare = 0.5 },
}

for key, value in pairs(require(script.Parent:WaitForChild("ConfigSpecies"))) do
	Config[key] = value
end

-- the launch gift (LaunchGift service): once a player, the first time their real save loads (tutorial done or not), a
-- WelcomeRex of Rarity and Size, marked 🎉 (unit.Launch); a big celebration window shows it the first time they are on a
-- screen to see it (the main game, or the tutorial field they are sent to). LastDay: the last day number
-- (Config.Rewards' days) it is still given to new players; nil = always (until the launch window is set). 임시값
-- (2026-10-04, "디펜스 초반이라 그런가 좀 쉬운거 같은데" → ②: was Giant; a giant one alone reached the whole boss's way and won
-- every promotion to LV 13 by itself; Big: not alone, with two common dinos to LV 11 (an epic one and two common: 10))
Config.LaunchGift = { Species = "WelcomeRex", Rarity = "Special", Size = "Big", LastDay = nil, ShowLevel = 2 }

-- (2026-10-04) 🎉 the launch event: its missions, the skin and title for all of them (ConfigEvent)
Config.LaunchEvent = require(script.Parent:WaitForChild("ConfigEvent"))

Config.Gacha = {
	LimitedChancePercent = 1, -- this week's limited dino, rolled first
	LimitedPotionChancePercent = 3, -- while a limited luck potion is active
	-- the rest (99%) is split evenly between the unlocked species (2026-10-01: the later ones were rarer;
	-- "새 공룡과 일반 공룡 차이 없어"). The variants (변종, "특수 개체들만 상위 등급에서"): only from
	-- VariantMinKey and better keys, each VariantWeight times as likely as a plain species
	VariantMinKey = "Silver", -- 임시값
	-- (2026-10-01, "은열쇠도 되는데 확률은 아주 낮지") a variant's weight by key: very low from silver, more
	-- from each better key (a plain species weighs 1). 임시값
	VariantWeight = { Silver = 0.02, Gold = 0.08, Ruby = 0.2, Diamond = 0.4, Rainbow = 0.7 },
	WeeklyNewSpecies = 2,
	TotalSpecies = 75,
	LuckFromRarity = "Legendary", -- luck multiplies Legendary and up; the extra comes out of Common
	LuckMaxMultiplier = 12, -- all luck combined ...
	-- (2026-10-02, "현질엔 예외적으로 이득을 줄 수 있도록 해 돈 쓴거잖아"; 원칙 "무과금도 플레이 가능한 게임이되 현질엔
	-- 확실히 이득") ... but while a luck potion or a server luck boost is on, up to this: what was paid for always
	-- adds on top. 임시값
	PaidLuckMax = 24,
	-- (2026-10-02, "각 각성 등급에 맞게 조절해 높은 급의 공룡 확률도") a rarity is this share of its chance in the
	-- awakening that opened it ([1]), the next ([2]), ...; its full chance after. Better keys' best-of picks
	-- multiply it up, so the first share is small. 임시값
	-- (2026-10-02, 점검: at ×2% / ×20% a free player's first mythic came after ~127 hours and the first rainbow
	-- after ~760, while 🟢 LV 100 needs about a rainbow team: "둘 다 조금씩") ×10% / ×40%: mythic ~25 h, rainbow ~150 h
	NewRarityScale = { 0.5, 0.8 },
	-- (2026-10-02, "과금 상품에 불만이 없을지" → "뽑기 천장") a draw after Pity.Draws − 1 draws in a row below
	-- Pity.Rarity is at least it (Formulas.applyPity; any key, bought or found; saved, so it survives leaving).
	-- A legendary or better comes about every 330 draws of a normal key: 500 keeps it a safety net (about one
	-- run in five ends at it), not the usual way. 임시값
	Pity = { Rarity = "Legendary", Draws = 500 },
	-- (2026-10-01) a better key's draw = the best of this many draws of the grade below (rarity), and
	-- the biggest of UpgradeSizePicks sizes: one exchanged key (10 of the grade below) is about twice as
	-- good as the best of those 10 (tools: the gacha test). 임시값
	-- (2026-10-02, "완전 상위 공룡 쪽도 뽑기 어려운 거 맞지 후반컨텐츠에서도" → 둘 다 손보기) UpgradePicks (12 a grade) is gone:
	-- a key is the best of what the exchange takes to make it (Formulas.keyPicks: rainbow 24,010 normal draws,
	-- was 248,832). And luck counts only Share on the top Rarities rarities open at the key's level (a rainbow
	-- key with a potion gave the tier's best rarity 1 in 3). 임시값
	TopLuck = { Rarities = 3, Share = 0.5 },
	UpgradeSizePicks = 3,
	-- (2026-10-01) ... but a step up that brings no better rarity (the better ones still locked by level
	-- or past the key's MaxRarity) takes LockedSizePicks sizes instead of UpgradeSizePicks: the rarity
	-- picks are wasted there, so the size gets them; at least Keys.ExchangeRate, so one exchanged key is
	-- never worse than the best of the 10 it was made of (before: down to ×0.8 at low levels). 임시값
	LockedSizePicks = 10,
	-- with no limited dino this week, its share goes to the unlocked species too (always 100%)
	MaxDrawCount = 10, -- one key per draw; 1 to 10 at once (fewer than 10 keys: all of them in one go)
	KeyBuyCounts = { 1, 10 }, -- keys sold in the shop at Formulas.keyShopPrice(level, type) each
	KeyBulkDiscount = { [10] = 0.2 }, -- 임시값 (2026-10-07) share off when buying this many at once
	MaxOwnedUnits = 1000, -- 임시값: no more draws past this many dinos (the save must stay small)
	AnnounceFromRarity = "Secret", -- server-wide notice for draws of this rarity and up (design 4.4)
	ChatFromRarity = "Mythic",
}
Config.Boxes = require(script.Parent:WaitForChild("ConfigBoxes"))

-- locked rarities never drop; their chance is added to Common
-- (2026-10-01, "early on players collect too many, it gets dull"): Legendary to Golden much rarer (1.25 /
-- 0.5 / 0.175 / 0.05 / 0.0175 % → 0.3 / 0.18 / 0.05 / 0.03 / 0.012 %) so a free player owns about 3-7 of the
-- best open rarity when the next one opens (was 29 legendaries, 11 mythic, 15 transcendent), and those
-- tiers a little stronger (Power 5 / 7.5 / 11 / 17 / 25 → 6 / 8.7 / 12.8 / 18.5 / 26.5) so the team of 8
-- stays within ~7% of before at every point of the pace table (the defense balance). Common takes the rest.
-- (tools/monetization_sim.py: rarity windows and teams) 임시값
-- (2026-10-01, "attack should grow with the rarity above all; a big size can still rival a higher rarity"):
-- from Mythic up each step is about ×1.5-1.65 (was ×1.45; Mythic 8.7 → 9, Transcendent 12.8 → 13.5, Rainbow
-- 18.5 → 20, Golden 26.5 → 32, Onyx 38 → 52, Celestial 57 → 85, Secret 85 → 140, Cosmic 125 → 230, Primeval
-- 185 → 380, Divine 270 → 630); up to Legendary as it was (the early defense walls). Sizes stay: Giant ×1.75
-- is about one rarity step, Primordial ×3 about two
-- when each rarity is in the draw: UnlockRebirths awakenings (rebirths) or more, no level within the tier
-- (2026-10-02, "전설까진 1레벨부터 그냥 되게 하자" → "각 각성마다 등급이 해금되게하자 각성 레벨제한꺼지 두지말고":
-- 일반~전설 from the start, the rest as soon as its awakening; was a defense level each)
-- (2026-10-04, "나 시작한지 얼마 안 돼서 보라색 잔뜩 뽑았다니까" → A: Epic 6 → 2%, the 4% to Common 53.42 → 57.42)
Config.Rarities = {
	{ Id = "Common", Name = "일반", Look = "회색, 연출 없음", UnlockRebirths = 0, ChancePercent = 57.40304, Power = 1, FarmCoefficient = 1 },
	{ Id = "Uncommon", Name = "고급", Look = "초록 테두리", UnlockRebirths = 0, ChancePercent = 28, Power = 1.5, FarmCoefficient = 1.5 },
	{ Id = "Rare", Name = "희귀", Look = "파랑 테두리 + 빛", UnlockRebirths = 0, ChancePercent = 12, Power = 2.2, FarmCoefficient = 2 },
	{ Id = "Epic", Name = "영웅", Look = "보라 오라", UnlockRebirths = 0, ChancePercent = 2, Power = 3.3, FarmCoefficient = 3 },
	{ Id = "Legendary", Name = "전설", Look = "주황 오라 + 파티클", UnlockRebirths = 0, ChancePercent = 0.3, Power = 6, FarmCoefficient = 5 },
	{ Id = "Mythic", Name = "신화", Look = "빨강 불꽃", UnlockRebirths = 1, ChancePercent = 0.18, Power = 9, FarmCoefficient = 8 },
	{ Id = "Transcendent", Name = "초월", Look = "분홍 네온", UnlockRebirths = 2, ChancePercent = 0.05, Power = 13.5, FarmCoefficient = 12 },
	{ Id = "Rainbow", Name = "무지개", Look = "색 순환", UnlockRebirths = 3, ChancePercent = 0.03, Power = 20, FarmCoefficient = 18 },
	{ Id = "Golden", Name = "황금", Look = "금속 광택", UnlockRebirths = 4, ChancePercent = 0.012, Power = 32, FarmCoefficient = 27 },
	{ Id = "Onyx", Name = "오닉스", Look = "검정 + 보라 번개", UnlockRebirths = 5, ChancePercent = 0.015, Power = 52, FarmCoefficient = 40 },
	{ Id = "Celestial", Name = "천상", Look = "흰빛 + 별 파티클", UnlockRebirths = 6, ChancePercent = 0.006, Power = 85, FarmCoefficient = 60 },
	{ Id = "Secret", Name = "시크릿", Look = "전용 등장 연출 + 서버 공지", UnlockRebirths = 7, ChancePercent = 0.0024, Power = 140,
		FarmCoefficient = 100 },
	-- (2026-10-01) three more above Secret for the long haul: their chances come out of Common's (임시값)
	{ Id = "Cosmic", Name = "우주", Look = "성운 연기 + 별 + 행성 고리", UnlockRebirths = 8, ChancePercent = 0.001, Power = 230,
		FarmCoefficient = 150 },
	{ Id = "Primeval", Name = "태초", Look = "호박빛 불꽃 + 빛기둥 + 금가루", UnlockRebirths = 9, ChancePercent = 0.0004, Power = 380,
		FarmCoefficient = 220 },
	{ Id = "Divine", Name = "신", Look = "흰 금빛 후광 + 빛줄기 + 무지개", UnlockRebirths = 10, ChancePercent = 0.00016, Power = 630,
		FarmCoefficient = 320 },
}

-- (2026-10-04, "등급은 특별 등급으로 하나 새로 만들어") rarities that are only ever given (the launch gift's ⭐ 특별):
-- never drawn, not in the collection (species × Config.Rarities), never merged; looked up like any rarity
-- (Formulas.rarity). Place: the rarity step it counts as where steps matter (feeding, enhancing, the draw's pity);
-- Power / FarmCoefficient as a rarity's. 임시값
Config.SpecialRarities = {
	-- (2026-10-04, "뽑기로 영웅 잘 뜨던데": at Power 3 it was no better than an epic in an epic team) Power 4.5: above
	-- every epic, below a legendary
	{ Id = "Special", Name = "특별", Look = "보라·금빛 별 반짝임", Place = 5, Power = 4.5, FarmCoefficient = 4 },
}

-- Dino enhancement: feed a dino others (they are used up) for experience.
Config.Enhance = { -- 임시값
	MaxLevel = 100,
	ExpBase = 10,
	LevelBands = { { From = 1, Growth = 1.03 } },
	RarityGrowth = 7,
	PowerPerLevel = 0.2, -- attack +20% a level up to level 20 (level 10: +180%, level 20: +380%) ...
	LatePowerFrom = 21, LatePowerPerLevel = 0.08, -- ... then +8% a level (level 40: +540%, level 60: +700%, level 100: +1,020%)
	OtherSpeciesShare = 0.5, -- fodder of another species gives this share of its experience
	FodderRarityGrowth = 5,
	MaxFodder = 100, -- dinos used up in one go (was 50)
	StallRange = 10, -- studs from the enhance stall in front of the defense arena for its prompt
	SizeExp = { Hatchling = 400, Tiny = 500, Baby = 600, Small = 700, Young = 800, Junior = 940, Teen = 1100, Grown = 1300,
		Adult = 1500, Big = 1700, Alpha = 2000, Giant = 2800, Colossal = 4000, Titan = 6000, Behemoth = 8000, Primordial = 10000 },
}

Config.Recommend = { BossShare = 0.5, FodderMaxRarity = "Uncommon", FodderSizeBelow = "Big", EndWeight = 1 } -- 임시값

-- the dinos roaming the safe land (StarterPlayerScripts/Wildlife, display only): the giants' model, its own
-- (tools/dinos.json "Argentino"; since 2026-10-01 also a collectible species, LV 300), copied for the clients with the others (Defense)
-- (2026-10-01) players can climb onto any of them (the "🦖 올라타기" prompt, Wildlife service): after
-- RideSeconds it rears up, roars and throws them ThrowStuds away (just for fun, nothing is lost). 임시값
Config.Wildlife = {
	-- (2026-10-01) the wild ones are now of many species (their Dino_<species> models, StarterPlayerScripts/
	-- Wildlife); these two are still copied for the clients: the giants' and the packs' stand-ins
	GiantModel = "Dino_Argentino",
	RaptorModel = "Dino_WildRaptor", -- (tools/dinos.json "WildRaptor") one of the running packs' kinds
	RideRange = 12, -- studs from its feet for the prompt (the giants: × GiantRangeScale)
	GiantRangeScale = 3,
	RideSeconds = 4, -- 임시값 (2026-10-07, "야생 공룡 타면 아주 잠깐은 조종가능하게": was 1) steered this long, then thrown
	RideSteerSpeed = 30, -- 임시값: studs per second the rider steers it
	FeedFood = 1, -- 임시값
	FeedSeconds = 3, -- 임시값
	FeedMax = 3, -- 임시값
	ThrowStuds = 26,
	ThrowFlight = 1.1, -- seconds in the air
	RideCooldown = 4,
	-- (2026-10-02) slapped (StarterPlayerScripts/Wildlife, design 9장): a little one flies off like a zombie
	-- and says a word, gets up and runs at the slapper to slap back; a giant kicks them off like a ride. 임시값
	SlapFlyStuds = 16, -- a little one flies this far from the slap
	SlapFlySeconds = 0.9,
	SlapDownSeconds = 1.2, -- lying dizzy before it gets up
	ChaseSeconds = 8, -- then it runs at the slapper this long at most ...
	ChaseSpeed = 22, -- studs a second (a player walks 16) 임시값
	ChaseLeash = 70, -- ... and gives up (back to its path, neutral) once they are this far from where it was slapped
	CounterReach = 4.5, -- studs: it slaps back this close
	CounterStuds = 14, -- its slap back throws the player this far ...
	CounterFlight = 0.8, -- ... this long in the air
	CounterWindow = 13, -- seconds after a slap its slap back may come (Wildlife service; fly + down + chase + a little)
	KickWindow = 2, -- seconds after a slap a giant's kick may come (it throws like a ride: ThrowStuds, ThrowFlight)
}

Config.Merge = { -- 합성 at the enhance stall (Enhance service): top-level dinos into one of the next rarity. 임시값
	Count = 3, -- dinos of the same rarity, all at least at Level ...
	Level = 10, -- (2026-10-01: was Enhance.MaxLevel, which went 10 → 20; merging stays where it was)
	MaxResultRarity = "Onyx", -- ... make one a rarity higher (Celestial and Secret only from draws)
	-- (2026-10-02, "공룡합성에 크고 레벨높은 공룡이 들어갈 수록 다음 등급의 공룡의 레벨과 크기도 달라짐. 모두 최대레벨
	-- 최고크기 기준 최대에서 3분의 2정도의 성능"; chosen: by attack) the new dino's size and level come from the three
	-- (Formulas.mergeResult): its size is the three's average size step × (TopSize's step / the biggest step), its
	-- level the highest that keeps its attack (level × size) at PowerShare of the three's average. Three at the
	-- top level and the biggest size make a TopSize dino at about level 76: about 2/3 of the best there is.
	PowerShare = 2 / 3,
	TopSize = "Titan",
}

-- (2026-10-02, "나무에서 떨어지는 열매의 크기도 랜덤으로 클수록 확률 낮게 해서, 이걸 새로운 시스템, 공룡사육에 추가하자.
-- 열매를 모아서 먹이로 주면 공룡 크기를 키울 수 있는거"; chosen: up to the biggest size) 공룡 사육: a slap that reaches
-- a fruit tree (Fruits service) drops a fruit. (2026-10-02, "열매주운거 남도 먹을 수 있게", "열쇠처럼 주웠다 내려놓기도
-- 가능한"; chosen: carried, but not scattered by slaps) Everyone sees it and anyone may pick it up by walking over it;
-- picked fruit is carried (up to MaxCarried) and becomes 🍎 food (Food by its size) once brought into the player's
-- own base. "🍎⬇️ 내려놓기" puts the carried fruit down for anyone (the one who put it down waits DropperPickupDelay).
-- At the enhance stall's "🍎 먹이" tab food grows a dino one size (Config.Sizes) at a time, up to the biggest
-- (Formulas.feedCost: FeedBase × FeedGrowth^(size step − 1) × FeedRarityGrowth^(rarity step − 1)). 임시값
Config.Fruit = {
	Sizes = { -- rolled by WeightPercent (bigger ones rarer); Scale: how big it is drawn
		{ Id = "Small", Name = "작은", Food = 1, WeightPercent = 60, Scale = 0.8 },
		{ Id = "Medium", Name = "보통", Food = 2, WeightPercent = 28, Scale = 1.1 },
		{ Id = "Big", Name = "큰", Food = 5, WeightPercent = 10, Scale = 1.5 },
		{ Id = "King", Name = "왕", Food = 20, WeightPercent = 2, Scale = 2.2 },
	},
	-- (2026-10-02, "열매 나무에서 하나씩 밖에 안 나오네 중복채취도 안 되고 불편하군") a slap shakes PerTree fruits down
	-- and the same tree drops again after a few seconds (was one fruit, then 30 s). 임시값
	PerTree = { Min = 2, Max = 4 },
	TreeCooldown = 5, -- seconds before the same tree drops fruit for the same player again
	PerSlap = 2, -- at most this many trees drop fruit for one slap ...
	PerMinute = 60, -- ... and at most this many fruits a minute for one player (was 30)
	LifeSeconds = 30, -- a fruit from a tree waits this long on the ground ...
	DroppedLifetime = 60, -- ... one put down by a player this long
	MaxOnGround = 120, -- fruits on the ground on the whole server at once (no more fall while there are)
	MaxCarried = 40, -- fruits one player can carry
	DropperPickupDelay = 3, -- seconds before the one who put fruit down can pick it up again
	DropSpread = 4, -- studs around the player where the fruit put down lands
	PickRange = 5, -- studs: walking this close picks it up (the server allows a little more)
	FeedBase = 10, -- food for one size step of a common 갓 부화 (the smallest) ...
	FeedGrowth = 1.5, -- ... each bigger step this many times more (a common 어린 → 태고: about 8,600 food) ...
	FeedRarityGrowth = 1.1, -- ... and each rarity step up this many times more
	TipLevel = 2, -- Coco's "🌳 slap a tree" tip from this defense level
	FeedTipFood = 20, -- Coco's "🍎 feed it" tip once this much food is saved
}

-- (2026-10-01) 16 sizes (was 10; the old Ids keep their Scale and Power, saved dinos stay as they are).
-- Scale: the size for the game (footprint on the platform, reach). Look: how big it is drawn (× its
-- model), growing much faster than Scale for the big ones so a big dino really looks big. Weights 임시값.
Config.Sizes = {
	{ Id = "Hatchling", Name = "갓 부화", Scale = 0.6, Look = 0.55, Power = 0.8, WeightPercent = 16 },
	{ Id = "Tiny", Name = "꼬마", Scale = 0.7, Look = 0.65, Power = 0.85, WeightPercent = 15 },
	{ Id = "Baby", Name = "새끼", Scale = 0.8, Look = 0.75, Power = 0.9, WeightPercent = 14 },
	{ Id = "Small", Name = "작은", Scale = 0.9, Look = 0.88, Power = 0.95, WeightPercent = 13 },
	{ Id = "Young", Name = "어린", Scale = 1.0, Look = 1.0, Power = 1.0, WeightPercent = 12 },
	{ Id = "Junior", Name = "자라는", Scale = 1.1, Look = 1.15, Power = 1.07, WeightPercent = 9 },
	{ Id = "Teen", Name = "청소년", Scale = 1.2, Look = 1.3, Power = 1.15, WeightPercent = 7 },
	{ Id = "Grown", Name = "다 자란", Scale = 1.3, Look = 1.5, Power = 1.22, WeightPercent = 5 },
	{ Id = "Adult", Name = "성체", Scale = 1.4, Look = 1.75, Power = 1.3, WeightPercent = 3.2 },
	{ Id = "Big", Name = "큰", Scale = 1.55, Look = 2.05, Power = 1.4, WeightPercent = 2.2 },
	{ Id = "Alpha", Name = "우두머리", Scale = 1.7, Look = 2.4, Power = 1.5, WeightPercent = 1.6 },
	{ Id = "Giant", Name = "거대", Scale = 2.0, Look = 3.0, Power = 1.75, WeightPercent = 1.1 },
	{ Id = "Colossal", Name = "초거대", Scale = 2.4, Look = 3.8, Power = 2.0, WeightPercent = 0.5 },
	{ Id = "Titan", Name = "타이탄", Scale = 2.9, Look = 4.8, Power = 2.4, WeightPercent = 0.25 },
	{ Id = "Behemoth", Name = "괴수", Scale = 3.2, Look = 5.6, Power = 2.7, WeightPercent = 0.1 },
	{ Id = "Primordial", Name = "태고", Scale = 3.5, Look = 6.5, Power = 3.0, WeightPercent = 0.05 },
}

Config.Mutations = { -- second update
	Types = {
		{ Id = "Neon", Name = "네온", Power = 1.2 },
		{ Id = "Crystal", Name = "결정", Power = 1.25 },
		{ Id = "Shadow", Name = "그림자", Power = 1.3 },
		{ Id = "Galaxy", Name = "은하", Power = 1.35 },
		{ Id = "Ghost", Name = "유령", Power = 1.4 },
		{ Id = "Pixel", Name = "픽셀", Power = 1.5 },
	},
	EventChancePercent = 5, -- only during server events, split evenly; 0 otherwise
}

-- ---------------------------------------------------------------------------
-- Pickaxe: 15 tiers, 10 power steps per tier (all needed for the next tier), one 30-level speed
-- track for all tiers. Tiers 1-5 from tools/economy_sim.py; from tier 6 (2026-10-07, 돈 흐름 분석) each costs about
-- 2 hours of the arena's idle income at its NeedLevel, about ×2 a tier (was 0.4M-1.7M, flat).
-- ---------------------------------------------------------------------------

Config.Pickaxe = {
	Tiers = { -- 임시값
		{ Name = "나무", Price = 0, Power = 10, Speed = 1.0, Yield = 1 },
		{ Name = "돌", Price = 400, Power = 13, Speed = 1.03, Yield = 1.2 },
		{ Name = "구리", Price = 2500, Power = 17, Speed = 1.06, Yield = 1.4 },
		{ Name = "철", Price = 24000, Power = 22, Speed = 1.09, Yield = 1.6 },
		{ Name = "강철", Price = 40000, Power = 29, Speed = 1.13, Yield = 1.9 },
		{ Name = "금", Price = 60000, Power = 37, Speed = 1.16, Yield = 2.2 },
		{ Name = "다이아", Price = 90000, Power = 48, Speed = 1.19, Yield = 2.6 },
		{ Name = "에메랄드", Price = 110000, Power = 63, Speed = 1.23, Yield = 3 },
		{ Name = "루비", Price = 140000, Power = 82, Speed = 1.27, Yield = 3.5 },
		{ Name = "사파이어", Price = 200000, Power = 106, Speed = 1.3, Yield = 4.1 },
		{ Name = "흑요석", Price = 260000, Power = 138, Speed = 1.34, Yield = 4.8 },
		{ Name = "화산암", Price = 340000, Power = 179, Speed = 1.38, Yield = 5.6 },
		{ Name = "빙하", Price = 500000, Power = 233, Speed = 1.43, Yield = 6.6 },
		{ Name = "우주", Price = 600000, Power = 303, Speed = 1.47, Yield = 7.7 },
		{ Name = "무한", Price = 700000, Power = 394, Speed = 1.51, Yield = 9 },
	},
	ModelPrefix = "Pickaxe_T", -- Pickaxe_T1 .. Pickaxe_T15
	PowerSteps = 10, -- per tier; back to 0 with a new tier
	PowerPerStep = 0.05,
	NextTierNeedsAllPowerSteps = true, -- the next tier can only be bought with all 10 power steps done
	NeedPowerSteps = { [2] = 3, [3] = 3 }, -- 임시값
	-- (2026-10-05, "메인은 디노디펜스에 맞춰야 하는데" → "그럼 그렇게 해") [tier] = the real defense level (rebirth tiers in it,
	-- Formulas.levelText) that tier needs: the pickaxes follow the defense, about 300 h for the last; tiers 1-5 free
	NeedLevel = { [6] = 80, [7] = 131, [8] = 180, [9] = 231, [10] = 280, [11] = 331, [12] = 380, [13] = 431, [14] = 460, [15] = 480 },
	-- (2026-10-01, "곡괭이 강화 쪽이 좀 비상식적인 강화비용인가" → A) a +5% power step cost about as much as the
	-- next pickaxe (from tier 11 on more), the 10 steps 5-40 times it. Each tier's money (its 10 steps +
	-- the next pickaxe, tools/economy_sim.py) is shared out again, the same total: the next pickaxe about
	-- 2 steps' worth (an even step's share × 2), at most a 4-hour wait (tools/income_sim.py; the other
	-- upgrades keep the 2.5-hour rule), the steps the rest, from 0.9 to 1.1 of an even share (a first step
	-- raised to the tier before's last where it was lower: in buying order they never go down). 임시값
	PowerStepCost = { -- [tier][step]: the cost of each power step
		{ 220, 230, 230, 240, 240, 250, 250, 260, 270, 270 }, -- tier 1
		{ 1500, 1500, 1600, 1600, 1600, 1700, 1700, 1700, 1800, 1800 }, -- tier 2
		{ 11000, 12000, 12000, 12000, 13000, 13000, 13000, 13000, 14000, 14000 }, -- tier 3
		{ 58000, 60000, 61000, 63000, 64000, 66000, 67000, 69000, 70000, 72000 }, -- tier 4
		{ 190000, 190000, 190000, 200000, 200000, 210000, 210000, 220000, 220000, 230000 }, -- tier 5
		{ 230000, 230000, 230000, 230000, 230000, 240000, 240000, 250000, 250000, 260000 }, -- tier 6
		{ 330000, 330000, 340000, 350000, 360000, 370000, 370000, 380000, 390000, 400000 }, -- tier 7
		{ 400000, 400000, 400000, 400000, 400000, 400000, 400000, 410000, 420000, 430000 }, -- tier 8
		{ 430000, 430000, 430000, 430000, 440000, 450000, 460000, 470000, 480000, 490000 }, -- tier 9
		{ 490000, 490000, 490000, 490000, 490000, 490000, 500000, 510000, 520000, 530000 }, -- tier 10
		{ 610000, 620000, 640000, 650000, 670000, 680000, 700000, 710000, 730000, 740000 }, -- tier 11
		{ 740000, 740000, 740000, 740000, 740000, 740000, 740000, 760000, 780000, 790000 }, -- tier 12
		{ 790000, 790000, 790000, 800000, 820000, 840000, 860000, 880000, 890000, 910000 }, -- tier 13
		{ 910000, 910000, 910000, 910000, 910000, 910000, 930000, 950000, 970000, 990000 }, -- tier 14
		{ 1100000, 1100000, 1100000, 1200000, 1200000, 1200000, 1200000, 1300000, 1300000, 1300000 }, -- tier 15
	},
	SpeedUpgrade = { -- one track, kept when the tier changes
		Levels = 30,
		PerLevel = 0.02,
		Cost = { -- cost to reach that level (tools/economy_sim.py)
			200, 270, 1100, 2100, 8500, 16000, 46000, 85000, 220000, 230000,
			250000, 260000, 390000, 400000, 420000, 430000, 470000, 490000, 520000, 530000,
			720000, 740000, 770000, 790000, 880000, 910000, 960000, 990000, 1200000, 1200000,
		},
	},
	ResetsOnRebirth = false, -- (2026-10-01: rebirth keeps the tier, power steps and the speed track)
}

-- ---------------------------------------------------------------------------
-- Move speed
-- ---------------------------------------------------------------------------

-- (2026-10-04, "차라리 신체강화나 곡괭이 강화 같은걸 기지 내에서 훈련으로 강화시킬 수 있게하자. 어차피 안 사게 되네. 훈련은
-- 그냥 해당 지역에서 훈련하면 계속 조금씩 경험치 얻어서 강화되는 식" → 훈련만 · 서 있기만 · 손바닥·이동속도·곡괭이 파워·속도·가방;
-- "강화 관련 모델링도 만들어놔", "튜토에도 반영하고 강화가 그렇게 빠르게 오르진 않도록", "적당히 잘 오르게") the five upgrades are
-- trained, not bought: four stations in every base (Training service; models Train_OreRock, Train_Dummy, Train_Treadmill,
-- Train_Sacks from tools/make_training.py, plain parts without them), at plot spot { across, depth } (MapBuilder's plot
-- coordinates: across from the middle, depth in from the entrance). Standing within Range studs of one for a second
-- trains its tracks (the ore rock both pickaxe tracks at once). Level n → n + 1 takes First × Growth^(n − 1) seconds of
-- standing there (the power steps counted over every tier: (tier − 1) × 10 + step), at most CapSeconds: the first few
-- in seconds, the last ones an hour or two; to the top of each about 10-30 hours there (tools: sums below). Boost: money
-- buys Multiplier times as fast training for Minutes (price BoostBase × BoostGrowth^(defense LV − 1)), the old shop
-- money's use now. 임시값
Config.Training = {
	Range = 9, -- studs from a station's middle
	CheckEvery = 1, -- seconds between steps of training (the server)
	CapSeconds = 7200, -- no level takes longer than this
	-- (2026-10-04, "훈련장 비슷한 위치에 4개를 한꺼번에 놔야지") one training ground, the stations 20 studs apart (the 9-stud
	-- rings just clear of each other); plot coordinates { across, in from the front }.
	-- (2026-10-04, "왼쪽 훈련장 두개를 리스폰 지점 옆으로 옮겨서 나머지 두 훈련장 아래에 맞게 붙이기") two by two beside the
	-- spawn pad (52.5, 27): the rock and the dummy in front of the treadmill and the sacks, the rock's ring 5 studs from the
	-- pad (the offline money pile moved in front of the pad, MoneyPile)
	Stations = {
		{ Id = "Rock", Model = "Train_OreRock", Name = "⛏️ 광물 바위", Tracks = { "Power", "Speed" }, Spot = { 70, 26 }, Color = { 90, 160, 255 } },
		{ Id = "Dummy", Model = "Train_Dummy", Name = "👋 찰싹 인형", Tracks = { "Slap" }, Spot = { 90, 26 }, Color = { 230, 120, 80 } },
		{ Id = "Treadmill", Model = "Train_Treadmill", Name = "👟 달리기 트랙", Tracks = { "MoveSpeed" }, Spot = { 70, 46 }, Color = { 120, 220, 120 } },
		{ Id = "Sacks", Model = "Train_Sacks", Name = "🎒 짐 나르기", Tracks = { "Bag" }, Spot = { 90, 46 }, Color = { 210, 170, 90 } },
	},
	-- per track: the first level's seconds and the growth (power about 30 hours to the top, its tiers bought)
	-- (2026-10-04, "훈련이 쉽나 밸런스 체크해봐" → A: the first hour at a station gave more than half the levels and the
	-- rest took about 10 hours; now about a third in the first hour, the top about 1.3 times later. Was Speed 15 / 1.2824
	-- (17.4 h), Slap 20 / 1.3118 (11 h), MoveSpeed 15 / 1.2462 (12 h), Bag 15 / 1.2557 (11.6 h).) 임시값
	Tracks = {
		Power = { First = 8, Growth = 1.0434, Name = "💥 곡괭이 파워" },
		-- (2026-10-05, "후반 컨텐츠가 힘든거지 거기까지 도달하는건 개빠른거임 초반부터 점점 느려지지만 전반적으로 개빠르다고") one
		-- curve for these four: 25 s, then 6% longer a step: 6 min step 10, 35 min the old top, about 4 h the top (slap 2 h).
		-- Were Speed 110 / 1.192 (82 h), and slap 165 / 1.186, move speed and bag 115 / 1.164 at 3 times the pace
		Speed = { First = 30, Growth = 1.07, Name = "⚡ 곡괭이 속도" },
		Slap = { First = 30, Growth = 1.07, Name = "👋 손바닥" },
		MoveSpeed = { First = 30, Growth = 1.07, Name = "👟 이동속도" },
		Bag = { First = 30, Growth = 1.07, Name = "🎒 가방" },
	},
	BoostMultiplier = 2,
	BoostMinutes = 10,
	BoostBase = 40000, -- money at defense LV 1 (2026-10-04 A: was 20,000, about 8% of a beginner's income an hour)
	BoostGrowth = 1.0165, -- 임시값
	-- (2026-10-04, "제안은 전부 진행") 👥 training with a friend: × (1 + FriendBonus) while a Roblox friend on this
	-- server is within FriendRange studs; friends may also train at each other's base stations
	FriendBonus = 0.2,
	FriendRange = 40,
	-- 🔧 훈련장 강화: each station of mine trains PerLevel faster a level (my own, wherever I train), Levels in all,
	-- bought at the station for Base × Growth^level (level 0 → 1: Base). One station to the top about 20M, all four
	-- about 82M (tools/income_sim.py's upgrade money: all four about 125 hours of it at 25 h, 50 at LV 100; the first
	-- levels a few minutes each)
	Gear = { Levels = 10, PerLevel = 0.1, Base = 40000, Growth = 1.5 }, -- 임시값
	-- (2026-10-04, "훈련도에 따라서 해당 부위에 이펙트 달아주자", "등급별로 색도 다르고 이펙트가") the look on the body
	-- (StarterPlayerScripts/TrainingLook): a track's grade is the last of LookShares of its top level its level reaches
	-- (Formulas.trainLookGrade), shown as LookMarks (the training panel) and in that grade's color and effects
	LookShares = { 0.15, 0.35, 0.55, 0.8, 1 },
	LookMarks = { "🟢", "🔵", "🟣", "🟠", "🌈" },
	-- (2026-10-04, "훈련레벨을 아주아주 많이 늘리고, 그에따라 레벨업 하는게 눈에 잘 띄게해줘. 사실상 다른건 없지만") every
	-- step of a track is several training levels (Formulas.trainShown: the step's seconds in equal parts); each one
	-- reached is a level-up everyone near sees (Net push TrainLevelFx). The steps and what they give are as before 임시값
	-- (2026-10-05, "레벨 단계도 통일해서 많이 올리고 경험치 쫙쫙 오르고 레벨업도 쫙쫙 보이게") every track Lv 1 → TopLevel, its steps
	-- sharing the levels evenly (Formulas.trainShown); was 10 levels a step (power 3,001, move speed 601 ...)
	TopLevel = 10000,
	FrontLoad = { Share = 1 / 3, Boost = 1.5 }, -- 임시값
	-- (2026-10-04) the look's grades (LookShares) are of these levels, the tracks' old tops (they go on past them now)
	LookTop = { Speed = 30, Slap = 25, MoveSpeed = 30, Bag = 30 },
}

Config.MoveSpeed = {
	Base = 16,
	Levels = 30,
	PerLevel = 0.4, -- 16 → 28
	CostBase = 200, -- cost = 200 × CostGrowth^(level − 1)
	CostGrowth = 1.42, -- (2026-10-04: was 1.35, the cheapest track: all 30 levels 55M → about 250M) 임시값
}

-- ---------------------------------------------------------------------------
-- Slap toy (no damage: a hit drops every carried key and throws the target; the level makes the
-- hand bigger and reach farther)
-- ---------------------------------------------------------------------------

Config.Slap = {
	Cooldown = 1.2, -- every level (draft)
	ReachBase = 8, -- 임시값: (was 5, then 6, then 7) studs a level-1 hand reaches in front of the slapper ...
	ReachPerScale = 4, -- 임시값: (was 3.5) ... + this per 1 of hand scale above 1 (level 25: 14)
	FrontDot = -0.25, -- 임시값: (was 0.2, about 78° either side) the target must be in front: within about 105° of
	-- the facing direction (cos of the angle) ...
	CloseRadius = 4, -- 임시값: ... or this close, on any side
	-- 임시값 (2026-10-01, "slaps miss while running"): the server sees everyone a moment late. It takes the
	-- slapper's own position and facing from their screen when within what their walk speed covers in
	-- TargetLagSeconds (+2, at most LagStuds) of where it has them, and
	-- counts a moving target also where it was TargetLagSeconds ago (where the slapper's screen shows it)
	LagStuds = 10,
	TargetLagSeconds = 0.25,
	LevelsPerLook = 5,
	Looks = { "Slap_Sponge", "Slap_Rubber", "Slap_Squeaky", "Slap_BearPaw", "Slap_GoldGod" },
	Scale = {
		1.00, 1.06, 1.13, 1.19, 1.25, 1.31, 1.38, 1.44, 1.50, 1.56,
		1.63, 1.69, 1.75, 1.81, 1.88, 1.94, 2.00, 2.06, 2.13, 2.19,
		2.25, 2.31, 2.38, 2.44, 2.50,
	},
	-- a hit throws the target up and Knockback[slapper's level] studs away in a high arc for FlightSeconds; after landing it
	-- lies groggy for GroggySeconds. Flying and groggy it can't move or be slapped again. 임시값
	FlightSeconds = 0.9, -- (was 0.75 for 10 studs) the arc peaks about 20 studs up
	-- slapping the fossils on your own defense track; fossils within FossilSplashRadius of
	-- the ones hit take FossilSplashShare of that too. The kill pays as usual. 임시값
	FossilDamage = 6, -- 임시값
	FossilDamageGrowth = 1.15, -- 임시값
	FossilTargetsBase = 1, -- fossils one slap hits (nearest first): this + 1 per FossilTargetsEveryLevels levels
	FossilTargetsEveryLevels = 5,
	FossilBossShare = 0.25, -- the promotion boss takes this share of a slap (a slap was a big part of its health)
	FossilSplashRadius = 5,
	FossilPush = 2, -- 임시값
	FossilBossPush = 0.25, -- 임시값
	FossilSplashShare = 0.3, -- (was 0.5)
	FossilHeight = 12, -- the slapper must be within this many studs above or below the arena
	GroggySeconds = 1,
	Knockback = { -- studs a hit throws the target, by the slapper's level (20 → 30; 임시값)
		20, 20.4, 20.8, 21.2, 21.7, 22.1, 22.5, 22.9, 23.3, 23.8,
		24.2, 24.6, 25, 25.4, 25.8, 26.2, 26.7, 27.1, 27.5, 27.9,
		28.3, 28.8, 29.2, 29.6, 30,
	},
	Cost = { -- cost to reach that level; level 1 is given
		0, 150, 270, 490, 880, 1600, 2800, 5100, 9200, 17000,
		30000, 54000, 96000, 174000, 312000, 562000, 1000000, 1800000, 3300000, 5900000,
		11000000, 19000000, 34000000, 62000000, 111000000,
	},
	DropsAllKeys = true, -- one hit drops every carried key, whatever the level
	-- slap skins (look only: the hit, reach and knockback stay the level's, and the skin is drawn at the
	-- level's Scale). Worn in the inventory's "👋 스킨" tab (Skins service); without one the level's look
	-- (Looks) shows. How each is had: Theme = every species of that theme collected (Farm), Collection =
	-- that many species × rarity pairs collected (Farm), Robux = sold for Robux only (the sale comes later:
	-- no product yet). Ids are kept in the profile's Skins. Models from tools/make_slap.py
	-- (2026-10-02, "찰싹 스킨들도 등급별로 이펙트 넣어주자") Grade: a rarity Id, by how hard it is to have; its
	-- color and effects when it swings and hits (CombatFx) and its border in the inventory. 임시값
	Skins = {
		{ Id = "Theme:Carnivore", Name = "티라노 발톱", Grade = "Rare", Model = "Slap_RexClaw", Theme = "Carnivore" },
		{ Id = "Theme:Herbivore", Name = "잎사귀 손", Grade = "Rare", Model = "Slap_LeafHand", Theme = "Herbivore" },
		{ Id = "Theme:Armored", Name = "등껍질 장갑", Grade = "Rare", Model = "Slap_ShellGlove", Theme = "Armored" },
		{ Id = "Theme:Sky", Name = "깃털 날개 손", Grade = "Rare", Model = "Slap_WingHand", Theme = "Sky" },
		{ Id = "Theme:Sea", Name = "지느러미 손", Grade = "Rare", Model = "Slap_FinHand", Theme = "Sea" },
		{ Id = "Theme:Variant", Name = "해골 손", Grade = "Legendary", Model = "Slap_BoneHand", Theme = "Variant" },
		-- 임시값: the counts (2026-10-01: 20/60/120/200 → 40/120/250/400; the Ids stay, skins already had stay)
		{ Id = "Dex:20", Name = "피자 손", Grade = "Rare", Model = "Slap_Pizza", Collection = 40 },
		{ Id = "Dex:60", Name = "얼음 손", Grade = "Epic", Model = "Slap_IceHand", Collection = 120 },
		{ Id = "Dex:120", Name = "문어 손", Grade = "Legendary", Model = "Slap_Octopus", Collection = 250 },
		{ Id = "Dex:200", Name = "왕의 손", Grade = "Mythic", Model = "Slap_Crown", Collection = 400 },
		-- (2026-10-01) rebirth skins: had at that many rebirths (임시값)
		{ Id = "Rebirth:1", Name = "비취 장갑", Grade = "Epic", Model = "Slap_Jade", Rebirth = 1 },
		{ Id = "Rebirth:3", Name = "자수정 손", Grade = "Legendary", Model = "Slap_Amethyst", Rebirth = 3 },
		{ Id = "Rebirth:5", Name = "불사조 손", Grade = "Mythic", Model = "Slap_PhoenixHand", Rebirth = 5 },
		-- (2026-10-02) season pass skins: tier 10 of the pass in a season of that theme (Config.Season.Themes)
		{ Id = "Season:Jurassic", Name = "공룡알 장갑", Grade = "Epic", Model = "Slap_EggShell", Season = 1 },
		{ Id = "Season:Lava", Name = "용암 주먹", Grade = "Epic", Model = "Slap_LavaFist", Season = 2 },
		{ Id = "Season:Coral", Name = "산호 손", Grade = "Epic", Model = "Slap_CoralHand", Season = 3 },
		{ Id = "Season:Star", Name = "별빛 장갑", Grade = "Epic", Model = "Slap_StarGlove", Season = 4 },
		{ Id = "Shop:CatPaw", Name = "고양이 발바닥", Grade = "Rare", Model = "Slap_CatPaw", Robux = 99 }, -- 임시값: the prices
		{ Id = "Shop:RoboArm", Name = "로봇 팔", Grade = "Epic", Model = "Slap_RoboArm", Robux = 199 },
		{ Id = "Shop:Neon", Name = "네온 장갑", Grade = "Epic", Model = "Slap_Neon", Robux = 199 },
		{ Id = "Shop:DragonClaw", Name = "용 발톱", Grade = "Legendary", Model = "Slap_DragonClaw", Robux = 399 },
		-- (2026-10-04) event skins: every mission of that event done (Config.LaunchEvent; only then, never sold)
		{ Id = "Event:Launch", Name = "런칭 파티 장갑", Grade = "Legendary", Model = "Slap_Launch", Event = "Launch1" },
	},
}

-- ---------------------------------------------------------------------------
-- (2026-10-04, "훈련단계가 원래도 너무 적었던거 같은데" → 단계 2~3배, 최고치도 위로) the trained tracks twice as long:
-- the levels up to the old top as they were (OldTop), every level past it gives a little more (PerLevelAfter and the
-- tables below go on more gently), each taking the training's longest level time (Config.Training.CapSeconds).
-- The look on the body still reaches its last grade at the old top (Config.Training.LookTop). 임시값
-- (2026-10-05, "극 후반 컨텐츠 끝난 사람은 아예 게임 내 벨붕 개사기 존재가 되게" → "맥스 달성할때 체감이 아니라 강해지는게 느껴지면서
-- 맥스일 땐 진짜 개사기 급") past the old top each level gives more than the one before ((past / extra)^AFTER_POWER of the
-- gain), up to far beyond everything else at the top; up to the old top as it was
-- ---------------------------------------------------------------------------
do
	local EXTRA = 30 -- levels past the old top: move speed, pickaxe speed and bag 30 → 60
	local SLAP_EXTRA = 25 -- slap 25 → 50
	local AFTER_POWER = 1.6
	local function round2(x) -- two significant figures, like the tables
		if x < 100 then
			return math.floor(x + 0.5)
		end
		local unit = 10 ^ (math.floor(math.log10(x)) - 1)
		return math.floor(x / unit + 0.5) * unit
	end
	local function extend(t, n, step)
		local last = t[#t]
		for i = 1, n do
			t[#t + 1] = step(last, i)
		end
	end
	-- 👟 move speed: past 30 (28) up to 64 at 60 (was +0.15 a level, 32.5)
	Config.MoveSpeed.OldTop = Config.MoveSpeed.Levels
	Config.MoveSpeed.Levels += EXTRA
	Config.MoveSpeed.PerLevelAfter = { Gain = 36, Levels = EXTRA, Power = AFTER_POWER }
	-- ⚡ pickaxe speed: past 30 (+60%) up to +300% at 60 (was +1% a level, +90%)
	local sp = Config.Pickaxe.SpeedUpgrade
	sp.OldTop = sp.Levels
	sp.Levels += EXTRA
	sp.PerLevelAfter = { Gain = 2.4, Levels = EXTRA, Power = AFTER_POWER }
	extend(sp.Cost, EXTRA, function(last, i)
		return round2(last * 1.12 ^ i)
	end)
	-- 🎒 bag: past 30 (4,096) +8.7% a level, 60: about 50,000 (was +4%, 13,300)
	Config.Bag.OldTop = #Config.Bag.Capacity
	extend(Config.Bag.Capacity, EXTRA, function(last, i)
		return math.floor(last * 1.087 ^ i + 0.5)
	end)
	extend(Config.Bag.Cost, EXTRA, function(last, i)
		return round2(last * 1.12 ^ i)
	end)
	-- 👋 slap: past 25 the hand 2.5 → 6 at 50 (reach 14 → 28), the throw 30 → 80 studs
	-- and one more fossil every FossilTargetsEveryLevelsAfter levels up to FossilTargetsMax (2026-10-05, "이 파워 인플레에
	-- 다른 시스템들도 조절해"), and the boss takes 40% of a level's damage step
	-- (was the hand +0.03 a level to 3.25, the throw to 35, 7 fossils)
	local sl = Config.Slap
	sl.OldTop = #sl.Scale
	extend(sl.Scale, SLAP_EXTRA, function(last, i)
		return math.floor((last + 3.5 * (i / SLAP_EXTRA) ^ AFTER_POWER) * 100 + 0.5) / 100
	end)
	extend(sl.Knockback, SLAP_EXTRA, function(last, i)
		return math.floor((last + 50 * (i / SLAP_EXTRA) ^ AFTER_POWER) * 10 + 0.5) / 10
	end)
	extend(sl.Cost, SLAP_EXTRA, function(last, i)
		return round2(last * 1.12 ^ i)
	end)
	sl.FossilTargetsEveryLevelsAfter = 3
	sl.FossilTargetsMax = 10
	sl.BossDamageAfterShare = 0.4
	-- (2026-10-04, "곡괭이 파워도 늘려. 광물 등급도 그에 맞춰 조정") ⛏️ power: 20 steps a pickaxe (was 10), +3% power each (all
	-- 20: +60%, was +50%: the most it may be, a new pickaxe's bare power must still beat the last one fully trained, the
	-- closest two 1.67 apart); the mining speed a step half (+2%: all 20 still +40%, carried to the next pickaxe as
	-- before); each step's money the old step's half twice (a pickaxe's price the same); the training a step half as long
	-- (Training.Tracks.Power: a pickaxe's steps take about as long as before). The minerals stay as they are: a grade's
	-- hardness is its recommended pickaxe's bare power (one base turn there), and the most a pickaxe gains is only a little
	-- more (+60% for +50%)
	local px = Config.Pickaxe
	px.PowerSteps = 20
	px.PowerPerStep = 0.01 -- 임시값
	for tier, costs in ipairs(px.PowerStepCost) do
		local split = {}
		for _, c in ipairs(costs) do
			table.insert(split, c / 2)
			table.insert(split, c / 2)
		end
		px.PowerStepCost[tier] = split
	end
	Config.Training.Tracks.Power.First = 4
	Config.Training.Tracks.Power.Growth = 1.0215
end

-- ---------------------------------------------------------------------------
-- Monsters and economy
-- ---------------------------------------------------------------------------

Config.Monsters = {
	Models = { "Monster_BoneRaptor", "Monster_BoneTrike", "Monster_BoneStego", "Monster_BonePtera", "Monster_BoneRex" },
	BossCrown = "Boss_Crown",
	-- (2026-10-03) what attribute hits leave on a fossil (tools/make_status.py; drawn by DefenseView)
	StatusModels = { "Status_Snow", "Status_IceBlock", "Status_Flame", "Status_Wet", "Status_Poison", "Status_Spark",
		"Status_Rocks", "Status_Crack", "Fx_PoisonPool" }, -- (Fx_: what an attack leaves on the track, tools/make_fx.py)
	HealthBase = 26, -- 26 × 1.035^(LV − 1) (임시값, 2026-10-01: was 20, defense too easy; more and three common dinos stall before LV 10)
	HealthGrowth = 1.035,
	-- 임시값 (2026-10-01, "going for the next rebirth the defense levels are too hard, so the rebirth money
	-- is hard to save"; then "upgraded to 12 and still can't pass the promotion"): past HealthGrowthAfterLevel
	-- (LV 60; was the first tier's top, LV 100) monsters grow HealthGrowthAfter a level, not
	-- 1.035: a tier (100 levels) was ×31 tougher while a player's dinos grow about ×4-5 over it (the next
	-- rarities and later species, the rebirth bonus); now ×5.9 a tier (was 1.05 past LV 300: ×131 a tier)
	HealthGrowthAfterLevel = 60, -- (2026-10-01: was 100) from here on
	HealthGrowthAfter = 1.018,
	-- 임시값 (2026-10-01, "defense harder", now that the farm can answer it): from HardFromLevel on, every
	-- level's monsters are HardGrowth times tougher again, up to HardUntilLevel (so × HardGrowth^(LV −
	-- HardFromLevel + 1) on top, at most about ×26 from LV 60): the first promotions stay as they were.
	-- (was from LV 6, ×1.02, to LV 80: "still easy") Three common dinos stop at LV 5; with a small farm
	-- they reach LV 9; rare ones need the farm too past LV 12 (tools/tests/defense_logic_test.lua)
	HardFromLevel = 5,
	HardGrowth = 1.06,
	-- (2026-10-01: was 40, then 60 "a tester reached LV 76 on the first day"; then 30: with the promotion
	-- fight simulated (DefenseLogic), even 8 golden big Lv 20 dinos at +300% power stopped near LV 65, so LV 100,
	-- the rebirth, could only be reached with test commands)
	HardUntilLevel = 30,
	KillRewardBase = 3.8, -- (2026-10-07, 돈 흐름 분석: 광질 수입이 디펜스의 2배 → ×1.3; was 5.85; was 0.8, then 1.0, then 1.3; ×3 with a third of the idle fossils, then ×0.5 with twice as many, then ×3 "the defense pays too little": 1.95, 2026-10-01) the arena pays more; it runs while the player does other things (임시값)
	ColorEveryLevels = 10,
	StarEveryLevels = 100,
	Colors = { "초록", "청록", "파랑", "남색", "보라", "분홍", "빨강", "주황", "노랑", "흰색" },
}

Config.Rebirth = {
	-- (2026-10-01) the defense level climbs in tiers: rebirth is only at the top of a tier and opens the
	-- next one. The level shown starts again at LV 1 with the tier's mark, but the real level goes on
	-- (better keys, rarity unlocks); the pickaxe and the bag stay. The first tier is FirstTierLevels long
	-- (2026-10-01, "the first rebirth after ~100 hours is too far": LV 30, about 8-10 hours of free play),
	-- every later one LevelsPerTier: tier 1 = real LV 31-130, tier 2 = 131-230, ... 임시값
	FirstTierLevels = 30,
	LevelsPerTier = 100,
	-- 임시값 (2026-10-01, "just reset the fossils' level on a rebirth, so players understand"; a reborn tester's
	-- 6 Lv 12 dinos couldn't pass LV 102): the fossils start again at LV 1 in every tier (Formulas.monsterHealth),
	-- MonsterHealthTiers[n] times as tough in tier n and MonsterHealthPerTier times more for each tier past the list.
	-- The rest (kill money, keys, unlocks) goes by the real level
	MonsterHealthTiers = { 9.5, 104, 166, 370, 720, 1450, 2500, 4700 },
	MonsterHealthPerTier = 1.5,
	-- display: the mark before "LV" for each tier (rebirths 0, 1, 2, ...); the last one repeats
	TierMarks = { "", "🟢", "🔵", "🟣", "🟠", "🔴", "⭐" },
	CostBase = 70000, -- 임시값
	CostGrowth = 1.6, -- 임시값
	MoneyBonusPerRebirth = 0.25, -- added up
	-- (2026-10-01, "make rebirth something players want") more for good with every rebirth, added up
	-- (Formulas.bonuses, on top of the farm's caps): all dinos' power, rare chance in draws, placement
	-- slots (at most MaxSlotsFromRebirth). 임시값
	UnitPowerPerRebirth = 0.25, -- (2026-10-01: was 0.10, so the next tier's climb starts easier)
	RareChancePerRebirth = 0.05,
	SlotsPerRebirth = 1,
	MaxSlotsFromRebirth = 5,
	-- keys given at once with every rebirth (saved keys by grade): RewardKeys[n] for the nth rebirth,
	-- the last one again after that. 임시값
	RewardKeys = {
		{ Gold = 3, Ruby = 1 },
		{ Gold = 5, Ruby = 2 },
		{ Ruby = 3, Diamond = 1 },
		{ Ruby = 4, Diamond = 2 },
		{ Diamond = 3, Rainbow = 1 },
	},
	-- the rebirth-only dinos (Config.RebirthSpecies): each comes with its own rebirth (Rebirth = n), and
	-- after the last of them every SpecialDinoEvery-th rebirth gives one of them at random. It comes at
	-- the best rarity open at the player's level, SpecialRarityBelowTop grades down, and SpecialSize. 임시값
	SpecialDinoEvery = 5,
	SpecialRarityBelowTop = 2, -- (2026-10-02: 1; the rarities now open at the awakening itself, a grade lower keeps it near the old)
	SpecialSize = "Giant",
	Keeps = { "Slap", "MoveSpeed", "Pickaxe", "Bag" }, -- (2026-10-01: the pickaxe and bag did reset; the shown level starts over)
	SignRange = 10, -- 임시값: studs from the rebirth sign beside the base's spawn pad
}

-- (2026-10-02) a species opening with an awakening (UnlockRebirths = n) opens at that tier's first real level
for _, s in ipairs(Config.Species) do
	if s.UnlockRebirths then
		s.UnlockLevel = Config.Rebirth.FirstTierLevels + (s.UnlockRebirths - 1) * Config.Rebirth.LevelsPerTier + 1
	end
end

Config.Unlocks = require(script.Parent:WaitForChild("ConfigUnlocks")) -- 임시값
Config.Practice = { -- 임시값
	ZombieCount = 3,
	BossHits = 10,
	BossBack = 3,
	BossChests = 3,
	BossChestSpread = 9,
	HitGap = 0.6,
	ZombieBody = 2.5,
	BossBody = 5,
	TreeSeconds = 2,
	TreeStand = 2.4,
	TreeOn = 1.5,
	MeetRange = 14,
	CountSeconds = 6,
	RunDistance = 25,
	CatchRange = 5,
	CatchPause = 2.5,
	SurviveSeconds = 12,
	PlayRadius = 40,
	SeekerSee = 24,
	SeekerSeeDisguised = 5,
	SeekerSpeed = 10,
	SeekerRoam = 26,
	SeekerPause = { 1.5, 3.5 },
	RetryGap = 5,
	ThiefBody = 3,
	ThiefRoam = 16,
	ThiefSpeed = 9,
	ThiefBack = 1.1,
	GuardBoxAhead = 8,
	GuardBoxEvery = 5,
	GuardCatch = 4,
	GuardRest = 2,
	GuardChaseRange = 40,
}

-- ---------------------------------------------------------------------------
-- Monetization (Robux prices are drafts)
-- ---------------------------------------------------------------------------

-- (2026-10-01) checked against free play with tools/monetization_sim.py (design 11): a small pack gives
-- about an hour of free play for ~80-100 R$, bulk up to ~60% cheaper; keys and money come in hours of
-- the buyer's own income so a pack is worth the same at every level. All 임시값 (stage 10 builds them)
Config.Products = { -- developer products
	-- once per account, shown once after the tutorial: 2 hours of keys, 3 gold keys (each the best of 144
	-- draws, inside the open rarities), 30 minutes of luck ×2 (was 20 keys + a legendary: legendary
	-- opens at LV 20, after the pack is shown)
	StarterPack = { Robux = 49, KeyHours = 6, SpecialKeys = { Gold = 5, Ruby = 1 }, LuckMinutes = 60, SureBelowTop = 1,
		SureMinRarity = "Legendary", OncePerAccount = true }, -- 임시값
	ServerLuckBoost = { Robux = 99, Minutes = 30, LuckMultiplier = 2, CrownMinutes = 30 }, -- the whole server
	ServerLuckBoostBig = { Robux = 399, Minutes = 60, LuckMultiplier = 3, CrownMinutes = 60 },
	LuckPotion = { Robux = 49, Minutes = 15, LuckMultiplier = 2 },
	LuckPotionBig = { Robux = 149, Minutes = 60, LuckMultiplier = 2 },
	-- (2026-10-02) this week's limited dino's share 1% → Gacha.LimitedPotionChancePercent for Minutes (more add time)
	LimitedLuckPotion = { Robux = 69, Minutes = 15, LimitedMultiplier = 3 },
	-- move speed is never sold for good (it decides the key chases): only this, +SpeedBonus while it lasts,
	-- more potions add time, not speed; carrying keys still slows
	-- (2026-10-01) money earned by playing ×MoneyMultiplier for Minutes; more add time; with the DoubleMoney pass
	-- it adds nothing (never ×4), so the shop hides it then; not doubled by the first purchase's bonus
	MoneyBoost = { Robux = 49, Minutes = 60, MoneyMultiplier = 2 },
	-- (2026-10-01) the race record (wins and losses, over the head) back to 0-0. 임시값
	RaceRecordReset = { Robux = 25 },
	SpeedPotion = { Robux = 29, Minutes = 15, SpeedBonus = 0.2 },
	SpeedPotionBig = { Robux = 99, Minutes = 60, SpeedBonus = 0.2 },
	-- (was "legendary or better ×10" for 999: at LV 50 a free player draws one every ~50 keys, 2-5 hours of
	-- play for 999) ruby keys: each the best of 490 draws (Formulas.keyPicks) inside the open rarities, the shop's 400 keys'
	-- worth: about 9 hours of free drawing for the five at LV 20, 6 at LV 200
	-- (2026-10-02, "로벅스 아이템 가격" → 999 → 799: at 999 the 899 key pack gave more at every level; 임시값)
	-- (2026-10-02) 5 → 15 keys: a ruby key became the best of 490 draws (was 1,728; Formulas.keyPicks), so the
	-- pack's worth stays about the same ("돈 쓴거잖아"). 임시값
	RubyKeys = { Robux = 799, SpecialKeys = { Ruby = 30 } }, -- 임시값
	-- (2026-10-02: was 1,499 R$ with no rarity set, "시세가 맞나" → 499 and a sure legendary) this week's limited dino
	-- (🎖️, Limited service) at Rarity and Size, once a limited week (the shop hides it after; 임시값)
	-- (2026-10-02, the same check: a sure legendary was below what a LV 50+ player draws anyway) its rarity is the
	-- buyer's best open one RarityBelowTop grades down, at least MinRarity (Formulas.limitedDinoRarity; 임시값)
	-- (2026-10-02, the same check: 499 R$ for a 전설·큰 was less than the free attendance dino, 전설·거대) 초거대
	LimitedDino = { Robux = 499, PerWeek = 1, MinRarity = "Legendary", RarityBelowTop = 1, Size = "Colossal" },
	PromotionRevive = { Robux = 10, Lives = 10, OfferSeconds = 60, WatchRange = 200 }, -- 임시값 (2026-10-07) lives all lost: once a fight, ❤️ back to Lives; bought too late: no wait before the next try
	-- (2026-10-02) this season's pass: the pass rewards of every tier reached and to come (Config.Season); bought
	-- again each season. Leads to keys, so not sold where paid random items are restricted. 임시값
	SeasonPass = { Robux = 249 },
	SlapSkinMinRobux = 99,
	SlapSkinMaxRobux = 399,
	PremiumSlapSkinRobux = 799, -- a moving premium skin (looks only)
	-- key packs and VIP's daily keys: KeysPerHour × the home value at the buyer's level an hour (a free
	-- player draws about that from the altar, minerals and promotions: 150 at LV 3, 240 at LV 100)
	KeysPerHour = 100,
	KeyPackIncomeShare = 0.5, -- 임시값
	MoneyPackKeyShare = 0.5, -- 임시값
}

-- (2026-10-01: were 10 / 50 / 150 keys for 79 / 349 / 899: 3 to 60 minutes of free play, 900-2,400 R$ an hour)
Config.KeyPacks = {
	{ Id = "Small", Robux = 79, Hours = 3 }, -- 임시값
	{ Id = "Medium", Robux = 349, Hours = 15 },
	{ Id = "Large", Robux = 899, Hours = 45 },
	{ Id = "Huge", Robux = 2499, Hours = 150 },
}

-- dino skins: another look for one species (look only: the same dino, stats and all), bought with Robux.
-- (2026-10-01) modeled ahead, not on sale yet: no product ids and no way to wear them in the game so far
-- (Model: tools/dinos.json / make_dino.py, exports/Dino_<Model>.fbx). Prices 임시값
Config.DinoSkins = {
	{ Id = "TRexGalaxy", Species = "TRex", Name = "우주 티라노", Model = "Dino_TRexGalaxy", Robux = 199 },
	{ Id = "RaptorNinja", Species = "Raptor", Name = "닌자 랩터", Model = "Dino_RaptorNinja", Robux = 149 },
	{ Id = "TrikeCandy", Species = "Trike", Name = "사탕 트리케라", Model = "Dino_TrikeCandy", Robux = 149 },
	{ Id = "StegoRobot", Species = "Stego", Name = "로봇 스테고", Model = "Dino_StegoRobot", Robux = 199 },
	{ Id = "PteranodonPhoenix", Species = "Pteranodon", Name = "불사조 프테라", Model = "Dino_PteranodonPhoenix", Robux = 199 },
	{ Id = "MosaShark", Species = "Mosa", Name = "상어 모사", Model = "Dino_MosaShark", Robux = 149 },
}

Config.GamePasses = {
	-- (was 249, then 399: it halves the base content, 210 → 105 hours, for good; 2026-10-01 "forever is strong":
	-- 799, a big spender's pass, and the 1-hour MoneyBoost product for everyone else)
	DoubleMoney = { Robux = 799, MoneyMultiplier = 2 },
	-- (2026-10-02, "결제상품인데 주변에만가서 알아서 캐지는건 좀 너무하다"; was: standing in reach started the
	-- nearest mineral) the player's character runs to the mineral worth the most money a second, mines it, and
	-- with a full bag runs home and empties it; switched on and off by its button (StarterPlayerScripts/AutoMine).
	-- CheckSeconds: how often it looks (moving by hand switches it off: StarterPlayerScripts/AutoMine);
	-- SkipSeconds: a mineral stopped by hand or out of reach is left alone this long; GiveUpSeconds: one walk
	-- at most. 임시값
	-- Zombies (2026-10-02, "좀비등이랑 만나면 어떻게 할지"): it never fights; minerals with a zombie within
	-- ZombieAvoid studs (a boss: BossAvoid) are left out, one within ZombieFlee (BossFlee) makes it stop and go
	-- home with a bag, or FleeStuds away (Config.Zombies AggroRange 28 / Boss 45: just outside them). 임시값
	AutoMine = { Robux = 249, CheckSeconds = 0.3, SkipSeconds = 30, GiveUpSeconds = 40,
		ZombieAvoid = 36, ZombieFlee = 24, BossAvoid = 70, BossFlee = 50, FleeStuds = 40 },
	-- (2026-10-01: was 199) the bag ×2 alone earned only +6-21% (fewer trips home): it mines MiningSpeedBonus
	-- faster too, so it clearly pays (+30-45% mining money). 임시값
	DoubleBag = { Robux = 249, CapacityMultiplier = 2, MiningSpeedBonus = 0.2 },
	PlacementSlot = { Robux = 349, Slots = 1 }, -- (2026-10-01: was 199, then 299; defense power for good, the best pass)
	FarmSlots = { Robux = 199, Slots = 10 }, -- (2026-10-01: was 149)
	-- (was 5 keys a day: two minutes of play) half an hour of keys a day (Products.KeysPerHour)
	-- (2026-10-02: was 0.5 hour of keys, weaker than the attendance rewards) a day: an hour of keys and a silver key
	-- (2026-10-02, design 14 "대체 혜택은 미정") where paid random items are restricted (Policy) the keys lead to
	-- draws, so a VIP there gets RestrictedDaily instead: SpeedMinutes of the speed potion (Products.SpeedPotion's
	-- bonus; 29 R$ for 15 minutes, so about 58 R$ a day against the keys' hour, a 79 R$ pack) and bombs of
	-- each kind (up to Bombs.MaxHeld). Nothing of it turns into draws. 임시값
	VIP = { Robux = 299, DailyKeyHours = 3, DailySpecialKeys = { Silver = 2, Gold = 1 }, -- 임시값
		RestrictedDaily = { SpeedMinutes = 30, Bombs = { Egg = 3, Poop = 3 } } },
}

-- instant upgrade with Robux: one level at a time; levels outside every band are game money only
Config.InstantBuy = {
	ShowWhenMinutesShort = 10, -- only show the Robux button if earning the gap takes 10+ minutes
	Slap = { { From = 6, To = 10, Robux = 19 }, { From = 11, To = 15, Robux = 39 }, { From = 16, To = 20, Robux = 79 },
		{ From = 21, To = 25, Robux = 129 } },
	PickaxeTier = { { From = 5, To = 7, Robux = 29 }, { From = 8, To = 10, Robux = 59 }, { From = 11, To = 13, Robux = 99 },
		{ From = 14, To = 15, Robux = 149 } },
	Bag = { { From = 9, To = 15, Robux = 15 }, { From = 16, To = 22, Robux = 35 }, { From = 23, To = 30, Robux = 69 } },
}

Config.MoneyPacks = { -- hourly income = average of the last hour of mining and hunting, without boosts
	-- (2026-10-02, "로벅스 아이템 가격" → about a quarter less: 1/5/15/50 hours were worth 1.3 hours of
	-- upgrading each, a free player spending half the money on keys; 36-64 R$ an hour of play against
	-- the aim of 100, now about 48-85 like the key packs. 임시값)
	{ Id = "Small", Robux = 79, Hours = 0.75 },
	{ Id = "Medium", Robux = 349, Hours = 4 },
	{ Id = "Large", Robux = 899, Hours = 11 },
	{ Id = "Huge", Robux = 2499, Hours = 37 },
}

-- Stage 10, step 1 (2026-10-01, Monetization service): what is on sale now, the Roblox ids to fill in from
-- the Creator Dashboard (0 = not made yet: hidden in a live game; Studio grants it at once for testing),
-- the first purchase's bonus and when the starter pack is offered. 임시값
Config.Monetization = {
	-- developer products on sale (the keys in Config.Products, KeyPack_<Id>, MoneyPack_<Id>) and their ids
	ProductIds = {
		-- (2026-10-02, the Creator Dashboard's ids)
		StarterPack = 3715878524, LuckPotion = 3715878580, LuckPotionBig = 3715878640,
		ServerLuckBoost = 3715878857, ServerLuckBoostBig = 3715878897,
		SpeedPotion = 3715878926, SpeedPotionBig = 3715878948, RubyKeys = 3715879815, MoneyBoost = 3715878969,
		RaceRecordReset = 3715878989, LimitedLuckPotion = 3715950286, LimitedDino = 3715950333, SeasonPass = 3715949502,
		KeyPack_Small = 3715879025, KeyPack_Medium = 3715879048, KeyPack_Large = 3715879075, KeyPack_Huge = 3715879100,
		MoneyPack_Small = 3715879127, MoneyPack_Medium = 3715879161, MoneyPack_Large = 3715879231, MoneyPack_Huge = 3715879180,
		PromotionRevive = 3717008278,
		BoxRush1 = 3717051151, BoxRush2 = 3717051192, BoxRush3 = 3717051238, BoxRush4 = 3717051295,
	},
	-- game passes on sale (Config.GamePasses) and their ids (2026-10-02, the Creator Dashboard's passes: shown on
	-- the game page's Store tab, owned on Roblox's side. DoubleMoney stays a developer product: it leads to draws,
	-- so it is hidden where paid random items are restricted, and a game pass is sold on the Store tab to everyone)
	GamePassIds = { DoubleMoney = 0, DoubleBag = 2005388374, PlacementSlot = 2005340387, FarmSlots = 2004902394,
		VIP = 2005364394, AutoMine = 2005988388 },
	-- (2026-10-02) the same passes made as developer products on the Creator Dashboard instead: bought once and
	-- kept for good in the save (profile Passes), as a game pass. A key uses its GamePassIds id when that is set,
	-- else this one (the five with a game pass now: their developer products go off sale; a player who bought one
	-- keeps it in the save)
	PassProductIds = { DoubleMoney = 3715879302, DoubleBag = 3715879396, PlacementSlot = 3715879334,
		FarmSlots = 3715879463, VIP = 3715879364, AutoMine = 3715879434 },
	-- (2026-10-01, "big spenders shouldn't finish too fast") key and money packs: at most this many of each a day
	-- (the day of Config.Rewards); the 💎 shop greys a pack out at its limit (a purchase Roblox already
	-- charged is still given). 임시값
	PackDailyLimit = { Small = 5, Medium = 3, Large = 2, Huge = 1 },
	-- the very first Robux purchase of a key or money pack gives this many times as much ...
	FirstPurchaseMultiplier = 2,
	-- ... but at most this many hours more (2026-10-02, "첫 구매 ×2 최대 5시간치까지만": the 50-hour pack was
	-- 100 hours at 25 R$ an hour). The starter pack (already about 6 times the packs' worth) doesn't get it
	-- and doesn't use it up. 임시값
	FirstPurchaseMaxBonusHours = 15, -- 임시값 (2026-10-05: ×3 with the key packs)
	-- (2026-10-02, "과금 상품에 불만이 없을지" → "문제 해결해봐": a 79 R$ pack is ~200 draws, and about half its buyers
	-- saw no legendary, far below the pity's 500) the first key pack an account buys (any size, even after a money
	-- pack) also gives one draw whose first dino is at least this rarity (profile GuaranteedDraws, Gacha). 임시값
	FirstKeyPackGuaranteed = "Legendary",
	-- (2026-10-02, "현질 아이템들이 확실히 의미있는지" → "일부를 황금 열쇠로": normal keys stop at Legendary, so after an
	-- awakening a 2,499 R$ pack gave no mythic or better at all) this share of a key pack's worth comes as gold keys
	-- (each its Config.Keys.Types PriceMultiplier normal keys; at least one), the rest as normal keys. 임시값
	KeyPackGoldShare = 0.3,
	-- (2026-10-04, "구매 광고는 접속했을때 띄우고 나중에 랜덤적으론 띄우지 말자. 튜토하는 사람은 튜토 끝나고") the starter
	-- pack pops up once a session, OfferJoinSeconds after the player has joined and is free (the tutorial done or
	-- skipped, nothing asked of them; never on a tutorial field), while it is not bought; on their screen when no other
	-- window is open. It used to pop up after the first draw and the first promotion lost. 임시값
	OfferJoinSeconds = 8,
	-- the server luck boost's buyer: a crown and "🍀 행운 선물" over the head while it lasts, a big banner to all
	BoostBannerSeconds = 8,
}

-- The community reward (Community service, 2026-10-01, "a reward for joining the community, in the base, enough
-- to help a complete beginner"): a sign at the front of every base; a player in the game's Roblox group takes
-- Reward once per account (about the first half hour's worth: keys for a dozen draws and two silver keys,
-- money for the first bag and pickaxe upgrades, luck ×2). GroupId: the group's id (0 = not made yet). 임시값
Config.Community = {
	GroupId = 0,
	Reward = { Keys = 30, SpecialKeys = { Silver = 2 }, MoneyChests = 10 },
	LuckMinutes = 15,
	SignRange = 12,
}

-- Robux products that lead to paid random items; blocked when PolicyService says they are restricted
Config.RestrictedProducts = { "KeyPacks", "MoneyPacks", "StarterPack", "LuckPotion", "LuckPotionBig", "ServerLuckBoost",
	"ServerLuckBoostBig", "LimitedLuckPotion", "RubyKeys", "DoubleMoney", "MoneyBoost", "SeasonPass" } -- (LimitedDino: a set dino, not random)
for i, rush in ipairs(Config.Boxes.Rush) do
	Config.Products["BoxRush" .. i] = rush
	table.insert(Config.RestrictedProducts, "BoxRush" .. i)
end

-- ---------------------------------------------------------------------------
-- Live events
-- ---------------------------------------------------------------------------

Config.Weekly = {
	LimitedRotationWeekday = 7, -- Saturday (os.date("*t").wday)
}

-- ---------------------------------------------------------------------------
-- Tutorial and starter missions (tutorial rules are separate from the main game)
-- ---------------------------------------------------------------------------

-- the tutorial's numbers and lines: ReplicatedStorage/ConfigTutorial (Config.lua must stay under Roblox's
-- 200,000 characters a script)
Config.Tutorial = require(script.Parent:WaitForChild("ConfigTutorial"))
Config.Story = require(script.Parent:WaitForChild("ConfigStory"))

-- (2026-10-01, "추가된 내용들도 튜토리얼에서 알려줄수 있게") Coco's tips (design 10 나중에 열리는 안내): what
-- the tutorial can't show in the base, told the first time it comes up (StarterPlayerScripts/Hints). Each
-- tip once per account (profile Hints, Net request HintSeen), none while the tutorial runs; one at a time.
-- NearStuds: how close counts for the "near something" tips (the race road, a wild dino, a treasure chest). 임시값
Config.Hints = {
	PromoNudge = { FirstMinutes = 4, EveryMinutes = 6, Times = 3, UntilLevel = 20 }, -- 임시값
	-- (2026-10-04, "뉴비 팁도 알림으로 뜨는거, 너무 글로만 돼있지 않나..아이들 입장에 맞추랬지") every tip a short picture line:
	-- its first emoji is the notice's big badge (Shared/Notices), then pictures and arrows with few words
	Tips = {
		{ Id = "BagFull", Text = "🎒 가방 꽉! → 💰 입금 → 💪 짐 나르기로 키우기" },
		{ Id = "Slapped", Text = "🎁 맞으면 상자 와르르! 🏠 기지에 넣어야 내 거" },
		{ Id = "SlotsFull", Text = "🦖 자리 꽉! ➕ 자리 늘리기 · 🌾 농장에 넣기" },
		{ Id = "PromoBoss", Text = "👑 보스 약점 = 🧪 그 속성 공룡이 💥 더 세게!" },
		{ Id = "DamageBoard", Text = "📊 🩺 옆 간판에 공룡마다 때린 양! 💤 못 때린 공룡은 길 가까이" },
		{ Id = "HelpSlap", Text = "🤝 남의 보스 웨이브도 👋 찰싹으로 도와요! 같이 이기면 🔑" },
		{ Id = "Night", Text = "🌙 밤엔 🧟 좀비! 👋 찰싹으로 날려!" },
		{ Id = "Boss", Text = "👑🧟 보스! 다 같이 👋 → 🔑 열쇠 + 🦴 뼈" }, -- (2026-10-04: was 💣 money)
		{ Id = "Aurora", Text = "🌌 오로라 보스! 다 같이 잡으면 🎁 큰 선물" },
		{ Id = "KingKey", Text = "👑🎁 왕 상자 = 🎁×5! 들고 가는 사람을 👋" },
		{ Id = "Guardian", Text = "🛡️ 좋은 상자일수록 지킴이가 빨라요! 💨 발판도 소용없어요 · 👟 이동속도 훈련!" },
		{ Id = "BoxLock", Text = "🔒 좋은 상자는 🔄 환생해야 들 수 있어요!" },
		{ Id = "Bombs", Text = "💣 들판에서 던져! 펑 → 주변 모두 👋 · 🦴 내 화석 길에도" },
		{ Id = "Race", Text = "🏁 레이스 · 🙈 숨바꼭질 한 판마다 🔑 열쇠! 🎮 놀이방에서 같이" },
		{ Id = "Wild", Text = "🦕 야생 공룡! 가까이 → 🦖 올라타기" },
		{ Id = "WildFeed", Text = "🍎 타고 있을 때 먹이 주면 ⏱️ 더 오래 타요!" },
		{ Id = "TopView", Text = "👋 찰싹 위 🗺️ 탑뷰! 위에서 👆 눌러 옮기기" },
		{ Id = "Nest", Text = "🐣 바위 둥지엔 아무 공룡이나 한 마리만! 📏 사거리 ×1.5" },
		{ Id = "Perch", Text = "🏔️ 하늘 바위엔 🦅 하늘 공룡만! 📏 더 멀리 · 관통 +1" },
		{ Id = "Twist", Text = "🎲 변칙 승급전! 맞는 공룡만 싸워요 · 💤 나머지는 쉬어요 · 🔑 보너스" },
		{ Id = "ClaimAll", Text = "🎁 받을 보상이 많으면 → 🎁 모두 받기 한 번에!" },
		{ Id = "EnhanceBulk", Text = "⬆️ 강화 재료는 💎 등급 버튼으로 한 번에 골라요" },
		{ Id = "BoxReady", Text = "📦 상자 다 됐어요! 위의 📦 → 📦 모두 열기" },
		{ Id = "FreeSkip", Text = "🎟️ 무료 바로 열기권이 있어요! 위의 📦 → 🎟️ 무료로 열기" },
		{ Id = "BoxWait", Text = "⏳ 좋은 상자일수록 오래 걸려요! 나중에 와서 열어요" },
		{ Id = "Chest", Text = "📦 보물상자! 👆 꾹 → 💰" },
		{ Id = "Rebirth", Text = "🔝 LV 끝! 🔄 환생 → 💪 더 세게 + 🦖 새 공룡" },
		-- (2026-10-02, "그걸 유저들에게 알릴 방법 있을까? 코코로") after the first awakening, once
		{ Id = "NewRarities", Text = "🔓 새 등급 열림! 🎰 다음 뽑기 1번은 새 등급 확정" },
		-- (2026-10-02, "코코의 팁 지금까지 업데이트한 내용들 더 추가")
		{ Id = "Storm", Text = "⚡ 빛나는 바닥 = 번개! 🏃 원 밖으로" },
		{ Id = "Weather", Text = "🌧️ 비 · 🌈 무지개 = 💰 돈 몇 배!" },
		{ Id = "Attendance", Text = "📆 매일 들어오면 🎁 선물!" },
		{ Id = "Friends", Text = "👫 친구랑 같이 = 💰 +10% · 🔑 열쇠" },
		{ Id = "Limited", Text = "🎖️ 이번 주 한정 공룡! 🎰 뽑기에서 가끔" },
		{ Id = "Variant", Text = "✨ 변종 공룡 = ⚪ 은 열쇠부터!" },
		{ Id = "RidePractice", Text = "⏱️ 혼자 레이스 기록전도 OK! (Z · X)" },
		{ Id = "DayBuff", Text = "🎉 어젯밤 보스 잡음! ☀️ 오늘 낮 보너스 ⬆️" },
		{ Id = "PoopBomb", Text = "💩 똥 폭탄 = 🧟 · 🦴 화석 꼼짝 못 해!" },
		-- (2026-10-02) 공룡 사육 and the new 합성
		{ Id = "Fruit", Text = "🌳 나무 👋 → 🍎 열매 = 바로 공룡 먹이" }, -- (2026-10-05: food at once)
		{ Id = "FruitCarry", Text = "🍎 들고 🏠 기지로 = 먹이! ⬇️ 친구에게도" },
		{ Id = "Feed", Text = "🍎 먹이 모임! 🦖 강화 가판대 → 🍎 탭" },
		{ Id = "Merge", Text = "🧬 공룡 3마리 → ⬆️ 더 좋은 1마리!" },
		-- (2026-10-02, "튜토리얼이 모든 걸 필요한 만큼 설명해 주나" → 강화 방법·칸 늘리기 · 새 기능 팁)
		{ Id = "Enhance", Text = "🦖 남는 공룡 = ⬆️ 강화 재료!" },
		{ Id = "Challenge", Text = "♾️ 도전! 몇 판 버틸까? 🏆 순위 선물" },
		{ Id = "DexTitle", Text = "📖 칭호 얻음! 더 모으면 🔑 + 새 칭호" },
		-- (2026-10-03) near the board by the key altar
		{ Id = "HideSeek", Text = "🙈 숨바꼭질! 방 열기 → 2명 이상 준비" },
		-- (2026-10-03) the first game as a hider: the traps and the heartbeat
		{ Id = "HideTrap", Text = "🕸️ 함정 놓기! 📡 경고 뜨면 멈춰요 · 💓 빨라지면 술래가 가까이" },
		-- (2026-10-06) the defense roads: the first fossil through the end gate, the first group, the maps a rebirth opens
		{ Id = "Leak", Text = "💔 화석이 빠지면 ❤️가 줄어요! 👑 보스는 ❤️ 전부 · 길 끝에도 🦖" },
		{ Id = "Group", Text = "🚩 화석 무리! 깃발 든 화석부터 👋" },
		{ Id = "NewMap", Text = "🗺️ 새 맵! 아레나 옆 🗺️ 맵 게시판에서 바꿔요" },
		{ Id = "Shell", Text = "🥚 껍질 화석! 깨지면 작은 화석이 튀어나와요" },
		{ Id = "Immune", Text = "🧱🧊🌋 안 통하는 화석! 🦖 종류를 섞어요 · 🎯 대상 바꾸기" },
		{ Id = "Airship", Text = "🎈 화석 비행선! 💪 센 공룡으로 · 떨어지면 우르르" },
		{ Id = "Sprinter", Text = "🏃 질주 화석! 🎯 '🏁 맨 앞' 공격 · ❄️ 얼음으로" },
		{ Id = "TipsOff", Text = "⚙️ 팁 끄기는 설정에서!" },
	},
	VariantTipLevel = 5, -- the variants' tip from this defense level (after the first steps)
	EnhanceTipSpare = 5, -- (2026-10-02) the enhance tip once this many dinos are neither placed nor on the farm
	ChallengeTipLevel = 10, -- (2026-10-02) the ♾️ 무한 도전 tip from this defense level
	TipsOffAfter = 3, -- the "you can turn tips off" tip once this many were shown
	NearStuds = 30,
	GapSeconds = 6, -- at least this long between two tips
	FromLevel = 2,
}

-- the beginner mission board: ReplicatedStorage/ConfigStarter (2026-10-03: moved out, Config.lua must stay under
-- Roblox's 200,000 characters a script)
Config.StarterMissions = require(script.Parent:WaitForChild("ConfigStarter"))

-- ---------------------------------------------------------------------------
-- Technical: saving, requests from clients, movement checks, Studio test commands
-- (design: 기술 원칙; the design gives the rules, the numbers here are placeholders)
-- ---------------------------------------------------------------------------

Config.Watchdog = { -- finding stalls (Watchdog service, StarterPlayerScripts/LagCheck). 임시값
	PingEvery = 2, -- seconds between the client's checks that the server answers
	SlowAfter = 3, -- no answer for this long: the "server is slow" banner
	RetrySeconds = 10, -- a Ping waiting this long is sent again (one lost while the phone slept)
	LagWarnSeconds = 1, -- a server frame longer than this is written to the server's log
	ErrorsPerMinute = 10, -- client errors written to the log at most this often per player
	JoinGraceSeconds = 45, -- no "server is slow" banner this long after joining (the map is still coming in)
	PerfReportGap = 60, -- 임시값
}

-- (2026-10-02, 비공개 베타 준비 "튜토리얼 완료율, 막히는 레벨, 재방문율, 결제 전환율") what goes to Roblox's
-- analytics (Analytics service): the economy (money in and out, summed by reason) and counted actions
-- every FlushSeconds and when the player leaves; promotion fights won and lost as each level's
-- progression. (The tutorial's funnel is the Tutorial service's; visits and Robux are Roblox's own.)
-- (2026-10-04, "나 Honey_anana 는 개발자 입장이라 랭킹에 안 올라야 할 거 같은데 모든 랭킹에서 나만 안뜨게 해줘") the game's
-- developers, by Roblox user name (any case): left out of every ranking (all servers' and this server's lists, the weekly
-- ranked games, the bounty #1), and the only ones who see the 🐢 slow-screen banner outside Studio (PerfCheck)
Config.Developers = {
	Names = { "Honey_anana" },
	StarterReplay = 2,
}

Config.DevGifts = {
	am600295 = { Passes = { "VIP" } },
}

Config.Analytics = {
	FlushSeconds = 300,
	-- money reasons (PlayerData.addMoney / spendMoney) -> Roblox's transaction types; the rest are "Gameplay"
	TransactionTypes = {
		purchase = "IAP", reward = "TimedReward", offline = "TimedReward",
		pickaxe = "Shop", power = "Shop", speed = "Shop", bag = "Shop", slot = "Shop", farmslot = "Shop",
		keys = "Shop", bomb = "Shop",
	},
	-- Rewards.add kinds counted and sent as custom events
	CountedKinds = { "Draws", "Enhance", "Place", "Boss", "KeysHome", "StealKeys", "Chests", "WildRide", "Bell", "Comeback" },
	-- (2026-10-04, "본게임에서 광질 조금 하다 가던데") a new player's first steps in the game, each logged once ever
	-- (Roblox's funnel Name: AnalyticsService:LogFunnelStepEvent, the run is the player's UserId): Kind = a Rewards.add
	-- kind done the first time, Minutes = play time reached (profile.PlaySeconds), Tier = the pickaxe tier reached, none
	-- = arriving. Saves from before it have played already (profile.FirstPlay.Done); nothing on a tutorial field
	FirstPlay = {
		Name = "FirstPlay5",
		CheckSeconds = 15, -- how often play time and the pickaxe are looked at
		Steps = {
			{ Id = "Arrive" },
			{ Id = "IntroDone", Kind = "IntroDone" },
			{ Id = "Draw", Kind = "Draws" },
			{ Id = "Box", Kind = "BoxOpen" },
			{ Id = "Place", Kind = "Place" },
			{ Id = "Win2", Level = 2 },
			{ Id = "KeyBuy", Kind = "KeyBuy" },
			{ Id = "Play5", Minutes = 5 },
			{ Id = "Win3", Level = 3 },
			{ Id = "Play10", Minutes = 10 },
			{ Id = "Win5", Level = 5 },
			{ Id = "Enhance", Kind = "Enhance" },
			{ Id = "Play20", Minutes = 20 },
			{ Id = "Play40", Minutes = 40 },
		},
	},
}

-- (2026-10-02, 비공개 베타 준비 "업데이트 소식 창 + 버그 신고 버튼 + 오류 기록 저장"; BetaLog service,
-- Shared/BetaWindows) what testers tell us and what broke, kept in a DataStore by day (read in Studio with
-- ;reports / ;errors), and the update news shown once per Version on joining. 임시값
Config.Beta = {
	StoreName = "BetaLog_v1", -- DataStore: "Reports_<day>" (bug reports), "Errors_<day>" (script errors, merged)
	FlushSeconds = 60, -- what was collected is written this often (and when the server closes)
	ReportMaxLength = 300, -- characters of a bug report
	InboxDays = 14, -- 임시값
	InboxMax = 60, -- 임시값
	ReportMinLength = 4, -- shorter is turned away ("조금 더 자세히")
	ReportCooldown = 60, -- seconds between one player's reports
	ReportsPerDay = 10, -- one player's reports a day at most
	ReportsKeptPerDay = 400, -- reports kept a day (all servers; the oldest go first past it)
	ErrorsKeptPerDay = 200, -- different errors kept a day (the same error again only counts up)
	ErrorTextLength = 300, -- characters of an error's message and of its trace kept
	RecentErrorsInReport = 3, -- a report carries the reporter's last few script errors
	Survey = {
		AfterMinutes = 10, -- 임시값
		CheckSeconds = 30,
		Up = { { Id = "Mine", Text = "⛏️ 캐기" }, { Id = "Draw", Text = "🎰 뽑기" }, { Id = "Defense", Text = "⚔️ 디펜스" },
			{ Id = "Slap", Text = "👋 찰싹" }, { Id = "Ride", Text = "🦖 공룡 타기" }, { Id = "Play", Text = "🎮 놀이방" } },
		Down = { { Id = "Slow", Text = "🐢 지루해요" }, { Id = "Hard", Text = "😣 어려워요" }, { Id = "Slapped", Text = "👋 맞아서 짜증나요" },
			{ Id = "Lost", Text = "❓ 뭘 할지 몰라요" }, { Id = "Lag", Text = "🐌 렉이 걸려요" }, { Id = "Shop", Text = "💎 사라는 창이 많아요" } },
	},
	LikeAsk = { Times = 2, GapMinutes = 30, PlayMinutes = 15, BoxFrom = "Legendary", Levels = { 3, 5 } }, -- 임시값
	Mail = {
		SecretName = "BugMail",
		UrlPrefix = "https://script.google.com/macros/s/",
		UrlSuffix = "/exec",
		EverySeconds = 60,
		MaxPerMail = 20,
		MaxQueued = 60,
		Subject = "🐞 Dino game reports: %d",
		FilterFailed = "(filter failed: read it with ;reports in Studio)",
	},
	ReportKinds = { -- the buttons on the report window (Id saved with the report)
		{ Id = "Bug", Name = "🐞 버그" },
		{ Id = "Stuck", Name = "😵 막혔어요" },
		{ Id = "Idea", Name = "💡 의견" },
	},
	News = require(script.Parent:WaitForChild("ConfigNews")),
}

Config.Leaderboard = { -- the all-server ranking on the central board (Leaderboards service). 임시값
	StoreName = "GlobalRank_v5", -- OrderedDataStore: UserId -> the real defense level (rebirth tiers count on)
	WriteSeconds = 120, -- each player's score is written at most this often (and when they leave)
	ReadSeconds = 120, -- the top list is read again this often
	Top = 10, -- how many the all-server list keeps
	-- (2026-10-02, "탈 공룡 창 밑에 자기 기록이랑 전 서버 기록 지상이랑 공중") the best race times: OrderedDataStores
	-- RaceStoreName .. "_Road" / "_Sky", UserId -> hundredths of a second (lowest first); the top RaceTop shown
	RaceStoreName = "RaceBest_v5",
	RaceTop = 3,
	-- (2026-10-03, "숨박꼭질도 랭킹을..") 🙈 hide-and-seek wins of all servers: OrderedDataStore HideSeekStoreName, UserId ->
	-- games won (written at each win); the top Top shown in the hide-and-seek window, the top HideSeekBoardTop on its board
	HideSeekStoreName = "HideSeekWins_v5",
	HideSeekBoardTop = 3,
}

Config.Data = {
	StoreName = "PlayerData_v5", -- DataStore name; a new name starts every player from scratch
	Version = 4,
	StartMoney = 0, -- 임시값
	StartKeys = 34, -- 임시값
	AutosaveInterval = 60, -- 임시값
	-- 임시값: a lock older than this is from a crashed server and may be taken over. A live server
	-- refreshes its lock with every autosave, so 3 autosaves (2026-10-01, was 1800: a player kicked with
	-- "couldn't load" after a disconnect waited up to half an hour)
	SessionLockTimeout = 180,
	LoadWaitSeconds = 90, -- 임시값: how long a joining player waits for another server to let go of the save (was about 30)
	ReleaseTopic = "ReleaseLock", -- MessagingService topic: "let go of this player's save" (PlayerData)
	RetryDelay = 2, -- 임시값: seconds, grows with each attempt ...
	RetryDelayMax = 6, -- ... up to this
	SaveAttempts = 3, -- 임시값
	CloseTimeout = 25, -- 임시값: how long a closing server waits for the last saves
}

Config.Net = { -- per player and per request type
	RateLimitPerSecond = 15, -- 임시값
	RateLimitBurst = 30, -- 임시값
	-- (2026-10-02, the hacking check) no request carries a longer string or a bigger table than this (a cheat
	-- sending megabytes, or tables in tables, is turned away before any handler; the most a real one sends:
	-- an error trace, 100 dinos' ids at the enhance stall)
	MaxStringLength = 1000,
	MaxTableItems = 120,
	-- (2026-10-02) the asks with big answers, slower than the rest: a cheat asking 15 times a second would make
	-- the server send every arena's fossils (tens of KB each time) over and over. The game asks them when a
	-- window opens or the data changes, far less often. { per second, burst } 임시값
	Limits = {
		GetDefense = { 1, 3 },
		GetMyUnits = { 3, 10 },
		GetInventory = { 3, 10 },
		GetCollection = { 3, 10 },
		GetRewards = { 3, 10 },
		GetSeason = { 3, 10 }, -- (2026-10-02, the 🏆 window: 30 tiers × 2 in words)
		GetMyData = { 2, 5 },
	},
}

-- (2026-10-04, "유저가 나무위 등반해서 숨으니까 재밌네. 기본적으로 나무위 등반할 수있게 하자") 🌳 climbing trees
-- (StarterPlayerScripts/Climb, ServerScriptService/Services/TreeClimb): walking into a tree's trunk with the stick or
-- the keys for PushSeconds climbs it at Speed studs a second; at the trunk's top a hop onto it (HopSeconds), standing
-- in the leaves. Jumping or letting go of the stick lets go. 임시값
Config.Climb = {
	Speed = 12,
	PushSeconds = 0.2,
	Reach = 1.5, -- studs past the body's side the trunk is felt
	HopSeconds = 0.25,
}

Config.MoveGuard = { -- design: a position change bigger than the upgraded move speed allows is undone
	Enabled = true,
	CheckInterval = 0.5, -- 임시값
	SpeedTolerance = 1.5, -- 임시값: allowed = speed × time × this + ExtraStuds
	ExtraStuds = 6, -- 임시값
	CatchUpSeconds = 2.5, -- 임시값
	StillStuds = 0.5, -- 임시값
	GraceAfterSpawn = 3, -- 임시값: seconds without checks after a server teleport; a new character has this long to show up at a spawn
	-- (2026-10-01, the cheat check) 임시값
	LooseSpeed = 60, -- studs a second fine while a move the player set off lasts (a slap's flight: 30 in 0.9 s)
	SpawnRadius = 25, -- a new character within this of a SpawnLocation is where it should be
	FlyGap = 14, -- nothing under the character this far down (a jump's top is about 10 above the ground) ...
	FallStuds = 3, -- ... and not this much lower than a check ago (falling) ...
	FlyChecks = 4, -- ... this many checks in a row: flying, back to where it last stood
}

Config.Policy = {
	RestrictedWhenUnknown = true, -- if PolicyService fails, treat the player as restricted (the safe side)
	Attempts = 3, -- 임시값
}

Config.DevCommands = { -- Studio only (RunService:IsStudio()); never in a real server
	Prefix = ";",
}

Config.Bell = { -- the 🔔 button: show everyone where I am (Bell service). 임시값
	Cooldown = 5, -- seconds between rings, so nobody spams it (2026-10-01: was 30, then 10, "too long")
	MarkSeconds = 10, -- how long the mark stands where it was rung
}

Config.UI = {
	NoticeSeconds = 5, -- 임시값: how long a notice stays on screen
	-- 임시값: seconds to hold down a prompt that spends (buying slots), so a
	-- stray tap does nothing (Shared/HoldButton). (2026-10-01: the shop's upgrades, key buys and the key
	-- exchange are a plain tap now, "just touch")
	HoldSeconds = 1,
}

-- ---------------------------------------------------------------------------
-- Freeze everything so game code can only read it
-- ---------------------------------------------------------------------------

local function deepFreeze(t)
	for _, v in pairs(t) do
		if type(v) == "table" and not table.isfrozen(v) then
			deepFreeze(v)
		end
	end
	return table.freeze(t)
end

return deepFreeze(Config)
