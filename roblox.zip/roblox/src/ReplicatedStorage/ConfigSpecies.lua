local M = {}

-- first release: 24 species, then the first update's 6 (30). Model = the Blender asset name (exports/Dino_{Id}.fbx).
-- Attributes follow the design's theme × attribute table.
-- (2026-10-02, "할 게 점점 많아지면서 수집창고 보면서 뿌듯해하는 그런 감성" → 공룡 해금을 각성까지 펼치기) each theme's ten:
-- three at LV 1, two at LV 10, one at LV 25, then one with each of the first four awakenings (UnlockRebirths: its
-- UnlockLevel is that tier's first real level, set below Config.Rebirth), so every awakening brings 5 new dinos. 임시값
M.Species = {
	{ Id = "TRex", Name = "티라노", Theme = "Carnivore", Attribute = "Neutral", UnlockLevel = 1 },
	{ Id = "Raptor", Name = "랩터", Theme = "Carnivore", Attribute = "Electric", UnlockLevel = 1 },
	{ Id = "Trike", Name = "트리케라톱스", Theme = "Herbivore", Attribute = "Earth", UnlockLevel = 1 },
	{ Id = "Iguanodon", Name = "이구아노돈", Theme = "Herbivore", Attribute = "Neutral", UnlockLevel = 1 },
	{ Id = "Ankylo", Name = "안킬로사우루스", Theme = "Armored", Attribute = "Earth", UnlockLevel = 1 },
	{ Id = "Pachy", Name = "파키케팔로사우루스", Theme = "Armored", Attribute = "Neutral", UnlockLevel = 1 },
	{ Id = "Pteranodon", Name = "프테라노돈", Theme = "Sky", Attribute = "Water", UnlockLevel = 1 },
	{ Id = "Mosa", Name = "모사사우루스", Theme = "Sea", Attribute = "Water", UnlockLevel = 1 },
	{ Id = "Spino", Name = "스피노", Theme = "Carnivore", Attribute = "Water", UnlockLevel = 10 },
	{ Id = "Brachio", Name = "브라키오", Theme = "Herbivore", Attribute = "Water", UnlockLevel = 10 },
	{ Id = "Stego", Name = "스테고", Theme = "Armored", Attribute = "Fire", UnlockLevel = 10 },
	{ Id = "Rhampho", Name = "람포링쿠스", Theme = "Sky", Attribute = "Fire", UnlockLevel = 10 },
	{ Id = "Plesio", Name = "플레시오", Theme = "Sea", Attribute = "Ice", UnlockLevel = 10 },
	{ Id = "Krono", Name = "크로노", Theme = "Sea", Attribute = "Earth", UnlockRebirths = 2 },
	{ Id = "Dilopho", Name = "딜로포", Theme = "Carnivore", Attribute = "Poison", UnlockRebirths = 2 },
	{ Id = "Parasaur", Name = "파라사우", Theme = "Herbivore", Attribute = "Electric", UnlockRebirths = 2 },
	{ Id = "Kentro", Name = "켄트로", Theme = "Armored", Attribute = "Poison", UnlockRebirths = 2 },
	{ Id = "Quetzal", Name = "케찰", Theme = "Sky", Attribute = "Neutral", UnlockRebirths = 4 },
	{ Id = "Microraptor", Name = "미크로랍토르", Theme = "Sky", Attribute = "Electric", UnlockRebirths = 2 },
	{ Id = "Shoni", Name = "쇼니", Theme = "Sea", Attribute = "Ice", UnlockRebirths = 4 },
	{ Id = "IceRex", Name = "얼음 티라노", Theme = "Variant", BaseTheme = "Carnivore", Attribute = "Ice", UnlockLevel = 1, MinKey = "Gold" },
	{ Id = "RoboRaptor", Name = "로봇 랩터", Theme = "Variant", BaseTheme = "Carnivore", Attribute = "Electric", UnlockLevel = 1, MinKey = "Gold" },
	{ Id = "MagmaTrike", Name = "마그마 트리케라톱스", Theme = "Variant", BaseTheme = "Herbivore", Attribute = "Fire", UnlockLevel = 1, MinKey = "Ruby" },
	{ Id = "FlameSpino", Name = "불꽃 스피노", Theme = "Variant", BaseTheme = "Carnivore", Attribute = "Fire", UnlockLevel = 1, MinKey = "Gold" },
	-- (2026-10-01, "그냥 모델링만 추가한 거지") the update's species are plain species like the first ones:
	-- each theme's six spread over LV 1, 10 and 25, drawn as often, no extra damage. The variants (변종,
	-- Theme "Variant") open at LV 1 but only better keys give them: each from its MinKey and better (2026-10-02,
	-- "금열쇠 + 루비열쇠+ 종류들도 구분해줘": 은+ 3, 황금+ 3, 루비+ 2, 다이아+ 1, 무지개 1; Gacha.VariantMinKey when
	-- it has none). 임시값
	{ Id = "Allo", Name = "알로사우루스", Theme = "Carnivore", Attribute = "Fire", UnlockLevel = 1 },
	{ Id = "Nodo", Name = "노도사우루스", Theme = "Armored", Attribute = "Ice", UnlockLevel = 1 },
	{ Id = "Ichthyo", Name = "이크티오사우루스", Theme = "Sea", Attribute = "Electric", UnlockLevel = 1 },
	{ Id = "Therizino", Name = "테리지노사우루스", Theme = "Herbivore", Attribute = "Poison", UnlockLevel = 25 },
	{ Id = "Dimorpho", Name = "디모르포돈", Theme = "Sky", Attribute = "Poison", UnlockLevel = 1 },
	{ Id = "ThunderStego", Name = "번개 스테고", Theme = "Variant", BaseTheme = "Armored", Attribute = "Electric", UnlockLevel = 1, MinKey = "Silver" },
	-- (2026-10-01) the rest of the design's 60 (테마 × 속성 table). Models: tools/dinos.json → exports/new/2026-10-01_species (Argentino: the wild giant's model)
	{ Id = "Utahraptor", Name = "유타랍토르", Theme = "Carnivore", Attribute = "Ice", UnlockLevel = 10 },
	{ Id = "Edmonto", Name = "에드몬토사우루스", Theme = "Herbivore", Attribute = "Ice", UnlockLevel = 1 },
	{ Id = "Pterodac", Name = "프테로닥틸루스", Theme = "Sky", Attribute = "Ice", UnlockLevel = 1 },
	{ Id = "Notho", Name = "노토사우루스", Theme = "Sea", Attribute = "Electric", UnlockLevel = 1 },
	{ Id = "Baryonyx", Name = "바리오닉스", Theme = "Carnivore", Attribute = "Water", UnlockLevel = 25 },
	{ Id = "Maia", Name = "마이아사우라", Theme = "Herbivore", Attribute = "Neutral", UnlockLevel = 10 },
	{ Id = "Huayango", Name = "후아양고사우루스", Theme = "Armored", Attribute = "Water", UnlockLevel = 25 },
	{ Id = "PoisonDilopho", Name = "독 딜로포", Theme = "Variant", BaseTheme = "Carnivore", Attribute = "Poison", UnlockLevel = 1, MinKey = "Silver" },
	{ Id = "Carno", Name = "카르노타우루스", Theme = "Carnivore", Attribute = "Earth", UnlockRebirths = 1 },
	{ Id = "Styraco", Name = "스티라코사우루스", Theme = "Herbivore", Attribute = "Fire", UnlockRebirths = 1 },
	{ Id = "Gastonia", Name = "가스토니아", Theme = "Armored", Attribute = "Electric", UnlockRebirths = 1 },
	{ Id = "Stegoceras", Name = "스테고케라스", Theme = "Armored", Attribute = "Neutral", UnlockLevel = 10 },
	{ Id = "Ornitho", Name = "오르니토케이루스", Theme = "Sky", Attribute = "Electric", UnlockLevel = 10 },
	{ Id = "Tylo", Name = "틸로사우루스", Theme = "Sea", Attribute = "Poison", UnlockLevel = 25 },
	{ Id = "GemStego", Name = "보석 스테고", Theme = "Variant", BaseTheme = "Armored", Attribute = "Earth", UnlockLevel = 1, MinKey = "Silver" },
	{ Id = "Cerato", Name = "케라토사우루스", Theme = "Carnivore", Attribute = "Earth", UnlockRebirths = 3 },
	{ Id = "Diplo", Name = "디플로도쿠스", Theme = "Herbivore", Attribute = "Electric", UnlockRebirths = 3 },
	{ Id = "Euoplo", Name = "에우오플로케팔루스", Theme = "Armored", Attribute = "Ice", UnlockRebirths = 3 },
	{ Id = "Tupux", Name = "투푹수아라", Theme = "Sky", Attribute = "Fire", UnlockLevel = 25 },
	{ Id = "Anurog", Name = "아누로그나투스", Theme = "Sky", Attribute = "Poison", UnlockRebirths = 1 },
	{ Id = "Elasmo", Name = "엘라스모사우루스", Theme = "Sea", Attribute = "Electric", UnlockLevel = 10 },
	{ Id = "ClockBrachio", Name = "태엽 브라키오", Theme = "Variant", BaseTheme = "Herbivore", Attribute = "Earth", UnlockLevel = 1, MinKey = "Ruby" },
	{ Id = "Giganoto", Name = "기가노토사우루스", Theme = "Carnivore", Attribute = "Fire", UnlockRebirths = 4 },
	{ Id = "Argentino", Name = "아르젠티노사우루스", Theme = "Herbivore", Attribute = "Earth", UnlockRebirths = 4 },
	{ Id = "Saichania", Name = "사이카니아", Theme = "Armored", Attribute = "Fire", UnlockRebirths = 4 },
	{ Id = "Hatzego", Name = "하체고프테릭스", Theme = "Sky", Attribute = "Earth", UnlockRebirths = 3 },
	{ Id = "Archelon", Name = "아르켈론", Theme = "Sea", Attribute = "Earth", UnlockRebirths = 1 },
	{ Id = "Liopleuro", Name = "리오플레우로돈", Theme = "Sea", Attribute = "Neutral", UnlockRebirths = 3 },
	{ Id = "CosmoMosa", Name = "우주 모사", Theme = "Variant", BaseTheme = "Sea", Attribute = "Water", UnlockLevel = 1, MinKey = "Rainbow" },
	{ Id = "CyberAnkylo", Name = "사이버 안킬로", Theme = "Variant", BaseTheme = "Armored", Attribute = "Neutral", UnlockLevel = 1, MinKey = "Diamond" },
	-- (2026-10-02, "각성+열쇠 둘 다 필요한 공룡 3종") awakened variants: drawn only by a player with at least
	-- MinRebirths rebirths (각성) AND with a MinKey key or better; VariantPower instead of VariantPowerByKey
	-- (above every plain variant, among the rebirth dinos). Not counted for a theme's completion. 임시값
	{ Id = "AuroraParasaur", Name = "오로라 파라사우롤로푸스", Theme = "Variant", BaseTheme = "Herbivore", Attribute = "Ice",
		UnlockLevel = 1, MinKey = "Diamond", MinRebirths = 1, VariantPower = 2.5 },
	{ Id = "StormQuetzal", Name = "폭풍 케찰코아틀루스", Theme = "Variant", BaseTheme = "Sky", Attribute = "Electric",
		UnlockLevel = 1, MinKey = "Diamond", MinRebirths = 2, VariantPower = 2.8 },
	{ Id = "SolarAllo", Name = "태양 알로사우루스", Theme = "Variant", BaseTheme = "Carnivore", Attribute = "Fire",
		UnlockLevel = 1, MinKey = "Rainbow", MinRebirths = 3, VariantPower = 3.3 },
	{ Id = "Yutyrannus", Name = "유티란누스", Theme = "Carnivore", Attribute = "Ice", UnlockRebirths = 5, HighRebirth = true }, -- 임시값
	{ Id = "Tapejara", Name = "타페자라", Theme = "Sky", Attribute = "Water", UnlockRebirths = 5, HighRebirth = true },
	{ Id = "Amarga", Name = "아마르가사우루스", Theme = "Herbivore", Attribute = "Poison", UnlockRebirths = 6, HighRebirth = true },
	{ Id = "Temno", Name = "템노돈토사우루스", Theme = "Sea", Attribute = "Fire", UnlockRebirths = 6, HighRebirth = true },
	{ Id = "Scolo", Name = "스콜로사우루스", Theme = "Armored", Attribute = "Electric", UnlockRebirths = 7, HighRebirth = true },
	{ Id = "Cryolo", Name = "크리올로포사우루스", Theme = "Carnivore", Attribute = "Electric", UnlockRebirths = 7, HighRebirth = true },
	{ Id = "Nycto", Name = "닉토사우루스", Theme = "Sky", Attribute = "Neutral", UnlockRebirths = 8, HighRebirth = true },
	{ Id = "Kosmo", Name = "코스모케라톱스", Theme = "Herbivore", Attribute = "Ice", UnlockRebirths = 8, HighRebirth = true },
	{ Id = "Tany", Name = "타니스트로페우스", Theme = "Sea", Attribute = "Poison", UnlockRebirths = 9, HighRebirth = true },
	{ Id = "Dracorex", Name = "드라코렉스", Theme = "Armored", Attribute = "Earth", UnlockRebirths = 9, HighRebirth = true },
	{ Id = "Concave", Name = "콘카베나토르", Theme = "Carnivore", Attribute = "Neutral", UnlockRebirths = 10, HighRebirth = true },
	{ Id = "Deino", Name = "데이노케이루스", Theme = "Herbivore", Attribute = "Water", UnlockRebirths = 10, HighRebirth = true },
}

-- (2026-10-02, "고급 공룡들의 성능도 밸런스 조절") a variant hits harder the better the key it needs (MinKey), not the
-- theme's flat DamageMultiplier 1.3 for all: a rainbow-key variant was no stronger than a silver-key one of the
-- same rarity. On top of its original theme's damage. 임시값
M.VariantPowerByKey = { Silver = 1.3, Gold = 1.45, Ruby = 1.6, Diamond = 1.8, Rainbow = 2.0 }

-- (2026-10-01) dinos only rebirth gives (Config.Rebirth): never in draws, the collection or the theme
-- counts. Rebirth = the rebirth that gives it; DamageMultiplier on top of the theme's damage. Models:
-- tools/dinos.json → exports/Dino_<Id>.fbx. 임시값
-- (2026-10-02) 2 / 2.5 / 3 → 2.2 / 2.6 / 3: above the best key variants (VariantPowerByKey) of the same rarity
M.RebirthSpecies = {
	{ Id = "PhoenixRex", Name = "불사조 렉스", Theme = "Carnivore", Attribute = "Fire", UnlockLevel = 1, Rebirth = 1,
		DamageMultiplier = 2.2 },
	{ Id = "CrystalAnkylo", Name = "수정 안킬로", Theme = "Armored", Attribute = "Earth", UnlockLevel = 1, Rebirth = 2,
		DamageMultiplier = 2.4, CatchUp = true }, -- 임시값
	{ Id = "StarTrike", Name = "별빛 트리케라톱스", Theme = "Herbivore", Attribute = "Electric", UnlockLevel = 1, Rebirth = 3,
		DamageMultiplier = 2.6 },
	{ Id = "AbyssKrono", Name = "심해왕 크로노", Theme = "Sea", Attribute = "Water", UnlockLevel = 1, Rebirth = 4,
		DamageMultiplier = 2.8, CatchUp = true }, -- 임시값
	{ Id = "GoldPtera", Name = "황금 프테라노돈", Theme = "Sky", Attribute = "Ice", UnlockLevel = 1, Rebirth = 5,
		DamageMultiplier = 3 },
	{ Id = "AuroraBrachio", Name = "오로라 브라키오", Theme = "Herbivore", Attribute = "Ice", UnlockLevel = 1, Rebirth = 6,
		DamageMultiplier = 3.15, CatchUp = true }, -- 임시값
	{ Id = "ThunderRaptor", Name = "천둥 랩터", Theme = "Carnivore", Attribute = "Electric", UnlockLevel = 1, Rebirth = 7,
		DamageMultiplier = 3.3, CatchUp = true }, -- 임시값
	{ Id = "SunQuetzal", Name = "태양 케찰", Theme = "Sky", Attribute = "Fire", UnlockLevel = 1, Rebirth = 8,
		DamageMultiplier = 3.45, CatchUp = true }, -- 임시값
	{ Id = "VenomStego", Name = "독안개 스테고", Theme = "Armored", Attribute = "Poison", UnlockLevel = 1, Rebirth = 9,
		DamageMultiplier = 3.6, CatchUp = true }, -- 임시값
	{ Id = "DivineRex", Name = "신룡 렉스", Theme = "Carnivore", Attribute = "Neutral", UnlockLevel = 1, Rebirth = 10,
		DamageMultiplier = 3.8, CatchUp = true }, -- 임시값
}

-- (2026-10-04, "튜토 끝내면 신규 게임 런칭 웰컴 기념 한정 공룡 하나 선물해주자. 빛깔 멋진걸로 얼리어댑터에게 주는 호칭같은
-- 느낌으로", "튜토 안 끝내고 그냥 나와도 일단 1회는 한정공룡 주면서 창 띄우는거야", "막 대단한거 받은 거처럼") dinos that are
-- only ever given, never drawn (looked up like any species; their models shared like the others)
M.GiftSpecies = {
	-- (2026-10-04, "웰컴렉스는 초반에 유용하게", "등급은 특별 등급으로 하나 새로 만들어") ⚡ electric: its chain hits
	-- several fossils at once — the early promotions are lost to too many fossils, not to tough ones (a neutral one,
	-- hitting one at a time, moved nothing: 3 commons and it + 2 commons both stopped at level 8). Its grade ⭐ 특별
	-- (Config.SpecialRarities). DefenseLogic sim, the best of the spot orders by the portal: 3 commons stop at level 8,
	-- it + 2 commons at 15 (an epic 랩터 + 2 commons: 11, a legendary one: 12); 3 epics 15, it + 2 epics 21; 3
	-- legendaries 21, it + 2 legendaries 21 — better than any epic, overtaken once the team is legendary
	{ Id = "WelcomeRex", Name = "웰컴 렉스", Theme = "Carnivore", Attribute = "Electric", UnlockLevel = 1 },
	-- (2026-10-04, the night boss's ②) the 🦴 bone dinos: BossKind's bones (Config.Zombies.Boss.BonesForDino of them)
	-- become one (Zombies service), their models the boss kinds' own (Dino_ZombieRex / Trike / Ptera); the 프테라 flies
	-- when ridden, like any 하늘 one. 임시값
	{ Id = "ZombieRex", Name = "좀비 티라노", Theme = "Carnivore", Attribute = "Poison", UnlockLevel = 1, BossKind = "Rex" },
	{ Id = "ZombieTrike", Name = "좀비 트리케라", Theme = "Herbivore", Attribute = "Earth", UnlockLevel = 1, BossKind = "Trike" },
	{ Id = "ZombiePtera", Name = "좀비 프테라", Theme = "Sky", Attribute = "Ice", UnlockLevel = 1, BossKind = "Ptera" },
}

return M
