--[[
ConfigEvent: Config.LaunchEvent, the 🎉 launch event's missions (Rewards service, RewardLogic; the 🎁 window's 🎉 tab).
Config.lua puts it at Config.LaunchEvent and freezes it with the rest. Read it as Config.LaunchEvent, never this
module directly.
]]
-- (2026-10-04, "런칭 이벤트 임무도 하나 만들자", "임무 칸, 임무들 졸요하면 스킨 주든가 칭호 주든가 뭐 하면 되지") 🎉 the launch
-- event (Rewards service, RewardLogic; the 🎁 window's 🎉 이벤트 tab): missions through the whole game, counted from a
-- player's first play while it runs (Rewards.add kinds: any of Kinds), each with its Reward once done (받기); every one
-- taken: AllReward — the event-only slap skin (Config.Slap.Skins Event = Id), the title over the head (Title) and its
-- keys. A new Id starts the missions over (the skin and title stay had). LastDay: the last day number (Config.Rewards'
-- days) missions count; nil = until it is set (the launch day is not fixed yet); done ones can be taken after. 임시값
return {
	Id = "Launch1",
	Name = "🎉 런칭 이벤트",
	Title = "🎉 런칭 개척자",
	LastDay = nil,
	-- (2026-10-04, "런칭 기념 미션 광고 띄워줘야지 접속할 때마다 … 보상도 쫙 멋지게", "런칭 이벤트 보상은 통크게 가고",
	-- "밸붕급 하진말고 적당히 좋네 수준") bigger: was 0.1 h of keys or 1 silver key each, all done 1 gold key. Now in all
	-- 0.75 h of keys, 9 money chests, 6 silver, 3 gold, 1 ruby (the 49 Robux starter pack: 2 h of keys, 3 gold, luck) 임시값
	Missions = {
		{ Kinds = { "Mine" }, Target = 300, Name = "⛏️ 광물 %d개 캐기", Reward = { KeyHours = 0.25, MoneyChests = 2 } },
		{ Kinds = { "KeysHome" }, Target = 15, Name = "🎁 선물상자 %d개 집에 가져가기", Reward = { KeyHours = 0.25 } },
		{ Kinds = { "Draws" }, Target = 20, Name = "🎰 뽑기 %d번", Reward = { SpecialKeys = { Silver = 2 } } },
		{ Kinds = { "Chests" }, Target = 10, Name = "💰 보물상자 %d개 열기", Reward = { MoneyChests = 4 } },
		{ Kinds = { "Promotion" }, Target = 3, Name = "👑 보스 웨이브 %d번 깨기", Reward = { SpecialKeys = { Gold = 1 } } },
		{ Kinds = { "Boss" }, Target = 3, Name = "👑 밤의 보스 %d번 쓰러뜨리기", Reward = { SpecialKeys = { Gold = 1 } } },
		{ Kinds = { "TrainMinutes" }, Target = 15, Name = "💪 훈련장에서 %d분 훈련", Reward = { KeyHours = 0.25 } },
		{ Kinds = { "WildRide" }, Target = 3, Name = "🦕 야생 공룡 %d번 올라타기", Reward = { MoneyChests = 3 } },
		{ Kinds = { "Enhance" }, Target = 3, Name = "✨ 공룡 강화 %d번", Reward = { SpecialKeys = { Silver = 2 } } },
		-- (a practice race counts too: no one else may be on to race or play with)
		{ Kinds = { "RaceDone", "RacePractice", "HideSeekGame" }, Target = 2, Name = "🏁 레이스·🙈 숨바꼭질 %d판",
			Reward = { SpecialKeys = { Silver = 2 } } },
	},
	AllReward = { Skin = "Event:Launch", SpecialKeys = { Gold = 1, Ruby = 1 } },
	-- (2026-10-04) the event's pop-up on every join (StarterPlayerScripts/EventAd), AdSeconds after the player is free (the
	-- tutorial done or skipped, nothing asked of them), while it runs and its all-done reward is not taken yet
	AdSeconds = 4,
}
