--[[
ConfigMaps: Config.Defense's fossil kinds, maps and fossil groups (2026-10-06), apart because Config.lua must stay under Roblox's
200,000 characters a script. Config.lua puts each key into Config.Defense and freezes it with the rest. Read it as
Config.Defense.Kinds, Config.Defense.Maps, Config.Defense.Groups, ... never this module directly.
]]
return {
	SpeciesReach = { -- 임시값
		TRex = 1, Raptor = 0.7, Spino = 1.15, Allo = 1, Utahraptor = 0.85, Baryonyx = 1.1,
		Carno = 0.9, Cerato = 1, Giganoto = 1.1, Dilopho = 1.25, WelcomeRex = 1, Trike = 1,
		Iguanodon = 1, Brachio = 1.6, Therizino = 1.2, Edmonto = 1, Maia = 0.9, Parasaur = 1.1,
		Styraco = 0.9, Diplo = 1.35, Argentino = 1.6, Ankylo = 1.1, Pachy = 0.7, Stego = 1,
		Kentro = 1.1, Nodo = 0.9, Huayango = 1, Gastonia = 0.95, Stegoceras = 0.8, Euoplo = 1.15,
		Saichania = 1, Pteranodon = 1, Rhampho = 0.85, Quetzal = 1.35, Microraptor = 0.65, Dimorpho = 0.9,
		Pterodac = 1, Ornitho = 1.1, Tupux = 1.15, Anurog = 0.85, Hatzego = 1.3, Mosa = 1,
		Plesio = 1.2, Krono = 0.9, Shoni = 1.1, Ichthyo = 0.85, Notho = 0.9, Tylo = 1,
		Elasmo = 1.35, Archelon = 0.7, Liopleuro = 1.05, IceRex = 1, RoboRaptor = 0.85, MagmaTrike = 1,
		FlameSpino = 1.15, ThunderStego = 1, PoisonDilopho = 1.25, GemStego = 1, ClockBrachio = 1.6, CosmoMosa = 1.1,
		CyberAnkylo = 1.1, ZombieRex = 1, ZombieTrike = 1, ZombiePtera = 1,
		AuroraParasaur = 1.1, StormQuetzal = 1.35, SolarAllo = 1, PhoenixRex = 1, StarTrike = 1, GoldPtera = 1,
		Yutyrannus = 1, Tapejara = 1.05, Amarga = 1.4, Temno = 0.9, Scolo = 1.1, Cryolo = 1, Nycto = 1.2, Kosmo = 1,
		Tany = 1.45, Dracorex = 0.8, Concave = 1, Deino = 1.2, CrystalAnkylo = 1.1, AbyssKrono = 0.9, AuroraBrachio = 1.6,
		ThunderRaptor = 0.7, SunQuetzal = 1.35, VenomStego = 1, DivineRex = 1,
	},
	ReachDamageExponent = 0.8, -- 임시값
	-- (2026-10-07, "사거리가 아주 넓지만 한마리밖에 때리지 못하지만 데미지는 좋은 것") snipers: hit only one fossil, from
	-- far, hard (Damage a shot, every Interval, Range studs before size; no reach penalty). 임시값
	Snipers = { Dilopho = true, PoisonDilopho = true, Quetzal = true, StormQuetzal = true, Elasmo = true, Diplo = true,
		Tany = true, SunQuetzal = true },
	Sniper = { Damage = 40, Interval = 1.6, Range = 34, StrengthReach = 1.3 },
	-- (2026-10-02, "디펜스 전략의 재미가 이 게임에 잘 녹아있나" → 화석 종류) special fossils mixed into the promotion
	-- fights and the ♾️ challenge (not the idle hunting): a new fossil is one of these by ChancePercent (the rest
	-- plain), from FromLevel (a promotion fight's level) or FromWave (the challenge's wave); with a weekly rule's
	-- KindChance the chance is × that and it comes from a third of FromWave. Health and Speed × a plain fossil's
	-- (the kill pays × Health); Scale and Rgb are only the look. 💨 Fast runs through short reach (long reach
	-- and slows answer it); 🛡️ Armored carries one of Resists (random, shown over it): that attribute's dinos do
	-- half to it, like the boss (a mixed team answers it); 🐜 Swarm comes Count at once side by side (area attacks
	-- answer it). DefenseLogic.spawn; the window lines in Placement. 임시값
	Kinds = {
		{ Id = "Fast", Tip = "멀리 닿는 🦅하늘·🌊바다 공룡이나 ❄️얼음으로", Name = "빠른 화석", Icon = "💨", ChancePercent = 15, FromLevel = 5, FromWave = 4, Health = 0.6,
			Speed = 1.7, Scale = 0.8, Rgb = { 255, 225, 80 }, LeakLives = 1 },
		{ Id = "Armored", Tip = "🧪 속성을 여러 개 섞어 두세요", Name = "단단한 화석", Icon = "🛡️", ChancePercent = 10, FromLevel = 15, FromWave = 8, Health = 2.2,
			Speed = 0.75, Scale = 1.3, Rgb = { 120, 130, 150 }, Resists = { "Fire", "Ice", "Electric", "Water", "Earth", "Poison" }, LeakLives = 4 },
		{ Id = "Swarm", Tip = "한꺼번에 때리는 🔥❄️☠️ 공룡으로", Name = "떼 화석", Icon = "🐜", ChancePercent = 6, FromLevel = 25, FromWave = 12, Health = 0.3,
			Speed = 1.15, Count = 4, Scale = 0.6, Rgb = { 140, 220, 110 }, LeakLives = 1 },
		-- (2026-10-06, "몽키td디펜스참고" → 다 해) like the bloons: 🥚 Shell breaks into Split.Count plain fossils (Split.Kind: that
		-- kind instead), 🗿 Giant into shells; 🧱 Stone takes nothing from ImmuneAttack attacks, ❄️ Frost / 🔥 Lava nothing from
		-- their ImmuneAttribute (no damage, no effect; those dinos look past them); LeakLives: lives a leak costs, × its health
		-- left (rounded up). 🎈 Airship: never rolled, comes by Config.Defense.Airships; it breaks into its Split too. 임시값
	-- (2026-10-06, "모델링이 필요한거 아니었어??") Look: what it wears (a model over the fossil, DefenseView), Balloon: the
	-- airship's balloon (tools/make_td.py)
		{ Id = "Shell", Tip = "깨지면 작은 화석이 나와요! 길 뒤쪽에도 공룡을", Name = "껍질 화석", Icon = "🥚", ChancePercent = 7, FromLevel = 10,
			FromWave = 6, Health = 1.6, Speed = 0.9, Scale = 1.15, Rgb = { 235, 225, 200 }, Split = { Count = 3 }, LeakLives = 8, Look = "Kind_Shell" },
		{ Id = "Giant", Tip = "깨지면 껍질 화석 3마리! 센 공룡을 모아서", Name = "거대 화석", Icon = "🗿", ChancePercent = 2, FromLevel = 30,
			FromWave = 15, Health = 6, Speed = 0.6, Scale = 1.8, Rgb = { 170, 150, 120 }, Split = { Count = 3, Kind = "Shell" },
			LeakLives = 24 },
		{ Id = "Stone", Tip = "🦖 물기(육식)가 안 통해요! 밟기·관통·물 공룡으로", Name = "돌 화석", Icon = "🧱", ChancePercent = 5,
			FromLevel = 20, FromWave = 10, Health = 1.2, Speed = 0.9, Scale = 1.05, Rgb = { 110, 110, 115 }, ImmuneAttack = "SingleTarget",
			Look = "Kind_Stone", LeakLives = 3 },
		{ Id = "Frost", Tip = "❄️ 얼음이 안 통해요! 다른 속성으로", Name = "서리 화석", Icon = "🧊", ChancePercent = 3, FromLevel = 18,
			FromWave = 9, Health = 1.2, Speed = 1, Scale = 1, Rgb = { 170, 220, 255 }, ImmuneAttribute = "Ice", Look = "Kind_Frost", LeakLives = 3 },
		{ Id = "Lava", Tip = "🔥 불이 안 통해요! 다른 속성으로", Name = "용암 화석", Icon = "🌋", ChancePercent = 3, FromLevel = 22,
			FromWave = 11, Health = 1.2, Speed = 1, Scale = 1, Rgb = { 255, 120, 60 }, ImmuneAttribute = "Fire", Look = "Kind_Lava", LeakLives = 3 },
		{ Id = "Ghost", Tip = "🌊 바다 공룡만 찾아내요! 연못에 바다 공룡을", Name = "유령 화석", Icon = "👻", ChancePercent = 6,
			FromLevel = 15, FromWave = 8, Health = 1, Speed = 1.1, Scale = 1, Rgb = { 200, 225, 255 }, Hidden = true, Ghost = 0.6, LeakLives = 3 },
		{ Id = "Airship", Tip = "깨지면 화석이 우르르! 💪 센 공룡으로 · 🎯 💪 센 놈", Name = "화석 비행선", Icon = "🎈", ChancePercent = 0,
			FromLevel = 10, FromWave = 5, Health = 30, Speed = 0.45, Scale = 1.6, Rgb = { 200, 120, 230 },
			Split = { Count = 6, Kind = "Shell" }, LeakLives = 20, Balloon = "Fossil_Airship" },
		{ Id = "Doll3", Tip = "깨지면 작은 인형 2개! 작아질수록 빨라요", Name = "큰 마트료시카 화석", Icon = "🎎", ChancePercent = 1.5,
			FromLevel = 45, FromWave = 14, Health = 2, Speed = 0.6, Scale = 1.6, Rgb = { 170, 70, 220 },
			Split = { Count = 2, Kind = "Doll2" }, LeakLives = 12, Look = "Kind_Doll", LookTint = true },
		{ Id = "Doll2", Tip = "깨지면 더 작은 인형 2개!", Name = "중간 마트료시카 화석", Icon = "🎎", ChancePercent = 0,
			FromLevel = 45, FromWave = 14, Health = 1.3, Speed = 0.85, Scale = 1.25, Rgb = { 235, 70, 70 },
			Split = { Count = 2, Kind = "Doll1" }, LeakLives = 6, Look = "Kind_Doll", LookTint = true },
		{ Id = "Doll1", Tip = "깨지면 화석 2마리!", Name = "작은 마트료시카 화석", Icon = "🎎", ChancePercent = 0,
			FromLevel = 45, FromWave = 14, Health = 0.8, Speed = 1.1, Scale = 0.95, Rgb = { 255, 190, 40 },
			Split = { Count = 2 }, LeakLives = 4, Look = "Kind_Doll", LookTint = true },
		{ Id = "Sprinter", Tip = "보스 웨이브에서 맨 앞을 달려요! 🎯 '🏁 맨 앞' 공격·❄️ 얼음으로", Name = "질주 화석", Icon = "🏃",
			ChancePercent = 0, FromLevel = 9999, FromWave = 9999, Health = 0.45, Speed = 2.1, Scale = 0.75, Rgb = { 255, 120, 70 },
			Look = "Kind_Sprinter", LeakLives = 1 },
	},
	-- 🎈 the fossil airship in a promotion fight: at each Times (seconds in) whose row's Level the fight has reached; in the
	-- challenge every ChallengeEvery waves from ChallengeFromWave (Kinds Airship). 임시값
	Airships = {
		Times = { { Level = 10, At = 25 }, { Level = 40, At = 12 } },
		ChallengeFromWave = 5,
		ChallengeEvery = 5,
	},
	-- (2026-10-06) 🎯 whom a dino hits first (the placing window's button on a placed dino; profile Targeting): Auto = its
	-- kind's own way (bites the toughest, the others the nearest, sea where most bunch up)
	Targets = {
		{ Id = "Auto", Icon = "🤖", Name = "알아서" },
		{ Id = "First", Icon = "🏁", Name = "맨 앞" },
		{ Id = "Strong", Icon = "💪", Name = "센 놈" },
		{ Id = "Close", Icon = "📍", Name = "가까운" },
		{ Id = "Last", Icon = "👣", Name = "맨 뒤" },
	},
	-- (2026-10-06, "기지 내에 비는공간 … 환생하면 다른 맵이 생기고, 배치도 바꿔볼 수 있는 전략성", "길 처음 게이트에서 화석 나오고
	-- 끝 게이트에서 사라지고 … TD디펜스 참고") the defense maps: a road from a start gate to an end gate in the arena's flat
	-- frame (-Z toward the old portal, the base's front): corners joined by straight roads, each corner rounded by Corner.
	-- Rebirths: the rebirths that open it. HealthScale: × the fossils' health there (tools/progress_sim), BossHealth: × the
	-- boss's. Tip: the window's line. (2026-10-06, "맵은 울타리까지 넓혀도 되고 비는 공간에", "첫맵은 알아서": every map
	-- spread to the fences; the first map a winding road in place of the old ring round the platform) 임시값
	Maps = {
		{ Id = "Meadow", Name = "꼬불 들판", Icon = "🌿", Rebirths = 0, HealthScale = 1, Corner = 12,
			Points = { { 24, 41 }, { -30, 41 }, { -30, 4 }, { 30, 4 }, { 30, -33 }, { -45.5, -33 } },
			Tip = "🌿 굽은 길 안쪽에 놓으면 화석을 오래 때려요", Ponds = { { 10, -14 }, { -10, 22 } }, Perches = { { 18, -20 }, { -2, 28 } },
			Nests = {  }, Rocks = {} },
		{ Id = "Cross", Name = "십자 교차로", Icon = "✖️", Rebirths = 1, HealthScale = 2.05, BossHealth = 1.16, RoadWeight = 0, Corner = 8,
			Points = { { -45.5, 2 }, { 39, 2 }, { 39, 42.5 }, { 0, 42.5 }, { 0, -38 }, { -45.5, -38 } },
			Tip = "✖️ 길이 엇갈리는 곳 옆은 길 네 줄에 닿아요", Ponds = { { 20, 24 }, { -14, -16 } }, Perches = { { 12, 18 }, { -23, -21 } },
			Nests = { { -14, 17 } }, Rocks = {
				{ -22.8, -8.3 }, { -16.4, -8.3 }, { -10, -8.3 }, { 13.2, 12.3 }, { 19.6, 12.3 },
				{ 26, 12.3 }, { 13.6, -8.3 }, { 20, -8.3 }, { 26.4, -8.3 }, { 33.7, -8.1 } } },
		{ Id = "Snake", Name = "뱀길", Icon = "🐍", Rebirths = 2, HealthScale = 0.74, BossHealth = 0.55, RoadWeight = 2, Corner = 10,
			Points = { { -45.5, -33.5 }, { 41.5, -33.5 }, { 41.5, -11 }, { -41.5, -11 }, { -41.5, 11 }, { 41.5, 11 }, { 41.5, 33.5 },
				{ -45.5, 33.5 } },
			Tip = "🐍 길 사이 좁은 땅에 놓으면 두 줄을 한 번에 때려요", Ponds = { { 18, 22 }, { -18, 0 } }, Perches = { { 39, 0 }, { -45, 19 } },
			Nests = {  }, Rocks = {
				{ -6.8, -23.2 }, { -0.4, -23.2 }, { 6, -23.2 }, { 12.4, -23.2 }, { 18.8, -23.2 },
				{ -26.8, -23.2 }, { -20.4, -23.2 }, { -14, -23.2 }, { -36.8, -43.8 }, { -30.4, -43.8 },
				{ -24, -43.8 }, { -17.6, -43.8 }, { -11.2, -43.8 }, { 3.2, -43.8 }, { 9.6, -43.8 },
				{ 16, -43.8 }, { 22.4, -43.8 }, { 28.8, -43.8 } } },
		{ Id = "Spiral", Name = "소용돌이", Icon = "🌀", Rebirths = 3, HealthScale = 1.37, BossHealth = 0.94, Corner = 8,
			Points = { { -45.5, -38 }, { 41.5, -38 }, { 41.5, 45 }, { -41.5, 45 }, { -41.5, -15.5 }, { 19.5, -15.5 }, { 19.5, 22.5 },
				{ -15, 22.5 } },
			Tip = "🌀 가운데에 놓으면 여러 바퀴에 닿아요", Ponds = { { 0, 4 }, { 24, 30 } }, Perches = { { -27, 31 }, { -27, -3 } },
			Nests = { { 28, -23 }, { -16, 1 } }, Rocks = {
				{ -16.8, -27.7 }, { -10.4, -27.7 }, { -4, -27.7 }, { 2.4, -27.7 }, { 8.8, -27.7 },
				{ -34, -27.7 }, { -27.6, -27.7 }, { -21.2, -27.7 }, { -4.8, -5.2 }, { 1.6, -5.2 },
				{ 8, -5.2 }, { 10.8, 32.8 }, { 4.4, 32.8 }, { -2, 32.8 } } },
		{ Id = "Valley", Name = "U자 골짜기", Icon = "🏞️", Rebirths = 0, Level = 5, HealthScale = 0.99, BossHealth = 0.99, Corner = 14,
			Points = { { 36, 45 }, { 36, -30 }, { -36, -30 }, { -36, 45 } },
			Tip = "🏞️ 골짜기 바닥 가운데는 세 줄에 닿아요", Ponds = { { 16, -10 }, { -16, -10 } }, Perches = { { 10, -18 }, { -24, -4 } },
			Nests = { { 22, 5 } }, Rocks = {
				{ 25.7, -4.6 }, { 25.7, -11 }, { 25.6, -16.5 }, { 46.3, 17.8 }, { 46.3, 11.4 },
				{ 46.3, 5 }, { 46.3, -1.4 }, { 46.3, -7.8 } } },
		{ Id = "Lightning", Name = "번개길", Icon = "⚡", Rebirths = 0, Level = 10, HealthScale = 1.21, BossHealth = 1.26, Corner = 8,
			Points = { { 38, 44 }, { -34, 24 }, { 34, 4 }, { -34, -16 }, { 38, -36 } },
			Tip = "⚡ 뾰족한 꺾임 안쪽에 놓으면 두 줄을 때려요", Ponds = { { -16, 2 }, { 14, -14 } }, Perches = { { -24, 8 }, { 24, -13 } },
			Nests = { { 16, 23 } }, Rocks = {
				{ 1.7, 44.6 }, { -4.4, 42.9 }, { -10.6, 41.2 }, { -16.8, 39.5 }, { -22.9, 37.8 },
				{ 17.5, 49 }, { 11.4, 47.3 }, { 5.2, 45.6 } } },
		{ Id = "Castle", Name = "성벽 둘레", Icon = "🏰", Rebirths = 0, Level = 15, HealthScale = 0.95, BossHealth = 1, Corner = 10,
			Points = { { 41.5, -38 }, { 41.5, 45 }, { -41.5, 45 }, { -41.5, -38 }, { -10, -38 }, { -10, 10 } },
			Tip = "🏰 성 안쪽 끝 문 옆이 마지막 방어선이에요", Ponds = { { -26, -16 }, { -22, 26 } }, Perches = { { -29, -26 }, { 24, 28 } },
			Nests = { { 28, 17 } }, Rocks = {
				{ 31.2, -21.8 }, { 31.2, -15.4 }, { 31.2, -9 }, { 31.2, -2.6 }, { 31.2, 3.8 },
				{ 31.2, 24.6 }, { 31.2, 31 } } },
		{ Id = "Stairs", Name = "계단길", Icon = "📶", Rebirths = 0, Level = 20, HealthScale = 0.93, BossHealth = 0.99, RoadWeight = -0.5, Corner = 6,
			Points = { { -41.5, 45 }, { 40, 45 }, { 40, 20 }, { 10, 20 }, { 10, -6 }, { -20, -6 }, { -20, -32 }, { -45.5, -32 } },
			Tip = "📶 꺾이는 모서리 안쪽에 센 공룡을 모아요", Ponds = { { 18, 32 }, { -2, -24 } }, Perches = { { -3, 19 }, { -32, -10 } },
			Nests = { { 4, 31 } }, Rocks = {
				{ -30.4, 34.7 }, { -24, 34.7 }, { -17.6, 34.7 }, { -11.2, 34.7 }, { -2, 4.3 },
				{ -8.4, 4.3 }, { -15.7, 4.2 } } },
		{ Id = "LongRoad", Name = "큰 C자 길", Icon = "🛤️", Rebirths = 0, Level = 25, HealthScale = 0.98, BossHealth = 0.98, Corner = 16,
			Points = { { -45.5, 44 }, { 38, 44 }, { 38, -36 }, { -45.5, -36 } },
			Tip = "🛤️ 가운데 넓은 땅: 멀리 닿는 공룡이 좋아요", Ponds = { { 18, -16 }, { 18, 24 } }, Perches = { { 26, 18 }, { 12, -24 } },
			Nests = { { -8, 29 } }, Rocks = {
				{ 1.2, 33.7 }, { 7.6, 33.7 }, { 14, 33.7 }, { 20.4, 33.7 }, { 25.8, 33.3 },
				{ -32.4, 33.7 }, { -26, 33.7 }, { -19.6, 33.7 } } },
		{ Id = "Comb", Name = "빗살길", Icon = "🎹", Rebirths = 1, Level = 20, HealthScale = 1.01, BossHealth = 0.85, RoadWeight = 2, Corner = 8,
			Points = { { 38, -38 }, { 38, 44 }, { 14, 44 }, { 14, -30 }, { -10, -30 }, { -10, 44 }, { -34, 44 }, { -34, -38 } },
			Tip = "🎹 빗살 사이 땅은 길 두 줄 사이예요", Ponds = { { 2, -8 }, { -22, 22 } }, Perches = { { -22, 9 }, { 2, -18 } },
			Nests = { { 2, 43 } }, Rocks = {
				{ 27.7, -5.8 }, { 27.7, 0.6 }, { 27.7, 7 }, { 27.7, 13.4 }, { 27.7, 19.8 },
				{ 27.7, -29.4 }, { 27.7, -23 }, { 27.7, -16.6 }, { 27.7, -10.2 }, { 48.3, 4.2 },
				{ 48.3, 10.6 }, { 48.3, 17 }, { 48.3, 23.4 }, { 48.3, 29.8 } } },
		{ Id = "Diamond", Name = "다이아몬드", Icon = "💎", Rebirths = 1, Level = 50, HealthScale = 0.93, BossHealth = 0.94, RoadWeight = 0.5, Corner = 10,
			Points = { { -45.5, 4 }, { 0, 44 }, { 40, 4 }, { 0, -36 }, { -38, -36 } },
			Tip = "💎 다이아 한가운데는 네 변에 다 닿아요", Ponds = { { 14, 4 }, { -10, -16 } }, Perches = { { 13, 14 }, { 0, -18 } },
			Nests = { { -2, 21 } }, Rocks = {
				{ -33.3, 28.5 }, { -28.5, 32.7 }, { -23.7, 36.9 }, { -18.9, 41.1 }, { -13.3, 45.9 },
				{ -27.3, 6.2 }, { -22.5, 10.5 }, { -17.7, 14.7 }, { -12.9, 18.9 }, { 13.6, 44.9 },
				{ 18.8, 39.8 }, { 23.3, 35.3 }, { 27.8, 30.7 } } },
		{ Id = "Maze", Name = "미로", Icon = "🧩", Rebirths = 1, Level = 80, HealthScale = 1.12, BossHealth = 0.9, RoadWeight = 0.5, Corner = 7,
			Points = { { 41.5, 45 }, { 41.5, 25 }, { -20, 25 }, { -20, 5 }, { 30, 5 }, { 30, -15 }, { -30, -15 }, { -30, -36 },
				{ 41.5, -36 } },
			Tip = "🧩 꺾이는 곳이 많아요: 모서리마다 하나씩", Ponds = { { -22, -4 }, { 32, 14 } }, Perches = { { 40, 8 }, { -30, 2 } },
			Nests = { { 22, 39 } }, Rocks = {
				{ 2.8, 35.3 }, { -3.6, 35.3 }, { -10, 35.3 }, { -19.6, 34.2 }, { -30.1, 20.5 },
				{ 17.2, -25.7 }, { 23.6, -25.7 }, { 30, -25.7 }, { -2.8, -25.7 }, { 3.6, -25.7 },
				{ 10, -25.7 } } },
		{ Id = "Hook", Name = "물음표길", Icon = "❓", Rebirths = 2, Level = 30, HealthScale = 1.19, BossHealth = 0.96, RoadWeight = 0, Corner = 10,
			Points = { { 41.5, -36 }, { -20, -36 }, { -20, 4 }, { 20, 4 }, { 20, 44 }, { -36, 44 }, { -36, -10 } },
			Tip = "❓ 고리 안쪽 땅은 길 세 줄에 닿아요", Ponds = { { -2, -16 }, { 0, 24 } }, Perches = { { -17, 21 }, { 8, 30 } },
			Nests = { { 12, -21 }, { -36, -37 } }, Rocks = {
				{ 0.4, -25.7 }, { -6, -25.7 }, { 28, -25.7 }, { 21.6, -25.7 }, { -25.7, 33 },
				{ -25.7, 26.6 }, { -25.7, 20.2 }, { -17.6, -45.1 }, { -30.3, -25 } } },
		{ Id = "Wave", Name = "파도길", Icon = "🌊", Rebirths = 2, Level = 70, HealthScale = 1.45, BossHealth = 1.05, Corner = 6,
			Points = { { 38, -38 }, { 20, 44 }, { 0, -30 }, { -20, 44 }, { -38, -38 } },
			Tip = "🌊 파도 꼭대기 사이에 놓으면 두 줄에 닿아요", Ponds = { { 0, 28 }, { -18, -12 } }, Perches = { { 0, 18 }, { -17, -22 } },
			Nests = { { 18, -17 }, { 40, 15 } }, Rocks = {
				{ 20.3, -5.5 }, { 18.9, 0.8 }, { 45.2, -23 }, { 43.9, -16.7 }, { 42.5, -10.5 },
				{ 41.1, -4.2 }, { 39.8, 2.1 }, { 35.1, 23 }, { 33.8, 29.3 }, { 32.4, 35.5 },
				{ 30.9, 42.2 }, { 8.2, 39.8 }, { -42.9, -12.1 }, { -44.2, -18.4 }, { -45.6, -24.6 } } },
		{ Id = "Star", Name = "별길", Icon = "⭐", Rebirths = 3, Level = 50, HealthScale = 2, BossHealth = 1.1, Corner = 4,
			Points = { { 0, 45 }, { -30, -36 }, { 38, 18 }, { -38, 18 }, { 30, -36 } },
			Tip = "⭐ 별 가운데 오각형은 다섯 줄이 지나가요", Ponds = { { -2, 6 }, { -32, -10 } }, Perches = { { 26, -7 }, { -4, -34 } },
			Nests = { { -20, 33 }, { -40, 1 } }, Rocks = {
				{ -34.4, -18.1 }, { -36.6, -24.1 }, { -39.2, -32.5 }, { 20.8, 28.3 }, { 14.4, 28.3 },
				{ 8, 28.3 }, { -38, -28.1 }, { -19.5, -40.8 }, { -14.5, -36.9 }, { -9.5, -32.9 },
				{ -4.5, -28.9 }, { 19.1, -14.2 }, { 24.1, -18.1 }, { 29.1, -22.1 } } },
		{ Id = "Corner", Name = "직각길", Icon = "📐", Rebirths = 1, Level = 10, HealthScale = 0.83, BossHealth = 0.62, RoadWeight = 0, Corner = 8,
			Points = { { -45.5, -36 }, { 34, -36 }, { 34, 45 } },
			Tip = "📐 짧은 길: 꺾이는 모서리에 다 모아요", Ponds = { { -10, 10 }, { 10, -20 } }, Perches = { { 20, -16 }, { 22, 21 } },
			Nests = { { -20, -21 } }, Rocks = {
				{ 15.6, -25.7 }, { 22, -25.7 }, { -10.8, -25.7 }, { -4.4, -25.7 }, { 2, -25.7 },
				{ -34, -25.7 }, { -27.6, -25.7 } } },
		{ Id = "Ladder", Name = "사다리길", Icon = "🚧", Rebirths = 1, Level = 35, HealthScale = 0.84, BossHealth = 0.8, Corner = 8,
			Points = { { -45.5, -32 }, { -22, -32 }, { -22, 42 }, { 6, 42 }, { 6, -32 }, { 34, -32 }, { 34, 45 } },
			Tip = "🚧 세로 길 사이 땅은 양쪽 길에 닿아요", Ponds = { { -8, -14 }, { 20, 26 } }, Perches = { { 19, -7 }, { -7, 17 } },
			Nests = { { -36, -13 } }, Rocks = {
				{ -32.3, -3.4 }, { -32.3, 3 }, { -32.3, 9.4 }, { -32.3, 15.8 }, { -11.7, 0.2 },
				{ -11.7, 6.6 }, { -11.7, 13 }, { -11.7, 19.4 }, { -11.7, 25.8 }, { -34.4, -42.3 },
				{ -27.1, -42.1 }, { -13.1, -31.7 }, { -11.7, -22.2 } } },
		{ Id = "Moon", Name = "초승달길", Icon = "🌙", Rebirths = 1, Level = 65, HealthScale = 0.85, BossHealth = 0.58, Corner = 14,
			Points = { { -45.5, 40 }, { -6, 45 }, { 26, 32 }, { 38, 6 }, { 26, -22 }, { -6, -36 }, { -45.5, -34 } },
			Tip = "🌙 달 안쪽 가운데: 멀리 닿는 공룡이 좋아요", Ponds = { { -10, 4 }, { -30, 20 } }, Perches = { { 21, -2 }, { -15, -23 } },
			Nests = { { -4, 27 } }, Rocks = {
				{ -34.4, 31 }, { -28, 31.8 }, { -21.7, 32.6 }, { -15.8, 33.3 }, { -11.1, 33.3 },
				{ 11.3, 26.7 }, { 14.5, 24.8 }, { 18.3, 21.4 }, { 20.6, 18.4 }, { 23, 13.9 },
				{ 15.2, 47.5 }, { 22.7, 44 }, { 29, 39.6 }, { 34.5, 34.1 } } },
		{ Id = "Crown", Name = "왕관길", Icon = "👑", Rebirths = 2, Level = 15, HealthScale = 1.42, BossHealth = 0.95, Corner = 6,
			Points = { { -45.5, -30 }, { -34, 40 }, { -17, 8 }, { 0, 40 }, { 17, 8 }, { 34, 40 }, { 45.5, -30 } },
			Tip = "👑 왕관 뾰족한 곳 아래는 두 줄에 닿아요", Ponds = { { 0, -16 }, { 28, -12 } }, Perches = { { 16, 38 }, { 28, -2 } },
			Nests = { { -26, -1 }, { -18, 39 } }, Rocks = {
				{ -48.3, 16.7 }, { -47.2, 23 }, { -46.2, 29.4 }, { -45.1, 35.7 }, { -33.7, -21.5 },
				{ -32.6, -15.2 }, { -31.6, -8.9 }, { -13.7, 0.9 }, { -3.9, 10.7 }, { -0.9, 16.4 },
				{ 18.5, 32.7 }, { 21.5, 38.4 }, { 43.8, 40.3 } } },
		{ Id = "Heart", Name = "하트길", Icon = "❤️", Rebirths = 2, Level = 50, HealthScale = 0.57, BossHealth = 0.66, Corner = 10,
			Points = { { 0, -38 }, { 40, 8 }, { 32, 40 }, { 0, 26 }, { -32, 40 }, { -40, 8 }, { -14, -24 } },
			Tip = "❤️ 하트 한가운데는 길 여러 줄에 닿아요", Ponds = { { 0, 4 }, { -22, 18 } }, Perches = { { 13, 17 }, { -21, 8 } },
			Nests = { { 24, 13 }, { 4, -11 } }, Rocks = {
				{ 45.5, 0.2 }, { 48.3, 9.6 }, { 47.8, 19.3 }, { 46.1, 26.2 }, { 44.5, 32.4 },
				{ 14, -6.2 }, { 18.2, -1.4 }, { 22.4, 3.4 }, { 22.6, -27.8 }, { 26.8, -22.9 },
				{ 31, -18.1 }, { 35.2, -13.3 }, { 39.4, -8.4 }, { -38.1, -10.7 }, { -34, -15.7 },
				{ -30, -20.6 } } },
		{ Id = "Figure8", Name = "8자 교차로", Icon = "♾️", Rebirths = 2, Level = 90, HealthScale = 1.61, BossHealth = 0.77, Corner = 8,
			Points = { { -45.5, -38 }, { 38, 44 }, { -38, 44 }, { 45.5, -38 } },
			Tip = "♾️ 길이 엇갈리는 한가운데가 명당이에요", Ponds = { { 0, -24 }, { -30, 10 } }, Perches = { { 3, 29 }, { 2, -14 } },
			Nests = { { -32, -5 }, { -14, -27 } }, Rocks = {
				{ -9.2, -16.8 }, { -4.7, -12.3 }, { -0.1, -7.9 }, { -22.8, -1.3 }, { -18.2, 3.2 },
				{ 15, 6.9 }, { 19.5, 11.4 }, { 24.1, 15.9 }, { 28.7, 20.4 }, { -10, 31 },
				{ -5.5, 26.5 }, { -0.9, 22 } } },
		{ Id = "Seashell", Name = "소라길", Icon = "🐚", Rebirths = 3, Level = 30, HealthScale = 1.22, BossHealth = 1.08, Corner = 6,
			Points = { { 6, 6 }, { 6, -14 }, { -22, -14 }, { -22, 24 }, { 26, 24 }, { 26, -34 }, { -42, -34 }, { -42, 45 } },
			Tip = "🐚 가운데에서 나와 바깥으로 돌아요", Ponds = { { 44, 0 }, { -10, 5 } }, Perches = { { 12, -22 }, { -30, 30 } },
			Nests = { { -14, 39 }, { 40, -21 } }, Rocks = {
				{ -31.7, -23.4 }, { -31.7, -17 }, { -11.2, -44.3 }, { -17.6, -44.3 }, { -24, -44.3 },
				{ -30.4, -44.3 }, { -37.7, -44.2 }, { 8.8, -44.3 }, { 2.4, -44.3 }, { -4, -44.3 },
				{ -4.8, 34.3 }, { 1.6, 34.3 }, { 8, 34.3 }, { 14.4, 34.3 }, { 21.7, 34.2 } } },
		{ Id = "Camel", Name = "낙타 고개", Icon = "🐫", Rebirths = 3, Level = 70, HealthScale = 1.35, BossHealth = 0.96, Corner = 8,
			Points = { { -45.5, -36 }, { -30, 40 }, { -8, -14 }, { 8, -14 }, { 30, 40 }, { 45.5, -36 } },
			Tip = "🐫 두 고개 사이 골짜기가 지키기 좋아요", Ponds = { { 0, 20 }, { 0, -30 } }, Perches = { { -3, 10 }, { 47, 17 } },
			Nests = { { -26, -9 }, { -12, 31 } }, Rocks = {
				{ -47.3, 6.6 }, { -46, 12.9 }, { -44.8, 19.2 }, { -43.5, 25.4 }, { -42.2, 31.7 },
				{ -33.2, -27.2 }, { -31.9, -20.9 }, { 27.1, 2.8 }, { 28.4, -3.5 }, { 29.6, -9.7 },
				{ 10.8, 20.1 }, { 13.2, 26 }, { 15.6, 32 }, { 18.3, 38.4 }, { 41.2, 36.1 } } },
		{ Id = "Lollipop", Name = "막대사탕길", Icon = "🍭", Rebirths = 4, Level = 20, HealthScale = 1.02, BossHealth = 0.88, RoadWeight = 2, Corner = 10,
			Points = { { 45.5, 14 }, { 12, 14 }, { 12, 44 }, { -38, 44 }, { -38, -30 }, { 12, -30 }, { 12, -6 } },
			Tip = "🍭 사탕 안쪽은 둥근 길이 다 지나가요", Ponds = { { -14, 8 }, { 32, -20 } }, Perches = { { -13, -14 }, { -14, 30 } },
			Nests = { { 26, 29 }, { -2, 29 } }, Rocks = {
				{ 32, 3.7 }, { 25.6, 3.7 }, { 6.1, 10.5 }, { 1.9, 21.4 }, { -12.8, -19.7 },
				{ -6.4, -19.7 }, { 0, -19.7 }, { -27.7, -6.2 }, { -27.7, -12.6 }, { -27.7, -19 } } },
		{ Id = "Ribbon", Name = "리본길", Icon = "🎀", Rebirths = 4, Level = 60, HealthScale = 1.89, BossHealth = 1.03, Corner = 8,
			Points = { { -45.5, 40 }, { 40, -36 }, { 40, 40 }, { -40, -36 } },
			Tip = "🎀 리본 매듭(가운데)이 두 길이 만나는 곳", Ponds = { { -8, -30 }, { 22, -2 } }, Perches = { { 24, 8 }, { -30, -8 } },
			Nests = { { -22, 1 }, { -4, 21 } }, Rocks = {
				{ -0.1, -14.2 }, { 4.7, -18.4 }, { 9.5, -22.7 }, { 14.3, -26.9 }, { -42.4, 23.5 },
				{ -37.6, 19.2 }, { -32.8, 14.9 }, { -28, 10.7 }, { -29.4, 39.5 }, { -24.6, 35.2 },
				{ -19.8, 31 }, { -15, 26.7 }, { 29.7, -11 }, { 29.7, -4.6 }, { 29.7, 1.8 } } },
	},
	Pond = { Radius = 5, Snap = 9, Reach = 1.25, WaveEvery = 6, WavePush = 6, WaveBossShare = 0.5 }, -- 임시값
	Perch = { Radius = 3, Snap = 6, ReachBonus = 0.4, PierceBonus = 1, Model = "Map_Perch" }, -- 임시값
	Twists = { -- 임시값
		FromTier = 1,
		FromLevel = 8,
		Every = 5,
		EaseAfterLosses = 2,
		BonusKeyShare = 1,
		Rules = {
			{ Id = "Land", Icon = "🦖", Text = "🦖 땅 공룡만 싸워요 · 🦅🌊 쉬어요", Health = 0.5 },
			{ Id = "Element", Icon = "🚫", Health = 0.72 },
			{ Id = "Sky", Icon = "🦅", Text = "🦅 하늘 공룡만 싸워요", Health = 0.12 },
			{ Id = "Ace", Icon = "⭐", Text = "⭐ 가장 센 공룡 2마리는 쉬어요", Health = 0.6, Count = 2 },
			{ Id = "Sea", Icon = "🌊", Text = "🌊 바다 공룡만 싸워요", Health = 0.15 },
			{ Id = "Unique", Icon = "🧬", Text = "🧬 같은 종은 한 마리만 싸워요 · 겹치면 쉬어요", Health = 0.85 },
		},
	},
	Rocks = { Radius = 1.0, Gap = 3.4, Spacing = 6.4, PerRow = 5, Nest = { Pocket = 4.3, Count = 8, ReachBonus = 0.5, Snap = 5.3 } }, -- 임시값
	MapFirstWin = { { Rebirths = 0, Key = "Silver", Count = 2 }, { Rebirths = 1, Key = "Gold", Count = 1 } }, -- 임시값
	-- where a map's dinos may stand: x within ±X, z from ZFront to ZBack (the arena's field up to its fences: x ±52.5, the back
	-- fence z 54, the yard from z −51), and TrackHalfWidth + the dino's footprint from the road's middle (the melee reach is
	-- measured from there too), GateClear from a gate. LayoutVersion: saved layouts from before it are laid out again
	MapBounds = { X = 50, ZFront = -47, ZBack = 51.5 },
	-- the road's gates (tools/make_td.py; plain parts when the models are missing)
	Gates = { Start = "Gate_FossilStart", End = "Gate_FossilEnd" },
	LayoutVersion = 2,
	TrackHalfWidth = 5.3,
	GateClear = 6,
	-- (2026-10-06, "화석들 중 일부가 그룹으로(개별적이면 안됨) 어떤 속성을 지니고 등장해서 또 전략성을 강화") 🚩 fossil
	-- groups in the promotion fights and the challenge: a flag-bearer and Members behind it, all of one kind. Element: the
	-- whole group carries one attribute (that attribute's dinos do half, no effect); Fast: Speed and Health ×; Shield: while
	-- the bearer stands, the others take Guard of the damage; Heal: the bearer heals the others within HealRadius by
	-- HealPerSecond of their health; Ghost: only dinos within Sight studs see them (blasts, chains and pools still hit).
	-- A fight's groups are fixed by its level (Formulas.fightGroups), so the next fight's can be shown beforehand: Times
	-- (seconds in), how many by the level (Count: the last row reached), Members by the level. The challenge: one every
	-- ChallengeEvery waves from ChallengeFromWave. 임시값
	Groups = {
		Times = { 9, 21, 31 },
		Count = { { Level = 5, Groups = 1 }, { Level = 15, Groups = 2 }, { Level = 28, Groups = 3 } },
		Members = { { Level = 1, Count = 4 }, { Level = 15, Count = 6 }, { Level = 30, Count = 8 }, { Level = 130, Count = 10 } },
		Spacing = 2.2, -- studs between a group's rows (two across)
		LeaderHealth = 3, -- × a member's
		LeaderScale = 1.6, -- (looks)
		FlagModel = "Prop_FossilFlag", -- the bearer's flag on its back (tools/make_td.py)
		ChallengeFromWave = 3,
		ChallengeEvery = 2,
		ChallengeLevelPerWave = 5,
		Elements = { "Fire", "Water", "Electric", "Ice", "Earth", "Poison" },
		Kinds = {
			{ Id = "Element", Weight = 6, FromLevel = 1, Tip = "다른 속성 공룡을 섞어 놓아요" },
			{ Id = "Fast", Name = "빠른 무리", Icon = "💨", Weight = 2, FromLevel = 12, Speed = 1.4, Health = 0.6,
				Tip = "❄️ 얼음으로 늦추고 멀리 닿는 공룡으로" },
			{ Id = "Shield", Name = "방패 무리", Icon = "🛡️", Weight = 2, FromLevel = 18, Guard = 0.4, LeaderHealth = 5,
				Tip = "🚩 깃발 든 화석부터! 쓰러지면 방패가 사라져요" },
			{ Id = "Heal", Name = "치유 무리", Icon = "💚", Weight = 2, FromLevel = 22, HealPerSecond = 0.05, HealRadius = 10,
				Tip = "🚩 깃발 든 화석부터 잡아야 회복이 멈춰요" },
			{ Id = "Ghost", Name = "유령 무리", Icon = "👻", Weight = 2, FromLevel = 26, Sight = 10,
				Tip = "길 바로 옆 공룡만 보여요! 🔥❄️💧 폭발·⚡ 연쇄는 맞아요" },
		},
	},
}
