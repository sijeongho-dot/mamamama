--[[
ConfigTutorial: Config.Tutorial, the tutorial's numbers and lines. It lives apart from Config.lua (2026-10-03,
Studio "Unable to assign property Source. Provided string length (201003) is greater than or equal to max length
(200000)": one script's source holds less than 200,000 characters); Config.lua puts it at Config.Tutorial and
freezes it with the rest. Read it as Config.Tutorial, never this module directly.
]]
-- (2026-10-01) the tutorial runs in the player's own base on the real map (design 10, decided with the
-- owner: not a separate island): Coco walks the player through one thing at a time (Tutorial service,
-- StarterPlayerScripts/Tutorial). The first run is safe (nobody can hit the player: TutorialShield) and
-- fixed (the first draw is rare, the second an ice dino, the first promotion easier); a replay from
-- 보기 설정 only shows the way (no gifts, no shield, no fixed draws). Steps in order:
--   Event = the step ends after Count of these (Rewards kinds; Place = a dino placed, DummyHit = a slap on the dummy)
--   Reach = ends when the player gets within ReachRange of that spot (Center: the key zone)
--   Client = ends when the client says so (the hatching, pressing a button)
--   Button = the top bar / side button the finger points at (its text); Target = what the beam points at
--   GiftKeys = saved keys given when the step starts (first run only); EnsureKeys = at least this many saved keys
--   CarryKeys = keys put in the player's hands on reaching (first run only); Forced = the next draw's first dino
--   FirstRunOnly = left out of a replay
local Tutorial = { -- 임시값
	-- (2026-10-03, "튜토리얼 필드를 새로 만들고 튜토리얼 진행하는 사람은 거기로 보내서 체험할 수 있는거 다해보게 하자 …
	-- 튜토리얼을 모두 끝내면 보상도 주고. 나중에 다 끝내고 재도전은 보상없고 … 튜토리얼 필드에선 게임 시스템 전부를 이해시켜야돼
	-- … 끝나면 본인 기지에서 완전 새로운 시작", chosen: 나만의 튜토리얼 서버) the steps run on a server of the player's own
	-- (TutorialField), on a save apart; Coco brings the weather, the night, zombies and the night boss there. Setup: what a
	-- step makes sure of as it starts (Tutorial service; on the field only): Money ("Shop": the next pickaxe; "Keys": a
	-- key at the key stall), Team (a 💧 water and an ❄️ ice dino placed), Fodder, Food, MergeSet, Spare (a dino for the
	-- farm), Bombs, Weather, Night (true / false), Boss, Chest. So a replay of one part has what it needs.
	-- The cards speak one polite voice (-요) and say what each game word is the first time (2026-10-03, "튜토리얼 문구들이
	-- 초보 눈높이에 맞는지").
	Steps = {
		{ Id = "Hatch", Text = "안녕! 난 코코야!", Client = true },
		{ Id = "Welcome", Text = "끝까지 꼭 같이 하자!", Client = true, FirstRunOnly = true,
			-- (2026-10-04, the onboarding funnel: 6 of 17 left on this card, four pages to read before playing → "그렇게
			-- 해봐") one page: the game in a line and the reward; the rest is on the Finish card and the beginner missions
			Info = { "🐣 코코의 부탁!",
				"이 게임은: ⛏️ 광물 캐서 💰 돈 → 🎰 공룡 뽑기 → 🦖 공룡이 기지를 지켜요",
				"🎁 끝까지 하면 보상: 열쇠 8개 · 🍀 행운 1시간!" } },
		-- (2026-10-03, "튜토 광물 캐는것도 파란것만 캐게 해야지.. 나머지는 시간 걸리는데 왜 보내") only the blue droplet stone
		-- counts (the quickest with the first pickaxe), and the beam goes to the nearest one of those
		-- (2026-10-04, the funnel: 4 of 11 left while mining 10 times) 5 times
		{ Id = "Mine", Text = "파란 광물을 캐 보자!", Event = "MineDroplet", Count = 5, Target = "Mineral",
			Guide = { "⛏️ 광물 캐기",
				"광물 앞에서 '⛏ 캐기!' 버튼을 눌러요 (키보드는 E)",
				"캔 광물은 🎒 가방에 쏙! 5번 캐 봐요" } },
		{ Id = "Deposit", Text = "입금통에 넣자!", Event = "Deposit", Target = "DepositBin",
			Guide = { "💰 광물을 돈으로 바꾸기",
				"빛나는 길을 따라 내 기지의 💰 입금통으로 가요",
				"💰 입금통 가까이 가면 바로 돈이 돼요" } },
		-- (2026-10-04, "튜토에도 반영하고": the five upgrades are trained now) the shop step is the training rock: stand there
		-- until the first power step comes (Config.Training.Tracks.Power.First seconds)
		{ Id = "Shop", Text = "훈련해서 강해지자!", Event = "Upgrade", Target = "TrainRock",
			-- (2026-10-04, "상점 이름도 조절해 … 튜토리얼도 조절하고": the shop is the ⛏️ 곡괭이 상점, the next pickaxe only)
			Guide = { "💪 훈련장",
				"⛏️ 광물 바위 옆에 서 있으면 곡괭이가 저절로 강해져요",
				"충분히 강해지면 ⛏️ 곡괭이 상점에서 새 곡괭이를 사요" } },
		{ Id = "Draw1", Text = "열쇠로 뽑기!", Event = "Draws", Button = "뽑기", Target = "GachaMachine", EnsureKeys = 1,
			Forced = { Rarity = "Rare", Attribute = "Water" },
			Guide = { "🎰 첫 공룡 뽑기",
				"✨ 빛나는 줄을 따라 기지의 🎰 뽑기 자판기로!",
				"👆 오른쪽 위 '🎰 뽑기' 버튼으로도 뽑아요",
				"📦 뽑으면 공룡 상자가 나와요! 농장에 쌓여요",
				"이번엔 💧 물 공룡이 꼭 나와요! (희귀 등급)" } },
		{ Id = "Open1", Text = "상자를 열자!", Event = "BoxOpen", Button = "📦", Buttons = { "📦", "모두 열기" },
			Guide = { "📦 공룡 상자 열기",
				"상자 색 = 공룡 등급 · 상자 크기 = 공룡 크기",
				"⏳ 좋은 공룡일수록 오래 기다려요 (일반은 5초!)",
				"✅ 다 되면 위의 📦 → '📦 모두 열기'를 눌러요" } },
		-- (2026-10-03, "공룡놓기 할 때도 길 알려주고") the beam to the arena too
		-- (2026-10-04, the funnel: 2 of 5 left here, many presses to find) the list opens by itself (Placement) and the
		-- finger goes along Buttons: the newest one on the screen ({ Exact = text }: that exact text, not "🦖 공룡 배치")
		{ Id = "Place1", Text = "공룡을 놓아 보자!", Event = "Place", Button = "공룡 배치", Target = "Base_Arena",
			Buttons = { "공룡 배치", { Exact = "배치" }, "✅ 놓기" },
			Guide = { "🦖 공룡 놓기",
				"공룡이 길을 도는 💀 화석을 잡으면 💰 돈이 생겨요",
				"👆 손가락을 따라 '배치' → '✅ 놓기'를 눌러요" } },
		{ Id = "Draw2", Text = "선물 열쇠! 또 뽑자", Event = "BoxOpen", Button = "뽑기", Buttons = { "뽑기", "📦", "모두 열기" },
			GiftKeys = 1,
			Forced = { Attribute = "Ice" },
			Guide = { "🎁 코코의 선물 열쇠!",
				"한 번 더 뽑으면 ❄️ 얼음 공룡이 나와요. 그 공룡도 놓아요",
				"📦 상자가 다 되면 열어요",
				"💧 물 + ❄️ 얼음은 같이 쓰면 더 세져요! 조금 뒤에 보여 줄게요" } },
		{ Id = "Place2", Text = "얼음 공룡도 놓자!", Event = "Place", Button = "공룡 배치", Target = "Base_Arena",
			Buttons = { "공룡 배치", { Exact = "배치" }, "✅ 놓기" } },
		-- (2026-10-03, "30이나 걸려 튜토가??" → 짧은 튜토리얼 + 나머지는 배우기) the first win right after the two dinos
		{ Id = "Promotion", Text = "👑 보스에 도전!", Event = "Promotion", Button = "보스 도전", Setup = { Team = true },
			Guide = { "👑 보스 웨이브: 디펜스 레벨 올리기",
				"위쪽 '⚔️ 보스 도전' 버튼을 눌러요",
				"⏱️ 시간 제한 없음! 보스를 잡으면 레벨 UP · 열쇠도 받아요",
				"💔 화석이 빠지면 ❤️가 줄어요 · ❤️ 0이면 실패!" } },
		-- (2026-10-03, "튜토리얼 필드에서 빠진 시스템 없는지 다시 점검해봐": the odds table, better keys, variants, the
		-- limited dino, luck; the battlefield's own rules; the home button, the dex, the inventory, the rewards button)
		{ Id = "GachaMore", Text = "뽑기를 더 알아보자!", Client = true,
			Info = { "🎰 뽑기 더 알기",
				"뽑기 창의 '📋 등급표': 무엇이 얼마나 잘 나오는지 보여 줘요",
				"📦 상자는 등급이 높고 클수록 오래 걸려요 (전설 10분 · 신화 30분…) 나중에 와서 열어요!",
				"🔑 좋은 열쇠(은·황금·루비…)일수록 좋은 등급·큰 공룡이 나와요",
				"✨ 변종 공룡은 은 열쇠 이상으로 뽑아야 나와요",
				"🎖️ 이번 주 한정 공룡도 가끔 나와요 (매주 바뀌어요)",
				"🍀 행운이 켜져 있으면 좋은 공룡이 더 잘 나와요" } },
		{ Id = "Attributes", Text = "보스 속성을 확인해!", Reach = "AttributeBoard", Target = "AttributeBoard",
			Info = { "🧪 속성표",
				"공룡과 보스는 속성이 있어요 (🔥 불, 💧 물, ⚡ 전기, ❄️ 얼음 …)",
				"🔥 펑! · ❄️ 꽁꽁 · ☠️ 독 웅덩이 · ⚡ 찌릿 번개 · ⚪ 보스에 세요",
				"⚠️ 보스랑 같은 속성 공룡은 약해져요",
				"🎯 보스마다 약점이 있어요! 그 속성 공룡이 더 세요",
				"🦖 보스 속성을 보고, 약점 공룡을 놓아요" } },
		{ Id = "TopView", Text = "위에서 내려다보자!", Client = true, Button = "탑뷰", Target = "Base_Arena",
			Guide = { "🗺️ 탑뷰",
				"🏟️ 내 아레나 가까이 가면 👋 찰싹 버튼 위에 '🗺️ 탑뷰'가 생겨요",
				"👆 누르면 하늘에서 내려다봐요 · 공룡을 눌러 옮겨요",
				"🔄 '🔄 90°'를 누르면 화면이 돌아가요 · 여러 방향에서 봐요",
				"📊 피해 창을 눌러 누가 공격했는지 확인해요",
				"🛡️ 감속·물 공룡은 피해가 낮아도 조합을 도와요",
				"↩️ '🗺️ 탑뷰 끄기'를 누르면 돌아와요" } },
		{ Id = "Combo", Text = "속성 조합을 지켜보자!", Event = "Combo", Needs = "ComboTeam", Target = "Base_Arena",
			Setup = { Team = true },
			Guide = { "🧪 속성 조합",
				"💧 물 공룡이 화석을 물에 젖게 해요",
				"젖은 화석을 ❄️ 얼음 공룡이 때리면 '빙결!' 더 오래 얼어요",
				"⚡ 전기 공룡이 때리면 '감전!' 더 아파요",
				"👀 길에서 '빙결!' 글자가 뜰 때까지 지켜봐요",
				"🍖 육식 2종 · 🛡️ 초식+갑옷 · 🦅 비행+육식은 조합 효과!" } },
		{ Id = "Fossils", Text = "특별한 화석들!", Client = true,
			Info = { "🦴 레벨이 오르면 나오는 특별한 화석",
				"💨 빠른 화석 (LV 5~): 멀리 닿는 하늘·바다 공룡이 좋아요",
				"🛡️ 단단한 화석 (LV 15~): 머리 위 속성은 잘 안 통해요. 여러 속성을 놓아요",
				"🐜 떼 화석 (LV 25~): 우르르 몰려와요! 펑 터지는 🔥❄️☠️ 공룡이 좋아요",
				"🥚 껍질 · 🧱 돌 · 🧊 서리 · 🌋 용암 · 🎈 비행선 · 🗿 거대 · 🎎 인형 · 👻 유령 · 🚩 무리도 와요!",
				"🌊 바다 공룡은 연못에만 놓아요. 파도로 화석을 뒤로 밀어요",
				"헷갈리면 '🦖 공룡 배치' 창 맨 위를 봐요" } },
		-- (2026-10-03, "폭탄 던져보기 약한 보스 찰싹과 폭탄으로 처치해보기 … 왜 이런 디테일들 안 넣냐? 넣어도 될건 다 넣고 좀
		-- 과하다 싶은 것만 빼고", "내가 요청한 것 외에도 다 찾아봐 가능할만한거") hands-on wherever it can be: a wave of the
		-- challenge, a slot bought, fruit carried home, a key trade, a speed pad, zombies, both bombs, the boss beaten, the bell
		{ Id = "Challenge", Text = "무한 도전 1판!", Event = "ChallengeWave", Button = "♾️ 도전", Busy = "ChallengeWave", Target = "Base_Arena",
			Guide = { "♾️ 무한 도전",
				"오른쪽 '♾️ 도전' 버튼을 누르면 바로 시작해요",
				"🦴 점점 센 화석이 끝없이 와요. 1판만 버텨 봐요!",
				"🏆 1판만 해도 다음 주에 선물! 순위가 높으면 더 좋아요",
				"👍 레벨은 그대로라 언제든 해도 돼요 (돈은 안 나와요)" } },
		{ Id = "Slots", Text = "공룡 자리를 늘리자!", Event = "SlotBuy", Target = "DefenseSign",
			Setup = { StopChallenge = true, Money = "Slot" },
			Guide = { "➕ 공룡 자리 늘리기",
				"📍 공룡을 놓을 자리는 정해져 있어요",
				"✨ 빛나는 길을 따라 아레나 앞 표지판으로 가요",
				"👆 '공룡 자리 늘리기'를 눌러 1칸 사 봐요 (코코가 돈을 보탰어요)",
				"🦖 공룡이 많을수록 디펜스가 세져요!" } },
		{ Id = "Maps", Text = "맵 게시판도 있어!", Reach = "MapBoard", Target = "MapBoard",
			Info = { "🗺️ 디펜스 맵",
				"🔓 LV 5부터 새 맵이 열려요 (LV 10 · 15 · 20 · 25 …)",
				"👆 아레나 옆 🗺️ 맵 게시판을 눌러 골라요",
				"🛣️ 맵마다 길 모양이 달라요. 내 공룡에 맞는 맵을 골라요",
				"📍 맵마다 배치가 따로 저장돼요",
				"🏔️ 맵마다 하늘 바위: 🦅 하늘 공룡만 앉아요 · 📏 더 멀리",
				"🎲 첫 환생 뒤 LV 8부터 5레벨마다 변칙 승급전! 맞는 공룡만 싸워요" } },
		{ Id = "Enhance", Text = "공룡을 강화하자!", Event = "Enhance", Target = "EnhanceStall", Setup = { Fodder = true, StopChallenge = true },
			Guide = { "⬆️ 공룡 강화",
				"빛나는 길을 따라 아레나 앞 🦖 공룡 강화 가판대로 가요",
				"🎁 코코가 연습용 공룡을 몇 마리 줬어요",
				"👆 키울 공룡을 고르고, 안 쓰는 공룡을 재료로 넣어요",
				"레벨이 오르면 공격이 세져요! ⭐추천 공룡에 '✨ 추천 선택'" } },
		{ Id = "Dummy", Text = "인형을 찰싹 3번!", Event = "DummyHit", Count = 3, Target = "Dummy",
			Guide = { "👋 찰싹 연습",
				"✨ 빛나는 길을 따라 기지 입구 쪽 연습 인형으로 가요",
				"인형 앞에서 '👋 찰싹' 버튼을 3번! (키보드는 F)",
				"👋 기지 밖 들판에선 찰싹으로 친구를 날릴 수 있어요",
				"🎁 맞은 사람은 들고 있던 선물상자를 떨어뜨려요!" } },
		{ Id = "Fruit", Text = "나무를 찰싹! 열매 3개!", Event = "FruitPick", Count = 3, Target = "FruitTree",
			Guide = { "🌳 열매 따기",
				"✨ 빛나는 길을 따라 가까운 나무로 가요",
				"나무 앞에서 '👋 찰싹'! 열매가 우수수 떨어져요",
				"🍎 떨어진 열매 위로 걸어가면 주워요. 3개 모아 봐요" } },
		-- (2026-10-05, "열매는 굳이 기지로 돌아가는 시스템을 안 넣어도 되지") picked fruit is food at once: nothing is carried, so
		-- this step is passed by as it comes (Needs "Carrying", Tutorial.onEnter). Kept: a save counts its step by index
		{ Id = "FruitHome", Text = "열매가 먹이로!", Event = "FruitHome", Target = "Home", Needs = "Carrying",
			Guide = { "🍎 열매 → 먹이",
				"🍎 주운 열매는 바로 먹이가 돼요",
				"🍎 먹이로 공룡을 키워요!" } },
		{ Id = "Feed", Text = "먹이로 공룡을 키우자!", Event = "Feed", Target = "EnhanceStall", Setup = { Food = true },
			Guide = { "🍎 공룡 먹이",
				"강화 가판대 창의 '🍎 먹이' 탭을 눌러요",
				"🍎 모아 온 먹이로 키워요 (모자라면 코코가 채워 줘요)",
				"공룡을 고르고 '🍎 먹이 주기'! 먹이가 쌓여 다 차면 한 크기 커져요",
				"클수록 세요!" } },
		{ Id = "Merge", Text = "공룡을 합성하자!", Event = "Merge", Target = "EnhanceStall", Setup = { MergeSet = true },
			Guide = { "🧬 공룡 합성",
				"강화 가판대 창의 '🧬 합성' 탭을 눌러요",
				"🧬 같은 등급, Lv 10 이상 공룡 3마리 → 한 등급 위 공룡 1마리!",
				"🎁 코코가 합성할 공룡 3마리를 줬어요. 골라서 합성해 봐요",
				"⭐ 크고 레벨 높은 공룡을 넣을수록 좋은 공룡이 나와요" } },
		-- (2026-10-03, "농장에 공룡을 넣자가 왜 농장 칸늘리기로 노란줄이 연결되냐": was FarmSign, the slot sign) the pen
		{ Id = "Farm", Text = "농장에 공룡을 넣자!", Event = "FarmAdd", Button = "공룡 배치", Target = "Base_FarmPen",
			Setup = { Spare = true },
			Guide = { "🌾 농장: 공룡을 넣어 두면 계속 도움",
				"'🦖 공룡 배치' 창에서 공룡 줄의 '농장' 버튼을 눌러요",
				"공룡마다 돕는 게 달라요: 💪힘 · 💰돈 · ⛏️채굴 · 🍀좋은 공룡 · 🐢화석 느리게",
				"⭐ 좋은 등급, 큰 공룡일수록 도움이 커요",
				"➕ 농장 표지판에서 칸을 늘릴 수 있어요",
				"🌾 빼려면: 농장 안 공룡 옆에 가서 '🌾 빼기'" } },
		{ Id = "Ride", Text = "공룡 타고 달리자!", Event = "Mount", Target = "MountPedestal",
			Guide = { "🦖 공룡 타기",
				"✨ 빛나는 길을 따라 탈 공룡 발판으로 가서 탈 공룡(등급·크기)을 골라요",
				"오른쪽 아래 '🦖 타기' 버튼을 눌러요 (키보드는 R)",
				"💨 타면 빨리 달려요 · 하늘 공룡은 날 수도 있어요",
				"🏁 다른 사람과 레이스, 발판에서 혼자 연습도 돼요" } },
		{ Id = "KeyStall", Text = "열쇠를 사 보자!", Event = "KeyBuy", Target = "KeyStall", Setup = { Money = "Keys" },
			Guide = { "🔑 열쇠 가판대",
				"✨ 빛나는 길을 따라 열쇠 가판대로 가서 열쇠를 1개 사 봐요",
				"💰 돈으로 언제든 열쇠를 살 수 있어요",
				"🔒 루비 열쇠부터는 환생해야 살 수 있어요" } },
		{ Id = "KeyTrade", Text = "열쇠 10개를 은 열쇠로!", Event = "KeyTrade", Target = "KeyStall", EnsureKeys = 10,
			Guide = { "🔁 열쇠 바꾸기",
				"🔄 같은 가판대의 '교환'에서 열쇠 10개 → 은 열쇠 1개!",
				"🎁 코코가 열쇠 10개를 채워 줬어요. 바꿔 봐요",
				"⬆️ 은 → 황금 → 루비 … 위로는 7개씩 바꿔요",
				"🦖 좋은 열쇠일수록 좋은·큰·특별한 공룡이 나와요!" } },
		{ Id = "CenterKey", Text = "가운데로 가자!", Reach = "Center", Target = "Center", CarryKeys = 1,
			Guide = { "🎁 선물상자 줍기",
				"✨ 빛나는 길을 따라 맵 한가운데 선물 제단으로 가요",
				"🎁 몇 분마다 제단에 공룡 선물상자가 떨어져요. 상자 앞에서 꾹 눌러 들어요",
				"🌈 색은 등급, 크기는 공룡 크기! 🛡️ 제단 지킴이가 쫓아와요" } },
		{ Id = "CarryHome", Text = "상자 들고 집으로!", Event = "KeysHome", Target = "Home",
			Guide = { "🏠 상자 지키기",
				"🏃 상자를 머리에 이고 빛나는 길을 따라 내 기지로 달려요",
				"🏠 기지에 들어가면 📦 내 상자 더미에 쌓여요",
				"⚠️ 찰싹 맞거나 🛡️ 지킴이에게 잡히면 상자를 놓쳐요!" } },
		{ Id = "Battlefield", Text = "들판에는 규칙이 있어!", Client = true,
			Info = { "⚔️ 기지 밖 들판",
				"💰 현상금: 1등을 찰싹하면 보상을 받아요",
				"👑 왕 상자는 상자 5개 값! 들고 가는 사람을 노려요",
				"🟡 스피드 패드를 밟으면 잠깐 빨라져요",
				"🦕 야생 공룡: 가까이 가서 올라타고, 남에게 던질 수도 있어요",
				"🦅 익룡 똥에 맞으면 잠깐 못 움직여요 · 💎 대박 광물은 돈·열쇠가 와르르",
				"🎒 가방이 꽉 차면 기지로 돌아가 입금해요" } },
		{ Id = "SpeedPad", Text = "스피드 패드를 밟자!", Event = "Pads", Target = "SpeedPad", Setup = { SpeedPad = true },
			Guide = { "🟡 스피드 패드",
				"✨ 기지 밖에 노란 스피드 패드가 생겼어요! 빛나는 길을 따라가요",
				"💨 밟으면 잠깐 엄청 빨라져요",
				"🏃 쫓아오는 친구를 따돌려요 · 🛡️ 지킴이는 같이 빨라져요" } },
		{ Id = "Chest", Text = "보물상자를 열자!", Event = "Chests", Target = "Chest", Setup = { Chest = true },
			Guide = { "🎁 보물상자",
				"✨ 기지 밖 들판에 보물상자가 나타났어요! 빛나는 길을 따라가요",
				"👆 상자 앞에서 '열기'를 꾹 누르고 있어요",
				"💰 돈·열쇠·광물이 들어 있어요. 들판 여기저기에 가끔 나와요" } },
		{ Id = "Home", Text = "기지로 순간이동!", Event = "HomeTeleport", Button = "기지로",
			Guide = { "🏠 기지로 순간이동",
				"멀리 나왔으면 오른쪽 '🏠 기지로' 버튼을 눌러요",
				"⚡ 누르면 바로 내 기지로 휙! 한 번 해 봐요",
				"🚫 상자를 들고 있을 땐 못 써요 (걸어서 가져가야 해요)" } },
		{ Id = "Weather", Text = "날씨가 바뀌었어!", Client = true, Setup = { Weather = "Rain" },
			Info = { "🌧️ 날씨",
				"🌧️ 가끔 날씨가 바뀌어요. 지금은 비가 와요!",
				"🌧️ 비 · 🌈 무지개: 돈을 몇 배로 벌어요" } },
		{ Id = "Night", Text = "밤이 됐어! 좀비 3마리 찰싹!", Event = "ZombieSlap", Count = 3, Target = "Zombie",
			Setup = { Night = true, Weather = "Clear" },
			Guide = { "🌙 밤과 🧟 좀비 공룡",
				"🌙 밤이 되면 들판에 좀비 공룡이 나와서 쫓아와요",
				"좀비를 '👋 찰싹'으로 날려 버려요! 3마리 해 봐요" } },
		{ Id = "BombEgg", Text = "좀비에게 알 폭탄!", Event = "BombEgg", Button = "💥", Target = "Zombie", Setup = { Night = true, Bombs = true },
			Guide = { "💣 폭탄 던지기",
				"코코가 💣 폭탄을 줬어요! 👆 손가락이 가리키는 💥 버튼을 써요",
				"👆 오른쪽 아래 💥 버튼을 꾹 누른 채 끌어서 겨누고, 떼면 던져요" } },
		{ Id = "BombPoop", Text = "보스에게 똥 폭탄!", Event = "BombPoop", Button = "💩", Target = "Boss",
			Setup = { Night = true, Boss = true, Bombs = true },
			Guide = { "👑 밤 보스 등장!",
				"먼저 💩 똥 폭탄을 보스에게 던져요",
				"💩 맞은 보스는 똥에 파묻혀 한동안 못 움직여요" } },
		{ Id = "BossKill", Text = "보스를 쓰러뜨려!", Event = "Boss", Target = "Boss",
			Setup = { Night = true, Boss = true, Bombs = true },
			Guide = { "👑 보스 쓰러뜨리기",
				"'👋 찰싹'과 🥚 알 폭탄으로 보스를 공격해요",
				"👑 이 보스는 연습용이라 약해요. 끝까지 쓰러뜨려 봐요!" } },
		{ Id = "BombShop", Text = "폭탄은 여기서 사!", Reach = "BombStall", Target = "BombStall", Setup = { Night = false },
			Info = { "💣 폭탄 가게",
				"💰 폭탄은 여기서 돈으로 사요",
				"⚔️ 기지 밖 들판에서만 던질 수 있어요" } },
		{ Id = "Rebirth", Text = "LV 30이면 여기서 환생!", Reach = "RebirthSign", Target = "RebirthSign",
			Info = { "🔄 환생",
				"🔄 LV 30이 되면 여기서 환생해요",
				"🔁 디펜스 레벨은 LV 1부터 다시 해요",
				"대신 영원히 세져요: 💪힘 · 💰돈 · 🍀좋은 공룡 · ➕자리",
				"🔓 환생할 때마다 새 등급과 새 공룡이 열려요",
				"🎰 새 등급 확정 뽑기 1번도 받아요" } },
		-- (2026-10-02, "튜토리얼이 가장 중요해. 유저가 뭘 하고 뭘 중점적으로 키워 나가고 뭘 더 할 수 있을지 다 알려 줘")
		{ Id = "Grow", Text = "이렇게 키워 나가자!", Client = true,
			Info = { "🎯 이렇게 키워요 (위에서부터 차례로)",
				"1. 🎰 뽑기 → 🦖 배치 → 👑 보스 웨이브",
				"2. 🛣️ 레벨마다 🎁 상자 · 10레벨마다 더 좋은 상자",
				"3. 🦖 공룡: ⬆️ 강화·🍎 먹이·🧬 합성으로 세게",
				"4. 🔄 LV 30이 되면 환생: 영원히 세지고 새 공룡이 열려요",
				"🏆 마지막 목표: 📖 공룡을 다 모아 👑 공룡 왕!" } },
		{ Id = "Dex", Text = "도감을 열어 봐!", Client = true, Button = "도감",
			Guide = { "📖 도감",
				"📖 내가 모은 공룡 종류와 등급이 기록돼요",
				"🏅 많이 모을수록 열쇠와 칭호(머리 위에 보여요)를 받아요",
				"👑 공룡을 다 모으면 공룡 왕! 마지막 목표예요",
				"위쪽 '📖 도감' 버튼을 눌러 봐요" } },
		{ Id = "Bag", Text = "인벤토리를 열어 봐!", Client = true, Button = "인벤토리",
			Guide = { "🎒 인벤토리",
				"🎒 내 공룡·아이템·손바닥 스킨을 한눈에 봐요",
				"👋 스킨을 끼면 손바닥 모양이 바뀌어요",
				"오른쪽 '🎒 인벤토리' 버튼을 눌러 봐요" } },
		{ Id = "RewardsBtn", Text = "보상은 여기!", Client = true, Button = "보상",
			Guide = { "🎁 보상",
				"🎁 임무·출석·선물 보상을 받는 곳이에요",
				"🔴 받을 게 있으면 버튼에 숫자가 떠요",
				"오른쪽 '🎁 보상' 버튼을 눌러 봐요" } },
		{ Id = "Bell", Text = "종을 울려 봐!", Event = "Bell", Button = "🔔",
			Guide = { "🔔 종",
				"왼쪽 아래 '🔔' 버튼을 눌러요",
				"📍 내 자리에 소리와 표시가 떠서 멀리서도 보여요",
				"친구를 부를 때 써요!" } },
		{ Id = "More", Text = "할 게 더 많아!", Client = true,
			Info = { "🌟 이것도 해 봐요",
				"📋 왼쪽 위 초보 미션: 다음에 할 일을 하나씩 알려 줘요",
				"🏁 레이스 · 🏆 시즌 패스",
				"⚙️ 설정: 렉 줄이기·소리·🌐 언어·코코의 팁",
				"👫 친구랑 같은 서버면 돈 +10%" } },
		{ Id = "Finish", Text = "다 했어! 최고야!", Client = true,
			Info = { "🎉 튜토리얼 완료!",
				"🏠 이제 내 기지로 가서 진짜 시작해요!",
				"📋 나머지는 왼쪽 위 초보 미션으로 배워요 (미션마다 🎁)",
				"🔓 LV을 올리고 초보 미션을 끝내면 시설과 들판이 하나씩 열려요!" } },
	},
	FirstRun = false,
	IslandHello = {
		"안녕! 나는 코코야! 🦖 이 섬에 사는 아기 공룡이야",
		"튜토리얼 끝! 이제 섬 전체를 보여 줄게 🏝️",
	},
	IslandIntro = {
		"와! 이제 섬 전체가 보여! 🏝️",
		"앗! 저기 하늘 위에 🧙 화석 마녀가 있어!",
		"하늘에서 💫 뼈별이 떨어진 곳이 바로 여기, 섬 한가운데야!",
		"😱 저 마녀가 다 꾸민 일이었어!",
		"뼈별 가루가 땅에 스며들자 💀 화석들이 깨어났어!",
		"🎁 그 상자들이 떨어지는 곳이 바로 선물 제단이야!",
		"🛡️ 지킴이를 피해 집에 가져가면 🦖 공룡 친구가 나와!",
		"밤엔 🧟 좀비 공룡까지 나타나… 나 혼자선 못 막아!",
		"📖 공룡을 다 모아 👑 공룡 왕이 되면 화석들이 땅속으로 돌아가!",
		"자, 같이 섬을 지키러 가자! 🦖",
		"🎯 첫 목표는 디펜스 LV 30! 그다음 🔄 첫 환생이야",
	},
	IslandShots = { "Tour", "Sky", "Sky", "Witch", "Raid", "Altar", "Bases", "Battle", "Wild", "Coco", "Coco" },
	IntroVersion = 2,
	StepsVersion = 2,
	CinemaFocusSeconds = 150, -- 임시값
	Openings = {
		Resume = { "다시 왔구나! 기다리고 있었어 🐣", "멈췄던 곳부터 이어서 하자! 🦖" },
		Part = { "또 배우러 왔구나! 📖", "이번엔 이 부분만 다시 볼게. 가자! 🦖" },
	},
	-- (2026-10-02, "튜토리얼 다시보기 파트별로 가능하게") 설정 → 📖 코코에게 배우기: the whole, or one part (its
	-- steps From .. To; a part's hands-on steps done before still only show their card, TutorialLogic)
	-- (2026-10-03, "튜토리얼 미션도 추가해서 거기에 보상 넣고 그걸 클리어하게 유도하면서 배우게 하자") the Lesson parts are
	-- now learned on the beginner mission board in the real game (Config.StarterMissions, Learn): no Reward, Offer or Ask
	-- here any more, so Coco offers no trip to the field; 설정 → 📖 코코에게 배우기 still replays any part (no reward).
	-- Before that:
	-- (2026-10-03, "30이나 걸려 튜토가??" → "그렇게 바꿔") the first run is only the parts without Lesson (about 8
	-- minutes: mine, deposit, upgrade, two draws, two dinos, the first promotion won, then the night: zombies, both
	-- bombs and the practice boss beaten); a Lesson part is learned later on
	-- the field like a replay, and the first time it is finished pays its Reward (Rewards.grant; together with
	-- Field.Reward what the whole tutorial paid before). Coco offers each lesson once, when it is needed (Offer:
	-- Level = the defense level reached, PromoFail = a lost promotion, Battlefield = on the battlefield, Night = a
	-- night; StarterPlayerScripts/Lessons, with Coco's Ask line); 설정 lists them all, 🎁 = not learned yet. 임시값
	Parts = {
		{ Id = "Money", Name = "⛏️ 캐기·입금", From = "Mine", To = "Deposit" },
		{ Id = "Train", Name = "💪 훈련장", From = "Shop", To = "Shop", Lesson = true },
		{ Id = "Dinos", Name = "🎰 뽑기·공룡 놓기·첫 보스", From = "Draw1", To = "Promotion" },
		{ Id = "Defense", Name = "⚔️ 디펜스 전략·속성", From = "GachaMore", To = "Maps", Lesson = true },
		{ Id = "Grow", Name = "⬆️ 강화·열매·먹이·합성·농장", From = "Enhance", To = "Farm", Lesson = true },
		{ Id = "Keys", Name = "🎁 타기·선물상자·들판", From = "Ride", To = "Home", Lesson = true },
		-- (2026-10-03, "왜 튜토리얼에서 보스 잡는게 사라졌지") the night, the bombs and the boss fight are in the first
		-- run again (they were a lesson for a while)
		{ Id = "Night", Name = "🌙 날씨·밤·보스·폭탄", From = "Weather", To = "BossKill", Lesson = true },
		{ Id = "BombShop", Name = "💣 폭탄 가게", From = "BombShop", To = "BombShop", Lesson = true },
		{ Id = "Plan", Name = "🎯 환생·도감·보상·할 것", From = "Rebirth", To = "More", Lesson = true },
	},
	Field = {
		StoreName = "TutorialField_v5", -- the field's saves, apart from the real ones (PlayerData)
		-- the first finish only, in the real save (Rewards.grant); 2026-10-03: was 10 keys and 3 silver for the whole
		-- tutorial, the rest now comes with the lessons (Parts' Reward)
		Reward = { Keys = 8 }, -- (2026-10-03: 5, plus the night lesson's 3 now that the night is in the first run)
		RewardLuckMinutes = 60, -- ... and the draws' luck × StarterMissions.LuckMultiplier this long
		Fodder = 3, -- the ⬆️ 강화 step: this many spare common dinos
		MergeRarity = "Uncommon", -- the 🧬 합성 step: three dinos of it at Merge.Level
		-- the bomb and boss steps: at least this many (2026-10-03: were 3 and 1, "보스 잡을때 폭탄 지급을 더 많이"; then 5 and 2,
		-- "튜토에서 보스 약하게 하랬지 폭탄도 많이주고. 튜토나가면 어차피 다 초기화잖아": the field's save is thrown away)
		-- (2026-10-03, "폭탄도 가득 주고": full, Bombs.MaxHeld of each; true here)
		BombsFull = true,
		Bombs = { Egg = 10, Poop = 5 }, -- (used only without BombsFull)
		-- the practice boss's health (2026-10-03, "10으로 해": a fixed 10, the bar reads 10/10; a slap at level 1 does 1,
		-- an egg bomb 7). Before: BossSlaps = 5 slaps' worth (was 14, "보스 체력을 튜토리얼 한정 낮추든가", then 8)
		BossHealth = 10,
		PadOut = 12, -- studs out of the base's entrance for the speed pad step's pad ...
		ChestOut = 25, -- ... the chest step's chest ...
		BossOut = 60, -- ... and the night boss
		LeaveDelay = 2, -- seconds after the last card before the trip home
	},
	ReachRange = 14, -- studs (flat) from a Reach spot that count as there (Center: the key zone's radius)
	PromotionHealthShare = 0.5, -- the first run's promotion fight: its monsters this share as tough
	DummyDropKeys = 1, -- keys the dummy drops after its last slap (first run only)
	DummyDistance = 30, -- studs in from the base entrance, left of the middle line ...
	DummySide = -22, -- ... (studs across: negative = the entrance's left)
	PraiseSeconds = 3, -- "잘했어!" between steps (2026-10-03, "코코 말이 좀 빠른 듯": was 1.6, then 2.2)
	-- (2026-10-01) the first run's help, only where it is meant: nobody can hit the player (and they can't
	-- hit other players) up to and including ShieldUntilStep and for at most ShieldMinutes after the first
	-- join; the promotion is easier only on EasyStep. (They lasted the whole first run: never finishing
	-- the tutorial kept a player unhittable at the key zone and every promotion at half health.)
	ShieldUntilStep = "CarryHome",
	ShieldMinutes = 20,
	EasyStep = "Promotion",
	MaxWordsPerLine = 6,
	-- (2026-10-02) Needs: what a step needs to be done at all (Tutorial service); without it Coco's card tells it and
	-- moves on. Placed: a dino on the platform; ComboTeam: a placed 💧 water dino with an ❄️ ice or ⚡ electric one
}

return Tutorial
