return {
	RaritySeconds = { -- 임시값
		Common = 5, Uncommon = 10, Rare = 30, Epic = 120, Legendary = 600, Mythic = 1800, Transcendent = 3600,
		Rainbow = 7200, Golden = 10800, Onyx = 14400, Celestial = 21600, Secret = 28800, Cosmic = 36000,
		Primeval = 43200, Divine = 64800, Special = 5,
	},
	SizeMultiplier = { -- 임시값
		Hatchling = 0.5, Tiny = 0.6, Baby = 0.7, Small = 0.85, Young = 1, Junior = 1.25, Teen = 1.5, Grown = 1.8,
		Adult = 2.2, Big = 2.7, Alpha = 3.3, Giant = 4, Colossal = 5.5, Titan = 7, Behemoth = 9, Primordial = 12,
	},
	MinSeconds = 3, -- 임시값
	MaxSeconds = 86400, -- 임시값
	FirstDrawSeconds = 5, -- 임시값
	FirstDraws = 35, -- 임시값
	TutorialSeconds = 3, -- 임시값
	PileShown = 24, -- 임시값
	GrowFrom = 0.35, -- 임시값
	OpenAtOnce = 50, -- 임시값
	ReadyNoticeGap = 30, -- 임시값
	Rush = { -- 임시값
		{ Robux = 10, Seconds = 600 },
		{ Robux = 29, Seconds = 3600 },
		{ Robux = 79, Seconds = 21600 },
		{ Robux = 199, Seconds = 86400 },
	},
	RushIntentSeconds = 300, -- 임시값
	FreeSkips = 1, -- 임시값
	FreeSkipMinSeconds = 60, -- 임시값
}
