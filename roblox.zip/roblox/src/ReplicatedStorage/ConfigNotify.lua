return {
	FriendPlaying = { MessageId = "", AfterMinutes = 3, MaxFriends = 20, Gap = 0.5 }, -- 임시값
	BoxReady = { MessageId = "", MinMinutes = 30, KeepHours = 12, PollEvery = 60, Batch = 20, Map = "BoxReadyDue" }, -- 임시값
	OptIn = { AfterMinutes = 4, CheckEvery = 5, ExplainSeconds = 3 }, -- 임시값
	JoinDelay = 2, -- 임시값
	JoinPrefix = "friend:",
	SharePrefix = "share:",
	BoxLaunch = "boxes",
	Package = { "OpenCloud", "V2", "UserNotification" },
}
