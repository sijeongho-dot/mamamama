--[[
ConfigRanked: Config.Ranked, the 🏆 랭킹전 of 🙈 hide-and-seek and 🏁 the races (2026-10-04, "술래잡기 레이스 둘다
랭킹전 일반전 있게 하자. 일반전은 기록이 안남고 랭킹전은 기록이 남는", "랭킹전 보상도 주간 열쇠로 주는 식 어때").
(2026-10-04) 🧟 the night boss hunts are ranked the same way (game "Boss", Zombies service).
Config.lua puts it at Config.Ranked and freezes it with the rest. Read it as Config.Ranked, never this module directly.

A room is opened as 🏆 랭킹전 (the wins and losses are saved, the all-server records, and each win counts in this week's
ranking) or 🎈 일반전 (nothing saved). Each game has its own week's ranking by ranked wins (RewardLogic.rankedWin,
Leaderboards): when the week is over, its rank pays RankRewards, the rest with a win PlayReward. 임시값
]]
return {
	StoreName = "RankedWins_v1", -- OrderedDataStore per game and week: StoreName .. "_" .. game .. "_" .. week
	-- (the profile's Ranked fields and the stores go by these; 2026-10-04, the night boss's ③: "Boss", this week's
	-- 🧟 bosses helped down, RewardLogic.rankedAdd, no rivals)
	Games = { "Hide", "Race", "Boss" },
	Top = 10, -- the week's top shown in the 🎮 놀이방 window
	RankRead = 100, -- read for the rewards (as deep as the last RankRewards row)
	-- a win counts in the week's ranking only against a rival who has given the winner fewer than SameRivalWins
	-- counted wins this week (two friends trading wins get a few, not a pile); RivalsKept rivals remembered a week
	-- (the save stays small: past it, wins count)
	SameRivalWins = 3,
	RivalsKept = 100,
	RankRewards = { -- the first row whose Top the rank is within
		{ Top = 1, Reward = { SpecialKeys = { Diamond = 1 } } },
		{ Top = 3, Reward = { SpecialKeys = { Ruby = 1 } } },
		{ Top = 10, Reward = { SpecialKeys = { Gold = 3 } } },
		{ Top = 100, Reward = { SpecialKeys = { Gold = 1 } } },
	},
	PlayReward = { SpecialKeys = { Silver = 2 } }, -- everyone else with a counted win that week
	PlayKeys = { Minutes = 4, WinMinutes = 10, DailyGames = 15 }, -- 임시값
	-- (2026-10-06, "랭킹전은 입장시 열쇠소모하게. 이기면 많은 열쇠를 다시 얻게", "단체전이면 등수에 따라 차등지급 꼴찌는 0") a ranked
	-- game takes one of Grades' stakes from each player as it starts (the host picks it when opening the room, only
	-- those holding it can join; RewardLogic.stakePayouts): the pot (players × the stake's worth in plain keys, by the
	-- key's PriceMultiplier) is shared by place, a place's share (players − place)² (tied places share), the last gets
	-- none, paid in the stake's grade and the rest in plain keys; WinBonus more on top of a payout for each player's
	-- first BonusGamesPerDay ranked games of the day. A race called off pays back. 임시값
	Stake = {
		Grades = { { Id = "Normal", Keys = 10 }, { Id = "Silver", Keys = 2 }, { Id = "Gold", Keys = 1 } },
		WinBonus = 0.5,
		BonusGamesPerDay = 10,
	},
}
