--[[
ConfigZombies: Config.Zombies, the zombie dinos on the battlefield at night, the night's boss and the aurora boss
(Zombies service, ZombieLogic). Split off Config.lua on 2026-10-04 (Roblox takes less than 200,000 characters a
script); Config.lua puts it at Config.Zombies and freezes it with the rest. Read it as Config.Zombies, never this
module directly. All 임시값
]]
return {
	Count = 40, -- (was 24, then 18, then 26; 2026-10-01 "more zombies at night") spread evenly over the battlefield
	Model = "Dino_Zombie", -- their own cute zombie dino (tools/dinos.json "Zombie"); without it ...
	Species = { "TRex", "Raptor", "Trike", "Stego", "Spino", "Ankylo" }, -- ... these, turned rotten, in turn
	EdgeMargin = 10, -- studs inside the flags
	PlazaRadius = 60, -- they stay out of the middle (the key altar fight stays between players)
	HomeRadius = 30, -- each wanders around its own spot
	WanderSpeed = 5,
	ChaseSpeed = 13, -- a little slower than a walking player (16): you can get away
	AggroRange = 28, -- (was 35) a player this close draws it ...
	LoseRange = 60, -- ... farther than this, it gives up
	HitRange = 4.5,
	HitCooldown = 3,
	Knockback = 18, -- studs a hit throws a player (like a slap: carried keys fall, groggy after)
	RiseSeconds = 3, -- crawling out of the ground at nightfall ...
	RiseSpread = 8, -- ... each after up to this many seconds
	SinkSeconds = 3, -- back into the ground at dawn
	PauseSeconds = { 1.5, 4 }, -- standing still between wanders
	TickSeconds = 0.1, -- how often the server moves them
	PublishSeconds = 0.3, -- (2026-10-01) how often their positions go to the screens (they glide between)
	-- players slap them back: a slap reaching one (reach + BodyRadius, in front) throws it SlapKnockback
	-- studs away in an arc for SlapFlightSeconds, then it lies dizzy for SlapStunSeconds (no chasing)
	BodyRadius = 2.5,
	SlapKnockback = 26,
	SlapFlightSeconds = 1.1,
	SlapStunSeconds = 1, -- (was 4, then 2: still too long before it got up)
	-- 임시값 (2026-10-01, "a closer player should become the target"): a chasing zombie (and boss) turns to
	-- another player who comes this many studs nearer than the one it chases
	RetargetMargin = 3,
	-- 임시값 (2026-10-01, "고도 상관없이 공격", "지형지물 통과", "크리스탈 위면 점프해서 올라", "끼지 않게 최적 경로"):
	-- the ground under them (Zombies service, ZombieLogic): walking, they step up at most StepHeight
	-- (crystals, rocks and trees are in the way: they go round); a hit needs the player's feet within
	-- HitHeight of theirs. (2026-10-01, "위에서 버티면 점프해서 위로 쫓아가게, 지형 이용해서 버티기 못하게")
	-- a player up on something (a crystal, a rock, a tree) within JumpReach studs across and at most
	-- JumpUpHeight up: it jumps up beside them (JumpSeconds in the air, again after JumpCooldown).
	-- A chaser that runs into something gets a path round it (PathfindingService): at most PathsPerTick
	-- new paths a tick, each zombie at most every RepathSeconds, a new one when its target moved
	-- RepathMove studs from the path's end
	StepHeight = 2,
	HitHeight = 6,
	JumpUpHeight = 40, -- (the tallest battlefield trees are about 30)
	JumpReach = 14,
	JumpSeconds = 0.5,
	JumpCooldown = 2,
	PathsPerTick = 4,
	RepathSeconds = 1,
	RepathMove = 6,
	PathWaypointSpacing = 4,
	-- the night's boss: one giant zombie dino somewhere on the battlefield each night. Players slap it
	-- down together (a slap near it hits it instead of a player); down, it drops a pile of treasure
	-- chests around where it fell (anyone opens them; each pays at the opener's own defense level)
	Boss = {
		-- (2026-10-01) a giant steps over more, reaches and jumps higher (its HitHeight × its size ÷ the
		-- base size for Roar and Charge). 임시값
		StepHeight = 6,
		HitHeight = 10,
		JumpUpHeight = 50,
		JumpReach = 22,
		-- its look by the players on the server at nightfall (the last one with MinPlayers or fewer)
		-- (2026-10-04: its health and chests no longer by these stages, see HealthPerPlayer; was 50 / 112 / 200 health
		-- and 4 / 7 / 10 chests) 임시값
		Stages = {
			{ MinPlayers = 1, Prefix = "", Scale = 2.2 },
			{ MinPlayers = 3, Prefix = "큰 ", Scale = 2.6 },
			{ MinPlayers = 6, Prefix = "왕 ", Scale = 3.0 },
		},
		-- (2026-10-04, "보스들 인원수에 맞춰서 난이도 조절되어 나오게 하자 지금 혼자인데 보스를 잡을 수가 없네. 난이도는
		-- 체력을 말하는거. 물론 그만큼 보상도 적어지고": alone it had 50, a level-1 slap takes 1 while it throws you about)
		-- health = HealthPerPlayer × the players on the server (Formulas.bossHealth), kept so while it is up: one joins,
		-- it grows, one leaves, it shrinks (the share of health left stays). Each hitter's reward (HitterReward, the
		-- aurora boss's too) × the players ÷ RewardFullPlayers (at most 1: full from that many on;
		-- Formulas.bossRewardShare). 임시값
		HealthPerPlayer = 20,
		Chests = 3, -- 임시값
		ChestSeconds = 300, -- 임시값
		RewardFullPlayers = 3,
		-- (2026-10-01) three kinds, one picked at random each night (never the same twice in a row): each
		-- with its own model (tools/dinos.json), its own big attack, its own chests (Chest: "Money" = the
		-- usual treasure, "Keys" = KeyChest, "Minerals" = MineralChest) and, once it is down, its own
		-- buff for the whole server through the next day (Config.DayBuffs)
		Kinds = {
			-- (Species: the living species drawn rotten when its Model is not in ReplicatedStorage.DinoModels)
			{ Id = "Rex", Name = "좀비 티라노", Icon = "🦖", Model = "Dino_ZombieRex", Species = "TRex", Attack = "Roar", Chest = "Money",
				Buff = "Money" },
			{ Id = "Trike", Name = "좀비 트리케라", Icon = "🦕", Model = "Dino_ZombieTrike", Species = "Trike", Attack = "Charge",
				Chest = "Keys",
				Buff = "Defense" },
			{ Id = "Ptera", Name = "좀비 프테라", Icon = "🦅", Model = "Dino_ZombiePtera", Species = "Pteranodon", Attack = "Bomb",
				Chest = "Minerals",
				Buff = "Mining", Hover = 5 }, -- flies low: this many studs over the ground (× its stage Scale ÷ 2.2)
		},
		-- the big attacks (each when someone hittable is within Reach studs, every Every seconds); a hit
		-- throws like the boss's bite (Knockback)
		Roar = { Every = 9, Reach = 30, WindUp = 1.2, Radius = 22 }, -- rears up, then a shockwave all round
		Charge = { Every = 8, Reach = 45, WindUp = 1.0, Distance = 40, Speed = 45, HitRadius = 6 }, -- paws, then charges
		Bomb = { Every = 3.5, Reach = 40, FallSeconds = 1.3, Radius = 7 }, -- drops a big dropping where a player stands
		KeyChest = { Base = 2, PerLevels = 25, Max = 6 }, -- keys: Base + 1 per PerLevels defense levels, at most Max
		MineralChest = { ValueShare = 1.2 }, -- minerals worth this many money chests (at the opener's level) into the bag
		DamagePerLevel = 0.1, -- a slap's damage: 1 + this per slap level above 1
		-- (2026-10-05, "이 파워 인플레에 다른 시스템들도 조절해" "밤보스 같은거") each player brings HealthPerPlayer × (their
		-- slap's damage)^PowerExponent of health (Formulas.bossPower): a strong slapper still ends it sooner, the boss
		-- stays a fight 임시값
		PowerExponent = 0.75,
		-- 임시값 (2026-10-01, "bombs on the boss should pay": was nothing but the chests on the ground, which
		-- anyone opens, so an egg bomb was ~10 times its price lost): every 1 of a boss's health a player takes
		-- pays them this many treasure chests' worth at their own level at once (Formulas.bossHitMoney; the
		-- aurora boss too). A slap (~2) ≈ 0.8 chests; an egg bomb (7 slaps) ≈ 2 × its price
		MoneyPerDamage = 0.4,
		-- studs: a slap this much farther than its reach still hits the big body (× stage Scale ÷ 2.4); 2026-10-03: was 4,
		-- "찰싹으로 보스때리기가 너무 어렵다 범위때문에" — the model's head and tail reach much farther than 4 (its middle) 임시값
		BodyRadius = 7,
		ChestSpread = { 8, 16 }, -- studs from where it fell (a ring, spread out so several players open at once)
		HomeRadius = 40, -- (its own, like below: ZombieLogic reads a zombie's own numbers first)
		ChaseSpeed = 11,
		AggroRange = 45,
		LoseRange = 80,
		HitRange = 9,
		HitCooldown = 2.5,
		Knockback = 22, -- (was 28: threw players too far)
		RiseSeconds = 4.5,
		SinkSeconds = 4,
		-- (2026-10-04, "밤 보스를 잡아야 되는 이유를 모르겠네 … 잡아야 되는 명분이 있으면", then "밤보스는 123 다 되나") what
		-- each player who slapped the night's boss gets once it is down (Zombies service): ① HitterReward at their own
		-- level (KeyHours: hours of Products.KeysPerHour, ~6 minutes of keys), and the one who took the most of its health
		-- MvpReward too when MvpMinHitters or more hit it; ② 🦴 its kind's bones (Bones, the MVP BonesMvp more):
		-- BonesForDino of one kind become that kind's zombie dino (Config.GiftSpecies with BossKind, of BoneDino's rarity
		-- and size) and that kind starts over; the aurora boss gives AuroraBones of every kind; ③ every boss helped down
		-- (the aurora one too) is a hunt: this week's hunts are a 🏆 ranking like the games' (Config.Ranked game "Boss"),
		-- all hunts ever give HuntTitles (over the head, the first reached in Hunts). Not on a tutorial field. 임시값
		HitterReward = { KeyHours = 0.1, MoneyChests = 2 },
		MvpReward = { SpecialKeys = { Silver = 1 } },
		MvpMinHitters = 2,
		Bones = 1,
		BonesMvp = 1,
		BonesForDino = 6,
		BoneDino = { Rarity = "Special", Size = "Big" },
		AuroraBones = 1,
		HuntTitles = {
			{ Hunts = 5, Name = "🧟 좀비 사냥꾼" },
			{ Hunts = 30, Name = "💀 좀비 대장 사냥꾼" },
			{ Hunts = 100, Name = "👑 전설의 좀비 사냥꾼" },
		},
	},
	-- (2026-10-01) the aurora boss: when the aurora lights up the night sky (Config.Weather "Aurora") a far
	-- bigger, far tougher zombie king climbs out somewhere on the battlefield, besides the night's boss. It
	-- uses all three big attacks in turn and more often; slapped down it showers chests of every kind and
	-- everyone who slapped it gets HitterReward at their own level (Rewards.grant). 임시값
	AuroraBoss = {
		Name = "오로라 좀비 킹", Icon = "🌌", Model = "Dino_ZombieRex", Species = "TRex",
		Scale = 4.2,
		-- health = this × the players on the server, kept so while it is up (Formulas.auroraBossHealth; 2026-10-04, like
		-- the night boss's: was 310 + 75 × players, 385 alone; 2026-10-01: 250 + 60 × players)
		HealthPerPlayer = 75,
		Attacks = { "Roar", "Charge", "Bomb" }, -- in turn
		EveryMultiplier = 0.6, -- its big attacks come this much sooner
		Chests = { Money = 2, Keys = 2, Minerals = 2 }, -- 임시값
		-- (2026-10-01, "is the aurora reward too small?": about 0.3 h of money and 66 keys' worth for a rare
		-- whole-server fight) every hitter: Keys + 2 gold keys; its hits pay MoneyPerDamageMultiplier times a
		-- night boss's; the MvpCount who hit it hardest get MvpReward too (a ruby key). 임시값
		HitterReward = { MoneyChests = 6, Keys = 15, SpecialKeys = { Gold = 2 } },
		MoneyPerDamageMultiplier = 2,
		MvpCount = 3, -- (2026-10-04: only when the night boss's MvpMinHitters or more hit it, so never alone)
		MvpReward = { SpecialKeys = { Ruby = 1 } },
		Knockback = 30, ChaseSpeed = 12, AggroRange = 60, LoseRange = 110, HitRange = 12, -- (its own; the rest the boss's)
		RiseSeconds = 6,
		-- (2026-10-01) its plain bite didn't throw players (only its big attacks did: roar, charge, bomb); (2026-10-03,
		-- "그럼 오로라 공룡도 기본공격 가능하게 하자 이제": the slaps reach its body farther now, BodyRadius) it does again
		PlainHitThrows = true,
		-- (2026-10-01) zombie guards climb out with it and keep round it (ordinary zombies: a slap throws
		-- them; they come back to it), and sink when it goes down. 임시값
		Guards = 4,
		GuardRing = 16, -- studs from the boss, spread round it
		GuardHomeRadius = 8, -- they wander only this far from their spot by the boss
	},
	Guardians = { -- 임시값
		Count = { 1, 2, 3, 4, 5, 6, 7, 8 },
		Pool = 8,
		Model = "Dino_ThiefRaptor",
		FallbackModel = "Dino_WildRaptor",
		PostRing = { 36, 44 },
		HomeRadius = 5,
		WanderSpeed = 7,
		ReturnSpeed = 18,
		AggroRange = 120,
		LoseRange = 900,
		ReactSeconds = 0.2,
		ChaseBase = 17,
		ChasePerRarity = 0.4,
		HardFrom = "Mythic",
		HardBase = 24,
		HardGrowth = 1.12,
		ChasePerSize = 0.025,
		ChaseMax = 55,
		HitRange = 4,
		HitCooldown = 3,
		Knockback = 14,
		SlapKnockback = 9,
		SlapFlightSeconds = 0.45,
		SlapStunSeconds = 0.6,
		StepHeight = 3.5,
		StuckSeconds = 1.5,
		UnstickDistance = 8,
		SlapRewindSeconds = 0.4,
		PlazaRadius = 0,
		EdgeMargin = 0,
		RiseSeconds = 2,
		SinkSeconds = 2,
	},
	SuperThief = { -- 임시값
		Model = "Dino_SuperThiefRaptor",
		EverySeconds = { 600, 900 },
		FirstSeconds = 180,
		LifeSeconds = 180,
		SpawnAwayFrom = 70,
		Scale = 1.2,
		ModelScale = 1.6,
		RewindSeconds = 0.75,
		HitSlack = 2,
		-- (2026-10-05, "이 파워 인플레에 다른 시스템들도 조절해") the fastest walker within ChaseRange makes it run
		-- × (their walk speed / ChaseFrom)^ChasePower (at least × 1): a trained-up chaser (walk 64) still has a chase 임시값
		ChaseRange = 60,
		ChaseFrom = 30,
		ChasePower = 0.5,
		Dash = { Range = 20, Multiplier = 1.35, Seconds = 1.5, Cooldown = 4 },
		Keys = {
			{ Grade = "Gold", Weight = 72, Speed = 29 },
			{ Grade = "Ruby", Weight = 22, Speed = 32 },
			{ Grade = "Diamond", Weight = 5, Speed = 35 },
			{ Grade = "Rainbow", Weight = 1, Speed = 38 },
		},
		StuckSeconds = 1.5,
		UnstickDistance = 8,
		SlapRewindSeconds = 1.1,
		Params = {
			HomeRadius = 60,
			WanderSpeed = 12,
			FleeSpeed = 14,
			LoseRange = 900,
			JukeAngle = 30,
			JukeSpeed = 2.5,
			EscapeLook = 25,
			EscapeEdge = 10,
			StepHeight = 3.5,
			PlazaRadius = 8,
			Knockback = 14,
			RiseSeconds = 2,
			SinkSeconds = 2,
		},
	},
}
