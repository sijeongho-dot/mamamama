--[[
Bell: the 🔔 button at the bottom left (over the friends' bonus) rings my bell (Net request RingBell,
the server's Bell service checks the cooldown); the button counts down until it can ring again
(player attribute BellReadyAt). When anyone rings (Net push BellPing), every screen hears the bell
and sees a mark where they stood for Config.Bell.MarkSeconds: a tall blinking light column, a ring on
the ground and "🔔 name" over it, drawn on top and from far away. Each player's bell has a color of its
own (their BellSlot from the server: nobody else in the server has it), on the sleeve, rings and name.
From far away (past FAR_FROM studs) the pillar widens with the distance, so the bell is seen from anywhere on the map
(2026-10-01, "멀리서 확인할 수 있게"; until 2026-10-04 a flat laser drawn over everything did that, "제대로 나오다가 갑자기
저래 선으로 바뀜").
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Unlock = require(Shared:WaitForChild("Unlock"))

local player = Players.LocalPlayer

-- display only
local BUTTON_SIZE = UDim2.fromOffset(48, 48)
local BUTTON_POS = UDim2.new(0, 12, 1, -30) -- its bottom left: the bottom left corner
local COLOR_READY = Color3.fromRGB(240, 190, 60)
local COLOR_WAIT = Color3.fromRGB(110, 110, 120)
local PILLAR_HEIGHT = 400 -- (2026-10-04: was 160, with a laser for afar; now the pillar alone, seen over the hills)
-- (2026-10-04, "알림종 보통 때나 술래잡기때나 좀 많이 커야돼. 거의 제단 반경만큼. 투명도 조금 올려서 내가 썼을 때 내 캐릭터도
-- 보일 정도": the colored sleeve as wide as the key altar (its rim about 12 studs out), the white core 10 wide; both
-- see-through enough to see the ringer inside: were 7 and 14 wide, 0.35 and 0.55 see-through)
local PILLAR_WIDTH = 14 -- (2026-10-04, "알람 빛도 줄기가 제단만해지도록 넓히고": was 10; before: 2.5, then 4.5, "울림 종 빛 광선은 좀좀좀 더 두껍게", "빛기둥 더두껍게", then 7)
local PILLAR_TRANSPARENCY = 0.8 -- ("투명도 조금만 더 올려라": was 0.72)
-- (2026-10-01) a look no other light in the game has: a white neon core in a sleeve of the player's color,
-- blinking, and rings pulsing out on the ground every PULSE_EVERY seconds (key pillars, lamps, pads: steady)
local CORE_COLOR = Color3.fromRGB(255, 255, 255)
local SLEEVE_WIDTH = 36 -- (2026-10-04, "알람 빛도 줄기가 제단만해지도록 넓히고": the key altar's whole width, its rim 18 studs
-- out (tools/make_map.py zone_key_altar 12 × MAP_SCALE 1.5); was 24, before 5, 9, 14)
local SLEEVE_TRANSPARENCY = 0.86 -- (was 0.8)
local BLINK_SECONDS = 0.35
local PULSE_EVERY = 1
local RING_SIZE = 36 -- (the sleeve's width on the ground; was 9, then 24)
local AREA_PULSE = 1.4
local AREA_RING_SEE = 0.55
-- studs (flat) from the camera past which the pillar widens with the distance (as wide on screen from anywhere)
local FAR_FROM = 160
local LABEL_STUDS = Vector2.new(150, 32)
local LABEL_PIXELS = Vector2.new(240, 52)
local LABEL_ABOVE = 80
local FADE_SECONDS = 1.5
-- (2026-10-04, "빛기둥은 일반적으로 보물상자 색이랑 같은 노란색은 유저가 안 쓰게") no yellow nor golden orange: the
-- treasure chests' beams are that color
local COLORS = { -- a bell's color by its slot (1, 2, ...; past the last it starts over), far apart in hue
	Color3.fromRGB(255, 40, 200), -- magenta
	Color3.fromRGB(40, 200, 255), -- sky blue
	Color3.fromRGB(60, 230, 90), -- green
	Color3.fromRGB(255, 90, 40), -- orange red
	Color3.fromRGB(150, 80, 255), -- violet
	Color3.fromRGB(40, 255, 210), -- aqua
	Color3.fromRGB(255, 140, 180), -- pink
	Color3.fromRGB(190, 255, 40), -- lime
	Color3.fromRGB(60, 90, 255), -- blue
	Color3.fromRGB(230, 230, 255), -- white
}

local gui = Instance.new("ScreenGui")
gui.Name = "Bell"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local button = Instance.new("TextButton")
button.Name = "RingBell"
button.AnchorPoint = Vector2.new(0, 1)
button.Size = BUTTON_SIZE
button.Position = BUTTON_POS
button.BackgroundColor3 = COLOR_READY
button.Font = Enum.Font.GothamBold
button.TextSize = 22
button.TextColor3 = Color3.new(1, 1, 1)
button.Text = "🔔"
button.Parent = gui
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0.5, 0)
corner.Parent = button
local function refreshShown()
	button.Visible = Unlock.shown("BellButton")
end
Unlock.watch(refreshShown)
refreshShown()

button.Activated:Connect(function()
	local readyAt = player:GetAttribute("BellReadyAt") or 0
	if Workspace:GetServerTimeNow() >= readyAt then
		Net.request("RingBell")
	end
end)

RunService.Heartbeat:Connect(FrameMeter.wrap("Bell", function()
	local wait = (player:GetAttribute("BellReadyAt") or 0) - Workspace:GetServerTimeNow()
	if wait > 0 then
		button.Text = tostring(math.ceil(wait))
		button.BackgroundColor3 = COLOR_WAIT
	else
		button.Text = "🔔"
		button.BackgroundColor3 = COLOR_READY
	end
end))

local function part(props, parent)
	local p = Instance.new("Part")
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
	p.Material = Enum.Material.Neon
	for k, v in pairs(props) do
		p[k] = v
	end
	p.Parent = parent
	return p
end

local marks = {} -- [userId] = that player's mark now (a new ring replaces it)

-- the ground under where the bell was rung (rung flying or jumping: the pillar still stands on the ground)
local GROUND_LOOK = 600 -- studs down to look
local function groundBelow(position)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true -- (the invisible zone boxes aren't ground)
	local skip = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(skip, p.Character)
		end
	end
	params.FilterDescendantsInstances = skip
	local hit = Workspace:Raycast(position, Vector3.new(0, -GROUND_LOOK, 0), params)
	return hit and hit.Position.Y or position.Y - 3
end

Net.onPush("BellPing", function(userId, position, slot, area)
	local who = Players:GetPlayerByUserId(userId)
	if marks[userId] then
		marks[userId]:Destroy()
	end
	slot = slot or (who and who:GetAttribute("BellSlot")) or userId
	local color = COLORS[(slot - 1) % #COLORS + 1]
	-- my own bell in my ears; another's from where it rang (with the ring every 5 seconds, eight players'
	-- bells all over the map would never stop; the pillar is what shows them from afar)
	Sfx.play("BellRing", userId ~= player.UserId and position or nil)
	local mark = Instance.new("Model")
	mark.Name = "BellMark"
	-- from the ground under the spot up past it (rung in the air: the pillar is that much taller)
	local ground = math.min(groundBelow(position), position.Y - 3)
	local height = position.Y - ground + PILLAR_HEIGHT - 3
	local up = CFrame.new(Vector3.new(position.X, ground + height / 2, position.Z)) * CFrame.Angles(0, 0, math.rad(90))
	local pillar = part({ Name = "Pillar", Shape = Enum.PartType.Cylinder, Size = Vector3.new(height, PILLAR_WIDTH, PILLAR_WIDTH),
		CFrame = up, Color = CORE_COLOR, Transparency = PILLAR_TRANSPARENCY }, mark)
	local sleeve = part({ Name = "Sleeve", Shape = Enum.PartType.Cylinder, Size = Vector3.new(height, SLEEVE_WIDTH, SLEEVE_WIDTH),
		CFrame = up, Color = color, Transparency = SLEEVE_TRANSPARENCY }, mark)
	local blink = TweenInfo.new(BLINK_SECONDS, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true)
	TweenService:Create(pillar, blink, { Transparency = 0.93 }):Play()
	TweenService:Create(sleeve, blink, { Transparency = 0.95 }):Play()
	local ringSize = type(area) == "number" and math.max(RING_SIZE, area * 2) or RING_SIZE
	local ringAt = CFrame.new(Vector3.new(position.X, ground + 0.2, position.Z)) * CFrame.Angles(0, 0, math.rad(90))
	local ring = part({ Name = "Ring", Shape = Enum.PartType.Cylinder, Size = Vector3.new(0.2, ringSize, ringSize),
		CFrame = ringAt, Color = color, Transparency = 0.4 }, mark)
	task.spawn(function() -- a ring pulses out on the ground every PULSE_EVERY seconds while the mark stands
		while mark.Parent do
			task.wait(PULSE_EVERY)
			if not mark.Parent then
				break
			end
			local pulse = part({ Name = "Pulse", Shape = Enum.PartType.Cylinder, Size = Vector3.new(0.2, ringSize, ringSize),
				CFrame = ringAt, Color = color, Transparency = 0.3 }, mark)
			TweenService:Create(pulse, TweenInfo.new(PULSE_EVERY, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
				{ Size = Vector3.new(0.2, ringSize * (area and AREA_PULSE or 3), ringSize * (area and AREA_PULSE or 3)),
					Transparency = 1 }):Play()
			task.delay(PULSE_EVERY, function()
				pulse:Destroy()
			end)
		end
	end)
	local anchor = part({ Name = "LabelAnchor", Size = Vector3.one, Transparency = 1,
		CFrame = CFrame.new(position + Vector3.new(0, LABEL_ABOVE, 0)) }, mark)
	local gui3d = Instance.new("BillboardGui")
	gui3d:SetAttribute("KeepSize", true)
	gui3d.Size = UDim2.new(LABEL_STUDS.X, LABEL_PIXELS.X, LABEL_STUDS.Y, LABEL_PIXELS.Y)
	gui3d.AlwaysOnTop = true
	gui3d.MaxDistance = 100000 -- seen from anywhere on the map
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBold
	text.TextScaled = true
	text.TextColor3 = color
	text.TextStrokeTransparency = 0.2
	text.Text = area and string.format("🔔 %s · 이 근처!", who and who.DisplayName or "누군가")
		or "🔔 " .. (who and who.DisplayName or "누군가")
	text.Parent = gui3d
	gui3d.Parent = anchor
	mark:SetAttribute("Spot", position)
	mark.Parent = Workspace
	marks[userId] = mark
	-- the ring swells out once, then everything fades at the end
	TweenService:Create(ring, TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{ Size = area and Vector3.new(0.2, ringSize, ringSize) or Vector3.new(0.2, RING_SIZE * 2, RING_SIZE * 2),
			Transparency = area and AREA_RING_SEE or 0.7 }):Play()
	task.delay(Config.Bell.MarkSeconds - FADE_SECONDS, function()
		local fade = TweenInfo.new(FADE_SECONDS)
		TweenService:Create(pillar, fade, { Transparency = 1 }):Play()
		TweenService:Create(sleeve, fade, { Transparency = 1 }):Play()
		TweenService:Create(ring, fade, { Transparency = 1 }):Play()
		TweenService:Create(text, fade, { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
		mark:SetAttribute("Fading", true)
		task.delay(FADE_SECONDS, function()
			mark:Destroy()
			if marks[userId] == mark then
				marks[userId] = nil
			end
		end)
	end)
end)

-- (2026-10-04, "제대로 나오다가 갑자기 저래 선으로 바뀜": from afar a flat screen laser took the pillar's place, a sudden
-- thin line of another look) one pillar always: past FAR_FROM studs it widens with the distance, so it stays about as wide
-- on screen as it was there, seen from anywhere on the map
RunService.RenderStepped:Connect(FrameMeter.wrap("Bell", function()
	local eye = Workspace.CurrentCamera.CFrame.Position
	for _, mark in pairs(marks) do
		local spot = mark:GetAttribute("Spot")
		local pillar, sleeve = mark:FindFirstChild("Pillar"), mark:FindFirstChild("Sleeve")
		if spot and pillar and sleeve then
			local k = math.max(1, (Vector3.new(spot.X, eye.Y, spot.Z) - eye).Magnitude / FAR_FROM)
			if math.abs(k - (mark:GetAttribute("Widen") or 1)) > 0.06 then -- (resized only when it changed a little)
				mark:SetAttribute("Widen", k)
				pillar.Size = Vector3.new(pillar.Size.X, PILLAR_WIDTH * k, PILLAR_WIDTH * k)
				sleeve.Size = Vector3.new(sleeve.Size.X, SLEEVE_WIDTH * k, SLEEVE_WIDTH * k)
			end
		end
	end
end))
