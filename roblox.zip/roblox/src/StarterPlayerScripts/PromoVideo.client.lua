local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local StarterGui = game:GetService("StarterGui")
local TextChatService = game:GetService("TextChatService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))

local player = Players.LocalPlayer

local ZOOM_SECONDS = 1.2
local FAR = { Radius = 80, Up = 40 }
local NEAR = { Radius = 26, Up = 11 }
local ARENA_NEAR = { Radius = 55, Up = 30 }
local SKY_NEAR = { Radius = 34, Up = 6 }
local SKY_SMOOTH = 4
local VIEW_TRIES = 16
local VIEW_SAMPLES = 4
local VIEW_SEE_THROUGH = 0.5
local ORBIT_SPEED = 0.12
local PUSH_IN = 0.04
local TARGET_SMOOTH = 1.5
local LOOK_UP = 2.5
local FLASH_SECONDS = 0.25
local FOV_PUNCH = { 82, 70 }

local gui = Instance.new("ScreenGui")
gui.Name = "PromoVideo"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.DisplayOrder = 100
gui.Enabled = false
gui.Parent = player:WaitForChild("PlayerGui")
local flash = Instance.new("Frame")
flash.Size = UDim2.fromScale(1, 1)
flash.BackgroundColor3 = Color3.new(1, 1, 1)
flash.BackgroundTransparency = 1
flash.BorderSizePixel = 0
flash.Parent = gui

local running = false
local hidden = {}
local oldType, oldFov, oldBubbles = nil, nil, nil
local current = nil

local function fakeMiddle()
	local folder = Workspace:FindFirstChild("FakePlayers")
	local sum, n = Vector3.zero, 0
	for _, m in ipairs(folder and folder:GetChildren() or {}) do
		local root = m:IsA("Model") and (m:FindFirstChild("HumanoidRootPart") or m.PrimaryPart)
		if root then
			sum += root.Position
			n += 1
		end
	end
	return n > 0 and sum / n or nil
end

local function setMine(transparent)
	local character = player.Character
	for _, d in ipairs(character and character:GetDescendants() or {}) do
		if d:IsA("BasePart") or d:IsA("Decal") then
			d.LocalTransparencyModifier = transparent and 1 or 0
		end
	end
end

local function nearOf(kind)
	return kind == "Arena" and ARENA_NEAR or kind == "Sky" and SKY_NEAR or NEAR
end

local function clearView(from, to)
	local skip = { Workspace:FindFirstChild("FakePlayers") }
	for _, p in ipairs(Players:GetPlayers()) do
		table.insert(skip, p.Character)
	end
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	for _ = 1, 6 do
		params.FilterDescendantsInstances = skip
		local hit = Workspace:Raycast(from, to - from, params)
		if not hit then
			return true
		end
		if hit.Instance.Transparency < VIEW_SEE_THROUGH then
			return false
		end
		table.insert(skip, hit.Instance)
	end
	return true
end

local function openAngle(target, kind, seconds)
	local near = nearOf(kind)
	local look = target + Vector3.new(0, LOOK_UP, 0)
	local start = math.random() * 2 * math.pi
	local best, bestScore = start, -1
	for i = 0, VIEW_TRIES - 1 do
		local a0 = start + i / VIEW_TRIES * 2 * math.pi
		local score = 0
		for k = 0, VIEW_SAMPLES do
			local a = a0 + ORBIT_SPEED * (seconds or 0) * k / VIEW_SAMPLES
			for _, r in ipairs({ { near.Radius, near.Up }, { (near.Radius + FAR.Radius) / 2, (near.Up + FAR.Up) / 2 },
				{ FAR.Radius, FAR.Up } }) do
				local eye = target + Vector3.new(math.cos(a) * r[1], r[2], math.sin(a) * r[1])
				if clearView(look, eye) then
					score += 1
				end
			end
		end
		if score > bestScore then
			best, bestScore = a0, score
		end
	end
	return best
end

local function step(dt)
	local s = current
	if not s then
		return
	end
	setMine(true)
	local camera = Workspace.CurrentCamera
	local raw = (s.kind ~= "Altar" and s.kind ~= "Arena" and fakeMiddle()) or s.at or fakeMiddle() or s.target
	if raw then
		local smooth = s.kind == "Sky" and SKY_SMOOTH or TARGET_SMOOTH
		s.target = s.target and s.target:Lerp(raw, 1 - math.exp(-dt * smooth)) or raw
	end
	if not s.target then
		return
	end
	local now = os.clock()
	local t = math.clamp((now - s.start) / ZOOM_SECONDS, 0, 1)
	local q = 1 - (1 - t) ^ 5
	local near = nearOf(s.kind)
	local angle = s.angle + (now - s.start) * ORBIT_SPEED
	local push = 1 - math.min(0.35, math.max(0, now - s.start - ZOOM_SECONDS) * PUSH_IN)
	local radius = (FAR.Radius + (near.Radius - FAR.Radius) * q) * push
	local up = FAR.Up + (near.Up - FAR.Up) * q
	local eye = s.target + Vector3.new(math.cos(angle) * radius, up, math.sin(angle) * radius)
	camera.CFrame = CFrame.lookAt(eye, s.target + Vector3.new(0, LOOK_UP, 0))
end

local function begin()
	if running then
		return
	end
	running = true
	player:SetAttribute("Cinematic", true)
	hidden = {}
	for _, g in ipairs(player.PlayerGui:GetChildren()) do
		if g:IsA("ScreenGui") and g.Enabled and g ~= gui then
			g.Enabled = false
			table.insert(hidden, g)
		end
	end
	pcall(function()
		StarterGui:SetCore("TopbarEnabled", false)
	end)
	pcall(function()
		oldBubbles = TextChatService.BubbleChatConfiguration.Enabled
		TextChatService.BubbleChatConfiguration.Enabled = false
	end)
	local camera = Workspace.CurrentCamera
	oldType, oldFov = camera.CameraType, camera.FieldOfView
	camera.CameraType = Enum.CameraType.Scriptable
	gui.Enabled = true
	RunService:BindToRenderStep("PromoVideo", Enum.RenderPriority.Camera.Value + 2, step)
end

local function finish()
	if not running then
		return
	end
	running = false
	player:SetAttribute("Cinematic", nil)
	current = nil
	RunService:UnbindFromRenderStep("PromoVideo")
	setMine(false)
	for _, g in ipairs(hidden) do
		if g.Parent then
			g.Enabled = true
		end
	end
	hidden = {}
	pcall(function()
		StarterGui:SetCore("TopbarEnabled", true)
	end)
	pcall(function()
		if oldBubbles ~= nil then
			TextChatService.BubbleChatConfiguration.Enabled = oldBubbles
		end
	end)
	local camera = Workspace.CurrentCamera
	camera.CameraType = oldType or Enum.CameraType.Custom
	camera.FieldOfView = oldFov or 70
	gui.Enabled = false
end

local function cut()
	flash.BackgroundTransparency = 0
	TweenService:Create(flash, TweenInfo.new(FLASH_SECONDS), { BackgroundTransparency = 1 }):Play()
	local camera = Workspace.CurrentCamera
	camera.FieldOfView = FOV_PUNCH[1]
	TweenService:Create(camera, TweenInfo.new(ZOOM_SECONDS, Enum.EasingStyle.Quint, Enum.EasingDirection.Out),
		{ FieldOfView = FOV_PUNCH[2] }):Play()
end

Net.onPush("PromoShot", function(kind, seconds, at)
	if kind == "End" then
		finish()
		return
	end
	begin()
	cut()
	local fixed = typeof(at) == "Vector3" and at or nil
	local target = fixed or fakeMiddle()
	current = { kind = kind, start = os.clock(), at = fixed, target = target,
		angle = target and openAngle(target, kind, seconds) or math.random() * 2 * math.pi }
end)
