local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Lang = require(Shared:WaitForChild("Lang"))
local Net = require(Shared:WaitForChild("Net"))
local Prices = require(Shared:WaitForChild("Prices"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

local FONT = Enum.Font.GothamBold
local SIZE = Vector2.new(360, 210)
local COLOR_BG = Color3.fromRGB(40, 24, 34)
local COLOR_STROKE = Color3.fromRGB(255, 110, 130)
local COLOR_BUY = Color3.fromRGB(235, 70, 100)
local COLOR_FREE = Color3.fromRGB(70, 180, 90)
local COLOR_NO = Color3.fromRGB(90, 95, 110)
local BUTTON_H = 46

local gui = Instance.new("ScreenGui")
gui.Name = "PromoRevive"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.DisplayOrder = 9
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Name = "PromoRevive"
frame.AnchorPoint = Vector2.new(0.5, 0.5)
frame.Position = UDim2.fromScale(0.5, 0.5)
frame.Size = UDim2.fromOffset(SIZE.X, SIZE.Y)
frame.BackgroundColor3 = COLOR_BG
frame.Visible = false
frame.Parent = gui
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 16)
corner.Parent = frame
local stroke = Instance.new("UIStroke")
stroke.Color = COLOR_STROKE
stroke.Thickness = 3
stroke.Parent = frame

local function label(text, size, y, h)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = size
	l.TextWrapped = true
	l.Size = UDim2.new(1, -24, 0, h)
	l.Position = UDim2.fromOffset(12, y)
	l.Text = text
	l.Parent = frame
	return l
end
local title = label("", 22, 12, 34)
local line = label("", 15, 50, 44)

local function button(color, x)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 16
	b.TextColor3 = Color3.new(1, 1, 1)
	b.BackgroundColor3 = color
	b.Size = UDim2.new(0.5, -18, 0, BUTTON_H)
	b.Position = UDim2.new(x, x == 0 and 12 or 6, 1, -BUTTON_H - 14)
	b.Parent = frame
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 10)
	c.Parent = b
	return b
end
local buy = button(COLOR_BUY, 0)
local no = button(COLOR_NO, 0.5)
Windows.fit(frame)

local free = false

local function close()
	frame.Visible = false
end

local function priceText()
	if free then
		Lang.set(buy, "🎁 무료로 이어하기")
	else
		Lang.set(buy, string.format("❤️ 이어하기 R$%d", Prices.get(Config.Monetization.ProductIds.PromotionRevive or 0, false,
			Config.Products.PromotionRevive.Robux)))
	end
end
Prices.onChanged(function()
	if frame.Visible then
		priceText()
	end
end)

buy.Activated:Connect(function()
	if free then
		Net.request("PromoReviveFree")
		return
	end
	local id = Config.Monetization.ProductIds.PromotionRevive or 0
	if id > 0 then
		MarketplaceService:PromptProductPurchase(player, id)
	elseif RunService:IsStudio() then
		Net.request("StudioBuy", "PromotionRevive")
	end
end)
no.Activated:Connect(function()
	Net.request("PromoReviveNo")
	close()
end)

Net.onPush("PromoReviveOffer", function(gained, isFree)
	free = isFree == true
	Lang.set(title, "💔 ❤️를 다 잃었어요")
	Lang.set(line, string.format("⏸️ 싸움이 멈췄어요 · ❤️ %d개로 이어서 할 수 있어요", tonumber(gained) or 0))
	Lang.set(no, "🏳️ 그만하기")
	buy.BackgroundColor3 = free and COLOR_FREE or COLOR_BUY
	priceText()
	frame.Visible = true
	Sfx.play("PromotionFail")
end)

player:GetAttributeChangedSignal("PromoLives"):Connect(function()
	if frame.Visible and (player:GetAttribute("PromoLives") or 0) > 0 then
		close()
	end
end)
player:GetAttributeChangedSignal("PromoLevel"):Connect(function()
	if not player:GetAttribute("PromoLevel") then
		close()
	end
end)

