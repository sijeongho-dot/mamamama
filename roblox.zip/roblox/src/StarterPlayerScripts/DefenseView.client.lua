--[[
DefenseView: draws the monsters on every running defense track and the dinos' attacks (display
only; the server's Defense service decides every hit).

The server sends a monster's distance s along the track and its speed v at a server time, and
again only when that speed changes (DefenseEvents: S spawn, M speed, H health, D died, A attack,
C base cleared). Between events this script moves each monster on by itself:
s(now) = s + v × (now − that time), along the base's map road (base folder attribute DefenseMap, Formulas.lanePath)
in the arena frame (base folder attribute ArenaFrame, -Z toward the spawn portal). (2026-10-06) "L": one went out
through the end gate (a puff, and "❤️ -1" over it on my own fight); 🚩 group fossils carry their group's icon, the
flag-bearer drawn bigger with a 🚩; "G": a whole group beaten.

Only bases near the camera get models; health bars show on the player's own base. The player's
settings (attributes HideMyDinos, HideMyFossils, HideOtherDinos, HideOtherFossils, from the Settings
service) hide the dinos or fossils of their own track or of the others' tracks, to cut lag.
Monsters and the dinos on the platforms move their legs, neck, head and tail with Shared/DinoMotion
(walking at their speed, standing when frozen, a lunge when a dino attacks).

Sounds (Shared/Sfx), only for tracks within HEAR_DISTANCE of the camera and never more than a few a
second per track: each attack by its kind (a bite, a stomp, a diving swoop, a splash; now and then the
dino's own voice with it), bone knocks on hits, bones clattering apart when a fossil dies, the walking
fossils rattling, and a roar when the promotion boss comes. The dinos standing on the platforms and in
the farm pens also growl now and then, each species in its own voice (Shared/DinoVoices).

The farm dinos walk round their pen (the FarmGrass folder's PenCFrame / PenSize): mostly to one of
the grass clumps, where they put their heads down and graze for a while (DinoMotion.graze), now and then
to a random spot to stand and look around.

Chatter: now and then (CHAT_EVERY) one of those dinos near the camera says a random line in a speech
bubble for a few seconds, one dino at a time: a battle line while fossils are on its track, a line
of its theme (육식, 초식, ...), a farm line in the pens, or a general one (CHAT_LINES).

(2026-10-02, "디펜스 전략의 재미") Fossil kinds (Config.Defense.Kinds: 💨 fast, 🛡️ armored, 🐜 swarm) are drawn at
their Scale, their body tinted toward their Rgb, with their icon (and the attribute they shrug off) over them. A
combo (A event's 5th value: "Shock" 감전 = 물+전기, "Freeze" 빙결 = 물+얼음) pops its name over the fossil.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TextService = game:GetService("TextService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))
local DefensePack = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("DefensePack"))
local DinoMotion = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("DinoMotion"))
local Lod = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Lod"))
local RarityFx = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("RarityFx"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))
local Sfx = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Sfx"))
local Fx = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Fx")) -- (2026-10-04: a fossil breaking apart)
local DinoVoices = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("DinoVoices"))

local player = Players.LocalPlayer

-- display only
local TRACK_TOP = 0.15 -- Base_Arena: the sand track above the model's bottom (tools/make_map.py 0.1 × 1.5)
local MONSTER_DRAW_SCALE = 1.3 -- fossils drawn bigger (the dinos are 1.5)
local POP_SECONDS, POP_RISE, POP_START = 1, 4, 3 -- the "+money" over a killed fossil
local POP_PER_SECOND = 12 -- at most this many a second (a big wave would flood the screen)
local POP_COLOR = Color3.fromRGB(255, 220, 80)
local FIELD_REACH = 55 -- studs from an arena's middle to its field's far corner (the roads lie within)
local KIND_TINT = 0.65 -- a special fossil's body: this far from its level color toward its kind's color
local COMBO_GAP = 0.6 -- seconds between two combo labels on one track (a wet crowd would flood the screen)
local COMBO_SECONDS, COMBO_RISE = 1.1, 5
local COMBO_SIZE = UDim2.fromOffset(130, 34)
local LEAK_COLOR = Color3.fromRGB(255, 90, 90)
local AIRSHIP = { Lift = 4, Balloon = 9, String = 0.15, Gap = 1.5, Color = Color3.fromRGB(200, 120, 230) }
-- (2026-10-06) what a special fossil wears and the bearer's flag (tools/make_td.py): its bottom at this × the fossil's height
local WEAR_LIFTS = { Kind_Shell = 0.18, Kind_Stone = 0.36, Kind_Frost = 0.388, Kind_Lava = 0.28, Prop_FossilFlag = 0.55,
	Kind_Doll = 0.05, Kind_Sprinter = 0.343 }
local GROUP_LOOK = { "🚩 무리 격파!", Color3.fromRGB(255, 220, 90) }
local LEAK_COLORS = { Color3.fromRGB(235, 75, 70), Color3.fromRGB(255, 180, 120) }
local COACH = { Every = 0.3, Danger = 0.7, Near = 14, Crowd = 6, MarkSize = UDim2.fromScale(8, 2.6), MarkUp = 3.5,
	MarkColor = Color3.fromRGB(255, 95, 70), Bounce = 0.7, Speed = 6, GlowColor = Color3.fromRGB(255, 225, 80),
	GlowThickness = 3, GlowSpeed = 8 }
local COMBO_LOOKS = { -- (combo -> text, color)
	Shock = { "⚡💧 감전!", Color3.fromRGB(255, 240, 90) },
	Freeze = { "❄️💧 빙결!", Color3.fromRGB(150, 225, 255) },
}
-- (2026-10-03, "속성공격 공룡마다 화석에 적용시키게 만들어 껍데기만 있네 … 모든 속성 공격 맞은 화석 모델링 해") what an
-- attribute hit leaves on a fossil while it lasts (DefenseModels.Status_*, tools/make_status.py): Model, its bottom at
-- Lift × the fossil's height, see-through, and how long the brief ones show (the others: their Config.Attributes time)
local STATUS_LOOKS = {
	Snow = { Model = "Status_Snow", Lift = 0.74 }, -- ❄️ slowed
	IceBlock = { Model = "Status_IceBlock", Lift = -0.04, Transparency = 0.4 }, -- ❄️ frozen (until it walks again)
	Flame = { Model = "Status_Flame", Lift = 0.55, Transparency = 0.05 }, -- 🔥 burning
	Wet = { Model = "Status_Wet", Lift = 0, Transparency = 0.15 }, -- 💧 wet
	Poison = { Model = "Status_Poison", Lift = 0.42 }, -- ☠️ poisoned
	Spark = { Model = "Status_Spark", Lift = 0, Seconds = 0.6 }, -- ⚡ shocked
	Rocks = { Model = "Status_Rocks", Lift = -0.02, Seconds = 0.8 }, -- ⛰️ an earth hit
	Crack = { Model = "Status_Crack", Lift = 0.45, Seconds = 0.5 }, -- ⚪ a plain hit
}
local STATUS_OF = { Water = "Wet", Ice = "Snow", Fire = "Flame", Poison = "Poison", Electric = "Spark", Earth = "Rocks",
	Neutral = "Crack" }
local STATUS_REF_HEIGHT = 3 -- studs: the looks are made for a fossil this tall (tools/make_status.py)
local STATUS_MAX = 60 -- looks at once on one track (a big wave would cost too much)
local RAINBOW_SECONDS = 3 -- one turn of a rainbow-rarity ring's colors
local UNIT_FOLDERS = { "DefenseUnits", "FarmUnits" } -- placed dinos and farm dinos (Farm)
local DRAW_DISTANCE = 300 -- bases farther than this from the camera get no monster models
local TOP_VIEW_SEE_THROUGH = 0.6
local LIGHT_DRAW_DISTANCE = 140 -- (2026-10-04, "지연도 확실히 해결해") ... in 🍃 light mode (player attribute LightMode)
-- (2026-10-02, "진행중인 남의 기지 들어갔는데 서버지연 걸렸어": coming near a busy track made all of its up to
-- 120 fossil models in one frame, a long freeze on a phone that also held up its answers to the server)
-- fossil models are made a few a frame, the player's own track first
local MODELS_PER_FRAME = 6
local ANIM_DISTANCE = 160 -- bases farther than this slide their monsters and dinos without moving legs
-- (2026-10-06, "렉이 많이 있는데") a late fight brings 300 fossils to a road: only those within FOSSIL_ANIM_NEAR of the
-- camera move their legs, at most FOSSIL_ANIM_MAX a frame (the rest slide, as on a far base)
local FOSSIL_ANIM_NEAR = 80
local FOSSIL_ANIM_MAX = 40
local AURA_DISTANCE = 120 -- dinos farther than this from the camera show no rarity lights or particles
local UNIT_CHECK_EVERY = 0.5
local GLIDE = { Seconds = 0.8, Hop = 1.5, Speed = 16 }
local TROT_HOP = 0.35 -- studs a walking fossil bobs up each stride
local TROT_HOP_SPEED = 9 -- radians a second (two hops a stride)
local TROT_SWAY = 0.5 -- studs it weaves to each side
local TROT_SWAY_SPEED = 2.2
local BAR_MAX_DISTANCE = 90
local TOP_VIEW_LABEL_DISTANCE = 2000
local FARM_WALK_SPEED = 3 -- studs a second, strolling round the pen
local FARM_TURN = 4 -- how fast a farm dino turns toward where it goes
local FARM_SIZE_REFERENCE = 3 -- studs tall: dinos taller than this walk faster (their legs are longer) ...
local FARM_SPEED_MAX = 3 -- ... up to this many times FARM_WALK_SPEED
local FARM_GRASS_CHANCE = 0.7 -- the next stop is a grass clump (else a random spot)
local FARM_GRAZE_SECONDS = { 4, 9 }
local FARM_IDLE_SECONDS = { 1.5, 4 }
-- (2026-10-02) a storm bolt beside a farm dino (Net push Lightning): it hops away and yelps
local JOLT_STUDS, JOLT_HEIGHT, JOLT_SECONDS = 4, 2, 0.45
local YELP_PITCH = 1.5 -- × its own voice's: a short high cry
local FARM_MOUTH_REACH = 0.4 -- × the dino's length: how far from the clump it stands to eat it
-- the placed dinos come alive on their spot: they turn toward the fossil they bite (and the nearest
-- one coming), look about when the track is empty, shuffle a step now and then and roar when they growl
local DEFENSE_TURN = 5 -- how fast a placed dino turns (per second, toward its wanted facing)
local DEFENSE_TURN_MAX = math.rad(75) -- the most it turns away from its spot's facing
local DEFENSE_LOOK_EVERY = { 2.5, 5 } -- seconds between glances while nothing is near
local DEFENSE_LOOK_ANGLE = math.rad(35) -- how far a glance turns
local DEFENSE_WATCH_RANGE = 30 -- studs: a fossil this near is watched
local DEFENSE_FACE_SECONDS = 0.9 -- after a bite it keeps facing the bitten fossil this long
local DEFENSE_STEP_EVERY = { 5, 11 } -- seconds between shuffles
local DEFENSE_STEP = 0.7 -- studs at most from its spot (it never wanders off the platform)
local DEFENSE_STEP_SPEED = 2.5 -- studs a second while shuffling (the legs walk)
-- (2026-10-04, "디펜스에 보는 맛이 없는데.... 이펙트가 뭔가 더 해줘야할거 같은데", "더 크게 이펙트를놔준다든") the attack
-- line thicker and a little longer (was 0.25 wide, 0.12 s), a glowing pop where each hit lands, a bone burst on a death
local FX_SECONDS = 0.18
local FX_WIDTH = 0.6
local IMPACT_SECONDS = 0.28 -- a hit's pop: a glowing ball in the attribute's color growing and fading
local IMPACT_FROM, IMPACT_TO = 0.8, 4 -- studs across
local IMPACT_TRANSPARENCY = 0.2
local IMPACT_MAX = 3 -- pops for one attack at most (the first fossils it hits)
local IMPACT_POOL_MAX = 40
local DEATH_COLORS = { Color3.fromRGB(245, 240, 225), Color3.fromRGB(200, 185, 150) } -- bone chips
local DEATH_BURST = { count = 14, speed = 20, size = 0.6, life = 0.6 } -- a fossil breaking
local BOSS_DEATH_BURST = { count = 60, speed = 40, size = 1.2, life = 1.1 } -- a boss breaking
local DEATH_FLASH, BOSS_DEATH_FLASH = 2, 6 -- the white pop's size (× IMPACT_TO) on a death
local LINE_POOL_MAX = 80 -- (2026-10-04) attack lines' parts kept to use again
-- (2026-10-03, "속성마다 다른 공격 방식") a fire / ice / water blast: a flat ring growing to its radius and fading; a
-- poison pool: a purple puddle for its seconds (at most POOL_MAX on one track)
local BURST_SECONDS = 0.5 -- (2026-10-04, "더 크게 이펙트를": was 0.35, 0.08 thick, 0.35 see-through)
local BURST_THICKNESS = 0.25
local BURST_TRANSPARENCY = 0.15
local WAVE = { Seconds = 0.9, Thickness = 0.6, Color = Color3.fromRGB(90, 180, 255), Transparency = 0.25, Up = 0.6 }
local POOL_COLOR = Color3.fromRGB(150, 60, 210) -- (the plain disc, without the Fx_PoisonPool model)
local POOL_TRANSPARENCY = 0.35
local POOL_MODEL_TRANSPARENCY = 0.1 -- the puddle model (2026-10-03, "바닥에 남는 모델이 돼 있나")
local POOL_THICKNESS = 0.06
local POOL_UP = 0.05 -- studs over the track
local POOL_MAX = 16
local GREY_MONSTER = Vector3.new(1.6, 2.4, 2.6)
local STAND_IN_RETRY = 1
local BOSS_LABEL_SIZE = UDim2.fromOffset(150, 34)
local CROWN_ABOVE_HEAD = 0.08 -- × the boss's height
local LEVEL_COLORS = { -- Config.Monsters.Colors: 초록 청록 파랑 남색 보라 분홍 빨강 주황 노랑 흰색
	Color3.fromRGB(110, 190, 90), Color3.fromRGB(70, 190, 180), Color3.fromRGB(70, 130, 230),
	Color3.fromRGB(60, 70, 160), Color3.fromRGB(140, 80, 200), Color3.fromRGB(235, 120, 180),
	Color3.fromRGB(220, 60, 60), Color3.fromRGB(240, 140, 50), Color3.fromRGB(240, 210, 60),
	Color3.fromRGB(235, 235, 235),
}
local ATTRIBUTE_COLORS = {
	Ice = Color3.fromRGB(150, 220, 255), Fire = Color3.fromRGB(255, 120, 40), Electric = Color3.fromRGB(255, 235, 60),
	Poison = Color3.fromRGB(170, 80, 220), Earth = Color3.fromRGB(160, 110, 60), Water = Color3.fromRGB(60, 140, 255),
	Neutral = Color3.fromRGB(255, 255, 255),
}

-- sounds
local HEAR_DISTANCE = 110 -- tracks farther than this from the camera are not heard
local ATTACK_SOUNDS = { SingleTarget = "DinoBite", AreaAround = "DinoStomp", PiercingLine = "DinoSwoop", Splash = "DinoSplash" }
-- (2026-10-03, "디펜스 공룡들 효과음 볼륨 줄여. 특히 번개음같은거") the fight's sounds this much as loud as elsewhere: the
-- sharp ones (a bite's slash and a flyer's swoop, the "zap" of every few seconds) most of all
-- (2026-10-03, "디펜스 공룡들 소리 이번엔 너무 작아": were 0.3 / 0.45 / 0.55 / 0.75 / 0.6, steps 0.5; then "디펜스 속성
-- 소리 너무 작다고": were 0.55 / 0.5 / 0.75 / 0.8 / 0.9 / 0.85) the attacks at full again, the swoop a little under
local DEFENSE_GAIN = { DinoBite = 1, DinoSwoop = 0.85, DinoStomp = 1, DinoSplash = 1, BoneHit = 1,
	BoneBreak = 1, BossRoar = 1, Voice = 1 }
-- (2026-10-03, "농장에서 으르렁 모션하는 공룡들 왜 으르렁 소리 안 내": the growl played at the voice's own quiet level from
-- a pen tens of studs away, barely heard) an idle growl (the platforms' and the pens') this much louder
local GROWL_GAIN = 2
-- (2026-10-04, "빙속성 속성공격 소리가 넘 크다") a dino's attack sound × this by its attribute (1 when not listed)
local ATTRIBUTE_GAIN = { Ice = 0.5 }
-- (2026-10-04, "번개는 소리도 안나네 속성공격", "사운드너무 크게 넣지말고") an attribute's own sound over the attack's, soft
local ATTRIBUTE_SOUNDS = { Electric = "ElecZap", Fire = "FireWhoosh", Ice = "IceCrack", Water = "WaterDrop",
	Poison = "PoisonBubble", Earth = "EarthThud" } -- (2026-10-04, "모든 속성 공격사운드 다존재하나?": all of them)
local ATTRIBUTE_SOUND_GAIN = 0.75
local DEFENSE_STEP_GAIN = 0.7 -- the platform and farm dinos' footfalls and wingbeats (Shared/DinoMotion soundGain)
local PER_SECOND = { attack = 6, hit = 5, death = 4, voice = 3, impact = 14, deathFx = 8 } -- per track, so a big wave
-- does not roar (impact, deathFx: the pops and bursts drawn, 2026-10-04)
local ATTACK_VOICE_CHANCE = 0.4 -- (was 0.12) an attack often comes with the dino's own roar or call
local BONE_STEP_EVERY = 0.22 -- seconds between rattles of the walking fossils on a heard track
local GROWL_EVERY = { 8, 20 } -- seconds between one dino's idle growls
local GROWL_DISTANCE = 90 -- only dinos this close to the camera growl
local GROWL_GAP = 1.2 -- seconds between any two idle growls (not a choir)

-- chatter: now and then a placed or farm dino says a line in a speech bubble
local CHAT_EVERY = { 18, 45 } -- seconds between one dino's lines
local CHAT_DISTANCE = 80 -- only dinos this close to the camera talk
local CHAT_GAP = 2.5 -- seconds between any two lines (one at a time, not a crowd)
local CHAT_SECONDS = 3.5 -- how long a bubble stays
-- (2026-10-02, "자막 크기 괜찮은거야?": a fixed 170 × 44 box with the text filling it made a short "Grrr…"
-- huge) the words at one size, the bubble fitted round them
local CHAT_TEXT_SIZE = 15
local CHAT_MAX_WIDTH = 190 -- longer lines wrap
local CHAT_PAD = Vector2.new(10, 5)
local CHAT_ABOVE = 2.5 -- studs over the dino's head
local CHAT_BG = Color3.fromRGB(255, 255, 255)
local CHAT_TEXT = Color3.fromRGB(40, 40, 50)
-- (2026-10-02, "다른 날씨들엔 디펜스 공룡까지 포함해서 그에 맞는 대사들을") in a weather, half the lines are about it
local WEATHER_CHAT_SHARE = 0.5
local WEATHER_CHAT = {
	Clear = { "날씨 좋다~ ☀️", "햇볕 따뜻해", "산책하기 딱 좋아!" },
	Rain = { "비 온다! ☔", "빗물 시원해~", "젖어도 안 져!", "웅덩이에서 첨벙!" },
	Storm = { "번개 무서워! ⚡", "쾅! 깜짝이야!", "천둥 소리 너무 커…", "꼭 붙어 있자!" },
	RainbowSky = { "무지개다! 🌈", "소원 빌자!", "알록달록 예뻐~", "오늘은 운이 좋을 거야!" },
	Aurora = { "하늘이 춤춘다! 🌌", "초록빛 너무 예뻐…", "오로라 좀비 킹이 온대!", "밤하늘 최고~" },
}
local CHAT_LINES = {
	Any = { "오늘도 기지는 내가 지킨다!", "주인님 최고! 💕", "졸려… 💤", "크아앙!", "강화해 주면 더 세질 텐데…",
		"옆 친구, 자리 좀 비켜 줄래?", "배고프다… 🍖", "화석 녀석들 다 덤벼!", "여기 경치 좋다~", "나 오늘 좀 멋진 듯 😎",
		"열쇠 많이 모아 와!", "심심해… 놀아 줘!", "으랏차차! 💪", "비 오면 보상이 더 많대!" },
	Battle = { "온다 온다!", "받아라! 🦴", "하나도 못 지나가!", "뼈다귀 발견!", "이 정도쯤이야!", "도와줘~!", "한 방에 보내 주마!" },
	Carnivore = { "고기… 고기가 필요해 🍖", "이빨 날카롭지?", "사냥 시간이다!" },
	Herbivore = { "풀 먹고 싶다 🌿", "평화가 좋아~", "나뭇잎 간식 없어?" },
	Armored = { "내 등껍질 단단하지?", "막는 건 자신 있어 🛡️", "쿵! 쿵!" },
	Sky = { "하늘이 그리워~ 🦅", "날아오르고 싶다!", "위에서 다 보여!" },
	Sea = { "물 어디 없나? 🌊", "첨벙첨벙 하고 싶다", "바다 냄새가 그리워" },
	Variant = { "난 특별해 ✨", "이 힘을 봐라!", "평범한 공룡이랑은 달라" },
	Farm = { "농장 생활 최고~ 🌾", "여기 풀 맛있어!", "일은 디펜스 친구들이 하겠지…" },
}


local bases = {} -- [base number] = { frame, monsters = { [id] = monster }, near }
local unitRig -- defined below
local fxFolder = Instance.new("Folder")
fxFolder.Name = "DefenseFx"
fxFolder.Parent = Workspace

local function baseFolder(index)
	local map = Workspace:FindFirstChild("Map")
	return map and map:FindFirstChild("Base" .. index)
end

local ARENA_STAGE = Formulas.stageOf("Base_Arena")
local function arenaStaged(index)
	local folder = ARENA_STAGE and baseFolder(index)
	local id = folder and folder:GetAttribute("OwnerUserId")
	local owner = id and Players:GetPlayerByUserId(id)
	return owner ~= nil and owner:GetAttribute("Staged" .. ARENA_STAGE) == true
end

local function getBase(index)
	local b = bases[index]
	if not b then
		local folder = baseFolder(index)
		local frame = folder and folder:GetAttribute("ArenaFrame")
		if not frame then
			return nil
		end
		b = { frame = frame, monsters = {}, near = false, index = index,
			path = Formulas.lanePath(folder:GetAttribute("DefenseMap")) }
		bases[index] = b
		folder:GetAttributeChangedSignal("DefenseMap"):Connect(function()
			b.path = Formulas.lanePath(folder:GetAttribute("DefenseMap"))
		end)
	end
	return b
end

-- ---------------------------------------------------------------------------
-- Monster models
-- ---------------------------------------------------------------------------

local templates = ReplicatedStorage:FindFirstChild("DefenseModels")
local function templateOf(name)
	if not (templates and templates.Parent) then
		templates = ReplicatedStorage:FindFirstChild("DefenseModels")
	end
	return templates and templates:FindFirstChild(name)
end
local standIns = {}

-- (2026-10-01) the fossils' level as every other level shows: the tier's mark and the level within it
local function levelText(level)
	return Formulas.levelText(level)
end

local function levelColor(level)
	local within = (Formulas.shownLevel(level, Formulas.tierOfLevel(level)) - 1) % Config.Monsters.StarEveryLevels
	return LEVEL_COLORS[within // Config.Monsters.ColorEveryLevels + 1] or LEVEL_COLORS[1]
end

local function wear(model, name, height)
	local source = templateOf(name)
	if not source then
		return nil
	end
	local look = source:Clone()
	if not look:IsA("Model") then
		local wrap = Instance.new("Model")
		look.Parent = wrap
		look = wrap
	end
	for _, d in ipairs(look:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
		end
	end
	local cf, size = look:GetBoundingBox()
	look.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
	look:ScaleTo(math.max(height / STATUS_REF_HEIGHT, 0.2))
	look:PivotTo(model:GetPivot() * CFrame.new(0, (WEAR_LIFTS[name] or 0) * height, 0))
	look.Name = name
	look.Parent = model
	return look
end

local function newModel(m, own)
	local name = Config.Monsters.Models[m.modelIndex]
	local source = templateOf(name)
	local model
	if source then
		model = source:Clone()
		if not model:IsA("Model") then
			local wrap = Instance.new("Model")
			model.Parent = wrap
			model = wrap
		end
	else
		model = Instance.new("Model")
		local part = Instance.new("Part")
		part.Size = GREY_MONSTER
		part.TopSurface, part.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
		part.Parent = model
		m.standIn = true
	end
	model.Name = "Monster"
	local biggest, biggestVolume = nil, 0
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored = true
			d.CanCollide = false
			d.CanQuery = false
			d.CanTouch = false
			d.CastShadow = false
			local v = d.Size.X * d.Size.Y * d.Size.Z
			if v > biggestVolume then
				biggest, biggestVolume = d, v
			end
		end
	end
	local kind = m.kind and Formulas.fossilKind(m.kind)
	local group = m.group and Formulas.groupKind(m.group)
	if biggest then -- body color by level (10 colors, then again with a star); a special kind tinted its way
		biggest.Color = kind and levelColor(m.level):Lerp(Color3.fromRGB(table.unpack(kind.Rgb)), KIND_TINT) or levelColor(m.level)
	end
	if kind and kind.Ghost then
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") then
				d.Transparency = math.max(d.Transparency, kind.Ghost)
			end
		end
	end
	local cf, size = model:GetBoundingBox()
	model.PrimaryPart = nil
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
	model:ScaleTo(MONSTER_DRAW_SCALE * (kind and kind.Scale or 1) * (m.leader and Config.Defense.Groups.LeaderScale or 1))
	if m.boss then -- the promotion boss: the same model, bigger, with a crown on its head
		model:ScaleTo(Config.Defense.Boss.SizeMultiplier * MONSTER_DRAW_SCALE)
		cf, size = model:GetBoundingBox()
		model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
		local crownSource = templateOf(Config.Monsters.BossCrown)
		if crownSource then
			local crown = crownSource:Clone()
			if not crown:IsA("Model") then
				local wrap = Instance.new("Model")
				crown.Parent = wrap
				crown = wrap
			end
			for _, d in ipairs(crown:GetDescendants()) do
				if d:IsA("BasePart") then
					d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
				end
			end
			crown:ScaleTo(Config.Defense.Boss.SizeMultiplier)
			local ccf, csize = crown:GetBoundingBox()
			crown.WorldPivot = CFrame.new(ccf.Position - Vector3.new(0, csize.Y / 2, 0))
			local head = model:FindFirstChild("Head", true)
			local top = head and head:IsA("Bone") and head.WorldPosition + Vector3.new(0, size.Y * CROWN_ABOVE_HEAD, 0)
				or cf.Position + Vector3.new(0, size.Y / 2, 0)
			crown:PivotTo(CFrame.new(top))
			crown.Parent = model
		end
	end

	if not m.boss and (kind and kind.Look or m.leader) then
		local height = select(2, model:GetBoundingBox()).Y
		if kind and kind.Look then
			local look = wear(model, kind.Look, height)
			if look and kind.LookTint then
				for _, d in ipairs(look:GetDescendants()) do
					if d:IsA("BasePart") then
						d.Color = Color3.fromRGB(table.unpack(kind.Rgb))
					end
				end
			end
		end
		if m.leader then
			wear(model, Config.Defense.Groups.FlagModel, height)
		end
	end

	local balloonSource = kind and kind.Balloon and templateOf(kind.Balloon)
	if balloonSource then
		cf, size = model:GetBoundingBox()
		local balloon = balloonSource:Clone()
		if not balloon:IsA("Model") then
			local wrap = Instance.new("Model")
			balloon.Parent = wrap
			balloon = wrap
		end
		for _, d in ipairs(balloon:GetDescendants()) do
			if d:IsA("BasePart") then
				d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
			end
		end
		local bcf, bsize = balloon:GetBoundingBox()
		balloon.WorldPivot = CFrame.new(bcf.Position - Vector3.new(0, bsize.Y / 2, 0))
		balloon:PivotTo(model:GetPivot() * CFrame.new(0, size.Y + AIRSHIP.Gap, 0))
		balloon.Parent = model
		size = Vector3.new(size.X, size.Y + AIRSHIP.Gap + bsize.Y, size.Z)
	elseif kind and kind.Id == "Airship" then
		cf, size = model:GetBoundingBox()
		local top = cf.Position + Vector3.new(0, size.Y / 2, 0)
		local center = top + Vector3.new(0, AIRSHIP.Gap + AIRSHIP.Balloon / 2, 0)
		local balloon = Instance.new("Part")
		balloon.Shape = Enum.PartType.Ball
		balloon.Size = Vector3.one * AIRSHIP.Balloon
		balloon.Color = AIRSHIP.Color
		balloon.Material = Enum.Material.SmoothPlastic
		balloon.CFrame = CFrame.new(center)
		balloon.Anchored, balloon.CanCollide, balloon.CanQuery, balloon.CanTouch = true, false, false, false
		balloon.Parent = model
		for _, side in ipairs({ -1, 1 }) do
			local a = top + Vector3.new(side * size.X / 4, 0, 0)
			local c = center - Vector3.new(0, AIRSHIP.Balloon / 2 - 0.3, 0)
			local rope = Instance.new("Part")
			rope.Size = Vector3.new(AIRSHIP.String, AIRSHIP.String, (c - a).Magnitude)
			rope.CFrame = CFrame.lookAt((a + c) / 2, c)
			rope.Color = Color3.new(1, 1, 1)
			rope.Anchored, rope.CanCollide, rope.CanQuery, rope.CanTouch = true, false, false, false
			rope.Parent = model
		end
		size = Vector3.new(size.X, size.Y + AIRSHIP.Gap + AIRSHIP.Balloon, size.Z)
	end

	local gui = Instance.new("BillboardGui")
	gui.Size = m.boss and BOSS_LABEL_SIZE or UDim2.fromOffset(64, 22)
	gui.StudsOffsetWorldSpace = Vector3.new(0, size.Y + 0.8, 0)
	gui.MaxDistance = BAR_MAX_DISTANCE
	local text = Instance.new("TextLabel")
	text.Size = UDim2.new(1, 0, 0, m.boss and 16 or 12)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBold
	text.TextScaled = true
	text.TextColor3 = Color3.new(1, 1, 1)
	text.TextStrokeTransparency = 0.3
	local marks = (m.leader and "🚩" or "") .. (group and group.Icon or "") .. (kind and kind.Icon or "")
		.. (m.attribute and Config.Attributes[m.attribute].Icon or "")
	-- (2026-10-03) the boss's weakness after its attribute
	local weakness = m.boss and Config.Attributes[Formulas.bossWeakness(m.attribute) or "Neutral"]
	text.Text = m.boss and string.format("보스 %s · %s · 약점 %s", levelText(m.level), Config.Attributes[m.attribute].Name,
		weakness.Icon)
		or (marks ~= "" and marks .. " " .. levelText(m.level) or levelText(m.level))
	text.Parent = gui
	if own then
		local back = Instance.new("Frame")
		back.Position = UDim2.fromOffset(0, m.boss and 19 or 14)
		back.Size = UDim2.new(1, 0, 0, m.boss and 10 or 6)
		back.BackgroundColor3 = Color3.fromRGB(40, 20, 20)
		back.BorderSizePixel = 0
		back.Parent = gui
		local fill = Instance.new("Frame")
		fill.Name = "Fill"
		fill.Size = UDim2.fromScale(m.hp, 1)
		fill.BackgroundColor3 = Color3.fromRGB(90, 220, 90)
		fill.BorderSizePixel = 0
		fill.Parent = back
		m.fill = fill
	end
	gui.Parent = model
	m.label = gui
	-- (2026-10-04, "8명이 풀로 승급전 돌리고 … 매끄럽게") the body part carries the pivot: the fossils are moved with
	-- Workspace:BulkMoveTo (the render loop), and the model's pivot (GetPivot: the looks, the sounds, the attacks' aim)
	-- follows its parts that way, where a WorldPivot would stay behind
	if biggest then
		local pivot = model:GetPivot()
		model.PrimaryPart = biggest
		biggest.PivotOffset = biggest.CFrame:ToObjectSpace(pivot)
	end
	model.Parent = Workspace
	m.model = model
	m.height = select(2, model:GetBoundingBox()).Y
	m.rig = DinoMotion.new(model)
	m.rig.silent = true -- (no dino footfalls: a fossil's bones rattle instead, BoneStep below)
end

local buildQueue = {} -- { b, m } waiting for a model (MODELS_PER_FRAME)
local function queueModel(b, m)
	if not m.queued and not m.model then
		m.queued = true
		table.insert(buildQueue, { b, m })
	end
end

-- (2026-10-04) a fossil's parts (its status looks' too) and each one's place against its pivot, for the render loop's
-- one BulkMoveTo a base; worked out again when a look comes or goes (m.parts = nil)
local function partsOf(m)
	if not m.parts then
		local pivot = m.model:GetPivot()
		local parts, offsets = {}, {}
		for _, d in ipairs(m.model:GetDescendants()) do
			if d:IsA("BasePart") then
				table.insert(parts, d)
				table.insert(offsets, pivot:ToObjectSpace(d.CFrame))
			end
		end
		m.parts, m.offsets = parts, offsets
	end
	return m.parts, m.offsets
end

local function dropModel(m)
	m.queued = nil -- (a waiting one is skipped: see buildSome)
	m.parts, m.offsets = nil, nil
	if m.looks then -- (their models go with the fossil's)
		local b = m.base
		for _ in pairs(m.looks) do
			if b then
				b.looksCount = (b.looksCount or 0) - 1
			end
		end
		m.looks = nil
		if b and b.withLooks then
			b.withLooks[m] = nil
		end
	end
	if m.model then
		m.model:Destroy()
		m.model = nil
		m.fill = nil
		m.rig = nil
	end
end

-- ---------------------------------------------------------------------------
-- Positions
-- ---------------------------------------------------------------------------

local function sNow(m, now)
	return m.s + m.v * (now - m.t)
end

local function worldAt(b, s, offset)
	local x, z, tx, tz = Formulas.lanePoint(b.path, s, offset)
	return b.frame * Vector3.new(x, TRACK_TOP, z), b.frame:VectorToWorldSpace(Vector3.new(tx, 0, tz))
end

-- ---------------------------------------------------------------------------
-- Attack effects
-- ---------------------------------------------------------------------------

-- (2026-10-04, "8명이 풀로 승급전 … 매끄럽게") the lines' parts are used again (a busy fight made and destroyed some 50 a
-- second): taken from the pool, put back when their time is up
local linePool = {}

local function line(from, to, color)
	local length = (to - from).Magnitude
	if length < 0.05 then
		return
	end
	local p = table.remove(linePool)
	if not p then
		p = Instance.new("Part")
		p.Anchored = true
		p.CanCollide = false
		p.CanQuery = false
		p.CanTouch = false
		p.CastShadow = false
		p.Material = Enum.Material.Neon
	end
	p.Color = color
	p.Size = Vector3.new(FX_WIDTH, FX_WIDTH, length)
	p.CFrame = CFrame.lookAt((from + to) / 2, to)
	p.Parent = fxFolder
	task.delay(FX_SECONDS, function()
		if #linePool < LINE_POOL_MAX then
			p.Parent = nil
			table.insert(linePool, p)
		else
			p:Destroy()
		end
	end)
end

-- a hit's pop (2026-10-04): a neon ball growing and fading at `at`, size × scale; its parts used again like the lines'
local impactPool = {}
local function impact(at, color, scale)
	local p = table.remove(impactPool)
	if not p then
		p = Instance.new("Part")
		p.Shape = Enum.PartType.Ball
		p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
		p.Material = Enum.Material.Neon
	end
	p.Color = color
	p.Transparency = IMPACT_TRANSPARENCY
	p.Size = Vector3.one * IMPACT_FROM * scale
	p.CFrame = CFrame.new(at)
	p.Parent = fxFolder
	TweenService:Create(p, TweenInfo.new(IMPACT_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{ Size = Vector3.one * IMPACT_TO * scale, Transparency = 1 }):Play()
	task.delay(IMPACT_SECONDS + 0.02, function()
		if #impactPool < IMPACT_POOL_MAX then
			p.Parent = nil
			table.insert(impactPool, p)
		else
			p:Destroy()
		end
	end)
end

local function monsterPoint(b, id, now)
	local m = b.monsters[id]
	if not m then
		return nil
	end
	local pos = worldAt(b, sNow(m, now), m.offset)
	return pos + Vector3.new(0, 1.2, 0)
end

-- the dinos standing on the platforms: [model] = { rig }; where they stand is the model attribute Rest
local units = setmetatable({}, { __mode = "k" })

unitRig = function(model)
	local u = units[model]
	if not u then
		u = {}
		units[model] = u
	end
	if not u.rig then
		u.rig = DinoMotion.new(model, u.applied) -- (where this screen last put it: its parts stand there now)
		u.rig.soundGain = DEFENSE_STEP_GAIN
		if not u.watching then
			-- on a phone the model streams in bit by bit: a rig made before its mesh (and bones) arrived
			-- had no legs to move, for good. Anything arriving later makes it again
			u.watching = model.DescendantAdded:Connect(function(d)
				if d:IsA("BasePart") or d:IsA("Bone") then
					u.rig = nil
				end
			end)
		end
	end
	return u.rig
end

-- (2026-10-04, "공룡 모델이 뒤집힌게 아니라 지가 저렇게 뭐에 홀린듯 뒤돈거": a placed dino stood turned round and pushed off
-- its spot) every part of a dino is put where it belongs from where it should stand this frame, each by its own offset
-- from the server's Rest (taken when the part arrives, at the server's pose). Before, PivotTo moved the model on from
-- wherever it was: on a phone a model streams in bit by bit, and a part arriving while the dino was turned toward a
-- fossil or lunging (or whatever the server re-placed meanwhile) was carried along from the wrong place for good: the
-- dino stayed turned round or shoved aside until it was made again
local function placeUnit(model, u, rest, cf)
	if not u.known then
		u.known = setmetatable({}, { __mode = "k" }) -- [part] = its offset from Rest
		u.partsDirty = true
		local function mark(d)
			if d:IsA("BasePart") then
				u.partsDirty = true
			end
		end
		u.partsWatch = { model.DescendantAdded:Connect(mark), model.DescendantRemoving:Connect(mark) }
	end
	if u.partsDirty then
		u.partsDirty = false
		local parts, offsets = {}, {}
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") then
				local offset = u.known[d]
				if not offset then -- (just arrived: where the server put it, against its Rest)
					offset = rest:ToObjectSpace(d.CFrame)
					u.known[d] = offset
				end
				table.insert(parts, d)
				table.insert(offsets, offset)
			end
		end
		u.parts, u.offsets = parts, offsets
	end
	local cframes = table.create(#u.parts)
	for i, offset in ipairs(u.offsets) do
		cframes[i] = cf * offset
	end
	Workspace:BulkMoveTo(u.parts, cframes, Enum.BulkMoveMode.FireCFrameChanged)
	u.applied = cf
end

-- is this kind ("Dinos" or "Fossils") hidden on this base by the player's settings?
local function hidden(kind, index)
	local own = player:GetAttribute("Base") == index
	return player:GetAttribute((own and "HideMy" or "HideOther") .. kind) == true
end

-- a fire / ice / water blast round its target ("R" event)
local function burstFx(b, s, offset, radius, attribute)
	if not b.near or hidden("Fossils", b.index) then
		return
	end
	local at = worldAt(b, s, offset) + Vector3.new(0, POOL_UP, 0)
	local p = Instance.new("Part")
	p.Shape = Enum.PartType.Cylinder
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
	p.Material = Enum.Material.Neon
	p.Color = ATTRIBUTE_COLORS[attribute] or ATTRIBUTE_COLORS.Neutral
	p.Transparency = BURST_TRANSPARENCY
	p.Size = Vector3.new(BURST_THICKNESS, 1, 1)
	p.CFrame = CFrame.new(at) * CFrame.Angles(0, 0, math.pi / 2)
	p.Parent = fxFolder
	TweenService:Create(p, TweenInfo.new(BURST_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{ Size = Vector3.new(BURST_THICKNESS, radius * 2, radius * 2), Transparency = 1 }):Play()
	task.delay(BURST_SECONDS, function()
		p:Destroy()
	end)
end

local function waveFx(b, unitId, reach)
	if not b.near or hidden("Dinos", b.index) then
		return
	end
	local folder = baseFolder(b.index)
	local unitsFolder = folder and folder:FindFirstChild("DefenseUnits")
	local unit = unitsFolder and unitsFolder:FindFirstChild(unitId)
	local rest = unit and unit:GetAttribute("Rest")
	if not rest then
		return
	end
	local p = Instance.new("Part")
	p.Shape = Enum.PartType.Cylinder
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
	p.Material = Enum.Material.Neon
	p.Color = WAVE.Color
	p.Transparency = WAVE.Transparency
	p.Size = Vector3.new(WAVE.Thickness, 2, 2)
	p.CFrame = CFrame.new(rest.Position + Vector3.new(0, WAVE.Up, 0)) * CFrame.Angles(0, 0, math.pi / 2)
	p.Parent = fxFolder
	TweenService:Create(p, TweenInfo.new(WAVE.Seconds, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{ Size = Vector3.new(WAVE.Thickness, reach * 2, reach * 2), Transparency = 1 }):Play()
	task.delay(WAVE.Seconds, function()
		p:Destroy()
	end)
	Sfx.play("DinoSplash", rest.Position)
end

-- a poison pool on the track ("W" event), gone after its seconds
local function poolFx(b, s, offset, radius, seconds)
	if not b.near or hidden("Fossils", b.index) then
		return
	end
	b.pools = b.pools or {}
	while #b.pools >= POOL_MAX do
		table.remove(b.pools, 1):Destroy()
	end
	local at = worldAt(b, s, offset) + Vector3.new(0, POOL_UP, 0)
	local template = templateOf("Fx_PoisonPool")
	local p
	if template then -- the puddle model (1 stud in radius), turned at random, as big as the pool
		p = template:Clone()
		if p:IsA("BasePart") then
			local holder = Instance.new("Model")
			p.Parent = holder
			p = holder
		end
		for _, d in ipairs(p:GetDescendants()) do
			if d:IsA("BasePart") then
				d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
				d.Transparency = POOL_MODEL_TRANSPARENCY
			end
		end
		local _, size = p:GetBoundingBox()
		p:ScaleTo(radius * 2 / math.max(size.X, size.Z, 0.01))
		local cf, scaled = p:GetBoundingBox()
		p:PivotTo(CFrame.new(at + (p:GetPivot().Position - cf.Position) + Vector3.new(0, scaled.Y / 2, 0))
			* CFrame.Angles(0, math.random() * 2 * math.pi, 0) * p:GetPivot().Rotation) -- (as imported, turned)
	else
		p = Instance.new("Part")
		p.Shape = Enum.PartType.Cylinder
		p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
		p.Material = Enum.Material.SmoothPlastic
		p.Color = POOL_COLOR
		p.Transparency = POOL_TRANSPARENCY
		p.Size = Vector3.new(POOL_THICKNESS, radius * 2, radius * 2)
		p.CFrame = CFrame.new(at) * CFrame.Angles(0, 0, math.pi / 2)
	end
	p.Name = "PoisonPool"
	p.Parent = fxFolder
	table.insert(b.pools, p)
	task.delay(seconds, function()
		local i = table.find(b.pools, p)
		if i then
			table.remove(b.pools, i)
		end
		p:Destroy()
	end)
end

-- show or hide a dino model on this screen only (the server's model stays as it is); its rarity aura
-- also goes with the view setting "오라" (HideAuras)
local function setUnitHidden(model, hide, far, ghost, hideAuras)
	local u = units[model] or {}
	units[model] = u
	-- the rarity lights and particles also go out on dinos far from the camera (2026-10-01: on a phone,
	-- every rare dino of eight bases lit at once)
	local auraOff = hide or far == true or ghost == true or hideAuras == true
	ghost = ghost == true
	if u.hidden == hide and u.auraOff == auraOff and u.ghost == ghost then
		return
	end
	local partsChanged = u.hidden ~= hide or u.ghost ~= ghost
	u.hidden, u.auraOff, u.ghost = hide, auraOff, ghost
	if partsChanged then
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") then
				d.LocalTransparencyModifier = hide and 1 or ghost and TOP_VIEW_SEE_THROUGH or 0
			elseif d:IsA("BillboardGui") then
				-- (2026-10-02: shown again here, a farm dino's "💰 +0.4%" came back with 농장 효과 글씨 off)
				d.Enabled = not hide and not (d.Name == "FarmBuff" and player:GetAttribute("HideFarmLabels") == true)
			end
		end
	end
	RarityFx.setVisible(model, not auraOff) -- its lights and particles too
end

-- at most PER_SECOND[kind] sounds a second on this track
local function allowSound(b, kind)
	b.sounds = b.sounds or {}
	local s = b.sounds[kind]
	local now = os.clock()
	if not s or now - s.start >= 1 then
		s = { start = now, count = 0 }
		b.sounds[kind] = s
	end
	if s.count >= (PER_SECOND[kind] or 3) then
		return false
	end
	s.count += 1
	return true
end

-- what kind of attack a dino model makes (its species' theme), for its sound
local function attackKind(model)
	local species = Formulas.species(model:GetAttribute("Species") or "")
	local theme = species and Formulas.theme(species.Theme == "Variant" and species.BaseTheme or species.Theme)
	return theme and theme.Attack
end

local function voiceOf(model, position, gain)
	local species = model:GetAttribute("Species")
	if species then
		local name, pitch = DinoVoices.voice(species, model:GetAttribute("Footprint"))
		Sfx.play(name, position, pitch, DEFENSE_GAIN.Voice * (gain or 1))
	end
end

-- a dino on a platform or in a farm pen growls now and then in its own voice
local lastGrowl = 0
local function growlNow(model, position)
	local u = units[model]
	local now = os.clock()
	if not u then
		return
	end
	if not u.nextGrowl then
		u.nextGrowl = now + math.random(GROWL_EVERY[1], GROWL_EVERY[2])
		return
	end
	if now < u.nextGrowl then
		return
	end
	u.nextGrowl = now + math.random(GROWL_EVERY[1], GROWL_EVERY[2])
	local camera = Workspace.CurrentCamera
	if not camera or (camera.CFrame.Position - position).Magnitude > GROWL_DISTANCE or now - lastGrowl < GROWL_GAP then
		return
	end
	lastGrowl = now
	DinoMotion.roar(unitRig(model)) -- it rears up and roars with it
	voiceOf(model, position, GROWL_GAIN)
end

-- a dino says a random line (its theme's, a battle line while fossils are on the track, or a general one)
local lastChat = 0
local function chatter(b, model, folderName, position)
	local u = units[model]
	local now = os.clock()
	if not u then
		return
	end
	if not u.nextChat then
		u.nextChat = now + math.random(CHAT_EVERY[1], CHAT_EVERY[2])
		return
	end
	if now < u.nextChat then
		return
	end
	u.nextChat = now + math.random(CHAT_EVERY[1], CHAT_EVERY[2])
	if folderName == "FarmUnits" and player:GetAttribute("HideFarmLabels") then
		return -- (2026-10-02, "Farm labels 를 끄면 농장에 있는 자막들이 다 사라져야지": the farm dinos' talk too)
	end
	local camera = Workspace.CurrentCamera
	if not camera or (camera.CFrame.Position - position).Magnitude > CHAT_DISTANCE or now - lastChat < CHAT_GAP then
		return
	end
	lastChat = now
	local species = Formulas.species(model:GetAttribute("Species") or "")
	local pool = CHAT_LINES.Any
	local roll = math.random()
	if folderName == "FarmUnits" and roll < 0.5 then
		pool = CHAT_LINES.Farm
	elseif folderName ~= "FarmUnits" and next(b.monsters) ~= nil and roll < 0.6 then
		pool = CHAT_LINES.Battle
	elseif species and CHAT_LINES[species.Theme] and roll < 0.75 then
		pool = CHAT_LINES[species.Theme]
	end
	local weatherLines = WEATHER_CHAT[ReplicatedStorage:GetAttribute("Weather") or "Clear"]
	if weatherLines and math.random() < WEATHER_CHAT_SHARE then
		pool = weatherLines
	end
	local cf, size = model:GetBoundingBox()
	local part = model:FindFirstChildWhichIsA("BasePart", true)
	if not part then
		return
	end
	local line = pool[math.random(1, #pool)]
	local Lang = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Lang"))
	local shown = Lang.t(line, Lang.code(player)) -- (sized for the words this screen shows)
	local bounds = TextService:GetTextSize(shown, CHAT_TEXT_SIZE, Enum.Font.GothamBold, Vector2.new(CHAT_MAX_WIDTH, 1000))
	local bubble = Instance.new("BillboardGui")
	bubble.Name = "DinoChat"
	bubble.Size = UDim2.fromOffset(bounds.X + CHAT_PAD.X * 2 + 4, bounds.Y + CHAT_PAD.Y * 2 + 2)
	-- over the top of the whole dino (the part it hangs on can sit anywhere in it), drawn over it
	bubble.StudsOffsetWorldSpace = Vector3.new(0, cf.Position.Y + size.Y / 2 - part.Position.Y + CHAT_ABOVE, 0)
	bubble.AlwaysOnTop = true
	bubble.Adornee = part
	bubble.MaxDistance = CHAT_DISTANCE
	bubble.ResetOnSpawn = false
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundColor3 = CHAT_BG
	text.TextColor3 = CHAT_TEXT
	text.Font = Enum.Font.GothamBold
	text.TextSize = CHAT_TEXT_SIZE
	text.TextWrapped = true
	text.Text = line
	text.Parent = bubble
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 12)
	round.Parent = text
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, CHAT_PAD.X), UDim.new(0, CHAT_PAD.X)
	pad.PaddingTop, pad.PaddingBottom = UDim.new(0, CHAT_PAD.Y), UDim.new(0, CHAT_PAD.Y)
	pad.Parent = text
	bubble.Parent = player:WaitForChild("PlayerGui")
	task.delay(CHAT_SECONDS, function()
		bubble:Destroy()
	end)
end

local function between(range)
	return range[1] + math.random() * (range[2] - range[1])
end

-- a farm dino's spot this frame: strolling to grass and grazing (see the top); returns the CFrame it
-- stands at and its walking speed
local function farmPlace(folder, model, rest, dt)
	local u = units[model] or {}
	units[model] = u
	local grass = folder:FindFirstChild("FarmGrass")
	local penCf = grass and grass:GetAttribute("PenCFrame")
	local penSize = grass and grass:GetAttribute("PenSize")
	local rig = unitRig(model)
	if not penCf or not penSize then
		return rest, 0
	end
	local f = u.farm
	if not f or f.rest ~= rest then -- (a new dino, or the server moved it)
		local look = rest.LookVector
		local _, size = model:GetBoundingBox()
		f = { rest = rest, pos = rest.Position, dir = Vector3.new(look.X, 0, look.Z).Unit, mode = "idle",
			untilTime = os.clock() + between(FARM_IDLE_SECONDS), length = math.max(size.X, size.Z) }
		u.farm = f
	end
	local now, speed = os.clock(), 0
	if f.jolt then -- hopping away from a bolt, kept inside the pen
		local t = (now - f.jolt.start) / JOLT_SECONDS
		if t >= 1 then
			f.jolt = nil
		else
			local to = penCf:PointToObjectSpace(f.jolt.to)
			to = penCf:PointToWorldSpace(Vector3.new(math.clamp(to.X, -penSize.X / 2, penSize.X / 2), to.Y,
				math.clamp(to.Z, -penSize.Z / 2, penSize.Z / 2)))
			f.pos = f.jolt.from:Lerp(Vector3.new(to.X, f.jolt.from.Y, to.Z), t)
			return CFrame.lookAt(f.pos, f.pos + f.dir) + Vector3.new(0, math.sin(math.pi * t) * JOLT_HEIGHT, 0), 0
		end
	end
	if f.mode == "walk" then
		local to = Vector3.new(f.target.X - f.pos.X, 0, f.target.Z - f.pos.Z)
		if to.Magnitude < 0.3 then
			if f.toGrass then
				f.mode, f.untilTime = "graze", now + between(FARM_GRAZE_SECONDS)
				DinoMotion.graze(rig, true)
			else
				f.mode, f.untilTime = "idle", now + between(FARM_IDLE_SECONDS)
			end
		else
			local walkSpeed = FARM_WALK_SPEED * math.clamp(rig.height / FARM_SIZE_REFERENCE, 1, FARM_SPEED_MAX) -- big ones stride faster
			local step = math.min(to.Magnitude, walkSpeed * dt)
			f.pos += to.Unit * step
			f.dir = f.dir:Lerp(to.Unit, math.min(1, dt * FARM_TURN))
			if f.dir.Magnitude < 0.01 then
				f.dir = to.Unit
			end
			f.dir = f.dir.Unit
			speed = walkSpeed
		end
	elseif now >= f.untilTime then -- off to the next stop
		DinoMotion.graze(rig, false)
		local clumps = grass:GetChildren()
		if #clumps > 0 and math.random() < FARM_GRASS_CHANCE then
			local at = clumps[math.random(1, #clumps)]:GetPivot().Position
			local from = Vector3.new(f.pos.X - at.X, 0, f.pos.Z - at.Z)
			from = from.Magnitude > 0.1 and from.Unit or Vector3.xAxis
			f.target, f.toGrass = Vector3.new(at.X, f.pos.Y, at.Z) + from * f.length * FARM_MOUTH_REACH, true
		else
			local spot = penCf:PointToWorldSpace(Vector3.new((math.random() - 0.5) * penSize.X, 0,
				(math.random() - 0.5) * penSize.Z))
			f.target, f.toGrass = Vector3.new(spot.X, f.pos.Y, spot.Z), false
		end
		f.mode = "walk"
	end
	return CFrame.lookAt(f.pos, f.pos + f.dir), speed
end

-- a placed dino's spot this frame (see DEFENSE_* at the top); returns the CFrame and its walking speed
local function defensePlace(b, model, rest, dt, now)
	if model:GetAttribute("Bench") then
		return rest, 0
	end
	local u = units[model]
	local d = u.defense
	if not d or d.rest ~= rest then -- a new dino, or the server moved it
		d = { rest = rest, yaw = 0, want = 0, offset = Vector3.zero, to = Vector3.zero,
			nextLook = os.clock() + between(DEFENSE_LOOK_EVERY), nextStep = os.clock() + between(DEFENSE_STEP_EVERY) }
		u.defense = d
	end
	local clock = os.clock()
	local here = rest.Position + d.offset
	local target = u.faceUntil and clock < u.faceUntil and u.faceAt or nil
	if not target then -- the nearest fossil coming, if any is near
		local best = DEFENSE_WATCH_RANGE
		for id in pairs(b.monsters) do
			local p = monsterPoint(b, id, now)
			if p then
				local dist = Vector3.new(p.X - here.X, 0, p.Z - here.Z).Magnitude
				if dist < best then
					best, target = dist, p
				end
			end
		end
	end
	if target then
		local to = rest:PointToObjectSpace(Vector3.new(target.X, rest.Position.Y, target.Z))
		d.want = math.clamp(math.atan2(-to.X, -to.Z), -DEFENSE_TURN_MAX, DEFENSE_TURN_MAX)
	elseif clock >= d.nextLook then -- nothing near: glance about
		d.nextLook = clock + between(DEFENSE_LOOK_EVERY)
		d.want = (math.random() * 2 - 1) * DEFENSE_LOOK_ANGLE
	end
	d.yaw += (d.want - d.yaw) * math.min(1, dt * DEFENSE_TURN)
	-- a little shuffle: a step to a spot near its own, then back after a while
	local speed = 0
	if clock >= d.nextStep then
		d.nextStep = clock + between(DEFENSE_STEP_EVERY)
		if d.to.Magnitude > 0 then
			d.to = Vector3.zero
		else
			local a = math.random() * 2 * math.pi
			d.to = Vector3.new(math.cos(a), 0, math.sin(a)) * DEFENSE_STEP * (0.5 + 0.5 * math.random())
		end
	end
	local gap = d.to - d.offset
	if gap.Magnitude > 0.02 then
		local step = math.min(gap.Magnitude, DEFENSE_STEP_SPEED * dt)
		d.offset += gap.Unit * step
		speed = DEFENSE_STEP_SPEED
	end
	return CFrame.new(d.offset) * rest * CFrame.Angles(0, d.yaw, 0), speed
end

local lodEye = Vector3.zero -- the camera this frame (set by the drawing loop)
local liteNow = nil
local unitLists = setmetatable({}, { __mode = "k" })
local function childrenOf(folder)
	local c = unitLists[folder]
	if not c then
		c = { dirty = true, list = {} }
		unitLists[folder] = c
		folder.ChildAdded:Connect(function()
			c.dirty = true
		end)
		folder.ChildRemoved:Connect(function()
			c.dirty = true
		end)
	end
	if c.dirty then
		c.dirty = false
		c.list = folder:GetChildren()
	end
	return c.list
end

local function animateUnits(b, dt, animate, hideAuras)
	local clock = os.clock()
	local check = clock >= (b.unitCheckAt or 0)
	if not animate and not check then
		return
	end
	if check then
		b.unitCheckAt = clock + UNIT_CHECK_EVERY
	end
	local folder = baseFolder(b.index)
	if not folder then
		return
	end
	local own = b.index == player:GetAttribute("Base")
	local topView = player:GetAttribute("TopView") == true
		and b.index == (player:GetAttribute("TopViewBase") or player:GetAttribute("Base"))
	if b.topView ~= topView then
		b.topView = topView
		for _, m in pairs(b.monsters) do
			if m.label and m.label.Parent then
				m.label.MaxDistance = topView and TOP_VIEW_LABEL_DISTANCE or BAR_MAX_DISTANCE
			end
		end
	end
	for _, name in ipairs(UNIT_FOLDERS) do
		-- the platform's dinos (HideMyDinos / HideOtherDinos) and the farm's (HideMyFarm / HideOtherFarm)
		local list = folder:FindFirstChild(name)
		local hide = hidden(name == "FarmUnits" and "Farm" or "Dinos", b.index) or (list ~= nil and list:GetAttribute("Hidden") == true)
		for _, model in ipairs(list and childrenOf(list) or {}) do
			local u = units[model]
			if not u then
				u = {}
				units[model] = u
			end
			if u.isModel == nil then
				u.isModel = model:IsA("Model")
			end
			if u.isModel then
				-- (2026-10-04) one I'm moving is picked up (Placement: PlacingHidden): only its silhouette shows
				local hideThis = hide or (own and model:GetAttribute("PlacingHidden") == true)
				local rest = model:GetAttribute("Rest")
				setUnitHidden(model, hideThis, not rest or (rest.Position - lodEye).Magnitude > AURA_DISTANCE,
					topView and name == "DefenseUnits", hideAuras)
				if check or u.halo == nil then
					local fx = model:FindFirstChild("RarityFx")
					local halo = fx and fx:FindFirstChild("RarityHalo")
					u.halo = halo and halo:GetAttribute("Rainbow") and halo or false
				end
				local due, step = false, 0
				if rest and animate and not hideThis then -- far ones move every 2nd, 3rd or 4th frame (Shared/Lod)
					due, step = Lod.due(u, (rest.Position - lodEye).Magnitude, dt)
				end
				if rest ~= u.restWas then
					if u.restWas and u.applied and name ~= "FarmUnits" then
						u.glideFrom, u.glideAt = u.applied, clock
					end
					u.restWas = rest
				end
				if due then
					local place, speed = rest, 0
					if name == "FarmUnits" then -- strolling to the grass and grazing
						place, speed = farmPlace(folder, model, rest, step)
					else -- on the platform: turning, glancing, shuffling
						place, speed = defensePlace(b, model, rest, step, Workspace:GetServerTimeNow())
					end
					if u.glideFrom then
						local t = (clock - u.glideAt) / GLIDE.Seconds
						if t >= 1 then
							u.glideFrom = nil
						else
							local a = t * t * (3 - 2 * t)
							local from = u.glideFrom.Position
							local pos = from:Lerp(place.Position, a) + Vector3.new(0, math.sin(math.pi * t) * GLIDE.Hop, 0)
							local flat = (place.Position - from) * Vector3.new(1, 0, 1)
							place = flat.Magnitude > 0.05 and CFrame.lookAt(pos, pos + flat.Unit) or place.Rotation + pos
							speed = math.max(speed, GLIDE.Speed)
						end
					end
					placeUnit(model, u, rest, place * DinoMotion.step(unitRig(model), step, speed))
					growlNow(model, place.Position)
					chatter(b, model, name, place.Position)
					if u.halo and not u.auraOff then -- 무지개 / 시크릿: the halo cycles its colors
						RarityFx.tint(u.halo, Color3.fromHSV((clock / RAINBOW_SECONDS) % 1, 0.7, 1))
					end
				end
			end
		end
	end
end

local function attackFx(b, unitId, hitIds, chainIds, now)
	if not b.near or hidden("Dinos", b.index) then
		return
	end
	local folder = baseFolder(b.index)
	local unitsFolder = folder and folder:FindFirstChild("DefenseUnits")
	local unit = unitsFolder and unitsFolder:FindFirstChild(unitId)
	if not unit then
		return
	end
	local rig = unitRig(unit)
	if rig then
		DinoMotion.attack(rig)
	end
	local firstHit = hitIds[1] and monsterPoint(b, hitIds[1], now)
	local state = units[unit] -- (the module's per-model table, not the folder)
	if firstHit and state then -- it turns to the fossil it bites
		state.faceAt, state.faceUntil = firstHit, os.clock() + DEFENSE_FACE_SECONDS
	end
	local cf, size = unit:GetBoundingBox()
	local from = cf.Position + Vector3.new(0, size.Y * 0.2, 0)
	if b.heard and allowSound(b, "attack") then
		local sound = ATTACK_SOUNDS[attackKind(unit)]
		if sound then
			Sfx.play(sound, cf.Position, 0.9 + math.random() * 0.2,
				DEFENSE_GAIN[sound] * (ATTRIBUTE_GAIN[unit:GetAttribute("Attribute")] or 1))
		end
		local extra = ATTRIBUTE_SOUNDS[unit:GetAttribute("Attribute")]
		if extra then -- (from the fossil it hits: the spark is there)
			Sfx.play(extra, firstHit or cf.Position, 0.9 + math.random() * 0.25, ATTRIBUTE_SOUND_GAIN)
		end
		if math.random() < ATTACK_VOICE_CHANCE and allowSound(b, "voice") then
			voiceOf(unit, cf.Position)
		end
	end
	local color = ATTRIBUTE_COLORS[unit:GetAttribute("Attribute")] or ATTRIBUTE_COLORS.Neutral
	local first = nil
	local pops = 0
	for _, id in ipairs(hitIds) do
		local to = monsterPoint(b, id, now)
		if to then
			line(from, to, color)
			first = first or to
			if pops < IMPACT_MAX and allowSound(b, "impact") then -- (2026-10-04) a pop where it lands
				pops += 1
				impact(to, color, 1)
			end
		end
	end
	for _, id in ipairs(chainIds) do
		local to = monsterPoint(b, id, now)
		if first and to then
			line(first, to, color)
		end
	end
end

-- ---------------------------------------------------------------------------
-- What attribute hits leave on the fossils (STATUS_LOOKS)
-- ---------------------------------------------------------------------------

local LOOK_SECONDS = {
	Snow = Config.Attributes.Ice.SlowDuration, Wet = Config.Attributes.Water.WetDuration,
	Flame = Config.Attributes.Fire.Duration, Poison = Config.Attributes.Poison.PoolSeconds,
}

local function removeLook(b, m, name)
	local look = m.looks and m.looks[name]
	if not look then
		return
	end
	look.model:Destroy()
	m.looks[name] = nil
	m.parts = nil -- (its parts no longer move with the fossil)
	b.looksCount = (b.looksCount or 0) - 1
	if next(m.looks) == nil then
		m.looks = nil
		b.withLooks[m] = nil
	end
end

-- show name's look on the fossil for seconds (math.huge: until removeLook); a look already on it lasts longer
local function addLook(b, m, name, seconds)
	local spec = STATUS_LOOKS[name]
	if not spec or not m.model or not m.height or not b.near or hidden("Fossils", b.index) then
		return
	end
	local untilTime = os.clock() + (seconds or spec.Seconds or LOOK_SECONDS[name] or 1)
	local now = m.looks and m.looks[name]
	if now then
		now.untilTime = math.max(now.untilTime, untilTime)
		return
	end
	if (b.looksCount or 0) >= STATUS_MAX then
		return
	end
	local source = templateOf(spec.Model)
	if not source then
		return
	end
	local look = source:Clone()
	if not look:IsA("Model") then
		local wrap = Instance.new("Model")
		look.Parent = wrap
		look = wrap
	end
	for _, d in ipairs(look:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
			d.Transparency = spec.Transparency or 0
		end
	end
	local cf, size = look:GetBoundingBox()
	look.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
	look:ScaleTo(math.max(m.height / STATUS_REF_HEIGHT, 0.2))
	look:PivotTo(m.model:GetPivot() * CFrame.new(0, spec.Lift * m.height, 0))
	look.Name = name
	look.Parent = m.model -- (it moves with the fossil)
	m.parts = nil -- (its parts go in the fossil's BulkMoveTo from now on)
	m.looks = m.looks or {}
	m.looks[name] = { model = look, untilTime = untilTime }
	m.base = b
	b.looksCount = (b.looksCount or 0) + 1
	b.withLooks = b.withLooks or {}
	b.withLooks[m] = true
end

-- the looks whose time is up go
local function expireLooks(b)
	if not b.withLooks then
		return
	end
	local now = os.clock()
	for m in pairs(b.withLooks) do
		for name, look in pairs(m.looks or {}) do
			if now >= look.untilTime then
				removeLook(b, m, name)
			end
		end
	end
end

-- an attack: the attacker's attribute on every fossil it hit (an electric one's chain too)
local function attackLooks(b, unitId, hitIds, chainIds)
	local folder = baseFolder(b.index)
	local unitsFolder = folder and folder:FindFirstChild("DefenseUnits")
	local unit = unitsFolder and unitsFolder:FindFirstChild(unitId)
	local name = unit and STATUS_OF[unit:GetAttribute("Attribute") or "Neutral"]
	if not name then
		return
	end
	-- (2026-10-03) a better or bigger dino's effect lasts longer (Formulas.effectStrength; the looks with a time of their own)
	local spec = STATUS_LOOKS[name]
	local seconds = not (spec and spec.Seconds) and LOOK_SECONDS[name] and LOOK_SECONDS[name] * (unit:GetAttribute("Effect") or 1)
		or nil
	for _, list in ipairs({ hitIds, chainIds }) do
		for _, id in ipairs(list) do
			local m = b.monsters[id]
			if m then
				addLook(b, m, name, seconds)
			end
		end
	end
end

-- ---------------------------------------------------------------------------
-- Events
-- ---------------------------------------------------------------------------

local function clearBase(b)
	for _, m in pairs(b.monsters) do
		dropModel(m)
	end
	b.monsters = {}
	for _, pool in ipairs(b.pools or {}) do
		pool:Destroy()
	end
	b.pools = {}
end

local moneyPop -- (a local; defined just below)
-- "+12" rising from a monster this player's dinos killed (what the kill paid, as the server counts it)
local popsThisSecond, popSecond = 0, 0
moneyPop = function(b, m, now)
	if not b.near or os.clock() - popSecond < 1 and popsThisSecond >= POP_PER_SECOND then
		return
	end
	if os.clock() - popSecond >= 1 then
		popSecond, popsThisSecond = os.clock(), 0
	end
	popsThisSecond += 1
	local at = m.model and m.model.Parent and m.model:GetPivot().Position
	if not at then
		return
	end
	local w = Formulas.weather(ReplicatedStorage:GetAttribute("Weather"))
	local kind = m.kind and Formulas.fossilKind(m.kind)
	local paid = Formulas.killReward(m.level) * (m.boss and Formulas.bossHealthMultiplier(m.level) or 1)
		* (kind and kind.Health or 1)
		* (1 + (player:GetAttribute("BonusMoney") or 0)) * w.DefenseMoneyMultiplier
	local anchor = Instance.new("Part")
	anchor.Anchored, anchor.CanCollide, anchor.CanQuery, anchor.CanTouch = true, false, false, false
	anchor.Transparency = 1
	anchor.Size = Vector3.one * 0.2
	anchor.CFrame = CFrame.new(at + Vector3.new(0, POP_START, 0))
	anchor.Parent = Workspace
	local gui = Instance.new("BillboardGui")
	gui.Size = UDim2.fromOffset(90, 26)
	gui.AlwaysOnTop = true
	gui.Parent = anchor
	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.Font = Enum.Font.GothamBold
	label.TextScaled = true
	label.TextColor3 = POP_COLOR
	label.TextStrokeTransparency = 0.2
	label.Text = paid >= 10 and string.format("+%s💰", Formulas.shortNumber(paid + 0.5)) or string.format("+%.1f💰", paid)
	label.Parent = gui
	TweenService:Create(anchor, TweenInfo.new(POP_SECONDS), { CFrame = anchor.CFrame + Vector3.new(0, POP_RISE, 0) }):Play()
	TweenService:Create(label, TweenInfo.new(POP_SECONDS), { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
	task.delay(POP_SECONDS, function()
		anchor:Destroy()
	end)
end

-- "⚡💧 감전!" over the fossil a combo hit (at most one every COMBO_GAP on a track)
local function comboPop(b, monsterId, combo, now)
	local look = COMBO_LOOKS[combo]
	if not look or not b.near or os.clock() - (b.comboAt or 0) < COMBO_GAP then
		return
	end
	local at = monsterPoint(b, monsterId, now)
	if not at then
		return
	end
	b.comboAt = os.clock()
	local anchor = Instance.new("Part")
	anchor.Anchored, anchor.CanCollide, anchor.CanQuery, anchor.CanTouch = true, false, false, false
	anchor.Transparency = 1
	anchor.Size = Vector3.one * 0.2
	anchor.CFrame = CFrame.new(at + Vector3.new(0, POP_START + 1, 0))
	anchor.Parent = Workspace
	local gui = Instance.new("BillboardGui")
	gui.Size = COMBO_SIZE
	gui.AlwaysOnTop = true
	gui.MaxDistance = BAR_MAX_DISTANCE
	gui.Parent = anchor
	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.Font = Enum.Font.GothamBlack
	label.TextScaled = true
	label.TextColor3 = look[2]
	label.TextStrokeTransparency = 0
	label.Text = look[1]
	label.Parent = gui
	TweenService:Create(anchor, TweenInfo.new(COMBO_SECONDS), { CFrame = anchor.CFrame + Vector3.new(0, COMBO_RISE, 0) }):Play()
	TweenService:Create(label, TweenInfo.new(COMBO_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.In),
		{ TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
	task.delay(COMBO_SECONDS, function()
		anchor:Destroy()
	end)
end

local function textPop(at, look)
	local anchor = Instance.new("Part")
	anchor.Anchored, anchor.CanCollide, anchor.CanQuery, anchor.CanTouch = true, false, false, false
	anchor.Transparency = 1
	anchor.Size = Vector3.one * 0.2
	anchor.CFrame = CFrame.new(at + Vector3.new(0, POP_START + 1, 0))
	anchor.Parent = Workspace
	local gui = Instance.new("BillboardGui")
	gui.Size = COMBO_SIZE
	gui.AlwaysOnTop = true
	gui.MaxDistance = BAR_MAX_DISTANCE
	gui.Parent = anchor
	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.Font = Enum.Font.GothamBlack
	label.TextScaled = true
	label.TextColor3 = look[2]
	label.TextStrokeTransparency = 0
	label.Text = look[1]
	label.Parent = gui
	TweenService:Create(anchor, TweenInfo.new(COMBO_SECONDS), { CFrame = anchor.CFrame + Vector3.new(0, COMBO_RISE, 0) }):Play()
	TweenService:Create(label, TweenInfo.new(COMBO_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.In),
		{ TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
	task.delay(COMBO_SECONDS, function()
		anchor:Destroy()
	end)
end

local function apply(index, events, t)
	local b = getBase(index)
	if not b then
		return
	end
	local own = player:GetAttribute("Base") == index
	for _, e in ipairs(DefensePack.unpack(events)) do
		local kind = e[1]
		if kind == "S" then
			local m = { s = e[3], v = e[4], t = t, hp = e[5], modelIndex = e[6], level = e[7], offset = e[8] or 0,
				boss = e[9] == true, attribute = e[10] or nil, kind = e[11] or nil, group = e[12] or nil,
				leader = e[13] == true, base = b }
			b.monsters[e[2]] = m
			if b.near then
				queueModel(b, m)
			end
			if m.boss and b.heard then
				Sfx.play("BossRoar", monsterPoint(b, e[2], t), nil, DEFENSE_GAIN.BossRoar)
			end
		elseif kind == "M" then
			local m = b.monsters[e[2]]
			if m then
				m.s, m.v, m.t = e[3], e[4], t
				-- (a fossil stops only when it is frozen: DefenseLogic) the ice block until it walks again
				if e[4] == 0 and not m.boss then
					addLook(b, m, "IceBlock", math.huge)
				elseif e[4] ~= 0 and m.looks and m.looks.IceBlock then
					removeLook(b, m, "IceBlock")
				end
			end
		elseif kind == "H" then
			for i = 2, #e - 1, 2 do
				local m = b.monsters[e[i]]
				if m then
					m.hp = e[i + 1]
					if b.heard and b.near and allowSound(b, "hit") then
						Sfx.play("BoneHit", monsterPoint(b, e[i], t), 0.85 + math.random() * 0.3, DEFENSE_GAIN.BoneHit)
					end
					if m.fill then
						m.fill.Size = UDim2.fromScale(math.clamp(m.hp, 0, 1), 1)
					end
				end
			end
		elseif kind == "D" then
			local m = b.monsters[e[2]]
			if m then
				if own then
					moneyPop(b, m, t)
				end
				if b.heard and b.near and allowSound(b, "death") then
					Sfx.play("BoneBreak", monsterPoint(b, e[2], t), m.boss and 0.7 or (0.9 + math.random() * 0.25),
						DEFENSE_GAIN.BoneBreak)
				end
				-- (2026-10-04, "더 크게 이펙트를") it breaks apart: bone chips flying and a white pop, a boss's far bigger
				local at = b.near and not hidden("Fossils", b.index) and (m.boss or allowSound(b, "deathFx"))
					and monsterPoint(b, e[2], t)
				if at then
					local burst = m.boss and BOSS_DEATH_BURST or DEATH_BURST
					Fx.burst(at, DEATH_COLORS, burst.count, burst.speed, burst.size, burst.life)
					impact(at, Color3.new(1, 1, 1), m.boss and BOSS_DEATH_FLASH or DEATH_FLASH)
				end
				dropModel(m)
				b.monsters[e[2]] = nil
			end
		elseif kind == "L" then
			local m = b.monsters[e[2]]
			if m then
				local at = b.near and not hidden("Fossils", b.index) and monsterPoint(b, e[2], t)
				if at then
					Fx.burst(at, LEAK_COLORS, DEATH_BURST.count, DEATH_BURST.speed, DEATH_BURST.size, DEATH_BURST.life)
					if own and (e[3] or 0) > 0 and (player:GetAttribute("PromoLives") or player:GetAttribute("ChallengeWave")) then
						textPop(at, { string.format("❤️ -%d", e[3]), LEAK_COLOR })
					end
				end
				dropModel(m)
				b.monsters[e[2]] = nil
			end
		elseif kind == "G" then
			if own then
				local at = b.frame * Vector3.new(0, TRACK_TOP, 0)
				local char = player.Character
				local root = char and char:FindFirstChild("HumanoidRootPart")
				textPop(root and root.Position or at, GROUP_LOOK)
			end
		elseif kind == "A" then
			attackFx(b, e[2], e[3], e[4], t)
			attackLooks(b, e[2], e[3], e[4])
			if e[5] and not hidden("Fossils", b.index) then
				comboPop(b, e[3][1] or e[4][1], e[5], t)
			end
		elseif kind == "R" then
			burstFx(b, e[2], e[3], e[4], e[5])
		elseif kind == "W" then
			poolFx(b, e[2], e[3], e[4], e[5])
		elseif kind == "T" then
			waveFx(b, e[2], e[3])
		elseif kind == "C" then
			clearBase(b)
		end
	end
end

Net.onPush("DefenseEvents", function(t, batch)
	for _, item in ipairs(batch) do
		-- one base's bad event must not drop the others (it is still reported as an error)
		local ok, err = pcall(apply, item[1], item[2], t)
		if not ok then
			task.spawn(error, err, 0)
		end
	end
end)

task.spawn(function()
	for _ = 1, 20 do -- the server answers once this player's data is loaded
		local answer = Net.ask("GetDefense")
		if answer then
			local t = answer[1]
			for _, item in ipairs(answer[2]) do
				local b = getBase(item[1])
				if b then
					for _, m in ipairs(item[2]) do
						if not b.monsters[m[1]] then
							b.monsters[m[1]] = { s = m[2], v = m[3], t = t, hp = m[4], modelIndex = m[5], level = m[6],
								offset = m[7] or 0, boss = m[8] == true, attribute = m[9] or nil, kind = m[10] or nil,
								group = m[11] or nil, leader = m[12] == true }
						end
					end
				end
			end
			return
		end
		task.wait(0.5)
	end
end)

-- ---------------------------------------------------------------------------
-- Drawing
-- ---------------------------------------------------------------------------

-- make up to MODELS_PER_FRAME waiting fossil models, the player's own track first (a removed one, or one of a
-- track gone out of sight, is skipped)
local function buildSome()
	if #buildQueue == 0 then
		return
	end
	local myBase = player:GetAttribute("Base")
	table.sort(buildQueue, function(x, y)
		return (x[1].index == myBase and 0 or 1) < (y[1].index == myBase and 0 or 1)
	end)
	local made, keep = 0, {}
	for _, item in ipairs(buildQueue) do
		local b, m = item[1], item[2]
		if m.queued and not m.model and b.near then
			if made < MODELS_PER_FRAME then
				m.queued = nil
				m.standIn = nil
				newModel(m, b.index == myBase)
				if b.topView and m.label then
					m.label.MaxDistance = TOP_VIEW_LABEL_DISTANCE
				end
				if m.standIn then
					standIns[m] = b
				end
				made += 1
			else
				table.insert(keep, item)
			end
		end
	end
	buildQueue = keep
end

task.spawn(function()
	while true do
		task.wait(STAND_IN_RETRY)
		for m, b in pairs(standIns) do
			if not m.model or not m.standIn then
				standIns[m] = nil
			elseif templateOf(Config.Monsters.Models[m.modelIndex]) then
				standIns[m] = nil
				dropModel(m)
				queueModel(b, m)
			end
		end
	end
end)

RunService.RenderStepped:Connect(FrameMeter.wrap("DefenseView", function(dt)
	local camera = Workspace.CurrentCamera
	if not camera then
		return
	end
	buildSome()
	local now = Workspace:GetServerTimeNow()
	local eye = camera.CFrame.Position
	local lightMode = player:GetAttribute("LightMode") == true
	local hideAuras = player:GetAttribute("HideAuras") == true
	if lightMode ~= liteNow then
		liteNow = lightMode
		RarityFx.setLite(lightMode)
		for _, u in pairs(units) do
			u.auraOff = nil
		end
	end
	local animated = 0
	for index, b in pairs(bases) do
		local near = (b.frame.Position - eye).Magnitude <= (lightMode and LIGHT_DRAW_DISTANCE
			or player:GetAttribute("LowDetail") and (LIGHT_DRAW_DISTANCE + DRAW_DISTANCE) / 2 or DRAW_DISTANCE)
			and not hidden("Fossils", index) and not arenaStaged(index)
		if near ~= b.near then
			b.near = near
			for _, m in pairs(b.monsters) do
				if near then
					queueModel(b, m)
				else
					dropModel(m)
				end
			end
		end
		-- (2026-10-02, "지금도 조금씩 톡톡 끊기는 느낌": up to 120 fossils a track were moved every frame however far)
		-- a farther base's fossils every few frames (Shared/Lod), by the time that passed
		local due, step = false, 0
		if near then
			-- (measured to the field's edge, not its middle: a road beside the camera stays smooth)
			due, step = Lod.due(b, math.max(0, (b.frame.Position - eye).Magnitude - FIELD_REACH), dt)
		end
		if due then
			local dt = step
			local animate = (b.frame.Position - eye).Magnitude <= ANIM_DISTANCE
			-- (2026-10-04, "8명이 풀로 승급전 … 매끄럽게") every fossil of the base in one Workspace:BulkMoveTo (was a PivotTo
			-- each: up to 120 a track, the heaviest work of a full promotion fight); the lists kept from frame to frame
			local parts, cframes, n = b.moveParts or {}, b.moveCFrames or {}, 0
			b.moveParts, b.moveCFrames = parts, cframes
			for id, m in pairs(b.monsters) do
				if m.model then
					-- (display only) a walking fossil trots: a little hop each stride and a sway side to side
					local moving = math.abs(m.v) > 0.1 and not m.boss
					local phase = (tonumber(id) or 0) * 1.7
					local sway = moving and TROT_SWAY * math.sin(now * TROT_SWAY_SPEED + phase) or 0
					local pos, ahead = worldAt(b, sNow(m, now), m.offset + sway)
					if m.kind == "Airship" then
						pos += Vector3.new(0, AIRSHIP.Lift, 0)
					end
					if moving then
						pos += Vector3.new(0, TROT_HOP * math.abs(math.sin(now * TROT_HOP_SPEED + phase)), 0)
					end
					local place = CFrame.lookAt(pos, pos + ahead)
					if animate and m.rig and animated < FOSSIL_ANIM_MAX and (pos - eye).Magnitude <= FOSSIL_ANIM_NEAR then
						animated += 1
						place *= DinoMotion.step(m.rig, dt, math.abs(m.v))
					end
					local ps, offsets = partsOf(m)
					for k = 1, #ps do
						n += 1
						parts[n], cframes[n] = ps[k], place * offsets[k]
					end
				end
			end
			for k = #parts, n + 1, -1 do -- (fewer than last time: the rest let go)
				parts[k], cframes[k] = nil, nil
			end
			if n > 0 then
				Workspace:BulkMoveTo(parts, cframes, Enum.BulkMoveMode.FireCFrameChanged)
			end
		end
		b.heard = near and (b.frame.Position - eye).Magnitude <= HEAR_DISTANCE
		if b.heard then -- the walking fossils rattle: now and then one of them, somewhere on the track
			b.stepClock = (b.stepClock or 0) + dt
			if b.stepClock >= BONE_STEP_EVERY then
				b.stepClock = 0
				local walking = {}
				for _, m in pairs(b.monsters) do
					if m.model and math.abs(m.v) > 0.1 then
						table.insert(walking, m)
					end
				end
				if #walking > 0 then
					local m = walking[math.random(1, #walking)]
					Sfx.play("BoneStep", m.model:GetPivot().Position, 0.85 + math.random() * 0.35)
				end
			end
		end
		lodEye = eye
		expireLooks(b)
		animateUnits(b, dt, (b.frame.Position - eye).Magnitude <= ANIM_DISTANCE, hideAuras)
	end
end))

do
	local coach = { part = Instance.new("Part"), gui = Instance.new("BillboardGui"), label = Instance.new("TextLabel"),
		wait = 0, lead = nil, near = false, crowd = false, was = false, slap = nil }
	coach.part.Name = "CoachMark"
	coach.part.Size = Vector3.new(0.2, 0.2, 0.2)
	coach.part.Transparency = 1
	coach.part.Anchored, coach.part.CanCollide, coach.part.CanQuery, coach.part.CanTouch = true, false, false, false
	coach.part.Parent = fxFolder
	coach.gui.Name = "CoachMark"
	coach.gui.Size = COACH.MarkSize
	coach.gui.AlwaysOnTop = true
	coach.gui.LightInfluence = 0
	coach.gui.Enabled = false
	coach.gui.Adornee = coach.part
	coach.gui.Parent = player:WaitForChild("PlayerGui")
	coach.label.Size = UDim2.fromScale(1, 1)
	coach.label.BackgroundTransparency = 1
	coach.label.Font = Enum.Font.GothamBlack
	coach.label.Text = "⚠️ 막아요! 👋 찰싹"
	coach.label.TextScaled = true
	coach.label.TextColor3 = COACH.MarkColor
	coach.label.TextStrokeTransparency = 0
	coach.label.Parent = coach.gui

	function coach.glow(button, on, wave)
		if not button then
			return
		end
		local stroke = button:FindFirstChild("CoachGlow")
		if on and not stroke then
			stroke = Instance.new("UIStroke")
			stroke.Name = "CoachGlow"
			stroke.Color = COACH.GlowColor
			stroke.Thickness = COACH.GlowThickness
			stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			stroke.Parent = button
		elseif not on and stroke then
			stroke:Destroy()
			return
		end
		if stroke then
			stroke.Transparency = 0.6 - 0.6 * wave
		end
	end

	function coach.helpNear(root)
		local now = Workspace:GetServerTimeNow()
		local mine = player:GetAttribute("Base")
		for index, b in pairs(bases) do
			local folder = index ~= mine and b.path and b.path.length > 0 and baseFolder(index)
			local owner = folder and Players:GetPlayerByUserId(folder:GetAttribute("OwnerUserId") or 0)
			if owner and owner:GetAttribute("PromoLevel") ~= nil and owner:GetAttribute("ChallengeWave") == nil then
				for _, m in pairs(b.monsters) do
					if (worldAt(b, sNow(m, now), m.offset) - root.Position).Magnitude <= COACH.Near then
						return true
					end
				end
			end
		end
		return false
	end

	function coach.look()
		coach.lead, coach.near, coach.crowd = nil, false, false
		local index = player:GetAttribute("Base")
		local b = index and bases[index]
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		local fighting = player:GetAttribute("PromoLevel") ~= nil or player:GetAttribute("ChallengeWave") ~= nil
		if not fighting or not b or not b.path or b.path.length <= 0 or not root then
			coach.near = root ~= nil and not fighting and coach.helpNear(root)
			return
		end
		local now = Workspace:GetServerTimeNow()
		local best, count = 0, 0
		for id, m in pairs(b.monsters) do
			count += 1
			local s = sNow(m, now)
			if s / b.path.length > best then
				best, coach.lead = s / b.path.length, id
			end
			if not coach.near and (worldAt(b, s, m.offset) - root.Position).Magnitude <= COACH.Near then
				coach.near = true
			end
		end
		if best < COACH.Danger then
			coach.lead = nil
		end
		coach.crowd = count >= COACH.Crowd
	end

	RunService.Heartbeat:Connect(FrameMeter.wrap("DefenseCoach", function(dt)
		coach.wait -= dt
		if coach.wait <= 0 then
			coach.wait = COACH.Every
			coach.look()
		end
		local on = coach.lead ~= nil or coach.near or coach.crowd
		if not on and not coach.was then
			return
		end
		coach.was = on
		local now = Workspace:GetServerTimeNow()
		local index = player:GetAttribute("Base")
		local b = index and bases[index]
		local at = coach.lead and b and monsterPoint(b, coach.lead, now)
		coach.gui.Enabled = at ~= nil
		if at then
			coach.part.CFrame = CFrame.new(at + Vector3.new(0, COACH.MarkUp + COACH.Bounce * math.abs(math.sin(now * COACH.Speed)), 0))
		end
		if not coach.slap or not coach.slap.Parent then
			coach.slap = player.PlayerGui:FindFirstChild("SlapButton", true)
		end
		local wave = 0.5 + 0.5 * math.sin(os.clock() * COACH.GlowSpeed)
		coach.glow(coach.slap, coach.near or at ~= nil, wave)
		local bombs = player.PlayerGui:FindFirstChild("Bombs")
		if bombs then
			for _, k in ipairs(Config.Bombs.Kinds) do
				local button = bombs:FindFirstChild("Bomb" .. k.Id)
				coach.glow(button, coach.crowd and button ~= nil and button.Visible, wave)
			end
		end
	end))
end

-- (2026-10-02) a storm bolt (Lightning service): farm dinos within its reach hop away and yelp, a short
-- high cry in their own voice (WeatherFx draws the bolt)
local function farmJolt(x, y, z, radius)
	local yelped = false
	for model, u in pairs(units) do
		local f = u.farm
		if f and model.Parent then
			local off = Vector3.new(f.pos.X - x, 0, f.pos.Z - z)
			if off.Magnitude <= radius + f.length / 2 and math.abs(f.pos.Y - y) < radius then
				local away = off.Magnitude > 0.1 and off.Unit or Vector3.xAxis
				f.jolt = { start = os.clock(), from = f.pos, to = f.pos + away * JOLT_STUDS }
				f.mode, f.untilTime = "idle", os.clock() + JOLT_SECONDS + between(FARM_IDLE_SECONDS)
				DinoMotion.graze(unitRig(model), false)
				local species = model:GetAttribute("Species")
				if species and not yelped then -- (one cry is enough when a few are hit)
					yelped = true
					local name, pitch = DinoVoices.voice(species, model:GetAttribute("Footprint"))
					Sfx.play(name, f.pos, pitch * YELP_PITCH)
				end
			end
		end
	end
end

Net.onPush("Lightning", function(x, y, z, warnSeconds, radius)
	task.delay(warnSeconds, function()
		farmJolt(x, y, z, radius)
	end)
end)

Net.onPush("BombBlast", function(_, at, _, _, _, reach)
	if typeof(at) == "Vector3" then
		farmJolt(at.X, at.Y, at.Z, tonumber(reach) or Config.Slap.ReachBase)
	end
end)
