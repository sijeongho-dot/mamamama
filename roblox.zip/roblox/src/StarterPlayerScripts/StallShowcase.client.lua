--[[
StallShowcase: what a stall sells, standing on its roof and slowly turning (display only, this screen; 2026-10-04,
"곡괭이 상점 같은 경우 다음 곡괭이 뭔지 모델링 박아주고", "폭탄 상점도 모델링 박고"). (2026-10-04, "공중에 폭탄알이 하나 떠있다고":
they floated 6 studs over the roof, bobbing, so from afar a lone egg bomb hung in the sky; now they rest on the roof,
the stall's name over them: Bombs, Shop)

- Over my own base's ⛏️ 곡괭이 상점 (Base_Shop): the next pickaxe I can buy (ReplicatedStorage.ItemModels
  Pickaxe_T<tier + 1>), changed when my tier changes, gone at the top tier.
- Over every base's 💣 폭탄 상점 (BombStall): the two bombs side by side (Config.Bombs.Kinds' Model).
Models come from ReplicatedStorage.ItemModels (the Defense service shares them); without them nothing shows. The stalls
are looked for again every LOOK_EVERY seconds (they stream in and out).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))

local player = Players.LocalPlayer

-- display only
local LOOK_EVERY = 2 -- seconds between looks for the stalls
local SHOW_HEIGHT = 3.2 -- studs: each shown model is this tall
local ROOF_GAP = 0.05 -- studs between the roof's top and a model's bottom
local BOMB_APART = 3.4 -- studs between the two bombs' middles
local SPIN = 1.2 -- radians a second
local DRAW_DISTANCE = 220

local shows = {} -- [stall] = { models = { { model, offset } }, center = Vector3, tier = n? }

local function clean(model)
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
		elseif d:IsA("Script") or d:IsA("LocalScript") or d:IsA("ProximityPrompt") then
			d:Destroy()
		end
	end
end

-- a copy of ItemModels' `name`, its pivot at its middle, SHOW_HEIGHT tall; nil when it isn't there
local function copyOf(name)
	local models = ReplicatedStorage:FindFirstChild("ItemModels")
	local source = models and models:FindFirstChild(name)
	if not source then
		return nil
	end
	local model = Instance.new("Model")
	model.Name = "Showcase_" .. name
	source:Clone().Parent = model
	clean(model)
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position)
	model:ScaleTo(SHOW_HEIGHT / math.max(size.Y, size.X, size.Z, 0.1))
	return model
end

local function drop(stall)
	local show = shows[stall]
	if show then
		for _, m in ipairs(show.models) do
			m[1]:Destroy()
		end
		shows[stall] = nil
	end
end

local function center(stall)
	local cf, size = stall:GetBoundingBox()
	return cf.Position + Vector3.new(0, size.Y / 2 + ROOF_GAP + SHOW_HEIGHT / 2, 0)
end

local function showOver(stall, names, tier)
	drop(stall)
	local list = {}
	for _, name in ipairs(names) do
		local model = copyOf(name)
		if model then
			model.Parent = Workspace
			table.insert(list, { model, 0 })
		end
	end
	for i, m in ipairs(list) do -- (side by side; one alone in the middle, e.g. a model not in the place yet)
		m[2] = (i - (#list + 1) / 2) * BOMB_APART
	end
	if #list > 0 then
		local look = stall:GetPivot().LookVector
		shows[stall] = { models = list, center = center(stall), tier = tier,
			right = Vector3.new(look.Z, 0, -look.X).Unit }
	end
end

local BOMB_MODELS = {}
for _, k in ipairs(Config.Bombs.Kinds) do
	table.insert(BOMB_MODELS, k.Model)
end

local function look()
	local map = Workspace:FindFirstChild("Map")
	local seen = {}
	for _, folder in ipairs(map and map:GetChildren() or {}) do
		local bombStall = folder:FindFirstChild("BombStall")
		if bombStall and bombStall:IsA("Model") and not bombStall:GetAttribute("Hidden") then
			seen[bombStall] = true
			if not shows[bombStall] then
				showOver(bombStall, BOMB_MODELS)
			end
		end
		local shop = folder.Name == "Base" .. tostring(player:GetAttribute("Base")) and folder:FindFirstChild("Base_Shop")
		if shop and shop:IsA("Model") and not shop:GetAttribute("Hidden") then
			local tier = player:GetAttribute("PickaxeTier") or 1
			local nextTier = tier < #Config.Pickaxe.Tiers and tier + 1 or nil
			seen[shop] = nextTier ~= nil or nil
			if nextTier and (not shows[shop] or shows[shop].tier ~= nextTier) then
				showOver(shop, { "Pickaxe_T" .. nextTier }, nextTier)
			end
		end
	end
	for stall in pairs(shows) do
		if not seen[stall] or not stall.Parent then
			drop(stall)
		end
	end
end

task.spawn(function()
	while true do
		local ok, err = pcall(look)
		if not ok then
			warn("[StallShowcase] " .. tostring(err))
		end
		task.wait(LOOK_EVERY)
	end
end)
player:GetAttributeChangedSignal("PickaxeTier"):Connect(function()
	task.defer(look)
end)

RunService.Heartbeat:Connect(FrameMeter.wrap("StallShowcase", function()
	local camera = Workspace.CurrentCamera
	local eye = camera and camera.CFrame.Position
	local t = os.clock()
	local turn = CFrame.Angles(0, t * SPIN, 0)
	for _, show in pairs(shows) do
		if eye and (show.center - eye).Magnitude <= DRAW_DISTANCE then
			for _, m in ipairs(show.models) do
				m[1]:PivotTo(CFrame.new(show.center + show.right * m[2]) * turn)
			end
		end
	end
end))
