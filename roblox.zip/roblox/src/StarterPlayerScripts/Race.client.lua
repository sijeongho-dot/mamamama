--[[
Race: dino races on this client (the server decides everything, ServerScriptService/Services/Race).

- A "🏁 레이스 신청" prompt on every other player (only on this screen, Config.Race.ChallengeRange,
  key V) while neither of us races: Net request RaceChallenge(userId).
- Net push RaceInvite(userId, name, seconds): a small window with 수락 / 거절 (Net request RaceAnswer).
- While I race (player attribute Racing): a bar at the top (opponent, who is ready, progress of both
  from the RaceProgress attributes, time left from RaceUntil) with a 🏳️ give up button (Net request
  RaceQuit) in place of the defense line (hidden meanwhile), the big 3-2-1-GO in the middle, and a "반대 방향" warning when I ride the wrong way.
- From the countdown on, a see-through barrier (결계) along both road edges, only on my screen: it
  keeps me on the road (the server puts me back if I still get past it).
- Net push RacePads: my race's pads (purple, and the strong yellow ones), drawn on the track only on my
  screen; Net push RacePadHit(index) dims the one I used. Net push RaceObstacles: crates, pillars, walls
  and rows of cones, solid only on my screen, the hammers and spinners moving by server time just as the
  server reckons their hits (Formulas.raceSwingAngle / raceSpinAngle), and the jump sections' mud (brown,
  "🟫 진흙: 부스트 꺼짐"). Net push RaceHit: "💥 쾅!" and a thud. All of them go when the race ends.
- Every player's race record over their head, the road race's and the sky race's each (attributes
  RaceWins / RaceLosses, SkyWins / SkyLosses): "🏁 3/2 · 🦅 1/0" (wins / losses, only the ones raced). In front of
  it the collection's grade emoji, big, then the share collected: "[🥚] 2.1% · 🏁 3/2" (📖 from the first dino).
- The challenge prompt shows while I ride a dino and neither of us races; the server says no (a notice) unless both
  ride a walking dino, or both a flying one: on a flying dino it reads "🦅 하늘 레이스 신청" (2026-10-01).
- The sky race (player attribute RaceKind "Sky"): no road barrier and no wrong-way warning; Net push
  SkyRings gives my course and I see only my next ring (attribute SkyRing): a glowing yellow ring (the
  last one red) facing the way I come from the one before, with "💍 3/10 · 120m" over it that shows
  from anywhere; when the server counts me through it, it goes with a chime and the next one shows.
  Net push SkyPads: the boost pads on my way, the road's pads standing up facing the way to go (only
  on my screen); RacePadHit dims the one I flew through, as on the road.
  The bar shows the rings each of us has passed. Over my head an arrow points at my next ring, big when
  it is near, small when far (2026-10-01).
- A practice (player attribute RacePractice, 2026-10-02; started from the mount window, StarterPlayerScripts/Ride):
  the same race alone: the bar shows only me, the result says 완주 with the time (or 연습 끝) and that no
  record is kept.
- (2026-10-04) a race from a room (🎮 놀이방, StarterPlayerScripts/GameRooms) may have more than two racers (player
  attribute RaceField = how many started): the bar shows my place among them (RacePlace, "🥈 2등/4명") in place of
  the one opponent, the result my place. 🏆 랭킹전 or 🎈 일반전 (RaceResult.Ranked): the result's last line is my record
  and this week's ranked wins, or that a 🎈 일반전 (or a practice) keeps nothing.]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TextService = game:GetService("TextService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Unlock = require(Shared:WaitForChild("Unlock"))
local Lang = require(Shared:WaitForChild("Lang"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local PointerArrow = require(Shared:WaitForChild("PointerArrow"))
local Fx = require(Shared:WaitForChild("Fx"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local PROMPT_KEY = Enum.KeyCode.V
local PROMPT_PAD_KEY = Enum.KeyCode.ButtonY
local PROMPT_HOLD = 0.3
local BAR_TOP = 6 -- just under Roblox's top bar, where the defense line (ArenaLine) is: that one hides while I race
local BAR_SIZE = UDim2.fromOffset(330, 36)
local QUIT_SIZE = UDim2.fromOffset(60, 30)
local INVITE_SIZE = UDim2.fromOffset(290, 112)
local BIG_SIZE = UDim2.fromOffset(400, 90)
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_ACCEPT = Color3.fromRGB(80, 170, 90)
local COLOR_DECLINE = Color3.fromRGB(200, 80, 80)
local COLOR_QUIT = Color3.fromRGB(150, 90, 90)
local COLOR_PAD = Color3.fromRGB(170, 70, 255)
local COLOR_PAD_USED = Color3.fromRGB(90, 60, 120)
local COLOR_YELLOW = Color3.fromRGB(255, 215, 40)
local OBSTACLE_LOOKS = { -- color, material of each obstacle kind
	Crate = { Color3.fromRGB(165, 110, 60), Enum.Material.WoodPlanks },
	Pillar = { Color3.fromRGB(150, 150, 160), Enum.Material.Concrete },
	Wall = { Color3.fromRGB(220, 60, 60), Enum.Material.SmoothPlastic },
	Cones = { Color3.fromRGB(255, 130, 30), Enum.Material.SmoothPlastic },
	Barrels = { Color3.fromRGB(70, 120, 200), Enum.Material.Metal },
	Hurdle = { Color3.fromRGB(235, 50, 50), Enum.Material.SmoothPlastic },
	Swing = { Color3.fromRGB(120, 80, 50), Enum.Material.Wood },
	Spinner = { Color3.fromRGB(250, 200, 40), Enum.Material.SmoothPlastic },
}
local HURDLE_STRIPE = Color3.fromRGB(245, 245, 240)
local HURDLE_STRIPES = 6
local JUMP_SIGN_COLOR = Color3.fromRGB(255, 230, 90) -- "⬆ 점프!" over a jump section's first hurdle
local SWING_HEAD = Vector3.new(table.unpack(Config.Race.Swing.Head)) -- the hammer's head (the server hits with it)
local SPINNER_BAR = Config.Race.Spinner.Bar
local MUD_COLOR = Color3.fromRGB(110, 75, 45)
local MUD_STEP = 1.5 -- degrees of track a mud piece covers (the road curves)
local MUD_SIGN_COLOR = Color3.fromRGB(230, 190, 140)
local HIT_COLOR = Color3.fromRGB(255, 90, 60)
local HIT_SIZE = UDim2.fromOffset(220, 60)
local HIT_SECONDS = 1.2
local BACK_STEER = 0.3 -- facing (or steering) more than this against the road's way counts as backwards
local HIT_FACE_SECONDS = 0.6 -- after a hammer or a bar hit me, I keep facing along the road this long
local CAMERA_BEHIND_DOT = 0.2 -- (2026-10-04) meanwhile a camera looking along the road less than this is turned behind me
local BARREL_SIZE = 2.6
local CONE_STRIPE = Color3.fromRGB(245, 245, 240)
local CONE_SIZE = 2.4
local RECORD_HEIGHT = 2.85
local RECORD_SIZE = UDim2.fromOffset(156, 12)
local RECORD_DISTANCE = 70
local RECORD_TEXT = 9
local RECORD_BADGE = 12
local RECORD_GAP = 1
local DEX_FIRST_ICON = "📖" -- the grade emoji from the first dino, before the first title (Config.Collection.Milestones)
local RECORD_COLOR = Color3.fromRGB(150, 230, 255)
-- (2026-10-04, "vip 채팅에만 넣지말고 한정 그 칭호 처럼 [VIP]이런걸 적어놓으란 말이야. 이게 제일 먼저 오게") a VIP's tag at the
-- very front of the line over the head, in the chat tag's gold (Robux: VIP_TAG)
local VIP_TAG = "[⭐VIP]"
local VIP_COLOR = Color3.fromRGB(255, 215, 90)
local COLOR_WARN = Color3.fromRGB(255, 90, 80)
local COLOR_GO = Color3.fromRGB(120, 255, 120)
local PAD_TOP = 0.75 -- just over the road (its top is 0.65)
local PAD_HEIGHT = 0.2
local PAD_RING = 0.8 -- studs of the lighter ring around each pad
local PROMPT_EVERY = 0.5
local WRONG_WAY_SECONDS = 0.7 -- riding backwards this long shows the warning
local WRONG_WAY_SPEED = 6 -- studs a second, slower than this never warns
-- the sky race's rings (only on the racers' screens)
local RING_SEGMENTS = 24
local RING_TUBE = 1.4 -- studs thick
local RING_YELLOW = Color3.fromRGB(255, 215, 50)
local RING_RED = Color3.fromRGB(255, 70, 70)
local RING_SPIN = 0.6 -- radians a second it turns in its own plane (it shows it is a ring from the side too)
local RING_LABEL_SIZE = UDim2.fromOffset(140, 36)
-- (2026-10-01, "다음 링이 어느 방향인지 머리 위에 화살표로 … 멀면 작은 화살표, 가까우면 큰 화살표") an arrow
-- over my head pointing at my next ring: ARROW_BIG times its size at ARROW_NEAR studs or nearer, down to
-- ARROW_SMALL at ARROW_FAR or farther; yellow, red for the last ring
local ARROW_UP = 4.5 -- studs over my character's middle (was 7: "화살표 캐릭터 쪽으로 더 가깝게")
local ARROW_NEAR, ARROW_FAR = 40, 500
local ARROW_BIG, ARROW_SMALL = 1.9, 0.5 -- (2026-10-02: were 2.4, 0.6, "크기도 조금 줄이고")
-- (2026-10-04, "하늘 레이스처럼 화살표도 좀 달아주고") the road race too: over my head, the arrow points at the road's middle
-- ROAD_ARROW_AHEAD studs on along the race's way (red once ROAD_ARROW_RED of the lap is done: the finish is near)
local ROAD_ARROW_AHEAD = 45
local ROAD_ARROW_RED = 0.92
-- (2026-10-04, "상대 윤곽선이 보여야할듯") the other racers outlined, seen through the obstacles
local RIVAL_OUTLINE = Color3.fromRGB(255, 120, 60)
local SKY_PAD_THICK = 0.3 -- studs thicker than a road pad (it is seen edge-on from the side)
local SKY_PAD_LIGHT = 2.5 -- its glow's reach, × its radius
local GO_SECONDS = 1 -- "GO!" stays this long
local BARRIER_SEGMENTS = 120 -- wall pieces on each edge
local BARRIER_HEIGHT = 40 -- (2026-10-02: was 16, "지상 레이스 배리어를 더 높게")
local BARRIER_THICKNESS = 1
local BARRIER_COLOR = Color3.fromRGB(190, 140, 255)
local BARRIER_TRANSPARENCY = 0.55
local ROAD_TOP = 0.65 -- roblox/MapBuilder.lua TOP.road
local OBSTACLE_STAND_LIFT = 3.2 -- a walking character's root over its feet (Race service: STAND_LIFT)
local OBSTACLE_AIRBORNE_SPEED = 4 -- studs a second up or down: jumping, not standing on an obstacle
-- (2026-10-01, "at the race's start my view should look ahead from behind my character") the camera at the
-- start: behind my back, looking down the road, a little from above
-- (2026-10-01, "시작 시점 변경 아직 안 됐다 … 캐릭터 오른쪽면부터 시작" twice) the way to face comes from the
-- race itself, not my character, and through the whole countdown this script holds the camera itself
-- (Scriptable: Roblox's camera could turn it back), every frame; at GO it hands the camera back, still
-- looking that way
local START_CAMERA_DISTANCE = 16 -- studs behind my character
local START_CAMERA_PITCH = math.rad(18) -- looking down this much
local START_CAMERA_FOCUS_UP = 2 -- studs over my character's middle it looks at ...
local START_CAMERA_LOOK_AHEAD = 6 -- ... and this far ahead of it (the way shows over my head)
-- the result screen at the end (2026-10-01, "show a result screen when the race ends")
local RESULT_SIZE = UDim2.fromOffset(330, 262)
local RESULT_SECONDS = 15 -- it closes by itself after this long
local RESULT_BG = Color3.fromRGB(25, 28, 40)
local RESULT_POP = 0.35 -- seconds the result's title takes to pop in
local RESULT_SHAKES, RESULT_SHAKE_PX = 8, 5 -- a loss: the title shakes this many times, this many pixels
local RESULT_LOOKS = { -- title, its color, the top band's color
	Win = { "🏆 승리!", Color3.fromRGB(255, 215, 70), Color3.fromRGB(200, 150, 30) },
	Lose = { "😢 패배", Color3.fromRGB(200, 205, 225), Color3.fromRGB(90, 95, 120) },
	Draw = { "🤝 무승부", Color3.fromRGB(170, 220, 255), Color3.fromRGB(60, 110, 170) },
	-- (2026-10-02) a practice alone: the course finished, or the practice ended before that
	Finish = { "🏁 완주!", Color3.fromRGB(150, 240, 170), Color3.fromRGB(50, 130, 80) },
	Practice = { "⏱️ 기록전 끝", Color3.fromRGB(200, 205, 225), Color3.fromRGB(80, 90, 130) },
}
local RESULT_ME = Color3.fromRGB(90, 200, 120)
local RESULT_THEM = Color3.fromRGB(230, 110, 90)
local RESULT_TRACK = Color3.fromRGB(55, 60, 80)
local RESULT_OK = Color3.fromRGB(80, 150, 230)

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 15
	b.TextColor3 = Color3.new(1, 1, 1)
	b.BackgroundColor3 = color
	b.Text = text
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 10)
	return b
end

local gui = Instance.new("ScreenGui")
gui.Name = "Race"
gui.ResetOnSpawn = false
gui.DisplayOrder = 1 -- under the windows (Shared/Windows)
gui.Parent = player:WaitForChild("PlayerGui")

local function racing()
	return player:GetAttribute("Racing")
end

-- ---------------------------------------------------------------------------
-- The challenge prompt on other players
-- ---------------------------------------------------------------------------

local prompts = {} -- [other player] = ProximityPrompt
local promptText = setmetatable({}, { __mode = "k" }) -- [prompt] = the Korean last written on it

local function addPrompt(other, character)
	if prompts[other] then
		prompts[other]:Destroy()
		prompts[other] = nil
	end
	local root = character:WaitForChild("HumanoidRootPart", 10)
	if not root or other.Character ~= character then
		return
	end
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "RacePrompt"
	prompt.ActionText = "🏁 레이스 신청"
	prompt.ObjectText = other.DisplayName
	prompt.KeyboardKeyCode = PROMPT_KEY
	prompt.GamepadKeyCode = PROMPT_PAD_KEY
	prompt.HoldDuration = PROMPT_HOLD
	prompt.MaxActivationDistance = Config.Race.ChallengeRange
	prompt.RequiresLineOfSight = false
	prompt:SetAttribute("Kind", "RaceChallenge")
	prompt.Triggered:Connect(function()
		Net.request("RaceChallenge", other.UserId)
	end)
	prompt.Parent = root
	prompts[other] = prompt
end

local function watchPlayer(other)
	if other == player then
		return
	end
	other.CharacterAdded:Connect(function(character)
		addPrompt(other, character)
	end)
	if other.Character then
		task.spawn(addPrompt, other, other.Character)
	end
end
for _, other in ipairs(Players:GetPlayers()) do
	watchPlayer(other)
end
Players.PlayerAdded:Connect(watchPlayer)
Players.PlayerRemoving:Connect(function(other)
	if prompts[other] then
		prompts[other]:Destroy()
		prompts[other] = nil
	end
end)

-- ---------------------------------------------------------------------------
-- The invite window
-- ---------------------------------------------------------------------------

local invite = Instance.new("Frame")
invite.AnchorPoint = Vector2.new(0.5, 0)
invite.Position = UDim2.new(0.5, 0, 0.28, 0)
invite.Size = INVITE_SIZE
invite.BackgroundColor3 = COLOR_BG
invite.Visible = false
invite.Parent = gui
corner(invite, 14)
local inviteText = label(invite, "", UDim2.new(1, -20, 0, 54), UDim2.fromOffset(10, 4), 16)
inviteText.TextWrapped = true
local accept = button(invite, "✅ 수락", COLOR_ACCEPT, UDim2.new(0.5, -15, 0, 40), UDim2.new(0, 10, 1, -48))
local decline = button(invite, "❌ 거절", COLOR_DECLINE, UDim2.new(0.5, -15, 0, 40), UDim2.new(0.5, 5, 1, -48))
local inviteFrom, inviteName, inviteUntil, inviteKind = nil, "", 0, "Road"

local function answer(yes)
	if inviteFrom then
		Net.request("RaceAnswer", inviteFrom, yes)
	end
	inviteFrom = nil
	invite.Visible = false
end
accept.Activated:Connect(function()
	answer(true)
end)
decline.Activated:Connect(function()
	answer(false)
end)
Net.onPush("RaceInvite", function(userId, name, seconds, kind)
	inviteFrom, inviteName, inviteUntil, inviteKind = userId, name, os.clock() + seconds, kind or "Road"
	invite.Visible = true
end)

-- ---------------------------------------------------------------------------
-- The race bar, the countdown and the wrong-way warning
-- ---------------------------------------------------------------------------

local bar = Instance.new("Frame")
bar.Name = "RaceBar" -- (WeatherFx puts its line under it while it shows)
bar.AnchorPoint = Vector2.new(0.5, 0)
bar.Position = UDim2.new(0.5, 0, 0, BAR_TOP)
bar.Size = BAR_SIZE
bar.BackgroundColor3 = COLOR_BG
bar.BackgroundTransparency = 0.15
bar.Visible = false
bar.Parent = gui
corner(bar, 10)
local barText = label(bar, "", UDim2.new(1, -QUIT_SIZE.X.Offset - 14, 1, 0), UDim2.fromOffset(8, 0), 14)
barText.TextXAlignment = Enum.TextXAlignment.Left
barText.TextScaled = true
local quit = button(bar, "🏳️ 포기", COLOR_QUIT, QUIT_SIZE, UDim2.new(1, -QUIT_SIZE.X.Offset - 3, 0.5, -QUIT_SIZE.Y.Offset / 2))
quit.TextSize = 13
quit.Activated:Connect(function()
	Net.request("RaceQuit")
end)

local big = label(gui, "", BIG_SIZE, UDim2.new(0.5, -BIG_SIZE.X.Offset / 2, 0.3, 0), 60)
big.TextStrokeTransparency = 0.2
big.Visible = false

local function opponent()
	return Players:GetPlayerByUserId(player:GetAttribute("RaceOpponent") or 0)
end

local PLACES = { "🥇", "🥈", "🥉" }

-- (2026-10-04) more than two racers: my place among them, "🥈 2등/4명"
local function placeText()
	local place = player:GetAttribute("RacePlace") or 1
	return string.format("%s %d등/%d명", PLACES[place] or "🏅", place, player:GetAttribute("RaceField") or 1)
end

local function percent(p)
	return math.floor((p and p:GetAttribute("RaceProgress") or 0) * 100 + 0.5)
end

local function timeLeft()
	return math.max(0, (player:GetAttribute("RaceUntil") or 0) - Workspace:GetServerTimeNow())
end

local KIND_TEXT = { Road = "🏁 지상", Sky = "🦅 하늘" }

local function nextMedal(kind, seconds)
	for i = #(Config.Race.Medals[kind] or {}), 1, -1 do
		local m = Config.Race.Medals[kind][i]
		if m.Seconds and seconds <= m.Seconds then
			return m
		end
	end
	return nil
end

local goUntil = 0
local skyCourse = nil -- my sky race's rings (Net push SkyRings)
local lastCount = nil -- the countdown number last beeped
local backwards = 0
local lastPos = nil

local function updateHud(dt)
	if inviteFrom and os.clock() > inviteUntil then
		inviteFrom = nil
		invite.Visible = false
	end
	if inviteFrom then
		inviteText.Text = string.format(inviteKind == "Sky" and "🦅 %s님이 하늘 레이스를 신청했어요! 나는 공룡을 타고 수락 (%d초)"
			or "🏁 %s님이 공룡 레이스를 신청했어요! (%d초)", inviteName, math.ceil(inviteUntil - os.clock()))
	end
	local state = racing()
	local other = opponent()
	local name = other and other.DisplayName or "?"
	bar.Visible = state ~= nil
	local bigText, bigColor = nil, Color3.new(1, 1, 1)
	local sky = player:GetAttribute("RaceKind") == "Sky"
	local practice = player:GetAttribute("RacePractice") == true
	if practice and state == "Gather" then
		barText.Text = string.format(sky and "⏱️ 기록전 · 나는 공룡을 타면 출발 준비 · %d초"
			or "⏱️ 기록전 · 🦖 걷는 공룡을 타면 출발 준비 · %d초",
			math.ceil(timeLeft()))
	elseif practice and state == "Countdown" then
		barText.Text = "⏱️ 기록전 · 곧 출발!"
		bigText = tostring(math.max(1, math.ceil(timeLeft())))
		goUntil = os.clock() + GO_SECONDS
		if bigText ~= lastCount then
			lastCount = bigText
			Sfx.play("CountTick")
		end
	elseif practice and state == "Go" then
		local left = timeLeft()
		local went = (sky and Config.Race.Sky.TimeLimit or Config.Race.TimeLimit) - left
		if sky then
			barText.Text = string.format("💍 기록전 · %d/%d · ⏱ %.1f초", (player:GetAttribute("SkyRing") or 1) - 1,
				skyCourse and #skyCourse or 0, went)
		else
			local m = nextMedal("Road", went)
			barText.Text = m and string.format("⏱️ %d%% · %.1f초 · %s %d초 안에!", percent(player), went, m.Icon, m.Seconds)
				or string.format("⏱️ %d%% · %.1f초", percent(player), went)
		end
	elseif state == "Gather" and not other then -- (2026-10-04: more than two racers)
		barText.Text = string.format(sky and "🦅 %d명 레이스 · 나는 공룡을 타면 준비! 나 %s · %d초"
			or "🏁 %d명 레이스 · 🦖 걷는 공룡을 타면 준비! 나 %s · %d초", player:GetAttribute("RaceField") or 0,
			player:GetAttribute("RaceReady") and "✅" or "⏳", math.ceil(timeLeft()))
	elseif state == "Countdown" and not other then
		barText.Text = string.format("🏁 %d명 레이스 · 곧 출발!", player:GetAttribute("RaceField") or 0)
		bigText = tostring(math.max(1, math.ceil(timeLeft())))
		goUntil = os.clock() + GO_SECONDS
		if bigText ~= lastCount then
			lastCount = bigText
			Sfx.play("CountTick")
		end
	elseif state == "Go" and not other then
		local left = timeLeft()
		barText.Text = sky and string.format("💍 나 %d/%d · %s · ⏱ %d:%02d", (player:GetAttribute("SkyRing") or 1) - 1,
			skyCourse and #skyCourse or 0, placeText(), math.floor(left / 60), math.floor(left % 60))
			or string.format("🏁 나 %d%% · %s · ⏱ %d:%02d", percent(player), placeText(), math.floor(left / 60),
				math.floor(left % 60))
	elseif state == "Gather" and sky then
		barText.Text = string.format("🦅 vs %s · 나는 공룡을 타면 준비! 나 %s 상대 %s · %d초",
			name, player:GetAttribute("RaceReady") and "✅" or "⏳",
			other and other:GetAttribute("RaceReady") and "✅" or "⏳", math.ceil(timeLeft()))
	elseif state == "Gather" then
		barText.Text = string.format("🏁 vs %s · 🦖 걷는 공룡을 타면 준비! 나 %s 상대 %s · %d초",
			name, player:GetAttribute("RaceReady") and "✅" or "⏳",
			other and other:GetAttribute("RaceReady") and "✅" or "⏳", math.ceil(timeLeft()))
	elseif state == "Countdown" then
		barText.Text = string.format("🏁 vs %s · 곧 출발!", name)
		bigText = tostring(math.max(1, math.ceil(timeLeft())))
		goUntil = os.clock() + GO_SECONDS
		if bigText ~= lastCount then -- a beep with each number
			lastCount = bigText
			Sfx.play("CountTick")
		end
	elseif state == "Go" and sky then
		local left = timeLeft()
		local all = skyCourse and #skyCourse or 0
		barText.Text = string.format("💍 나 %d/%d · %s %d/%d · ⏱ %d:%02d", (player:GetAttribute("SkyRing") or 1) - 1, all,
			name, (other and other:GetAttribute("SkyRing") or 1) - 1, all, math.floor(left / 60), math.floor(left % 60))
	elseif state == "Go" then
		local left = timeLeft()
		barText.Text = string.format("🏁 나 %d%% · %s %d%% · ⏱ %d:%02d", percent(player), name, percent(other),
			math.floor(left / 60), math.floor(left % 60))
	end
	if state == "Go" and os.clock() < goUntil then
		bigText, bigColor = "GO! 🏁", COLOR_GO
		if lastCount ~= "GO" then
			lastCount = "GO"
			Sfx.play("CountGo")
		end
	end
	-- the wrong way: riding against the arrows for a moment
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if state == "Go" and root and not sky then
		local pos = Vector3.new(root.Position.X, 0, root.Position.Z)
		if lastPos and dt > 0 then
			local v = (pos - lastPos) / dt
			local a = math.rad(Formulas.compassAngle(pos.X, pos.Z))
			local ahead = Vector3.new(math.cos(a), 0, math.sin(a))
			if v.Magnitude > WRONG_WAY_SPEED and v:Dot(ahead) < -0.5 * v.Magnitude then
				backwards += dt
			else
				backwards = 0
			end
		end
		lastPos = pos
		if backwards > WRONG_WAY_SECONDS and not bigText then
			bigText, bigColor = "⚠️ 반대 방향! 화살표 쪽으로", COLOR_WARN
		end
	else
		lastPos, backwards = nil, 0
	end
	big.Visible = bigText ~= nil
	if bigText then
		big.Text = bigText
		big.TextColor3 = bigColor
		big.TextScaled = #bigText > 8
	end
end

local sincePrompts = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("Race", function(dt)
	updateHud(dt)
	sincePrompts += dt
	if sincePrompts >= PROMPT_EVERY then
		sincePrompts = 0
		local riding = player:GetAttribute("Riding")
		local sky = riding and player:GetAttribute("Flying")
		for other, prompt in pairs(prompts) do
			-- (only while I ride a dino: "아무것도 안 타고 있으면 레이스 신청 버튼이 안 나타나게", 2026-10-02)
			prompt.Enabled = riding and racing() == nil and other:GetAttribute("Racing") == nil and Unlock.usable("GameRooms") or false
			-- (2026-10-02, "창 글자가 커졌다 작아졌다하는데": writing the Korean again every PROMPT_EVERY undid its
			-- translation each time, so the prompt flicked between the two widths) only when road/sky changes
			local text = sky and "🦅 하늘 레이스 신청" or "🏁 레이스 신청"
			if promptText[prompt] ~= text then
				promptText[prompt] = text
				prompt.ActionText = text
			end
		end
	end
end))

-- ---------------------------------------------------------------------------
-- My race's purple pads
-- ---------------------------------------------------------------------------

local padFolder = nil
local pads = {}

local function clearPads()
	if padFolder then
		padFolder:Destroy()
		padFolder = nil
	end
	pads = {}
end

local function disc(name, at, radius, color, parent)
	local p = Instance.new("Part")
	p.Name = name
	p.Shape = Enum.PartType.Cylinder
	p.Size = Vector3.new(PAD_HEIGHT, radius * 2, radius * 2)
	p.CFrame = CFrame.new(at) * CFrame.Angles(0, 0, math.pi / 2)
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch = true, false, false, false
	p.Material = Enum.Material.Neon
	p.Color = color
	p.CastShadow = false
	p.Parent = parent
	return p
end

Net.onPush("RacePads", function(list)
	clearPads()
	padFolder = Instance.new("Folder")
	padFolder.Name = "RacePads"
	for i, xz in ipairs(list) do
		local at = Vector3.new(xz[1], PAD_TOP, xz[2])
		local color = xz[3] == "Yellow" and COLOR_YELLOW or COLOR_PAD
		local ring = disc("PadRing", at, Config.Race.PadRadius + PAD_RING, color:Lerp(Color3.new(1, 1, 1), 0.5), padFolder)
		ring.Transparency = 0.4
		pads[i] = { disc("Pad", at + Vector3.new(0, 0.05, 0), Config.Race.PadRadius, color, padFolder), ring }
	end
	padFolder.Parent = Workspace
end)

-- (2026-10-01) the sky race's pads: the same discs standing up, facing the way to fly
Net.onPush("SkyPads", function(list)
	clearPads()
	if type(list) ~= "table" then
		return
	end
	padFolder = Instance.new("Folder")
	padFolder.Name = "SkyPads"
	local radius = Config.Race.Sky.PadRadius
	for i, pad in ipairs(list) do
		local at, facing = pad[1], pad[3]
		if typeof(at) == "Vector3" and typeof(facing) == "Vector3" and facing.Magnitude > 0.01 then
			-- (a cylinder's round faces are along its X: turn X to the way)
			local frame = CFrame.lookAt(at, at + facing) * CFrame.Angles(0, math.pi / 2, 0)
			local color = pad[2] == "Yellow" and COLOR_YELLOW or COLOR_PAD
			local ring = disc("PadRing", at, radius + PAD_RING, color:Lerp(Color3.new(1, 1, 1), 0.5), padFolder)
			ring.CFrame = frame
			ring.Transparency = 0.4
			local face = disc("Pad", at, radius, color, padFolder)
			face.CFrame = frame
			face.Size += Vector3.new(SKY_PAD_THICK, 0, 0)
			local light = Instance.new("PointLight")
			light.Color = color
			light.Range = radius * SKY_PAD_LIGHT
			light.Parent = face
			pads[i] = { face, ring }
		end
	end
	padFolder.Parent = Workspace
end)

-- my race's obstacles: solid parts only on my screen (each leaves a lane free; the server checks I go round)
local obstacleFolder = nil
local movers = {} -- the swinging and spinning ones: function(t) placing them at time t
local obstacleList = nil -- this race's obstacles as the server sent them (Formulas.raceObstacleHit)
local faceUntil = 0 -- till then my character faces along the road (after a hit, or turned round at an obstacle)
local safeSpot = nil -- my last spot clear of every obstacle

local function clearObstacles()
	if obstacleFolder then
		obstacleFolder:Destroy()
		obstacleFolder = nil
	end
	movers = {}
	obstacleList, safeSpot = nil, nil
end

-- my own racer, every frame: riding, the character floats at the mount's height and steps up onto
-- anything lower, so walking into a crate or a hurdle would just go over it. Standing on one (or inside)
-- stops me at its face at once (2026-10-04; was back to where I was clear of them) (the server checks the same, Formulas.raceObstacleHit);
-- a hurdle is passed by jumping
RunService.Heartbeat:Connect(FrameMeter.wrap("Race", function()
	if not obstacleList or racing() ~= "Go" then
		return
	end
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = humanoid and humanoid.RootPart
	if not root then
		return
	end
	-- (2026-10-03, "망치 막대에서 발생한 문젠데 또?": a hit still turned the character round) whatever turns me, every
	-- frame of a road race: no spinning, and facing against the race's way while not steering that way is put
	-- right at once (steering back, or sideways round something, is left alone)
	root.AssemblyAngularVelocity = Vector3.zero
	do
		local a = math.rad(Formulas.compassAngle(root.Position.X, root.Position.Z))
		local ahead = Vector3.new(math.cos(a), 0, math.sin(a))
		local move = Vector3.new(humanoid.MoveDirection.X, 0, humanoid.MoveDirection.Z)
		local look = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z)
		local steeringBack = move.Magnitude > 0.1 and move.Unit:Dot(ahead) < -BACK_STEER
		if not steeringBack and look.Magnitude > 0.01 and look.Unit:Dot(ahead) < -BACK_STEER then
			local face = move.Magnitude > 0.1 and move.Unit or ahead
			root.CFrame = CFrame.lookAt(root.Position, root.Position + face)
		end
	end
	local state = humanoid:GetState()
	local up = state == Enum.HumanoidStateType.Jumping or state == Enum.HumanoidStateType.Freefall
		or math.abs(root.AssemblyLinearVelocity.Y) > OBSTACLE_AIRBORNE_SPEED
	local pos = Vector3.new(root.Position.X, 0, root.Position.Z)
	local feet = root.Position.Y - (player:GetAttribute("RideDrop") or OBSTACLE_STAND_LIFT)
	if Formulas.raceObstacleHit(obstacleList, pos, feet, up, ROAD_TOP, 0) then
		if safeSpot then
			-- (2026-10-04, "자꾸 장애물에 밀려나는게 조금 부자연": was back to the last clear spot) stopped at its face
			local out = Formulas.raceClearPoint(obstacleList, safeSpot, pos, feet, up, ROAD_TOP, 0)
			root.CFrame = root.CFrame + Vector3.new(out.X - pos.X, 0, out.Z - pos.Z)
			root.AssemblyLinearVelocity = Vector3.new(0, math.min(root.AssemblyLinearVelocity.Y, 0), 0)
			root.AssemblyAngularVelocity = Vector3.zero
			-- (2026-10-03) face along the road again a moment; (2026-10-04) every time, the camera too: put back, it
			-- could end up looking backwards (faceUntil, the camera fix below)
			faceUntil = os.clock() + HIT_FACE_SECONDS
		end
	elseif not Formulas.raceObstacleHit(obstacleList, pos, -math.huge, false, ROAD_TOP, 0) then
		safeSpot = pos
	end
end))

RunService.RenderStepped:Connect(FrameMeter.wrap("Race", function()
	local t = Workspace:GetServerTimeNow() -- (the server reckons their hits at the same time)
	for _, move in ipairs(movers) do
		move(t)
	end
end))

local function block(name, size, cf, color, material, parent)
	local p = Instance.new("Part")
	p.Name = name
	p.Size = size
	p.CFrame = cf
	-- (2026-10-03, "지상 레이스 시에 장애물 부딪히면 또 뒤도네": bumping into a solid crate or wall at riding speed spun the
	-- character round) nothing of a race's obstacles is solid: the obstacle guard below puts me back where I was clear
	-- of them (and the server checks the same), so they still stop me, without the knock
	p.Anchored, p.CanCollide, p.CanTouch = true, false, false
	p.Color = color
	p.Material = material
	p.Parent = parent
	return p
end

-- a race's obstacles and mud in a new folder (not yet in the Workspace), and its moving ones' movers
local function buildObstacles(list, mud, name)
	local lastHurdle = nil
	local obstacleFolder = Instance.new("Folder")
	obstacleFolder.Name = name
	local movers = {}
	for _, o in ipairs(list) do
		local x, z, kind, across, along, height, angle = table.unpack(o)
		local a = math.rad(angle)
		local base = Vector3.new(x, ROAD_TOP, z)
		local frame = CFrame.lookAt(base, base + Vector3.new(math.cos(a), 0, math.sin(a))) -- along the road
		local look = OBSTACLE_LOOKS[kind] or OBSTACLE_LOOKS.Crate
		if kind == "Pillar" then
			local p = block("Pillar", Vector3.new(height, across, across), frame * CFrame.new(0, height / 2, 0)
				* CFrame.Angles(0, 0, math.pi / 2), look[1], look[2], obstacleFolder)
			p.Shape = Enum.PartType.Cylinder
		elseif kind == "Cones" then -- a row of striped cones and an invisible wall between them
			local wall = block("ConeWall", Vector3.new(across, height, along), frame * CFrame.new(0, height / 2, 0), look[1],
				look[2], obstacleFolder)
			wall.Transparency = 1
			local n = math.max(2, math.floor(across / CONE_SIZE))
			for k = 0, n - 1 do
				local offset = (k + 0.5) / n * across - across / 2
				for level = 0, 2 do
					local size = CONE_SIZE * (1 - level * 0.28)
					local cone = block("Cone", Vector3.new(size, height / 3, size),
						frame * CFrame.new(offset, height / 6 + level * height / 3, 0), level == 1 and CONE_STRIPE or look[1],
						look[2], obstacleFolder)
					cone.CanCollide = false
				end
			end
		elseif kind == "Barrels" then -- a heap of barrels (one solid box round them, the barrels on show)
			local box = block("BarrelHeap", Vector3.new(across, height, along), frame * CFrame.new(0, height / 2, 0), look[1],
				look[2], obstacleFolder)
			box.Transparency = 1
			local nx, nz = math.max(1, math.floor(across / BARREL_SIZE)), math.max(1, math.floor(along / BARREL_SIZE))
			for i = 0, nx - 1 do
				for j = 0, nz - 1 do
					local h = (i + j) % 2 == 0 and height or height * 0.6
					local barrel = block("Barrel", Vector3.new(h, BARREL_SIZE * 0.95, BARREL_SIZE * 0.95),
						frame * CFrame.new((i + 0.5) / nx * across - across / 2, h / 2, (j + 0.5) / nz * along - along / 2)
							* CFrame.Angles(0, 0, math.pi / 2), (i + j) % 3 == 0 and HURDLE_STRIPE or look[1], look[2], obstacleFolder)
					barrel.Shape = Enum.PartType.Cylinder
					barrel.CanCollide = false
				end
			end
		elseif kind == "Hurdle" then -- a low striped bar right across the road: jump it
			local n = HURDLE_STRIPES
			for k = 0, n - 1 do
				block("Hurdle", Vector3.new(across / n, height, along), frame * CFrame.new((k + 0.5) / n * across - across / 2,
					height / 2, 0), k % 2 == 0 and look[1] or HURDLE_STRIPE, look[2], obstacleFolder)
			end
			if not lastHurdle or math.abs(Formulas.angleStep(lastHurdle, angle)) > 2 * Config.Race.JumpSpacingDegrees then
				-- the first hurdle of a jump section: a sign over it
				local anchor = block("JumpSign", Vector3.one, frame * CFrame.new(0, height + 4, 0), look[1], look[2], obstacleFolder)
				anchor.Transparency, anchor.CanCollide = 1, false
				local sign = Instance.new("BillboardGui")
				sign.Size = UDim2.fromOffset(120, 34)
				sign.MaxDistance = 160
				local t = label(sign, "⬆ 점프!", UDim2.fromScale(1, 1), UDim2.new(), 22)
				t.TextColor3 = JUMP_SIGN_COLOR
				t.TextStrokeTransparency = 0.2
				sign.Parent = anchor
			end
			lastHurdle = angle
		elseif kind == "Swing" then -- a gallows over the road and a hammer swinging across it
			for _, side in ipairs({ -1, 1 }) do
				block("Post", Vector3.new(1, height, 1), frame * CFrame.new(side * (across / 2 + 0.5), height / 2, 0), look[1],
					look[2], obstacleFolder)
			end
			block("Beam", Vector3.new(across + 2, 1, 1), frame * CFrame.new(0, height, 0), look[1], look[2], obstacleFolder)
			local armLength = height - SWING_HEAD.Y / 2 - 0.6
			local arm = block("Arm", Vector3.new(0.6, armLength, 0.6), frame, look[1], look[2], obstacleFolder)
			arm.CanCollide = false
			local head = block("Hammer", SWING_HEAD, frame, OBSTACLE_LOOKS.Wall[1], OBSTACLE_LOOKS.Wall[2], obstacleFolder)
			-- (2026-10-03, "망치에 맞거나 막대에 맞으면 캐릭터가 뒤도는 버그": the moving part shoved and spun the
			-- character; the server's hitByMovers does the bounce)
			head.CanCollide = false
			local pivot = frame * CFrame.new(0, height, 0)
			table.insert(movers, function(t)
				local swing = pivot * CFrame.Angles(0, 0, Formulas.raceSwingAngle(o, t))
				arm.CFrame = swing * CFrame.new(0, -armLength / 2, 0)
				head.CFrame = swing * CFrame.new(0, -armLength - SWING_HEAD.Y / 2 + 0.3, 0)
			end)
		elseif kind == "Spinner" then -- a low bar turning flat on the road: jump it or slip past
			local hub = block("Hub", Vector3.new(height + 1, 2.4, 2.4), frame * CFrame.new(0, (height + 1) / 2, 0)
				* CFrame.Angles(0, 0, math.pi / 2), OBSTACLE_LOOKS.Wall[1], look[2], obstacleFolder)
			hub.Shape = Enum.PartType.Cylinder
			local bar = block("SpinBar", Vector3.new(across, SPINNER_BAR, SPINNER_BAR), frame, look[1], look[2], obstacleFolder)
			bar.CanCollide = false -- (as the hammer: it spun the character round)
			local center = frame * CFrame.new(0, height - SPINNER_BAR / 2, 0)
			table.insert(movers, function(t)
				bar.CFrame = center * CFrame.Angles(0, Formulas.raceSpinAngle(o, t), 0)
			end)
		else -- a crate or a wall
			block(kind, Vector3.new(across, height, along), frame * CFrame.new(0, height / 2, 0), look[1], look[2],
				obstacleFolder)
		end
	end
	-- the jump sections' mud: brown pieces over the road (a pad's boost ends there), a sign at the start
	local c = Config.Race
	for _, m in ipairs(mud or {}) do
		local steps = math.max(1, math.ceil((m[2] - m[1]) / MUD_STEP))
		local stepDeg = (m[2] - m[1]) / steps
		local length = 2 * c.Radius * math.sin(math.rad(stepDeg) / 2) + 1
		for k = 0, steps - 1 do
			local a = math.rad(m[1] + (k + 0.5) * stepDeg)
			local at = Vector3.new(math.sin(a) * c.Radius, ROAD_TOP + 0.03, -math.cos(a) * c.Radius)
			local piece = block("Mud", Vector3.new(c.Width, 0.06, length),
				CFrame.lookAt(at, at + Vector3.new(math.cos(a), 0, math.sin(a))), MUD_COLOR, Enum.Material.Mud, obstacleFolder)
			piece.CanCollide, piece.CanQuery = false, false
		end
		local a = math.rad(m[1])
		local anchor = block("MudSign", Vector3.one,
			CFrame.new(math.sin(a) * c.Radius, ROAD_TOP + 7, -math.cos(a) * c.Radius), MUD_COLOR, Enum.Material.Mud, obstacleFolder)
		anchor.Transparency, anchor.CanCollide = 1, false
		local sign = Instance.new("BillboardGui")
		sign.Size = UDim2.fromOffset(170, 30)
		sign.MaxDistance = 160
		local t = label(sign, "🟫 진흙: 부스트 꺼짐, 하나씩 점프!", UDim2.fromScale(1, 1), UDim2.new(), 16)
		t.TextColor3 = MUD_SIGN_COLOR
		t.TextStrokeTransparency = 0.2
		sign.Parent = anchor
	end
	return obstacleFolder, movers
end

Net.onPush("RaceObstacles", function(list, mud)
	clearObstacles()
	obstacleList = list
	obstacleFolder, movers = buildObstacles(list, mud, "RaceObstacles")
	obstacleFolder.Parent = Workspace
end)

-- a hammer or a spinner hit me (the server bounced me back, still riding): "💥 쾅!" and a thud, and I keep
-- facing along the road a moment (2026-10-03: hits turned the character round; faceUntil, by the obstacle guard)
RunService.Heartbeat:Connect(FrameMeter.wrap("Race", function()
	if os.clock() > faceUntil then
		return
	end
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = humanoid and humanoid.RootPart
	if not root then
		return
	end
	local a = math.rad(Formulas.compassAngle(root.Position.X, root.Position.Z))
	local ahead = Vector3.new(math.cos(a), 0, math.sin(a)) -- the race's way round at this spot
	root.CFrame = CFrame.lookAt(root.Position, root.Position + ahead)
	root.AssemblyAngularVelocity = Vector3.zero
end))

-- (2026-10-04, "지상레이스하면 밑에 돌아가는 막대에 타이밍잘맞게 점프해서 부딪히면 시점이 뒤로 쑥 돌아감") bounced back by a
-- spinner or a hammer (the server) or put back off an obstacle (above), a phone's camera that follows the character
-- swung round to look back down the road: while faceUntil lasts, a camera looking back is turned behind me again,
-- looking along the race's way (its distance and its up-down kept), after Roblox's camera each frame
RunService:BindToRenderStep("RaceHitCamera", Enum.RenderPriority.Camera.Value + 1, FrameMeter.wrap("Race", function()
	if os.clock() > faceUntil or not racing() then
		return
	end
	local camera = Workspace.CurrentCamera
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not camera or not root or camera.CameraType ~= Enum.CameraType.Custom then
		return
	end
	local a = math.rad(Formulas.compassAngle(root.Position.X, root.Position.Z))
	local ahead = Vector3.new(math.cos(a), 0, math.sin(a))
	local look = camera.CFrame.LookVector
	local flatLook = Vector3.new(look.X, 0, look.Z)
	if flatLook.Magnitude < 1e-3 or flatLook.Unit:Dot(ahead) >= CAMERA_BEHIND_DOT then
		return
	end
	local focus = camera.Focus.Position
	local distance = (camera.CFrame.Position - focus).Magnitude
	local up = math.clamp(look.Y, -0.95, 0.95)
	local dir = ahead * math.sqrt(1 - up * up) + Vector3.new(0, up, 0)
	camera.CFrame = CFrame.lookAt(focus - dir * distance, focus)
end))

-- (2026-10-04, "레이스 경우에 자꾸 장애물에 밀려나는게 조금 부자연": the server put me back at once and tossed me up)
-- flown back (dx, dz) studs along the road in an arc over `seconds`, still riding: the way along held by a
-- LinearVelocity, the arc up and down by gravity
local function bounceBack(dx, dz, studs, seconds)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root or not dx or not studs or not seconds or seconds <= 0 then
		return
	end
	local old = root:FindFirstChild("RaceBounce")
	if old then
		old:Destroy()
	end
	local at = Instance.new("Attachment")
	at.Name = "RaceBounce"
	at.Parent = root
	local push = Instance.new("LinearVelocity")
	push.Attachment0 = at
	push.VelocityConstraintMode = Enum.VelocityConstraintMode.Plane
	push.PrimaryTangentAxis, push.SecondaryTangentAxis = Vector3.xAxis, Vector3.zAxis
	push.RelativeTo = Enum.ActuatorRelativeTo.World
	push.PlaneVelocity = Vector2.new(dx, dz) * (studs / seconds)
	push.MaxForce = math.huge
	push.Parent = at
	root.AssemblyLinearVelocity = Vector3.new(dx * studs / seconds, Workspace.Gravity * seconds / 2, dz * studs / seconds)
	task.delay(seconds, function()
		at:Destroy()
	end)
end

Net.onPush("RaceHit", function(kind, dx, dz, studs, seconds)
	Sfx.play("SlapHit")
	faceUntil = os.clock() + math.max(HIT_FACE_SECONDS, (tonumber(seconds) or 0) + 0.2)
	bounceBack(tonumber(dx), tonumber(dz), tonumber(studs), tonumber(seconds))
	local gui = player.PlayerGui:FindFirstChild("RaceHit") or Instance.new("ScreenGui")
	gui.Name = "RaceHit"
	gui.ResetOnSpawn = false
	gui:ClearAllChildren()
	local t = label(gui, kind == "Swing" and "💥 쾅! 망치에 맞았어요" or "💥 쾅! 막대에 걸렸어요", HIT_SIZE,
		UDim2.new(0.5, -HIT_SIZE.X.Offset / 2, 0.32, 0), 26)
	t.TextColor3 = HIT_COLOR
	t.TextStrokeTransparency = 0.2
	gui.Parent = player.PlayerGui
	task.delay(HIT_SECONDS, function()
		if t.Parent then
			t:Destroy()
		end
	end)
end)

Net.onPush("RacePadHit", function(index)
	local pad = pads[index]
	if pad then
		pad[1].Color = COLOR_PAD_USED
		pad[1].Material = Enum.Material.SmoothPlastic
		pad[2].Transparency = 0.85
		local light = pad[1]:FindFirstChildOfClass("PointLight") -- (a sky pad's glow)
		if light then
			light.Enabled = false
		end
	end
end)

-- ---------------------------------------------------------------------------
-- The barrier along both road edges while the race is on
-- ---------------------------------------------------------------------------

local barrier = nil

local function buildBarrier()
	local c = Config.Race
	barrier = Instance.new("Folder")
	barrier.Name = "RaceBarrier"
	for _, r in ipairs({ c.Radius - c.Width / 2 - BARRIER_THICKNESS / 2, c.Radius + c.Width / 2 + BARRIER_THICKNESS / 2 }) do
		local length = 2 * r * math.sin(math.pi / BARRIER_SEGMENTS) + BARRIER_THICKNESS
		for k = 0, BARRIER_SEGMENTS - 1 do
			local a = (k + 0.5) * 2 * math.pi / BARRIER_SEGMENTS
			local at = Vector3.new(math.sin(a) * r, ROAD_TOP + BARRIER_HEIGHT / 2, -math.cos(a) * r)
			local wall = Instance.new("Part")
			wall.Name = "Wall"
			wall.Size = Vector3.new(BARRIER_THICKNESS, BARRIER_HEIGHT, length)
			wall.CFrame = CFrame.lookAt(at, at + Vector3.new(math.cos(a), 0, math.sin(a))) -- along the road
			wall.Anchored, wall.CanCollide, wall.CanQuery, wall.CanTouch = true, true, false, false
			wall.Material = Enum.Material.ForceField
			wall.Color = BARRIER_COLOR
			wall.Transparency = BARRIER_TRANSPARENCY
			wall.CastShadow = false
			wall.Parent = barrier
		end
	end
	barrier.Parent = Workspace
end

-- the way the race starts: down the road from the start boxes (the server's Race.startBox), or from my
-- spot to the sky course's first ring
local function startAhead(root)
	local ahead
	if player:GetAttribute("RaceKind") == "Sky" then
		local first = skyCourse and skyCourse[1]
		ahead = first and Vector3.new(first.X - root.Position.X, 0, first.Z - root.Position.Z)
	else
		local c = Config.Race
		local a = math.rad(c.FinishAngle - c.StartBack)
		ahead = Vector3.new(math.cos(a), 0, math.sin(a))
	end
	return ahead and ahead.Magnitude > 1e-3 and ahead.Unit or nil
end

-- through the countdown: my character turned that way and the camera held right behind it
local holding = nil -- the RenderStepped connection while the camera is held

local function releaseStart()
	if not holding then
		return
	end
	holding:Disconnect()
	holding = nil
	local camera = Workspace.CurrentCamera
	if camera and camera.CameraType == Enum.CameraType.Scriptable then
		camera.CameraType = Enum.CameraType.Custom -- (Roblox's camera goes on from where it looks now)
	end
end

local function holdStart()
	local camera = Workspace.CurrentCamera
	if holding or not camera then
		return
	end
	camera.CameraType = Enum.CameraType.Scriptable
	holding = RunService.RenderStepped:Connect(FrameMeter.wrap("Race", function()
		if racing() ~= "Countdown" then
			releaseStart()
			return
		end
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		local look = root and startAhead(root)
		if not look then
			return
		end
		if root.CFrame.LookVector:Dot(look) < 0.999 then -- (mine to turn: it shows on every screen)
			root.CFrame = CFrame.lookAt(root.Position, root.Position + look)
		end
		local focus = root.Position + Vector3.new(0, START_CAMERA_FOCUS_UP, 0)
		local back = -look * math.cos(START_CAMERA_PITCH) + Vector3.yAxis * math.sin(START_CAMERA_PITCH)
		camera.CFrame = CFrame.lookAt(focus + back * START_CAMERA_DISTANCE, focus + look * START_CAMERA_LOOK_AHEAD)
	end))
end

player:GetAttributeChangedSignal("Racing"):Connect(function()
	if racing() ~= nil then
		Windows.closeAll()
	end
	if racing() == nil then
		clearPads()
		clearObstacles()
	end
	if racing() == "Countdown" then -- the camera behind me, looking down the road (or to the first ring)
		holdStart()
	else
		releaseStart()
	end
	local on = (racing() == "Countdown" or racing() == "Go") and player:GetAttribute("RaceKind") ~= "Sky"
	if on and not barrier then
		buildBarrier()
	elseif not on and barrier then
		barrier:Destroy()
		barrier = nil
	end
	local line = player.PlayerGui:FindFirstChild("ArenaLine") -- the defense line (Placement) sits where the bar is
	if line and line:IsA("ScreenGui") then
		line.Enabled = racing() == nil
	end
end)

-- ---------------------------------------------------------------------------
-- Every player's race record over their head
-- ---------------------------------------------------------------------------

-- (2026-10-04, "머리 위 칭호에 도감 수집률 이모지 각 등급에 따른 거 그거 넣어줘") the line leads with the collection's
-- grade emoji, big: the title's own (🥚 → 🌱 → … → 👑, Farm: DexTitle), DEX_FIRST_ICON from the first dino before the first
-- title; then the title's name and the share collected (Farm: CollectionCount, Formulas.collectionPercentText: "2.1%").
-- Written here in my language (KeepText: Translate leaves it) so its width is known and the emoji sits right beside it,
-- the two centered over the head. Returns the emoji (nil: nothing collected) and the line.
local function recordLine(other)
	local code = Lang.code(player)
	local a = function(name)
		return other:GetAttribute(name) or 0
	end
	local icon, parts = nil, {}
	-- (2026-10-04, "내 vip나 도감, 승패기록도 설정에서 키고 끌 수 있게 하자") each player's own 보기 설정 switches (Settings:
	-- HideMyDex, HideMyRecord, HideMyVIP), for everyone who sees them
	local count = other:GetAttribute("HideMyDex") and 0 or a("CollectionCount")
	if count > 0 then
		local share = Formulas.collectionPercentText(count)
		local title = other:GetAttribute("DexTitle")
		local lead, name
		if title then
			lead, name = string.match(Lang.t(title, code), "^(%S+)%s+(.+)$")
		end
		icon = name and lead or DEX_FIRST_ICON
		table.insert(parts, string.format("%s%%", share))
	end
	-- (2026-10-04) the launch event's title (Rewards service), the night boss hunts' (Zombies service)
	for _, name in ipairs({ "EventTitle", "HuntTitle" }) do
		local title = other:GetAttribute(name)
		if title then
			table.insert(parts, Lang.t(title, code))
		end
	end
	local records = not other:GetAttribute("HideMyRecord")
	if records and a("RaceWins") + a("RaceLosses") > 0 then
		table.insert(parts, string.format("🏁 %d/%d", a("RaceWins"), a("RaceLosses")))
	end
	if records and a("SkyWins") + a("SkyLosses") > 0 then
		table.insert(parts, string.format("🦅 %d/%d", a("SkyWins"), a("SkyLosses")))
	end
	if records and a("HideWins") + a("HideLosses") > 0 then -- (2026-10-03) 🙈 hide-and-seek (HideSeek service)
		table.insert(parts, string.format("🙈 %d/%d", a("HideWins"), a("HideLosses")))
	end
	return icon, table.concat(parts, " · ")
end

local function recordOver(other)
	local head = other.Character and other.Character:FindFirstChild("Head")
	if not head then
		return
	end
	local icon, text = recordLine(other)
	local vip = other:GetAttribute("VIP") == true and not other:GetAttribute("HideMyVIP")
	local gui = head:FindFirstChild("RaceRecord")
	if text == "" and not icon and not vip then
		if gui then
			gui:Destroy()
		end
		return
	end
	if not gui then
		gui = Instance.new("BillboardGui")
		gui.Name = "RaceRecord"
		gui.Size = RECORD_SIZE
		gui.StudsOffsetWorldSpace = Vector3.new(0, RECORD_HEIGHT, 0)
		gui.SizeOffset = Vector2.new(0, 0.5)
		gui.MaxDistance = RECORD_DISTANCE
		local row = Instance.new("UIListLayout") -- [grade emoji][the line], centered
		row.FillDirection = Enum.FillDirection.Horizontal
		row.HorizontalAlignment = Enum.HorizontalAlignment.Center
		row.VerticalAlignment = Enum.VerticalAlignment.Center
		row.SortOrder = Enum.SortOrder.LayoutOrder
		row.Padding = UDim.new(0, RECORD_GAP)
		row.Parent = gui
		local tag = label(gui, VIP_TAG, UDim2.new(0, 0, 1, 0), UDim2.new(), RECORD_TEXT)
		tag.Name = "Vip"
		tag.LayoutOrder = 0 -- (first of all)
		tag.TextColor3 = VIP_COLOR
		tag.TextStrokeTransparency = 0.3
		tag:SetAttribute("KeepText", true)
		local badge = label(gui, "", UDim2.new(0, RECORD_BADGE, 1, 0), UDim2.new(), RECORD_BADGE)
		badge.Name = "Badge"
		badge.LayoutOrder = 1
		badge.TextScaled = true
		badge:SetAttribute("KeepText", true)
		local text = label(gui, "", UDim2.fromScale(1, 1), UDim2.new(), RECORD_TEXT)
		text.Name = "Text"
		text.LayoutOrder = 2
		text:SetAttribute("KeepText", true) -- (already in my language)
		text.TextScaled = true
		local most = Instance.new("UITextSizeConstraint")
		most.MaxTextSize = RECORD_TEXT
		most.Parent = text
		text.TextColor3 = RECORD_COLOR
		text.TextStrokeTransparency = 0.3
		gui.Parent = head
	end
	local badge, line, tag = gui.Badge, gui.Text, gui.Vip
	badge.Visible = icon ~= nil
	badge.Text = icon or ""
	tag.Visible = vip
	local tagWidth = TextService:GetTextSize(VIP_TAG, RECORD_TEXT, FONT, Vector2.new(10000, RECORD_BADGE)).X + 4
	tag.Size = UDim2.new(0, tagWidth, 1, 0)
	line.Visible = text ~= ""
	local room = RECORD_SIZE.X.Offset - (icon and RECORD_BADGE + RECORD_GAP or 0) - (vip and tagWidth + RECORD_GAP or 0)
	local width = TextService:GetTextSize(text, RECORD_TEXT, FONT, Vector2.new(10000, RECORD_BADGE)).X + 4
	line.Size = UDim2.new(0, math.min(width, room), 1, 0)
	line.Text = text
end

local function watchRecord(other)
	other.CharacterAdded:Connect(function(character)
		character:WaitForChild("Head", 10)
		recordOver(other)
	end)
	for _, name in ipairs({ "RaceWins", "RaceLosses", "SkyWins", "SkyLosses", "HideWins", "HideLosses", "DexTitle",
		"CollectionCount", "HuntTitle", "EventTitle", "VIP", "HideMyVIP", "HideMyDex", "HideMyRecord" }) do
		other:GetAttributeChangedSignal(name):Connect(function()
			recordOver(other)
		end)
	end
	task.spawn(recordOver, other)
end
for _, other in ipairs(Players:GetPlayers()) do
	watchRecord(other)
end
Players.PlayerAdded:Connect(watchRecord)
player:GetAttributeChangedSignal("Language"):Connect(function() -- (every line again, in my new language)
	for _, other in ipairs(Players:GetPlayers()) do
		recordOver(other)
	end
end)

-- ---------------------------------------------------------------------------
-- The result screen (Net push RaceResult): win / lose / draw, why, the time, how far each got, pads used,
-- hits taken and my record; "확인" or RESULT_SECONDS closes it
-- ---------------------------------------------------------------------------

local resultGui = Instance.new("ScreenGui")
resultGui.Name = "RaceResult"
resultGui.ResetOnSpawn = false
resultGui.Parent = player:WaitForChild("PlayerGui")
local result = Instance.new("Frame")
result.AnchorPoint = Vector2.new(0.5, 0.5)
result.Position = UDim2.fromScale(0.5, 0.5)
result.Size = RESULT_SIZE
result.BackgroundColor3 = RESULT_BG
result.Visible = false
result.Parent = resultGui
corner(result, 14)
Windows.fit(result)
local band = Instance.new("Frame")
band.Size = UDim2.new(1, 0, 0, 56)
band.BorderSizePixel = 0
band.Parent = result
corner(band, 14)
local resultTitle = label(band, "", UDim2.new(1, -60, 0, 34), UDim2.fromOffset(14, 4), 28)
-- (2026-10-03, "레이스 승리 패배도 이펙트랑 소리 들어가게 술래잡기처럼?") the title pops in; a win: the Victory fanfare and
-- confetti, a loss: the Defeat "와와와와~" and a little shake (the hide-and-seek's own sounds)
local titleScale = Instance.new("UIScale")
titleScale.Parent = resultTitle
resultTitle.TextXAlignment = Enum.TextXAlignment.Left
local resultWhy = label(band, "", UDim2.new(1, -28, 0, 16), UDim2.fromOffset(14, 36), 12)
resultWhy.TextXAlignment = Enum.TextXAlignment.Left
resultWhy.TextTruncate = Enum.TextTruncate.AtEnd

local function progressRow(y, name, color)
	local who = label(result, name, UDim2.fromOffset(90, 18), UDim2.fromOffset(14, y), 13)
	who.TextXAlignment = Enum.TextXAlignment.Left
	who.TextTruncate = Enum.TextTruncate.AtEnd
	local track = Instance.new("Frame")
	track.Size = UDim2.new(1, -170, 0, 12)
	track.Position = UDim2.fromOffset(108, y + 3)
	track.BackgroundColor3 = RESULT_TRACK
	track.BorderSizePixel = 0
	track.Parent = result
	corner(track, 6)
	local fill = Instance.new("Frame")
	fill.Size = UDim2.fromScale(0, 1)
	fill.BackgroundColor3 = color
	fill.BorderSizePixel = 0
	fill.Parent = track
	corner(fill, 6)
	local percent = label(result, "", UDim2.fromOffset(50, 18), UDim2.new(1, -60, 0, y), 13)
	percent.TextXAlignment = Enum.TextXAlignment.Right
	return who, fill, percent
end
local timeLine = label(result, "", UDim2.new(1, -28, 0, 20), UDim2.fromOffset(14, 64), 16)
timeLine.TextXAlignment = Enum.TextXAlignment.Left
local _, meFill, mePercent = progressRow(94, "나", RESULT_ME)
local themName, themFill, themPercent = progressRow(118, "상대", RESULT_THEM)
local statsLine = label(result, "", UDim2.new(1, -28, 0, 20), UDim2.fromOffset(14, 148), 14)
statsLine.TextXAlignment = Enum.TextXAlignment.Left
local recordLine = label(result, "", UDim2.new(1, -28, 0, 20), UDim2.fromOffset(14, 172), 14)
recordLine.TextXAlignment = Enum.TextXAlignment.Left
local okButton = button(result, "확인", RESULT_OK, UDim2.new(1, -28, 0, 40), UDim2.new(0, 14, 1, -52))
Windows.register(result)

local shownAt = 0
okButton.Activated:Connect(function()
	result.Visible = false
end)

Net.onPush("RaceResult", function(r)
	if type(r) ~= "table" then
		return
	end
	local look = RESULT_LOOKS[r.Outcome] or RESULT_LOOKS.Draw
	resultTitle.Text = look[1]
	resultTitle.TextColor3 = look[2]
	band.BackgroundColor3 = look[3]
	resultWhy.Text = (type(r.Why) == "string" and r.Why ~= "") and r.Why or string.format("vs %s", tostring(r.Opponent))
	local seconds = tonumber(r.Seconds) or 0
	local many = (tonumber(r.Racers) or 2) > 2 -- (2026-10-04: a room's race of more than two: my place)
	timeLine.Text = many and string.format("⏱️ %d:%02d · %s %d등/%d명", math.floor(seconds / 60), math.floor(seconds % 60),
		PLACES[tonumber(r.Place) or 0] or "🏅", tonumber(r.Place) or 0, tonumber(r.Racers) or 0)
		or string.format("⏱️ %d:%02d · 상대 %s", math.floor(seconds / 60), math.floor(seconds % 60), tostring(r.Opponent))
	if r.Practice then -- (alone: the time to the tenth, no opponent's row)
		resultWhy.Text = (type(r.Why) == "string" and r.Why ~= "") and r.Why
			or string.format("⏱️ %s 기록전", KIND_TEXT[r.Kind] or KIND_TEXT.Road)
		timeLine.Text = string.format("⏱️ %d:%04.1f · 기록전", math.floor(seconds / 60), seconds % 60)
	end
	local mine, theirs = math.clamp(tonumber(r.Mine) or 0, 0, 1), math.clamp(tonumber(r.Theirs) or 0, 0, 1)
	meFill.Size = UDim2.fromScale(mine, 1)
	themFill.Size = UDim2.fromScale(theirs, 1)
	mePercent.Text = string.format("%d%%", math.floor(mine * 100 + 0.5))
	themPercent.Text = string.format("%d%%", math.floor(theirs * 100 + 0.5))
	themName.Text = tostring(r.Opponent)
	statsLine.Text = r.Kind == "Sky" and string.format("💍 지난 링 %d / %d개 · ⚡ 부스터 %d개", tonumber(r.Rings) or 0,
		tonumber(r.AllRings) or 0, tonumber(r.Pads) or 0)
		or string.format("⚡ 발판 %d개 · 💥 부딪힘 %d번", tonumber(r.Pads) or 0, tonumber(r.Hits) or 0)
	recordLine.Text = string.format("%s 내 기록 %d승 %d패", KIND_TEXT[r.Kind] or KIND_TEXT.Road, tonumber(r.Wins) or 0,
		tonumber(r.Losses) or 0)
	if r.Ranked then -- (2026-10-04) 🏆 랭킹전: this week's ranked wins too (or that this win didn't count)
		recordLine.Text = (r.Outcome == "Win" and r.Counted ~= true)
			and string.format("🏆 같은 상대는 한 주에 %d승까지만 순위에 들어가요", Config.Ranked.SameRivalWins)
			or string.format("%s 내 기록 %d승 %d패 · 이번 주 🏆 %d승", KIND_TEXT[r.Kind] or KIND_TEXT.Road,
				tonumber(r.Wins) or 0, tonumber(r.Losses) or 0, tonumber(r.WeekWins) or 0)
	elseif not r.Practice then
		recordLine.Text = "🎈 일반전이라 기록은 남지 않아요"
	end
	themName.Visible, themFill.Parent.Visible, themPercent.Visible = not r.Practice, not r.Practice, not r.Practice
	local medals = Config.Race.Medals[r.Kind]
	if r.Practice then
		recordLine.Text = "⏱️ 시간 안에 들어오면 메달과 보상!"
	end
	if medals and type(r.Judged) == "number" then
		local got = medals[tonumber(r.Medal) or 0]
		local nextOne = medals[(tonumber(r.Medal) or 0) + 1]
		local nextText = nextOne and string.format(" · 다음 %s %.1f초", nextOne.Icon,
			Formulas.raceMedalTarget(r.Kind, (tonumber(r.Medal) or 0) + 1, tonumber(r.Ideal)) or 0) or ""
		recordLine.Text = (got and string.format("%s 메달 · ⏱️ %.1f초", got.Icon, r.Judged)
			or string.format("⏱️ %.1f초 · 메달 없음", r.Judged)) .. nextText
		if r.NewMedal and got then
			resultWhy.Text = string.format("🎉 새 메달 %s! 보상을 받았어요", got.Icon)
		end
	end
	result.Visible = true
	local mark = os.clock()
	shownAt = mark
	titleScale.Scale = 0.3
	TweenService:Create(titleScale, TweenInfo.new(RESULT_POP, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
		{ Scale = 1 }):Play()
	if r.Outcome == "Win" or r.Outcome == "Finish" then
		Sfx.play("Victory")
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if root then
			Fx.confetti(root.Position + Vector3.new(0, 4, 0))
		end
	elseif r.Outcome == "Lose" then
		Sfx.play("Defeat")
		task.spawn(function() -- a little shake of the title
			local home = resultTitle.Position
			for k = 1, RESULT_SHAKES do
				resultTitle.Position = home + UDim2.fromOffset((k % 2 == 0 and 1 or -1) * RESULT_SHAKE_PX, 0)
				task.wait(0.05)
			end
			resultTitle.Position = home
		end)
	end
	task.delay(RESULT_SECONDS, function()
		if shownAt == mark then
			result.Visible = false
		end
	end)
end)

-- ---------------------------------------------------------------------------
-- The sky race's rings (Net push SkyRings): only my next one, only on my screen
-- ---------------------------------------------------------------------------

local ringModel, ringRadius, ringShown = nil, 12, nil
local ringLabel = nil

local function clearRing()
	if ringModel then
		ringModel:Destroy()
		ringModel = nil
	end
	ringShown, ringLabel = nil, nil
end

-- ring i of my course: neon pieces round a circle, its hole facing the way from the ring before
local function drawRing(i)
	clearRing()
	local at = skyCourse and skyCourse[i]
	if not at then
		return
	end
	local from = skyCourse[i - 1]
	if not from then
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		from = root and root.Position or at - Vector3.new(0, 0, 10)
	end
	local through = Vector3.new(at.X - from.X, 0, at.Z - from.Z)
	through = through.Magnitude > 0.1 and through.Unit or Vector3.zAxis
	local last = i == #skyCourse
	local color = last and RING_RED or RING_YELLOW
	local model = Instance.new("Model")
	model.Name = "SkyRing"
	local frame = CFrame.lookAt(at, at + through) -- the ring stands in this frame's X-Y plane
	local pieces = {}
	local length = 2 * math.pi * ringRadius / RING_SEGMENTS + 0.3
	for k = 1, RING_SEGMENTS do
		local p = Instance.new("Part")
		p.Name = "Piece"
		p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
		p.Material = Enum.Material.Neon
		p.Color = color
		p.Size = Vector3.new(RING_TUBE, length, RING_TUBE)
		p.Parent = model
		pieces[k] = p
	end
	local anchor = Instance.new("Part")
	anchor.Name = "Center"
	anchor.Anchored, anchor.CanCollide, anchor.CanQuery, anchor.CanTouch = true, false, false, false
	anchor.Transparency = 1
	anchor.Size = Vector3.one
	anchor.CFrame = frame
	anchor.Parent = model
	local light = Instance.new("PointLight")
	light.Color = color
	light.Range = ringRadius * 2
	light.Brightness = 2
	light.Parent = anchor
	local gui = Instance.new("BillboardGui")
	gui.Size = RING_LABEL_SIZE
	gui.AlwaysOnTop = true -- (seen from anywhere: it may be far)
	gui.StudsOffsetWorldSpace = Vector3.new(0, ringRadius + 3, 0)
	local text = label(gui, "", UDim2.fromScale(1, 1), UDim2.new(), 18)
	text.TextColor3 = color
	text.TextStrokeTransparency = 0.2
	text.TextScaled = true
	gui.Parent = anchor
	model.Parent = Workspace
	ringModel, ringShown, ringLabel = model, i, text
	local spin = 0
	local function place()
		for k, p in ipairs(pieces) do
			local a = (k - 1) / RING_SEGMENTS * 2 * math.pi + spin
			p.CFrame = frame * CFrame.Angles(0, 0, a) * CFrame.new(ringRadius, 0, 0)
		end
	end
	place()
	ringModel:SetAttribute("Last", last)
	return place, function(dt)
		spin += RING_SPIN * dt
		place()
	end
end

-- the arrow (Shared/PointerArrow; the key carrier's home arrow is the same one, KeyArrow)
local arrow = nil
local function clearArrow()
	if arrow then
		arrow:Destroy()
		arrow = nil
	end
end

-- every frame: over my head, at my next ring, sized by how far it is; (2026-10-04) on the road, along the road ahead
local function pointArrow()
	local i = player:GetAttribute("SkyRing")
	local target = skyCourse and i and skyCourse[i]
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local last = target and i == #skyCourse
	if not target and root and racing() == "Go" and player:GetAttribute("RaceKind") ~= "Sky" then
		local c = Config.Race
		local a = math.rad(Formulas.compassAngle(root.Position.X, root.Position.Z) + math.deg(ROAD_ARROW_AHEAD / c.Radius))
		target = Vector3.new(math.sin(a) * c.Radius, root.Position.Y + ARROW_UP, -math.cos(a) * c.Radius)
		last = (player:GetAttribute("RaceProgress") or 0) >= ROAD_ARROW_RED
	end
	if not target or not root or racing() == nil then
		clearArrow()
		return
	end
	if not arrow or arrow:GetAttribute("Last") ~= last then
		clearArrow()
		arrow = PointerArrow.make(last and RING_RED or RING_YELLOW)
		arrow.Name = "SkyArrow"
		arrow:SetAttribute("Last", last)
	end
	PointerArrow.point(arrow, root.Position + Vector3.new(0, ARROW_UP, 0), target,
		{ ARROW_NEAR, ARROW_FAR, ARROW_BIG, ARROW_SMALL })
end

-- (2026-10-04, "상대 윤곽선이보여야할듯") while I race, every other racer (and the dino they ride) outlined, through
-- walls and obstacles; looked over every RIVAL_LOOK_EVERY seconds
local RIVAL_LOOK_EVERY = 0.5
local outlined = {} -- [Highlight] = true
local function outlineRivals()
	local me = racing() ~= nil
	local rivals = {} -- [the model to outline] = true
	if me then
		for _, other in ipairs(Players:GetPlayers()) do
			if other ~= player and other.Character and other:GetAttribute("Racing") ~= nil then
				rivals[other.Character] = true
			end
		end
		local folder = Workspace:FindFirstChild("RideMounts") -- (Ride.client: each mount says its rider)
		for _, mount in ipairs(folder and folder:GetChildren() or {}) do
			local rider = Players:GetPlayerByUserId(mount:GetAttribute("RiderId") or 0)
			if rider and rider ~= player and rider:GetAttribute("Racing") ~= nil then
				rivals[mount] = true
			end
		end
	end
	for model in pairs(rivals) do
		if not model:FindFirstChild("RaceRival") then
			local mark = Instance.new("Highlight")
			mark.Name = "RaceRival"
			mark.FillTransparency = 1
			mark.OutlineColor = RIVAL_OUTLINE
			mark.OutlineTransparency = 0
			mark.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
			mark.Parent = model
		end
	end
	for mark in pairs(outlined) do
		if not mark.Parent or not rivals[mark.Parent] then
			mark:Destroy()
			outlined[mark] = nil
		end
	end
	for model in pairs(rivals) do
		outlined[model.RaceRival] = true
	end
end
task.spawn(function()
	while true do
		outlineRivals()
		task.wait(RIVAL_LOOK_EVERY)
	end
end)

local spinRing = nil
local function showMyRing()
	local i = player:GetAttribute("SkyRing")
	if not skyCourse or not i or racing() == nil then
		clearRing()
		spinRing = nil
		return
	end
	if ringShown ~= i then
		if ringShown then -- passed the one before
			Sfx.play("CountGo")
		end
		local _, spinner = drawRing(i)
		spinRing = spinner
	end
end

Net.onPush("SkyRings", function(list, radius)
	if type(list) ~= "table" then
		return
	end
	skyCourse, ringRadius = list, tonumber(radius) or ringRadius
	ringShown = nil
	showMyRing()
end)
player:GetAttributeChangedSignal("SkyRing"):Connect(showMyRing)
player:GetAttributeChangedSignal("Racing"):Connect(function()
	if racing() == nil then
		skyCourse = nil
		clearRing()
		clearArrow()
		spinRing = nil
	end
end)
RunService.RenderStepped:Connect(FrameMeter.wrap("Race", function(dt)
	pointArrow()
	if not ringModel or not ringLabel then
		return
	end
	if spinRing then
		spinRing(dt)
	end
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local center = ringModel:FindFirstChild("Center")
	if root and center and skyCourse then
		ringLabel.Text = string.format("%s %d/%d · %dm", ringModel:GetAttribute("Last") and "🏁" or "💍", ringShown or 0,
			#skyCourse, math.floor((center.Position - root.Position).Magnitude + 0.5))
	end
end))
