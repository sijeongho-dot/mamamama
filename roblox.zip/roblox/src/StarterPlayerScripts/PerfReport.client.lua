local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Stats = game:GetService("Stats")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local Net = require(Shared:WaitForChild("Net"))

local player = Players.LocalPlayer

local FIRST_AFTER = 90
local EVERY = 180
local SLOW_FPS = 30
local HITCHES_SLOW = 3
local HITCH_SECONDS = 0.25
local PAUSE_GAP = 2
local TOP_SCRIPTS = 5

local frames, lastFrame = 0, os.clock()
local hitches, worst = 0, nil
local minFps = math.huge

RunService:BindToRenderStep("PerfReport", Enum.RenderPriority.First.Value, function()
	local now = os.clock()
	local dt = now - lastFrame
	lastFrame = now
	frames += 1
	local spent = FrameMeter.frameReport()
	if dt < HITCH_SECONDS or dt > PAUSE_GAP then
		return
	end
	hitches += 1
	if not worst or dt > worst.seconds then
		local name, most = nil, 0
		for n, s in pairs(spent) do
			if s > most then
				name, most = n, s
			end
		end
		worst = { seconds = dt, name = name, nameSeconds = most }
	end
end)

local function ms(seconds)
	return math.floor(seconds * 1000 + 0.5)
end

local function line(fps, frameCount)
	local list = {}
	local scripts = 0
	for n, s in pairs(FrameMeter.takeReport()) do
		scripts += s
		table.insert(list, { n, s })
	end
	table.sort(list, function(a, b)
		return a[2] > b[2]
	end)
	local top = {}
	for i = 1, math.min(TOP_SCRIPTS, #list) do
		table.insert(top, string.format("%s %.1f", list[i][1], list[i][2] / frameCount * 1000))
	end
	local okMb, mb = pcall(function()
		return Stats:GetTotalMemoryUsageMb()
	end)
	local okCount, count = pcall(function()
		return Stats.InstanceCount
	end)
	local asks = Net.takeAskReport()
	local okPing, ping = pcall(function()
		return player:GetNetworkPing()
	end)
	local camera = Workspace.CurrentCamera
	local screen = camera and camera.ViewportSize or Vector2.zero
	local parts = {
		string.format("fps %d (min %d)", math.floor(fps + 0.5), minFps == math.huge and 0 or math.floor(minFps + 0.5)),
		string.format("hitch %d", hitches) .. (worst and string.format(" (worst %dms%s)", ms(worst.seconds),
			worst.name and string.format(": %s %dms", worst.name, ms(worst.nameSeconds)) or "") or ""),
		string.format("scripts %.1fms/frame: %s", scripts / frameCount * 1000, table.concat(top, ", ")),
		(okPing and string.format("ping %dms", ms(ping)) or "ping ?") .. (asks.count > 0 and string.format(" · ask %d avg %dms (worst %s %dms)",
			asks.count, ms(asks.total / asks.count), tostring(asks.worstName), ms(asks.worst)) or ""),
		(okMb and string.format("mem %dMB", math.floor(mb + 0.5)) or "mem ?") .. (okCount and string.format(" · inst %d", count) or ""),
		string.format("%s %dx%d", UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and "phone" or "pc",
			math.floor(screen.X), math.floor(screen.Y)),
		"light " .. (player:GetAttribute("LightMode") == true and "on" or player:GetAttribute("LowDetail") and "low" or "off"),
		"lang " .. tostring(player:GetAttribute("Language")),
		ReplicatedStorage:GetAttribute("Night") == true and "night" or "day",
		player:GetAttribute("PromoLevel") and "promo" or "",
		string.format("players %d", #Players:GetPlayers()),
	}
	return table.concat(parts, " · "):sub(1, Config.Net.MaxStringLength)
end

task.spawn(function()
	local startedAt = os.clock()
	local periodStart, periodFrames = os.clock(), 0
	local secondStart, secondFrames = os.clock(), frames
	local sent = false
	while true do
		task.wait(1)
		local now = os.clock()
		local elapsed = now - secondStart
		if elapsed < PAUSE_GAP then
			minFps = math.min(minFps, (frames - secondFrames) / math.max(elapsed, 1e-3))
		end
		secondStart, secondFrames = now, frames
		local due = sent and EVERY or FIRST_AFTER
		if now - (sent and periodStart or startedAt) >= due then
			local count = math.max(frames - periodFrames, 1)
			local fps = count / math.max(now - periodStart, 1e-3)
			if not sent or fps < SLOW_FPS or hitches >= HITCHES_SLOW then
				pcall(Net.request, "PerfReport", line(fps, count))
			else
				FrameMeter.takeReport()
				Net.takeAskReport()
			end
			sent = true
			periodStart, periodFrames = now, frames
			hitches, worst, minFps = 0, nil, math.huge
		end
	end
end)
