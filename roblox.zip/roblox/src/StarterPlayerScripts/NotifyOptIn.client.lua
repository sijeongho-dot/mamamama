local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Notices = require(Shared:WaitForChild("Notices"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer
local N = Config.Notify

local TITLE_FRIENDS = "🔔 친구 알림 받기"
local TITLE_BOXES = "🔔 상자 알림 받기"
local TITLE_BOTH = "🔔 알림 받기"
local FRIENDS_LINE = "👥 친구가 놀 때 알려줘요! 같이 %d분 놀면 둘 다 🔑 %d개"
local BOXES_LINE = "📦 상자가 다 열리면 알려줘요!"

local friends = N.FriendPlaying.MessageId ~= ""
local boxes = N.BoxReady.MessageId ~= ""
if not (friends or boxes) or ReplicatedStorage:GetAttribute("TutorialField") then
	return
end

local okService, service = pcall(game.GetService, game, "ExperienceNotificationService")
if not okService or not service then
	return
end

local function quiet()
	return player:GetAttribute("TutorialStep") == nil and not player:GetAttribute("TutorialTravel")
		and not player:GetAttribute("CocoIntro") and not player:GetAttribute("FirstFight")
		and not player:GetAttribute("Cinematic") and not player:GetAttribute("PromoLevel")
		and not Windows.anyOpen()
end

local won = false
local level = player:GetAttribute("DefenseLevel")
player:GetAttributeChangedSignal("DefenseLevel"):Connect(function()
	local now = player:GetAttribute("DefenseLevel")
	won = won or (level ~= nil and now ~= nil and now > level)
	level = now
end)

local started = os.clock()
while true do
	task.wait(N.OptIn.CheckEvery)
	local long = os.clock() - started >= N.OptIn.AfterMinutes * 60
	if long and (won or os.clock() - started >= N.OptIn.AfterMinutes * 120) and quiet() then
		break
	end
end

local okAsk, can = pcall(service.CanPromptOptInAsync, service)
if not okAsk or not can then
	return
end
local f = Config.FriendInvite
local lines = {}
if friends then
	table.insert(lines, string.format(FRIENDS_LINE, f.MinutesTogether, f.Keys))
end
if boxes then
	table.insert(lines, BOXES_LINE)
end
Notices.show(friends and boxes and TITLE_BOTH or friends and TITLE_FRIENDS or TITLE_BOXES, table.concat(lines, "\n"))
task.wait(N.OptIn.ExplainSeconds)
pcall(service.PromptOptIn, service)
