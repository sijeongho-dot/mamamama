local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Lang = require(Shared:WaitForChild("Lang"))

local player = Players.LocalPlayer

local LOOK_EVERY = 1
local TICK = 0.25
local GROW_STEP = 0.004
local MOVE_STEP = 0.01
local VIEW_NEAR = 260
local VIEW_FAR = 320
local TIMER_SIZE = UDim2.fromOffset(78, 26)
local TIMER_ABOVE = 0.9
local TIMER_DISTANCE = 70
local HOP_HEIGHT = 0.5
local HOP_SPEED = 5
local PROMPT_RANGE = 14
local RAINBOW_SECONDS = 4
local COLOR_WAIT = Color3.fromRGB(255, 255, 255)
local COLOR_READY = Color3.fromRGB(255, 215, 80)
local BOX_EDGE_SMALLEST = 1.2
local BOX_EDGE_BIGGEST = 5.2
local BOX_BODY_HEIGHT = 0.8
local LID_HEIGHT = 0.22
local LID_WIDER = 1.08
local RIBBON_SHARE = 0.16
local RIBBON_OVER = 0.05
local RIBBON_COLOR = Color3.fromRGB(255, 250, 240)
local RIBBON_READY_COLOR = Color3.fromRGB(255, 215, 80)
local LID_DARKEN = 0.25
local PILE_TURN = 12
local TITLE_COLOR = Color3.fromRGB(255, 215, 120)
local TITLE_SIZE = UDim2.fromOffset(200, 34)
local TITLE_ABOVE = 3
local TITLE_DISTANCE = 140
local BOX_COLORS = {
	Common = Color3.fromRGB(170, 170, 170), Uncommon = Color3.fromRGB(90, 200, 90), Rare = Color3.fromRGB(70, 140, 255),
	Epic = Color3.fromRGB(170, 90, 230), Legendary = Color3.fromRGB(255, 150, 40), Mythic = Color3.fromRGB(240, 60, 60),
	Transcendent = Color3.fromRGB(255, 100, 200), Rainbow = Color3.fromRGB(120, 230, 255), Golden = Color3.fromRGB(255, 210, 60),
	Onyx = Color3.fromRGB(60, 40, 90), Celestial = Color3.fromRGB(245, 245, 255), Secret = Color3.fromRGB(255, 240, 150),
	Cosmic = Color3.fromRGB(110, 90, 240), Primeval = Color3.fromRGB(255, 160, 40), Divine = Color3.fromRGB(255, 245, 200),
	Special = Color3.fromRGB(150, 95, 255),
}
local RAINBOW_RARITIES = { Rainbow = true, Secret = true, Divine = true }
local SHINY_FROM = "Legendary"

local view = Instance.new("Folder")
view.Name = "BoxPileView"
view.Parent = Workspace

local states = {}

local function rank(rarityId)
	return Formulas.rarity(rarityId .. "#") or 0
end

local function fullEdge(sizeId)
	local rank = Formulas.dinoSizeRank(sizeId)
	rank = rank > 0 and rank or Formulas.dinoSizeRank("Young")
	return BOX_EDGE_SMALLEST + (BOX_EDGE_BIGGEST - BOX_EDGE_SMALLEST) * (rank - 1) / math.max(#Config.Sizes - 1, 1)
end

local function newPart(parent, name, color, material)
	local p = Instance.new("Part")
	p.Name = name
	p.Color = color
	p.Material = material or Enum.Material.SmoothPlastic
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Parent = parent
	return p
end

local function parseBoxes(text)
	local list = {}
	for entry in string.gmatch(type(text) == "string" and text or "", "[^;]+") do
		local id, rarity, size, made, ready, cell = string.match(entry, "^([^,]*),([^,]*),([^,]*),([^,]*),([^,]*),([^,]*)$")
		if id and tonumber(ready) and tonumber(cell) then
			table.insert(list, { id = id, rarity = rarity, size = size ~= "" and size or nil, madeAt = tonumber(made),
				readyAt = tonumber(ready), cell = tonumber(cell) })
		end
	end
	return list
end

local function parseCells(text)
	local cells = {}
	for entry in string.gmatch(type(text) == "string" and text or "", "[^;]+") do
		local x, y, z = string.match(entry, "^([^,]+),([^,]+),([^,]+)$")
		if tonumber(x) and tonumber(y) and tonumber(z) then
			table.insert(cells, Vector3.new(tonumber(x), tonumber(y), tonumber(z)))
		end
	end
	return cells
end

local function shape(box, scale, ready)
	local e = box.edge * scale
	local bodyH, lidH = e * BOX_BODY_HEIGHT, e * LID_HEIGHT
	local h = bodyH + lidH
	local w, across = e * RIBBON_SHARE, e * LID_WIDER + RIBBON_OVER
	box.body.Size = Vector3.new(e, bodyH, e)
	box.lid.Size = Vector3.new(e * LID_WIDER, lidH, e * LID_WIDER)
	box.ribbonX.Size = Vector3.new(across, h + RIBBON_OVER, w)
	box.ribbonZ.Size = Vector3.new(w, h + RIBBON_OVER, across)
	box.bodyH, box.lidH, box.height, box.scale = bodyH, lidH, h, scale
	if box.ready ~= ready then
		box.ready = ready
		box.lid.Material = (ready or box.shiny) and Enum.Material.Neon or Enum.Material.SmoothPlastic
		box.ribbonX.Color = ready and RIBBON_READY_COLOR or RIBBON_COLOR
		box.ribbonZ.Color = box.ribbonX.Color
	end
	box.at = nil
end

local function pose(box, at, yaw)
	local base = CFrame.new(at) * CFrame.Angles(0, yaw + box.turn, 0)
	box.body.CFrame = base * CFrame.new(0, box.bodyH / 2, 0)
	box.lid.CFrame = base * CFrame.new(0, box.bodyH + box.lidH / 2, 0)
	box.ribbonX.CFrame = base * CFrame.new(0, box.height / 2, 0)
	box.ribbonZ.CFrame = box.ribbonX.CFrame
	box.at = at
end

local function addTimer(box)
	local gui = Instance.new("BillboardGui")
	gui.Name = "BoxTimer"
	gui.Size = TIMER_SIZE
	gui.MaxDistance = TIMER_DISTANCE
	gui.Adornee = box.body
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBold
	text.TextScaled = true
	text.TextStrokeTransparency = 0
	text.Parent = gui
	gui.Parent = box.model
	box.timer = { gui = gui, text = text, phase = math.random() * math.pi * 2 }
end

local function buildBox(state, b)
	local color = BOX_COLORS[b.rarity] or BOX_COLORS.Common
	local model = Instance.new("Model")
	model.Name = "Box"
	local box = {
		model = model,
		edge = fullEdge(b.size),
		shiny = rank(b.rarity) >= rank(SHINY_FROM),
		rainbow = RAINBOW_RARITIES[b.rarity] == true,
		turn = math.rad(((((tonumber(string.match(b.id, "%d+")) or 0) * 37) % (PILE_TURN * 2)) - PILE_TURN)),
	}
	box.body = newPart(model, "Body", color)
	box.lid = newPart(model, "Lid", color:Lerp(Color3.new(), LID_DARKEN), box.shiny and Enum.Material.Neon or nil)
	box.ribbonX = newPart(model, "RibbonX", RIBBON_COLOR)
	box.ribbonZ = newPart(model, "RibbonZ", RIBBON_COLOR)
	model.PrimaryPart = box.body
	if state.mine then
		addTimer(box)
	end
	model.Parent = state.holder
	return box
end

local function releaseBoxes(state)
	for id, box in pairs(state.boxes) do
		box.model:Destroy()
		state.boxes[id] = nil
	end
end

local function dropState(folder)
	local state = states[folder]
	if not state then
		return
	end
	for _, c in ipairs(state.links) do
		c:Disconnect()
	end
	state.holder:Destroy()
	states[folder] = nil
end

local function titleText(state)
	local total, ready = state.folder:GetAttribute("Total") or 0, state.folder:GetAttribute("Ready") or 0
	return ready > 0 and string.format("📦 상자 %d개 · ✅ %d개", total, ready) or string.format("📦 상자 %d개", total)
end

local function sync(state)
	state.stale = false
	local folder = state.folder
	state.cells = parseCells(folder:GetAttribute("Cells"))
	state.yaw = folder:GetAttribute("Yaw") or 0
	local spot, spotSize = folder:GetAttribute("Spot"), folder:GetAttribute("SpotSize")
	if typeof(spot) == "CFrame" and typeof(spotSize) == "Vector3" then
		state.anchor.CFrame, state.anchor.Size = spot, spotSize
	end
	local hidden = folder:GetAttribute("Hidden") == true or #state.cells == 0
	state.title.Enabled = not hidden
	if state.prompt then
		state.prompt.Enabled = not hidden
	end
	if hidden then
		releaseBoxes(state)
		return
	end
	local keep = {}
	local stacks = {}
	for order, b in ipairs(parseBoxes(folder:GetAttribute("Boxes"))) do
		local box = state.boxes[b.id] or buildBox(state, b)
		state.boxes[b.id] = box
		box.readyAt, box.cell, box.order = b.readyAt, math.clamp(b.cell, 1, #state.cells), order
		box.madeAt = b.madeAt or b.readyAt
		box.at = nil
		keep[b.id] = true
		stacks[box.cell] = (stacks[box.cell] or 0) + box.edge * (BOX_BODY_HEIGHT + LID_HEIGHT)
	end
	for id, box in pairs(state.boxes) do
		if not keep[id] then
			box.model:Destroy()
			state.boxes[id] = nil
		end
	end
	local tallest = 0
	for _, h in pairs(stacks) do
		tallest = math.max(tallest, h)
	end
	state.title.StudsOffsetWorldSpace = Vector3.new(0, tallest + TITLE_ABOVE, 0)
	Lang.set(state.titleLabel, titleText(state))
end

local function newState(folder, mine)
	local holder = Instance.new("Folder")
	holder.Name = "Pile" .. tostring(folder:GetAttribute("Owner"))
	holder.Parent = view
	local anchor = newPart(holder, "PileAnchor", Color3.new())
	anchor.Transparency = 1
	anchor.Size = Vector3.one
	local title = Instance.new("BillboardGui")
	title.Name = "PileTitle"
	title.Size = TITLE_SIZE
	title.MaxDistance = TITLE_DISTANCE
	title.Adornee = anchor
	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.Font = Enum.Font.GothamBold
	label.TextScaled = true
	label.TextColor3 = TITLE_COLOR
	label.TextStrokeTransparency = 0
	label.Parent = title
	title.Parent = anchor
	local state = { folder = folder, mine = mine, holder = holder, anchor = anchor, title = title, titleLabel = label,
		boxes = {}, cells = {}, yaw = 0, stale = true, links = {} }
	if mine then
		local prompt = Instance.new("ProximityPrompt")
		prompt.Name = "BoxPrompt"
		prompt.ActionText = "📦 상자 열기"
		prompt.ObjectText = "📦 내 상자"
		prompt.HoldDuration = 0
		prompt.RequiresLineOfSight = false
		prompt.MaxActivationDistance = PROMPT_RANGE
		prompt.Triggered:Connect(function()
			player:SetAttribute("OpenBoxes", true)
		end)
		prompt.Parent = anchor
		state.prompt = prompt
	end
	table.insert(state.links, folder.AttributeChanged:Connect(function()
		state.stale = true
	end))
	table.insert(state.links, folder.AncestryChanged:Connect(function()
		if not folder:IsDescendantOf(Workspace) then
			dropState(folder)
		end
	end))
	states[folder] = state
	return state
end

local function cameraAt()
	local camera = Workspace.CurrentCamera
	return camera and camera.CFrame.Position or Vector3.zero
end

local function centerOf(folder)
	local spot = folder:GetAttribute("Spot")
	return typeof(spot) == "CFrame" and spot.Position or nil
end

local function look()
	local map = Workspace:FindFirstChild("Map")
	local seen = {}
	local eye = cameraAt()
	for index = 1, Config.Map.BaseCount do
		local base = map and map:FindFirstChild("Base" .. index)
		local folder = base and base:FindFirstChild("BoxPile")
		if folder and folder:IsA("Folder") then
			local mine = folder:GetAttribute("Owner") == player.UserId
			local at = centerOf(folder)
			local d = at and (at - eye).Magnitude or math.huge
			local state = states[folder]
			if mine or d <= (state and VIEW_FAR or VIEW_NEAR) then
				seen[folder] = true
				if not state then
					newState(folder, mine)
				end
			end
		end
	end
	for folder in pairs(states) do
		if not seen[folder] then
			dropState(folder)
		end
	end
end

local function update(state, now, color)
	if state.stale then
		sync(state)
	end
	local cells = {}
	for _, box in pairs(state.boxes) do
		local s = Formulas.boxScale({ MadeAt = box.madeAt, ReadyAt = box.readyAt }, now)
		local ready = box.readyAt <= now
		if not box.scale or math.abs(box.scale - s) > GROW_STEP or box.ready ~= ready then
			shape(box, s, ready)
		end
		cells[box.cell] = cells[box.cell] or {}
		table.insert(cells[box.cell], box)
		if box.rainbow then
			box.body.Color = color
		end
	end
	for index, list in pairs(cells) do
		table.sort(list, function(a, b)
			return a.order < b.order
		end)
		local base = state.cells[index]
		local y = base.Y
		for _, box in ipairs(list) do
			local at = Vector3.new(base.X, y, base.Z)
			if not box.at or (box.at - at).Magnitude > MOVE_STEP then
				pose(box, at, state.yaw)
			end
			y += box.height
			local t = box.timer
			if t then
				local top = box.height - box.bodyH / 2 + TIMER_ABOVE
				local left = box.readyAt - now
				if left > 0 then
					Lang.set(t.text, "⏳ " .. Formulas.clockText(left))
					t.text.TextColor3 = COLOR_WAIT
					t.gui.StudsOffsetWorldSpace = Vector3.new(0, top, 0)
				else
					Lang.set(t.text, "✅")
					t.text.TextColor3 = COLOR_READY
					t.gui.StudsOffsetWorldSpace = Vector3.new(0, top
						+ HOP_HEIGHT * math.abs(math.sin(os.clock() * HOP_SPEED + t.phase)), 0)
				end
			end
		end
	end
	Lang.set(state.titleLabel, titleText(state))
end

task.spawn(function()
	while true do
		look()
		task.wait(LOOK_EVERY)
	end
end)

task.spawn(function()
	while true do
		task.wait(TICK)
		local now = Workspace:GetServerTimeNow()
		local color = Color3.fromHSV((os.clock() / RAINBOW_SECONDS) % 1, 0.6, 1)
		for _, state in pairs(states) do
			update(state, now, color)
		end
	end
end)
