--[[
Challenge: the ♾️ 무한 도전 window (2026-10-02, "전체적인 난이도가 과금유저에게도 게임을 즐기고 싶게 만드는가" →
무한 도전 + 주간 랭킹; design 2.4). Display only: the server runs the waves (Defense) and the ranking
(Leaderboards).

A "♾️ 도전" button in the right column (third column, under 자동 채굴; 2026-10-02: not the top bar, which ran into
the 🏆 Season button on iPhones with five buttons) opens it. It shows how the challenge works, my best this week and ever
(player attributes ChallengeBest, ChallengeAllBest), when this week's ranking ends (ReplicatedStorage
ChallengeWeekEnds), this week's wave rewards (✅ once this week's best reached them), last week's rank
rewards, this week's all-server top (ReplicatedStorage ChallengeTop, JSON) and this server's players. Its
button sends StartChallenge, or CancelChallenge while a run is on (player attribute ChallengeWave); the run's
own bar is the defense line's fight bar (Placement).
]]

local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(Shared:WaitForChild("Windows"))
local SideButtons = require(Shared:WaitForChild("SideButtons"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Unlock = require(Shared:WaitForChild("Unlock"))

local player = Players.LocalPlayer
local C = Config.Defense.Challenge

-- display only
local FONT = Enum.Font.GothamBold
local PANEL_SIZE = UDim2.fromOffset(380, 460)
local ROW_HEIGHT = 20
local START_HEIGHT = 40
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_BUTTON = Color3.fromRGB(40, 150, 200)
local COLOR_START = Color3.fromRGB(70, 180, 90)
local COLOR_STOP = Color3.fromRGB(230, 60, 60)
local COLOR_CLOSE = Color3.fromRGB(235, 70, 80)
local COLOR_HEAD = Color3.fromRGB(255, 205, 60)
local COLOR_DONE = Color3.fromRGB(120, 220, 120)
local COLOR_TODO = Color3.fromRGB(170, 170, 180)
local COLOR_ME = Color3.fromRGB(120, 200, 255)
local COLOR_RULE = Color3.fromRGB(255, 150, 90)
local SERVER_SHOWN = 8 -- this server's players listed
local OPEN_SIZE = UDim2.fromOffset(68, 36)
local OPEN_POS = UDim2.new(1, -12 - 2 * (68 + 10), 0, 132) -- its middle: left of 보상 (Rewards), under 자동 채굴 (AutoMine);
-- the windows may cover this third column, so it hides while another window is open (the iPhone SE)

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextSize = textSize
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local rewardText = Formulas.rewardShortText

local gui = Instance.new("ScreenGui")
gui.Name = "Challenge"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local openButton = Instance.new("TextButton")
openButton.Name = "ChallengeOpen"
openButton.AnchorPoint = Vector2.new(1, 0.5)
openButton.Size = OPEN_SIZE
openButton.Position = OPEN_POS
openButton.BackgroundColor3 = COLOR_BUTTON
openButton.Font = FONT
openButton.TextSize = 13
openButton.TextColor3 = Color3.new(1, 1, 1)
openButton.Text = "♾️ 도전"
openButton.Parent = gui
corner(openButton, 10)
SideButtons.register(openButton) -- folds with the right column

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(1, 0)
panel.Position = UDim2.new(1, -8, 0, 8)
panel.Size = PANEL_SIZE
panel.BackgroundColor3 = COLOR_BG
panel.Visible = false
panel.Parent = gui
corner(panel, 14)
Windows.fit(panel)

label(panel, "♾️ 무한 도전", UDim2.new(1, -60, 0, 34), UDim2.fromOffset(14, 6), 20)
local close = Instance.new("TextButton")
close.Size = UDim2.fromOffset(34, 34)
close.Position = UDim2.new(1, -42, 0, 8)
close.BackgroundColor3 = COLOR_CLOSE
close.Font = FONT
close.TextSize = 18
close.TextColor3 = Color3.new(1, 1, 1)
close.Text = "X"
close.Parent = panel
corner(close, 10)

local list = Instance.new("ScrollingFrame")
list.Position = UDim2.fromOffset(10, 44)
list.Size = UDim2.new(1, -20, 1, -54 - START_HEIGHT - 8)
list.BackgroundTransparency = 1
list.ScrollBarThickness = 6
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = panel
local layout = Instance.new("UIListLayout")
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = list

local startButton = Instance.new("TextButton")
startButton.AnchorPoint = Vector2.new(0.5, 1)
startButton.Position = UDim2.new(0.5, 0, 1, -10)
startButton.Size = UDim2.new(1, -28, 0, START_HEIGHT)
startButton.Font = FONT
startButton.TextSize = 17
startButton.TextColor3 = Color3.new(1, 1, 1)
startButton.Parent = panel
corner(startButton, 10)

local order = 0
local function row(text, color, size)
	order += 1
	local l = label(list, text, UDim2.new(1, -8, 0, ROW_HEIGHT), UDim2.new(), size or 13, color)
	l.LayoutOrder = order
	l.TextWrapped = true
	l.AutomaticSize = Enum.AutomaticSize.Y
	return l
end

local function decode(name)
	local ok, value = pcall(function()
		return HttpService:JSONDecode(ReplicatedStorage:GetAttribute(name) or "[]")
	end)
	return ok and type(value) == "table" and value or {}
end

local function myRankText(best, top)
	if best <= 0 then
		return "📍 아직 기록이 없어요 · ▶️ 도전해서 순위에 올라요"
	end
	for i, e in ipairs(top) do
		if e.Name == player.DisplayName or e.Name == player.Name then
			return string.format("📍 내 순위 %d위 · 이번 주 최고 %d판", i, best)
		end
	end
	local last = top[#top]
	if #top >= C.Top and last then
		return string.format("📍 이번 주 최고 %d판 · %d판 넘으면 순위에 들어가요", best, tonumber(last.Waves) or 0)
	end
	return string.format("📍 이번 주 최고 %d판 · 곧 순위에 올라요", best)
end

local function refresh()
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("TextLabel") then
			c:Destroy()
		end
	end
	order = 0
	local best = player:GetAttribute("ChallengeBest") or 0
	local top = decode("ChallengeTop")
	row("🏅 이번 주 순위 보상 · 높을수록 좋은 열쇠!", COLOR_HEAD, 15)
	local from = 1
	for _, r in ipairs(C.RankRewards) do
		local place = from == r.Top and string.format("%d위", r.Top) or string.format("%d~%d위", from, r.Top)
		row(string.format("%s: %s", place, rewardText(r.Reward)))
		from = r.Top + 1
	end
	row(string.format("🙌 그 밖에 1판 이상: %s", rewardText(C.PlayReward)))
	row(myRankText(best, top), COLOR_ME, 15)
	if top[1] then
		row(string.format("🥇 지금 1위 %s · %d판", tostring(top[1].Name), tonumber(top[1].Waves) or 0), COLOR_HEAD)
	end
	local ends = ReplicatedStorage:GetAttribute("ChallengeWeekEnds")
	if ends then
		local left = math.max(0, ends - Workspace:GetServerTimeNow())
		row(string.format("⏳ 이번 주 순위 마감까지 %d일 %d시간", left // 86400, (left % 86400) // 3600), COLOR_TODO)
	end
	row(string.format("⏱️ %d초마다 화석이 더 세져요! ❤️ %d개 다 잃으면 끝나요", C.WaveSeconds, C.Lives), COLOR_TODO)
	row("몇 판 버텼는지가 기록 · 언제든 다시! · 도전 중엔 💰 돈이 안 나와요", COLOR_TODO)
	local rule = Formulas.challengeRuleById(ReplicatedStorage:GetAttribute("ChallengeRule"))
	if rule then
		row(string.format("📅 이번 주 규칙 %s", rule.Name), COLOR_RULE, 15)
		row(rule.Text, COLOR_RULE)
	end
	for _, k in ipairs(Config.Defense.Kinds) do
		local times = rule and rule.KindChance and rule.KindChance[k.Id] or 1
		local from2 = times > 1 and math.ceil(k.FromWave / 3) or k.FromWave
		row(string.format("%s %s (%d판~): %s", k.Icon, k.Name, from2, k.Tip), COLOR_TODO)
	end
	row(string.format("🏆 이번 주 최고 %d판 · 역대 최고 %d판", best, player:GetAttribute("ChallengeAllBest") or 0),
		COLOR_HEAD, 15)

	row("🎁 이번 주 선물 (한 주에 한 번)", COLOR_HEAD, 14)
	for _, m in ipairs(C.Milestones) do
		local done = best >= m.Wave
		row(string.format("%s %d판: %s", done and "✅" or "⬜", m.Wave, rewardText(m.Reward)), done and COLOR_DONE or nil)
	end

	row("🌍 이번 주 전 서버 순위", COLOR_HEAD, 14)
	if #top == 0 then
		row("아직 기록이 없어요", COLOR_TODO)
	end
	for i, e in ipairs(top) do
		local mine = e.Name == player.DisplayName or e.Name == player.Name
		row(string.format("%d. %s · %d판", i, tostring(e.Name), tonumber(e.Waves) or 0), mine and COLOR_ME or nil)
	end

	row("🖥️ 이 서버 순위 (이번 주)", COLOR_HEAD, 14)
	local here = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if not p:GetAttribute("Developer") then
			table.insert(here, { p, p:GetAttribute("ChallengeBest") or 0 })
		end
	end
	table.sort(here, function(a, b)
		return a[2] > b[2]
	end)
	for i = 1, math.min(#here, SERVER_SHOWN) do
		local p, waves = here[i][1], here[i][2]
		row(string.format("%d. %s · %d판", i, p.DisplayName, waves), p == player and COLOR_ME or nil)
	end
end

local function refreshButton()
	local running = player:GetAttribute("ChallengeWave") ~= nil
	if running then
		startButton.Text = "⛔ 도전 그만하기 (기록은 남아요)"
		startButton.BackgroundColor3 = COLOR_STOP
	else
		startButton.Text = "▶️ 도전 시작"
		startButton.BackgroundColor3 = COLOR_START
	end
	local best = player:GetAttribute("ChallengeBest") or 0
	openButton.Text = running and "♾️ 도전 중" or Unlock.ready("Challenge") and "🔓 ♾️ 도전"
		or best > 0 and string.format("♾️ 도전\n🏆 %d판", best) or "♾️ 도전"
end

local function setOpen(open)
	panel.Visible = open
	if open then
		refresh()
		refreshButton()
	end
end

Windows.register(panel, function()
	setOpen(false)
end)
openButton.Activated:Connect(function()
	if Unlock.ready("Challenge") and not player:GetAttribute("ChallengeWave") then
		Unlock.ask("Challenge")
		return
	end
	if player:GetAttribute("ChallengeWave") then
		setOpen(not panel.Visible)
	else
		setOpen(false)
		Net.request("StartChallenge")
	end
end)
close.Activated:Connect(function()
	setOpen(false)
end)
startButton.Activated:Connect(function()
	if player:GetAttribute("ChallengeWave") then
		Net.request("CancelChallenge")
	else
		Net.request("StartChallenge")
		setOpen(false) -- (the run is watched on the track)
	end
end)

player:GetAttributeChangedSignal("ChallengeWave"):Connect(refreshButton)
refreshButton()
local opened = Unlock.usable("Challenge") or Unlock.ready("Challenge")
Unlock.watch(function()
	opened = Unlock.usable("Challenge") or Unlock.ready("Challenge")
	refreshButton()
end)
RunService.Heartbeat:Connect(FrameMeter.wrap("Challenge", function() -- (hidden under another window: see OPEN_POS)
	local show = (panel.Visible or not Windows.anyOpen()) and (opened or player:GetAttribute("ChallengeWave") ~= nil)
	if openButton.Visible ~= show then
		openButton.Visible = show
	end
end))
for _, name in ipairs({ "ChallengeBest", "ChallengeAllBest" }) do
	player:GetAttributeChangedSignal(name):Connect(function()
		refreshButton()
		if panel.Visible then
			refresh()
		end
	end)
end
for _, name in ipairs({ "ChallengeTop", "ChallengeRule" }) do
	ReplicatedStorage:GetAttributeChangedSignal(name):Connect(function()
		if panel.Visible then
			refresh()
		end
	end)
end
