--[[
Placement: the defense HUD line and the screen for putting dinos on the player's own platform
(design 2.2 공룡 배치; grey-box UI, the full UI comes in stage 9).

- Top center: defense level, monsters on the track, kills and money per minute (player attributes
  from the Defense service).
- "공룡 배치" opens the list of the player's dinos (Net ask GetMyUnits). "배치"/"이동" starts
  placing: a see-through silhouette of the dino (its parts glowing white or red, and a Highlight
  outline drawn on top) with its footprint circle and reach ring stands on the platform: where the
  dino stands now when moving it, else the first free place. Press anywhere on the platform and drag:
  it follows (a screen-wide invisible layer takes the presses, so the camera stays put). It is white
  where it fits and red where it does not; "✅ 놓기" at the bottom (beside "❌ 취소"; 2026-10-01, was
  small ✅ ❌ over its head, too high up over a big dino) sends PlaceUnit(unitId, x, z) in the arena's
  flat frame (base folder attribute ArenaFrame), "❌ 취소" (or Esc) gives up.
  "빼기" sends RemoveUnit. The server checks everything again.
- While the list or placing is open, every placed dino shows its reach ring.
- Walking up to one of the player's placed dinos outlines it and shows small "이동" / "빼기" buttons
  beside it (the same as the list's buttons).
- The enhance window opens from the "공룡 강화" prompt of the player's own enhance stall (in front of
  the defense arena, Enhance service): step 1 choose the dino, step 2 pick fodder (any species, its own first;
  "추천 선택"); the button stays grey until fodder is
  picked, then asks "강화할까요?" and sends Net ask Enhance. Walking away closes it.
  (2026-10-02) Two more tabs: "🍎 먹이" grows a chosen dino one size with the food from the trees' fruit
  (Net ask Feed, Config.Fruit) and "🧬 합성" (Net ask Merge) shows the new dino's level, size and attack first.
- More slots are bought at the defense sign in front of the field (server prompt, Defense service).
- The buttons sit in the top-right row (Shared/TopBar): "승급전" sends StartPromotion. During the fight a bar under the defense line
  shows the time left, the monsters on the track against the fail limit and the boss's health
  (player attributes PromoLevel, PromoTimeLeft, PromoOnTrack, PromoBoss); after a failure the
  button counts down to PromoRetryAt.
- (2026-10-02, "디펜스 전략의 재미" → 배치 도움 · 속성 조합) The list starts with the team's lines: the next boss's
  attribute and how many of my placed dinos it shrugs off, the two combos (감전 물+전기, 빙결 물+얼음: ✅ when both are
  placed), and the special fossils with what answers them. While placing, a line under the tip shows the spot's
  efficiency (Formulas.spotEfficiency: the track it reaches against the best spot for that dino).
]]

local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Unlock = require(Shared:WaitForChild("Unlock"))
local Lang = require(Shared:WaitForChild("Lang")) -- (Lang.set: a text set every frame, only when it changes)
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local TopBar = require(Shared:WaitForChild("TopBar"))
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Windows"))
local Fx = require(Shared:WaitForChild("Fx"))
local Notices = require(Shared:WaitForChild("Notices"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Coach = require(Shared:WaitForChild("Coach"))
local GachaFx = require(Shared:WaitForChild("GachaFx"))
local Pictures = require(Shared:WaitForChild("Pictures"))

local player = Players.LocalPlayer

-- display only
local K = {}
K.FONT = Enum.Font.GothamBold
K.UNIT_TOP = 0 -- the dinos stand on the ground (until the base tells its DefenseUnitTop)
K.PANEL_SIZE = UDim2.fromOffset(360, 434)
K.SORT_Y = 72
K.SORT_H = 30
K.SORT_GAP = 4
K.SORT_TEXT = 13
K.SORT_ARROWS = { [true] = " ▼", [false] = " ▲" }
K.SORTS = {
	{ Id = "Power", Text = "⚔️ 공격력순" },
	{ Id = "Rarity", Text = "💎 등급순" },
	{ Id = "Level", Text = "⬆️ 레벨순" },
	{ Id = "Attribute", Text = "🔥 속성순" },
}
K.ATTRIBUTE_ORDER = {}
for i, id in ipairs(Config.Defense.Boss.AttributeOrder) do
	K.ATTRIBUTE_ORDER[id] = i
end
K.CARD = {
	Size = UDim2.fromOffset(102, 136), Columns = 3, Gap = 6, Portrait = 58, Text = 12, Line = 14, ButtonH = 24, EmptyH = 52,
	Aim = UDim2.fromOffset(42, 22),
	BuffIcons = { UnitPower = "💪", Money = "💰", MonsterSlow = "🐢", RareChance = "🍀", Mining = "⛏️" },
}
K.COLOR_BG = Color3.fromRGB(25, 28, 40)
K.COLOR_ROW = Color3.fromRGB(40, 44, 60)
K.COLOR_BUTTON = Color3.fromRGB(80, 190, 110)
K.COLOR_MOVE = Color3.fromRGB(70, 140, 230)
K.COLOR_REMOVE = Color3.fromRGB(235, 70, 80)
K.COLOR_FARM = Color3.fromRGB(150, 120, 60)
K.COLOR_FARM_ROW = Color3.fromRGB(52, 56, 44)
K.COLOR_ENHANCE = Color3.fromRGB(200, 120, 40)
K.ENHANCE_SIZE = UDim2.fromOffset(380, 526)
K.MERGE_RESULT_SIZE = UDim2.fromOffset(320, 392)
K.MERGE_PICTURE = 190
K.MERGE_OK_SIZE = UDim2.fromOffset(140, 40)
K.MERGE_POP = 0.6
K.MERGE_POP_SECONDS = 0.35
K.ENHANCE_SORT_Y = 142 -- (2026-10-05) the sort buttons' row ...
K.ENHANCE_BUTTON_Y = 178 -- ... the 추천 선택 / 선택 해제 / 공룡 고르기 row under it (when shown) ...
K.ENHANCE_BAR_H = 32
K.ENHANCE_LIST_GAP = 8 -- ... and the list under the last of them
K.ENHANCE_LIST_BOTTOM = 108 -- room under the list (summary, the go button)
K.ENHANCE_SORT_W = 85
K.ENHANCE_SORT_GAP = 4
K.ENHANCE_SORT_TEXT = 13
K.ENHANCE_ROW = 48
K.FODDER_SHOWN = 200 -- the enhance window lists at most this many fodder dinos (the cheapest)
K.CATCHER_STICK = 0.4 -- the phone's move stick area (left share of the screen, lower two thirds) ...
K.CATCHER_RIGHT = 204 -- ... and the right edge's buttons stay uncovered while placing
K.ENHANCE_PICK_BOTTOM = 12
K.PICK_COLUMNS = 4
K.PICK_GAP = 6
K.PICK_TEXT_H = 40
K.PICK_TEXT_SIZE = 11
K.PICK_ICON_SIZE = 13
K.PICK_MARK_SIZE = 16
K.COLOR_STAR = Color3.fromRGB(255, 215, 80)
K.ENHANCE_PORTRAIT = 42 -- the dino picture at the start of each enhance row
K.RARITY_ROW_H = 26
K.RARITY_ROW_GAP = 4
K.RARITY_CHIP_W = 56
K.RARITY_CHIP_PAD = 8
K.RARITY_CHIP_TEXT = 12
K.RARITY_ASK_FROM = "Epic"
K.RARITY_ASK_SIZE = UDim2.fromOffset(270, 120)
K.COLOR_PICKED = Color3.fromRGB(60, 90, 60)
K.COLOR_EXP = Color3.fromRGB(240, 170, 60)
K.COLOR_WARN = Color3.fromRGB(255, 150, 120)
K.COLOR_MERGE = Color3.fromRGB(150, 90, 210) -- 합성
K.COLOR_FEED = Color3.fromRGB(215, 70, 80) -- 🍎 먹이 (2026-10-02, 공룡 사육)
K.FEED_BAR_H = 4
K.FEED_ONE, K.FEED_TEN = 1, 10
K.FEED_BAR_BACK = 0.7
K.GROWN_FROM = "Big" -- (2026-10-02) fodder this size or bigger may have been grown with food: warn, and "추천 선택" skips it
K.TAB_SIZE = UDim2.fromOffset(78, 30) -- the two buttons for the other tabs, left of the X
K.TAB_GAP = 4
K.COLOR_KEEP = Color3.fromRGB(255, 215, 90) -- the ⭐ kept species
-- (2026-10-04, "공룡 배치중 공룡 원형 오라에 배치 실루엣이 안보임": white, half see-through, it vanished on the light
-- platform and in a dino's aura) bold green where it fits, red where it does not, mostly solid
K.COLOR_OK = Color3.fromRGB(60, 235, 110) -- the placing silhouette: green where it fits ...
K.SILHOUETTE_FILL = 0.35 -- the Highlight fill over the silhouette (its outline is solid)
K.SILHOUETTE_PARTS = 0
K.COLOR_BAD = Color3.fromRGB(240, 70, 70) -- ... red where it does not
K.COLOR_RING = Color3.fromRGB(255, 255, 255)
K.COLOR_PROMO = Color3.fromRGB(200, 80, 200)
-- (2026-10-01, "the next boss's attribute where it shows better") its emoji on the promotion button's corner
K.BOSS_BADGE_SIZE = 20
K.BOSS_BADGE_COLOR = Color3.fromRGB(30, 30, 40)
K.PRIZE_GAP = 4
K.GAUGE_HEIGHT = 5
K.GAUGE_INSET = 4
K.GAUGE_COLOR = Color3.fromRGB(255, 215, 90)
K.GAUGE_BACK = Color3.fromRGB(70, 30, 80)
K.GAUGE_GLOW_FROM = 0.8
K.GAUGE_GLOW_COLOR = Color3.fromRGB(255, 255, 230)
K.GAUGE_GLOW_SPEED = 6
K.PRIZE_HEIGHT = 20
K.PRIZE_TEXT = 12
K.PRIZE_PAD = 8
K.PRIZE_PARTS = 2
K.PRIZE_COLOR = Color3.fromRGB(150, 70, 160)
K.ROAD_LEVELS = 3
K.ROAD_MARKS = { Normal = "🎁", Silver = "🎁⚪", Gold = "🎁🟡" }
K.COLOR_DISABLED = Color3.fromRGB(110, 110, 120)
K.COLOR_OK_BUTTON = Color3.fromRGB(70, 180, 90)
K.PLACE_BUTTON_SIZE = UDim2.fromOffset(80, 40) -- "❌ 취소" and "✅ 놓기" side by side at the bottom while placing
K.PLACE_BUTTON_Y = -140 -- from the screen's bottom
K.PLACE_BUTTON_GAP = 8
K.TOPVIEW_BUTTON = UDim2.fromOffset(100, 30)
K.TOPVIEW_PLACE_SIZE = UDim2.fromOffset(48, 40)
K.COLOR_BOSS = Color3.fromRGB(230, 60, 60)
K.COLOR_LIVES = Color3.fromRGB(255, 105, 150)
K.FIGHT_BAR_WIDTH = 260
K.FIGHT_BAR_HEIGHT, K.FIGHT_BAR_HEIGHT_BOSS = 28, 36
K.FIGHT_LINE = 16
K.FIGHT_TEXT = 12
K.FIGHT_GAUGE = 5
K.FIGHT_LIVES_Y, K.FIGHT_BOSS_Y = 19, 27
K.LINE_TEXT = 13
K.GIVE_UP_SIZE = UDim2.fromOffset(300, 96)
K.STATS_TOP = 4
K.STATS_SIZE = UDim2.fromOffset(200, 34)
K.FIGHT_GAP = 2
K.FIGHT_TOP = K.STATS_TOP + K.STATS_SIZE.Y.Offset + K.FIGHT_GAP
K.NEAR_UNIT_RANGE = 7 -- studs from a placed dino's edge within which its 이동/빼기 buttons show
K.NEAR_UNIT_CHECK = 0.15 -- seconds between looks for the nearest placed dino
K.NEAR_BUTTONS = UDim2.fromOffset(160, 30)
K.NEAR_BUTTONS_MAX_UP = 6
K.NEAR_FARM_REMOVE = 80
K.NEAR_BUTTON_WIDTH = 54
K.NEAR_SMALL_WIDTH = 44
K.NEAR_GAP = 4
K.NEAR_TAP_PIXELS = 90 -- a tap this close (on screen) to a dino in reach picks it
K.COLOR_NEAR_STROKE = Color3.fromRGB(255, 230, 120)
K.TEAM_TEXT = 13
K.COLOR_TEAM_BG = Color3.fromRGB(34, 38, 54)
K.COLOR_EFF_GOOD, K.COLOR_EFF_POOR = Color3.fromRGB(120, 230, 120), Color3.fromRGB(255, 170, 90)
K.EFF_GOOD = 0.7 -- efficiency from this shows green
K.COLOR_NEST_RING = Color3.fromRGB(255, 216, 74)
K.COLOR_PERCH_RING = Color3.fromRGB(150, 220, 255)
K.SPOT_TAP = "PlaceSpot"
K.SPOT_COLOR = Color3.fromRGB(255, 215, 80)
K.SPOT_RING_EXTRA = 0.6
K.SPOT_RING_HEIGHT = 0.12
K.SPOT_RING_LIFT = 0.08
K.SPOT_PULSE_SPEED = 4
K.SPOT_PULSE_FROM, K.SPOT_PULSE_TO = 0.2, 0.7
K.SPOT_GOOD = 0.8
K.SPOT_LOOK = 80
K.SPOT_START_GAP = 12
K.SPOT_SNAP = 5
K.SPOT_TAP_PIXELS = 80
K.SPOT_SAME = 0.5
K.SPOT_SEEN_EDGE = 0.12
K.SPOT_MARK_SIZE = UDim2.fromScale(4, 4)
K.SPOT_MARK_UP = 3.5
K.SPOT_MARK_TEXT = "🎯"
K.TOP_CATCH_ORDER = -1

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = K.FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.TextStrokeTransparency = 0.5
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.Font = K.FONT
	b.TextSize = 15
	b.TextColor3 = Color3.new(1, 1, 1)
	b.Text = text
	b.BackgroundColor3 = color
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 8)
	return b
end

local gui = Instance.new("ScreenGui")
gui.Name = "Placement"
gui.ResetOnSpawn = false
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling -- a window drawn over others (ZIndex 3) still shows its own contents
gui.Parent = player:WaitForChild("PlayerGui")

-- ---------------------------------------------------------------------------
-- Defense line
-- ---------------------------------------------------------------------------

-- in its own ScreenGui under the windows (Shared/Windows puts this script's gui over the HUD)
local statsGui = Instance.new("ScreenGui")
statsGui.Name = "ArenaLine"
statsGui.ResetOnSpawn = false
statsGui.IgnoreGuiInset = true
statsGui.Parent = gui.Parent
local statsTop = Instance.new("ScreenGui")
statsTop.Name = "ArenaTop"
statsTop.ResetOnSpawn = false
statsTop.IgnoreGuiInset = true
statsTop.DisplayOrder = 4
statsTop.Parent = gui.Parent
local stats = label(statsTop, "", K.STATS_SIZE, UDim2.new(0.5, 0, 0, K.STATS_TOP), K.LINE_TEXT)
stats.AnchorPoint = Vector2.new(0.5, 0)
stats.TextScaled = true
stats.TextWrapped = true
local statsMax = Instance.new("UITextSizeConstraint")
statsMax.MaxTextSize = K.LINE_TEXT
statsMax.Parent = stats
TopBar.keepRightOf(stats)

local function level() -- the real defense level (the shown one starts again each rebirth: levelText)
	return player:GetAttribute("DefenseLevel") or 1
end

local function levelText(lv)
	return Formulas.levelText(lv, player:GetAttribute("Rebirths"))
end

local function refreshStats()
	stats.Text = string.format("🛡️ %s · 🦴 %d/%d · %d마리/분 · +%s원/분", levelText(level()),
		player:GetAttribute("DefenseOnTrack") or 0, Config.Defense.Idle.MaxOnTrack,
		player:GetAttribute("DefenseKillsPerMinute") or 0, Formulas.shortNumber(player:GetAttribute("DefenseMoneyPerMinute") or 0))
end
for _, name in ipairs({ "DefenseOnTrack", "DefenseKillsPerMinute", "DefenseMoneyPerMinute" }) do
	player:GetAttributeChangedSignal(name):Connect(refreshStats)
end
refreshStats()

-- ---------------------------------------------------------------------------
-- Promotion fight (승급전): the button, and while fighting the time, the crowd and the boss
-- ---------------------------------------------------------------------------

local promoButton = TopBar.button("⚔️ 보스 도전", 1, K.COLOR_PROMO)
promoButton.Name = "PromoButton"
local promoPrize = Instance.new("TextLabel")
promoPrize.Name = "PromoPrize"
promoPrize.AnchorPoint = Vector2.new(0, 0)
promoPrize.Position = UDim2.new(0, 0, 1, K.PRIZE_GAP + K.GAUGE_HEIGHT / 2)
promoPrize.Size = UDim2.fromOffset(0, K.PRIZE_HEIGHT)
promoPrize.AutomaticSize = Enum.AutomaticSize.X
promoPrize.BackgroundColor3 = K.PRIZE_COLOR
promoPrize.BackgroundTransparency = 0.1
promoPrize.Font = Enum.Font.GothamBold
promoPrize.TextSize = K.PRIZE_TEXT
promoPrize.TextColor3 = Color3.new(1, 1, 1)
promoPrize.Text = ""
promoPrize.Visible = false
promoPrize.Parent = promoButton
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 8)
	round.Parent = promoPrize
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, K.PRIZE_PAD), UDim.new(0, K.PRIZE_PAD)
	pad.Parent = promoPrize
end
local gaugeBack = Instance.new("Frame")
gaugeBack.Name = "PromoGauge"
gaugeBack.AnchorPoint = Vector2.new(0.5, 0.5)
gaugeBack.Position = UDim2.new(0.5, 0, 1, 0)
gaugeBack.Size = UDim2.new(1, -K.GAUGE_INSET * 2, 0, K.GAUGE_HEIGHT)
gaugeBack.BackgroundColor3 = K.GAUGE_BACK
gaugeBack.BorderSizePixel = 0
gaugeBack.Visible = false
gaugeBack.Parent = promoButton
local gaugeFill = Instance.new("Frame")
gaugeFill.Size = UDim2.fromScale(0, 1)
gaugeFill.BackgroundColor3 = K.GAUGE_COLOR
gaugeFill.BorderSizePixel = 0
gaugeFill.Parent = gaugeBack
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = gaugeBack
	local fillRound = Instance.new("UICorner")
	fillRound.CornerRadius = UDim.new(0.5, 0)
	fillRound.Parent = gaugeFill
end
local bossBadge = Instance.new("TextLabel")
bossBadge.Name = "BossAttribute"
bossBadge.AnchorPoint = Vector2.new(0.25, 0.25)
bossBadge.Position = UDim2.fromOffset(0, 0)
bossBadge.Size = UDim2.fromOffset(K.BOSS_BADGE_SIZE, K.BOSS_BADGE_SIZE)
bossBadge.BackgroundColor3 = K.BOSS_BADGE_COLOR
bossBadge.TextScaled = true
bossBadge.Font = Enum.Font.GothamBold
bossBadge.TextColor3 = Color3.new(1, 1, 1)
bossBadge.ZIndex = promoButton.ZIndex + 1
bossBadge.Parent = promoButton
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = bossBadge
end
-- the attribute of the boss at this level (emoji), and its name
local function bossOf(at)
	local a = Config.Attributes[Formulas.bossAttribute(at)]
	return a.Icon, a.Name
end

local fightBar = Instance.new("Frame")
fightBar.Name = "FightBar" -- (WeatherFx puts its line under it while it shows)
fightBar.AnchorPoint = Vector2.new(0.5, 0)
fightBar.Position = UDim2.new(0.5, 0, 0, K.FIGHT_TOP)
fightBar.Size = UDim2.fromOffset(K.FIGHT_BAR_WIDTH, K.FIGHT_BAR_HEIGHT)
fightBar.BackgroundColor3 = K.COLOR_BG
fightBar.BackgroundTransparency = 0.15
fightBar.Visible = false
fightBar.Parent = statsGui -- with the defense line, under the windows (WeatherFx looks for it there)
corner(fightBar, 10)
local fightText = label(fightBar, "", UDim2.new(1, -16, 0, K.FIGHT_LINE), UDim2.fromOffset(8, 2), K.FIGHT_TEXT)
fightText.TextScaled = true
do
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = K.FIGHT_TEXT
	most.Parent = fightText
end

local function gauge(y, color)
	local back = Instance.new("Frame")
	back.Position = UDim2.fromOffset(8, y)
	back.Size = UDim2.new(1, -16, 0, K.FIGHT_GAUGE)
	back.BackgroundColor3 = Color3.fromRGB(50, 50, 60)
	back.Parent = fightBar
	corner(back, 4)
	local fill = Instance.new("Frame")
	fill.Size = UDim2.fromScale(0, 1)
	fill.BackgroundColor3 = color
	fill.Parent = back
	corner(fill, 4)
	return fill, back
end
-- giving up the fight (the retry wait still starts)
local giveUp = Instance.new("Frame")
giveUp.AnchorPoint = Vector2.new(0.5, 0)
giveUp.Position = UDim2.new(0.5, 0, 0, K.FIGHT_TOP + K.FIGHT_BAR_HEIGHT_BOSS + 6)
giveUp.Size = K.GIVE_UP_SIZE
giveUp.BackgroundColor3 = K.COLOR_BG
giveUp.Visible = false
giveUp.Parent = gui
Windows.fit(giveUp)
corner(giveUp, 10)
local giveUpText = label(giveUp, string.format("🏳️ 승급전을 그만할까요?\n⏱️ %d분 뒤에 다시 할 수 있어요",
	math.ceil(Config.Defense.Promotion.RetryCooldown / 60)), UDim2.new(1, -16, 0, 40), UDim2.fromOffset(8, 6), 14)
giveUpText.TextWrapped = true
local giveUpYes = button(giveUp, "🏳️ 포기하기", K.COLOR_BOSS, UDim2.new(0.5, -12, 0, 34), UDim2.new(0, 8, 1, -42))
local giveUpNo = button(giveUp, "▶️ 계속하기", K.COLOR_BUTTON, UDim2.new(0.5, -12, 0, 34), UDim2.new(0.5, 4, 1, -42))

local livesFill = gauge(K.FIGHT_LIVES_Y, K.COLOR_LIVES)
local bossFill, bossBack = gauge(K.FIGHT_BOSS_Y, K.COLOR_BOSS)

local function twistTag()
	local id = player:GetAttribute("PromoTwist")
	for _, r in ipairs(Config.Defense.Twists.Rules) do
		if r.Id == id then
			return " · 🎲" .. r.Icon
		end
	end
	return ""
end

RunService.Heartbeat:Connect(FrameMeter.wrap("Placement", function()
	local promoLevel = player:GetAttribute("PromoLevel")
	local left = player:GetAttribute("PromoTimeLeft")
	-- (2026-10-02) ♾️ 무한 도전 (Challenge.client has its window): the same bar shows the wave and the crowd
	local wave = player:GetAttribute("ChallengeWave")
	fightBar.Visible = (promoLevel ~= nil and left ~= nil) or wave ~= nil
	if wave then
		local limit = Config.Defense.Challenge.Lives
		local lives = player:GetAttribute("ChallengeLives") or limit
		Lang.set(fightText, string.format("♾️ %d판 · ⏱️%d초 · ❤️ %d/%d · 이번 주 최고 %d", wave,
			math.ceil(player:GetAttribute("ChallengeWaveLeft") or 0), lives, limit, player:GetAttribute("ChallengeBest") or 0))
		livesFill.Size = UDim2.fromScale(math.clamp(lives / limit, 0, 1), 1)
		bossBack.Visible = false
		fightBar.Size = UDim2.fromOffset(K.FIGHT_BAR_WIDTH, K.FIGHT_BAR_HEIGHT)
		bossBadge.Visible = false
		giveUp.Visible = false
		Lang.set(promoButton, "♾️ 도전 중")
		promoButton.BackgroundColor3 = K.COLOR_DISABLED
		promoPrize.Visible = false
		gaugeBack.Visible = false
		return
	end
	if fightBar.Visible then
		local limit = Config.Defense.Promotion.Lives
		local lives = player:GetAttribute("PromoLives") or limit
		local boss = player:GetAttribute("PromoBoss") or -1
		local bossIcon = bossOf(promoLevel)
		local weakIcon = Config.Attributes[Formulas.bossWeakness(Formulas.bossAttribute(promoLevel))].Icon -- (2026-10-03)
		bossBadge.Text, bossBadge.Visible = bossIcon, true
		Lang.set(fightText, string.format("👑 %s보스 %s · ❤️ %d/%d · 🦴 %d · 약점%s", bossIcon, levelText(promoLevel), lives, limit,
			player:GetAttribute("PromoOnTrack") or 0, weakIcon) .. twistTag())
		livesFill.Size = UDim2.fromScale(math.clamp(lives / limit, 0, 1), 1)
		bossBack.Visible = boss >= 0
		fightBar.Size = UDim2.fromOffset(K.FIGHT_BAR_WIDTH, boss >= 0 and K.FIGHT_BAR_HEIGHT_BOSS or K.FIGHT_BAR_HEIGHT)
		bossFill.Size = UDim2.fromScale(math.clamp(boss, 0, 1), 1)
		Lang.set(promoButton, "👑 보스 등장!")
		promoButton.BackgroundColor3 = K.COLOR_BOSS
		promoPrize.Visible = false
		gaugeBack.Visible = false
		return
	end
	giveUp.Visible = false
	local share = player:GetAttribute("PromoGauge")
	gaugeBack.Visible = share ~= nil
	if share and gaugeFill:GetAttribute("Share") ~= share then
		gaugeFill:SetAttribute("Share", share)
		gaugeFill.Size = UDim2.fromScale(math.clamp(share, 0, 1), 1)
	end
	if share and share >= K.GAUGE_GLOW_FROM then
		gaugeFill.BackgroundColor3 = K.GAUGE_COLOR:Lerp(K.GAUGE_GLOW_COLOR, 0.5 + 0.5 * math.sin(os.clock() * K.GAUGE_GLOW_SPEED))
	elseif gaugeFill.BackgroundColor3 ~= K.GAUGE_COLOR then
		gaugeFill.BackgroundColor3 = K.GAUGE_COLOR
	end
	local retry = player:GetAttribute("PromoRetryAt")
	local wait = retry and retry - Workspace:GetServerTimeNow() or 0
	local atTop = level() >= Formulas.maxDefenseLevel(player:GetAttribute("Rebirths") or 0)
	bossBadge.Visible = not atTop
	Lang.set(bossBadge, bossOf(level() + 1))
	local nextLevel = atTop and 0 or level() + 1
	if promoPrize:GetAttribute("For") ~= nextLevel then
		promoPrize:SetAttribute("For", nextLevel)
		local prize = nextLevel > 0 and Formulas.promotionPrizeParts(nextLevel) or {}
		promoPrize:SetAttribute("Has", #prize > 0)
		if #prize > 0 then
			Lang.set(promoPrize, table.concat(prize, " · ", 1, math.min(#prize, K.PRIZE_PARTS)))
		end
	end
	promoPrize.Visible = promoPrize:GetAttribute("Has") == true and not player:GetAttribute("FirstFight")
	if wait > 0 then
		Lang.set(promoButton, string.format("⏳ 재도전 %d:%02d", wait // 60, math.floor(wait % 60)))
		promoButton.BackgroundColor3 = K.COLOR_DISABLED
	elseif level() >= Formulas.maxDefenseLevel(player:GetAttribute("Rebirths") or 0) then -- the ceiling: rebirth next
		Lang.set(promoButton, string.format("🏆 최대 %s", levelText(level())))
		promoButton.BackgroundColor3 = K.COLOR_DISABLED
	else
		local rebirths = player:GetAttribute("Rebirths")
		Lang.set(promoButton, string.format(player:GetAttribute("PromoAutoOff") and "⏸️ 보스 도전 %d→%d" or "⚔️ 보스 도전 %d→%d",
			Formulas.shownLevel(level(), rebirths), Formulas.shownLevel(level() + 1, rebirths)))
		promoButton.BackgroundColor3 = K.COLOR_PROMO
	end
end))

-- (2026-10-05, "승급전 패배하면 승급전 분석 게시판으로 안내해두고") a lost fight: a glowing line from me to my base's 🩺 승급전
-- 분석 board (DefenseGuide: Map.DefenseGuides.DefenseGuideBase<n>.AdviceBoard) and a bouncing ⬇️ over it, until I have
-- been there and walk off again or GUIDE_LOOK.Seconds pass (or the next fight starts); the window's 🧭 button shows it again
K.GUIDE_LOOK = {
	Color = Color3.fromRGB(255, 150, 150), Width = 0.6, Arrive = 14, Leave = 28, Seconds = 120, MarkSize = UDim2.fromScale(6, 6), MarkUp = 3,
	Fresh = 5,
}
K.GUIDE_BOUNCE, K.GUIDE_BOUNCE_SPEED = 1.2, 4
local guide = nil -- { beam, from, to, mark, board, untilAt, reached }
local function stopGuide()
	if guide then
		guide.beam:Destroy()
		guide.from:Destroy()
		guide.to:Destroy()
		guide.mark:Destroy()
		guide = nil
	end
end
local function adviceBoard()
	local map = Workspace:FindFirstChild("Map")
	local holder = map and map:FindFirstChild("DefenseGuides")
	local index = player:GetAttribute("Base")
	local model = holder and index and holder:FindFirstChild("DefenseGuideBase" .. index)
	local board = model and model:FindFirstChild("AdviceBoard")
	return board and board:IsA("BasePart") and board or nil
end
local function startGuide()
	stopGuide()
	local board = adviceBoard()
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not board or not root then
		return
	end
	local from = Instance.new("Attachment")
	from.Parent = root
	local to = Instance.new("Attachment")
	to.Position = Vector3.new(0, -board.Size.Y / 2, -1) -- (at its foot, in front: its words face -Z)
	to.Parent = board
	local beam = Instance.new("Beam")
	beam.Attachment0, beam.Attachment1 = from, to
	beam.Color = ColorSequence.new(K.GUIDE_LOOK.Color)
	beam.Width0, beam.Width1 = K.GUIDE_LOOK.Width, K.GUIDE_LOOK.Width
	beam.FaceCamera = true
	beam.LightEmission = 1
	beam.Transparency = NumberSequence.new(0.2)
	beam.Parent = board
	local mark = Instance.new("BillboardGui")
	mark.Size = K.GUIDE_LOOK.MarkSize
	mark.AlwaysOnTop = true
	mark.Adornee = board
	mark.StudsOffsetWorldSpace = Vector3.new(0, board.Size.Y / 2 + K.GUIDE_LOOK.MarkUp, 0)
	local arrow = Instance.new("TextLabel")
	arrow.BackgroundTransparency = 1
	arrow.Size = UDim2.fromScale(1, 1)
	arrow.TextScaled = true
	arrow.Text = "⬇️"
	arrow:SetAttribute("KeepText", true)
	arrow.Parent = mark
	mark.Parent = gui
	guide = { beam = beam, from = from, to = to, mark = mark, board = board, untilAt = os.clock() + K.GUIDE_LOOK.Seconds }
end
RunService.Heartbeat:Connect(FrameMeter.wrap("PromoGuide", function()
	if not guide then
		return
	end
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if guide.from.Parent ~= root and root then -- (a new character)
		guide.from.Parent = root
	end
	local gap = root and (root.Position - guide.board.Position) * Vector3.new(1, 0, 1)
	guide.reached = guide.reached or gap ~= nil and gap.Magnitude <= K.GUIDE_LOOK.Arrive
	if not guide.board.Parent or os.clock() >= guide.untilAt or (guide.reached and gap and gap.Magnitude > K.GUIDE_LOOK.Leave)
		or player:GetAttribute("PromoLevel") then
		stopGuide()
		return
	end
	guide.mark.StudsOffsetWorldSpace = Vector3.new(0, guide.board.Size.Y / 2 + K.GUIDE_LOOK.MarkUp
		+ math.abs(math.sin(os.clock() * K.GUIDE_BOUNCE_SPEED)) * K.GUIDE_BOUNCE, 0)
end))

promoButton.Activated:Connect(function()
	if player:GetAttribute("PromoLevel") then
		return
	else
		local retry = player:GetAttribute("PromoRetryAt")
		if retry and retry > Workspace:GetServerTimeNow() and player:GetAttribute("PromoFailNote") then
			startGuide()
			Notices.show(nil, "🧭 빛줄기를 따라 🩺 보스 분석 판으로 가요")
			return
		end
		Net.request("StartPromotion")
	end
end)
giveUpYes.Activated:Connect(function()
	giveUp.Visible = false
	Net.request("CancelPromotion")
end)
giveUpNo.Activated:Connect(function()
	giveUp.Visible = false
end)

-- ---------------------------------------------------------------------------
-- The list of dinos
-- ---------------------------------------------------------------------------

local openButton = TopBar.button("🦖 공룡 배치", 2, K.COLOR_MOVE)
do
	local function arenaStage()
		local off = not Unlock.shown("Base_Arena")
		TopBar.setHidden(promoButton, off)
		TopBar.setHidden(openButton, off)
	end
	Unlock.watch(arenaStage)
	arenaStage()
end

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(0.5, 0.5) -- in the middle, clear of the top buttons and the right column
panel.Position = UDim2.fromScale(0.5, 0.5)
panel.Size = K.PANEL_SIZE
panel.BackgroundColor3 = K.COLOR_BG
panel.Visible = false
panel.Parent = gui
corner(panel, 14)
Windows.fit(panel) -- smaller on small screens, clear of the HUD
local title = label(panel, "공룡 배치", UDim2.new(1, -60 - K.TOPVIEW_BUTTON.X.Offset - 8, 0, 36), UDim2.fromOffset(14, 6), 20)
title.TextXAlignment = Enum.TextXAlignment.Left
do
	local top = button(panel, "🗺️ 탑뷰", K.COLOR_MOVE, K.TOPVIEW_BUTTON, UDim2.new(1, -50, 0, 10))
	top.AnchorPoint = Vector2.new(1, 0)
	top.TextSize = 14
	top.Activated:Connect(function()
		panel.Visible = false
		player:SetAttribute("TopView", true)
	end)
end
local hint = label(panel, "🦖 길 옆에 놓아요! 🦅🌊는 멀리서도 OK",
	UDim2.new(1, -28, 0, 30), UDim2.fromOffset(14, 38), 12)
hint.TextWrapped = true
hint.TextXAlignment = Enum.TextXAlignment.Left
local close = button(panel, "X", K.COLOR_REMOVE, UDim2.fromOffset(34, 34), UDim2.new(1, -42, 0, 8))
local listSort = { By = "Power", Desc = true }
local listSortButtons = {}
do
	local w = (K.PANEL_SIZE.X.Offset - 28 - (#K.SORTS - 1) * K.SORT_GAP) / #K.SORTS
	for i, s in ipairs(K.SORTS) do
		local b = button(panel, s.Text, K.COLOR_DISABLED, UDim2.fromOffset(w, K.SORT_H),
			UDim2.fromOffset(14 + (i - 1) * (w + K.SORT_GAP), K.SORT_Y))
		b.TextScaled = true
		local most = Instance.new("UITextSizeConstraint")
		most.MaxTextSize = K.SORT_TEXT
		most.Parent = b
		listSortButtons[s.Id] = b
	end
end

local list = Instance.new("ScrollingFrame")
list.Position = UDim2.fromOffset(10, K.SORT_Y + K.SORT_H + 6)
list.Size = UDim2.new(1, -20, 1, -(K.SORT_Y + K.SORT_H + 16))
list.BackgroundTransparency = 1
list.ScrollBarThickness = 6
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = panel
do
	local layout = Instance.new("UIListLayout")
	layout.Padding = UDim.new(0, 6)
	layout.SortOrder = Enum.SortOrder.LayoutOrder
	layout.Parent = list
end
do
	local auto = button(list, "✨ 자동 배치: 다음 보스에 맞춰 좋은 자리에", K.COLOR_MOVE, UDim2.new(1, -8, 0, 34), UDim2.new())
	auto.LayoutOrder = -2
	auto.TextScaled = true
	Coach.mark(auto, "AutoPlace")
	local armedUntil = 0
	local function paintAuto()
		Lang.set(auto, os.clock() <= armedUntil and "✨ 한 번 더 누르면 지금 자리를 바꿔요"
			or "✨ 자동 배치: 다음 보스에 맞춰 좋은 자리에")
	end
	auto.Activated:Connect(function()
		if os.clock() > armedUntil then
			armedUntil = os.clock() + 3
			paintAuto()
			task.delay(3, paintAuto)
			return
		end
		armedUntil = 0
		paintAuto()
		Net.request("AutoArrange")
	end)
	paintAuto()
end
do
	local farmAuto = button(list, "🌾 농장 자동: 좋은 공룡을 한 번에 넣기", K.COLOR_FARM, UDim2.new(1, -8, 0, 34), UDim2.new())
	farmAuto.LayoutOrder = -1
	farmAuto.TextScaled = true
	farmAuto.Visible = Unlock.shown("FarmBoard")
	Unlock.watch(function()
		farmAuto.Visible = Unlock.shown("FarmBoard")
	end)
	local armedUntil = 0
	farmAuto.Activated:Connect(function()
		if os.clock() > armedUntil then
			armedUntil = os.clock() + 3
			Lang.set(farmAuto, "🌾 한 번 더 누르면 농장을 바꿔요")
			task.delay(3, function()
				Lang.set(farmAuto, "🌾 농장 자동: 좋은 공룡을 한 번에 넣기")
			end)
			return
		end
		armedUntil = 0
		Lang.set(farmAuto, "🌾 농장 자동: 좋은 공룡을 한 번에 넣기")
		Net.request("AutoFarm")
	end)
end
local cards = Instance.new("Frame")
cards.LayoutOrder = 1
cards.Size = UDim2.new(1, -8, 0, 0)
cards.BackgroundTransparency = 1
cards.Parent = list
do
	local grid = Instance.new("UIGridLayout")
	grid.CellSize = K.CARD.Size
	grid.CellPadding = UDim2.fromOffset(K.CARD.Gap, K.CARD.Gap)
	grid.SortOrder = Enum.SortOrder.LayoutOrder
	grid.Parent = cards
end

local data = nil -- { Units, Placed, Slots } from the server
local placing = nil -- { unit, stats } while placing

local function autoSkip()
	local skip = table.clone(data.FarmLock or {})
	for _, id in ipairs(data.MergeDinos or {}) do
		skip[id] = true
	end
	return skip
end

local function myFrame()
	local map = Workspace:FindFirstChild("Map")
	local folder = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	return folder and folder:GetAttribute("ArenaFrame")
end

local function myMap()
	local map = Workspace:FindFirstChild("Map")
	local folder = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	return folder and folder:GetAttribute("DefenseMap") or Config.Defense.Maps[1].Id, folder and folder:GetAttribute("DefenseUnitTop") or K.UNIT_TOP
end

local function perchTop()
	local map = Workspace:FindFirstChild("Map")
	local folder = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	return folder and folder:GetAttribute("DefensePerchTop") or K.UNIT_TOP
end

local function myUnits()
	local map = Workspace:FindFirstChild("Map")
	local folder = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	return folder and folder:FindFirstChild("DefenseUnits")
end

local function placedCount()
	local n = 0
	if data then
		local owned = {}
		for _, u in ipairs(data.Units) do
			owned[u.Id] = true
		end
		for id in pairs(data.Placed) do
			if owned[id] then
				n += 1
			end
		end
	end
	return n
end

-- (2026-10-04, "공룡이 너무 많아 배치가 안되면 이렇게 빨간색이 아니라 아예 배치 시도부터 막기") no room for one more:
-- placing a new dino doesn't start (its "배치" button grey), it says why and what to do
local function slotsFull()
	return data ~= nil and placedCount() >= (data.Slots or 0)
end
local function sayFull()
	Notices.show(nil, string.format("🦖 공룡 자리 %d칸이 꽉 찼어요! 놓인 공룡을 '빼기' 하거나 ➕ 칸을 늘려요",
		data and data.Slots or 0))
end
local function guided()
	local taps = player:GetAttribute("MissionTaps")
	return type(taps) == "string" and string.find("," .. taps .. ",", "," .. K.SPOT_TAP .. ",", 1, true) ~= nil
end

-- reach rings of the placed dinos
local ringsFolder = Instance.new("Folder")
ringsFolder.Name = "PlacementRings"
ringsFolder.Parent = Workspace
-- the dino being placed (silhouette, footprint, reach): its own folder, since showRings clears ringsFolder
local previewFolder = Instance.new("Folder")
previewFolder.Name = "PlacementPreview"
previewFolder.Parent = Workspace

local function disc(radius, height, color, transparency, parent)
	local p = Instance.new("Part")
	p.Shape = Enum.PartType.Cylinder
	p.Anchored = true
	p.CanCollide = false
	p.CanQuery = false
	p.CanTouch = false
	p.CastShadow = false
	p.Material = Enum.Material.Neon
	p.Color = color
	p.Transparency = transparency
	p.Size = Vector3.new(height, radius * 2, radius * 2)
	p.Parent = parent or ringsFolder
	return p
end

local function flatAt(frame, x, z, lift)
	local _, top = myMap()
	return CFrame.new(frame * Vector3.new(x, top + lift, z)) * CFrame.Angles(0, 0, math.pi / 2)
end

local function showRings()
	ringsFolder:ClearAllChildren()
	local frame = myFrame()
	if not frame or not data or not (panel.Visible or placing or player:GetAttribute("TopView")) then
		return
	end
	local byId = {}
	for _, u in ipairs(data.Units) do
		byId[u.Id] = u
	end
	for id, pos in pairs(data.Placed) do
		local unit = byId[id]
		if unit and not (placing and placing.unit.Id == id) then
			local st = Formulas.placedStats(Formulas.unitStats(unit), (myMap()), pos.X, pos.Z)
			disc(st.Reach, 0.05, st.Perch and K.COLOR_PERCH_RING or st.Nest and K.COLOR_NEST_RING or K.COLOR_RING, 0.85).CFrame =
				flatAt(frame, pos.X, pos.Z, 0.03)
		end
	end
end

local startPlacing -- defined below
local fillPortraits -- defined below

local function cardLines(unit, onFarm)
	local species = Formulas.species(unit.Species)
	local third
	if onFarm then
		local kind, amount = Formulas.farmBuff(unit)
		third = string.format("🌾%s +%.2f%%", K.CARD.BuffIcons[kind] or "", amount * 100)
	else
		local theme = Formulas.theme(species.Theme)
		local attribute = Config.Attributes[species.Attribute]
		local stats = Formulas.unitStats(unit)
		third = string.format("%s%s ⚔️%s 📏%d", theme.Icon or "", attribute.Icon, Formulas.shortNumber(stats.Damage + 0.5),
			math.floor(stats.Reach + 0.5))
	end
	return string.format("%s Lv%d", Formulas.unitName(unit), Formulas.unitLevel(unit)),
		string.format("%s · %s", Formulas.rarity(unit.Rarity).Name, Formulas.dinoSize(unit.Size).Name), third
end

-- dino pictures only for the rows in view (a player can have hundreds of dinos)
function fillPortraits()
	local top = list.AbsolutePosition.Y - K.CARD.Size.Y.Offset
	local bottom = list.AbsolutePosition.Y + list.AbsoluteSize.Y + K.CARD.Size.Y.Offset
	for _, card in ipairs(cards:GetChildren()) do
		local species = card:IsA("Frame") and card:GetAttribute("Species")
		if species and not card:FindFirstChild("Portrait") and card.AbsolutePosition.Y < bottom
			and card.AbsolutePosition.Y + card.AbsoluteSize.Y > top then
			local picture = DinoPortrait.new(species, UDim2.fromOffset(K.CARD.Portrait, K.CARD.Portrait))
			picture.Name = "Portrait"
			picture.Position = UDim2.new(0.5, -K.CARD.Portrait / 2, 0, 4)
			picture.Parent = card
		end
	end
end
list:GetPropertyChangedSignal("CanvasPosition"):Connect(fillPortraits)

local function nextTwist()
	local lv = level() + 1
	local rule, eased, why = Formulas.activeTwist({ Units = data.Units, PromoAssist = data.PromoAssist }, lv)
	return rule, lv, eased, why
end

local function nextBench()
	local rule, lv = nextTwist()
	if not rule then
		return {}
	end
	local team = {}
	for _, u in ipairs(data.Units) do
		if data.Placed[u.Id] then
			table.insert(team, { Id = u.Id, Stats = Formulas.unitStats(u) })
		end
	end
	return Formulas.twistBench(rule, team, lv)
end

local function twistLine()
	local rule, lv, eased, why = nextTwist()
	if rule then
		return string.format("🎲 다음 승급전 변칙: %s · 이기면 🔑 보너스", Formulas.twistText(rule, lv))
	elseif eased then
		return why == "Losses" and "🎲 두 번 져서 다음엔 변칙 없이 싸워요"
			or string.format("🎲 다음 변칙(%s)은 쉬어 가요: 맞는 공룡이 없어요", eased.Icon)
	end
	local top = Formulas.maxDefenseLevel(player:GetAttribute("Rebirths") or 0)
	for at = lv + 1, math.min(top, lv + Config.Defense.Twists.Every) do
		local r = Formulas.twistRule(at)
		if r then
			return string.format("🎲 다음 변칙 승급전: %s %s", levelText(at), r.Icon)
		end
	end
	return nil
end

local function teamLines()
	local byId = {}
	for _, u in ipairs(data.Units) do
		byId[u.Id] = u
	end
	local bossAttribute = Formulas.bossAttribute(level() + 1)
	local weakId = Formulas.bossWeakness(bossAttribute)
	local strong = false
	for id in pairs(data.Placed) do
		local unit = byId[id]
		strong = strong or (unit ~= nil and Formulas.species(unit.Species).Attribute == weakId)
	end
	local icon = bossOf(level() + 1)
	local weakness = Config.Attributes[weakId]
	local resting = 0
	for _, u in ipairs(Formulas.recommendTeam(data.Units, data.Slots, level() + 1, myMap(), autoSkip(), (nextTwist()))) do
		resting += data.Placed[u.Id] and 0 or 1
	end
	return {
		strong and string.format("👑 다음 보스 %s → %s 공룡 ✅", icon, weakness.Icon)
			or string.format("👑 다음 보스 %s → %s 공룡을 놓아요!", icon, weakness.Icon),
		resting > 0 and string.format("⭐ 더 센 공룡 %d마리가 쉬고 있어요! ✨ 자동 배치로 바꿔요", resting) or false,
		(function()
			local icons = {}
			for _, g in ipairs(Formulas.fightGroups(level() + 1)) do
				table.insert(icons, Formulas.groupIcon(g))
			end
			return #icons > 0 and string.format("🚩 다음 보스 웨이브 무리: %s", table.concat(icons, " ")) or "🎯 길 옆이 최고!"
		end)(),
		twistLine() or false,
		(function()
			local rebirths = player:GetAttribute("Rebirths") or 0
			local function chip(l)
				return string.format("%d%s%s", Formulas.shownLevel(l, rebirths),
					K.ROAD_MARKS[Formulas.promotionBox(l)] or K.ROAD_MARKS.Normal, #Formulas.mapsOpenedAt(l) > 0 and "🗺️" or "")
			end
			local chips, better = {}, false
			for l = level() + 1, Formulas.maxDefenseLevel(rebirths) do
				local big = Formulas.promotionBox(l) ~= "Normal"
				if #chips < K.ROAD_LEVELS then
					table.insert(chips, chip(l))
					better = better or big
				elseif big and not better then
					table.insert(chips, "… " .. chip(l))
					break
				else
					if better then
						break
					end
				end
			end
			return #chips > 0 and string.format("🛣️ 레벨 길: %s", table.concat(chips, " ")) or false
		end)(),
		(player:GetAttribute("Rebirths") or 0) >= 1 and (function()
			local map = Formulas.defenseMap(myMap())
			return string.format("🗺️ %s %s · 바꾸기: 🗺️ 맵 게시판", map.Icon, map.Name)
		end)() or nil,
	}
end

local function orderUnits(units, by, desc, groupOf, plainTies)
	local key, power, at, group = {}, {}, {}, {}
	for i, u in ipairs(units) do
		at[u] = i
		group[u] = groupOf and groupOf(u) or 0
		power[u] = Formulas.unitStats(u).Damage
		local species = Formulas.species(u.Species)
		key[u] = by == "Rarity" and Formulas.rarityRank(u.Rarity) or by == "Level" and Formulas.unitLevel(u)
			or by == "Attribute" and -(K.ATTRIBUTE_ORDER[species and species.Attribute] or #Config.Defense.Boss.AttributeOrder + 1)
			or power[u]
	end
	table.sort(units, function(a, b)
		if group[a] ~= group[b] then
			return group[a] < group[b]
		end
		if key[a] ~= key[b] then
			return (key[a] > key[b]) == desc
		end
		if not plainTies and power[a] ~= power[b] then
			return power[a] > power[b]
		end
		return at[a] < at[b]
	end)
end

local function rebuildList()
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("Frame") and c ~= cards then
			c:Destroy()
		end
	end
	for _, c in ipairs(cards:GetChildren()) do
		if c:IsA("Frame") then
			c:Destroy()
		end
	end
	if not data then
		return
	end
	openButton.Text = string.format("🦖 배치 %d/%d", placedCount(), data.Slots)
	local units = table.clone(data.Units)
	local farm = data.Farm or {}
	local farmFirst = panel:GetAttribute("FarmFirst") == true
	title.Text = farmFirst and string.format("🌾 농장 (%d/%d칸) · 공룡 배치 %d/%d", player:GetAttribute("FarmCount") or 0,
		data.FarmSlots or 0, placedCount(), data.Slots)
		or string.format("공룡 배치 (%d/%d칸) · 농장 %d/%d", placedCount(), data.Slots, player:GetAttribute("FarmCount") or 0,
		data.FarmSlots or 0)
	Lang.set(hint, farmFirst and "🌾 농장 공룡이 맨 앞! 「🌾 빼기」로 빼요 · 🔒 잠그면 자동 배치로도 안 빠져요"
		or "🦖 길 옆에 놓아요! 🦅🌊는 멀리서도 OK")
	local function rank(u)
		if farmFirst then
			return farm[u.Id] and 0 or data.Placed[u.Id] and 2 or 1
		end
		return data.Placed[u.Id] and 0 or farm[u.Id] and 1 or 2
	end
	orderUnits(units, listSort.By, listSort.Desc, rank)
	for _, s in ipairs(K.SORTS) do
		local b = listSortButtons[s.Id]
		b.BackgroundColor3 = s.Id == listSort.By and K.COLOR_MOVE or K.COLOR_DISABLED
		Lang.set(b, s.Id == listSort.By and s.Text .. K.SORT_ARROWS[listSort.Desc] or s.Text)
	end
	if not farmFirst then -- the team's lines first
		local team = Instance.new("Frame")
		team.LayoutOrder = 0
		team.Size = UDim2.new(1, -8, 0, 0)
		team.AutomaticSize = Enum.AutomaticSize.Y
		team.BackgroundColor3 = K.COLOR_TEAM_BG
		team.Parent = list
		corner(team, 8)
		local pad = Instance.new("UIPadding")
		pad.PaddingTop, pad.PaddingBottom = UDim.new(0, 4), UDim.new(0, 4)
		pad.PaddingLeft, pad.PaddingRight = UDim.new(0, 8), UDim.new(0, 8)
		pad.Parent = team
		local teamLayout = Instance.new("UIListLayout")
		teamLayout.SortOrder = Enum.SortOrder.LayoutOrder
		teamLayout.Parent = team
		for i, line in ipairs(teamLines()) do
			if not line then
				continue
			end
			local l = label(team, line, UDim2.new(1, 0, 0, 0), UDim2.new(), K.TEAM_TEXT)
			l.LayoutOrder = i
			l.AutomaticSize = Enum.AutomaticSize.Y
			l.TextWrapped = true
			l.TextXAlignment = Enum.TextXAlignment.Left
		end
	end
	if #units == 0 then
		local empty = Instance.new("Frame")
		empty.BackgroundTransparency = 1
		empty.LayoutOrder = 2
		empty.Size = UDim2.new(1, -8, 0, K.CARD.EmptyH)
		empty.Parent = list
		label(empty, "🦖 아직 공룡이 없어요. 뽑기에서 뽑아 보세요", UDim2.fromScale(1, 1), UDim2.new(), 14)
	end
	cards.Size = UDim2.new(1, -8, 0, math.ceil(#units / K.CARD.Columns) * (K.CARD.Size.Y.Offset + K.CARD.Gap))
	local resting = nextBench()
	local better = {}
	for _, u in ipairs(Formulas.recommendTeam(data.Units, data.Slots, level() + 1, myMap(), autoSkip(), (nextTwist()))) do
		better[u.Id] = not data.Placed[u.Id] or nil
	end
	local half = UDim2.new(0.5, -6, 0, K.CARD.ButtonH)
	local buttonY = K.CARD.Size.Y.Offset - K.CARD.ButtonH - 4
	local function cardButton(card, text, color, wide, right)
		local b = button(card, text, color, wide and UDim2.new(1, -8, 0, K.CARD.ButtonH) or half,
			wide and UDim2.fromOffset(4, buttonY) or right and UDim2.new(0.5, 2, 0, buttonY) or UDim2.fromOffset(4, buttonY))
		b.TextScaled = true
		local most = Instance.new("UITextSizeConstraint")
		most.MaxTextSize = K.CARD.Text + 1
		most.Parent = b
		return b
	end
	for i, unit in ipairs(units) do
		local onFarm = farm[unit.Id] ~= nil
		local card = Instance.new("Frame")
		card.LayoutOrder = i
		card.BackgroundColor3 = onFarm and K.COLOR_FARM_ROW or K.COLOR_ROW
		card.Parent = cards
		corner(card, 8)
		card:SetAttribute("Species", unit.Species)
		DinoPortrait.border(card, unit.Rarity)
		local textTop = K.CARD.Portrait + 6
		for n, line in ipairs({ cardLines(unit, onFarm) }) do
			local l = label(card, line, UDim2.new(1, -6, 0, K.CARD.Line), UDim2.fromOffset(3, textTop + (n - 1) * K.CARD.Line),
				n == 1 and K.CARD.Text or K.CARD.Text - 1)
			l.TextScaled = true
		end
		local locked = onFarm and data.FarmLock and data.FarmLock[unit.Id] == true
		local marks = (better[unit.Id] and "⭐" or "") .. (data.Placed[unit.Id] and "🛡️" or "") .. (resting[unit.Id] and "💤" or "")
			.. (onFarm and "🌾" or "") .. (locked and "🔒" or "")
		if marks ~= "" then
			local mark = label(card, marks, UDim2.fromOffset(K.CARD.Line * 2 + 4, K.CARD.Line + 4), UDim2.fromOffset(3, 3), K.CARD.Text)
			mark.TextXAlignment = Enum.TextXAlignment.Left
			mark.ZIndex = 3
		end
		if data.Placed[unit.Id] then
			local targets = Config.Defense.Targets
			local mode = data.Targeting and data.Targeting[unit.Id] or targets[1].Id
			local at = 1
			for k, t in ipairs(targets) do
				at = t.Id == mode and k or at
			end
			local aim = button(card, "🎯" .. targets[at].Icon, K.COLOR_MOVE, K.CARD.Aim, UDim2.new(1, -K.CARD.Aim.X.Offset - 3, 0, 3))
			Coach.mark(aim, "Aim")
			aim.TextScaled = true
			aim.ZIndex = 4
			aim.Activated:Connect(function()
				local nextMode = targets[at % #targets + 1]
				data.Targeting = data.Targeting or {}
				data.Targeting[unit.Id] = nextMode.Id ~= "Auto" and nextMode.Id or nil
				Net.request("SetTargeting", unit.Id, nextMode.Id)
				Notices.show(nil, string.format("🎯 %s: %s %s", Formulas.species(unit.Species).Name, nextMode.Icon, nextMode.Name))
				rebuildList()
			end)
			local move = cardButton(card, "이동", K.COLOR_MOVE)
			Coach.mark(move, Formulas.flies(unit.Species) and "SkyMove" or nil)
			move.Activated:Connect(function()
				startPlacing(unit)
			end)
			cardButton(card, "빼기", K.COLOR_REMOVE, false, true).Activated:Connect(function()
				Net.request("RemoveUnit", unit.Id)
			end)
		elseif onFarm then
			cardButton(card, locked and "🔓 풀기" or "🔒 잠금", K.COLOR_MOVE).Activated:Connect(function()
				Net.request("FarmLock", unit.Id, not locked)
			end)
			cardButton(card, "🌾 빼기", locked and K.COLOR_DISABLED or K.COLOR_REMOVE, false, true).Activated:Connect(function()
				Net.request("UnregisterFarm", unit.Id)
			end)
		else
			local farmOpen = Unlock.shown("FarmBoard")
			if farmOpen then
				local toFarm = cardButton(card, "농장", K.COLOR_FARM)
				Coach.mark(toFarm, "FarmCard")
				toFarm.Activated:Connect(function()
					Net.request("RegisterFarm", unit.Id)
				end)
			end
			local place = cardButton(card, "배치", slotsFull() and K.COLOR_DISABLED or K.COLOR_BUTTON, not farmOpen, farmOpen)
			Coach.mark(place, not slotsFull() and (Formulas.flies(unit.Species) and "SkyCard" or "PlaceCard") or nil)
			place.Activated:Connect(function()
				startPlacing(unit)
			end)
		end
	end
	task.defer(fillPortraits)
end

for id, b in pairs(listSortButtons) do
	b.Activated:Connect(function()
		listSort.Desc = listSort.By ~= id or not listSort.Desc
		listSort.By = id
		rebuildList()
		list.CanvasPosition = Vector2.zero
	end)
end

local function reload()
	local answer = Net.ask("GetMyUnits")
	if answer then
		data = answer
		if panel.Visible then
			rebuildList()
		end
		showRings()
	end
end

-- ---------------------------------------------------------------------------
-- Enhance window: feed a dino others of its species (Net ask Enhance, Config.Enhance)
-- ---------------------------------------------------------------------------

local enhance = Instance.new("Frame")
enhance.AnchorPoint = Vector2.new(0.5, 0.5)
enhance.Position = UDim2.fromScale(0.5, 0.5)
enhance.Size = K.ENHANCE_SIZE
enhance.BackgroundColor3 = K.COLOR_BG
enhance.Visible = false
enhance.ZIndex = 3
enhance.Parent = gui
corner(enhance, 14)
Windows.fit(enhance) -- smaller on small screens, clear of the HUD
local enhanceTitle = label(enhance, "공룡 강화", UDim2.new(1, -60 - 2 * (K.TAB_SIZE.X.Offset + K.TAB_GAP), 0, 30),
	UDim2.fromOffset(14, 6), 18)
enhanceTitle.TextXAlignment = Enum.TextXAlignment.Left
local enhanceClose = button(enhance, "X", K.COLOR_REMOVE, UDim2.fromOffset(34, 34), UDim2.new(1, -42, 0, 8))
local targetText = label(enhance, "", UDim2.new(1, -96, 0, 44), UDim2.fromOffset(82, 40), 14)
targetText.TextXAlignment = Enum.TextXAlignment.Left
local expBack = Instance.new("Frame")
expBack.Position = UDim2.fromOffset(82, 88)
expBack.Size = UDim2.new(1, -96, 0, 12)
expBack.BackgroundColor3 = K.COLOR_ROW
expBack.Parent = enhance
corner(expBack, 6)
local expFill = Instance.new("Frame")
expFill.BackgroundColor3 = K.COLOR_EXP
expFill.Size = UDim2.fromScale(0, 1)
expFill.Parent = expBack
corner(expFill, 6)
local expText = label(expBack, "", UDim2.fromScale(1, 1), UDim2.new(), 11)
expText.ZIndex = 2
local hintText = label(enhance, "⚠️ 먹인 공룡은 사라져요! 아무 공룡이나 OK · 크고 좋은 공룡일수록 많이 커요",
	UDim2.new(1, -28, 0, 30), UDim2.fromOffset(14, 108), 12)
hintText.TextWrapped = true
hintText.TextXAlignment = Enum.TextXAlignment.Left
local autoButton = button(enhance, "✨ 추천 선택", K.COLOR_MOVE, UDim2.fromOffset(96, K.ENHANCE_BAR_H),
	UDim2.fromOffset(14, K.ENHANCE_BUTTON_Y))
local clearButton = button(enhance, "🧹 선택 해제", K.COLOR_DISABLED, UDim2.fromOffset(96, K.ENHANCE_BAR_H),
	UDim2.fromOffset(118, K.ENHANCE_BUTTON_Y))
local backButton = button(enhance, "← 공룡 고르기", K.COLOR_DISABLED, UDim2.fromOffset(120, K.ENHANCE_BAR_H),
	UDim2.fromOffset(222, K.ENHANCE_BUTTON_Y))
local bulk = {}
bulk.row = Instance.new("ScrollingFrame")
bulk.row.BackgroundTransparency = 1
bulk.row.Position = UDim2.fromOffset(14, K.ENHANCE_BUTTON_Y + K.ENHANCE_BAR_H + K.RARITY_ROW_GAP)
bulk.row.Size = UDim2.new(1, -28, 0, K.RARITY_ROW_H)
bulk.row.ScrollingDirection = Enum.ScrollingDirection.X
bulk.row.ScrollBarThickness = 0
bulk.row.AutomaticCanvasSize = Enum.AutomaticSize.X
bulk.row.CanvasSize = UDim2.new()
bulk.row.Visible = false
bulk.row.Parent = enhance
do
	local line = Instance.new("UIListLayout")
	line.FillDirection = Enum.FillDirection.Horizontal
	line.Padding = UDim.new(0, K.RARITY_ROW_GAP)
	line.SortOrder = Enum.SortOrder.LayoutOrder
	line.Parent = bulk.row
end
bulk.ask = Instance.new("Frame")
bulk.ask.AnchorPoint = Vector2.new(0.5, 0.5)
bulk.ask.Position = UDim2.fromScale(0.5, 0.5)
bulk.ask.Size = K.RARITY_ASK_SIZE
bulk.ask.BackgroundColor3 = K.COLOR_BG
bulk.ask.ZIndex = 10
bulk.ask.Visible = false
bulk.ask.Parent = enhance
corner(bulk.ask, 12)
do
	local edge = Instance.new("UIStroke")
	edge.Color = K.COLOR_WARN
	edge.Thickness = 2
	edge.Parent = bulk.ask
end
bulk.text = label(bulk.ask, "", UDim2.new(1, -16, 0, 62), UDim2.fromOffset(8, 6), 14)
bulk.text.TextWrapped = true
bulk.yes = button(bulk.ask, "✅ 고르기", K.COLOR_OK_BUTTON, UDim2.new(0.5, -12, 0, 36), UDim2.new(0, 8, 1, -44))
bulk.no = button(bulk.ask, "취소", K.COLOR_DISABLED, UDim2.new(0.5, -12, 0, 36), UDim2.new(0.5, 4, 1, -44))
local candidates = Instance.new("ScrollingFrame")
candidates.BackgroundTransparency = 1
candidates.ScrollBarThickness = 6
candidates.AutomaticCanvasSize = Enum.AutomaticSize.Y
candidates.CanvasSize = UDim2.new()
candidates.Parent = enhance
local candidateLayout = Instance.new("UIListLayout")
candidateLayout.Padding = UDim.new(0, 4)
candidateLayout.SortOrder = Enum.SortOrder.LayoutOrder
candidateLayout.Parent = candidates
local candidateGrid = Instance.new("UIGridLayout")
candidateGrid.CellPadding = UDim2.fromOffset(K.PICK_GAP, K.PICK_GAP)
candidateGrid.CellSize = UDim2.new(1 / K.PICK_COLUMNS, -K.PICK_GAP, 0, 10000)
candidateGrid.SortOrder = Enum.SortOrder.LayoutOrder
do
	local ratio = Instance.new("UIAspectRatioConstraint")
	ratio.AspectRatio = 3 / 4
	ratio.DominantAxis = Enum.DominantAxis.Width
	ratio.Parent = candidateGrid
end
-- dino pictures only for the rows in view (a player can have hundreds of dinos)
local function fillCandidatePortraits()
	local top = candidates.AbsolutePosition.Y - K.ENHANCE_ROW
	local bottom = candidates.AbsolutePosition.Y + candidates.AbsoluteSize.Y + K.ENHANCE_ROW
	for _, row in ipairs(candidates:GetChildren()) do
		local species = row:IsA("GuiObject") and row:GetAttribute("Species")
		if species and not row:FindFirstChild("Portrait") and row.AbsolutePosition.Y < bottom
			and row.AbsolutePosition.Y + row.AbsoluteSize.Y > top then
			local card = row:GetAttribute("Card")
			local picture = DinoPortrait.new(species, card and UDim2.new(1, -8, 1, -K.PICK_TEXT_H - 6)
				or UDim2.fromOffset(K.ENHANCE_PORTRAIT, K.ENHANCE_PORTRAIT))
			picture.Name = "Portrait"
			picture.Position = card and UDim2.fromOffset(4, 4) or UDim2.new(0, 4, 0.5, -K.ENHANCE_PORTRAIT / 2)
			picture.Parent = row
		end
	end
end
candidates:GetPropertyChangedSignal("CanvasPosition"):Connect(fillCandidatePortraits)
-- the list starts under the sort buttons, or under the button row when that is shown
local function placeList(withButtons, cards, rarities)
	local top = (withButtons and K.ENHANCE_BUTTON_Y or K.ENHANCE_SORT_Y) + K.ENHANCE_BAR_H + K.ENHANCE_LIST_GAP
		+ (rarities and K.RARITY_ROW_H + K.RARITY_ROW_GAP or 0)
	bulk.row.Visible = rarities == true
	if not rarities then
		bulk.ask.Visible = false
	end
	candidates.Position = UDim2.fromOffset(10, top)
	candidates.Size = UDim2.new(1, -20, 1, -top - ((cards and not withButtons) and K.ENHANCE_PICK_BOTTOM or K.ENHANCE_LIST_BOTTOM))
	candidateLayout.Parent = not cards and candidates or nil
	candidateGrid.Parent = cards and candidates or nil
end
placeList(false)

-- (2026-10-05, "공룡강화 창에 등급별로 나열할지 레벨별로 할지 같은 것도 넣어줘야지") the sort buttons over every list
-- of the window: each list (공룡 고르기, 재료, 🍎 먹이, 🧬 합성) keeps its own order. The strongest first (attack, rarity,
-- level; ties: attack), or grouped by attribute (the bosses' order); the 재료 list the cheapest first (its own order
-- for ties: the same species, low level first)
local sortBy = { Picker = "Power", Fodder = "Rarity", Feed = "Power", Merge = "Rarity" }
local sortDesc = { Picker = true, Fodder = false, Feed = true, Merge = true }
local placedFirst = { Picker = true, Feed = true }
local sortList = "Picker" -- the list now shown
local sortButtons = {}
for i, s in ipairs(K.SORTS) do
	local b = button(enhance, s.Text, K.COLOR_DISABLED, UDim2.fromOffset(K.ENHANCE_SORT_W, K.ENHANCE_BAR_H),
		UDim2.fromOffset(14 + (i - 1) * (K.ENHANCE_SORT_W + K.ENHANCE_SORT_GAP), K.ENHANCE_SORT_Y))
	b.TextScaled = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = K.ENHANCE_SORT_TEXT
	most.Parent = b
	b:SetAttribute("Sort", s.Id)
	sortButtons[s.Id] = b
end

local function placeGroup(u)
	return data and data.Placed[u.Id] and 1 or data and (data.Farm or {})[u.Id] and 2 or 3
end

local function placeMark(u)
	local group = placeGroup(u)
	return group == 1 and "🛡️" or group == 2 and "🌾" or ""
end

local function sortUnits(list, kind)
	sortList = kind
	local by = sortBy[kind]
	for _, s in ipairs(K.SORTS) do
		sortButtons[s.Id].BackgroundColor3 = s.Id == by and K.COLOR_MOVE or K.COLOR_DISABLED
		Lang.set(sortButtons[s.Id], s.Id == by and s.Text .. K.SORT_ARROWS[sortDesc[kind]] or s.Text)
	end
	orderUnits(list, by, sortDesc[kind], placedFirst[kind] and placeGroup or nil, kind == "Fodder")
end

-- the kind and the attribute as pictures (2026-10-05, "여기에도 속성 그림 이런거 다 추가해주고")
local function kindIcons(u)
	local species = Formulas.species(u.Species)
	local theme = species and Formulas.theme(species.Theme)
	local attribute = species and Config.Attributes[species.Attribute]
	return (theme and theme.Icon or "") .. (attribute and attribute.Icon or "")
end
local summaryText = label(enhance, "", UDim2.new(1, -28, 0, 40), UDim2.new(0, 14, 1, -104), 13)
summaryText.TextWrapped = true
summaryText.TextScaled = true -- (2026-10-02: a merge's warnings add lines; they shrink to fit, never past 13)
do
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = 13
	most.Parent = summaryText
end
summaryText.TextXAlignment = Enum.TextXAlignment.Left
local goButton = button(enhance, "⬆️ 강화하기", K.COLOR_ENHANCE, UDim2.new(1, -28, 0, 44), UDim2.new(0, 14, 1, -58))
-- three tabs (2026-10-02): ⬆️ 강화 (Net ask Enhance), 🍎 먹이 (Net ask Feed, Config.Fruit: food grows a dino one size)
-- and 🧬 합성 (Net ask Merge, Config.Merge: three dinos of a rarity into one of the next). The two buttons left of
-- the X open the other two.
K.TABS = { { Id = "Enhance", Text = "⬆️ 강화", Color = K.COLOR_ENHANCE }, { Id = "Feed", Text = "🍎 먹이", Color = K.COLOR_FEED },
	{ Id = "Merge", Text = "🧬 합성", Color = K.COLOR_MERGE } }
local tabButtons = {
	button(enhance, "", K.COLOR_FEED, K.TAB_SIZE, UDim2.new(1, -42 - 2 * (K.TAB_SIZE.X.Offset + K.TAB_GAP), 0, 10)),
	button(enhance, "", K.COLOR_MERGE, K.TAB_SIZE, UDim2.new(1, -42 - (K.TAB_SIZE.X.Offset + K.TAB_GAP), 0, 10)),
}
local mode = "Enhance" -- or "Feed" or "Merge"
local feedTarget = nil -- 🍎: the unit Id chosen to grow
local mergePicked = {} -- unit Ids in the order picked
local mergeKeep = nil -- the Id whose species the new dino gets (⭐)

local enhanceTarget = nil -- unit Id; nil: the window lists the dinos to choose from
local picked = {} -- [unit Id] = true
local portrait = nil
local stallPrompt = nil -- the stall's prompt that opened the window (walking away closes it)

local function unitById(id)
	for _, u in ipairs(data and data.Units or {}) do
		if u.Id == id then
			return u
		end
	end
	return nil
end

-- any species (2026-10-01; its own gives the most), not the target, not placed, not on the farm;
-- cheapest first (low rarity, low level, its own species first, small); at most FODDER_SHOWN
local function fodderList(target)
	local list = {}
	for _, u in ipairs(data.Units) do
		if u.Id ~= target.Id and not data.Placed[u.Id] and not (data.Farm or {})[u.Id] then
			table.insert(list, u)
		end
	end
	table.sort(list, function(a, b)
		local ra, rb = Formulas.rarity(a.Rarity .. "#") or 0, Formulas.rarity(b.Rarity .. "#") or 0
		if ra ~= rb then
			return ra < rb
		end
		if Formulas.unitLevel(a) ~= Formulas.unitLevel(b) then
			return Formulas.unitLevel(a) < Formulas.unitLevel(b)
		end
		local sa, sb = a.Species == target.Species, b.Species == target.Species
		if sa ~= sb then
			return sa
		end
		return Formulas.fodderExp(a) < Formulas.fodderExp(b)
	end)
	for i = #list, K.FODDER_SHOWN + 1, -1 do
		list[i] = nil
	end
	return list
end

local refreshEnhance -- defined below

local function keepSet()
	local keep = {}
	for _, u in ipairs(Formulas.recommendTeam(data.Units, data.Slots, level() + 1, myMap(), data.Farm or {})) do
		keep[u.Id] = true
	end
	return keep
end

function bulk.apply(target, rarityId)
	local count = 0
	for _ in pairs(picked) do
		count += 1
	end
	for _, u in ipairs(fodderList(target)) do
		if count >= Config.Enhance.MaxFodder then
			break
		end
		if u.Rarity == rarityId and not picked[u.Id] then
			picked[u.Id] = true
			count += 1
		end
	end
	refreshEnhance()
end

function bulk.pick(target, rarityId, all)
	if all then
		for _, u in ipairs(fodderList(target)) do
			if u.Rarity == rarityId then
				picked[u.Id] = nil
			end
		end
		refreshEnhance()
		return
	end
	if Formulas.rarityRank(rarityId) < Formulas.rarityRank(K.RARITY_ASK_FROM) then
		bulk.apply(target, rarityId)
		return
	end
	local count, add = 0, 0
	for _ in pairs(picked) do
		count += 1
	end
	for _, u in ipairs(fodderList(target)) do
		if u.Rarity == rarityId and not picked[u.Id] and count + add < Config.Enhance.MaxFodder then
			add += 1
		end
	end
	if add == 0 then
		return
	end
	bulk.text.Text = string.format("%s %d마리를 재료로 고를까요?\n⚠️ 먹인 공룡은 사라져요", Formulas.rarity(rarityId).Name, add)
	bulk.pending = { target.Id, rarityId }
	bulk.ask.Visible = true
end

bulk.yes.Activated:Connect(function()
	bulk.ask.Visible = false
	local pending = bulk.pending
	bulk.pending = nil
	local target = pending and enhanceTarget == pending[1] and unitById(pending[1])
	if target then
		bulk.apply(target, pending[2])
	end
end)
bulk.no.Activated:Connect(function()
	bulk.ask.Visible = false
	bulk.pending = nil
end)

-- first step: every dino, strongest first, to choose the one to enhance
local function showPicker()
	enhanceTarget = nil
	if portrait then
		portrait:Destroy()
		portrait = nil
	end
	enhanceTitle.Text = "1. 공룡 고르기"
	targetText.Text = "👆 강화할 공룡을 누르세요 · ⭐추천 = 가장 많이 세져요"
	expBack.Visible, autoButton.Visible, clearButton.Visible, backButton.Visible = false, false, false, false
	placeList(false, true)
	hintText.Text = "⬆️ 다른 공룡을 먹여서 레벨을 올려요! 크고 좋은 공룡일수록 많이"
	summaryText.Text = ""
	goButton.Visible = false
	Coach.mark(goButton, nil)
	Coach.mark(autoButton, nil)
	for _, c in ipairs(candidates:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
	local units = table.clone(data and data.Units or {})
	sortUnits(units, "Picker")
	local pickId = data and Formulas.enhancePick(data.Units, data.Placed, level() + 1)
	for i, u in ipairs(units) do
		local level = Formulas.unitLevel(u)
		local row = Instance.new("TextButton")
		row.LayoutOrder = u.Id == pickId and 0 or i
		row.BackgroundColor3 = K.COLOR_ROW
		row.Text = ""
		row:SetAttribute("Species", u.Species)
		row:SetAttribute("Card", true)
		DinoPortrait.border(row, u.Rarity)
		row.Parent = candidates
		Coach.mark(row, Formulas.enhanceNeed(u) and (not pickId or u.Id == pickId) and "EnhanceCard" or nil)
		corner(row, 8)
		local icons = label(row, placeMark(u) .. kindIcons(u), UDim2.new(1, -8, 0, K.PICK_ICON_SIZE + 4), UDim2.fromOffset(4, 3),
			K.PICK_ICON_SIZE)
		icons.TextXAlignment = Enum.TextXAlignment.Left
		icons.ZIndex = 3
		if u.Id == pickId then
			local star = label(row, "⭐추천", UDim2.new(1, -6, 0, K.PICK_MARK_SIZE + 4), UDim2.fromOffset(3, 3), K.PICK_MARK_SIZE)
			star.TextXAlignment = Enum.TextXAlignment.Right
			star.TextColor3 = K.COLOR_STAR
			star.ZIndex = 3
		end
		local t = label(row, string.format("%s\n%s · %s\nLv%d%s · ⚔️ %s", Formulas.unitName(u), Formulas.rarity(u.Rarity).Name,
			Formulas.dinoSize(u.Size).Name, level, level >= Config.Enhance.MaxLevel and "⭐" or "",
			Formulas.shortNumber(Formulas.unitStats(u).Damage + 0.5)), UDim2.new(1, -6, 0, K.PICK_TEXT_H), UDim2.new(0, 3, 1, -K.PICK_TEXT_H - 2),
			K.PICK_TEXT_SIZE)
		t.TextWrapped = true
		t.TextScaled = true
		local most = Instance.new("UITextSizeConstraint")
		most.MaxTextSize = K.PICK_TEXT_SIZE
		most.Parent = t
		row.Activated:Connect(function()
			enhanceTarget = u.Id
			picked = {}
			refreshEnhance()
		end)
	end
	if #units == 0 then
		placeList(false)
		label(candidates, "아직 공룡이 없어요", UDim2.new(1, -8, 0, K.ENHANCE_ROW), UDim2.new(), 13)
	end
	candidates.CanvasPosition = Vector2.zero
	task.defer(fillCandidatePortraits)
end

local function attackText(x)
	return x < 100 and string.format("%.1f", x) or Formulas.shortNumber(x + 0.5)
end

local function dinoCard(u, order, text, on, mark)
	local row = Instance.new("TextButton")
	row.LayoutOrder = order
	row.BackgroundColor3 = on and K.COLOR_PICKED or K.COLOR_ROW
	row.Text = ""
	row:SetAttribute("Species", u.Species)
	row:SetAttribute("Card", true)
	DinoPortrait.border(row, u.Rarity)
	row.Parent = candidates
	corner(row, 8)
	local icons = label(row, placeMark(u) .. kindIcons(u), UDim2.new(1, -8, 0, K.PICK_ICON_SIZE + 4), UDim2.fromOffset(4, 3),
		K.PICK_ICON_SIZE)
	icons.TextXAlignment = Enum.TextXAlignment.Left
	icons.ZIndex = 3
	if mark then
		local m = label(row, mark, UDim2.new(1, -6, 0, K.PICK_MARK_SIZE + 4), UDim2.fromOffset(3, 3), K.PICK_MARK_SIZE)
		m.TextXAlignment = Enum.TextXAlignment.Right
		m.ZIndex = 3
	end
	local t = label(row, text, UDim2.new(1, -6, 0, K.PICK_TEXT_H), UDim2.new(0, 3, 1, -K.PICK_TEXT_H - 2), K.PICK_TEXT_SIZE)
	t.TextWrapped = true
	t.TextScaled = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = K.PICK_TEXT_SIZE
	most.Parent = t
	return row, t
end

-- 합성: every top-level dino that is neither placed nor on the farm, the rarest first; pick three of
-- one rarity, ⭐ the one whose species to keep (a picked one tapped again becomes ⭐, the ⭐ tapped
-- again is put back)
local function showMerge()
	if portrait then
		portrait:Destroy()
		portrait = nil
	end
	enhanceTitle.Text = "🧬 합성"
	expBack.Visible, autoButton.Visible, backButton.Visible, clearButton.Visible, goButton.Visible = false, false, false, true, true
	clearButton.Text, clearButton.BackgroundColor3, clearButton.AutoButtonColor = "🧹 선택 해제", K.COLOR_DISABLED, true
	placeList(true, true)
	hintText.Text = string.format("레벨 %d 넘은 같은 등급 %d마리 → 한 등급 위 1마리! (⭐ 고른 공룡으로)",
		Config.Merge.Level, Config.Merge.Count)
	for _, c in ipairs(candidates:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
	local free, held, busy = {}, {}, {}
	for _, u in ipairs(data and data.Units or {}) do
		if Formulas.unitLevel(u) >= Config.Merge.Level then
			busy[u.Id] = data.Placed[u.Id] and "❌ 배치 중" or (data.Farm or {})[u.Id] and "❌ 농장에 있어요" or nil
			table.insert(busy[u.Id] and held or free, u)
		end
	end
	sortUnits(free, "Merge")
	sortUnits(held, "Merge")
	local list = table.move(held, 1, #held, #free + 1, free)
	local pickedSet = {}
	for _, id in ipairs(mergePicked) do
		pickedSet[id] = true
	end
	local pickedFirst = unitById(mergePicked[1] or "")
	local sameRarity = {}
	for _, u in ipairs(list) do
		if not busy[u.Id] then
			sameRarity[u.Rarity] = (sameRarity[u.Rarity] or 0) + 1
		end
	end
	for i, u in ipairs(list) do
		local why = busy[u.Id]
		local on = pickedSet[u.Id] == true and not why
		local row, t = dinoCard(u, i, string.format("%s\n%s · %s\nLv%d · %s", Formulas.unitName(u),
			Formulas.rarity(u.Rarity).Name, Formulas.dinoSize(u.Size).Name, Formulas.unitLevel(u),
			why or string.format("⚔️ %s", Formulas.shortNumber(Formulas.unitStats(u).Damage + 0.5))), on,
			why and "❌" or (mergeKeep == u.Id and "⭐" or "") .. (on and "✅" or "⬜"))
		if why then
			row.AutoButtonColor = false
			row.BackgroundColor3 = K.COLOR_DISABLED
			t.TextColor3 = K.COLOR_WARN
			continue
		end
		if mergeKeep == u.Id then
			t.TextColor3 = K.COLOR_KEEP
		end
		if not on and #mergePicked < Config.Merge.Count and (pickedFirst and pickedFirst.Rarity == u.Rarity
			or not pickedFirst and sameRarity[u.Rarity] >= Config.Merge.Count) then
			Coach.mark(row, "MergeCard")
		end
		row.Activated:Connect(function()
			if on and mergeKeep ~= u.Id then
				mergeKeep = u.Id -- this one's species is kept
			elseif on then
				table.remove(mergePicked, table.find(mergePicked, u.Id))
				mergeKeep = mergePicked[1]
			else
				local first = unitById(mergePicked[1] or "")
				if first and first.Rarity ~= u.Rarity then
					mergePicked = {} -- another rarity: start over with this one
				end
				if #mergePicked < Config.Merge.Count then
					table.insert(mergePicked, u.Id)
				end
				mergeKeep = mergeKeep and table.find(mergePicked, mergeKeep) and mergeKeep or mergePicked[1]
			end
			refreshEnhance()
		end)
	end
	if #list == 0 then
		placeList(true)
		local empty = label(candidates, string.format("레벨 %d 넘은 공룡이 없어요! 먼저 🦖 키워요 (디펜스·농장 공룡은 빼고)",
			Config.Merge.Level), UDim2.new(1, -8, 0, K.ENHANCE_ROW), UDim2.new(), 13)
		empty.TextWrapped = true
	end
	task.defer(fillCandidatePortraits)
	local first = unitById(mergePicked[1] or "")
	local ok, rarityOrWhy = false, nil
	if #mergePicked == Config.Merge.Count then
		ok, rarityOrWhy = Formulas.canMerge({ Units = data.Units, Placed = data.Placed, Farm = data.Farm }, mergePicked,
			mergeKeep, level())
	end
	local keep = unitById(mergeKeep or "")
	targetText.Text = first and string.format("고른 공룡 %d / %d · %s", #mergePicked, Config.Merge.Count,
		Formulas.rarity(first.Rarity).Name) or string.format("👆 같은 등급 %d마리를 골라 주세요", Config.Merge.Count)
	local preview = nil
	if ok then
		local three = {}
		for _, id in ipairs(mergePicked) do
			table.insert(three, unitById(id))
		end
		preview = Formulas.mergeResult(three, mergeKeep, rarityOrWhy)
	end
	summaryText.Text = preview and string.format("→ %s %s · Lv%d · %s · ⚔️ %s", Formulas.rarity(rarityOrWhy).Name,
		Formulas.unitName(keep), preview.Level, Formulas.dinoSize(preview.Size).Name,
		Formulas.shortNumber(Formulas.unitStats(preview).Damage + 0.5))
		or (#mergePicked == Config.Merge.Count and rarityOrWhy or "")
	-- (2026-10-02) what the player gives up, said before: a marked dino (🎖️ 한정, 🗓️ 출석, 🏆 시즌) that is not ⭐
	-- loses its mark with it, and a bigger dino than the result (fed with food, or drawn big) shrinks
	if preview then
		local marked, biggest = false, nil
		for _, id in ipairs(mergePicked) do
			local u = unitById(id)
			if u and id ~= mergeKeep and (u.Limited or u.Attend or u.Season) then
				marked = true
			end
			if u and (not biggest or (Formulas.dinoSize(u.Size .. "#") or 0) > (Formulas.dinoSize(biggest .. "#") or 0)) then
				biggest = u.Size
			end
		end
		if marked then
			summaryText.Text ..= "\n⚠ 🎖️·🗓️·🏆 표시 공룡이 재료로 사라져요 (⭐로 고르면 남아요)"
		end
		if biggest and (Formulas.dinoSize(biggest .. "#") or 0) > (Formulas.dinoSize(preview.Size .. "#") or 0) then
			summaryText.Text ..= string.format("\n⚠ 가장 큰 재료(%s)보다 작게 나와요. 공격력은 위 숫자를 보세요",
				Formulas.dinoSize(biggest).Name)
		end
	end
	summaryText.TextColor3 = ok and K.COLOR_KEEP or K.COLOR_WARN
	goButton.BackgroundColor3 = ok and K.COLOR_MERGE or K.COLOR_DISABLED
	goButton.AutoButtonColor = ok
	goButton.Text = ok and string.format("🧬 합성하기 (%s %d마리 사용)", Formulas.rarity(first.Rarity).Name, Config.Merge.Count)
		or string.format("공룡 %d마리를 고르세요", Config.Merge.Count)
	Coach.mark(goButton, ok and "MergeGo" or nil)
	Coach.mark(autoButton, nil)
end

-- 🍎 먹이 (2026-10-02, 공룡 사육): every dino; choose one, the button feeds it with
-- the food from the trees' fruit (player attribute Fruit)
local function showFeed()
	if portrait then
		portrait:Destroy()
		portrait = nil
	end
	local food = player:GetAttribute("Fruit") or 0
	enhanceTitle.Text = "🍎 먹이 주기"
	expBack.Visible, autoButton.Visible, backButton.Visible, clearButton.Visible, goButton.Visible = false, true, false, true, true
	placeList(true, true)
	hintText.Text = "🌳 나무를 찰싹 치면 열매가 떨어져요. 주우면 🍎 먹이! 먹이는 조금씩 넣어도 쌓이고, 다 차면 한 단계 커져요"
	for _, c in ipairs(candidates:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
	local units = table.clone(data and data.Units or {})
	sortUnits(units, "Feed")
	local chosen = nil
	for i, u in ipairs(units) do
		local on = feedTarget == u.Id
		chosen = on and u or chosen
		local cost = Formulas.feedCost(u)
		local nextSize = Formulas.nextDinoSize(u.Size)
		local row = dinoCard(u, i, cost and string.format("%s\n%s %s → %s\n⚔️ %s · 🍎 %d/%d", Formulas.unitName(u),
			Formulas.rarity(u.Rarity).Name, Formulas.dinoSize(u.Size).Name, nextSize.Name,
			Formulas.shortNumber(Formulas.unitStats(u).Damage + 0.5), u.Fed or 0, cost)
			or string.format("%s\n%s %s\n⚔️ %s · 가장 큰 크기", Formulas.unitName(u), Formulas.rarity(u.Rarity).Name,
				Formulas.dinoSize(u.Size).Name, Formulas.shortNumber(Formulas.unitStats(u).Damage + 0.5)), on, on and "✅" or nil)
		if cost then
			Coach.mark(row, "FeedCard")
			local back = Instance.new("Frame")
			back.BorderSizePixel = 0
			back.BackgroundColor3 = K.COLOR_FEED
			back.BackgroundTransparency = K.FEED_BAR_BACK
			back.Size = UDim2.new(1, -8, 0, K.FEED_BAR_H)
			back.Position = UDim2.new(0, 4, 1, -K.PICK_TEXT_H - K.FEED_BAR_H - 4)
			back.ZIndex = 3
			back.Parent = row
			local fill = Instance.new("Frame")
			fill.BorderSizePixel = 0
			fill.BackgroundColor3 = K.COLOR_FEED
			fill.Size = UDim2.fromScale(math.clamp((u.Fed or 0) / cost, 0, 1), 1)
			fill.ZIndex = 3
			fill.Parent = back
		end
		row.Activated:Connect(function()
			feedTarget = u.Id
			refreshEnhance()
		end)
	end
	if #units == 0 then
		placeList(true)
		label(candidates, "아직 공룡이 없어요", UDim2.new(1, -8, 0, K.ENHANCE_ROW), UDim2.new(), 13)
	end
	task.defer(fillCandidatePortraits)
	local ok, costOrWhy = false, nil
	if chosen then
		ok, costOrWhy = Formulas.canFeed({ Units = data.Units, Placed = data.Placed, Farm = data.Farm, Fruit = food }, chosen.Id)
		portrait = DinoPortrait.new(chosen.Species, UDim2.fromOffset(60, 60))
		DinoPortrait.border(portrait, chosen.Rarity)
		portrait.Position = UDim2.fromOffset(14, 40)
		portrait.Parent = enhance
	end
	targetText.Text = chosen and string.format("%s · %s %s\n%s · 🍎 가진 먹이 %d", Formulas.unitName(chosen),
		Formulas.rarity(chosen.Rarity).Name, Formulas.dinoSize(chosen.Size).Name, kindIcons(chosen), food)
		or string.format("키울 공룡을 누르세요\n🍎 가진 먹이 %d", food)
	local after = chosen and Formulas.nextDinoSize(chosen.Size)
	summaryText.Text = not chosen and ""
		or ok and string.format("🍎 %d / %d → %s · ⚔️ %s → %s", chosen.Fed or 0, Formulas.feedCost(chosen), after.Name,
			Formulas.shortNumber(Formulas.unitStats(chosen).Damage + 0.5),
			Formulas.shortNumber(Formulas.unitStats({ Species = chosen.Species, Rarity = chosen.Rarity, Size = after.Id,
				Mutation = chosen.Mutation, Level = chosen.Level }).Damage + 0.5))
		or costOrWhy
	summaryText.TextColor3 = ok and K.COLOR_KEEP or K.COLOR_WARN
	goButton.BackgroundColor3 = ok and K.COLOR_FEED or K.COLOR_DISABLED
	goButton.AutoButtonColor = ok
	goButton.Text = ok and string.format("🍎 먹이 주기 (🍎 %d 사용)", costOrWhy) or not chosen and "공룡을 고르세요"
		or "🍎 먹이가 모자라거나 줄 수 없어요"
	Coach.mark(goButton, ok and "FeedGo" or nil)
	Coach.mark(autoButton, nil)
	for i, b in ipairs({ autoButton, clearButton }) do
		local amount = i == 1 and K.FEED_ONE or K.FEED_TEN
		local can = chosen and Formulas.canFeed({ Units = data.Units, Placed = data.Placed, Farm = data.Farm, Fruit = food },
			chosen.Id, amount)
		b.Text = string.format("🍎 %d개 넣기", amount)
		b.BackgroundColor3 = can and K.COLOR_FEED or K.COLOR_DISABLED
		b.AutoButtonColor = can and true or false
	end
end

function refreshEnhance()
	local i = 0
	for _, tab in ipairs(K.TABS) do
		if tab.Id ~= mode then
			i += 1
			tabButtons[i].Text = tab.Text
			tabButtons[i].BackgroundColor3 = tab.Color
			tabButtons[i]:SetAttribute("Tab", tab.Id)
			Coach.mark(tabButtons[i], tab.Id .. "Tab")
		end
	end
	if mode == "Merge" then
		showMerge()
		return
	elseif mode == "Feed" then
		showFeed()
		return
	end
	local target = enhanceTarget and unitById(enhanceTarget)
	if not target then
		showPicker()
		return
	end
	expBack.Visible, autoButton.Visible, clearButton.Visible, backButton.Visible, goButton.Visible = true, true, true, true, true
	autoButton.Text, autoButton.BackgroundColor3, autoButton.AutoButtonColor = "✨ 추천 선택", K.COLOR_MOVE, true
	clearButton.Text, clearButton.BackgroundColor3, clearButton.AutoButtonColor = "🧹 선택 해제", K.COLOR_DISABLED, true
	placeList(true, false, true)
	enhanceTitle.Text = "2. 재료 고르기"
	hintText.Text = "⚠️ 먹인 공룡은 사라져요! ✨ 추천 선택은 배치에 안 쓸 약한 공룡만 골라요"
	if portrait then
		portrait:Destroy()
	end
	portrait = DinoPortrait.new(target.Species, UDim2.fromOffset(60, 60))
	DinoPortrait.border(portrait, target.Rarity)
	portrait.Position = UDim2.fromOffset(14, 40)
	portrait.Parent = enhance
	local level = Formulas.unitLevel(target)
	local need = Formulas.enhanceNeed(target)
	local damage = Formulas.unitStats(target).Damage
	local nextDamage = Formulas.unitStats({ Species = target.Species, Rarity = target.Rarity, Size = target.Size,
		Mutation = target.Mutation, Level = math.min(level + 1, Config.Enhance.MaxLevel) }).Damage
	targetText.Text = string.format("%s Lv%d/%d · %s %s\n%s · ⚔️ %s%s", Formulas.unitName(target), level,
		Config.Enhance.MaxLevel, Formulas.rarity(target.Rarity).Name, Formulas.dinoSize(target.Size).Name,
		kindIcons(target), attackText(damage), need and string.format(" → 다음 레벨 %s (+%d%%)", attackText(nextDamage),
		math.floor((nextDamage / math.max(damage, 1e-6) - 1) * 100 + 0.5)) or " (최고 레벨)")
	expFill.Size = UDim2.fromScale(need and math.clamp((target.Exp or 0) / need, 0, 1) or 1, 1)
	expText.Text = need and string.format("경험치 %s / %s", Formulas.shortNumber(target.Exp or 0), Formulas.shortNumber(need))
		or "최고 레벨"

	for _, c in ipairs(candidates:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
	local list = fodderList(target)
	sortUnits(list, "Fodder")
	local count, exp, rare = 0, 0, false
	local fodderRows, autoCan = {}, #Formulas.fodderPlan(target, list, keepSet()) > 0
	for i, u in ipairs(list) do
		local on = picked[u.Id] == true
		if on then
			count += 1
			exp += Formulas.fodderExp(u, target)
			rare = rare or (Formulas.rarity(u.Rarity .. "#") or 1) >= (Formulas.rarity("Rare#") or 3)
				or (Formulas.dinoSize(u.Size .. "#") or 1) >= (Formulas.dinoSize(K.GROWN_FROM .. "#") or 10)
				or Formulas.unitLevel(u) > 1 or (u.Fed or 0) > 0
		end
		local row = Instance.new("TextButton")
		row.LayoutOrder = i
		row.Size = UDim2.new(1, -8, 0, K.ENHANCE_ROW)
		row.BackgroundColor3 = on and K.COLOR_PICKED or K.COLOR_ROW
		row.AutoButtonColor = true
		row.Text = ""
		row:SetAttribute("Species", u.Species)
		DinoPortrait.border(row, u.Rarity)
		row.Parent = candidates
		table.insert(fodderRows, row)
		corner(row, 8)
		local level = Formulas.unitLevel(u)
		local t = label(row, string.format("%s %s · %s %s%s · ⚔️ %s\n%s · 경험치 +%s", on and "✅" or "⬜",
			Formulas.unitName(u), Formulas.rarity(u.Rarity).Name, Formulas.dinoSize(u.Size).Name,
			level > 1 and (" Lv" .. level) or "", Formulas.shortNumber(Formulas.unitStats(u).Damage + 0.5), kindIcons(u),
			Formulas.shortNumber(Formulas.fodderExp(u, target))),
			UDim2.new(1, -K.ENHANCE_PORTRAIT - 16, 1, 0), UDim2.fromOffset(K.ENHANCE_PORTRAIT + 10, 0), 13)
		t.TextWrapped = true
		t.TextXAlignment = Enum.TextXAlignment.Left
		row.Activated:Connect(function()
			if picked[u.Id] then
				picked[u.Id] = nil
			elseif count < Config.Enhance.MaxFodder then
				picked[u.Id] = true
			end
			refreshEnhance()
		end)
	end
	for _, c in ipairs(bulk.row:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
	local byRarity, pickedBy = {}, {}
	for _, u in ipairs(list) do
		byRarity[u.Rarity] = (byRarity[u.Rarity] or 0) + 1
		if picked[u.Id] then
			pickedBy[u.Rarity] = (pickedBy[u.Rarity] or 0) + 1
		end
	end
	for id, n in pairs(byRarity) do
		local all = pickedBy[id] == n
		local chip = button(bulk.row, string.format("%s%s %d", all and "✅ " or "", Formulas.rarity(id).Name, n),
			DinoPortrait.gradeColor(id), UDim2.fromOffset(K.RARITY_CHIP_W, K.RARITY_ROW_H), UDim2.new())
		chip.AutomaticSize = Enum.AutomaticSize.X
		chip.LayoutOrder = Formulas.rarityRank(id)
		chip.TextSize = K.RARITY_CHIP_TEXT
		chip.TextStrokeTransparency = 0.3
		local pad = Instance.new("UIPadding")
		pad.PaddingLeft, pad.PaddingRight = UDim.new(0, K.RARITY_CHIP_PAD), UDim.new(0, K.RARITY_CHIP_PAD)
		pad.Parent = chip
		chip.Activated:Connect(function()
			bulk.pick(target, id, all)
		end)
	end
	if #list == 0 then
		local empty = label(candidates, "🦖 재료로 쓸 공룡이 없어요 (아레나·농장 공룡은 빼고)",
			UDim2.new(1, -8, 0, K.ENHANCE_ROW), UDim2.new(), 13)
		empty.TextWrapped = true
	end
	task.defer(fillCandidatePortraits)
	local after = { Rarity = target.Rarity, Level = level, Exp = target.Exp or 0 }
	Formulas.addExp(after, exp)
	summaryText.Text = count == 0 and "재료를 골라 주세요"
		or string.format("재료 %d마리 · 경험치 +%s → Lv%d%s", count, Formulas.shortNumber(exp), Formulas.unitLevel(after),
			rare and "\n⚠ 희귀 이상·강화했거나 큰 공룡이 재료에 있어요" or "")
	summaryText.TextColor3 = rare and K.COLOR_WARN or Color3.new(1, 1, 1)
	local ready = count > 0 and need ~= nil
	goButton.BackgroundColor3 = ready and K.COLOR_ENHANCE or K.COLOR_DISABLED
	goButton.AutoButtonColor = ready
	goButton.Text = not need and "최고 레벨이에요" or ready and string.format("⬆️ 강화할까요? (재료 %d마리 사용)", count)
		or "재료를 고르세요"
	for _, r in ipairs(fodderRows) do
		Coach.mark(r, count == 0 and need and "EnhanceFodder" or nil)
	end
	Coach.mark(autoButton, count == 0 and need and autoCan and "EnhanceAuto" or nil)
	Coach.mark(goButton, ready and "EnhanceGo" or nil)
end

-- (2026-10-04) the boards beside the arena's and the farm's slot signs (PlaceBoards service): the placing window

-- the stall's prompt (Enhance service): only this player's own stall
ProximityPromptService.PromptTriggered:Connect(function(prompt)
	if prompt:GetAttribute("Kind") == "Enhance" and prompt:GetAttribute("Base") == player:GetAttribute("Base") then
		if enhance.Visible then -- E again closes it
			enhance.Visible = false
			return
		end
		stallPrompt = prompt
		local fresh = Net.ask("GetMyUnits")
		if fresh then
			data = fresh
		end
		enhanceTarget, picked = nil, {}
		enhance.Visible = true
		refreshEnhance()
	end
end)
RunService.Heartbeat:Connect(FrameMeter.wrap("Placement", function() -- walked away from the stall: close it
	if enhance.Visible and stallPrompt then
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		local holder = stallPrompt.Parent -- (a part, or an attachment: Bases.prompt, 2026-10-02)
		local at = holder and (holder:IsA("Attachment") and holder.WorldPosition or holder:IsA("BasePart") and holder.Position)
		if not root or not at or (root.Position - at).Magnitude > stallPrompt.MaxActivationDistance + 8 then
			enhance.Visible = false
		end
	end
end))
backButton.Activated:Connect(function()
	picked = {}
	showPicker()
end)
for _, b in pairs(sortButtons) do
	b.Activated:Connect(function()
		local by = b:GetAttribute("Sort")
		if sortBy[sortList] == by then
			sortDesc[sortList] = not sortDesc[sortList]
		else
			sortDesc[sortList] = sortList ~= "Fodder" or by == "Attribute"
		end
		sortBy[sortList] = by
		if sortList == "Picker" then
			showPicker()
		else
			refreshEnhance()
		end
		candidates.CanvasPosition = Vector2.zero
	end)
end

autoButton.Activated:Connect(function()
	if mode == "Feed" then
		return
	end
	local target = enhanceTarget and unitById(enhanceTarget)
	if not target or not Formulas.enhanceNeed(target) then
		return
	end
	picked = {}
	local ids = Formulas.fodderPlan(target, fodderList(target), keepSet())
	for _, id in ipairs(ids) do
		picked[id] = true
	end
	if #ids == 0 then
		Notices.show(nil, "✨ 재료로 쓸 약한 공룡이 없어요 · 센 공룡은 배치에 써요")
	end
	refreshEnhance()
end)
clearButton.Activated:Connect(function()
	if mode == "Feed" then
		return
	end
	picked = {}
	mergePicked, mergeKeep = {}, nil
	refreshEnhance()
end)
for _, tab in ipairs(tabButtons) do
	tab.Activated:Connect(function()
		mode = tab:GetAttribute("Tab") or "Enhance"
		picked, mergePicked, mergeKeep, enhanceTarget, feedTarget = {}, {}, nil, nil, nil
		refreshEnhance()
	end)
end
enhanceClose.Activated:Connect(function()
	enhance.Visible = false
end)
player:GetAttributeChangedSignal("Fruit"):Connect(function() -- (fruit picked up while the 🍎 tab is open)
	if enhance.Visible and mode == "Feed" then
		refreshEnhance()
	end
end)
local mergeResult = Instance.new("Frame")
mergeResult.AnchorPoint = Vector2.new(0.5, 0.5)
mergeResult.Position = UDim2.fromScale(0.5, 0.5)
mergeResult.Size = K.MERGE_RESULT_SIZE
mergeResult.BackgroundColor3 = K.COLOR_BG
mergeResult.Visible = false
mergeResult.ZIndex = 6
mergeResult.Parent = gui
corner(mergeResult, 14)
Windows.fit(mergeResult)
local mergeTitle = label(mergeResult, "🧬 합성 성공!", UDim2.new(1, -60, 0, 34), UDim2.fromOffset(14, 8), 22)
mergeTitle.Font = Enum.Font.GothamBlack
mergeTitle.TextColor3 = K.COLOR_KEEP
local mergePicture = Instance.new("Frame")
mergePicture.AnchorPoint = Vector2.new(0.5, 0)
mergePicture.Position = UDim2.new(0.5, 0, 0, 46)
mergePicture.Size = UDim2.fromOffset(K.MERGE_PICTURE, K.MERGE_PICTURE)
mergePicture.BackgroundTransparency = 1
mergePicture.Parent = mergeResult
local mergeRarity = label(mergeResult, "", UDim2.new(1, -28, 0, 28), UDim2.fromOffset(14, 46 + K.MERGE_PICTURE + 4), 22)
mergeRarity.Font = Enum.Font.GothamBlack
mergeRarity.TextStrokeTransparency = 0
local mergeName = label(mergeResult, "", UDim2.new(1, -28, 0, 24), UDim2.fromOffset(14, 46 + K.MERGE_PICTURE + 32), 18)
local mergeInfo = label(mergeResult, "", UDim2.new(1, -28, 0, 20), UDim2.fromOffset(14, 46 + K.MERGE_PICTURE + 56), 15)
local mergeNote = label(mergeResult, "🦖 배치 창에서 바로 놓을 수 있어요", UDim2.new(1, -28, 0, 18),
	UDim2.fromOffset(14, 46 + K.MERGE_PICTURE + 78), 13)
mergeNote.TextColor3 = K.COLOR_EXP
for _, l in ipairs({ mergeTitle, mergeRarity, mergeName, mergeInfo, mergeNote }) do
	l.TextScaled = true
end
local mergeOk = button(mergeResult, "✅ 확인", K.COLOR_MOVE, K.MERGE_OK_SIZE,
	UDim2.new(0.5, -K.MERGE_OK_SIZE.X.Offset / 2, 1, -K.MERGE_OK_SIZE.Y.Offset - 12))
local mergeScale = Instance.new("UIScale")
mergeScale.Parent = mergePicture
local function closeMergeResult()
	mergeResult.Visible = false
	for _, c in ipairs(mergePicture:GetChildren()) do
		if not c:IsA("UIScale") then
			c:Destroy()
		end
	end
end
mergeOk.Activated:Connect(closeMergeResult)
Windows.register(mergeResult, closeMergeResult)
local function showMergeResult(made)
	closeMergeResult()
	local color = DinoPortrait.gradeColor(made.Rarity)
	local unique = GachaFx.has(made.Rarity)
	if unique then
		GachaFx.suspense(made.Rarity, color)
	end
	local picture = Pictures.of({ "Dino", "Dino_" .. made.Species }, UDim2.fromScale(1, 1))
		or DinoPortrait.new(made.Species, UDim2.fromScale(1, 1))
	picture.Parent = mergePicture
	mergeRarity.Text = Formulas.rarity(made.Rarity).Name
	DinoPortrait.paint(mergeRarity, made.Rarity)
	mergeName.Text = Formulas.unitName(made)
	mergeInfo.Text = string.format("📏 %s · Lv %d · ⚔️ %s", Formulas.dinoSize(made.Size).Name, Formulas.unitLevel(made),
		Formulas.shortNumber(Formulas.unitStats(made).Damage + 0.5))
	DinoPortrait.border(mergeResult, made.Rarity, 3)
	mergeResult.Visible = true
	mergeScale.Scale = K.MERGE_POP
	TweenService:Create(mergeScale, TweenInfo.new(K.MERGE_POP_SECONDS, Enum.EasingStyle.Back), { Scale = 1 }):Play()
	if unique then
		GachaFx.burst(made.Rarity, color, mergeResult)
	else
		Sfx.play("GachaBig")
	end
end

local enhancing = false
local function doMerge()
	if enhancing or not goButton.AutoButtonColor then
		return
	end
	enhancing = true
	local answer = Net.ask("Merge", mergePicked, mergeKeep)
	enhancing = false
	mergePicked, mergeKeep = {}, nil
	local fresh = Net.ask("GetMyUnits")
	if fresh then
		data = fresh
		if panel.Visible then
			rebuildList()
		end
	end
	refreshEnhance()
	if not answer or answer.Error then
		summaryText.Text = answer and answer.Error or "⏳ 잠시 뒤에 다시 해 보세요"
		summaryText.TextColor3 = K.COLOR_WARN
		return
	end
	local made = answer.Unit
	summaryText.Text = string.format("🧬 합성 성공! %s %s (%s, Lv%d)", Formulas.rarity(made.Rarity).Name,
		Formulas.unitName(made), Formulas.dinoSize(made.Size).Name, Formulas.unitLevel(made))
	summaryText.TextColor3 = K.COLOR_KEEP
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if root then
		Fx.confetti(root.Position + Vector3.new(0, 3, 0))
	end
	showMergeResult(made)
end
local function doFeed(amount, from)
	if enhancing or not from.AutoButtonColor or not feedTarget then
		return
	end
	enhancing = true
	local answer = Net.ask("Feed", feedTarget, amount)
	enhancing = false
	local fresh = Net.ask("GetMyUnits")
	if fresh then
		data = fresh
		if panel.Visible then
			rebuildList()
		end
	end
	refreshEnhance()
	if not answer or answer.Error then
		summaryText.Text = answer and answer.Error or "⏳ 잠시 뒤에 다시 해 보세요"
		summaryText.TextColor3 = K.COLOR_WARN
		return
	end
	if not answer.Grew then
		summaryText.Text = string.format("🍎 냠냠! %d 넣었어요 (%d / %d)", answer.Put or 0, answer.Unit.Fed or 0,
			Formulas.feedCost(answer.Unit) or 0)
		summaryText.TextColor3 = K.COLOR_KEEP
		Sfx.play("Deposit")
		return
	end
	summaryText.Text = string.format("🍎 냠냠! %s → %s 크기가 됐어요!", Formulas.unitName(answer.Unit),
		Formulas.dinoSize(answer.Unit.Size).Name)
	summaryText.TextColor3 = K.COLOR_KEEP
	Sfx.play("LevelUp")
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if root then
		Fx.confetti(root.Position + Vector3.new(0, 3, 0))
	end
end
for i, b in ipairs({ autoButton, clearButton }) do
	b.Activated:Connect(function()
		if mode == "Feed" then
			doFeed(i == 1 and K.FEED_ONE or K.FEED_TEN, b)
		end
	end)
end
goButton.Activated:Connect(function()
	if mode == "Merge" then
		doMerge()
		return
	elseif mode == "Feed" then
		doFeed(math.max(1, player:GetAttribute("Fruit") or 0), goButton)
		return
	end
	local ids = {}
	for id in pairs(picked) do
		table.insert(ids, id)
	end
	if enhancing or #ids == 0 or not enhanceTarget or not goButton.AutoButtonColor then -- grey: nothing to do yet
		return
	end
	enhancing = true
	local before = unitById(enhanceTarget)
	local beforeDamage = before and Formulas.unitStats(before).Damage
	local answer = Net.ask("Enhance", enhanceTarget, ids)
	enhancing = false
	picked = {}
	if answer and answer.Error then
		summaryText.Text = answer.Error
		return
	end
	local fresh = Net.ask("GetMyUnits")
	if fresh then
		data = fresh
		if panel.Visible then
			rebuildList()
		end
	end
	refreshEnhance()
	if answer and answer.Gained and answer.Gained > 0 then
		local after = unitById(enhanceTarget)
		local afterDamage = after and Formulas.unitStats(after).Damage
		summaryText.Text = beforeDamage and afterDamage and string.format("⬆️ 레벨 업! Lv%d · ⚔️ %s → %s (+%d%%)", answer.Level,
			attackText(beforeDamage), attackText(afterDamage), math.floor((afterDamage / math.max(beforeDamage, 1e-6) - 1) * 100 + 0.5))
			or string.format("⬆️ 레벨 업! Lv%d (재료 %d마리, 경험치 +%s)", answer.Level, answer.Used, Formulas.shortNumber(answer.ExpAdded))
		summaryText.TextColor3 = K.COLOR_EXP
		Sfx.play("LevelUp")
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if root then
			Fx.confetti(root.Position + Vector3.new(0, 3, 0))
		end
	end
end)

openButton.Activated:Connect(function()
	panel.Visible = not panel.Visible
	if panel.Visible then
		panel:SetAttribute("FarmFirst", false)
		reload()
	else
		showRings()
	end
end)
close.Activated:Connect(function()
	panel.Visible = false
	showRings()
end)
-- (2026-10-04, the onboarding funnel: 2 of 5 left on the tutorial's first "공룡 놓기") on the tutorial's placing steps
-- the list opens by itself a moment after the step starts (the finger then points at "배치" and "✅ 놓기")
K.TUTORIAL_PLACE_STEPS = { Place1 = true, Place2 = true }
K.TUTORIAL_OPEN_DELAY = 1.2 -- seconds: the draw's window closes first
player:GetAttributeChangedSignal("TutorialStep"):Connect(function()
	local step = player:GetAttribute("TutorialStep")
	if not K.TUTORIAL_PLACE_STEPS[step] then
		return
	end
	task.delay(K.TUTORIAL_OPEN_DELAY, function()
		if player:GetAttribute("TutorialStep") == step and not player:GetAttribute("TutorialSkip") and not panel.Visible then
			panel:SetAttribute("FarmFirst", false)
			panel.Visible = true
			reload()
		end
	end)
end)
player:GetAttributeChangedSignal("UnitsVersion"):Connect(reload)
player:GetAttributeChangedSignal("FarmCount"):Connect(function() -- the farm changed (Farm service)
	if panel.Visible then
		reload()
	end
end)
player:GetAttributeChangedSignal("DefenseSlots"):Connect(reload)

-- ---------------------------------------------------------------------------
-- Placing
-- ---------------------------------------------------------------------------

local ghost, ghostRing, silhouette, glow = nil, nil, nil, nil
local carried = nil -- (2026-10-04) the placed dino being moved: hidden on this screen while its silhouette is carried

-- a see-through copy of the dino being placed (ReplicatedStorage.DinoModels), its size scale applied
local function makeSilhouette(unit, stats)
	local folder = ReplicatedStorage:FindFirstChild("DinoModels")
	local source = folder and folder:FindFirstChild("Dino_" .. unit.Species)
	local model = Instance.new("Model")
	model.Name = "PlacingSilhouette"
	if source then
		source:Clone().Parent = model
	else
		local p = Instance.new("Part")
		p.Size = Vector3.new(1.4, 2.4, 2)
		p.Parent = model
	end
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
			d.Transparency = K.SILHOUETTE_PARTS
			d.Material = Enum.Material.Neon -- one glowing see-through color (ForceField was nearly invisible)
			d.Color = K.COLOR_OK
			if d:IsA("MeshPart") then
				pcall(function() -- some places refuse texture changes at run time; the color still shows
					d.TextureID = ""
				end)
			end
		elseif d:IsA("SurfaceAppearance") or d:IsA("Decal") or d:IsA("Texture") then
			d:Destroy()
		end
	end
	model.WorldPivot = CFrame.new(model:GetBoundingBox().Position) -- upright (an imported pivot can be turned)
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0)) -- bottom middle, upright
	model:ScaleTo(Formulas.drawnScale(stats))
	local highlight = Instance.new("Highlight")
	highlight.FillColor = K.COLOR_OK
	highlight.OutlineColor = K.COLOR_OK
	highlight.FillTransparency = K.SILHOUETTE_FILL
	highlight.OutlineTransparency = 0
	highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop -- the outline shows even where the platform covers it
	highlight.Parent = model
	model.Parent = previewFolder
	return model, highlight
end
local spot = nil -- { x, z, fits, why }: where the silhouette stands now (the arena's flat frame)
local dragging = nil -- the mouse button or finger dragging the silhouette

local tip = label(gui, "", UDim2.new(0, 460, 0, 26), UDim2.new(0.5, -230, 0, 34), 17)
tip.Visible = false
tip.ZIndex = 5
local spotInfo = label(gui, "", UDim2.new(0, 460, 0, 22), UDim2.new(0.5, -230, 0, 34 + 26), 15)
spotInfo.Visible = false
spotInfo.ZIndex = 5
local spotInfoKey = nil -- (the dino and spot spotInfo was worked out for)
local cancel = button(gui, "❌ 취소", K.COLOR_REMOVE, K.PLACE_BUTTON_SIZE,
	UDim2.new(0.5, -K.PLACE_BUTTON_SIZE.X.Offset - K.PLACE_BUTTON_GAP / 2, 1, K.PLACE_BUTTON_Y))
cancel.Visible = false
cancel.ZIndex = 5
local confirmButton = button(gui, "✅ 놓기", K.COLOR_OK_BUTTON, K.PLACE_BUTTON_SIZE,
	UDim2.new(0.5, K.PLACE_BUTTON_GAP / 2, 1, K.PLACE_BUTTON_Y))
confirmButton.Visible = false
confirmButton.ZIndex = 5
Coach.mark(confirmButton, "PlaceOk")
local autoTop = false
local topToggle = button(gui, "🗺️", K.COLOR_MOVE, K.TOPVIEW_PLACE_SIZE,
	UDim2.new(0.5, -K.PLACE_BUTTON_SIZE.X.Offset - K.PLACE_BUTTON_GAP * 1.5 - K.TOPVIEW_PLACE_SIZE.X.Offset, 1, K.PLACE_BUTTON_Y))
topToggle.Visible = false
topToggle.ZIndex = 5
topToggle.Activated:Connect(function()
	autoTop = false
	player:SetAttribute("TopView", not player:GetAttribute("TopView") or nil)
end)
-- while placing, these invisible layers take the presses and drags (so a finger moving the silhouette
-- doesn't turn the camera). They leave the phone's move stick (bottom left), the right edge's
-- buttons and the slap / jump buttons uncovered: over the whole screen they froze moving and the
-- camera for as long as placing went on
local catchers = {}
local topCatchGui = Instance.new("ScreenGui")
topCatchGui.Name = "PlacementTopCatch"
topCatchGui.ResetOnSpawn = false
topCatchGui.IgnoreGuiInset = true
topCatchGui.DisplayOrder = K.TOP_CATCH_ORDER
topCatchGui.Parent = player.PlayerGui
for _, area in ipairs({
	{ UDim2.new(1, -K.CATCHER_RIGHT, 1 / 3, 0), UDim2.new() }, -- the top third
	{ UDim2.new(1 - K.CATCHER_STICK, -K.CATCHER_RIGHT, 2 / 3, 0), UDim2.new(K.CATCHER_STICK, 0, 1 / 3, 0) }, -- right of the stick
	{ UDim2.fromScale(1, 1), UDim2.new(), true },
}) do
	local c = Instance.new("TextButton")
	c.Name = "DragCatcher"
	c.Size, c.Position = area[1], area[2]
	c.BackgroundTransparency = 1
	c.Text = ""
	c.AutoButtonColor = false
	c.Visible = false
	c.ZIndex = 1
	c:SetAttribute("TopOnly", area[3] == true)
	c.Parent = area[3] and topCatchGui or gui
	table.insert(catchers, c)
end
local function showCatchers(on)
	local top = player:GetAttribute("TopView") == true
	for _, c in ipairs(catchers) do
		c.Visible = on and c:GetAttribute("TopOnly") == top
	end
end
local spotGuide = nil
local function clearSpotGuide()
	if spotGuide then
		spotGuide.ring:Destroy()
		spotGuide.anchor:Destroy()
		spotGuide.mark:Destroy()
		spotGuide = nil
	end
end
local function onSpot()
	return spotGuide ~= nil and spot ~= nil and math.abs(spot.x - spotGuide.x) <= K.SPOT_SAME
		and math.abs(spot.z - spotGuide.z) <= K.SPOT_SAME
end
local function stopPlacing(keepView)
	clearSpotGuide()
	placing = nil
	spot = nil
	dragging = nil
	if carried then
		carried:SetAttribute("PlacingHidden", nil) -- (DefenseView shows it again)
		carried = nil
	end
	if ghost then
		ghost:Destroy()
		ghostRing:Destroy()
		silhouette:Destroy()
		ghost, ghostRing, silhouette, glow = nil, nil, nil, nil
	end
	tip.Visible = false
	spotInfo.Visible = false
	cancel.Visible = false
	topToggle.Visible = false
	showCatchers(false)
	confirmButton.Visible = false
	player:SetAttribute("PlacingUnit", nil)
	showRings()
	if autoTop and not keepView then
		autoTop = false
		player:SetAttribute("TopView", nil)
	end
end
Net.onPush("OpenPlacement", function(farm)
	if placing then
		stopPlacing()
	end
	panel:SetAttribute("FarmFirst", farm == true)
	list.CanvasPosition = Vector2.zero
	panel.Visible = true
	reload()
end)

local function others()
	local list2 = {}
	local byId = {}
	for _, u in ipairs(data.Units) do
		byId[u.Id] = u
	end
	for id, pos in pairs(data.Placed) do
		if byId[id] and id ~= placing.unit.Id then
			table.insert(list2, { X = pos.X, Z = pos.Z, Footprint = Formulas.unitStats(byId[id]).Footprint })
		end
	end
	return list2
end

-- does the dino fit at (x, z)? (the server checks again)
local function judge(x, z)
	local sea, sky = Formulas.isSea(placing.stats), Formulas.isSky(placing.stats)
	if sea then
		local _, pond = Formulas.pondAt((myMap()), x, z, Config.Defense.Pond.Snap)
		if pond then
			x, z = pond[1], pond[2]
		end
	elseif sky and Formulas.perchAt((myMap()), x, z, Config.Defense.Perch.Snap) then
		x, z = Formulas.perchSnap((myMap()), x, z)
	else
		x, z = Formulas.nestSnap((myMap()), x, z, placing.stats.Footprint)
	end
	local fits, why = Formulas.placementFits(x, z, placing.stats.Footprint, others(), (myMap()), sea, sky)
	if fits and not data.Placed[placing.unit.Id] and placedCount() >= data.Slots then
		fits, why = false, "공룡 자리가 꽉 찼어요"
	end
	return { x = x, z = z, fits = fits, why = why }
end

-- the platform point under a screen position (GUI coordinates, as an InputObject gives them)
local function platformAt(screen)
	local frame = myFrame()
	local camera = Workspace.CurrentCamera
	if not frame or not camera then
		return nil
	end
	local ray = camera:ScreenPointToRay(screen.X, screen.Y)
	local planeY = (frame * Vector3.new(0, select(2, myMap()), 0)).Y
	if math.abs(ray.Direction.Y) < 1e-4 then
		return nil
	end
	local t = (planeY - ray.Origin.Y) / ray.Direction.Y
	if t < 0 then
		return nil
	end
	local lp = frame:PointToObjectSpace(ray.Origin + ray.Direction * t)
	return lp.X, lp.Z
end

-- where a new dino starts: (2026-10-02, 배치 도움; 2026-10-06 the map's best free spot, Formulas.layoutSpots)
local function freePerch()
	for _, p in ipairs(Formulas.defenseMap((myMap())).Perches or {}) do
		local s = judge(p[1], p[2])
		if s.fits then
			return s
		end
	end
	return nil
end

local function firstFreeSpot()
	if Formulas.isSky(placing.stats) then
		local s = freePerch()
		if s then
			return s
		end
	end
	if Formulas.isSea(placing.stats) then
		for _, p in ipairs(Formulas.defenseMap((myMap())).Ponds or {}) do
			local s = judge(p[1], p[2])
			if s.fits then
				return s
			end
		end
	end
	for _, p in ipairs(Formulas.layoutSpots(myMap(), placing.stats.Reach, placing.stats.Footprint)) do
		local s = judge(p[1], p[2])
		if s.fits then
			return s
		end
	end
	return judge(0, 0)
end

local function myPlace()
	local frame = myFrame()
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	return frame and root and frame:PointToObjectSpace(root.Position) or nil
end

local function seen(x, z)
	local frame = myFrame()
	local camera = Workspace.CurrentCamera
	if not frame or not camera then
		return true
	end
	local _, top = myMap()
	local p = camera:WorldToViewportPoint(frame * Vector3.new(x, top, z))
	local size, edge = camera.ViewportSize, K.SPOT_SEEN_EDGE
	return p.Z > 0 and p.X >= size.X * edge and p.X <= size.X * (1 - edge) and p.Y >= size.Y * edge
		and p.Y <= size.Y * (1 - edge)
end

local function nearestOf(list)
	local me = myPlace()
	local best, bestGap, bestSeen = nil, math.huge, false
	for i, p in ipairs(list) do
		local s = judge(p[1], p[2])
		if s.fits then
			local gap = me and (s.x - me.X) ^ 2 + (s.z - me.Z) ^ 2 or i
			local look = seen(s.x, s.z)
			if (look and not bestSeen) or (look == bestSeen and gap < bestGap) then
				best, bestGap, bestSeen = s, gap, look
			end
		end
	end
	return best
end

local function guideTarget()
	local stats = placing.stats
	if Formulas.isSky(stats) then
		local s = nearestOf(Formulas.defenseMap((myMap())).Perches or {})
		if s then
			return s
		end
	end
	if Formulas.isSea(stats) then
		return firstFreeSpot()
	end
	local spots = Formulas.layoutSpots(myMap(), stats.Reach, stats.Footprint)
	local top = spots[1] and spots[1][3] or 0
	local good = {}
	for i, p in ipairs(spots) do
		if i > K.SPOT_LOOK or p[3] < top * K.SPOT_GOOD then
			break
		end
		table.insert(good, p)
	end
	return nearestOf(good) or firstFreeSpot()
end

local function startAway(target)
	local stats = placing.stats
	local me = myPlace() or Vector3.new(target.x, 0, target.z)
	local far = K.SPOT_START_GAP * K.SPOT_START_GAP
	local order = {}
	for _, p in ipairs(Formulas.layoutSpots(myMap(), stats.Reach, stats.Footprint)) do
		if (p[1] - target.x) ^ 2 + (p[2] - target.z) ^ 2 >= far then
			table.insert(order, { p[1], p[2], (p[1] - me.X) ^ 2 + (p[2] - me.Z) ^ 2 })
		end
	end
	table.sort(order, function(a, b)
		return a[3] < b[3]
	end)
	local first = nil
	for i, p in ipairs(order) do
		if i > K.SPOT_LOOK then
			break
		end
		local s = judge(p[1], p[2])
		if s.fits and (s.x - target.x) ^ 2 + (s.z - target.z) ^ 2 >= far then
			if seen(s.x, s.z) then
				return s
			end
			first = first or s
		end
	end
	return first or target
end

local function showSpotGuide(target)
	clearSpotGuide()
	local frame = myFrame()
	if not frame then
		return
	end
	local mapId, top = myMap()
	local high = Formulas.placedStats(placing.stats, mapId, target.x, target.z).Perch and perchTop() or top
	local at = frame * Vector3.new(target.x, high, target.z)
	local ring = disc(placing.stats.Footprint + K.SPOT_RING_EXTRA, K.SPOT_RING_HEIGHT, K.SPOT_COLOR, K.SPOT_PULSE_FROM,
		previewFolder)
	ring.CFrame = CFrame.new(at + Vector3.new(0, K.SPOT_RING_LIFT, 0)) * CFrame.Angles(0, 0, math.pi / 2)
	local anchor = Instance.new("Part")
	anchor.Name = "PlaceSpotGuide"
	anchor.Anchored, anchor.CanCollide, anchor.CanQuery, anchor.CanTouch, anchor.CastShadow = true, false, false, false, false
	anchor.Transparency = 1
	anchor.Size = Vector3.new(0.2, 0.2, 0.2)
	anchor.CFrame = CFrame.new(at)
	anchor.Parent = previewFolder
	local mark = Instance.new("BillboardGui")
	mark.Name = "PlaceSpotMark"
	mark.Size = K.SPOT_MARK_SIZE
	mark.AlwaysOnTop = true
	mark.Active = true
	mark.ResetOnSpawn = false
	mark.Adornee = anchor
	mark.StudsOffsetWorldSpace = Vector3.new(0, K.SPOT_MARK_UP, 0)
	local icon = Instance.new("TextButton")
	icon.BackgroundTransparency = 1
	icon.AutoButtonColor = false
	icon.Size = UDim2.fromScale(1, 1)
	icon.TextScaled = true
	icon.Text = K.SPOT_MARK_TEXT
	icon:SetAttribute("KeepText", true)
	icon.Parent = mark
	Coach.mark(icon, K.SPOT_TAP)
	mark.Parent = player.PlayerGui
	spotGuide = { x = target.x, z = target.z, at = at, ring = ring, anchor = anchor, mark = mark }
	icon.Activated:Connect(function()
		if placing and spotGuide then
			spot = judge(spotGuide.x, spotGuide.z)
		end
	end)
end

local function nearSpot(position, x, z)
	local g = spotGuide
	if x and (x - g.x) ^ 2 + (z - g.z) ^ 2 <= K.SPOT_SNAP * K.SPOT_SNAP then
		return true
	end
	local camera = Workspace.CurrentCamera
	if not camera then
		return false
	end
	for _, lift in ipairs({ 0, K.SPOT_MARK_UP }) do
		local p = camera:WorldToScreenPoint(g.at + Vector3.new(0, lift, 0))
		if p.Z > 0 and (Vector2.new(p.X, p.Y) - Vector2.new(position.X, position.Y)).Magnitude <= K.SPOT_TAP_PIXELS then
			return true
		end
	end
	return false
end

function startPlacing(unit)
	if data and not data.Placed[unit.Id] and slotsFull() then
		sayFull()
		return
	end
	if not myFrame() then
		stopPlacing()
		return
	end
	stopPlacing(true)
	placing = { unit = unit, stats = Formulas.unitStats(unit) }
	do
		local rule, lv = nextTwist()
		if rule and rule.Id == "Unique" then
			local team = { { Id = unit.Id, Stats = placing.stats } }
			for _, u in ipairs(data.Units) do
				if data.Placed[u.Id] and u.Id ~= unit.Id then
					table.insert(team, { Id = u.Id, Stats = Formulas.unitStats(u) })
				end
			end
			placing.restsNext = Formulas.twistBench(rule, team, lv)[unit.Id] == true
		elseif rule and rule.Id ~= "Ace" then
			placing.restsNext = Formulas.twistBench(rule, { { Id = unit.Id, Stats = placing.stats } }, lv)[unit.Id] == true
		end
	end
	-- a placed dino being moved is picked up: only its silhouette shows (it stood in its own aura, hiding the silhouette)
	if data and data.Placed[unit.Id] then
		local units = myUnits()
		carried = units and units:FindFirstChild(unit.Id)
		if carried then
			carried:SetAttribute("PlacingHidden", true)
		end
	end
	ghost = disc(placing.stats.Footprint, 0.3, K.COLOR_OK, 0.3, previewFolder)
	ghostRing = disc(placing.stats.Reach, 0.05, K.COLOR_OK, 0.8, previewFolder)
	silhouette, glow = makeSilhouette(unit, placing.stats)
	-- a placed dino starts where it stands now; a new one at the first free place
	local now = data.Placed[unit.Id]
	spot = now and judge(now.X, now.Z) or firstFreeSpot()
	if guided() then
		local target = guideTarget()
		if not now then
			spot = startAway(target)
		end
		showSpotGuide(target)
	elseif now and Formulas.isSky(placing.stats) and player:GetAttribute("MissionGuideKind") == "Perch"
		and not Formulas.perchAt((myMap()), now.X, now.Z, Config.Defense.Perch.Snap) then
		spot = freePerch() or spot
	end
	tip.Visible = true
	spotInfo.Visible = true
	cancel.Visible = true
	topToggle.Visible = true
	showCatchers(true)
	confirmButton.Visible = true
	panel.Visible = false
	player:SetAttribute("PlacingUnit", unit.Id)
	showRings()
	if not player:GetAttribute("TopView") then
		autoTop = true
		player:SetAttribute("TopView", true)
	end
end
cancel.Activated:Connect(function()
	stopPlacing()
end)
player:GetAttributeChangedSignal("TopView"):Connect(function()
	showRings()
	showCatchers(placing ~= nil)
end)
player:GetAttributeChangedSignal("TopViewPick"):Connect(function()
	local id = player:GetAttribute("TopViewPick")
	if not id then
		return
	end
	player:SetAttribute("TopViewPick", nil)
	local unit = data and data.Placed[id] and unitById(id)
	if unit and not placing then
		startPlacing(unit)
	end
end)

confirmButton.Activated:Connect(function()
	if placing and spot and spot.fits and (not spotGuide or onSpot()) then
		Net.request("PlaceUnit", placing.unit.Id, spot.x, spot.z)
		stopPlacing()
	end
end)

-- press anywhere on the platform: the silhouette jumps there and follows the drag
local function dragTo(position)
	if not placing then
		return
	end
	local x, z = platformAt(Vector2.new(position.X, position.Y))
	if spotGuide and nearSpot(position, x, z) then
		x, z = spotGuide.x, spotGuide.z
	end
	if x then
		spot = judge(x, z)
	end
end
for _, c in ipairs(catchers) do
	c.InputBegan:Connect(function(input)
		if not placing then
			return
		end
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging = input
			dragTo(input.Position)
		end
	end)
end

-- placing ends by itself when I walk away from my arena, die or respawn (it never stays on unseen)
player.CharacterAdded:Connect(function()
	if placing then
		stopPlacing()
	end
end)
UserInputService.InputChanged:Connect(function(input)
	if not placing or not dragging then
		return
	end
	if (dragging.UserInputType == Enum.UserInputType.MouseButton1 and input.UserInputType == Enum.UserInputType.MouseMovement)
		or input == dragging then -- a finger's own InputObject moves
		dragTo(input.Position)
	end
end)
UserInputService.InputEnded:Connect(function(input)
	if dragging and (input == dragging or input.UserInputType == dragging.UserInputType) then
		dragging = nil
	end
end)

RunService.RenderStepped:Connect(FrameMeter.wrap("Placement", function()
	if not placing or not spot then
		return
	end
	local frame = myFrame()
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not frame or not root or not humanoid or humanoid.Health <= 0
		or (root.Position - frame.Position).Magnitude > Config.Placement.EditRange then
		stopPlacing()
		return
	end
	spot = judge(spot.x, spot.z) -- the others may have moved
	local color = spot.fits and K.COLOR_OK or K.COLOR_BAD
	ghost.Color, ghostRing.Color = color, color
	glow.FillColor, glow.OutlineColor = color, color
	if silhouette:GetAttribute("Fits") ~= spot.fits then -- recolor the parts only when it changes
		silhouette:SetAttribute("Fits", spot.fits)
		for _, d in ipairs(silhouette:GetDescendants()) do
			if d:IsA("BasePart") then
				d.Color = color
			end
		end
	end
	local mapId, top = myMap()
	local here = Formulas.placedStats(placing.stats, mapId, spot.x, spot.z)
	ghostRing.Size = Vector3.new(ghostRing.Size.X, here.Reach * 2, here.Reach * 2)
	ghost.CFrame = flatAt(frame, spot.x, spot.z, 0.15)
	ghostRing.CFrame = flatAt(frame, spot.x, spot.z, 0.05)
	-- standing on the platform, facing out toward the track like the placed dinos
	local at = frame * Vector3.new(spot.x, here.Perch and perchTop() or top, spot.z)
	local road = Formulas.lanePath(mapId)
	local rx, rz = Formulas.lanePoint(road, select(2, Formulas.laneDistance(road, spot.x, spot.z)), 0)
	local out = frame:VectorToWorldSpace(Vector3.new(rx - spot.x, 0, rz - spot.z))
	out = out.Magnitude > 1e-3 and out.Unit or frame.LookVector
	silhouette:PivotTo(CFrame.lookAt(at, at + out))
	local there = onSpot()
	if spotGuide then
		local pulse = (math.sin(os.clock() * K.SPOT_PULSE_SPEED) + 1) / 2
		spotGuide.ring.Transparency = there and 1 or K.SPOT_PULSE_FROM + (K.SPOT_PULSE_TO - K.SPOT_PULSE_FROM) * pulse
		spotGuide.mark.Enabled = not there
	end
	local ready = spot.fits and (not spotGuide or there)
	Coach.mark(confirmButton, (not spotGuide or there) and "PlaceOk" or nil)
	confirmButton.BackgroundColor3 = ready and K.COLOR_OK_BUTTON or K.COLOR_DISABLED
	confirmButton.AutoButtonColor = ready
	Lang.set(tip, spotGuide and not there and "🎯 빛나는 자리를 눌러 공룡을 옮겨요"
		or spot.fits and "👆 놓을 곳을 눌러요 · ✅ 놓기" or ("여기는 안 돼요: " .. tostring(spot.why)))
	local infoKey = string.format("%s/%.2f/%.2f", placing.unit.Id, spot.x, spot.z)
	if infoKey ~= spotInfoKey then -- (worked out when it moves)
		local efficiency = Formulas.spotEfficiency(spot.x, spot.z, here.Reach, placing.stats.Footprint, mapId)
		spotInfoKey = infoKey
		if here.Perch then
			spotInfo.Text = string.format("🏔️ 하늘 바위 📏+%d%% · 🎯 효율 %d%%",
				math.floor(Config.Defense.Perch.ReachBonus * 100 + 0.5), math.floor(efficiency * 100 + 0.5))
		elseif here.Nest then
			spotInfo.Text = string.format("🐣 둥지 📏+%d%% · 🎯 효율 %d%%",
				math.floor(Config.Defense.Rocks.Nest.ReachBonus * 100 + 0.5), math.floor(efficiency * 100 + 0.5))
		else
			spotInfo.Text = string.format("🎯 효율 %d%%", math.floor(efficiency * 100 + 0.5))
		end
		if placing.restsNext then
			spotInfo.Text = spotInfo.Text .. " · 💤 다음 변칙엔 쉬어요"
		end
		spotInfo.TextColor3 = efficiency >= K.EFF_GOOD and K.COLOR_EFF_GOOD or K.COLOR_EFF_POOR
	end
end))

UserInputService.InputBegan:Connect(function(input)
	if placing and input.KeyCode == Enum.KeyCode.Escape then
		stopPlacing()
	end
end)

task.spawn(function()
	for _ = 1, 20 do
		if Net.ask("GetMyUnits") then
			reload()
			return
		end
		task.wait(0.5)
	end
end)

-- promotion won (the defense level goes up): a fanfare and confetti; lost (a retry wait starts): a thud
task.spawn(function()
	local last = player:GetAttribute("DefenseLevel") or 1
	player:GetAttributeChangedSignal("DefenseLevel"):Connect(function()
		local value = player:GetAttribute("DefenseLevel") or 1
		if value > last then
			Sfx.play("Promotion")
			local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
			if root then
				Fx.confetti(root.Position + Vector3.new(0, 3, 0))
			end
		end
		last = value
	end)
end)
local lastFight = -math.huge -- os.clock() when a promotion fight was last seen running
player:GetAttributeChangedSignal("PromoLevel"):Connect(function()
	lastFight = os.clock()
end)
player:GetAttributeChangedSignal("PromoRetryAt"):Connect(function()
	if player:GetAttribute("PromoRetryAt") and os.clock() - lastFight < 5 then -- not the wait left over on joining
		Sfx.play("PromotionFail")
	end
end)

-- ---------------------------------------------------------------------------
-- Near one of my placed dinos: an outline around it and small "이동" / "빼기" buttons beside it
-- ---------------------------------------------------------------------------

local unitOutline = Instance.new("Highlight")
unitOutline.Name = "NearUnitOutline"
unitOutline.FillTransparency = 1
unitOutline.OutlineColor = K.COLOR_NEAR_STROKE
unitOutline.OutlineTransparency = 0
unitOutline.DepthMode = Enum.HighlightDepthMode.Occluded
unitOutline.Enabled = false
unitOutline.Parent = gui -- (kept when the character respawns)

local unitButtons = Instance.new("BillboardGui") -- in PlayerGui so its buttons can be pressed
unitButtons.Name = "NearUnitButtons"
unitButtons.Size = K.NEAR_BUTTONS
unitButtons.AlwaysOnTop = true
unitButtons.Active = true
unitButtons.Enabled = false
unitButtons.ResetOnSpawn = false -- made once by this script: respawning must not delete it
unitButtons.Parent = player.PlayerGui
local nearMove = button(unitButtons, "이동", K.COLOR_MOVE, UDim2.new(0, K.NEAR_BUTTON_WIDTH, 1, 0), UDim2.new())
local nearRemove = button(unitButtons, "빼기", K.COLOR_REMOVE, UDim2.new(0, K.NEAR_BUTTON_WIDTH, 1, 0),
	UDim2.fromOffset(K.NEAR_BUTTON_WIDTH + K.NEAR_GAP, 0))
local nearAim = button(unitButtons, "🎯", K.COLOR_PROMO, UDim2.new(0, K.NEAR_SMALL_WIDTH, 1, 0),
	UDim2.fromOffset(2 * (K.NEAR_BUTTON_WIDTH + K.NEAR_GAP), 0))
Coach.mark(nearAim, "Aim")
local nearNext = button(unitButtons, "⇄", K.COLOR_DISABLED, UDim2.new(0, K.NEAR_SMALL_WIDTH, 1, 0),
	UDim2.fromOffset(K.NEAR_BUTTONS.X.Offset + K.NEAR_GAP, 0))
local nearShape = nil
nearMove.TextSize, nearRemove.TextSize, nearNext.TextSize, nearAim.TextSize = 14, 14, 16, 14
local nearModel = nil

local nearUnitId = nil
local sinceNearUnit = 0
local pinnedId = nil -- the dino the player picked (tapped it, or ⇄) while several are in reach
local nearList = {} -- the dinos in reach, nearest (by their middle) first: { model, id }
nearNext.Activated:Connect(function() -- the next dino in reach
	for i, c in ipairs(nearList) do
		if c.id == nearUnitId then
			pinnedId = nearList[i % #nearList + 1].id
			sinceNearUnit = K.NEAR_UNIT_CHECK -- show it at once
			return
		end
	end
end)
-- tapping or clicking next to a dino in reach picks it (small ones beside big ones too)
UserInputService.InputBegan:Connect(function(input, processed)
	if processed or placing or #nearList < 2 then
		return
	end
	if input.UserInputType ~= Enum.UserInputType.MouseButton1 and input.UserInputType ~= Enum.UserInputType.Touch then
		return
	end
	local camera = Workspace.CurrentCamera
	local tap = Vector2.new(input.Position.X, input.Position.Y)
	local best, bestPixels = nil, K.NEAR_TAP_PIXELS
	for _, c in ipairs(nearList) do
		local cf = c.model:GetBoundingBox()
		local screen, visible = camera:WorldToViewportPoint(cf.Position)
		local pixels = (Vector2.new(screen.X, screen.Y) - tap).Magnitude
		if visible and pixels < bestPixels then
			best, bestPixels = c, pixels
		end
	end
	if best then
		pinnedId = best.id
		sinceNearUnit = K.NEAR_UNIT_CHECK
	end
end)
nearMove.Activated:Connect(function()
	local unit = nearUnitId and unitById(nearUnitId)
	if unit then
		startPlacing(unit)
	end
end)
nearAim.Activated:Connect(function()
	if not nearUnitId or not nearModel then
		return
	end
	local targets = Config.Defense.Targets
	local mode = nearModel:GetAttribute("Target") or targets[1].Id
	local at = 1
	for k, t in ipairs(targets) do
		at = t.Id == mode and k or at
	end
	local nextMode = targets[at % #targets + 1]
	nearModel:SetAttribute("Target", nextMode.Id)
	nearAim.Text = "🎯" .. nextMode.Icon
	Net.request("SetTargeting", nearUnitId, nextMode.Id)
	Notices.show(nil, string.format("🎯 %s %s", nextMode.Icon, Lang.t(nextMode.Name)))
	if data then
		data.Targeting = data.Targeting or {}
		data.Targeting[nearUnitId] = nextMode.Id ~= "Auto" and nextMode.Id or nil
		if panel.Visible then
			rebuildList()
		end
	end
end)
nearRemove.Activated:Connect(function()
	if nearUnitId then
		local farm = false
		for _, c in ipairs(nearList) do
			farm = farm or (c.id == nearUnitId and c.farm)
		end
		Net.request(farm and "UnregisterFarm" or "RemoveUnit", nearUnitId)
		nearUnitId = nil
		unitOutline.Enabled, unitButtons.Enabled = false, false
	end
end)

RunService.Heartbeat:Connect(FrameMeter.wrap("Placement", function(dt)
	sinceNearUnit += dt
	if sinceNearUnit < K.NEAR_UNIT_CHECK then
		return
	end
	sinceNearUnit = 0
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local map = Workspace:FindFirstChild("Map")
	local base = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	-- every placed dino in reach (by its edge; its footprint, not its rarity ring), nearest middle first:
	-- a small dino beside a big one is picked when the player stands by it, and ⇄ / a tap pick any of them
	local list = {}
	if root and base and data and not placing then
		for _, name in ipairs({ "DefenseUnits", "FarmUnits" }) do
			local farm = name == "FarmUnits"
			local units = not player:GetAttribute(farm and "HideMyFarm" or "HideMyDinos") and base:FindFirstChild(name)
			for _, model in ipairs(units and units:GetChildren() or {}) do
				local id = model:GetAttribute("UnitId")
				if id and (farm or data.Placed[id]) and model:IsA("Model") then
					local cf = model:GetBoundingBox()
					local d = cf.Position - root.Position
					local middle = Vector3.new(d.X, 0, d.Z).Magnitude
					if middle - (model:GetAttribute("Footprint") or 2) <= K.NEAR_UNIT_RANGE then
						table.insert(list, { model = model, id = id, middle = middle, farm = farm })
					end
				end
			end
		end
	end
	table.sort(list, function(a, b)
		return a.middle < b.middle
	end)
	nearList = list
	local best = nil
	for _, c in ipairs(list) do
		if c.id == pinnedId then
			best = c.model
		end
	end
	if not best then
		pinnedId = nil
		best = list[1] and list[1].model
	end
	local farmPick, lockedPick = false, false
	for _, c in ipairs(list) do
		farmPick = farmPick or (c.model == best and c.farm)
		lockedPick = lockedPick or (c.model == best and c.farm and data.FarmLock ~= nil and data.FarmLock[c.id] == true)
	end
	nearMove.Visible = not farmPick
	nearAim.Visible = not farmPick
	nearModel = best
	if best and not farmPick then
		local mode = best:GetAttribute("Target") or Config.Defense.Targets[1].Id
		for _, t in ipairs(Config.Defense.Targets) do
			if t.Id == mode then
				nearAim.Text = "🎯" .. t.Icon
			end
		end
	end
	Lang.set(nearRemove, lockedPick and "🔒 잠김" or farmPick and "🌾 빼기" or "빼기")
	nearNext.Visible = #list > 1
	local shape = (farmPick and "farm" or "unit") .. (#list > 1 and "+" or "")
	if shape ~= nearShape then
		nearShape = shape
		local w, small, gap = K.NEAR_BUTTON_WIDTH, K.NEAR_SMALL_WIDTH, K.NEAR_GAP
		local removeWidth = farmPick and K.NEAR_FARM_REMOVE or w
		local nextX = farmPick and removeWidth + gap or K.NEAR_BUTTONS.X.Offset + gap
		nearMove.Size, nearMove.Position = UDim2.new(0, w, 1, 0), UDim2.new()
		nearRemove.Size, nearRemove.Position = UDim2.new(0, removeWidth, 1, 0), UDim2.fromOffset(farmPick and 0 or w + gap, 0)
		nearAim.Size, nearAim.Position = UDim2.new(0, small, 1, 0), UDim2.fromOffset(2 * (w + gap), 0)
		nearNext.Size, nearNext.Position = UDim2.new(0, small, 1, 0), UDim2.fromOffset(nextX, 0)
		unitButtons.Size = UDim2.fromOffset(#list > 1 and nextX + small or farmPick and removeWidth or K.NEAR_BUTTONS.X.Offset,
			K.NEAR_BUTTONS.Y.Offset)
	end
	nearUnitId = best and best:GetAttribute("UnitId") or nil
	unitOutline.Enabled = best ~= nil
	unitButtons.Enabled = best ~= nil
	if best then
		unitOutline.Adornee = best
		local cf, size = best:GetBoundingBox()
		local part = best.PrimaryPart or best:FindFirstChildWhichIsA("BasePart", true)
		unitButtons.Adornee = part
		local up = math.min(size.Y + 1.5, K.NEAR_BUTTONS_MAX_UP)
		unitButtons.StudsOffsetWorldSpace = part and (cf.Position - part.Position + Vector3.new(0, up - size.Y / 2, 0))
			or Vector3.zero
	end
end))

-- Esc / Backspace / gamepad B closes the last opened window, or stops placing (Shared/Windows)
Windows.register(panel, function()
	panel.Visible = false
	showRings()
end)
Windows.register(cancel, stopPlacing)
Windows.register(enhance)
Windows.register(giveUp)
