local CollectionService = game:GetService("CollectionService")
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Unlock = require(Shared:WaitForChild("Unlock"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

local FONT = Enum.Font.GothamBlack
local CARD_SIZE = UDim2.fromOffset(440, 400)
local COLOR_BG = Color3.fromRGB(22, 26, 46)
local COLOR_TOP = Color3.fromRGB(80, 200, 255)
local COLOR_BOTTOM = Color3.fromRGB(130, 80, 235)
local COLOR_GO = Color3.fromRGB(80, 190, 95)
local COLOR_NEXT = Color3.fromRGB(170, 225, 255)
local GOLD = Color3.fromRGB(255, 215, 90)
local ICON_SIZE = 84
local ICON_TOP = 62
local TITLE_TEXT = 36
local NAME_TEXT = 36
local WHAT_TEXT = 26
local NEXT_TEXT = 22
local GO_TEXT = 30
local GO_SIZE = UDim2.fromOffset(280, 58)
local ICON_BOUNCE, ICON_SPEED = 6, 4
local RING_PULSE = 0.08
local BUTTON_PULSE = 0.06
local CARD_SECONDS = 4
local GUIDE_SECONDS = 90
local GUIDE_ARRIVE = 12
local ZONE_GUIDE_OUT = 6
local REVEAL_SECONDS = 1.2
local REVEAL_GLOW = Color3.fromRGB(255, 236, 150)
local REVEAL_GLOW_FILL = 0.35
local REVEAL_GLOW_MAX = 6
local BURST_COUNT = 70
local BURST_LIFE = 3
local BURST_SIZE = 1.6
local BURST_SPEED = NumberRange.new(14, 28)
local BURST_FALL = 12
local BURST_TEXTURE = "rbxasset://textures/particles/sparkles_main.dds"
local BURST_COLORS = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 225, 90)),
	ColorSequenceKeypoint.new(0.5, Color3.fromRGB(140, 255, 160)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(120, 210, 255)),
})
local POP_SIZE = UDim2.fromScale(16, 4)
local POP_UP = 8
local POP_RISE = 6
local POP_SECONDS = 2.6
local SPOT_PULSE = 0.25
local SPOT_PULSE_SPEED = 3
local SPOT_LOOK_EVERY = 1
local GATE_IN = 5
local REVEAL_GATHER = 0.15
local STAGE_TAG = "Staged"

local gui = Instance.new("ScreenGui")
gui.Name = "Unlocks"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.Text = text
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextStrokeTransparency = 0.3
	l.TextScaled = true
	l.TextWrapped = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = textSize
	most.Parent = l
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local card = Instance.new("Frame")
card.AnchorPoint = Vector2.new(0.5, 0.5)
card.Position = UDim2.fromScale(0.5, 0.5)
card.Size = CARD_SIZE
card.BackgroundColor3 = Color3.new(1, 1, 1)
card.Visible = false
card.Parent = gui
corner(card, 16)
local shade = Instance.new("UIGradient")
shade.Rotation = 90
shade.Color = ColorSequence.new(COLOR_TOP, COLOR_BOTTOM)
shade.Parent = card
local veil = Instance.new("Frame")
veil.Size = UDim2.fromScale(1, 1)
veil.BackgroundColor3 = COLOR_BG
veil.BackgroundTransparency = 0.45
veil.ZIndex = 0
veil.Parent = card
corner(veil, 16)
local stroke = Instance.new("UIStroke")
stroke.Color = GOLD
stroke.Thickness = 3
stroke.Parent = card

local titleLine = label(card, "", UDim2.new(1, -40, 0, 44), UDim2.fromOffset(20, 10), TITLE_TEXT, GOLD)
local ring = Instance.new("Frame")
ring.AnchorPoint = Vector2.new(0.5, 0)
ring.Size = UDim2.fromOffset(ICON_SIZE + 12, ICON_SIZE + 12)
ring.Position = UDim2.new(0.5, 0, 0, ICON_TOP - 6)
ring.BackgroundColor3 = COLOR_BG
ring.BackgroundTransparency = 0.3
ring.Parent = card
corner(ring, (ICON_SIZE + 12) / 2)
local ringEdge = Instance.new("UIStroke")
ringEdge.Color = GOLD
ringEdge.Thickness = 3
ringEdge.Parent = ring
local ringScale = Instance.new("UIScale")
ringScale.Parent = ring
local icon = label(card, "", UDim2.fromOffset(ICON_SIZE, ICON_SIZE), UDim2.new(0.5, -ICON_SIZE / 2, 0, ICON_TOP), 60)
local nameLine = label(card, "", UDim2.new(1, -30, 0, 42), UDim2.fromOffset(15, ICON_TOP + ICON_SIZE + 8), NAME_TEXT)
local whatLine = label(card, "", UDim2.new(1, -30, 0, 60), UDim2.fromOffset(15, ICON_TOP + ICON_SIZE + 52), WHAT_TEXT)
local nextLine = label(card, "", UDim2.new(1, -30, 0, 30), UDim2.fromOffset(15, ICON_TOP + ICON_SIZE + 114), NEXT_TEXT,
	COLOR_NEXT)
local go = Instance.new("TextButton")
go.AnchorPoint = Vector2.new(0.5, 1)
go.Position = UDim2.new(0.5, 0, 1, -12)
go.Size = GO_SIZE
go.BackgroundColor3 = COLOR_GO
go.Font = FONT
go.Text = ""
go.TextColor3 = Color3.new(1, 1, 1)
go.TextScaled = true
local goMost = Instance.new("UITextSizeConstraint")
goMost.MaxTextSize = GO_TEXT
goMost.Parent = go
go.Parent = card
corner(go, 12)
local goEdge = Instance.new("UIStroke")
goEdge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
goEdge.Color = Color3.new(1, 1, 1)
goEdge.Thickness = 2
goEdge.Parent = go
local goPulse = Instance.new("UIScale")
goPulse.Parent = go
Windows.fit(card)
Windows.register(card)
card:SetAttribute("NoCloseHint", true)

local queue = {}
local showing = nil
local guideToken = 0

local function myBase()
	local map = Workspace:FindFirstChild("Map")
	local index = player:GetAttribute("Base")
	return map and index and map:FindFirstChild("Base" .. index)
end

local function placeOf(u)
	local folder = myBase()
	if not folder then
		return nil
	end
	if u.Gate then
		local zone = folder:FindFirstChild("SafeZone")
		return zone and zone.CFrame:PointToWorldSpace(Vector3.new(0, -zone.Size.Y / 2, zone.Size.Z / 2 - GATE_IN)) or nil
	elseif u.Zone then
		local zone = folder:FindFirstChild("SafeZone")
		local flat = zone and Vector3.new(zone.Position.X, 0, zone.Position.Z)
		if not flat or flat.Magnitude < 1e-3 then
			return nil
		end
		local at = flat.Unit * (u.Zone.From + ZONE_GUIDE_OUT)
		return Vector3.new(at.X, zone.Position.Y - zone.Size.Y / 2, at.Z)
	end
	local inst = u.Where and folder:FindFirstChild(u.Where)
	if not inst then
		return nil
	elseif inst:IsA("BasePart") then
		return inst.Position
	elseif inst:IsA("Model") then
		return inst:GetPivot().Position
	end
	return nil
end

local function guide(u)
	guideToken += 1
	local mine = guideToken
	local spot = placeOf(u)
	if spot then
		player:SetAttribute("UnlockTarget", spot)
	elseif u.Button then
		player:SetAttribute("UnlockButton", u.Button)
	else
		return
	end
	local started = os.clock()
	task.spawn(function()
		while guideToken == mine and os.clock() - started < GUIDE_SECONDS do
			task.wait(0.25)
			local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
			if spot and root and Vector3.new(spot.X - root.Position.X, 0, spot.Z - root.Position.Z).Magnitude <= GUIDE_ARRIVE then
				break
			elseif not spot and (Windows.anyOpen() or not Unlock.ready(u.Id)) then
				break
			end
		end
		if guideToken == mine then
			player:SetAttribute("UnlockTarget", nil)
			player:SetAttribute("UnlockButton", nil)
		end
	end)
end

local function busy()
	return player:GetAttribute("CocoIntro") or player:GetAttribute("FirstFight") or player:GetAttribute("TutorialStep")
		or player:GetAttribute("Racing") or Windows.anyOpen(card)
end

local function nextText()
	local nextOne = Unlock.nextOne()
	return nextOne and string.format("🔜 다음: %s · %s", nextOne.Name, Unlock.whyText(nextOne))
		or "🎉 섬 전체가 열렸어요!"
end

local function fill(item)
	local u = Formulas.unlockOf(item.Id)
	if not u then
		return false
	end
	icon.Text = string.match(u.Name, "^(%S+)") or "🔓"
	nameLine.Text = u.Name
	if item.Kind == "Ready" then
		if not Unlock.ready(u.Id) then
			return false
		end
		titleLine.Text = "🔓 열 수 있어요!"
		whatLine.Text = u.Line or ""
		nextLine.Text = "👉 가면 바로 열려요!"
		go.Text = "✅ 가 보자!"
		go.BackgroundColor3 = COLOR_GO
	else
		titleLine.Text = "🎉 완전히 열렸어요!"
		whatLine.Text = item.Reward and item.Reward ~= "" and ("🎁 " .. item.Reward) or (u.Line or "")
		nextLine.Text = nextText()
		go.Text = "✅ 좋아!"
		go.BackgroundColor3 = COLOR_GO
	end
	return true
end

local function showNext()
	if showing or #queue == 0 then
		return
	end
	showing = table.remove(queue, 1)
	task.spawn(function()
		while showing and busy() do
			task.wait(0.5)
		end
		if not showing then
			return
		end
		if not fill(showing) then
			showing = nil
			showNext()
			return
		end
		card.Visible = true
		Sfx.play("Victory")
		local shown = showing
		task.delay(CARD_SECONDS, function()
			if showing == shown and card.Visible then
				card.Visible = false
			end
		end)
	end)
end

card:GetPropertyChangedSignal("Visible"):Connect(function()
	if not card.Visible and showing then
		local item = showing
		showing = nil
		local u = item.Kind == "Ready" and Formulas.unlockOf(item.Id)
		if u and Unlock.ready(u.Id) then
			guide(u)
		end
		task.defer(showNext)
	end
end)

go.Activated:Connect(function()
	card.Visible = false
end)

RunService.RenderStepped:Connect(FrameMeter.wrap("Unlocks", function()
	if not card.Visible then
		return
	end
	local t = os.clock()
	icon.Position = UDim2.new(0.5, -ICON_SIZE / 2, 0, ICON_TOP - math.abs(math.sin(t * ICON_SPEED)) * ICON_BOUNCE)
	ringScale.Scale = 1 + RING_PULSE * math.sin(t * ICON_SPEED)
	goPulse.Scale = 1 + BUTTON_PULSE * math.sin(t * 5)
end))

local function push(item)
	table.insert(queue, item)
	showNext()
end

local function burst(at, title)
	local holder = Instance.new("Part")
	holder.Name = "UnlockBurst"
	holder.Anchored, holder.CanCollide, holder.CanQuery, holder.CanTouch = true, false, false, false
	holder.Transparency = 1
	holder.Size = Vector3.one
	holder.CFrame = CFrame.new(at)
	local emitter = Instance.new("ParticleEmitter")
	emitter.Texture = BURST_TEXTURE
	emitter.Color = BURST_COLORS
	emitter.LightEmission = 1
	emitter.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, BURST_SIZE), NumberSequenceKeypoint.new(1, 0) })
	emitter.Lifetime = NumberRange.new(1, 1.8)
	emitter.Speed = BURST_SPEED
	emitter.SpreadAngle = Vector2.new(180, 180)
	emitter.Acceleration = Vector3.new(0, -BURST_FALL, 0)
	emitter.Drag = 1.5
	emitter.Rate = 0
	emitter.Parent = holder
	local pop = Instance.new("BillboardGui")
	pop.Size = POP_SIZE
	pop.AlwaysOnTop = true
	pop.LightInfluence = 0
	pop.StudsOffsetWorldSpace = Vector3.new(0, POP_UP, 0)
	local text = Instance.new("TextLabel")
	text.BackgroundTransparency = 1
	text.Size = UDim2.fromScale(1, 1)
	text.Font = FONT
	text.TextScaled = true
	text.TextColor3 = GOLD
	text.TextStrokeTransparency = 0.1
	text.Text = string.format("🎉 %s", title)
	text.Parent = pop
	pop.Parent = holder
	holder.Parent = Workspace
	emitter:Emit(BURST_COUNT)
	TweenService:Create(pop, TweenInfo.new(POP_SECONDS), { StudsOffsetWorldSpace = Vector3.new(0, POP_UP + POP_RISE, 0) }):Play()
	TweenService:Create(text, TweenInfo.new(POP_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.In),
		{ TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
	Debris:AddItem(holder, BURST_LIFE)
end

local function titleOf(key)
	local u = Formulas.unlockOf(key)
	if u then
		return u.Where and u.Name or nil
	end
	for _, m in ipairs(Config.StarterMissions.Missions) do
		if (m.Goal or m.Event) == key then
			return m.ShowName
		end
	end
	return nil
end

local function bounds(insts, visible)
	local lo, hi = nil, nil
	for _, inst in ipairs(insts) do
		local all = inst:GetDescendants()
		table.insert(all, inst)
		for _, d in ipairs(all) do
			if d:IsA("BasePart") and (not visible or d.Transparency < 1) then
				lo = lo and lo:Min(d.Position) or d.Position
				hi = hi and hi:Max(d.Position) or d.Position
			end
		end
	end
	return lo, hi
end

local function glow(adornee)
	local light = Instance.new("Highlight")
	light.Adornee = adornee
	light.FillColor = REVEAL_GLOW
	light.OutlineColor = REVEAL_GLOW
	light.FillTransparency = REVEAL_GLOW_FILL
	light.OutlineTransparency = 0
	light.DepthMode = Enum.HighlightDepthMode.Occluded
	light.Parent = Workspace.CurrentCamera
	TweenService:Create(light, TweenInfo.new(REVEAL_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.In),
		{ FillTransparency = 1, OutlineTransparency = 1 }):Play()
	Debris:AddItem(light, REVEAL_SECONDS)
end

local function reveal(key, insts)
	local shown, glows = {}, 0
	for _, inst in ipairs(insts) do
		if inst.Parent and not inst:GetAttribute("Hidden") then
			table.insert(shown, inst)
			local targets = (inst:IsA("Model") or inst:IsA("BasePart")) and { inst } or inst:GetChildren()
			for _, t in ipairs(targets) do
				if glows < REVEAL_GLOW_MAX and (t:IsA("Model") or t:IsA("BasePart")) then
					glows += 1
					glow(t)
				end
			end
		end
	end
	local lo, hi = bounds(shown, true)
	if not lo then
		lo, hi = bounds(shown, false)
	end
	local title = lo and titleOf(key)
	if title then
		burst(Vector3.new((lo.X + hi.X) / 2, lo.Y, (lo.Z + hi.Z) / 2), title)
	end
end

local gathering = {}
local function staged(inst)
	inst:GetAttributeChangedSignal("Hidden"):Connect(function()
		local key = inst:GetAttribute("StageGroup")
		if inst:GetAttribute("Hidden") or not key or inst:GetAttribute("StageBase") ~= player:GetAttribute("Base") then
			return
		end
		local list = gathering[key]
		if list then
			table.insert(list, inst)
			return
		end
		gathering[key] = { inst }
		task.delay(REVEAL_GATHER, function()
			local found = gathering[key]
			gathering[key] = nil
			reveal(key, found)
		end)
	end)
end
for _, inst in ipairs(CollectionService:GetTagged(STAGE_TAG)) do
	staged(inst)
end
CollectionService:GetInstanceAddedSignal(STAGE_TAG):Connect(staged)

Net.onPush("UnlockReady", function(id)
	if type(id) == "string" then
		push({ Kind = "Ready", Id = id })
	end
end)

Net.onPush("UnlockStarted", function(id)
	if type(id) ~= "string" then
		return
	end
	guideToken += 1
	player:SetAttribute("UnlockTarget", nil)
	player:SetAttribute("UnlockButton", nil)
	Sfx.play("Victory")
end)

Net.onPush("UnlockDone", function(id, reward)
	if type(id) == "string" then
		push({ Kind = "Done", Id = id, Reward = type(reward) == "string" and reward or nil })
	end
end)

local spot, spotLook = nil, 0
RunService.Heartbeat:Connect(FrameMeter.wrap("UnlockSpot", function()
	local now = os.clock()
	if now - spotLook >= SPOT_LOOK_EVERY then
		spotLook = now
		local folder = myBase()
		spot = folder and folder:FindFirstChild("UnlockSpot")
	end
	if spot and spot.Parent and spot:GetAttribute("State") == "Ready" then
		spot.LocalTransparencyModifier = SPOT_PULSE * (1 + math.sin(now * SPOT_PULSE_SPEED)) / 2
	end
end))
