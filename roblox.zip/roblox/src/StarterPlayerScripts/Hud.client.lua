--[[
Hud: the player's screen for the mining loop (grey-box UI, the full UI comes in stage 9).

- Bottom: the bag, the player's game money and draw keys, split by slashes
  ("🎒 12/50 (🔑+1) · 💰 1,234 · 🔑 5 ✨2": the keys found in minerals ride in the bag, ✨ the better
  grades' keys; red when the bag is full) and over it the pickaxe in short ("⛏️ 3티어 · 💥4.4 · ⚡1.22 · ×2",
  power, speed, minerals a turn). Short and small so they take little of a phone's screen.
- Bottom left corner: the money bonus from Roblox friends on the server, just "👥 +10%" (hidden with
  none). A key found in a mineral (Net push KeyFound) sparkles.
- The shop window opens from the "상점" prompt of the player's own base and closes when they walk
  away. Its button only sends a request (Net: BuyPickaxe; 2026-10-04: the ⛏️ 곡괭이 상점, only the next pickaxe; the
  power, speed, bag, slap and move speed are trained at the base's stations, Training);
  the "열쇠 상점" window (BuyKeys: every key grade, 1 or 10 at a time) opens the same way from the key
  stall beside the shop;
  prices shown here come from Formulas and are for display, the server decides.
- Deposit and shop prompts of other players' bases are hidden on this screen.
- Right edge, above 보기 설정: the key drop timer ("🔑 ⏰ 4:59", "⚡🔑 7:59" in gold when the next drop is a big
  one (attribute NextKeyDropBig), ReplicatedStorage attribute NextKeyDrop; red in the
  last seconds, when the carried keys are about to disappear).
- Right edge: "기지로" asks the server to move the player home (Net: TeleportHome); while the
  player attribute TeleportAt (server time) is set, the button counts down.
All values shown come from the server: player attributes (BagCount, BagCapacity, PickaxeTier,
PickaxePower, PickaxeSpeed, BagLevel, Base) and leaderstats.
]]

local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Fx = require(Shared:WaitForChild("Fx"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local Windows = require(Shared:WaitForChild("Windows"))
local WorldWatch = require(Shared:WaitForChild("WorldWatch"))
local LiveSet = require(Shared:WaitForChild("LiveSet"))
local SideButtons = require(Shared:WaitForChild("SideButtons"))
local Lang = require(Shared:WaitForChild("Lang"))
local Coach = require(Shared:WaitForChild("Coach"))

local player = Players.LocalPlayer

-- layout (display only)
local FONT = Enum.Font.GothamBold
local BAR_SIZE = UDim2.fromOffset(330, 28) -- (was 400 × 34: less of the phone's screen)
-- the bag bar's bottom right corner: left of the slap button (CombatFx, 196 from the right edge) so
-- they never overlap on a phone; on wide screens it still sits near the middle
local BAR_POS = UDim2.new(1, -204, 1, -10) -- (windows stay above it: Shared/Windows)
local BAR_TEXT = 15
local BAR_POP = 1.08 -- (2026-10-04) the bag bar's bounce when a mineral comes in: this big, back in BAR_POP_SECONDS
local BAR_POP_SECONDS = 0.25
local PICK_TEXT = 13 -- the pickaxe line over the bag bar
local FRIEND_SIZE = UDim2.fromOffset(124, 20)
local FRIEND_POS = UDim2.new(0, 16, 0, -22)
local FRIEND_TEXT = 14
local COLOR_FRIEND = Color3.fromRGB(140, 230, 140)
local BOOST_SIZE = UDim2.fromOffset(124, 20)
local BOOST_GAP = 6
local COLOR_BOOST = Color3.fromRGB(255, 215, 90)
-- (2026-10-04, "상점 가판대 정보도 정리해줘. 그리고 곡괭이 강화는 따로 빼" → 상점에서 빼기; "상점 이름도 조절해 바로 알아챌
-- 수 있게") the ⛏️ 곡괭이 상점: only the next pickaxe, and two notes (training at the base's stations, keys at the key
-- stall); the training boost is bought at the stations (Training.client)
local SHOP_SIZE = UDim2.fromOffset(330, 232)
local PICKAXE_ROW = 82 -- (2026-10-04, "다음 곡괭이 뭔지 모델링 박아주고") a taller row for a big picture of the next pickaxe
local PICKAXE_PICTURE = 76
local COLOR_NOTE = Color3.fromRGB(200, 170, 255)
-- (2026-10-04) the shop's "⭐ 추천" mark and glow on the best buy, and its "ℹ️ 자세히" button
local RECOMMEND_SIZE = Vector2.new(58, 20)
local RECOMMEND_STROKE = 3
local RECOMMEND_PULSE = 0.7 -- seconds a glow takes to fade (and back)
local COLOR_RECOMMEND = Color3.fromRGB(255, 210, 70)
local DETAILS_SIZE = Vector2.new(78, 30)
local BUTTON_HEIGHT = 58
local BUTTON_GAP = 8
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_FILL = Color3.fromRGB(70, 150, 255)
local COLOR_FULL = Color3.fromRGB(235, 70, 80)
local COLOR_BUTTON = Color3.fromRGB(80, 190, 110)
local COLOR_DISABLED = Color3.fromRGB(110, 110, 120)
local COLOR_HOME = Color3.fromRGB(240, 150, 50)
local COLOR_KEYS = Color3.fromRGB(200, 150, 40)
local COIN_COLORS = { Color3.fromRGB(255, 215, 60), Color3.fromRGB(255, 245, 170) }
local KEY_FOUND_COLORS = { Color3.fromRGB(255, 205, 60), Color3.fromRGB(255, 255, 200) }
local COLOR_REBIRTH = Color3.fromRGB(190, 80, 200)
local REBIRTH_KEEP_COLOR = Color3.fromRGB(140, 240, 140) -- the rebirth window's headings: what stays ...
local REBIRTH_GIFT_COLOR = Color3.fromRGB(255, 215, 90) -- ... what comes at once ...
local REBIRTH_BONUS_COLOR = Color3.fromRGB(170, 210, 255) -- ... what grows for good
local CONFIRM_SIZE = UDim2.fromOffset(340, 352)
-- (2026-10-04, "환생 창 … 그림 위주로 정리해줘", "아이들도 금방 이해할만한 설명이 주가") the rebirth window: one line saying what a
-- rebirth is, then pictures: what stays, what comes at once, what grows for good, the price
local REBIRTH_GIFT = 40 -- a gift's picture
local REBIRTH_GIFT_WIDTH = 50
local REBIRTH_KEY_WIDTH = 72
local REBIRTH_GIFT_GAP = 4
local REBIRTH_CHIP = Vector2.new(74, 34)
local KEY_ROW_HEIGHT = 46
local KEY_NAME_WIDTH = 116 -- the key shop row: the grade's name, then a buy button per count
local KEY_BUTTON_WIDTH = 88
local EXCHANGE_ROW = 44
local EXCHANGE_TEXT_WIDTH = 136
local EXCHANGE_ICON = 32 -- the exchange row: the key given, an arrow, the key got (2026-10-01)
local EXCHANGE_ARROW = 14
local EXCHANGE_BUTTON_WIDTH = 60
local COLOR_EXCHANGE = Color3.fromRGB(90, 150, 230)
local KEY_BUTTON_GAP = 6
local KEY_ICON = 42 -- the key's picture at the start of each key shop row
local KEY_SHOP_SIZE = UDim2.fromOffset(330 + KEY_ICON + 6, 466)
-- (2026-10-04, "열쇠 가판대 정보도 정리해줘") the key shop shows only the grades on sale to me, one after another, a single
-- line for the ones still locked, and is as tall as that (KEY_SHOP_TOP + rows + KEY_SHOP_BOTTOM)
-- (2026-10-04, "열쇠 상점칸 교환이랑 상점이랑 안 헷갈리게") two tabs under the title, 🛒 사기 (green) and 🔁 교환 (blue), on
-- both windows; the exchange window is tinted blue
local KEY_TAB_TOP, KEY_TAB_HEIGHT = 46, 38
local KEY_SHOP_TOP = KEY_TAB_TOP + KEY_TAB_HEIGHT + 8
local KEY_LOCK_LINE = 24
local KEY_SHOP_BOTTOM = 12
local COLOR_EXCHANGE_BG = Color3.fromRGB(26, 36, 62)
local COLOR_TAB_OFF_TEXT = Color3.fromRGB(200, 200, 210)
local COLOR_LOCKED = Color3.fromRGB(170, 170, 185)
-- the right edge, two columns 10 apart, rows 10 apart, from the top (under the arena line): 접기 (SideButtons)
-- | the key drop timer; 인벤토리 (Inventory) | 보기 설정 (ViewSettings); 보상 (Rewards) | 기지로. 타기 and
-- 울부짖기 (Ride) sit over the jump button, and fit there even on a short phone (2026-10-01: rows were 6
-- apart and 인벤토리 a third row, so 타기 had no room and touched it). tools/check_phone_ui.py checks it on phones
local HOME_SIZE = UDim2.fromOffset(68, 36)
local HOME_POS = UDim2.new(1, -12, 0, 132) -- its middle
local TIMER_SIZE = UDim2.fromOffset(68, 26)
local TIMER_POS = UDim2.new(1, -12, 0, 58) -- its bottom
local TIMER_SOON = 30 -- seconds: the timer turns red
local COLOR_TIMER_SOON = Color3.fromRGB(235, 70, 80)
local COLOR_TIMER_BIG = Color3.fromRGB(255, 220, 90) -- the next drop is a big one (⚡; Config.Keys.BigDrop)
local TIMER_GLOW = { Color = Color3.fromRGB(255, 215, 80), Thickness = 2, SoonThickness = 3, Speed = 4, SoonSpeed = 12,
	SoonScale = 0.1, SoonBack = Color3.fromRGB(120, 40, 45) }

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local gui = Instance.new("ScreenGui")
gui.Name = "Hud"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

-- ---------------------------------------------------------------------------
-- Bag bar and pickaxe
-- ---------------------------------------------------------------------------

-- in its own ScreenGui under the windows (Shared/Windows puts this script's gui, with the shops, over the HUD)
local barGui = Instance.new("ScreenGui")
barGui.Name = "BagBar"
barGui.ResetOnSpawn = false
barGui.Parent = gui.Parent

local bar = Instance.new("Frame")
bar.AnchorPoint = Vector2.new(1, 1)
bar.Size = BAR_SIZE
bar.Position = BAR_POS
bar.BackgroundColor3 = COLOR_BG
bar.BackgroundTransparency = 0.2
bar.Parent = barGui
player:GetAttributeChangedSignal("TopView"):Connect(function()
	bar.Visible = not player:GetAttribute("TopView")
end)
corner(bar, 10)

local fill = Instance.new("Frame")
fill.Size = UDim2.fromScale(0, 1)
fill.BackgroundColor3 = COLOR_FILL
fill.Parent = bar
corner(fill, 10)

local barPop = Instance.new("UIScale") -- (2026-10-04) a little bounce when a mineral comes into the bag
barPop.Parent = bar
local bagText = label(bar, "", UDim2.new(1, -12, 1, 0), UDim2.fromOffset(6, 0), BAR_TEXT)
bagText.ZIndex = 2
bagText.TextScaled = true -- shrinks when the numbers get long
local bagTextSize = Instance.new("UITextSizeConstraint")
bagTextSize.MaxTextSize = BAR_TEXT
bagTextSize.Parent = bagText
local pickText = label(bar, "", UDim2.new(1, 0, 0, 16), UDim2.new(0, 0, 0, -19), PICK_TEXT)
pickText.TextStrokeTransparency = 0.4
local friendText = label(bar, "", FRIEND_SIZE, FRIEND_POS, FRIEND_TEXT)
friendText.Name = "FriendBonus"
friendText.AnchorPoint = Vector2.new(0, 1)
friendText.BackgroundColor3 = COLOR_BG
friendText.BackgroundTransparency = 0.2
friendText.TextColor3 = COLOR_FRIEND
friendText.TextStrokeTransparency = 0.3
friendText.TextScaled = true
friendText.Visible = false
corner(friendText, 8)
do
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = FRIEND_TEXT
	most.Parent = friendText
end
local boostText = label(bar, "", BOOST_SIZE, FRIEND_POS, FRIEND_TEXT)
boostText.Name = "TrainBoost"
boostText.AnchorPoint = Vector2.new(0, 1)
boostText.BackgroundColor3 = COLOR_BG
boostText.BackgroundTransparency = 0.2
boostText.TextColor3 = COLOR_BOOST
boostText.TextStrokeTransparency = 0.3
boostText.TextScaled = true
boostText.Visible = false
corner(boostText, 8)
do
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = FRIEND_TEXT
	most.Parent = boostText
end

local function refreshBar()
	local count = player:GetAttribute("BagCount") or 0
	local capacity = player:GetAttribute("BagCapacity") or 1
	local tier = player:GetAttribute("PickaxeTier") or 1
	local steps = player:GetAttribute("TrainReal_Power") or player:GetAttribute("PickaxePower") or 0
	local speedLevel = player:GetAttribute("TrainReal_Speed") or player:GetAttribute("PickaxeSpeed") or 0
	fill.Size = UDim2.fromScale(math.clamp(count / capacity, 0, 1), 1)
	fill.BackgroundColor3 = count >= capacity and COLOR_FULL or COLOR_FILL
	local moneyText = Formulas.shortNumber(player:GetAttribute("Money") or 0)
	local special = 0 -- saved keys of the better grades (Keys: Keys<Grade>)
	for _, t in ipairs(Config.Keys.Types) do
		if t.Id ~= "Normal" then
			special += player:GetAttribute("Keys" .. t.Id) or 0
		end
	end
	local keyText = Formulas.shortNumber(player:GetAttribute("Keys") or 0) .. (special > 0 and string.format(" ✨%s", Formulas.shortNumber(special)) or "")
	local found = player:GetAttribute("FoundKeys") or 0 -- keys found in minerals, banked at the deposit bin
	local bagPart = found > 0 and string.format("🎒 %d/%d (🔑+%d)", count, capacity, found)
		or string.format("🎒 %d/%d", count, capacity)
	bagText.Text = count >= capacity
			and string.format("%s 가득! · 💰 %s · 🔑 %s", bagPart, moneyText, keyText)
		or string.format("%s · 💰 %s · 🔑 %s", bagPart, moneyText, keyText)
	local t = Config.Pickaxe.Tiers[tier]
	local friends = player:GetAttribute("Friends") or 0 -- Roblox friends on this server: a money buff
	pickText.Text = string.format("⛏️ %d티어 · 💥%.1f · ⚡%.2f · ×%.1f", tier,
		Formulas.pickaxePower(tier, steps), Formulas.pickaxeSpeed(tier, speedLevel), t.Yield)
	friendText.Visible = friends > 0
	friendText.Text = string.format("👥 친구 💰+%d%%", math.floor((Formulas.friendBoost(friends) - 1) * 100 + 0.5))
end

for _, name in ipairs({ "BagCount", "BagCapacity", "PickaxeTier", "PickaxePower", "PickaxeSpeed", "FoundKeys", "Friends",
	"TrainReal_Power", "TrainReal_Speed" }) do
	player:GetAttributeChangedSignal(name):Connect(refreshBar)
end
for _, t in ipairs(Config.Keys.Types) do
	player:GetAttributeChangedSignal("Keys" .. t.Id):Connect(refreshBar)
end

-- sounds: depositing (the bag emptied: coins fly), buying an upgrade
local lastBag = player:GetAttribute("BagCount") or 0
-- a key found in a mineral: a sparkle over me and the special key chime
Net.onPush("KeyFound", function()
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if root then
		Fx.burst(root.Position + Vector3.new(0, 3, 0), KEY_FOUND_COLORS, 20, 12, 0.5, 0.8)
		Sfx.play("SpecialKey", root.Position)
	end
end)

-- someone brought keys home (Net push KeysHome): a jingle and a golden sparkle round them; my own louder
Net.onPush("KeysHome", function(userId)
	local who = Players:GetPlayerByUserId(userId)
	local root = who and who.Character and who.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end
	Fx.burst(root.Position + Vector3.new(0, 3, 0), KEY_FOUND_COLORS, 30, 14, 0.6, 0.9)
	if who == player then
		Sfx.play("KeysHome") -- (2D: always heard in full)
	else
		Sfx.play("KeysHome", root.Position)
	end
end)

player:GetAttributeChangedSignal("BagCount"):Connect(function()
	local now = player:GetAttribute("BagCount") or 0
	if now > lastBag then -- (2026-10-04, "본게임에서 광질 조금 하다 가던데": a mined mineral showed nowhere but the number)
		barPop.Scale = BAR_POP
		TweenService:Create(barPop, TweenInfo.new(BAR_POP_SECONDS, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
			{ Scale = 1 }):Play()
	end
	if now == 0 and lastBag > 0 then
		Sfx.play("Deposit")
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if root then
			Fx.burst(root.Position + Vector3.new(0, 2, 0), COIN_COLORS, 20, 14, 0.5, 0.8)
		end
	end
	lastBag = now
end)
local upgradeLevels = {}
for _, name in ipairs({ "PickaxeTier", "PickaxePower", "PickaxeSpeed", "BagLevel", "SlapLevel", "MoveSpeedLevel" }) do
	upgradeLevels[name] = player:GetAttribute(name)
	player:GetAttributeChangedSignal(name):Connect(function()
		local now = player:GetAttribute(name)
		if upgradeLevels[name] and now and now > upgradeLevels[name] then
			Sfx.play("Buy")
		end
		upgradeLevels[name] = now
	end)
end
refreshBar()
player:GetAttributeChangedSignal("Money"):Connect(refreshBar)
player:GetAttributeChangedSignal("Keys"):Connect(refreshBar)

-- ---------------------------------------------------------------------------
-- Shop window
-- ---------------------------------------------------------------------------

local shop = Instance.new("Frame")
shop.AnchorPoint = Vector2.new(0.5, 0.5)
shop.Position = UDim2.fromScale(0.5, 0.5)
shop.Size = SHOP_SIZE
shop.BackgroundColor3 = COLOR_BG
shop.Visible = false
shop.Parent = gui
Windows.fit(shop) -- smaller on phones
corner(shop, 14)
label(shop, "⛏️ 곡괭이 상점", UDim2.new(1, 0, 0, 40), UDim2.fromOffset(0, 6), 24)

local close = Instance.new("TextButton")
close.Size = UDim2.fromOffset(36, 36)
close.Position = UDim2.new(1, -44, 0, 8)
close.Text = "X"
close.Font = FONT
close.TextSize = 20
close.TextColor3 = Color3.new(1, 1, 1)
close.BackgroundColor3 = COLOR_FULL
close.Parent = shop
corner(close, 8)

local function button(row)
	local b = Instance.new("TextButton")
	b.Size = UDim2.new(1, -32, 0, BUTTON_HEIGHT)
	b.Position = UDim2.fromOffset(16, 52 + (row - 1) * (BUTTON_HEIGHT + BUTTON_GAP))
	b.Font = FONT
	b.TextSize = 18
	b.TextWrapped = true
	b.TextColor3 = Color3.new(1, 1, 1)
	b.Parent = shop
	corner(b, 10)
	return b
end
local pickaxeButton = button(1)
pickaxeButton.Size = UDim2.new(1, -32, 0, PICKAXE_ROW)
-- (2026-10-04, "모든 정보가 최대한 그림으로") the next pickaxe's picture at the row's left (ReplicatedStorage.ItemModels)
local pickaxePicture = Instance.new("Frame")
pickaxePicture.BackgroundTransparency = 1
pickaxePicture.Size = UDim2.fromOffset(PICKAXE_PICTURE, PICKAXE_PICTURE)
-- (2026-10-04, "곡괭이 모델링이 이상한데 가있음": the padding that moves the row's text right of the picture moves the
-- button's children too, so the picture stood under the text) back by the padding: at the row's left edge
pickaxePicture.Position = UDim2.new(0, 4 - PICKAXE_PICTURE, 0.5, -PICKAXE_PICTURE / 2)
pickaxePicture.Parent = pickaxeButton
local pickaxeTextPad = Instance.new("UIPadding")
pickaxeTextPad.PaddingLeft = UDim.new(0, PICKAXE_PICTURE)
pickaxeTextPad.Parent = pickaxeButton
local pickaxeShown = nil -- the tier in the picture now
local function showPickaxe(tier)
	if pickaxeShown == tier then
		return
	end
	local models = ReplicatedStorage:FindFirstChild("ItemModels")
	local source = models and models:FindFirstChild("Pickaxe_T" .. tier)
	if not source then
		return -- (not yet arrived: tried again at the next refresh)
	end
	pickaxeShown = tier
	pickaxePicture:ClearAllChildren()
	DinoPortrait.ofModel(source, UDim2.fromScale(1, 1)).Parent = pickaxePicture
end
-- (2026-10-04) "ℹ️ 자세히": the numbers behind each row (showDetails)
local detailsButton = Instance.new("TextButton")
detailsButton.Size = UDim2.fromOffset(DETAILS_SIZE.X, DETAILS_SIZE.Y)
detailsButton.Position = UDim2.fromOffset(10, 10)
detailsButton.Font = FONT
detailsButton.TextSize = 13
detailsButton.TextColor3 = Color3.new(1, 1, 1)
detailsButton.BackgroundColor3 = COLOR_DISABLED
detailsButton.Text = "ℹ️ 자세히"
detailsButton.Parent = shop
corner(detailsButton, 8)
-- (2026-10-04) power, speed, bag, slap and move speed are trained, not bought: where
local trainNote = label(shop, "💪 곡괭이 파워·속도, 가방, 손바닥, 이동속도는\n기지 훈련장에 서 있으면 올라요", UDim2.new(1, -32, 0, 40),
	UDim2.fromOffset(16, 52 + PICKAXE_ROW + BUTTON_GAP + 4), 13)
trainNote.TextColor3 = COLOR_NOTE
local keyStallNote = label(shop, "🔑 열쇠 사기·🔄 교환은 옆 열쇠 가판대에서", UDim2.new(1, -32, 0, 24),
	UDim2.fromOffset(16, 52 + PICKAXE_ROW + BUTTON_GAP + 48), 13)
keyStallNote.TextColor3 = COLOR_KEYS

-- the key shop, opened at the key stall beside the shop (prompt Kind "KeyShop"): every grade
-- (Config.Keys.Types), 1 or 10 at a time, at very different prices
local keyShop = Instance.new("Frame")
keyShop.AnchorPoint = Vector2.new(0.5, 0.5)
keyShop.Position = UDim2.fromScale(0.5, 0.5)
keyShop.Size = KEY_SHOP_SIZE
keyShop.BackgroundColor3 = COLOR_BG
keyShop.Visible = false
keyShop.Parent = gui
Windows.fit(keyShop) -- smaller on phones
corner(keyShop, 14)
label(keyShop, "🔑 열쇠 상점", UDim2.new(1, 0, 0, 40), UDim2.fromOffset(0, 6), 24)
-- (2026-10-04) the keys' odds only with "ℹ️ 자세히" (the shop's showDetails, one setting for both)
local keyDetailsButton = detailsButton:Clone()
keyDetailsButton.Parent = keyShop
local keyRows = {} -- { grade, [count] = button }
for i, t in ipairs(Config.Keys.Types) do
	local y = 52 + (i - 1) * (KEY_ROW_HEIGHT + 6)
	local color = t.Rgb and Color3.fromRGB(table.unpack(t.Rgb)) or Color3.fromRGB(255, 205, 60)
	-- the key's picture (ReplicatedStorage.KeyModels from the Keys service; a 🔑 until it arrives)
	local icon = DinoPortrait.key(t.Id, UDim2.fromOffset(KEY_ICON, KEY_ICON))
	icon.Position = UDim2.fromOffset(12, y + (KEY_ROW_HEIGHT - KEY_ICON) / 2)
	icon.Parent = keyShop
	local name = label(keyShop, t.Name,
		UDim2.fromOffset(KEY_NAME_WIDTH, KEY_ROW_HEIGHT), UDim2.fromOffset(12 + KEY_ICON + 6, y), 12)
	name.TextWrapped = true
	name.TextScaled = true -- (three lines with my level's outlook: smaller when they don't fit)
	local nameMax = Instance.new("UITextSizeConstraint")
	nameMax.MaxTextSize = 12
	nameMax.Parent = name
	name.TextColor3 = color
	name.TextXAlignment = Enum.TextXAlignment.Left
	name.TextStrokeTransparency = 0.4
	local row = { grade = t.Id, name = name, keyName = t.Name, icon = icon }
	for j, count in ipairs(Config.Gacha.KeyBuyCounts) do
		local b = Instance.new("TextButton")
		b.Size = UDim2.fromOffset(KEY_BUTTON_WIDTH, KEY_ROW_HEIGHT)
		b.Position = UDim2.fromOffset(12 + KEY_ICON + 6 + KEY_NAME_WIDTH + 8 + (j - 1) * (KEY_BUTTON_WIDTH + KEY_BUTTON_GAP), y)
		b.Font = FONT
		b.TextSize = 13
		b.TextWrapped = true
		b.TextColor3 = Color3.new(1, 1, 1)
		b.Parent = keyShop
		corner(b, 8)
		b.Activated:Connect(function() -- a tap (2026-10-01: was held a moment)
			Net.request("BuyKeys", count, t.Id)
		end)
		if t.Id == "Normal" and j == 1 then
			Coach.mark(b, "KeyBuy")
		end
		row[count] = b
	end
	table.insert(keyRows, row)
end

local keyLockNote = label(keyShop, "🔒 더 좋은 열쇠는 환생하면 열려요", UDim2.new(1, -24, 0, KEY_LOCK_LINE),
	UDim2.fromOffset(12, 0), 13)
keyLockNote.TextColor3 = COLOR_LOCKED

-- the tabs: { buy, exchange } buttons in a window; the one for this window lit in its color, the other grey
local function keyTabs(window, buying)
	local tabs = {}
	for i, t in ipairs({ { "🛒 열쇠 사기", COLOR_BUTTON, true }, { "🔁 열쇠 교환", COLOR_EXCHANGE, false } }) do
		local b = Instance.new("TextButton")
		b.Size = UDim2.new(0.5, -15, 0, KEY_TAB_HEIGHT)
		b.Position = UDim2.new((i - 1) * 0.5, i == 1 and 12 or 3, 0, KEY_TAB_TOP)
		b.Font = FONT
		b.TextSize = 16
		b.Text = t[1]
		local on = t[3] == buying
		b.BackgroundColor3 = on and t[2] or COLOR_DISABLED
		b.TextColor3 = on and Color3.new(1, 1, 1) or COLOR_TAB_OFF_TEXT
		b.AutoButtonColor = not on
		b.Parent = window
		corner(b, 10)
		if on then
			local stroke = Instance.new("UIStroke")
			stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			stroke.Color = Color3.new(1, 1, 1)
			stroke.Thickness = 2
			stroke.Parent = b
		end
		tabs[i] = b
	end
	return tabs
end
local buyTabs = keyTabs(keyShop, true)
Coach.mark(buyTabs[2], "KeyTradeTab")

-- the exchange: ExchangeRate keys of a grade -> one of the next grade up (Net request ExchangeKeys)
local exchange = Instance.new("Frame")
exchange.AnchorPoint = Vector2.new(0.5, 0.5)
exchange.Position = UDim2.fromScale(0.5, 0.5)
exchange.Size = KEY_SHOP_SIZE -- room for the key pictures
exchange.BackgroundColor3 = COLOR_EXCHANGE_BG
exchange.Visible = false
exchange.Parent = gui
Windows.fit(exchange) -- smaller on phones
corner(exchange, 14)
label(exchange, "🔑 열쇠 상점", UDim2.new(1, 0, 0, 40), UDim2.fromOffset(0, 6), 24)
local exchangeTabs = keyTabs(exchange, false)
Coach.mark(exchangeTabs[1], "KeyBuyTab")
local EXCHANGE_TOP = KEY_SHOP_TOP + 24 -- (under the tabs and the hint)
local exchangeHint = label(exchange, "🔄 같은 열쇠를 모아서 더 좋은 열쇠 1개로!",
	UDim2.new(1, -24, 0, 20), UDim2.fromOffset(12, KEY_SHOP_TOP), 13)
exchangeHint.TextColor3 = Color3.fromRGB(190, 190, 200)
local exchangeRows = {} -- { from, up, text, one, all }
for i, t in ipairs(Config.Keys.Types) do
	local up = Config.Keys.Types[i + 1]
	if up then
		local y = EXCHANGE_TOP + (i - 1) * (EXCHANGE_ROW + 6)
		-- the pictures: this grade's key → the next grade's key (DinoPortrait.key, like the key shop)
		local iconY = y + (EXCHANGE_ROW - EXCHANGE_ICON) / 2
		local fromIcon = DinoPortrait.key(t.Id, UDim2.fromOffset(EXCHANGE_ICON, EXCHANGE_ICON))
		fromIcon.Position = UDim2.fromOffset(12, iconY)
		fromIcon.Parent = exchange
		local arrow = label(exchange, "→", UDim2.fromOffset(EXCHANGE_ARROW, EXCHANGE_ICON),
			UDim2.fromOffset(12 + EXCHANGE_ICON, iconY), 14)
		arrow.TextColor3 = Color3.fromRGB(190, 190, 200)
		local upIcon = DinoPortrait.key(up.Id, UDim2.fromOffset(EXCHANGE_ICON, EXCHANGE_ICON))
		upIcon.Position = UDim2.fromOffset(12 + EXCHANGE_ICON + EXCHANGE_ARROW, iconY)
		upIcon.Parent = exchange
		local textX = 12 + EXCHANGE_ICON * 2 + EXCHANGE_ARROW + 6
		local text = label(exchange, "", UDim2.fromOffset(EXCHANGE_TEXT_WIDTH, EXCHANGE_ROW), UDim2.fromOffset(textX, y), 12)
		text.TextWrapped = true
		text.TextScaled = true -- (the shop value line: smaller when it doesn't fit)
		local textMax = Instance.new("UITextSizeConstraint")
		textMax.MaxTextSize = 12
		textMax.Parent = text
		text.TextXAlignment = Enum.TextXAlignment.Left
		text.TextColor3 = up.Rgb and Color3.fromRGB(table.unpack(up.Rgb)) or Color3.new(1, 1, 1)
		local function exchangeButtonAt(x, caption, times)
			local b = Instance.new("TextButton")
			b.Size = UDim2.fromOffset(EXCHANGE_BUTTON_WIDTH, EXCHANGE_ROW)
			b.Position = UDim2.fromOffset(x, y)
			b.Font = FONT
			b.TextSize = 13
			b.TextColor3 = Color3.new(1, 1, 1)
			b.Text = caption
			b.Parent = exchange
			corner(b, 8)
			b.Activated:Connect(function() -- a tap (2026-10-01: was held a moment)
				Net.request("ExchangeKeys", t.Id, times)
			end)
			return b
		end
		local x0 = textX + EXCHANGE_TEXT_WIDTH + 6
		local one = exchangeButtonAt(x0, "🔁 1번", 1)
		if i == 1 then
			Coach.mark(one, "KeyTrade")
		end
		local all = exchangeButtonAt(x0 + EXCHANGE_BUTTON_WIDTH + 6, "🔁 전부", Config.Keys.ExchangeMaxAtOnce)
		table.insert(exchangeRows, { from = t, up = up, text = text, one = one, all = all,
			items = { fromIcon, arrow, upIcon, text, one, all } })
	end
end

-- saved keys of a grade (normal ones are the leaderboard's 열쇠, the others attributes Keys<Grade>)
local function savedKeys(grade)
	if grade == "Normal" then
		return player:GetAttribute("Keys") or 0
	end
	return player:GetAttribute("Keys" .. grade) or 0
end

local exchangeHeight, buyHeight = 0, 0 -- pixels each tab's contents need (the windows take the taller)
local function refreshExchange()
	local shown = 0
	for _, r in ipairs(exchangeRows) do
		local rate = Formulas.exchangeRate(r.from.Id)
		local have = savedKeys(r.from.Id)
		-- (2026-10-04, "열쇠 가판대 정보도 정리해줘") what is given and got, and how many I have; a grade not yet sold at
		-- this awakening is left out (they are the last rows: the window just ends sooner)
		r.text.Text = string.format("%s %d개 → %s 1개\n가진 %s개", r.from.Name, rate, r.up.Name, Formulas.shortNumber(have))
		local open = Formulas.keyShopOpen(r.up.Id, player:GetAttribute("Rebirths"))
		for _, item in ipairs(r.items) do
			item.Visible = open
		end
		if open then
			shown += 1
		end
		local can = open and have >= rate
		r.one.BackgroundColor3 = can and COLOR_EXCHANGE or COLOR_DISABLED
		r.all.BackgroundColor3 = can and COLOR_EXCHANGE or COLOR_DISABLED
		r.all.Text = can and string.format("🔁 전부\n(%d개)", math.min(have // rate, Config.Keys.ExchangeMaxAtOnce)) or "🔁 전부"
	end
	-- the two tabs are one window to the eye: both as tall as the taller of the two (switching never jumps)
	exchangeHeight = EXCHANGE_TOP + shown * (EXCHANGE_ROW + 6) + 12
	local h = math.max(exchangeHeight, buyHeight)
	exchange.Size = UDim2.fromOffset(KEY_SHOP_SIZE.X.Offset, h)
	keyShop.Size = UDim2.fromOffset(KEY_SHOP_SIZE.X.Offset, h)
end
for _, t in ipairs(Config.Keys.Types) do
	player:GetAttributeChangedSignal("Keys" .. t.Id):Connect(refreshExchange)
end
player:GetAttributeChangedSignal("Rebirths"):Connect(refreshExchange)
player:GetAttributeChangedSignal("Keys"):Connect(refreshExchange)
task.spawn(function()
	while player:GetAttribute("Keys") == nil do
		player:GetAttributeChangedSignal("Keys"):Wait()
	end
	refreshExchange()
end)
buyTabs[2].Activated:Connect(function() -- 🔁 교환
	keyShop.Visible = false
	refreshExchange()
	exchange.Visible = true
end)

-- character upgrades (kept on rebirth): a window like the key shop
-- an X in a window's top right corner that closes it
local function closeButton(window)
	local x = Instance.new("TextButton")
	x.Size = UDim2.fromOffset(36, 36)
	x.Position = UDim2.new(1, -44, 0, 8)
	x.Text = "X"
	x.Font = FONT
	x.TextSize = 20
	x.TextColor3 = Color3.new(1, 1, 1)
	x.BackgroundColor3 = COLOR_FULL
	x.Parent = window
	corner(x, 8)
	x.Activated:Connect(function()
		window.Visible = false
	end)
end
closeButton(keyShop)

-- the rebirth window, opened at the rebirth sign beside the base's spawn pad: what is paid, what is
-- left, what starts over, what is gained
local confirm = Instance.new("Frame")
confirm.AnchorPoint = Vector2.new(0.5, 0.5)
confirm.Position = UDim2.fromScale(0.5, 0.5)
confirm.Size = CONFIRM_SIZE
confirm.BackgroundColor3 = Color3.fromRGB(40, 30, 55)
confirm.Visible = false
confirm.ZIndex = 5
confirm.Parent = gui
Windows.fit(confirm) -- smaller on phones
corner(confirm, 14)
local function rebirthLine(text, y, size, color, height)
	local l = label(confirm, text, UDim2.new(1, -24, 0, height or 18), UDim2.fromOffset(12, y), size)
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextScaled = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = size
	most.Parent = l
	l.ZIndex = 5
	return l
end
local rebirthTitle = rebirthLine("", 8, 22, Color3.new(1, 1, 1), 28)
rebirthLine("🛡️ 디펜스는 LV 1부터 다시! 대신 영원히 더 세져요 💪", 38, 14, Color3.fromRGB(255, 230, 160))
rebirthLine("✅ 그대로 남아요", 62, 13, REBIRTH_KEEP_COLOR)
rebirthLine("⛏️ 곡괭이 · 🎒 가방 · 👋 손바닥 · 🦖 공룡 · 🔑 열쇠", 80, 14, Color3.new(1, 1, 1), 22)
rebirthLine("🎁 바로 받아요", 110, 13, REBIRTH_GIFT_COLOR)
local giftRow = Instance.new("Frame")
giftRow.BackgroundTransparency = 1
giftRow.Size = UDim2.new(1, -24, 0, REBIRTH_GIFT + 16)
giftRow.Position = UDim2.fromOffset(12, 128)
giftRow.ZIndex = 5
giftRow.Parent = confirm
do
	local list = Instance.new("UIListLayout")
	list.FillDirection = Enum.FillDirection.Horizontal
	list.HorizontalAlignment = Enum.HorizontalAlignment.Center
	list.Padding = UDim.new(0, REBIRTH_GIFT_GAP)
	list.SortOrder = Enum.SortOrder.LayoutOrder
	list.Parent = giftRow
end
rebirthLine("⭐ 영원히 더 세져요", 190, 13, REBIRTH_BONUS_COLOR)
local chipRow = Instance.new("Frame")
chipRow.BackgroundTransparency = 1
chipRow.Size = UDim2.new(1, -24, 0, REBIRTH_CHIP.Y)
chipRow.Position = UDim2.fromOffset(12, 208)
chipRow.ZIndex = 5
chipRow.Parent = confirm
do
	local list = Instance.new("UIListLayout")
	list.FillDirection = Enum.FillDirection.Horizontal
	list.HorizontalAlignment = Enum.HorizontalAlignment.Center
	list.Padding = UDim.new(0, 5)
	list.SortOrder = Enum.SortOrder.LayoutOrder
	list.Parent = chipRow
end
local rebirthChips = {}
for i = 1, 4 do
	local chip = label(chipRow, "", UDim2.fromOffset(REBIRTH_CHIP.X, REBIRTH_CHIP.Y), UDim2.new(), 13)
	chip.TextScaled = true
	local chipMost = Instance.new("UITextSizeConstraint")
	chipMost.MaxTextSize = 13
	chipMost.Parent = chip
	chip.LayoutOrder = i
	chip.BackgroundTransparency = 0.3
	chip.BackgroundColor3 = Color3.fromRGB(70, 80, 130)
	chip.ZIndex = 5
	corner(chip, 8)
	rebirthChips[i] = chip
end
local rebirthCost = rebirthLine("", 248, 18, Color3.fromRGB(255, 215, 90), 22)
local rebirthNeed = rebirthLine("", 272, 13, Color3.fromRGB(255, 120, 120), 18)
local giftsShownFor = nil -- the rebirth the gift pictures are for now

-- one gift: its picture (a GuiObject) and a word or count under it
local function gift(order, picture, caption, width)
	width = width or REBIRTH_GIFT_WIDTH
	local holder = Instance.new("Frame")
	holder.BackgroundTransparency = 1
	holder.Size = UDim2.fromOffset(width, REBIRTH_GIFT + 16)
	holder.LayoutOrder = order
	holder.ZIndex = 5
	holder.Parent = giftRow
	picture.Size = UDim2.fromOffset(REBIRTH_GIFT, REBIRTH_GIFT)
	picture.Position = UDim2.fromOffset((width - REBIRTH_GIFT) / 2, 0)
	picture.ZIndex = 5
	picture.Parent = holder
	local words = label(holder, caption, UDim2.new(1, 0, 0, 16), UDim2.fromOffset(0, REBIRTH_GIFT), 12)
	words.TextScaled = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = 12
	most.Parent = words
	words.ZIndex = 5
end
local function emojiTile(emoji, color)
	local t = Instance.new("TextLabel")
	t.Font = FONT
	t.TextScaled = true
	t.Text = emoji
	t.BackgroundColor3 = color
	t.BackgroundTransparency = 0.4
	corner(t, REBIRTH_GIFT // 2)
	return t
end
local function confirmButton(text, color, x)
	local b = Instance.new("TextButton")
	b.Size = UDim2.new(0.5, -18, 0, 44)
	b.Position = UDim2.new(x, x == 0 and 12 or 6, 1, -54)
	b.Font = FONT
	b.TextSize = 17
	b.TextColor3 = Color3.new(1, 1, 1)
	b.BackgroundColor3 = color
	b.Text = text
	b.ZIndex = 5
	b.Parent = confirm
	corner(b, 10)
	return b
end
local confirmYes = confirmButton("환생하기", COLOR_REBIRTH, 0)
local confirmNo = confirmButton("취소", COLOR_DISABLED, 0.5)

local function money()
	return player:GetAttribute("Money") or 0
end

local function paint(b, cost)
	b.BackgroundColor3 = (cost and money() >= cost) and COLOR_BUTTON or COLOR_DISABLED
end

-- (2026-10-04, "글을 읽기 싫어하는 애들 … 정보량이 글로만 너무 많아서" → "제안은 전부 진행") a row is short: what and the
-- level on the first line, the price on the second (and how much is still missing); the numbers behind it only with
-- "ℹ️ 자세히" (showDetails). The best buy now glows with "⭐ 추천" (recommend)
local showDetails = false
local function priceLine(cost)
	local have = money()
	return have >= cost and string.format("%s원", Formulas.shortNumber(cost))
		or string.format("%s원 · %s원 더 모아요", Formulas.shortNumber(cost), Formulas.shortNumber(cost - have))
end
local function row(b, simple, detail, cost)
	b.Text = (showDetails and detail or simple) .. "\n" .. priceLine(cost)
	paint(b, cost)
end
local recommendMarks = {} -- [button] = { star, stroke }
local function recommend(b, on)
	local mark = recommendMarks[b]
	if not mark then
		local star = Instance.new("TextLabel")
		star.AnchorPoint = Vector2.new(1, 0)
		star.Position = UDim2.new(1, 4, 0, -8)
		star.Size = UDim2.fromOffset(RECOMMEND_SIZE.X, RECOMMEND_SIZE.Y)
		star.BackgroundColor3 = COLOR_RECOMMEND
		star.Font = FONT
		star.TextSize = 13
		star.TextColor3 = Color3.fromRGB(60, 40, 0)
		star.Text = "⭐ 추천"
		star.ZIndex = b.ZIndex + 2
		star.Parent = b
		corner(star, 8)
		local stroke = Instance.new("UIStroke")
		stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		stroke.Color = COLOR_RECOMMEND
		stroke.Thickness = RECOMMEND_STROKE
		stroke.Parent = b
		TweenService:Create(stroke, TweenInfo.new(RECOMMEND_PULSE, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
			{ Transparency = 0.8 }):Play()
		mark = { star, stroke }
		recommendMarks[b] = mark
	end
	mark[1].Visible = on
	mark[2].Enabled = on
end

local function powerSecondsLeft(tier, steps)
	local base = (tier - 1) * Config.Pickaxe.PowerSteps
	local left = -(player:GetAttribute("TrainXP_Power") or 0)
	for step = steps, Formulas.powerStepsNeed(tier) - 1 do
		left += Formulas.trainSeconds("Power", base + step) or 0
	end
	return math.max(1, math.ceil(left))
end

local function refreshShop()
	local tier = player:GetAttribute("PickaxeTier") or 1
	local steps = player:GetAttribute("PickaxePower") or 0

	-- the next pickaxe: once this one's power steps are all trained (the rock station)
	local price = Formulas.nextPickaxePrice(tier, player:GetAttribute("DefenseLevel") or 1)
	local pickaxeCost = nil -- (for the recommendation: only when it can be bought)
	pickaxePicture.Visible = price ~= nil
	pickaxeTextPad.PaddingLeft = UDim.new(0, price and PICKAXE_PICTURE or 0)
	if price then
		showPickaxe(tier + 1)
	end
	if price and not Formulas.powerStepsDone(steps, tier) then
		local nextTier = Config.Pickaxe.Tiers[tier + 1]
		pickaxeButton.Text = string.format("⛏️ %s 곡괭이 · %d티어", nextTier.Name, tier + 1) .. "\n"
			.. string.format("🔒 광물 바위에서 💥 파워 훈련 %d초 · Lv %d/%d", powerSecondsLeft(tier, steps),
			Formulas.powerShown(tier, player:GetAttribute("TrainReal_Power") or steps),
			Formulas.powerShown(tier, Formulas.powerStepsNeed(tier)))
		paint(pickaxeButton, nil)
	elseif price and not Formulas.pickaxeOpen(tier + 1, player:GetAttribute("DefenseLevel")) then
		local nextTier = Config.Pickaxe.Tiers[tier + 1]
		pickaxeButton.Text = string.format("⛏️ %s 곡괭이 · %d티어", nextTier.Name, tier + 1) .. "\n"
			.. string.format("🔒 ⚔️ 디펜스 %s에 열려요 (지금 %s)", Formulas.levelText(Formulas.pickaxeNeedLevel(tier + 1)),
			Formulas.levelText(player:GetAttribute("DefenseLevel") or 1))
		paint(pickaxeButton, nil)
	elseif price then
		local nextTier = Config.Pickaxe.Tiers[tier + 1]
		local free = player:GetAttribute("CocoPays") == "Pickaxe"
		pickaxeCost = free and 0 or price
		local gain, opens = Formulas.nextPickaxeGain(tier, player:GetAttribute("TrainReal_Power") or steps,
			player:GetAttribute("TrainReal_Speed") or player:GetAttribute("PickaxeSpeed") or 0)
		local opened = opens and Formulas.grade(opens)
		local simple = opened and string.format("⛏️ %d티어 · 🔓 %s %s 해금!", tier + 1, opened.Icon, opened.Name)
			or string.format("⛏️ %s 곡괭이 · %d티어 · 캐기 ×%.1f", nextTier.Name, tier + 1, gain or 1)
		local detail = string.format("⛏️ 곡괭이 %d티어 %s (파워 %d · 한 번에 %.1f개)", tier + 1, nextTier.Name,
			nextTier.Power, nextTier.Yield)
		if free then
			pickaxeButton.Text = (showDetails and detail or simple) .. "\n" .. "🎁 코코가 내줘요 · 무료!"
			paint(pickaxeButton, 0)
		else
			row(pickaxeButton, simple, detail, price)
		end
	else
		pickaxeButton.Text = "⛏️ 곡괭이: 지금은 최고 티어"
		paint(pickaxeButton, nil)
	end

	local keyY, anyLocked = KEY_SHOP_TOP, false
	for _, row in ipairs(keyRows) do
		-- (2026-10-04) only the grades on sale to me, one after another; the locked ones are one line under them
		local onSale = Formulas.keyShopOpen(row.grade, player:GetAttribute("Rebirths"))
		row.icon.Visible, row.name.Visible = onSale, onSale
		for _, count in ipairs(Config.Gacha.KeyBuyCounts) do
			row[count].Visible = onSale
		end
		if onSale then
			row.icon.Position = UDim2.fromOffset(12, keyY + (KEY_ROW_HEIGHT - KEY_ICON) / 2)
			row.name.Position = UDim2.fromOffset(12 + KEY_ICON + 6, keyY)
			for j, count in ipairs(Config.Gacha.KeyBuyCounts) do
				row[count].Position = UDim2.fromOffset(12 + KEY_ICON + 6 + KEY_NAME_WIDTH + 8
					+ (j - 1) * (KEY_BUTTON_WIDTH + KEY_BUTTON_GAP), keyY)
			end
			keyY += KEY_ROW_HEIGHT + 6
		else
			anyLocked = true
		end
		-- (2026-10-01, "make the better keys something to want") what this key brings at my level now
		local defenseLevel = player:GetAttribute("DefenseLevel") or 1
		if not showDetails then
			row.name.Text = row.keyName
		else
			local o = Formulas.keyOutlook(defenseLevel, row.grade)
			local rarity = o.Rarity and Formulas.rarity(o.Rarity).Name or "?"
			local odds = o.Percent >= 99.95 and (rarity .. " 확정") or string.format("%s %.1f%%", rarity, o.Percent)
			row.name.Text = string.format("%s\n%s%s · ✨변이 %g%%", row.keyName, odds, o.SameAsBelow and " · 크기↑" or "",
				o.Mutation)
		end
		-- (2026-10-02) better grades are sold from an awakening on (Config.Keys.Types ShopRebirths)
		local open = Formulas.keyShopOpen(row.grade, player:GetAttribute("Rebirths"))
		for _, count in ipairs(Config.Gacha.KeyBuyCounts) do
			local total = Formulas.keyBuyPrice(defenseLevel, row.grade, count)
			local off = Formulas.keyBulkOff(count)
			row[count].Text = not open and string.format("🔒 %s부터", Formulas.keyShopCondition(row.grade))
				or off > 0 and string.format("🔑 %d개 -%d%%\n%s원", count, math.floor(off * 100 + 0.5), Formulas.shortNumber(total))
				or string.format("🔑 %d개\n%s원", count, Formulas.shortNumber(total))
			paint(row[count], open and total or nil)
		end
	end
	keyLockNote.Visible = anyLocked
	if anyLocked then
		keyLockNote.Position = UDim2.fromOffset(12, keyY)
		keyY += KEY_LOCK_LINE
	end
	buyHeight = keyY + KEY_SHOP_BOTTOM
	local h = math.max(buyHeight, exchangeHeight)
	keyShop.Size = UDim2.fromOffset(KEY_SHOP_SIZE.X.Offset, h)
	exchange.Size = UDim2.fromOffset(KEY_SHOP_SIZE.X.Offset, h)

	-- ⭐ the next pickaxe when it can be had (the stall NPC shows ❗ meanwhile, Npcs)
	recommend(pickaxeButton, pickaxeCost ~= nil and money() >= pickaxeCost)
	Coach.mark(pickaxeButton, pickaxeCost ~= nil and "BuyPickaxe" or nil)
end

-- the rebirth window's text and whether its button can be pressed (defense LV, money)
local function refreshRebirth()
	local rebirths = player:GetAttribute("Rebirths") or 0
	local cost = Formulas.rebirthCost(rebirths, player:GetAttribute("DefenseLevel") or 1)
	local have = money()
	local defenseLevel = player:GetAttribute("DefenseLevel") or 1
	local top = Formulas.maxDefenseLevel(rebirths)
	local ready = defenseLevel >= top and have >= cost
	local need = ""
	if defenseLevel < top then
		need = string.format("🔒 디펜스 LV %s에서 할 수 있어요 (지금 %s)", Formulas.levelText(top, rebirths),
			Formulas.levelText(defenseLevel, rebirths))
	elseif have < cost then
		need = string.format("💰 %s원 더 모아요", Formulas.shortNumber(cost - have))
	end
	local n = rebirths + 1
	rebirthTitle.Text = string.format("🔄 %d번째 환생", n)
	-- 🎁 what the next rebirth gives at once (Formulas.applyRebirth): pictures, made again only when it changes
	local giftsKey = n .. ":" .. top
	if giftsShownFor ~= giftsKey then
		giftsShownFor = giftsKey
		for _, c in ipairs(giftRow:GetChildren()) do
			if c:IsA("GuiObject") then
				c:Destroy()
			end
		end
		local order = 0
		for _, t in ipairs(Config.Keys.Types) do
			local count = Formulas.rebirthKeys(n)[t.Id]
			if count then
				order += 1
				gift(order, DinoPortrait.key(t.Id, UDim2.fromOffset(REBIRTH_GIFT, REBIRTH_GIFT)), string.format("%s %d개", t.Name, count),
					REBIRTH_KEY_WIDTH)
			end
		end
		local randomDino = false
		local dino = Formulas.rebirthDino(n, function()
			randomDino = true
			return 1
		end)
		if dino then
			order += 1
			gift(order, DinoPortrait.new(dino.Id, UDim2.fromOffset(REBIRTH_GIFT, REBIRTH_GIFT), { hidden = randomDino }),
				randomDino and "❓" or Formulas.rarity(Formulas.rebirthDinoRarity(top + 1)).Name)
		end
		for _, id in ipairs(Formulas.rebirthSureRarities(n)) do
			order += 1
			gift(order, emojiTile("🎰", Color3.fromRGB(120, 90, 200)), string.format("%s 확정", Formulas.rarity(id).Name))
		end
		for _, skin in ipairs(Config.Slap.Skins) do
			if skin.Rebirth == n then
				order += 1
				gift(order, emojiTile("👋", Color3.fromRGB(230, 120, 160)), "스킨")
			end
		end
	end
	-- ⭐ for good (Formulas.rebirthBonuses)
	local bonus = Formulas.rebirthBonuses(n)
	-- (each with a word: "봐도 모를만하게 그림만 막 교체하지 말고")
	rebirthChips[1].Text = string.format("💰 돈\n+%d%%", math.floor(bonus.Money * 100 + 0.5))
	rebirthChips[2].Text = string.format("🦖 공룡 힘\n+%d%%", math.floor(bonus.UnitPower * 100 + 0.5))
	rebirthChips[3].Text = string.format("🍀 좋은 공룡\n+%d%%", math.floor(bonus.RareChance * 100 + 0.5))
	rebirthChips[4].Text = string.format("➕ 공룡 자리\n+%d", bonus.Slots)
	rebirthCost.Text = string.format("💰 %s원", Formulas.shortNumber(cost))
	rebirthNeed.Text = need
	confirmYes.BackgroundColor3 = ready and COLOR_REBIRTH or COLOR_DISABLED
	confirmYes.AutoButtonColor = ready
end

-- buying: a tap (2026-10-01, "just touch": was held a moment)
local function toggleDetails()
	showDetails = not showDetails
	detailsButton.Text = showDetails and "ℹ️ 간단히" or "ℹ️ 자세히"
	keyDetailsButton.Text = detailsButton.Text
	refreshShop()
end
detailsButton.Activated:Connect(toggleDetails)
keyDetailsButton.Activated:Connect(toggleDetails)
pickaxeButton.Activated:Connect(function()
	Net.request("BuyPickaxe")
end)
confirmYes.Activated:Connect(function()
	if not confirmYes.AutoButtonColor then -- grey: not yet (the text says why); the server checks again anyway
		return
	end
	confirm.Visible = false
	Net.request("Rebirth")
end)
confirmNo.Activated:Connect(function()
	confirm.Visible = false
end)
close.Activated:Connect(function()
	shop.Visible = false
end)
-- (2026-10-02, a screen recording: the game stopped for 0.1-0.17 s every second; the money from the defense
-- comes every second and each time the shop and the rebirth window were worked out again, open or not, the
-- rebirth window's long text, with the money in it, translated anew each time) only while open; each is
-- worked out when it opens anyway
-- (2026-10-04) is anything in the shop or at the key stall within reach of the money now? (open or not: the stall NPCs'
-- ❗, Npcs.client; local attributes ShopReady / KeyShopReady, never sent anywhere)
local function updateReady()
	local have = money()
	local tier = player:GetAttribute("PickaxeTier") or 1
	local steps = player:GetAttribute("PickaxePower") or 0
	-- (2026-10-04: the rest is trained) the next pickaxe only
	local price = Formulas.powerStepsDone(steps, tier) and Formulas.pickaxeOpen(tier + 1, player:GetAttribute("DefenseLevel"))
		and Formulas.nextPickaxePrice(tier, player:GetAttribute("DefenseLevel") or 1) or nil
	local ready = price ~= nil and (have >= price or player:GetAttribute("CocoPays") == "Pickaxe")
	player:SetAttribute("ShopReady", ready or nil)
	local keyPrice = Formulas.keyShopPrice(player:GetAttribute("DefenseLevel") or 1, "Normal")
	player:SetAttribute("KeyShopReady", (keyPrice and have >= keyPrice) or nil)
end
local function refreshShopIfShown()
	updateReady()
	if shop.Visible or keyShop.Visible then
		refreshShop()
	end
end
local function refreshRebirthIfShown()
	if confirm.Visible then
		refreshRebirth()
	end
end
for _, name in ipairs({ "PickaxeTier", "PickaxePower", "PickaxeSpeed", "BagLevel", "SlapLevel", "MoveSpeedLevel",
	"Rebirths", "PassDoubleBag", "TrainBoostUntil", "TrainXP_Power", "TrainXP_Speed", "TrainXP_Bag", "TrainXP_Slap",
	"TrainXP_MoveSpeed", "CocoPays" }) do
	player:GetAttributeChangedSignal(name):Connect(refreshShopIfShown)
end
player:GetAttributeChangedSignal("Rebirths"):Connect(refreshRebirthIfShown)
player:GetAttributeChangedSignal("DefenseLevel"):Connect(refreshRebirthIfShown)
player:GetAttributeChangedSignal("DefenseLevel"):Connect(refreshShopIfShown) -- the key price follows the defense level
player:GetAttributeChangedSignal("Money"):Connect(refreshShopIfShown)
player:GetAttributeChangedSignal("Money"):Connect(refreshRebirthIfShown)
task.spawn(function()
	while player:GetAttribute("Money") == nil do
		player:GetAttributeChangedSignal("Money"):Wait()
	end
	refreshShop()
	updateReady()
end)

local shopPrompt, rebirthPrompt, keyPrompt = nil, nil, nil
ProximityPromptService.PromptTriggered:Connect(function(prompt)
	if prompt:GetAttribute("Base") ~= player:GetAttribute("Base") then
		return
	end
	local kind = prompt:GetAttribute("Kind")
	if kind == "Shop" then
		if shop.Visible then -- E again closes it
			shop.Visible = false
			return
		end
		confirm.Visible, keyShop.Visible = false, false
		shopPrompt = prompt
		refreshShop()
		shop.Visible = true
	elseif kind == "KeyShop" then
		if keyShop.Visible or exchange.Visible then -- E again closes it
			keyShop.Visible, exchange.Visible = false, false
			return
		end
		shop.Visible, confirm.Visible = false, false
		keyPrompt = prompt
		refreshShop()
		keyShop.Visible = true
	elseif kind == "Rebirth" then
		if confirm.Visible then -- E again closes it
			confirm.Visible = false
			return
		end
		shop.Visible, keyShop.Visible = false, false
		rebirthPrompt = prompt
		refreshRebirth()
		confirm.Visible = true
	end
end)

local function walkedAway(prompt, range)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local holder = prompt and prompt.Parent -- (a part, or an attachment: Bases.prompt, 2026-10-02)
	local at = holder and (holder:IsA("Attachment") and holder.WorldPosition or holder:IsA("BasePart") and holder.Position)
	return not root or not at or (root.Position - at).Magnitude > range + prompt.MaxActivationDistance
end

RunService.Heartbeat:Connect(FrameMeter.wrap("Hud", function() -- walked away from the shop or the rebirth sign: close it
	if shop.Visible and shopPrompt and walkedAway(shopPrompt, Config.Shop.Range) then
		shop.Visible = false
	end
	if (keyShop.Visible or exchange.Visible) and keyPrompt and walkedAway(keyPrompt, Config.Shop.Range) then
		keyShop.Visible, exchange.Visible = false, false
	end
	if confirm.Visible and rebirthPrompt and walkedAway(rebirthPrompt, Config.Rebirth.SignRange) then
		confirm.Visible = false
	end
end))

-- ---------------------------------------------------------------------------
-- Only this player's base prompts
-- ---------------------------------------------------------------------------

local basePrompts = LiveSet.new()
local laterPrompts = setmetatable({}, { __mode = "k" })
local lockWatched = setmetatable({}, { __mode = "k" })
local function promptAllowed(prompt)
	return prompt:GetAttribute("Base") == player:GetAttribute("Base") and not prompt:GetAttribute("Locked")
end
local function filterPrompt(prompt)
	if not prompt:IsA("ProximityPrompt") then
		return
	end
	if prompt:GetAttribute("Base") then
		basePrompts:add(prompt)
		prompt.Enabled = promptAllowed(prompt)
		if not lockWatched[prompt] then
			lockWatched[prompt] = true
			prompt:GetAttributeChangedSignal("Locked"):Connect(function()
				prompt.Enabled = promptAllowed(prompt)
			end)
		end
	elseif not laterPrompts[prompt] then
		laterPrompts[prompt] = true
		prompt:GetAttributeChangedSignal("Base"):Connect(function()
			filterPrompt(prompt)
		end)
	end
end

local function filterAll()
	basePrompts:each(function(prompt)
		prompt.Enabled = promptAllowed(prompt)
	end)
end

task.spawn(function()
	local map = Workspace:WaitForChild("Map")
	WorldWatch.listen({ "ProximityPrompt" }, function(prompt)
		if prompt:IsDescendantOf(map) then
			filterPrompt(prompt)
		end
	end)
end)
player:GetAttributeChangedSignal("Base"):Connect(filterAll)

-- ---------------------------------------------------------------------------
-- Home button
-- ---------------------------------------------------------------------------

local home = Instance.new("TextButton")
home.AnchorPoint = Vector2.new(1, 0.5)
home.Size = HOME_SIZE
home.Position = HOME_POS
home.Font = FONT
home.TextSize = 14
home.TextColor3 = Color3.new(1, 1, 1)
home.BackgroundColor3 = COLOR_HOME
home.Text = "🏠 기지로"
home.TextWrapped = true
home.Parent = gui
corner(home, 12)
SideButtons.register(home) -- the right column folds away (Shared/SideButtons)

home.Activated:Connect(function()
	if not player:GetAttribute("TeleportAt") then
		Net.request("TeleportHome")
	end
end)

-- key drop timer
local timer = label(gui, "", TIMER_SIZE, TIMER_POS, 14)
timer.TextScaled = true -- shrinks rather than spilling out of the narrow column
local timerTextSize = Instance.new("UITextSizeConstraint")
timerTextSize.MaxTextSize = 14
timerTextSize.Parent = timer
timer.AnchorPoint = Vector2.new(1, 1)
timer.BackgroundTransparency = 0.2
timer.BackgroundColor3 = COLOR_BG
corner(timer, 10)
do
	local glow = Instance.new("UIStroke")
	glow.Name = "Glow"
	glow.Color = TIMER_GLOW.Color
	glow.Thickness = TIMER_GLOW.Thickness
	glow.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	glow.Parent = timer
	local pop = Instance.new("UIScale")
	pop.Name = "Pop"
	pop.Parent = timer
end

local timerShown = nil
RunService.Heartbeat:Connect(FrameMeter.wrap("Hud", function()
	local boostLeft = math.ceil((player:GetAttribute("TrainBoostUntil") or 0) - Workspace:GetServerTimeNow())
	boostText.Visible = boostLeft > 0
	if boostLeft > 0 then
		boostText.Position = friendText.Visible and FRIEND_POS - UDim2.fromOffset(0, FRIEND_SIZE.Y.Offset + BOOST_GAP) or FRIEND_POS
		Lang.set(boostText, string.format("⚡ 훈련 ×%d · %d:%02d", Config.Training.BoostMultiplier, boostLeft // 60, boostLeft % 60))
	end
	local nextDrop = ReplicatedStorage:GetAttribute("NextKeyDrop")
	timer.Visible = nextDrop ~= nil
	if nextDrop then
		local left = math.max(0, math.ceil(nextDrop - Workspace:GetServerTimeNow()))
		local big = ReplicatedStorage:GetAttribute("NextKeyDropBig") == true
		local shownAs = big and -left - 1 or left
		if timerShown ~= shownAs then
			timerShown = shownAs
			timer.Text = string.format(big and "⚡🎁 %d:%02d" or "🎁 ⏰ %d:%02d", left // 60, left % 60)
		end
		timer.TextColor3 = left <= TIMER_SOON and COLOR_TIMER_SOON or big and COLOR_TIMER_BIG or COLOR_KEYS
		local soon = left <= TIMER_SOON
		local wave = math.sin(os.clock() * (soon and TIMER_GLOW.SoonSpeed or TIMER_GLOW.Speed))
		timer.Glow.Transparency = 0.45 - 0.45 * wave
		timer.Glow.Thickness = soon and TIMER_GLOW.SoonThickness or TIMER_GLOW.Thickness
		timer.Glow.Color = soon and COLOR_TIMER_SOON or TIMER_GLOW.Color
		timer.Pop.Scale = soon and 1 + TIMER_GLOW.SoonScale * math.abs(wave) or 1
		timer.BackgroundColor3 = soon and wave > 0 and TIMER_GLOW.SoonBack or COLOR_BG
	end
end))

local homeCount = nil -- the number the 기지로 countdown shows now: a beep with each, a chime at the end
RunService.Heartbeat:Connect(FrameMeter.wrap("Hud", function()
	local at = player:GetAttribute("TeleportAt")
	if at then
		local left = math.max(0, at - Workspace:GetServerTimeNow())
		local count = math.ceil(left)
		home.Text = string.format("🏠 %d…", count)
		home.BackgroundColor3 = COLOR_DISABLED
		if count ~= homeCount and count > 0 then
			Sfx.play("CountTick")
		end
		homeCount = count -- (0 too: the reset below goes by it)
	elseif homeCount then -- (2026-10-02: was "the text is not 🏠 기지로 yet", but in English the translator still
		-- remembered "🏠 기지로" under the countdown "🏠 0…" (no Korean in it), so the button stayed on "0…")
		home.Text = "🏠 기지로"
		home.BackgroundColor3 = COLOR_HOME
		Sfx.play("CountGo") -- off home
		homeCount = nil
	end
end))

-- Esc / Backspace / gamepad B closes the last opened window; a sub-window goes back to the shop
Windows.register(shop)
Windows.register(keyShop)
exchangeTabs[1].Activated:Connect(function() -- 🛒 사기 (here: refreshShop is known by now)
	exchange.Visible = false
	keyShop.Visible = true
	refreshShop()
end)
Windows.register(exchange, function() -- back to the key shop
	exchange.Visible = false
	keyShop.Visible = true
	refreshShop() -- (not kept up to date while closed)
end)
Windows.register(confirm)
