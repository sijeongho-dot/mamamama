local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local CocoVoice = require(Shared:WaitForChild("CocoVoice"))
local Lang = require(Shared:WaitForChild("Lang"))
local Net = require(Shared:WaitForChild("Net"))
local Pictures = require(Shared:WaitForChild("Pictures"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

local FONT = Enum.Font.GothamBlack
local DISPLAY_ORDER = 30
local CARD_SIZE = UDim2.fromOffset(460, 440)
local COLOR_BG = Color3.fromRGB(22, 26, 46)
local COLOR_TOP = Color3.fromRGB(120, 210, 120)
local COLOR_BOTTOM = Color3.fromRGB(70, 160, 220)
local COLOR_GO = Color3.fromRGB(80, 190, 95)
local GOLD = Color3.fromRGB(255, 215, 90)
local NOTE_COLOR = Color3.fromRGB(230, 255, 230)
local PICTURE_SIZE = 130
local PICTURE_TOP = 56
local TITLE_TEXT = 34
local LINE_TEXT = 26
local GIFT_TEXT = 28
local NOTE_TEXT = 21
local GO_TEXT = 30
local GO_SIZE = UDim2.fromOffset(300, 58)
local BUTTON_PULSE, PULSE_SPEED = 0.06, 5
local PICTURE_BOB, BOB_SPEED = 5, 3
local WAIT_STEP = 0.3
local START_DELAY = 3
local WELCOME_GAP = 3
local FREE_FOR = 0.6
local KEY_PICTURE = "Key_%s"
local PICTURE_NAME = "Picture"
local FALLBACK_ICON = { Money = "💰" }
local DEFAULT_ICON = "🎁"
local TITLE = "🌱 다시 와서 반가워요!"
local DAYS_LINE = "%d일 만이에요! 🎁 새 출발 선물이에요"
local NOTE = "📆 출석은 오늘부터 새로 1일째예요"
local GO = "🎁 받기!"

if ReplicatedStorage:GetAttribute("TutorialField") then
	return
end

local gui = Instance.new("ScreenGui")
gui.Name = "Comeback"
gui.ResetOnSpawn = false
gui.DisplayOrder = DISPLAY_ORDER
gui.Parent = player:WaitForChild("PlayerGui")

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.Text = ""
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextStrokeTransparency = 0.3
	l.TextScaled = true
	l.TextWrapped = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = textSize
	most.Parent = l
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local card = Instance.new("Frame")
card.AnchorPoint = Vector2.new(0.5, 0.5)
card.Position = UDim2.fromScale(0.5, 0.5)
card.Size = CARD_SIZE
card.BackgroundColor3 = Color3.new(1, 1, 1)
card.Visible = false
card.Parent = gui
corner(card, 16)
local shade = Instance.new("UIGradient")
shade.Rotation = 90
shade.Color = ColorSequence.new(COLOR_TOP, COLOR_BOTTOM)
shade.Parent = card
local veil = Instance.new("Frame")
veil.Size = UDim2.fromScale(1, 1)
veil.BackgroundColor3 = COLOR_BG
veil.BackgroundTransparency = 0.45
veil.ZIndex = 0
veil.Parent = card
corner(veil, 16)
local edge = Instance.new("UIStroke")
edge.Color = GOLD
edge.Thickness = 3
edge.Parent = card

local holder = Instance.new("Frame")
holder.AnchorPoint = Vector2.new(0.5, 0)
holder.Size = UDim2.fromOffset(PICTURE_SIZE, PICTURE_SIZE)
holder.Position = UDim2.new(0.5, 0, 0, PICTURE_TOP)
holder.BackgroundColor3 = COLOR_BG
holder.BackgroundTransparency = 0.3
holder.Parent = card
corner(holder, PICTURE_SIZE / 2)
local holderEdge = Instance.new("UIStroke")
holderEdge.Color = GOLD
holderEdge.Thickness = 3
holderEdge.Parent = holder
local icon = label(holder, UDim2.fromScale(0.8, 0.8), UDim2.fromScale(0.1, 0.1), 80)

local top = PICTURE_TOP + PICTURE_SIZE + 8
local title = label(card, UDim2.new(1, -60, 0, 44), UDim2.fromOffset(30, 8), TITLE_TEXT, GOLD)
local daysLine = label(card, UDim2.new(1, -30, 0, 34), UDim2.fromOffset(15, top), LINE_TEXT)
local giftLine = label(card, UDim2.new(1, -30, 0, 64), UDim2.fromOffset(15, top + 38), GIFT_TEXT, GOLD)
local note = label(card, UDim2.new(1, -30, 0, 28), UDim2.fromOffset(15, top + 106), NOTE_TEXT, NOTE_COLOR)

local go = Instance.new("TextButton")
go.AnchorPoint = Vector2.new(0.5, 1)
go.Position = UDim2.new(0.5, 0, 1, -14)
go.Size = GO_SIZE
go.BackgroundColor3 = COLOR_GO
go.Font = FONT
go.Text = GO
go.TextColor3 = Color3.new(1, 1, 1)
go.TextScaled = true
local goMost = Instance.new("UITextSizeConstraint")
goMost.MaxTextSize = GO_TEXT
goMost.Parent = go
go.Parent = card
corner(go, 12)
local goEdge = Instance.new("UIStroke")
goEdge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
goEdge.Color = Color3.new(1, 1, 1)
goEdge.Thickness = 2
goEdge.Parent = go
local pulse = Instance.new("UIScale")
pulse.Parent = go

Windows.fit(card)
Windows.register(card, nil, { Keep = true })

local welcomeClosedAt = -math.huge
player:GetAttributeChangedSignal("WelcomeUp"):Connect(function()
	if not player:GetAttribute("WelcomeUp") then
		welcomeClosedAt = os.clock()
	end
end)

local function busy()
	return os.clock() - welcomeClosedAt < WELCOME_GAP or player:GetAttribute("Loading")
		or player:GetAttribute("LanguagePick") or player:GetAttribute("TutorialAsk") or player:GetAttribute("CocoIntro") or player:GetAttribute("FirstFight") or player:GetAttribute("TutorialStep")
		or player:GetAttribute("TutorialTravel") or player:GetAttribute("Cinematic") or player:GetAttribute("Racing")
		or player:GetAttribute("PromoLevel") or player:GetAttribute("HideSeekRoom") or player:GetAttribute("WelcomeUp")
		or player:GetAttribute("FreshStart") or (player:GetAttribute("DefenseLevel") or 1) < 2
end

local function setPicture(keyId)
	local old = holder:FindFirstChild(PICTURE_NAME)
	if old then
		old:Destroy()
	end
	local picture = keyId and Pictures.of({ "Key", string.format(KEY_PICTURE, keyId) }, UDim2.fromScale(1, 1))
	if picture then
		picture.Name = PICTURE_NAME
		picture.Parent = holder
		icon.Text = ""
	else
		icon.Text = FALLBACK_ICON[keyId] or DEFAULT_ICON
	end
end

local showing = false
local function show()
	if showing or card.Visible then
		return
	end
	showing = true
	task.wait(START_DELAY)
	local freeSince = nil
	while player.Parent and player:GetAttribute("ComebackDays") do
		if busy() or Windows.anyOpen() then
			freeSince = nil
		elseif not freeSince then
			freeSince = os.clock()
		elseif os.clock() - freeSince >= FREE_FOR then
			break
		end
		task.wait(WAIT_STEP)
	end
	showing = false
	local days = player:GetAttribute("ComebackDays")
	if not days then
		return
	end
	title.Text = TITLE
	daysLine.Text = string.format(DAYS_LINE, days)
	giftLine.Text = player:GetAttribute("ComebackGift") or ""
	note.Text = NOTE
	go.Text = GO
	setPicture(player:GetAttribute("ComebackKey"))
	card.Visible = true
	Sfx.play("Victory")
	CocoVoice.babble(Lang.t(TITLE))
	while card.Visible do
		local t = os.clock()
		pulse.Scale = 1 + math.sin(t * PULSE_SPEED) * BUTTON_PULSE
		holder.Position = UDim2.new(0.5, 0, 0, PICTURE_TOP + math.sin(t * BOB_SPEED) * PICTURE_BOB)
		RunService.RenderStepped:Wait()
	end
end

go.Activated:Connect(function()
	if not card.Visible then
		return
	end
	card.Visible = false
	Sfx.play("LevelUp")
	Net.request("ClaimComeback")
end)

player:GetAttributeChangedSignal("ComebackDays"):Connect(function()
	if player:GetAttribute("ComebackDays") then
		task.spawn(show)
	else
		card.Visible = false
	end
end)
if player:GetAttribute("ComebackDays") then
	task.spawn(show)
end
