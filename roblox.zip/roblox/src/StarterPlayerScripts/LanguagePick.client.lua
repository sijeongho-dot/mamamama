--[[
LanguagePick (2026-10-03, "게임 시작 시 언어부터 선택하게 해서 코코가 튜토리얼 말할 때도 언어가 설정돼서 나오게 해"):
a player who never chose a language is asked first (player attribute LanguagePick, set by the Tutorial service
before the tutorial starts), and the settings' 🌐 button opens it too (LanguageMenu). A button a language, each
name in itself, the device's language first; a press sends Net request SetLanguage(code) (the Settings service
saves it and clears LanguagePick) and shows the screen in it at once.
Every text here keeps its own words (attribute KeepText: the Translate script leaves them).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Lang = require(Shared:WaitForChild("Lang"))

local player = Players.LocalPlayer

local FONT = Enum.Font.GothamBold
local PANEL_SIZE = UDim2.fromOffset(480, 290)
local TITLE_HEIGHT = 40
local LIST_TOP = 62
local BUTTON_HEIGHT = 44
local BUTTON_GAP = 8
local COLUMNS = 3
local CLOSE_SIZE = 30
local COLOR_DIM = Color3.fromRGB(0, 0, 0)
local DIM_TRANSPARENCY = 0.35
local COLOR_BG = Color3.fromRGB(30, 34, 50)
local COLOR_TITLE = Color3.fromRGB(150, 255, 220)
local COLOR_CLOSE = Color3.fromRGB(90, 96, 120)
local COLOR_DEVICE = Color3.fromRGB(255, 255, 255)
local DEVICE_STROKE = 3
local COLOR_NOW = Color3.fromRGB(255, 225, 90)
local COLORS = {
	en = Color3.fromRGB(70, 130, 220), ko = Color3.fromRGB(70, 180, 110), es = Color3.fromRGB(230, 130, 50),
	ro = Color3.fromRGB(200, 170, 40), fr = Color3.fromRGB(60, 90, 200), de = Color3.fromRGB(200, 70, 60),
	ru = Color3.fromRGB(120, 90, 200), pt = Color3.fromRGB(40, 160, 90), tr = Color3.fromRGB(220, 60, 90),
	pl = Color3.fromRGB(190, 80, 140), ja = Color3.fromRGB(210, 80, 110), id = Color3.fromRGB(180, 60, 60),
}
local FLAGS = {
	en = "🇺🇸", ko = "🇰🇷", es = "🇪🇸", ro = "🇷🇴", fr = "🇫🇷", de = "🇩🇪", ru = "🇷🇺", pt = "🇧🇷", tr = "🇹🇷", pl = "🇵🇱",
	ja = "🇯🇵", id = "🇮🇩",
}
local TITLE = "🌐 Language · Idioma · Langue · Sprache · Limbă\nЯзык · Língua · Dil · Język · 言語 · Bahasa"

local gui = Instance.new("ScreenGui")
gui.Name = "LanguagePick"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.DisplayOrder = 30
gui.Enabled = false
gui.Parent = player:WaitForChild("PlayerGui")

local dim = Instance.new("TextButton")
dim.Size = UDim2.fromScale(1, 1)
dim.BackgroundColor3 = COLOR_DIM
dim.BackgroundTransparency = DIM_TRANSPARENCY
dim.AutoButtonColor = false
dim.Text = ""
dim.Parent = gui

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(0.5, 0.5)
panel.Position = UDim2.fromScale(0.5, 0.5)
panel.Active = true
panel.BackgroundColor3 = COLOR_BG
panel.Parent = dim
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 16)
	round.Parent = panel
	local scale = Instance.new("UIAspectRatioConstraint")
	scale.AspectRatio = PANEL_SIZE.X.Offset / PANEL_SIZE.Y.Offset
	scale.Parent = panel
	local limit = Instance.new("UISizeConstraint")
	limit.MaxSize = Vector2.new(PANEL_SIZE.X.Offset, PANEL_SIZE.Y.Offset)
	limit.Parent = panel
end
panel.Size = UDim2.new(0.9, 0, 0.9, 0)

local title = Instance.new("TextLabel")
title.BackgroundTransparency = 1
title.Font = FONT
title.TextScaled = true
title.TextColor3 = COLOR_TITLE
title.Text = TITLE
title:SetAttribute("KeepText", true)
title.Size = UDim2.new(1, -32 - CLOSE_SIZE, 0, TITLE_HEIGHT)
title.Position = UDim2.fromOffset(16, 12)
title.Parent = panel

local close = Instance.new("TextButton")
close.Size = UDim2.fromOffset(CLOSE_SIZE, CLOSE_SIZE)
close.AnchorPoint = Vector2.new(1, 0)
close.Position = UDim2.new(1, -10, 0, 10)
close.BackgroundColor3 = COLOR_CLOSE
close.Font = FONT
close.TextScaled = true
close.TextColor3 = Color3.new(1, 1, 1)
close.Text = "X"
close:SetAttribute("KeepText", true)
close.Parent = panel
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = close
end

local list = Instance.new("Frame")
list.BackgroundTransparency = 1
list.Size = UDim2.new(1, -32, 1, -LIST_TOP - 14)
list.Position = UDim2.fromOffset(16, LIST_TOP)
list.Parent = panel
local grid = Instance.new("UIGridLayout")
grid.CellPadding = UDim2.fromOffset(BUTTON_GAP, BUTTON_GAP)
grid.CellSize = UDim2.new(1 / COLUMNS, -BUTTON_GAP * (COLUMNS - 1) / COLUMNS, 0, BUTTON_HEIGHT)
grid.SortOrder = Enum.SortOrder.LayoutOrder
grid.Parent = list

local function hide()
	player:SetAttribute("LanguageMenu", nil)
	gui.Enabled = player:GetAttribute("LanguagePick") == true
end

local buttons = {}
for i, code in ipairs(Lang.LANGUAGES) do
	local b = Instance.new("TextButton")
	b.LayoutOrder = i
	b.BackgroundColor3 = COLORS[code] or COLOR_BG
	b.Font = FONT
	b.TextScaled = true
	b.TextColor3 = Color3.new(1, 1, 1)
	b.Text = string.format("%s  %s", FLAGS[code] or "🌐", Lang.NAMES[code])
	b:SetAttribute("KeepText", true)
	b.Parent = list
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 12)
	round.Parent = b
	local pad = Instance.new("UIPadding")
	pad.PaddingTop, pad.PaddingBottom = UDim.new(0, 9), UDim.new(0, 9)
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, 6), UDim.new(0, 6)
	pad.Parent = b
	local stroke = Instance.new("UIStroke")
	stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	stroke.Thickness = DEVICE_STROKE
	stroke.Enabled = false
	stroke.Parent = b
	buttons[code] = { button = b, stroke = stroke }
	b.Activated:Connect(function()
		player:SetAttribute("Language", code)
		Net.request("SetLanguage", code)
		player:SetAttribute("LanguagePick", nil)
		hide()
	end)
end

local function arrange()
	local device = Lang.deviceCode(player)
	local now = Lang.code(player)
	for i, code in ipairs(Lang.LANGUAGES) do
		local b = buttons[code]
		b.button.LayoutOrder = if code == device then 0 else i
		b.stroke.Enabled = code == device or code == now
		b.stroke.Color = if code == now and player:GetAttribute("LanguageMenu") then COLOR_NOW else COLOR_DEVICE
	end
end

local function refresh()
	local asked = player:GetAttribute("LanguagePick") == true
	close.Visible = not asked
	arrange()
	gui.Enabled = asked or player:GetAttribute("LanguageMenu") == true
end
close.Activated:Connect(hide)
dim.Activated:Connect(function()
	if not player:GetAttribute("LanguagePick") then
		hide()
	end
end)
player:GetAttributeChangedSignal("LanguagePick"):Connect(refresh)
player:GetAttributeChangedSignal("LanguageMenu"):Connect(refresh)
refresh()
