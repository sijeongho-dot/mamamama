--[[
News: opens the update news (Shared/BetaWindows) when the server says it is new to this player (Net push
OpenNews from BetaLog, a few seconds after joining). 설정 has a button to see it again any time.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local BetaWindows = require(Shared:WaitForChild("BetaWindows"))

local player = game:GetService("Players").LocalPlayer

Net.onPush("OpenNews", function()
	-- (2026-10-03) not on the tutorial field, nor while on the way there
	if ReplicatedStorage:GetAttribute("TutorialField") or player:GetAttribute("TutorialTravel") then
		return
	end
	while player:GetAttribute("CocoIntro") or player:GetAttribute("FirstFight") or (player:GetAttribute("DefenseLevel") or 1) < 2
		or player:GetAttribute("FreshStart") do
		task.wait(0.5)
	end
	BetaWindows.openNews(true)
end)
