--[[
Music: the game's background music, on each client (display only).

The songs are the game's own mp3 files, uploaded to Roblox (Studio: Asset Manager → Bulk Import).
Every Sound in SoundService.GameMusic is a song, whatever its name; so are Sounds named like TRACKS
lying loose in SoundService, and the audio ids in UPLOADED. With none, nothing plays. The Output
window says once how many songs were found, and warns about a song that can't be loaded.

Order (2026-10-02): every song once a round, each round in a new shuffled order (never the same song twice
in a row). Between two songs: GAP_SECONDS of quiet. Each song fades in and out. The 보기
설정 bar "🎵 배경음악" (setting MusicVolume, 0 to 1, saved; 2026-10-01, was the MuteMusic switch) sets its volume:
at BAR_NORMAL (60%, where it starts) the songs play at VOLUME, at 100% about 3 times as loud (a curve, BAR_CURVE).
]]

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local SoundService = game:GetService("SoundService")

local player = Players.LocalPlayer

-- display only
local TRACKS = { "7out", "mixymixy", "ONE", "uo", "12-1-1", "ffddfi", "RYUE_soft_full", "MIN_soft_full", "TWOw_soft_full" }
local LEFT_OUT = { twow = true } -- songs taken out of the game (lower case): skipped even if still in GameMusic
-- (the old "TWOw" stays out; its soft remix "TWOw_soft_full" came in on 2026-10-01)
local SONG_VOLUME = { -- (lower case) songs mastered louder than the others play this much quieter (1 when not listed)
	-- (2026-10-03, "mixymixy, MIN_soft_full 제외하고 소리 조금 올리는거로하자. TWOw_soft_full는 방금 올린대로만 놔둬": the
	-- others up about a fifth: 7out, uo, 12-1-1, ffddfi were 1, ONE 0.9, RYUE_soft_full 0.5)
	["7out"] = 1.2, uo = 0.95, -- (2026-10-04, "곡 u 가 살짝 더 큰 거 같아": uo was 1.2)
	["12-1-1"] = 1.2, ffddfi = 1.2, one = 1.1, mixymixy = 0.5,
	-- (2026-10-01) the three soft remixes: as quiet as the quietest (mixymixy)
	ryue_soft_full = 0.6, min_soft_full = 0.5,
	twow_soft_full = 0.7, -- (2026-10-03, "TWOw_soft_full 음량이 조금 작은듯": was 0.5)
}
local UPLOADED = { -- audio ids by song name (0 = not uploaded); a Sound in SoundService.GameMusic wins over these
	["7out"] = 0, mixymixy = 0, ONE = 0, uo = 0, ["12-1-1"] = 0, ffddfi = 0,
	RYUE_soft_full = 0, MIN_soft_full = 0, TWOw_soft_full = 0,
}
local VOLUME = 0.17 -- steady, well under the sound effects (0.5-0.8); 0.4 and 0.3 got in their way
-- (2026-10-04, "음악소리가 전반적으로 큰 듯": was 0.22, about −2 dB)
local BAR_NORMAL = 0.6 -- the bar here plays the songs at VOLUME; above it louder (ProfileLogic MUSIC_SCALE)
local BAR_CURVE = 2.2 -- (bar ÷ BAR_NORMAL) ^ this: 100% about × 3.1 (+10 dB), 30% about × 0.22
local GAP_SECONDS = 12 -- quiet between two songs
local FADE_SECONDS = 2
local FIRST_DELAY = 3 -- after joining, before the first song
local LOAD_TIMEOUT = 15
local CINEMA_SONG = "ryue_soft_full"
local CINEMA_FADE_SECONDS = 0.6
local CINEMA_KEEP_LEFT = 60
local POLL = 0.1

-- every song found, as { name, id }: all Sounds in SoundService.GameMusic (any name, also in
-- subfolders), the TRACKS lying loose in SoundService (any upper/lower case), and the UPLOADED ids
local function findSongs()
	local songs, seen = {}, {}
	local function add(name, id)
		if id and id ~= "" and not seen[id] and not LEFT_OUT[string.lower(name)] then
			seen[id] = true
			table.insert(songs, { name = name, id = id })
		end
	end
	local folder = SoundService:FindFirstChild("GameMusic")
	if folder then
		for _, d in ipairs(folder:GetDescendants()) do
			if d:IsA("Sound") then
				add(d.Name, d.SoundId)
			end
		end
	end
	local wanted = {}
	for _, name in ipairs(TRACKS) do
		wanted[string.lower(name)] = true
	end
	for _, c in ipairs(SoundService:GetChildren()) do
		if c:IsA("Sound") and wanted[string.lower(c.Name)] then
			add(c.Name, c.SoundId)
		end
	end
	for _, name in ipairs(TRACKS) do
		local id = UPLOADED[name]
		if id and id ~= 0 then
			add(name, "rbxassetid://" .. id)
		end
	end
	-- (a fixed order: TRACKS' order first, then any other song by name)
	local rank = {}
	for i, name in ipairs(TRACKS) do
		rank[string.lower(name)] = i
	end
	table.sort(songs, function(a, b)
		local ra, rb = rank[string.lower(a.name)] or math.huge, rank[string.lower(b.name)] or math.huge
		if ra ~= rb then
			return ra < rb
		end
		return a.name < b.name
	end)
	return songs
end

-- a song's own volume (SONG_VOLUME) by its name in any case; a name with more around it (an import
-- that kept a prefix or ".ogg") still finds its song's entry
local function songVolumeOf(name)
	local lower = string.lower(name)
	if SONG_VOLUME[lower] then
		return SONG_VOLUME[lower]
	end
	for key, volume in pairs(SONG_VOLUME) do
		if #key > 4 and string.find(lower, key, 1, true) then
			return volume
		end
	end
	return 1
end

-- the 배경음악 bar (player attribute MusicVolume, 0 to 1; Settings)
local function barVolume()
	local v = player:GetAttribute("MusicVolume")
	-- (2026-10-02, "차이가 그다지 안나는데 60퍼랑 100퍼랑": × 1.67 at 100% is only about +4 dB) a curve: the ear hears
	-- loudness roughly by its log, so the bar's top part rises much more (100%: × (1 / 0.6) ^ BAR_CURVE, about +10 dB)
	return ((type(v) == "number" and math.clamp(v, 0, 1) or BAR_NORMAL) / BAR_NORMAL) ^ BAR_CURVE
end

-- (2026-10-02, "음악 재생은 한 사이클당 모든 곡이 한번씩은 재생되되 순서는 항상 다르게"; was the list's order with a
-- random first song) a round plays every song once in a new shuffled order; the next round never starts with the
-- song that just ended
local round = {} -- the songs still to play this round, next last
local lastSong = nil

local function sameSong(a, b)
	return a ~= nil and b ~= nil and a.id == b.id
end

local function inSongs(songs, song)
	for _, other in ipairs(songs) do
		if sameSong(other, song) then
			return true
		end
	end
	return false
end

local function nextSong()
	local songs = findSongs()
	if #songs == 0 then
		return nil
	end
	-- (a song gone from the list meanwhile is skipped)
	while #round > 0 and not inSongs(songs, round[#round]) do
		table.remove(round)
	end
	if #round == 0 then
		round = table.clone(songs)
		for i = #round, 2, -1 do -- shuffled
			local j = math.random(1, i)
			round[i], round[j] = round[j], round[i]
		end
		if #round > 1 and sameSong(round[#round], lastSong) then -- (not the same song twice in a row)
			round[#round], round[1] = round[1], round[#round]
		end
	end
	lastSong = table.remove(round)
	return lastSong
end

local music = Instance.new("Sound")
music.Name = "BackgroundMusic"
music.Volume = 0
music.Looped = false
music.Parent = SoundService

-- the volume, every frame: the song's fade × the 배경음악 bar (eased)
local fade, fadeTarget, fadeSeconds = 0, 0, FADE_SECONDS
local songVolume = 1 -- SONG_VOLUME of the song playing
local switch = barVolume()
RunService.Heartbeat:Connect(FrameMeter.wrap("Music", function(dt)
	local step = dt / fadeSeconds
	fade = if fadeTarget > fade then math.min(fadeTarget, fade + step) else math.max(fadeTarget, fade - step)
	local ease = dt / FADE_SECONDS
	local on = barVolume()
	switch = if on > switch then math.min(on, switch + ease) else math.max(on, switch - ease)
	music.Volume = VOLUME * fade * switch * songVolume
end))

local cue = nil
local playing = nil

local function cinemaSong()
	for _, song in ipairs(findSongs()) do
		if string.find(string.lower(song.name), CINEMA_SONG, 1, true) then
			return song
		end
	end
	return nil
end

local function onCinematic()
	if player:GetAttribute("Cinematic") ~= true then
		return
	end
	local song = cinemaSong()
	if not song then
		return
	end
	if sameSong(playing, song) and (not music.IsLoaded or music.TimeLength - music.TimePosition > CINEMA_KEEP_LEFT) then
		return
	end
	cue = song
end
player:GetAttributeChangedSignal("Cinematic"):Connect(onCinematic)

local function waitFor(seconds)
	local waited = 0
	while waited < seconds and not cue do
		waited += task.wait(POLL)
	end
end

local function fadeOut(seconds)
	fadeSeconds, fadeTarget = seconds, 0
	while fade > 0 and music.IsPlaying do
		task.wait(POLL)
	end
	music:Stop()
	fade, fadeSeconds, playing = 0, FADE_SECONDS, nil
end

local function play(song)
	playing, lastSong = song, song
	for i = #round, 1, -1 do
		if sameSong(round[i], song) then
			table.remove(round, i)
		end
	end
	music.SoundId = song.id
	songVolume = songVolumeOf(song.name)
	music.TimePosition = 0
	fade, fadeTarget, fadeSeconds = 0, 1, FADE_SECONDS
	music:Play()
	local waited = 0
	while not music.IsLoaded and waited < LOAD_TIMEOUT and not cue do -- a song that never loads is skipped
		waited += task.wait(0.25)
	end
	if cue then
		return fadeOut(CINEMA_FADE_SECONDS)
	end
	local length = music.TimeLength
	if not music.IsLoaded or length <= 0 then
		music:Stop()
		playing = nil
		warn(string.format("[Music] '%s' 곡을 불러오지 못했어요 (%s). 이 게임에서 쓸 수 있는 오디오인지 확인해 주세요",
			song.name, song.id))
		return
	end
	while music.IsPlaying and music.TimePosition < length - FADE_SECONDS and not cue do
		task.wait(POLL)
	end
	fadeOut(cue and CINEMA_FADE_SECONDS or FADE_SECONDS)
end

task.spawn(function()
	waitFor(FIRST_DELAY)
	local found = findSongs()
	if #found == 0 then
		print("[Music] 배경음악 곡이 없어요: SoundService 안 GameMusic 폴더에 곡(Sound)을 넣어 주세요")
	else
		local names = {}
		for _, song in ipairs(found) do
			table.insert(names, song.name)
		end
		print(string.format("[Music] 배경음악 %d곡: %s", #found, table.concat(names, ", ")))
	end
	onCinematic()
	while true do
		local song = cue or nextSong()
		cue = nil
		if song then
			play(song)
		end
		waitFor(GAP_SECONDS)
	end
end)
