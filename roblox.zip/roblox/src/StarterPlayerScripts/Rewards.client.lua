--[[
Rewards: the "🎁 보상" button (left of 인벤토리) and its window, on this client (the server's Rewards
service decides; Net ask GetRewards, Net request ClaimReward).

- The button shows a red badge with how many rewards are waiting (player attribute RewardsReady), and
  each tab in the window its own (RewardsReadyGifts / Daily / Weekly).
- Tab "🎁 선물": today's playtime gifts (once a day; every session of the day adds up), each with its minutes, what it gives and "받기" when
  ready (a countdown until then).
- Tab "✅ 임무": today's three missions with a progress bar and "받기" when done, the bonus for all three,
  and the time until new missions.
- Tab "🔑 주간": the weekly key challenge: keys brought home this week, each milestone and "받기".
- Tab "📋 초보" (2026-10-04, "초보미션 칸을 임무 보상 탭에 넣어서 뭘 하고 뭐 받게할지 딱딱 보이게"): every beginner
  mission (Config.StarterMissions) in order, what to do and what it gives: the ones done ✔, the one now with its
  progress and "받기" when reached (Net request ClaimStarter, as the board at the top left), the ones after 🔒.
  Read off the player attributes StarterStep / StarterCount / StarterReady / StarterDone (StarterMissions service);
  its badge is StarterReady. The tabs sit in their own row under the title (four did not fit beside it).
- Tab "🎉 이벤트" (2026-10-04, "런칭 이벤트 임무도 하나 만들자", Config.LaunchEvent): the launch event's missions with
  their progress and "받기", then the all-done reward (the event's slap skin, its picture from ReplicatedStorage.SlapModels,
  and the title over the head) once every one is taken (Net request ClaimReward("Event", i) / ("EventAll")). Its badge
  RewardsReadyEvent.
- "📆 출석" (2026-10-02, design 2.9): its own button in the right column, left of the 💎 상점, with its red badge
  (RewardsReadyAttendance). It opens
  the same window without the tabs, drawn as a calendar ("출석보상은 캘린더 모양으로"): across the top
  the 7-day streak, a cell a day (today's "받기", the days before stamped ✔, the ones after locked:
  the 7th's legendary draw shows ahead as the goal); on the left this month's calendar (the dates
  checked in stamped 🦖, today framed in yellow); on the right this month's milestones (7 / 14 / 21 /
  28 days; the 28th's dino in its picture). Net push OpenRewards(tab) opens the window on
  a tab or on 출석 (the server does on joining when attendance waits). Under it the friend bonus: playing
  with a Roblox friend gives both keys (Config.FriendInvite; the Friends service pays), and "👥 초대하기"
  opens Roblox's invite (SocialService:PromptGameInvite).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local SocialService = game:GetService("SocialService")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(Shared:WaitForChild("Windows"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Fx = require(Shared:WaitForChild("Fx"))
local Lang = require(Shared:WaitForChild("Lang"))
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Coach = require(Shared:WaitForChild("Coach"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local POP_RISE, POP_SECONDS = 5, 2.2 -- the "+money" over a head after picking up the money pile
local POP_COLOR = Color3.fromRGB(255, 225, 90)
local POP_SIZE = UDim2.fromOffset(200, 40)
local COINS = { Color3.fromRGB(255, 215, 70), Color3.fromRGB(110, 190, 90) }
local BUTTON_SIZE = UDim2.fromOffset(68, 36)
local BUTTON_POS = UDim2.new(1, -12 - 68 - 10, 0, 132) -- left of 기지로 (Hud); its middle
local WINDOW_SIZE = UDim2.fromOffset(440, 440)
local ROW_HEIGHT = 58
local TAB_BADGE = 20 -- the red count on each tab's top right corner
-- (2026-10-04) the tabs in a row of their own under the title: four across (five with 🎉 이벤트)
local TAB_TOP, TAB_HEIGHT, TAB_GAP = 46, 30, 6
local TAB_TEXT = 13 -- (at most: a longer word shrinks)
local NOTE_TOP_TABS, NOTE_TOP = 82, 46 -- the line under the tabs; under the title when there are none (출석)
local LIST_TOP = 106
local ATTEND_SIZE = UDim2.fromOffset(68, 36)
local ATTEND_POS = UDim2.new(1, -12 - 68 - 10, 0, 178)
local COLOR_ATTEND = Color3.fromRGB(240, 140, 60)
-- (2026-10-02, "출석보상은 캘린더 모양으로") the attendance window as a calendar: the 7-day streak across the
-- top, this month's calendar (stamped dates) on the left, the month's milestones on the right
-- (all inside the rewards window's own 440 × 440: under the title and the line, 420 × 362)
local STREAK_TOP, STREAK_HEIGHT, STREAK_GAP = 0, 96, 5
local STREAK_ICON = 28
local CAL_TOP = STREAK_HEIGHT + 8
local CAL_WIDTH = 246
local CAL_HEAD, CAL_WEEK, CAL_ROW = 20, 14, 24
local MILESTONE_HEIGHT, MILESTONE_GAP = 42, 4
local MILESTONE_ICON = 28
local FRIEND_HEIGHT = 36
local COLOR_CELL = Color3.fromRGB(45, 50, 68)
local COLOR_CELL_DONE = Color3.fromRGB(50, 80, 60)
local COLOR_CELL_TODAY = Color3.fromRGB(255, 205, 60)
local COLOR_STAMP = Color3.fromRGB(110, 210, 120)
local COLOR_SUNDAY = Color3.fromRGB(255, 120, 120)
local COLOR_SATURDAY = Color3.fromRGB(130, 170, 255)
local COLOR_LAST_DAY = Color3.fromRGB(255, 180, 60) -- the 7th day's frame: the big one
-- the calendar's weekday heads in each language (2026-10-02: kept out of the translator: "금" (Friday) is
-- also the gold pickaxe's name, so English showed "Gold" over Fridays)
local WEEKDAYS = {
	ko = { "일", "월", "화", "수", "목", "금", "토" },
	en = { "Su", "Mo", "Tu", "We", "Th", "Fr", "Sa" },
	es = { "Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sá" },
	ro = { "Du", "Lu", "Ma", "Mi", "Jo", "Vi", "Sâ" },
	fr = { "Di", "Lu", "Ma", "Me", "Je", "Ve", "Sa" },
	de = { "So", "Mo", "Di", "Mi", "Do", "Fr", "Sa" },
	ru = { "Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб" },
	pt = { "Do", "2ª", "3ª", "4ª", "5ª", "6ª", "Sá" },
	tr = { "Pz", "Pt", "Sa", "Ça", "Pe", "Cu", "Ct" },
	pl = { "Nd", "Pn", "Wt", "Śr", "Cz", "Pt", "So" },
	ja = { "日", "月", "火", "水", "木", "金", "土" },
	id = { "Mg", "Sn", "Sl", "Rb", "Km", "Jm", "Sb" },
}
local COLOR_LUCK = Color3.fromRGB(90, 190, 110)
local ICON_SIZE = 40 -- the reward's picture at the start of each row (its key, or 💰)
local COLOR_MONEY = Color3.fromRGB(240, 190, 60)
local COLOR_BUTTON = Color3.fromRGB(230, 90, 120)
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_ROW = Color3.fromRGB(45, 50, 68)
local COLOR_TAB_ON = Color3.fromRGB(90, 110, 170)
local COLOR_TAB_OFF = Color3.fromRGB(60, 64, 80)
local COLOR_READY = Color3.fromRGB(70, 180, 90)
local COLOR_WAIT = Color3.fromRGB(110, 110, 120)
local COLOR_DONE = Color3.fromRGB(60, 70, 60)
local COLOR_BAR = Color3.fromRGB(120, 200, 255)
local COLOR_BADGE = Color3.fromRGB(235, 50, 60)
local COLOR_SOFT = Color3.fromRGB(190, 190, 200)
local COLOR_CLOSE = Color3.fromRGB(235, 70, 80)
local SORT_READY = 1000
local SORT_TAKEN = 1000
local CLAIM_ALL_SIZE = UDim2.fromOffset(92, 26)
local CLAIM_ALL_POS = UDim2.new(1, -50, 0, 12)
local CLAIM_ALL_TEXT = 12
local POPUP_WAIT = 120

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.TextWrapped = true
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 14
	b.TextColor3 = Color3.new(1, 1, 1)
	b.TextWrapped = true
	b.Text = text
	b.BackgroundColor3 = color
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 10)
	return b
end

local function clock(seconds)
	seconds = math.max(0, math.floor(seconds))
	local h, m, s = seconds // 3600, seconds % 3600 // 60, seconds % 60
	return h > 0 and string.format("%d시간 %d분", h, m) or string.format("%d:%02d", m, s)
end

local gui = Instance.new("ScreenGui")
gui.Name = "Rewards"
gui.ResetOnSpawn = false
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.Parent = player:WaitForChild("PlayerGui")

local open = button(gui, "🎁 보상", COLOR_BUTTON, BUTTON_SIZE, BUTTON_POS)
require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("SideButtons")).register(open) -- folds with the right column
open.AnchorPoint = Vector2.new(1, 0.5)
open.TextSize = 13
local badge = label(open, "", UDim2.fromOffset(22, 22), UDim2.fromOffset(-8, -8), 13) -- top left: 인벤토리 is right
badge.BackgroundTransparency = 0
badge.BackgroundColor3 = COLOR_BADGE
badge.ZIndex = 2
corner(badge, 11)
local function refreshBadge()
	-- (2026-10-04) and a beginner mission reached (the 📋 tab)
	local n = (player:GetAttribute("RewardsReady") or 0) + (player:GetAttribute("StarterReady") and 1 or 0)
	badge.Visible = n > 0
	badge.Text = tostring(n)
end
player:GetAttributeChangedSignal("RewardsReady"):Connect(refreshBadge)
player:GetAttributeChangedSignal("StarterReady"):Connect(refreshBadge)
refreshBadge()

local attend = button(gui, "📆 출석", COLOR_ATTEND, ATTEND_SIZE, ATTEND_POS)
require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("SideButtons")).register(attend)
attend.AnchorPoint = Vector2.new(1, 0.5)
attend.TextSize = 13
local attendBadge = label(attend, "", UDim2.fromOffset(18, 18), UDim2.new(1, -10, 0, -6), 11)
attendBadge.BackgroundTransparency = 0
attendBadge.BackgroundColor3 = COLOR_BADGE
attendBadge.ZIndex = 2
corner(attendBadge, 9)
local function refreshAttendBadge()
	local n = player:GetAttribute("RewardsReadyAttendance") or 0
	attendBadge.Visible = n > 0
	attendBadge.Text = tostring(n)
end
player:GetAttributeChangedSignal("RewardsReadyAttendance"):Connect(refreshAttendBadge)
refreshAttendBadge()

local window = Instance.new("Frame")
window.AnchorPoint = Vector2.new(0.5, 0.5)
window.Position = UDim2.fromScale(0.5, 0.5)
window.Size = WINDOW_SIZE
window.BackgroundColor3 = COLOR_BG
window.Visible = false
window.Parent = gui
corner(window, 14)
Windows.fit(window)
DinoPortrait.backdrop(window, "Trike")
local title = label(window, "🎁 보상", UDim2.fromOffset(120, 34), UDim2.fromOffset(14, 6), 20)
title.TextXAlignment = Enum.TextXAlignment.Left
local close = button(window, "X", COLOR_CLOSE, UDim2.fromOffset(34, 34), UDim2.new(1, -42, 0, 8))
local claimAll = button(window, "🎁 모두 받기", COLOR_READY, CLAIM_ALL_SIZE, CLAIM_ALL_POS)
claimAll.AnchorPoint = Vector2.new(1, 0)
claimAll.TextSize = CLAIM_ALL_TEXT
claimAll.Visible = false
claimAll.Activated:Connect(function()
	Net.request("ClaimReward", "All", 0)
	if player:GetAttribute("StarterReady") then
		Net.request("ClaimStarter")
	end
end)
local tabs = {}
local current = "Gifts" -- the tab shown, or "Attendance" (the 📆 출석 button's window, no tabs)
local lastTab = "Gifts" -- the 🎁 window's tab when it opens again
local TAB_NAMES = { { "Gifts", "🎁 선물" }, { "Daily", "✅ 임무" }, { "Weekly", "📅 주간" }, { "Starter", "📋 초보" },
	{ "Event", "🎉 이벤트" } } -- (2026-10-04: the launch event)
for i, t in ipairs(TAB_NAMES) do
	local n = #TAB_NAMES
	tabs[t[1]] = button(window, t[2], COLOR_TAB_OFF,
		UDim2.new(1 / n, -(28 + TAB_GAP * (n - 1)) / n, 0, TAB_HEIGHT),
		UDim2.new((i - 1) / n, 14 - (i - 1) * (28 + TAB_GAP * (n - 1)) / n + (i - 1) * TAB_GAP, 0, TAB_TOP))
	-- (2026-10-04: five tabs now) a longer word (English, Spanish) shrinks to fit, 13 at most
	tabs[t[1]].TextScaled = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = TAB_TEXT
	most.Parent = tabs[t[1]]
end
-- each tab's red badge: how many wait there (player attributes RewardsReadyGifts / Daily / Weekly; the 📋 tab's
-- StarterReady)
for name, b in pairs(tabs) do
	local tabBadge = label(b, "", UDim2.fromOffset(TAB_BADGE, TAB_BADGE), UDim2.new(1, -TAB_BADGE + 6, 0, -6), 12)
	tabBadge.BackgroundTransparency = 0
	tabBadge.BackgroundColor3 = COLOR_BADGE
	tabBadge.ZIndex = 3
	corner(tabBadge, TAB_BADGE / 2)
	local attribute = name == "Starter" and "StarterReady" or "RewardsReady" .. name
	local function show()
		local n = player:GetAttribute(attribute) or 0
		n = n == true and 1 or n
		tabBadge.Visible = n > 0
		tabBadge.Text = tostring(n)
		Coach.mark(b, n > 0 and (name == "Gifts" or name == "Daily" or name == "Weekly") and "RewardTab" or nil)
	end
	player:GetAttributeChangedSignal(attribute):Connect(show)
	show()
end
local note = label(window, "", UDim2.new(1, -28, 0, 22), UDim2.fromOffset(14, NOTE_TOP_TABS), 13)
note.TextColor3 = COLOR_SOFT
note.TextXAlignment = Enum.TextXAlignment.Left
local list = Instance.new("ScrollingFrame")
list.Position = UDim2.fromOffset(10, LIST_TOP)
list.Size = UDim2.new(1, -20, 1, -LIST_TOP - 10)
list.BackgroundTransparency = 1
list.ScrollBarThickness = 6
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = window
local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 6)
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = list

local data = nil
local fetchedAt = 0

-- the calendar view (the attendance window): built again only when the data changes
local calView = Instance.new("Frame")
calView.Position = UDim2.fromOffset(10, 70)
calView.Size = UDim2.new(1, -20, 1, -78)
calView.BackgroundTransparency = 1
calView.Visible = false
calView.Parent = window
local calBuiltFor = nil

-- the reward's picture: its best key (Shared/DinoPortrait.key), or a coin for money
local function picture(parent, icon, size)
	size = size or ICON_SIZE
	local p
	if icon == "Money" or icon == "Luck" then
		p = label(parent, icon == "Luck" and "🍀" or "💰", UDim2.fromOffset(size, size), UDim2.new(), math.floor(size * 0.6))
		p.BackgroundTransparency = 0.5
		p.BackgroundColor3 = icon == "Luck" and COLOR_LUCK or COLOR_MONEY
		corner(p, size // 2)
	elseif type(icon) == "table" and icon.slap then -- (2026-10-04) { slap = model }: a slap skin (the event's)
		local models = ReplicatedStorage:FindFirstChild("SlapModels")
		local model = models and models:FindFirstChild(icon.slap)
		if model then
			p = DinoPortrait.ofModel(model, UDim2.fromOffset(size, size))
			p.Parent = parent
		else
			p = label(parent, "👋", UDim2.fromOffset(size, size), UDim2.new(), math.floor(size * 0.6))
			p.BackgroundTransparency = 0.5
			p.BackgroundColor3 = COLOR_MONEY
			corner(p, size // 2)
		end
	elseif type(icon) == "table" then -- { dino = species Id }: this month's attendance dino
		p = DinoPortrait.new(icon.dino, UDim2.fromOffset(size, size))
		p.Parent = parent
	else
		p = DinoPortrait.key(icon, UDim2.fromOffset(size, size))
		p.Parent = parent
	end
	p.AnchorPoint = Vector2.new(0, 0.5)
	p.Position = UDim2.new(0, 8, 0.5, 0)
	return p
end

-- (2026-10-04) a beginner mission's reward picture: its best key, else a plain key (as RewardLogic.icon)
local function rewardIcon(reward)
	local best = nil
	for _, t in ipairs(Config.Keys.Types) do
		if reward.SpecialKeys and (reward.SpecialKeys[t.Id] or 0) > 0 then
			best = t.Id
		end
	end
	return best or "Normal"
end

-- one row: the reward's picture, a title, a line under it, an optional progress bar, a button on the right
local function row(order, title, sub, progress, buttonText, color, onClick, icon)
	local r = Instance.new("Frame")
	r.LayoutOrder = onClick and order - SORT_READY or order
	r.Size = UDim2.new(1, -8, 0, ROW_HEIGHT)
	r.BackgroundColor3 = COLOR_ROW
	r.Parent = list
	corner(r, 8)
	local left = 10
	if icon then
		picture(r, icon)
		left = ICON_SIZE + 16
	end
	local t = label(r, title, UDim2.new(1, -100 - left, 0, 24), UDim2.fromOffset(left, 4), 15)
	t.TextXAlignment = Enum.TextXAlignment.Left
	local s = label(r, sub, UDim2.new(1, -100 - left, 0, 18), UDim2.fromOffset(left, 28), 12)
	s.TextXAlignment = Enum.TextXAlignment.Left
	s.TextColor3 = COLOR_SOFT
	if progress then
		local back = Instance.new("Frame")
		back.Position = UDim2.new(0, left, 1, -9)
		back.Size = UDim2.new(1, -110 - left, 0, 5)
		back.BackgroundColor3 = COLOR_BG
		back.Parent = r
		corner(back, 3)
		local fill = Instance.new("Frame")
		fill.Size = UDim2.fromScale(math.clamp(progress, 0, 1), 1)
		fill.BackgroundColor3 = COLOR_BAR
		fill.Parent = back
		corner(fill, 3)
	end
	local b = button(r, buttonText, color, UDim2.fromOffset(88, 36), UDim2.new(1, -96, 0.5, -18))
	b.AutoButtonColor = onClick ~= nil
	if onClick then
		b.Activated:Connect(onClick)
		if current == "Gifts" or current == "Daily" or current == "Weekly" then
			Coach.mark(b, "RewardClaim")
		end
	end
end

local function claim(kind, index)
	Net.request("ClaimReward", kind, index)
end

local function taken(order)
	return order + SORT_TAKEN
end

-- the attendance window, calendar style (2026-10-02)
local function buildCalendar()
	for _, c in ipairs(calView:GetChildren()) do
		c:Destroy()
	end
	local a = data.Attendance
	local width = WINDOW_SIZE.X.Offset - 20
	-- the 7-day streak: a cell a day, the reward's picture and words; taken ✔, today's 받기, the rest 🔒
	local cellW = (width - STREAK_GAP * (#a.Days - 1)) / #a.Days
	for i, d in ipairs(a.Days) do
		local done = i < a.Streak or (i == a.Streak and a.StreakClaimed)
		local today = i == a.Streak and not a.StreakClaimed
		local cell = Instance.new("Frame")
		cell.Position = UDim2.fromOffset((i - 1) * (cellW + STREAK_GAP), STREAK_TOP)
		cell.Size = UDim2.fromOffset(cellW, STREAK_HEIGHT)
		cell.BackgroundColor3 = done and COLOR_CELL_DONE or COLOR_CELL
		cell.Parent = calView
		corner(cell, 8)
		if today or i == #a.Days then
			local stroke = Instance.new("UIStroke")
			stroke.Color = today and COLOR_CELL_TODAY or COLOR_LAST_DAY
			stroke.Thickness = today and 3 or 2
			stroke.Parent = cell
		end
		label(cell, string.format("%d일차", i), UDim2.new(1, 0, 0, 16), UDim2.fromOffset(0, 2), 12)
		local pic = picture(cell, d.Icon, STREAK_ICON)
		pic.AnchorPoint = Vector2.new(0.5, 0)
		pic.Position = UDim2.new(0.5, 0, 0, 18)
		local words = label(cell, d.Text, UDim2.new(1, -4, 0, 26), UDim2.fromOffset(2, 47), 10)
		words.TextScaled = true
		words.TextColor3 = COLOR_SOFT
		if done then
			local stamp = label(cell, "✔", UDim2.fromOffset(30, 30), UDim2.new(1, -30, 0, -6), 26)
			stamp.TextColor3 = COLOR_STAMP
			stamp.TextStrokeTransparency = 0.3
			label(cell, "받음", UDim2.new(1, 0, 0, 18), UDim2.new(0, 0, 1, -21), 12).TextColor3 = COLOR_STAMP
		elseif today then
			local b = button(cell, "📆 받기", COLOR_READY, UDim2.new(1, -6, 0, 20), UDim2.new(0, 3, 1, -23))
			b.TextSize = 12
			b.Activated:Connect(function()
				claim("Streak", 0)
			end)
		else
			label(cell, string.format("🔒 %d일 뒤", i - a.Streak), UDim2.new(1, 0, 0, 18), UDim2.new(0, 0, 1, -21), 11)
				.TextColor3 = COLOR_WAIT
		end
	end
	-- this month's calendar: the dates checked in get a 🦖 stamp, today a yellow frame
	local cal = a.Calendar
	local calHeight = CAL_HEAD + CAL_WEEK + 6 * CAL_ROW + 4
	local calFrame = Instance.new("Frame")
	calFrame.Position = UDim2.fromOffset(0, CAL_TOP)
	calFrame.Size = UDim2.fromOffset(CAL_WIDTH, calHeight)
	calFrame.BackgroundColor3 = COLOR_ROW
	calFrame.Parent = calView
	corner(calFrame, 10)
	local head = label(calFrame, string.format("📅 %d년 %d월 · 출석 %d일", cal.Year, cal.Month, a.MonthDays),
		UDim2.new(1, -12, 0, CAL_HEAD), UDim2.fromOffset(6, 1), 13)
	head.TextXAlignment = Enum.TextXAlignment.Left
	local colW = (CAL_WIDTH - 8) / 7
	for w = 1, 7 do
		local names = WEEKDAYS[Lang.code(player)] or WEEKDAYS.en
		local l = label(calFrame, names[w], UDim2.fromOffset(colW, CAL_WEEK), UDim2.fromOffset(4 + (w - 1) * colW, CAL_HEAD), 11)
		l:SetAttribute("KeepText", true) -- (already in the player's language)
		l.TextColor3 = w == 1 and COLOR_SUNDAY or w == 7 and COLOR_SATURDAY or COLOR_SOFT
	end
	for date = 1, cal.Length do
		local slot = cal.FirstWeekday + date - 1
		local col, rowN = slot % 7, slot // 7
		local cell = Instance.new("Frame")
		cell.Position = UDim2.fromOffset(4 + col * colW + 1, CAL_HEAD + CAL_WEEK + rowN * CAL_ROW + 1)
		cell.Size = UDim2.fromOffset(colW - 2, CAL_ROW - 2)
		cell.BackgroundColor3 = COLOR_BG
		cell.BackgroundTransparency = date > cal.Today and 0.6 or 0
		cell.Parent = calFrame
		corner(cell, 5)
		if date == cal.Today then
			local stroke = Instance.new("UIStroke")
			stroke.Color = COLOR_CELL_TODAY
			stroke.Thickness = 2
			stroke.Parent = cell
		end
		local num = label(cell, tostring(date), UDim2.fromOffset(16, 12), UDim2.fromOffset(2, 1), 10)
		num.TextXAlignment = Enum.TextXAlignment.Left
		num.TextColor3 = col == 0 and COLOR_SUNDAY or col == 6 and COLOR_SATURDAY or COLOR_SOFT
		if a.Log[tostring(date)] then
			local stamp = label(cell, "🦖", UDim2.fromOffset(18, 18), UDim2.new(1, -18, 1, -18), 14)
			stamp.TextColor3 = COLOR_STAMP
		end
	end
	-- the month's milestones, beside the calendar
	local mx = CAL_WIDTH + 8
	local mw = width - mx
	for i, m in ipairs(a.Monthly) do
		local card = Instance.new("Frame")
		card.Position = UDim2.fromOffset(mx, CAL_TOP + (i - 1) * (MILESTONE_HEIGHT + MILESTONE_GAP))
		card.Size = UDim2.fromOffset(mw, MILESTONE_HEIGHT)
		card.BackgroundColor3 = m.Claimed and COLOR_CELL_DONE or COLOR_ROW
		card.Parent = calView
		corner(card, 8)
		local pic = picture(card, m.Icon == "Dino" and { dino = a.MonthDino } or m.Icon, MILESTONE_ICON)
		pic.Position = UDim2.new(0, 4, 0.5, 0)
		local left = MILESTONE_ICON + 8
		local title = label(card, string.format("%d일 출석", m.Days), UDim2.new(1, -left - 58, 0, 16), UDim2.fromOffset(left, 3), 12)
		title.TextXAlignment = Enum.TextXAlignment.Left
		title.TextScaled = true
		local words = label(card, m.Text, UDim2.new(1, -left - 58, 0, 20), UDim2.fromOffset(left, 19), 10)
		words.TextXAlignment = Enum.TextXAlignment.Left
		words.TextColor3 = COLOR_SOFT
		words.TextScaled = true
		if m.Claimed then
			label(card, "받음 ✔", UDim2.fromOffset(54, 20), UDim2.new(1, -56, 0.5, -10), 12).TextColor3 = COLOR_STAMP
		elseif a.MonthDays >= m.Days then
			local b = button(card, "🗓️ 받기", COLOR_READY, UDim2.fromOffset(54, 26), UDim2.new(1, -56, 0.5, -13))
			b.TextSize = 11
			b.Activated:Connect(function()
				claim("Monthly", i)
			end)
		else
			label(card, string.format("⏳ %d/%d", a.MonthDays, m.Days), UDim2.fromOffset(54, 20), UDim2.new(1, -56, 0.5, -10), 12)
				.TextColor3 = COLOR_WAIT
		end
	end
	-- the friend bonus (Friends service) and Roblox's invite, along the bottom
	local f = Config.FriendInvite
	local friend = Instance.new("Frame")
	friend.Position = UDim2.fromOffset(0, CAL_TOP + calHeight + 6) -- (under the calendar)
	friend.Size = UDim2.fromOffset(width, FRIEND_HEIGHT)
	friend.BackgroundColor3 = COLOR_ROW
	friend.Parent = calView
	corner(friend, 8)
	local fl = label(friend, string.format("👥 친구와 같은 서버에서 %d분이면 둘 다 🔑 %d개! (오늘 %d/%d명)", f.MinutesTogether,
		f.Keys, a.FriendsToday or 0, f.PerDay), UDim2.new(1, -116, 1, 0), UDim2.fromOffset(8, 0), 12)
	fl.TextXAlignment = Enum.TextXAlignment.Left
	local invite = button(friend, "👥 초대하기", COLOR_BUTTON, UDim2.fromOffset(100, 28), UDim2.new(1, -104, 0.5, -14))
	invite.TextSize = 13
	invite.Activated:Connect(function()
		local ok, can = pcall(SocialService.CanSendGameInviteAsync, SocialService, player)
		if ok and can then
			pcall(SocialService.PromptGameInvite, SocialService, player)
		end
	end)
end

local function rebuild()
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
	title.Text = current == "Attendance" and "📆 출석" or "🎁 보상"
	claimAll.Visible = current ~= "Attendance"
		and ((player:GetAttribute("RewardsReady") or 0) > 0 or player:GetAttribute("StarterReady") == true)
	Windows.cover(window, current == "Attendance" and "Big" or nil)
	for name, b in pairs(tabs) do
		b.BackgroundColor3 = name == current and COLOR_TAB_ON or COLOR_TAB_OFF
		b.Visible = current ~= "Attendance"
	end
	if not data then
		return
	end
	local elapsed = os.clock() - fetchedAt
	local attendance = current == "Attendance"
	list.Visible, calView.Visible = not attendance, attendance
	note.Position = UDim2.fromOffset(14, attendance and NOTE_TOP or NOTE_TOP_TABS)
	if attendance then
		local a = data.Attendance
		note.Text = string.format("📆 연속 %d일째 · 이번 달 %d일 출석 · ⏰ 내일 출석까지 %s", a.Streak, a.MonthDays,
			clock(data.DayEndsIn - elapsed))
		if calBuiltFor ~= data then -- (the countdown above ticks; the calendar only when something changed)
			calBuiltFor = data
			buildCalendar()
		end
	elseif current == "Starter" then
		-- (2026-10-04) every beginner mission: done ✔, now (progress, 받기), after 🔒
		local missions = Config.StarterMissions.Missions
		local allDone = player:GetAttribute("StarterDone") == true
		local step = player:GetAttribute("StarterStep")
		local count = player:GetAttribute("StarterCount") or 0
		local ready = player:GetAttribute("StarterReady") == true
		-- (2026-10-04) missions done on the board's older order, further down: ✔ too (StarterSkip, their names)
		local skipped, skips = {}, 0
		for name in string.gmatch(player:GetAttribute("StarterSkip") or "", "[^,]+") do
			skipped[name], skips = true, skips + 1
		end
		local main = 0
		for _, m in ipairs(missions) do
			main += m.Comeback and 0 or 1
		end
		local now = step and missions[step]
		local upTo = now and now.Comeback and player:GetAttribute("StarterMain") or step
		local done = allDone and main or (upTo and upTo - 1 + skips or 0)
		note.Text = allDone and "🎉 초보 미션을 모두 끝냈어요!"
			or string.format("📋 초보 미션 %d장 %d/%d · 하나씩 차례로 열려요",
				Formulas.starterChapter(math.min(done + 1, main), #missions))
		for i, m in ipairs(missions) do
			if m.Comeback and i ~= step then
				continue
			end
			local title = m.Text
			local gives = "🎁 " .. Formulas.starterRewardText(m.Reward)
			local icon = m.Reward.LuckMinutes and "Luck" or m.Reward.GuaranteedRarity and "Normal" or rewardIcon(m.Reward)
			if not m.Comeback and (allDone or (upTo and i < upTo) or skipped[m.Id or m.Goal or m.Event]) then
				row(i, title, gives, nil, "받음 ✔", COLOR_DONE, nil, icon)
			elseif i == step and not allDone then
				local optional = m.Optional and " · " .. "(선택)" or "" -- (one that needs others: 넘기기 on the board)
				local order = m.Comeback and 0 or i
				if ready then
					row(order, title, gives .. optional, 1, "🎁 받기", COLOR_READY, function()
						Net.request("ClaimStarter")
					end, icon)
				else
					row(order, title, string.format("%s · %d/%d%s", gives, math.min(count, m.Target), m.Target, optional),
						math.min(count, m.Target) / m.Target, "⏳ 진행 중", COLOR_WAIT, nil, icon)
				end
			else
				row(i, title, gives, nil, "🔒", COLOR_DONE, nil, icon)
			end
		end
	elseif current == "Event" then
		-- (2026-10-04) 🎉 the launch event: each mission (n/N, 받기), then the all-done reward
		local e = data.Event
		if not e then
			return
		end
		note.Text = e.Open and "🎉 런칭 이벤트 · 임무를 모두 끝내면 전용 스킨과 칭호!"
			or "🎉 런칭 이벤트가 끝났어요 · 끝낸 임무 보상은 받을 수 있어요"
		local allTaken = true
		for i, m in ipairs(e.Missions) do
			allTaken = allTaken and m.Claimed
			local sub = string.format("%d / %d · %s", math.min(m.Progress, m.Target), m.Target, m.Text)
			if m.Claimed then
				row(taken(i), m.Name, sub, 1, "받음 ✔", COLOR_DONE, nil, m.Icon)
			elseif m.Progress >= m.Target then
				row(i, m.Name, sub, 1, "🎉 받기", COLOR_READY, function()
					claim("Event", i)
				end, m.Icon)
			else
				row(i, m.Name, sub, m.Progress / m.Target, "⏳ 진행 중", COLOR_WAIT, nil, m.Icon)
			end
		end
		local title = string.format("🏆 모두 끝내면: 👋 %s", e.SkinName or "")
		local sub = string.format("칭호 %s · %s", e.Title or "", e.AllText or "")
		local icon = e.SkinModel and { slap = e.SkinModel } or "Gold"
		if e.AllClaimed then
			row(taken(100), title, sub, nil, "받음 ✔", COLOR_DONE, nil, icon)
		elseif e.AllReady then
			row(100, title, sub, nil, "🏆 받기", COLOR_READY, function()
				claim("EventAll", 0)
			end, icon)
		else
			row(100, title, sub, nil, allTaken and "⏳" or "🔒 모두 받으면", COLOR_WAIT, nil, icon)
		end
	elseif current == "Gifts" then
		local played = data.Played + elapsed
		note.Text = string.format("⏰ 오늘 플레이 %s · 하루 한 번씩, 자정에 새로 열려요", clock(played))
		local ready = 0
		for _, g in ipairs(data.Gifts) do
			if not g.Taken and g.Minutes * 60 - played <= 0 then
				ready += 1
			end
		end
		if ready >= 2 then
			row(0, string.format("🎁 받을 선물 %d개", ready), "한 번에 다 받아요", nil, "🎁 모두 받기", COLOR_READY, function()
				claim("PlaytimeAll", 0)
			end, "Gold")
		end
		for i, g in ipairs(data.Gifts) do
			local left = g.Minutes * 60 - played
			if g.Taken then
				row(taken(i), string.format("🎁 %d분 선물", g.Minutes), g.Text, nil, "받음 ✔", COLOR_DONE, nil, g.Icon)
			elseif left <= 0 then
				row(i, string.format("🎁 %d분 선물", g.Minutes), g.Text, nil, "🎁 받기", COLOR_READY, function()
					claim("Playtime", i)
				end, g.Icon)
			else
				row(i, string.format("🎁 %d분 선물", g.Minutes), g.Text, 1 - left / (g.Minutes * 60), "⏳ " .. clock(left), COLOR_WAIT,
					nil, g.Icon)
			end
		end
	elseif current == "Daily" then
		note.Text = string.format("⏰ 새 임무까지 %s · 임무마다 %s", clock(data.DayEndsIn - elapsed), data.MissionText)
		local allClaimed = #data.Missions > 0
		for i, m in ipairs(data.Missions) do
			allClaimed = allClaimed and m.Claimed
			local sub = string.format("%d / %d · %s", m.Progress, m.Target, data.MissionText)
			if m.Claimed then
				row(taken(i), m.Name, sub, 1, "받음 ✔", COLOR_DONE, nil, data.MissionIcon)
			elseif m.Progress >= m.Target then
				row(i, m.Name, sub, 1, "✅ 받기", COLOR_READY, function()
					claim("Daily", i)
				end, data.MissionIcon)
			else
				row(i, m.Name, sub, m.Progress / m.Target, "⏳ 진행 중", COLOR_WAIT, nil, data.MissionIcon)
			end
		end
		local bonus = "🏆 오늘 임무 모두 완료 보너스"
		if data.AllClaimed then
			row(taken(10), bonus, data.AllText, nil, "받음 ✔", COLOR_DONE, nil, data.AllIcon)
		elseif allClaimed then
			row(10, bonus, data.AllText, nil, "🏆 받기", COLOR_READY, function()
				claim("DailyAll", 0)
			end, data.AllIcon)
		else
			row(10, bonus, data.AllText, nil, "🔒 모두 받으면", COLOR_WAIT, nil, data.AllIcon)
		end
	else
		note.Text = string.format("🏠 이번 주 집에 가져온 선물상자 %d개 · ⏰ 새 주까지 %s", data.WeeklyKeys,
			clock(data.WeekEndsIn - elapsed))
		for i, m in ipairs(data.Milestones) do
			local title = string.format("🎁 선물상자 %d개 가져오기", m.Keys)
			local progress = math.min(1, data.WeeklyKeys / m.Keys)
			if m.Claimed then
				row(taken(i), title, m.Text, 1, "받음 ✔", COLOR_DONE, nil, m.Icon)
			elseif data.WeeklyKeys >= m.Keys then
				row(i, title, m.Text, 1, "🔑 받기", COLOR_READY, function()
					claim("Weekly", i)
				end, m.Icon)
			else
				row(i, title, m.Text, progress, string.format("⏳ %d/%d", data.WeeklyKeys, m.Keys), COLOR_WAIT, nil, m.Icon)
			end
		end
		-- the other weekly challenges: one row each, its next step (n/N), filled as the week goes
		for i, c in ipairs(data.Challenges or {}) do
			local title = string.format("📅 %s (%d/%d단계)", c.Name, c.Stage, c.Stages)
			local progress = math.min(1, c.Progress / c.Target)
			if c.Done then
				row(taken(100 + i), title, c.Text, 1, "받음 ✔", COLOR_DONE, nil, c.Icon)
			elseif c.Ready then
				row(100 + i, title, c.Text, 1, "📅 받기", COLOR_READY, function()
					claim("WeeklyChallenge", c.Kind)
				end, c.Icon)
			else
				row(100 + i, title, c.Text, progress, string.format("⏳ %d/%d", c.Progress, c.Target), COLOR_WAIT, nil, c.Icon)
			end
		end
	end
end

local function reload()
	local answer = Net.ask("GetRewards")
	if answer then
		data = answer
		fetchedAt = os.clock()
	end
	rebuild()
end

-- the 🎁 button opens the tabs, the 📆 button the attendance; the same button again closes it
local function toggle(attendance)
	local wanted = attendance and "Attendance" or lastTab
	if window.Visible and (current == "Attendance") == attendance then
		window.Visible = false
		return
	end
	current = wanted
	window.Visible = true
	reload()
end
open.Activated:Connect(function()
	toggle(false)
end)
attend.Activated:Connect(function()
	toggle(true)
end)
close.Activated:Connect(function()
	window.Visible = false
end)
for name, b in pairs(tabs) do
	b.Activated:Connect(function()
		current, lastTab = name, name
		rebuild()
	end)
end
-- (2026-10-04) the 📋 tab follows the beginner missions as they move
for _, name in ipairs({ "StarterStep", "StarterCount", "StarterReady", "StarterDone", "StarterSkip" }) do
	player:GetAttributeChangedSignal(name):Connect(function()
		if window.Visible and current == "Starter" then
			rebuild()
		end
	end)
end
player:GetAttributeChangedSignal("RewardsVersion"):Connect(function()
	if window.Visible then
		reload()
	end
end)
-- (2026-10-02) the server opens the window on a tab (the attendance on joining)
Net.onPush("OpenRewards", function(tab)
	while tab == "Attendance" and (player:GetAttribute("CocoIntro") or player:GetAttribute("FirstFight")
		or (player:GetAttribute("DefenseLevel") or 1) < 2 or player:GetAttribute("FreshStart")) do
		task.wait(0.5)
	end
	local waited = os.clock()
	while tab == "Attendance" and (Windows.anyOpen() or player:GetAttribute("LaunchGiftUp")
		or player:GetAttribute("EventAdUp")) and os.clock() - waited < POPUP_WAIT do
		task.wait(0.5)
	end
	if tabs[tab] or tab == "Attendance" then
		current = tab
		lastTab = tabs[tab] and tab or lastTab
		window.Visible = true
		reload()
	end
end)
-- (2026-10-04) another screen script opens it on a tab (the 🎉 event's pop-up, EventAd): a local player attribute
player:GetAttributeChangedSignal("OpenRewardsTab"):Connect(function()
	local tab = player:GetAttribute("OpenRewardsTab")
	if tab and tabs[tab] then
		player:SetAttribute("OpenRewardsTab", nil)
		current, lastTab = tab, tab
		window.Visible = true
		reload()
	end
end)
local sinceTick = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("Rewards", function(dt) -- the countdowns
	sinceTick += dt
	if window.Visible and sinceTick >= 1 then
		sinceTick = 0
		rebuild()
	end
end))
Windows.register(window)

-- someone picked up their pile of money from time away (Net push MoneyPop): "+12,345원" rising over
-- their head and fading, coins and a cash sound
Net.onPush("MoneyPop", function(userId, amount)
	local who = Players:GetPlayerByUserId(userId)
	local head = who and who.Character and who.Character:FindFirstChild("Head")
	if not head then
		return
	end
	Sfx.play("Deposit", head.Position)
	Fx.burst(head.Position, COINS, 30, 14, 0.6, 0.8)
	local gui = Instance.new("BillboardGui")
	gui.Size = POP_SIZE
	gui.AlwaysOnTop = true
	gui.MaxDistance = 150
	gui.StudsOffsetWorldSpace = Vector3.new(0, 2.5, 0)
	gui.Adornee = head
	local text = label(gui, "+" .. Formulas.shortNumber(amount) .. "원 💰", UDim2.fromScale(1, 1), UDim2.new(), 26)
	text.TextColor3 = POP_COLOR
	text.TextStrokeTransparency = 0.2
	gui.Parent = player:WaitForChild("PlayerGui")
	local start = os.clock()
	local connection
	connection = RunService.RenderStepped:Connect(FrameMeter.wrap("Rewards", function()
		local t = (os.clock() - start) / POP_SECONDS
		if t >= 1 or not gui.Parent then
			connection:Disconnect()
			gui:Destroy()
			return
		end
		gui.StudsOffsetWorldSpace = Vector3.new(0, 2.5 + POP_RISE * t, 0)
		text.TextTransparency = math.max(0, t * 2 - 1)
		text.TextStrokeTransparency = 0.2 + 0.8 * math.max(0, t * 2 - 1)
	end))
end)
