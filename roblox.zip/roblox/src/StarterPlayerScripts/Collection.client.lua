--[[
Collection: the 도감 window (design 2.8 농장 등록, 9 UI 화면 "농장·도감"). Display only.

A "도감" button in the top bar opens it. It shows every species as a picture first (2026-10-03: the dinos at the top, the rest below; in color once collected,
a light grey shadow before, with how many of its rarities are in), then how many species × rarity pairs
the player ever owned, the collection rewards reached and the next one, every theme's species collected (a
complete theme unlocks its slap skin), and every lasting bonus from the farm, the collection and
rebirths. A species keys can't give yet at my level shows "🔒 LV 25" (the level it opens at) in
place of its rarity count, a variant (변종) not collected yet "🔑 은 열쇠+" (only better keys give
them), and a line says how many keys give now, what opens next and the variants (2026-10-01).
Its data comes from the server (Net ask GetCollection) each time it opens or the
collection or farm changes (player attributes CollectionCount, FarmCount).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Windows"))
local TopBar = require(Shared:WaitForChild("TopBar"))
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local Formulas = require(Shared:WaitForChild("Formulas"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local PANEL_SIZE = UDim2.fromOffset(400, 480)
local CARD_SIZE = UDim2.fromOffset(84, 112) -- a species in the collection grid
local CARD_PICTURE = 68
local COLOR_CARD = Color3.fromRGB(45, 50, 68) -- collected: the dino in color
local COLOR_CARD_HIDDEN = Color3.fromRGB(205, 205, 210) -- not yet: a light grey card with a grey shadow
local COLOR_HIDDEN_TEXT = Color3.fromRGB(110, 110, 120)
local COLOR_LOCKED = Color3.fromRGB(150, 90, 40) -- "🔒 LV …" on a species keys don't give yet
local ROW_HEIGHT = 22
local BAR_HEIGHT = 12
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_BUTTON = Color3.fromRGB(70, 170, 150)
local COLOR_CLOSE = Color3.fromRGB(235, 70, 80)
local COLOR_DONE = Color3.fromRGB(120, 220, 120)
local COLOR_TODO = Color3.fromRGB(170, 170, 180)
local COLOR_HEAD = Color3.fromRGB(255, 205, 60)
local COLOR_BAR_BACK = Color3.fromRGB(50, 54, 70)
local COLOR_BAR = Color3.fromRGB(70, 170, 150)
local DEX_GAUGE_HEIGHT = 5
local DEX_GAUGE_INSET = 4
local DEX_GAUGE_BACK = Color3.fromRGB(30, 70, 60)
local DEX_GAUGE_FILL = Color3.fromRGB(255, 215, 90)
local DETAIL_HEIGHT = 118
local DETAIL_PICTURE = 104
local COLOR_DETAIL = Color3.fromRGB(38, 44, 64)
local COLOR_DETAIL_EDGE = Color3.fromRGB(255, 205, 60)

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextSize = textSize
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function percent(x)
	return string.format("+%s%%", (string.format("%.1f", x * 100):gsub("%.0$", "")))
end

local gui = Instance.new("ScreenGui")
gui.Name = "Collection"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local openButton = TopBar.button("📖 도감", 4, COLOR_BUTTON)
do
	local back = Instance.new("Frame")
	back.Name = "DexGauge"
	back.AnchorPoint = Vector2.new(0.5, 1)
	back.Position = UDim2.new(0.5, 0, 1, -DEX_GAUGE_INSET)
	back.Size = UDim2.new(1, -DEX_GAUGE_INSET * 2, 0, DEX_GAUGE_HEIGHT)
	back.BackgroundColor3 = DEX_GAUGE_BACK
	back.BorderSizePixel = 0
	back.Parent = openButton
	local fill = Instance.new("Frame")
	fill.BackgroundColor3 = DEX_GAUGE_FILL
	fill.BorderSizePixel = 0
	fill.Parent = back
	corner(back, DEX_GAUGE_HEIGHT)
	corner(fill, DEX_GAUGE_HEIGHT)
	local function refreshGauge()
		local n, total = player:GetAttribute("DexSpecies") or 0, Formulas.dexSpeciesTotal()
		fill.Size = UDim2.fromScale(math.clamp(n / total, 0, 1), 1)
		openButton.Text = string.format("📖 도감 %d/%d", n, total)
	end
	player:GetAttributeChangedSignal("DexSpecies"):Connect(refreshGauge)
	refreshGauge()
end

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(1, 0)
panel.Position = UDim2.new(1, -8, 0, 8)
panel.Size = PANEL_SIZE
panel.BackgroundColor3 = COLOR_BG
panel.Visible = false
panel.Parent = gui
corner(panel, 14)
Windows.fit(panel) -- smaller on small screens, clear of the HUD

local title = label(panel, "도감", UDim2.new(1, -60, 0, 34), UDim2.fromOffset(14, 6), 20)
local close = Instance.new("TextButton")
close.Size = UDim2.fromOffset(34, 34)
close.Position = UDim2.new(1, -42, 0, 8)
close.BackgroundColor3 = COLOR_CLOSE
close.Font = FONT
close.TextSize = 18
close.TextColor3 = Color3.new(1, 1, 1)
close.Text = "X"
close.Parent = panel
corner(close, 10)

local nextText = label(panel, "", UDim2.new(1, -28, 0, 18), UDim2.fromOffset(14, 42), 13, COLOR_HEAD)
local barBack = Instance.new("Frame")
barBack.Position = UDim2.fromOffset(14, 64)
barBack.Size = UDim2.new(1, -28, 0, BAR_HEIGHT)
barBack.BackgroundColor3 = COLOR_BAR_BACK
barBack.Parent = panel
corner(barBack, 6)
local bar = Instance.new("Frame")
bar.Size = UDim2.fromScale(0, 1)
bar.BackgroundColor3 = COLOR_BAR
bar.Parent = barBack
corner(bar, 6)

local list = Instance.new("ScrollingFrame")
list.Position = UDim2.fromOffset(10, 84)
list.Size = UDim2.new(1, -20, 1, -94)
list.BackgroundTransparency = 1
list.ScrollBarThickness = 6
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = panel
local layout = Instance.new("UIListLayout")
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = list

local detail = Instance.new("TextButton")
detail.AutoButtonColor = false
detail.Text = ""
detail.AnchorPoint = Vector2.new(0.5, 1)
detail.Position = UDim2.new(0.5, 0, 1, -8)
detail.Size = UDim2.new(1, -20, 0, DETAIL_HEIGHT)
detail.BackgroundColor3 = COLOR_DETAIL
detail.Visible = false
detail.ZIndex = 5
detail.Parent = panel
corner(detail, 12)
do
	local edge = Instance.new("UIStroke")
	edge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	edge.Color = COLOR_DETAIL_EDGE
	edge.Thickness = 2
	edge.Parent = detail
end
local detailPicture = nil
local detailName = label(detail, "", UDim2.new(1, -(DETAIL_PICTURE + 44), 0, 24), UDim2.fromOffset(DETAIL_PICTURE + 10, 6), 18,
	COLOR_HEAD)
local detailHow = label(detail, "", UDim2.new(1, -(DETAIL_PICTURE + 16), 0, 44), UDim2.fromOffset(DETAIL_PICTURE + 10, 32), 15)
local detailNext = label(detail, "", UDim2.new(1, -(DETAIL_PICTURE + 16), 0, 36), UDim2.fromOffset(DETAIL_PICTURE + 10, 78), 13,
	COLOR_TODO)
for _, l in ipairs({ detailName, detailHow, detailNext }) do
	l.ZIndex = 6
	l.TextWrapped = true
	l.TextScaled = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = l.TextSize
	most.Parent = l
end
local detailClose = Instance.new("TextButton")
detailClose.Size = UDim2.fromOffset(28, 28)
detailClose.Position = UDim2.new(1, -32, 0, 4)
detailClose.BackgroundColor3 = COLOR_CLOSE
detailClose.Font = FONT
detailClose.TextSize = 16
detailClose.TextColor3 = Color3.new(1, 1, 1)
detailClose.Text = "X"
detailClose.ZIndex = 7
detailClose.Parent = detail
corner(detailClose, 8)

local function hideDetail()
	detail.Visible = false
	if detailPicture then
		detailPicture:Destroy()
		detailPicture = nil
	end
end
detailClose.Activated:Connect(hideDetail)
detail.Activated:Connect(hideDetail)

local function howToGet(species, have, level, rebirths)
	if have > 0 then
		return string.format("✅ 모은 등급 %d/%d", have, #Config.Rarities), "🎰 뽑기에서 더 높은 등급도 나와요"
	end
	if species.Theme == "Variant" and species.MinRebirths then
		return string.format("🎰 %s환생 %d번 + 🔑 %s 이상으로 뽑으면 나와요", Formulas.rebirthMark(species.MinRebirths),
			species.MinRebirths, Formulas.keyType(species.MinKey).Name), "🔄 디펜스 최대 레벨에서 환생해요"
	elseif species.Theme == "Variant" then
		return string.format("🎰 🔑 %s 이상으로 뽑을 때만 나와요", Formulas.keyType(Formulas.variantMinKey(species)).Name),
			"🔑 열쇠 가판대의 '교환' 탭에서 좋은 열쇠를 만들어요"
	elseif species.UnlockLevel <= level then
		return "🎰 지금 뽑기에서 나와요!", "🔑 열쇠로 뽑아 도감을 채워요"
	elseif species.UnlockRebirths then
		return string.format("🎰 %s환생 %d번부터 뽑기에서 나와요 (지금 %d번)", Formulas.rebirthMark(species.UnlockRebirths),
			species.UnlockRebirths, rebirths),
			"🔄 디펜스 최대 레벨에서 환생해요"
	end
	return string.format("🎰 %s부터 뽑기에서 나와요 (지금 %s)", Formulas.levelText(species.UnlockLevel),
		Formulas.levelText(level)), "⚔️ 보스 웨이브를 깨면 디펜스 레벨이 올라요"
end

local function explain(species, have)
	hideDetail()
	local level = player:GetAttribute("DefenseLevel") or 1
	local how, nextStep = howToGet(species, have, level, player:GetAttribute("Rebirths") or 0)
	detailPicture = DinoPortrait.new(species.Id, UDim2.fromOffset(DETAIL_PICTURE, DETAIL_PICTURE),
		{ hidden = have == 0, spin = true })
	detailPicture.Position = UDim2.fromOffset(6, (DETAIL_HEIGHT - DETAIL_PICTURE) / 2)
	detailPicture.ZIndex = 6
	detailPicture.Parent = detail
	detailName.Text = have > 0 and species.Name or "???"
	detailHow.Text = how
	detailNext.Text = nextStep
	detail.Visible = true
end

local order = 0
local function row(text, color, size)
	order += 1
	local l = label(list, text, UDim2.new(1, -8, 0, ROW_HEIGHT), UDim2.new(), size or 13, color)
	l.LayoutOrder = order
	l.TextWrapped = true
	return l
end

local function rebuild(data)
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("TextLabel") then
			c:Destroy()
		end
	end
	order = 0
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("Frame") then
			c:Destroy()
		end
	end
	local total = Formulas.collectionTotal()
	local count = #data.Collection
	title.Text = string.format("도감 %d / %d", count, total)
	row(string.format("👑 공룡 %d종을 다 모으면 공룡 왕! · 📖 지금 %d종", Formulas.dexSpeciesTotal(),
		player:GetAttribute("DexSpecies") or 0), COLOR_HEAD, 15)
	row("🔄 환생할 때마다 새 공룡이 열려요 · 🎰 뽑고 🎁 상자를 모아요", COLOR_TODO, 12)

	local rewards = Config.Farm.CollectionRewards
	local function rewardText(r)
		if r.Reward == "PlacementSlots" then
			return string.format("➕ 공룡 자리 +%d", r.Amount)
		end
		return string.format("%s %s", Config.Farm.BuffNames[r.Reward], percent(r.Amount))
	end
	-- (2026-10-02) the next of both lists: the lasting buffs (Farm.CollectionRewards) and the milestones (Config.Collection)
	local nextReward = nil
	for _, r in ipairs(rewards) do
		if count < r.Count and (not nextReward or r.Count < nextReward.Count) then
			nextReward = { Count = r.Count, Text = rewardText(r) }
		end
	end
	for _, m in ipairs(Config.Collection.Milestones) do
		local need = Formulas.milestoneCount(m)
		if count < need and (not nextReward or need < nextReward.Count) then
			nextReward = { Count = need, Text = string.format("%s · %s", m.Title, Formulas.rewardShortText(m.Reward)) }
		end
	end
	if nextReward then
		nextText.Text = string.format("다음 보상: %d개 → %s (%d개 남음)", nextReward.Count, nextReward.Text,
			nextReward.Count - count)
		bar.Size = UDim2.fromScale(math.clamp(count / nextReward.Count, 0, 1), 1)
	else
		nextText.Text = "🎉 도감 보상을 모두 받았어요!"
		bar.Size = UDim2.fromScale(1, 1)
	end

	-- every species: in color once any of its rarities was collected, a light grey shadow before
	local rarityCount, bestRarity = {}, {}
	for _, key in ipairs(data.Collection) do
		local speciesId, rarityId = string.match(key, "^([^/]+)/(.+)$")
		if speciesId then
			rarityCount[speciesId] = (rarityCount[speciesId] or 0) + 1
			local best = bestRarity[speciesId]
			if not best or (Formulas.rarity(rarityId .. "#") or 0) > (Formulas.rarity(best .. "#") or 0) then
				bestRarity[speciesId] = rarityId
			end
		end
	end
	local level = player:GetAttribute("DefenseLevel") or 1
	-- (2026-10-03, "도감에서 공룡 파트가 먼저 나오게 해 … 도감에서 원하는건 공룡보는게 먼저잖아") the dinos first,
	-- then the title, the milestones, the rows, when rarities open and the rest
	-- (2026-10-04, "특별 등급으로 도감에 안 뜨냐 웰컴렉스") the gift-only dinos (⭐ 특별, Config.GiftSpecies): like the
	-- rebirth ones, not drawn and not in the count, shown in color once had; at the very top
	if #(Config.GiftSpecies or {}) > 0 then
		row("⭐ 특별 공룡 (선물·🦴 보스 뼈로만 · 도감 수에는 안 들어가요)", COLOR_HEAD, 14)
		order += 1
		local specialFrame = Instance.new("Frame")
		specialFrame.LayoutOrder = order
		specialFrame.BackgroundTransparency = 1
		specialFrame.Size = UDim2.new(1, -8, 0, 0)
		specialFrame.AutomaticSize = Enum.AutomaticSize.Y
		specialFrame.Parent = list
		local specialGrid = Instance.new("UIGridLayout")
		specialGrid.CellSize = CARD_SIZE
		specialGrid.CellPadding = UDim2.fromOffset(6, 6)
		specialGrid.SortOrder = Enum.SortOrder.LayoutOrder
		specialGrid.Parent = specialFrame
		for i, species in ipairs(Config.GiftSpecies) do
			local had = data.SpecialOwned and data.SpecialOwned[species.Id] == true
			local card = Instance.new("Frame")
			card.LayoutOrder = i
			card.BackgroundColor3 = had and COLOR_CARD or COLOR_CARD_HIDDEN
			card.Parent = specialFrame
			corner(card, 10)
			if had then
				DinoPortrait.border(card, "Special")
			end
			local picture = DinoPortrait.new(species.Id, UDim2.fromOffset(CARD_PICTURE, CARD_PICTURE), { hidden = not had })
			picture.AnchorPoint = Vector2.new(0.5, 0)
			picture.Position = UDim2.new(0.5, 0, 0, 2)
			picture.Parent = card
			local name = label(card, had and species.Name or "???", UDim2.new(1, -4, 0, 16),
				UDim2.fromOffset(2, CARD_PICTURE + 2), 11, had and Color3.new(1, 1, 1) or COLOR_HIDDEN_TEXT)
			name.TextXAlignment = Enum.TextXAlignment.Center
			name.TextScaled = true
			-- (2026-10-04) a 🦴 bone dino (the night boss's ②): the bones toward the next one
			local bones = species.BossKind and data.Bones and tonumber(data.Bones[species.BossKind]) or 0
			local note = label(card, had and "✅ 획득" or species.BossKind and string.format("🦴 뼈 %d/%d", bones,
				Config.Zombies.Boss.BonesForDino) or "🎉 출시 선물", UDim2.new(1, -4, 0, 14),
				UDim2.fromOffset(2, CARD_PICTURE + 18), 10, had and COLOR_DONE or COLOR_LOCKED)
			note.TextXAlignment = Enum.TextXAlignment.Center
			note.TextScaled = true
		end
		row("", nil)
	end
	row("공룡 (🔒 = 그 환생·레벨부터 뽑기에 나와요 · 🔑 = 좋은 열쇠에서만 · 👆 누르면 설명)", COLOR_HEAD, 14)
	local open, all, nextLevel, nextCount, nextRebirths = Formulas.speciesOutlook(level)
	row(nextRebirths and string.format("🎰 지금 뽑기에 나오는 공룡 %d / %d종 · 다음: %s환생 %d번에 %d종", open, all,
		Formulas.rebirthMark(nextRebirths), nextRebirths, nextCount)
		or nextLevel and string.format("🎰 지금 뽑기에 나오는 공룡 %d / %d종 · 다음: %s에 %d종", open, all,
		Formulas.levelText(nextLevel), nextCount) or string.format("🎰 모든 공룡 %d종이 뽑기에 나와요!", all),
		nextLevel and COLOR_TODO or COLOR_DONE, 12)
	-- (2026-10-02, "금열쇠 + 루비열쇠+ 종류들도 구분해줘") each variant from its own key and better
	row(string.format("✨ 변종 %d종: %s", Formulas.variantCount(), Formulas.variantTiersText()), COLOR_TODO, 12)
	-- (2026-10-02) the awakened variants: both a number of rebirths and a key
	row(string.format("🌟 환생 공룡 %d종: %s", #Formulas.awakenedVariants(), Formulas.awakenedVariantsText()), COLOR_TODO, 12)
	order += 1
	local gridFrame = Instance.new("Frame")
	gridFrame.LayoutOrder = order
	gridFrame.BackgroundTransparency = 1
	gridFrame.Size = UDim2.new(1, -8, 0, 0)
	gridFrame.AutomaticSize = Enum.AutomaticSize.Y
	gridFrame.Parent = list
	local grid = Instance.new("UIGridLayout")
	grid.CellSize = CARD_SIZE
	grid.CellPadding = UDim2.fromOffset(6, 6)
	grid.SortOrder = Enum.SortOrder.LayoutOrder
	grid.Parent = gridFrame
	for i, species in ipairs(Config.Species) do
		local have = rarityCount[species.Id] or 0
		local card = Instance.new("Frame")
		card.LayoutOrder = i
		card.BackgroundColor3 = have > 0 and COLOR_CARD or COLOR_CARD_HIDDEN
		card.Parent = gridFrame
		corner(card, 10)
		if bestRarity[species.Id] then
			DinoPortrait.border(card, bestRarity[species.Id]) -- the best rarity collected of it
		end
		local picture = DinoPortrait.new(species.Id, UDim2.fromOffset(CARD_PICTURE, CARD_PICTURE), { hidden = have == 0 })
		picture.AnchorPoint = Vector2.new(0.5, 0)
		picture.Position = UDim2.new(0.5, 0, 0, 2)
		picture.Parent = card
		local name = label(card, have > 0 and species.Name or "???", UDim2.new(1, -4, 0, 16),
			UDim2.fromOffset(2, CARD_PICTURE + 2), 11, have > 0 and Color3.new(1, 1, 1) or COLOR_HIDDEN_TEXT)
		name.TextXAlignment = Enum.TextXAlignment.Center
		name.TextScaled = true
		local variant = have == 0 and species.Theme == "Variant"
		local locked = have == 0 and (variant or species.UnlockLevel > level)
		local count = label(card, variant and species.MinRebirths
				and string.format("🌟%d+🔑%s", species.MinRebirths, Formulas.keyType(species.MinKey).Name)
			or variant and ("🔑 " .. Formulas.keyType(Formulas.variantMinKey(species)).Name .. "+")
			or locked and species.UnlockRebirths and string.format("🔒 %s환생 %d번", Formulas.rebirthMark(species.UnlockRebirths),
				species.UnlockRebirths)
			or locked and ("🔒 " .. Formulas.levelText(species.UnlockLevel))
			or string.format("등급 %d/%d", have, #Config.Rarities), UDim2.new(1, -4, 0, 14),
			UDim2.fromOffset(2, CARD_PICTURE + 18), 10, locked and COLOR_LOCKED or have > 0 and COLOR_DONE or COLOR_HIDDEN_TEXT)
		count.TextXAlignment = Enum.TextXAlignment.Center
		count.TextScaled = locked
		local tap = Instance.new("TextButton")
		tap.BackgroundTransparency = 1
		tap.Text = ""
		tap.Size = UDim2.fromScale(1, 1)
		tap.ZIndex = 3
		tap.Parent = card
		tap.Activated:Connect(function()
			explain(species, have)
		end)
	end
	row("", nil)

	-- (2026-10-01, "각성 레벨 충족해야 하는 공룡은 왜 도감에 안 뜨는 거") the rebirth-only dinos: not drawn and not
	-- in the count, but shown: in color once had, else "🔒 각성 n회" (the rebirth that gives it)
	row("🌟 환생 공룡 (환생 선물로만 · 도감 수에는 안 들어가요)", COLOR_HEAD, 14)
	order += 1
	local rebirthFrame = Instance.new("Frame")
	rebirthFrame.LayoutOrder = order
	rebirthFrame.BackgroundTransparency = 1
	rebirthFrame.Size = UDim2.new(1, -8, 0, 0)
	rebirthFrame.AutomaticSize = Enum.AutomaticSize.Y
	rebirthFrame.Parent = list
	local rebirthGrid = grid:Clone()
	rebirthGrid.Parent = rebirthFrame
	for i, species in ipairs(Config.RebirthSpecies) do
		local had = data.RebirthOwned and data.RebirthOwned[species.Id] == true
		local card = Instance.new("Frame")
		card.LayoutOrder = i
		card.BackgroundColor3 = had and COLOR_CARD or COLOR_CARD_HIDDEN
		card.Parent = rebirthFrame
		corner(card, 10)
		local picture = DinoPortrait.new(species.Id, UDim2.fromOffset(CARD_PICTURE, CARD_PICTURE), { hidden = not had })
		picture.AnchorPoint = Vector2.new(0.5, 0)
		picture.Position = UDim2.new(0.5, 0, 0, 2)
		picture.Parent = card
		local name = label(card, had and species.Name or "???", UDim2.new(1, -4, 0, 16),
			UDim2.fromOffset(2, CARD_PICTURE + 2), 11, had and Color3.new(1, 1, 1) or COLOR_HIDDEN_TEXT)
		name.TextXAlignment = Enum.TextXAlignment.Center
		name.TextScaled = true
		local note = label(card, had and "✅ 획득" or string.format("🔒 %s환생 %d번", Formulas.rebirthMark(species.Rebirth),
			species.Rebirth), UDim2.new(1, -4, 0, 14),
			UDim2.fromOffset(2, CARD_PICTURE + 18), 10, had and COLOR_DONE or COLOR_LOCKED)
		note.TextXAlignment = Enum.TextXAlignment.Center
		note.TextScaled = true
	end
	row(string.format("🔄 그 뒤로는 환생 %d번마다 이 중 하나가 또 와요", Config.Rebirth.SpecialDinoEvery), COLOR_TODO, 12)
	row("", nil)


	-- (2026-10-02, 도감 보상 끝까지) my title, the milestones (each once, a title each) and every rarity's row
	local myTitle = Formulas.collectionTitle(count)
	row(string.format("🏆 내 칭호: %s · 도감 %s%%", myTitle or "아직 없음 (도감 20부터)", Formulas.collectionPercentText(count)),
		COLOR_HEAD, 15)
	row("📖 도감 단계 보상 (한 번씩 · 칭호는 머리 위에 보여요)", COLOR_HEAD, 14)
	for _, m in ipairs(Config.Collection.Milestones) do
		local need = Formulas.milestoneCount(m)
		local done = count >= need
		row(string.format("%s %d개 · %s · %s", done and "✅" or "⬜", need, m.Title, Formulas.rewardShortText(m.Reward)),
			done and COLOR_DONE or COLOR_TODO, 12)
	end
	local plainTotal = 0
	for _, s in ipairs(Config.Species) do
		plainTotal += s.Theme ~= "Variant" and 1 or 0
	end
	local rows = {}
	for _, key in ipairs(data.Collection) do
		local speciesId, rarityId = string.match(key, "^([^/]+)/(.+)$")
		local species = speciesId and Formulas.species(speciesId)
		if species and species.Theme ~= "Variant" then
			rows[rarityId] = (rows[rarityId] or 0) + 1
		end
	end
	local steps = {}
	for _, step in ipairs(Config.Collection.Rows.Steps) do
		table.insert(steps, tostring(step.Species))
	end
	row(string.format("🎨 등급 줄 모으기 (변종 빼고 %d종 · %s종에 보상)", plainTotal, table.concat(steps, "·")), COLOR_HEAD, 14)
	for _, r in ipairs(Config.Rarities) do
		local have = rows[r.Id] or 0
		local nextStep = nil
		for _, step in ipairs(Config.Collection.Rows.Steps) do
			if not nextStep and have < step.Species then
				nextStep = step
			end
		end
		local line = nextStep and string.format("%s %d/%d종 · 다음 %d종: %s", r.Name, have, plainTotal, nextStep.Species,
			Formulas.rewardShortText(Formulas.rowReward(r.Id, nextStep))) or string.format("✅ %s %d/%d종 · 줄 완성!", r.Name, have, plainTotal)
		local color = COLOR_TODO
		if not nextStep then
			color = COLOR_DONE
		elseif have > 0 then
			color = Color3.new(1, 1, 1)
		end
		row(line, color, 12)
	end
	row("", nil)

	-- (2026-10-02, "이 표를 명시해놔야지 나도 햇갈리네 뽑기할 때 명시되게 도감에도") the rarities and when each opens
	row("📋 등급이 열리는 때 (환생)", COLOR_HEAD, 14)
	for _, u in ipairs(Formulas.rarityUnlocks(level)) do
		row(Formulas.rarityUnlockLine(u), u.Open and COLOR_DONE or COLOR_LOCKED, 12)
	end
	row(Formulas.newRarityRuleText(), COLOR_TODO, 12)
	row(string.format("🔄 환생할 때마다 전설 이상이 +%d%% 더 잘 나와요", math.floor(Config.Rebirth.RareChancePerRebirth * 100 + 0.5)),
		COLOR_TODO, 12)
	row("", nil)
	row("🎁 도감 보상 (종 × 등급을 하나씩 세요)", COLOR_HEAD, 14)
	for _, r in ipairs(rewards) do
		local done = count >= r.Count
		row(string.format("%s %d개 · %s", done and "✅" or "⬜", r.Count, rewardText(r)), done and COLOR_DONE or COLOR_TODO)
	end

	row("", nil)
	row("👋 도감 수 → 손바닥 스킨 (인벤토리 → 스킨에서 끼기)", COLOR_HEAD, 14)
	for _, skin in ipairs(Config.Slap.Skins) do
		if skin.Collection then
			local got = data.Skins[skin.Id] == true
			row(string.format("%s 도감 %d → 👋 %s%s", got and "✅" or "⬜", skin.Collection, skin.Name, got and " · 획득" or ""),
				got and COLOR_DONE or COLOR_TODO)
		end
	end
	row("", nil)
	row("🏅 테마 완성 → 전용 손바닥 스킨", COLOR_HEAD, 14)
	local seen = {}
	for _, key in ipairs(data.Collection) do
		seen[string.match(key, "^([^/]+)")] = true
	end
	for _, theme in ipairs(Config.Themes) do
		local have, all = 0, 0
		for _, s in ipairs(Config.Species) do
			if s.Theme == theme.Id then
				all += 1
				have += seen[s.Id] and 1 or 0
			end
		end
		if all > 0 then
			local got = data.Skins["Theme:" .. theme.Id]
			local skin = Formulas.skin("Theme:" .. theme.Id)
			row(string.format("%s %s %d/%d종 → 👋 %s%s", got and "✅" or "⬜", theme.Name, have, all, skin and skin.Name or "스킨",
				got and " · 획득" or ""), got and COLOR_DONE or COLOR_TODO)
		end
	end

	local b = data.Bonuses
	row("", nil)
	row(string.format("💪 지금 받는 보너스 (🌾 농장 %d/%d · 🔄 환생 %d번)", data.FarmCount, data.FarmSlots, data.Rebirths), COLOR_HEAD, 14)
	row(string.format("💪 파워 %s (🌾 농장 최대 %d%% + 🔄 환생) · 💰 돈 %s", percent(b.UnitPower), math.floor(Config.Farm.UnitPowerCap * 100 + 0.5),
		percent(b.Money)))
	row(string.format("화석 감속 %s (최대 %d%%) · 채취량 %s", percent(b.MonsterSlow),
		math.floor(Config.Farm.MonsterSlowCap * 100 + 0.5), percent(b.Mining)))
	row(string.format("🍀 좋은 공룡 %s (🌾 농장 최대 %d%% + 🔄 환생) · ➕ 공룡 자리 +%d", percent(b.RareChance),
		math.floor(Config.Farm.RareChanceCap * 100 + 0.5), b.Slots))
	row("🌾 농장에 넣기: '🦖 공룡 배치' 창의 '농장' 버튼", COLOR_TODO, 12)
	row("🌾 빼기: 농장 안 공룡 옆에 가면 '🌾 빼기' 버튼", COLOR_TODO, 12)
end

local function reload()
	local data = Net.ask("GetCollection")
	if data then
		rebuild(data)
	end
end

openButton.Activated:Connect(function()
	panel.Visible = not panel.Visible
	hideDetail()
	if panel.Visible then
		list.CanvasPosition = Vector2.zero -- (opens at the top: the dinos)
		reload()
	end
end)
close.Activated:Connect(function()
	panel.Visible = false
	hideDetail()
end)
for _, name in ipairs({ "CollectionCount", "FarmCount", "Rebirths", "DefenseLevel" }) do
	player:GetAttributeChangedSignal(name):Connect(function()
		if panel.Visible then
			reload()
		end
	end)
end

-- Esc / Backspace / gamepad B closes the last opened window (Shared/Windows)
Windows.register(panel)
