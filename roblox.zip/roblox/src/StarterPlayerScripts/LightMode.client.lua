--[[
LightMode (2026-10-04, "화면이 느려요" + a screenshot: FPS 28 with the scripts at 4 ms a frame, the rest drawing; "위는 너
추천대로 다 해"; then "지연도 확실히 해결해" + a screenshot: FPS 15, the scripts 7 ms, 95,000 things): what this screen draws.

- (2026-10-05) Never anything solid (CanCollide): an unseen camp or rock that still stops you is an invisible wall. So
  in effect only the grass, flowers, ground marks and the non-solid bits of the decor come and go.
- Draw distance, for everyone: the ground's patterns (Map.FieldGround), the grass tufts and their flowers (Map.FieldGrass,
  Map.SafeGrass), the field's camps, nests and tar pits (Map.FieldDecor.FieldProps) and the small decor of Map.Decor and
  Map.FieldDecor (mushrooms, stones, bushes, logs, bones, rocks: SMALL_DECOR; not the trees) - most of the map's parts -
  are drawn only within DRAW_RADIUS of the camera. They are sorted into CELL-stud squares once (and what streams in
  later), and every UPDATE_EVERY seconds only the squares that crossed the edge change (LocalTransparencyModifier 1 = not
  drawn), at most CHANGES_PER_UPDATE of them at a time, so moving fast never hitches.
- 보기 설정 "🍃 가벼운 모드" (player attribute LightMode, saved by the Settings service): none of them at all, no shadows
  (Lighting.GlobalShadows), no bloom, sun rays or blur (Lighting's post effects), and no clouds (WeatherFx reads it).
- A screen that stays under AUTO_FPS for AUTO_FOR seconds (after JOIN_GRACE, not in the tutorial) gets it switched on by
  itself, once a session, with Coco's notice that 설정 turns it off; switched off by hand, it is never switched on again
  that session. Display only.
]]

local Lighting = game:GetService("Lighting")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local Notices = require(Shared:WaitForChild("Notices"))

local player = Players.LocalPlayer

-- display only
-- (2026-10-05, "검정 연못도 그렇고 왜 안 보이나 했네. 바로 앞에서 투명화 되어있는거니까", "맵 안 지형지물에 저런거 있으면 다
-- 복구해놔") only the grass and its flowers come and go now: the ground's marks, the small decor (rocks, logs, bones,
-- mushrooms, ...) and the field's camps, nests and tar pits are always drawn (were FieldGround and SMALL_DECOR too)
local FOLDERS = {}
local PROPS = "FieldProps" -- under Map.FieldDecor
-- (in Map.Decor and Map.FieldDecor, the small things only, by their names: the trees stay, seen from afar)
local DECOR_FOLDERS = {} -- (2026-10-05: was Decor and FieldDecor; nothing of the map's decor is hidden now)
local SMALL_DECOR = { "Mushroom", "Stone", "Bush", "Log", "Bone", "Rock", "Cap", "Stem", "Spot", "Flower" }
local CELL = 64 -- studs: the squares things are sorted into
local DRAW_RADIUS = 240 -- studs from the camera (flat) a square is drawn within
local UPDATE_EVERY = 0.4 -- seconds between looks
local CHANGES_PER_UPDATE = 16 -- squares changed at most per look (the rest the next one)
local INDEX_PER_FRAME = 300
local POST_EFFECTS = { "BloomEffect", "SunRaysEffect", "DepthOfFieldEffect", "BlurEffect" } -- off in light mode
-- (2026-10-04, "내 폰은 성능 좋은데 가벼운 모드가 왜 켜져있는거": was 24 fps for 12 s, and once on it was saved for
-- good) stricter, and an automatic one lasts the session: on the next join it is off again (unless switched on by hand:
-- LightModeManual)
local AUTO_FPS = 20
local AUTO_FOR = 20 -- seconds
local JOIN_GRACE = 25
local DETAIL_FPS = 40
local DETAIL_FOR = 10

local shadowsBefore = Lighting.GlobalShadows
local light = false -- light mode on

-- the squares: [key] = { x, z (its middle), items = { part / decal ... }, shown }
local cells = {}
local function keyOf(x, z)
	return math.floor(x / CELL) * 100000 + math.floor(z / CELL)
end
local function hide(item, hidden)
	item.LocalTransparencyModifier = hidden and 1 or 0
end
local function add(item)
	local part = item:IsA("BasePart") and item or ((item:IsA("Decal") or item:IsA("Texture")) and item.Parent)
	if not part or not part:IsA("BasePart") then
		return
	end
	-- (2026-10-05, "새 지형지물들은 왜 다 투명이 된거야", "멀리서도 안 보이고 가까히에서도 안 보인다고", "근데 형체는 남아있고")
	-- what can be bumped into is always drawn: a hidden camp, nest, rock or log was an invisible wall (in light mode, or
	-- past the draw distance). Only what nothing stands on or bumps into (grass, ground marks, flowers) is left out
	if part.CanCollide then
		return
	end
	if item == part then
		part.CastShadow = false -- (small things: their shadows cost more than they show)
	end
	local p = part.Position
	local key = keyOf(p.X, p.Z)
	local cell = cells[key]
	if not cell then
		cell = { x = (math.floor(p.X / CELL) + 0.5) * CELL, z = (math.floor(p.Z / CELL) + 0.5) * CELL, items = {}, shown = true }
		cells[key] = cell
	end
	table.insert(cell.items, item)
	if not cell.shown then
		hide(item, true)
	end
end

local function addAll(list)
	for i, d in ipairs(list) do
		add(d)
		if i % INDEX_PER_FRAME == 0 then
			task.wait()
		end
	end
end

local watched = {} -- [folder] = true
local function watch()
	local map = Workspace:FindFirstChild("Map")
	if not map then
		return
	end
	local list = {}
	for _, name in ipairs(FOLDERS) do
		table.insert(list, map:FindFirstChild(name))
	end
	-- (2026-10-05: the field's camps, nests and tar pits no longer: always drawn, whole)
	for _, folder in pairs(list) do
		if folder and not watched[folder] then
			watched[folder] = true
			folder.DescendantAdded:Connect(add) -- (streamed in later)
			task.spawn(addAll, folder:GetDescendants())
		end
	end
	-- the small decor: a child of the folder whose name has one of SMALL_DECOR, and all in it
	local function small(name)
		for _, word in ipairs(SMALL_DECOR) do
			if string.find(name, word, 1, true) then
				return true
			end
		end
		return false
	end
	for _, name in ipairs(DECOR_FOLDERS) do
		local folder = map:FindFirstChild(name)
		if folder and not watched[folder] then
			watched[folder] = true
			local function addChild(child)
				if child.Name ~= PROPS and small(child.Name) then
					add(child)
					for _, d in ipairs(child:GetDescendants()) do
						add(d)
					end
				end
			end
			for _, child in ipairs(folder:GetChildren()) do
				addChild(child)
			end
			folder.ChildAdded:Connect(addChild)
		end
	end
end

local function setCell(cell, shown)
	cell.shown = shown
	local kept = {}
	for _, item in ipairs(cell.items) do
		if item.Parent then -- (gone ones are dropped: streamed out, a new copy comes in later)
			hide(item, not shown)
			table.insert(kept, item)
		end
	end
	cell.items = kept
end

-- every look: the squares that should change, nearest first, at most CHANGES_PER_UPDATE (all at once when `all`)
local function update(all)
	local camera = Workspace.CurrentCamera
	local eye = camera and camera.CFrame.Position or Vector3.zero
	local reach = DRAW_RADIUS + CELL * 0.71
	local changes = {}
	for _, cell in pairs(cells) do
		local d = math.sqrt((cell.x - eye.X) ^ 2 + (cell.z - eye.Z) ^ 2)
		local want = not light and d <= reach
		if want ~= cell.shown then
			table.insert(changes, { cell, want, d })
		end
	end
	if not all and #changes > CHANGES_PER_UPDATE then
		table.sort(changes, function(a, b)
			return a[3] < b[3]
		end)
	end
	for i, c in ipairs(changes) do
		if not all and i > CHANGES_PER_UPDATE then
			break
		end
		setCell(c[1], c[2])
	end
end

local effectsBefore = {} -- [effect] = Enabled before light mode
local function apply()
	light = player:GetAttribute("LightMode") == true
	Lighting.GlobalShadows = not light and not player:GetAttribute("LowDetail") and shadowsBefore
	for _, e in ipairs(Lighting:GetChildren()) do
		if table.find(POST_EFFECTS, e.ClassName) then
			if light then
				if effectsBefore[e] == nil then
					effectsBefore[e] = e.Enabled
				end
				e.Enabled = false
			elseif effectsBefore[e] ~= nil then
				e.Enabled = effectsBefore[e]
				effectsBefore[e] = nil
			end
		end
	end
	watch()
	update(true)
end

player:GetAttributeChangedSignal("LightMode"):Connect(apply)
player:GetAttributeChangedSignal("LowDetail"):Connect(apply)
local function hookMap(map)
	map.ChildAdded:Connect(function(child)
		if table.find(FOLDERS, child.Name) then
			watch()
		end
	end)
	watch()
end
if Workspace:FindFirstChild("Map") then
	hookMap(Workspace.Map)
else
	local waitMap
	waitMap = Workspace.ChildAdded:Connect(function(child)
		if child.Name == "Map" then
			waitMap:Disconnect()
			hookMap(child)
		end
	end)
end
task.spawn(function()
	apply()
	local since = 0
	while true do
		task.wait(UPDATE_EVERY)
		since += UPDATE_EVERY
		if since >= 10 then -- (the map may still be streaming in: its folders looked for again now and then)
			since = 0
			watch()
		end
		update(false)
	end
end)

-- a slow screen: light mode by itself, once a session (not again once switched off by hand)
local frames, slowSince, done = 0, nil, false
local joinedAt = os.clock()
local autoOn = false
RunService.RenderStepped:Connect(FrameMeter.wrap("LightMode", function()
	frames += 1
end))
player:GetAttributeChangedSignal("LightMode"):Connect(function()
	if autoOn and player:GetAttribute("LightMode") ~= true then
		done = true -- (switched off by hand)
	end
end)
task.spawn(function()
	local lowSince = nil
	while not done or not player:GetAttribute("LowDetail") do
		task.wait(1)
		local fps = frames
		frames = 0
		local settled = os.clock() - joinedAt > JOIN_GRACE and fps > 0
		if not done and settled and fps < AUTO_FPS and not light then
			slowSince = slowSince or os.clock()
			if os.clock() - slowSince >= AUTO_FOR and not player:GetAttribute("TutorialStep") then
				done, autoOn = true, true
				player:SetAttribute("LightMode", true)
				Notices.show("🍃 가벼운 모드", "📱 화면이 느려서 켰어요 · ⚙️ 설정에서 끌 수 있어요")
			end
		else
			slowSince = nil
		end
		if not player:GetAttribute("LowDetail") and settled and fps < DETAIL_FPS and not light then
			lowSince = lowSince or os.clock()
			if os.clock() - lowSince >= DETAIL_FOR then
				player:SetAttribute("LowDetail", true)
			end
		else
			lowSince = nil
		end
	end
end)
