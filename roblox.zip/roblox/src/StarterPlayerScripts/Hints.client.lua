--[[
Hints: Coco's tips (design 10 나중에 열리는 안내; 2026-10-01, "추가된 내용들도 튜토리얼에서 알려줄수 있게").

What the tutorial can't show in the base is told the first time it comes up: one line (Config.Hints.Tips)
titled "🐣 코코의 팁" in the notices at the left middle (the server sends it back as a Notice when it saves
the tip: Net request HintSeen; Tutorial service), with Coco's hello. Each tip once per account (player
attribute HintsSeen: the ones shown). None while the tutorial runs (player attribute TutorialStep), one at a
time, at least GapSeconds apart.

When each comes up (checked every CHECK_EVERY seconds, from what the screen already knows):
  BagFull    my bag is full (BagCount, BagCapacity)
  Slapped    I lie groggy after a slap (StunReason "Groggy")
  SlotsFull  every placement slot is taken (DefensePlaced, DefenseSlots)
  PromoBoss  a promotion fight's boss is on my track (PromoBoss)
  Night      it is night (ReplicatedStorage Night)
  Boss       a boss zombie is out (Workspace.Zombies, a Configuration with Boss)
  Aurora     the aurora weather (ReplicatedStorage Weather "Aurora")
  KingKey    a king key is on the ground (Workspace.Keys, Kind "King") or someone carries one (CarriedKing)
  Bombs      I have bombs (Bombs)
  Race       I am by the race road (Workspace.Map.Ground.RaceTrack: Radius, Width)
  Wild       a wild dino is near me (Workspace.Wildlife)
  Chest      a treasure chest is near me (Workspace.TreasureChests)
  Rebirth    my defense level is at its tier's top (Formulas.maxDefenseLevel)
  (2026-10-02, "지금까지 업데이트한 내용들 더 추가")
  Storm      a thunderstorm (ReplicatedStorage Weather "Storm": the bolts' glowing rings)
  Weather    rain or the rainbow sky (the bonuses)
  Attendance today's attendance is ready (RewardsReadyAttendance)
  Friends    a Roblox friend is on the server (Friends)
  Limited    this week's limited dino is on (ReplicatedStorage LimitedSpecies)
  Variant    defense level Config.Hints.VariantTipLevel (variants need a silver key or better)
  RidePractice I ride a dino (Riding)
  DayBuff    the boss's day buff is on (ReplicatedStorage DayBuff)
  PoopBomb   I have bombs and it is night (zombies to bury)
  (2026-10-02, 공룡 사육)
  Fruit      defense level Config.Fruit.TipLevel: slap a tree, pick up the fruit
  FruitCarry I carry fruit (CarriedFruit): it becomes food at home, ⬇️ puts it down for a friend
  Feed       Config.Fruit.FeedTipFood food saved (Fruit): feed it at the enhance stall's 🍎 tab
  Merge      a merge is possible (MergeReady, the Enhance service)
  (2026-10-02, "튜토리얼이 모든 걸 필요한 만큼 설명해 주나")
  Enhance    Config.Hints.EnhanceTipSpare dinos neither placed nor on the farm (SpareDinos, the Farm service)
  Challenge  defense level Config.Hints.ChallengeTipLevel: the ♾️ 도전 button
  DexTitle   the first collection title (DexTitle): more pairs, more titles and keys, the rarity rows
  (2026-10-03)
  HideSeek   I am by the 🙈 hide-and-seek board (Workspace.HideSeek)
  HideTrap   I hide in a game (player attribute HideSeekRole "Hider"): the 🕸️ traps and the 💓 heartbeat
  (2026-10-06)
  Leak       my boss wave is on (PromoOnTrack)
  Group      a 🚩 group is in my promotion fight (PromoGroup)
  NewMap     a rebirth opened another defense map (Rebirths)
  Shell / Immune / Airship  a 🥚 shell, a 🧱🧊🌋 immune fossil, a 🎈 airship in my promotion fight (PromoShell, PromoImmune,
             PromoAirship)
  TipsOff    Config.Hints.TipsOffAfter tips were shown: they can be turned off in the settings
- None at all while the setting "🐣 코코의 팁" is off (player attribute HideTips, 2026-10-02).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local CocoVoice = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("CocoVoice"))
local Unlock = require(Shared:WaitForChild("Unlock"))

local player = Players.LocalPlayer
local H = Config.Hints

-- display only
local CHECK_EVERY = 1 -- seconds between looks at what is going on
local HELP_TIP_RANGE = 60
local LOCKED_BY = { Race = "GameRooms", HideSeek = "GameRooms", RidePractice = "Ride", Fruit = "FieldEdge",
	FruitCarry = "FieldEdge", Feed = "Enhance", Merge = "Enhance", Enhance = "Enhance", EnhanceBulk = "Enhance",
	Challenge = "Challenge", Night = "FieldEdge", Boss = "Altar", Aurora = "Altar", KingKey = "Altar", Guardian = "Altar", BoxLock = "Altar", Bombs = "Bombs",
	PoopBomb = "Bombs", NewMap = "MapBoard", Rebirth = "Rebirth", Wild = "FieldEdge", WildFeed = "FieldEdge", Chest = "FieldEdge" }
local SHOWN_BY = { SlotsFull = "FarmBoard" }

-- ---------------------------------------------------------------------------
-- Which tips are shown already, and the queue
-- ---------------------------------------------------------------------------

local textOf = {}
for _, tip in ipairs(H.Tips) do
	textOf[tip.Id] = tip.Text
end

local seen = {} -- [id] = true (the server's list, and what this screen showed since)
local function readSeen()
	for id in string.gmatch(player:GetAttribute("HintsSeen") or "", "[^,]+") do
		seen[id] = true
	end
end
player:GetAttributeChangedSignal("HintsSeen"):Connect(readSeen)
readSeen()

local queue = {}
local lastShown = -math.huge

local function want(id)
	if seen[id] or table.find(queue, id) or not textOf[id] or (LOCKED_BY[id] and not Unlock.has(LOCKED_BY[id]))
		or (SHOWN_BY[id] and not Unlock.shown(SHOWN_BY[id])) then
		return
	end
	table.insert(queue, id)
end

local function showNext()
	if #queue == 0 or os.clock() - lastShown < H.GapSeconds or player:GetAttribute("TutorialStep") or player:GetAttribute("CocoIntro")
		or player:GetAttribute("TopView") or (player:GetAttribute("DefenseLevel") or 1) < H.FromLevel or player:GetAttribute("FreshStart") then
		return
	end
	local id = table.remove(queue, 1)
	if seen[id] then
		return
	end
	seen[id] = true
	lastShown = os.clock()
	Net.request("HintSeen", id) -- (the server saves it and shows it in the notices)
	CocoVoice.babble(id)
end

-- ---------------------------------------------------------------------------
-- When each comes up
-- ---------------------------------------------------------------------------

local function myPosition()
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	return root and root.Position
end

local function anyNear(folder, at, test)
	if not folder or not at then
		return false
	end
	for _, item in ipairs(folder:GetChildren()) do
		if (not test or test(item)) then
			local ok, pivot = pcall(function()
				return item:IsA("BasePart") and item.Position or item:GetPivot().Position
			end)
			if ok and (pivot - at).Magnitude <= H.NearStuds then
				return true
			end
		end
	end
	return false
end

local function byRaceRoad(at)
	local map = Workspace:FindFirstChild("Map")
	local ground = map and map:FindFirstChild("Ground")
	local track = ground and ground:FindFirstChild("RaceTrack")
	local radius, width = track and track:GetAttribute("Radius"), track and track:GetAttribute("Width")
	if not radius or not width or not at then
		return false
	end
	return math.abs(Vector3.new(at.X, 0, at.Z).Magnitude - radius) <= width / 2 + H.NearStuds / 2
end

local function bossOut()
	local folder = Workspace:FindFirstChild("Zombies")
	for _, conf in ipairs(folder and folder:GetChildren() or {}) do
		if conf:GetAttribute("Boss") then
			return true
		end
	end
	return false
end

local function kingKeyAround()
	for _, other in ipairs(Players:GetPlayers()) do
		if (other:GetAttribute("CarriedKing") or 0) > 0 then
			return true
		end
	end
	local keys = Workspace:FindFirstChild("Keys")
	for _, box in ipairs(keys and keys:GetDescendants() or {}) do
		if box:GetAttribute("King") then
			return true
		end
	end
	return false
end

local function guardianChasing()
	local folder = Workspace:FindFirstChild("Zombies")
	for _, conf in ipairs(folder and folder:GetChildren() or {}) do
		if conf:GetAttribute("Guardian") and conf:GetAttribute("ChaseUserId") == player.UserId then
			return true
		end
	end
	return false
end

local function lockedBoxNear(at)
	return anyNear(Workspace:FindFirstChild("Keys"), at, function(part)
		return part.Name == "AltarBox" and part:FindFirstChild("BoxLock") ~= nil
	end)
end

local function damageBoardShown()
	local map = Workspace:FindFirstChild("Map")
	local holder = map and map:FindFirstChild("DefenseGuides")
	local index = player:GetAttribute("Base")
	local model = holder and index and holder:FindFirstChild("DefenseGuideBase" .. index)
	return model ~= nil and model:GetAttribute("Hidden") ~= true and model:FindFirstChild("DamageBoard") ~= nil
end

local function helpWaveNear(at)
	local map = Workspace:FindFirstChild("Map")
	for _, other in ipairs(Players:GetPlayers()) do
		local index = at and map and other ~= player and other:GetAttribute("PromoLevel") ~= nil
			and other:GetAttribute("ChallengeWave") == nil and other:GetAttribute("Base")
		local folder = index and map:FindFirstChild("Base" .. index)
		local frame = folder and folder:GetAttribute("ArenaFrame")
		if typeof(frame) == "CFrame" and (frame.Position - at).Magnitude <= HELP_TIP_RANGE then
			return true
		end
	end
	return false
end

local function look()
	if player:GetAttribute("HintsSeen") == nil or player:GetAttribute("TutorialStep") or player:GetAttribute("HideTips") then
		return -- (not loaded yet, or Coco is showing the way herself, or the tips are turned off)
	end
	local a = function(name)
		return player:GetAttribute(name)
	end
	local at = myPosition()
	if (a("BagCapacity") or 0) > 0 and (a("BagCount") or 0) >= a("BagCapacity") then
		want("BagFull")
	end
	if a("StunReason") == "Groggy" then
		want("Slapped")
	end
	if (a("DefenseSlots") or 0) > 0 and (a("DefensePlaced") or 0) >= a("DefenseSlots") then
		want("SlotsFull")
	end
	if a("PromoBoss") then
		want("PromoBoss")
	end
	if not seen.DamageBoard and a("DamageAt") and damageBoardShown() then
		want("DamageBoard")
	end
	if not seen.HelpSlap and helpWaveNear(at) then
		want("HelpSlap")
	end
	if ReplicatedStorage:GetAttribute("Night") then
		want("Night")
	end
	if ReplicatedStorage:GetAttribute("Weather") == "Aurora" then
		want("Aurora")
	end
	if not seen.Boss and bossOut() then
		want("Boss")
	end
	if not seen.KingKey and kingKeyAround() then
		want("KingKey")
	end
	if not seen.Guardian and guardianChasing() then
		want("Guardian")
	end
	if not seen.BoxLock and lockedBoxNear(at) then
		want("BoxLock")
	end
	if (a("Bombs") or 0) > 0 then
		want("Bombs")
	end
	if not seen.Race and byRaceRoad(at) then
		want("Race")
	end
	if not seen.Wild and anyNear(Workspace:FindFirstChild("Wildlife"), at) then
		want("Wild")
	end
	if a("WildRiding") then
		want("WildFeed")
	end
	if a("PlacingUnit") then
		if not a("TopView") then
			want("TopView")
		end
		for _, m in ipairs(Config.Defense.Maps) do
			if m.Id == a("DefenseMap") and m.Nests and #m.Nests > 0 then
				want("Nest")
			end
			if m.Id == a("DefenseMap") and m.Perches and #m.Perches > 0 then
				want("Perch")
			end
		end
	end
	if (a("RewardsReady") or 0) >= 2 then
		want("ClaimAll")
	end
	if a("FreeSkipFor") then
		want("FreeSkip")
	end
	if (a("BoxesReady") or 0) > 0 then
		want("BoxReady")
	end
	if (a("BoxNextAt") or 0) - Workspace:GetServerTimeNow() > Config.Boxes.RaritySeconds.Epic then
		want("BoxWait")
	end
	if not seen.Chest and anyNear(Workspace:FindFirstChild("TreasureChests"), at) then
		want("Chest")
	end
	local level = a("DefenseLevel")
	if level and level >= Formulas.maxDefenseLevel(a("Rebirths") or 0) then
		want("Rebirth")
	end
	if (a("Rebirths") or 0) >= 1 then -- (2026-10-02) the rarities an awakening opens, and where to see them
		want("NewRarities")
	end
	if a("PromoOnTrack") then
		want("Leak")
	end
	if level and Formulas.twistRule(level + 1) then
		want("Twist")
	end
	if a("PromoGroup") then
		want("Group")
	end
	if a("PromoShell") then
		want("Shell")
	end
	if a("PromoImmune") then
		want("Immune")
	end
	if a("PromoAirship") then
		want("Airship")
	end
	if a("PromoSprinter") then
		want("Sprinter")
	end
	if (a("Rebirths") or 0) >= 1 then
		want("NewMap")
	end
	local weather = ReplicatedStorage:GetAttribute("Weather")
	if weather == "Storm" then
		want("Storm")
	end
	if weather == "Rain" or weather == "RainbowSky" then
		want("Weather")
	end
	if (a("RewardsReadyAttendance") or 0) > 0 then
		want("Attendance")
	end
	if (a("Friends") or 0) > 0 then
		want("Friends")
	end
	if ReplicatedStorage:GetAttribute("LimitedSpecies") then
		want("Limited")
	end
	if level and level >= H.VariantTipLevel then
		want("Variant")
	end
	if a("Riding") then
		want("RidePractice")
	end
	if ReplicatedStorage:GetAttribute("DayBuff") then
		want("DayBuff")
	end
	if (a("Bombs") or 0) > 0 and ReplicatedStorage:GetAttribute("Night") then
		want("PoopBomb")
	end
	if level and level >= Config.Fruit.TipLevel then
		want("Fruit")
	end
	if (a("CarriedFruit") or 0) > 0 then
		want("FruitCarry")
	end
	if (a("Fruit") or 0) >= Config.Fruit.FeedTipFood then
		want("Feed")
	end
	if a("MergeReady") then
		want("Merge")
	end
	if (a("SpareDinos") or 0) >= H.EnhanceTipSpare then
		want("Enhance")
		want("EnhanceBulk")
	end
	if level and level >= H.ChallengeTipLevel then
		want("Challenge")
	end
	if not seen.HideSeek and anyNear(Workspace:FindFirstChild("HideSeek"), at) then
		want("HideSeek")
	end
	if player:GetAttribute("HideSeekRole") == "Hider" then
		want("HideTrap")
	end
	if a("DexTitle") then
		want("DexTitle")
	end
	local shown = 0
	for _ in pairs(seen) do
		shown += 1
	end
	if shown >= H.TipsOffAfter then
		want("TipsOff")
	end
	showNext()
end

task.spawn(function()
	while true do
		task.wait(CHECK_EVERY)
		local ok, err = pcall(look)
		if not ok then
			warn("[Hints]", err)
		end
	end
end)
