local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Coach = require(Shared:WaitForChild("Coach"))
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Lang = require(Shared:WaitForChild("Lang"))
local Net = require(Shared:WaitForChild("Net"))
local Notices = require(Shared:WaitForChild("Notices"))
local ScreenButtons = require(Shared:WaitForChild("ScreenButtons"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

local FONT = Enum.Font.GothamBold
local FIT_MARGIN = 1.12
local TILT = math.rad(12)
local ZOOM_MIN, ZOOM_MAX = 0.3, 1.25
local WHEEL_STEP = 0.88
local EASE = 9
local TAP_PIXELS = 12
local TUTORIAL_STEP = "TopView"
local TAP_SLACK = 2
local TOGGLE_SIZE = UDim2.fromOffset(84, 40)
local TOGGLE_POS = UDim2.new(1, -112, 1, -112)
local TOGGLE_GAP = 10
local CLEAR_GAP = 4
local LIFT_STEP = 46
local LIFT_TRIES = 4
local COLOR_TOGGLE = Color3.fromRGB(70, 140, 230)
local COLOR_TOGGLE_OFF = Color3.fromRGB(235, 70, 80)
local COLOR_SHINE = Color3.fromRGB(255, 215, 70)
local SHINE_SPEED = 4
local SHINE_THICKNESS = 3
local PULSE_GROW = 0.06
local TOGGLE_EVERY = 0.25
local MARK_COLOR = Color3.fromRGB(255, 225, 60)
local MARK_FILL = 0.55
local STICK_SHARE = 0.4
local STICK_TOP = 1 / 3
local PAN_BEYOND = 0.6
local PAN_BEYOND_MAX = 45
local GRID_STEP = 16
local GRID_EDGE = 8
local BAR_SIZE = UDim2.fromOffset(340, 40)
local BAR_POS = UDim2.new(0.5, 0, 1, -6)
local EXIT_SIZE = UDim2.fromOffset(92, 30)
local TEXT_SIZE = 13
local COLOR_BAR = Color3.fromRGB(25, 28, 40)
local COLOR_EXIT = Color3.fromRGB(235, 70, 80)
local BAR_TRANSPARENCY = 0.15
local ROTATE_SIZE = UDim2.fromOffset(84, 40)
local ROTATE_GAP = 8
local ROTATE_TEXT_SIZE = 16
local COLOR_ROTATE = Color3.fromRGB(125, 95, 225)
local AUTO_GAP = 8
local AUTO_ARM = 3
local COLOR_AUTO = Color3.fromRGB(70, 140, 230)
local COLOR_AUTO_ARMED = Color3.fromRGB(240, 170, 60)
local LABEL_SEE = 2000

local gui = Instance.new("ScreenGui")
gui.Name = "TopView"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local bar = Instance.new("Frame")
bar.AnchorPoint = Vector2.new(0.5, 1)
bar.Position = BAR_POS
bar.Size = BAR_SIZE
bar.BackgroundColor3 = COLOR_BAR
bar.BackgroundTransparency = BAR_TRANSPARENCY
bar.Visible = false
bar.Parent = gui
do
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 12)
	c.Parent = bar
end
local words = Instance.new("TextLabel")
words.BackgroundTransparency = 1
words.Font = FONT
words.TextSize = TEXT_SIZE
words.TextColor3 = Color3.new(1, 1, 1)
words.TextXAlignment = Enum.TextXAlignment.Left
words.TextWrapped = true
words.Text = "🗺️ 공룡을 눌러 옮겨요 · 밀어서 둘러봐요"
words.Position = UDim2.fromOffset(12, 0)
words.Size = UDim2.new(1, -EXIT_SIZE.X.Offset - 24, 1, 0)
words.Parent = bar
local exit = Instance.new("TextButton")
exit.AnchorPoint = Vector2.new(1, 0.5)
exit.Position = UDim2.new(1, -6, 0.5, 0)
exit.Size = EXIT_SIZE
exit.BackgroundColor3 = COLOR_EXIT
exit.Font = FONT
exit.TextSize = TEXT_SIZE
exit.TextColor3 = Color3.new(1, 1, 1)
exit.Text = "↩️ 나가기"
exit.Parent = bar
do
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 8)
	c.Parent = exit
end

local rotate = Instance.new("TextButton")
rotate.Name = "TopViewRotate"
rotate.AnchorPoint = Vector2.new(0.5, 1)
rotate.Position = UDim2.new(0.5, 0, 1, BAR_POS.Y.Offset - BAR_SIZE.Y.Offset - ROTATE_GAP)
rotate.Size = ROTATE_SIZE
rotate.BackgroundColor3 = COLOR_ROTATE
rotate.Font = FONT
rotate.TextSize = ROTATE_TEXT_SIZE
rotate.TextColor3 = Color3.new(1, 1, 1)
rotate.Text = "🔄 90°"
rotate.Visible = false
rotate.Parent = gui
do
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 10)
	c.Parent = rotate
end

local toggle = Instance.new("TextButton")
toggle.Name = "TopViewToggle"
toggle.AnchorPoint = Vector2.new(1, 1)
toggle.Position = TOGGLE_POS
toggle.Size = TOGGLE_SIZE
toggle.BackgroundColor3 = COLOR_TOGGLE
toggle.Font = FONT
toggle.TextSize = TEXT_SIZE
toggle.TextColor3 = Color3.new(1, 1, 1)
toggle.Text = "🗺️ 탑뷰"
toggle.TextWrapped = true
toggle.Visible = false
toggle.Parent = gui
do
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 10)
	c.Parent = toggle
end
local autoButton = Instance.new("TextButton")
autoButton.Name = "TopViewAuto"
autoButton.AnchorPoint = Vector2.new(1, 1)
autoButton.Size = TOGGLE_SIZE
autoButton.BackgroundColor3 = COLOR_AUTO
autoButton.Font = FONT
autoButton.TextScaled = true
autoButton.TextColor3 = Color3.new(1, 1, 1)
autoButton.Text = "✨ 자동 배치"
autoButton.Visible = false
autoButton.Parent = gui
do
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 10)
	c.Parent = autoButton
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = TEXT_SIZE
	most.Parent = autoButton
end
Coach.mark(autoButton, "AutoPlace")
local function placeAuto()
	local at = toggle.Position + UDim2.fromOffset(0, -(TOGGLE_SIZE.Y.Offset + AUTO_GAP))
	if autoButton.Position ~= at then
		autoButton.Position = at
	end
end
local armedUntil = 0
local function paintAuto()
	local armed = os.clock() <= armedUntil
	autoButton.BackgroundColor3 = armed and COLOR_AUTO_ARMED or COLOR_AUTO
	Lang.set(autoButton, armed and "✨ 한 번 더!" or "✨ 자동 배치")
end
autoButton.Activated:Connect(function()
	if os.clock() > armedUntil then
		armedUntil = os.clock() + AUTO_ARM
		paintAuto()
		task.delay(AUTO_ARM, paintAuto)
		return
	end
	armedUntil = 0
	paintAuto()
	Net.request("AutoArrange")
end)
paintAuto()
local shine = Instance.new("UIStroke")
shine.Color = COLOR_SHINE
shine.Thickness = SHINE_THICKNESS
shine.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
shine.Parent = toggle
local pulse = Instance.new("UIScale")
pulse.Parent = toggle

local mark = Instance.new("Highlight")
mark.Name = "TopViewMe"
mark.FillColor = MARK_COLOR
mark.OutlineColor = MARK_COLOR
mark.FillTransparency = MARK_FILL
mark.OutlineTransparency = 0
mark.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
mark.Enabled = false
mark.Parent = gui

local on = false
local enteredAt = nil
local savedType = nil
local arenaModel, hiddenTitle = nil, nil
local savedView = nil
local savedOffset = nil
local up = Vector3.new(0, 0, -1)
local zoom = 1
local pan = Vector3.zero
local press = nil
local touches = {}
local pinchFrom = nil

local slap = nil
local function clearOf(a, b, boxes)
	for _, box in ipairs(boxes) do
		local g = box[3]
		if a.X < box[2].X + g and b.X > box[1].X - g and a.Y < box[2].Y + g and b.Y > box[1].Y - g then
			return false
		end
	end
	return a.X >= 0 and a.Y >= 0
end

local function overlap(a, b, boxes)
	local sum = 0
	for _, box in ipairs(boxes) do
		local g = box[3]
		local w = math.min(b.X, box[2].X + g) - math.max(a.X, box[1].X - g)
		local h = math.min(b.Y, box[2].Y + g) - math.max(a.Y, box[1].Y - g)
		if w > 0 and h > 0 then
			sum += w * h
		end
	end
	return sum
end

local function placeToggle()
	if not (slap and slap.Parent) then
		slap = player.PlayerGui:FindFirstChild("SlapButton", true)
	end
	if not slap or slap.AbsoluteSize.X < 1 then
		toggle.Position = TOGGLE_POS
		return
	end
	local w, h = TOGGLE_SIZE.X.Offset, TOGGLE_SIZE.Y.Offset
	local slapLeft = slap.AbsolutePosition.X
	local slapRight = slapLeft + slap.AbsoluteSize.X
	local bottom = slap.AbsolutePosition.Y - TOGGLE_GAP
	local boxes = ScreenButtons.boxes(gui, CLEAR_GAP)
	local rights = { slapRight }
	local touch = player.PlayerGui:FindFirstChild("TouchGui")
	local jump = touch and touch:FindFirstChild("JumpButton", true)
	if jump and jump:IsA("GuiObject") and jump.Visible and jump.AbsoluteSize.X > 0 then
		table.insert(boxes, { jump.AbsolutePosition, jump.AbsolutePosition + jump.AbsoluteSize, TOGGLE_GAP })
		table.insert(rights, math.min(slapRight, jump.AbsolutePosition.X - TOGGLE_GAP))
	end
	local bagGui = player.PlayerGui:FindFirstChild("BagBar")
	local bagBar = bagGui and bagGui:FindFirstChildWhichIsA("Frame")
	if bagBar and bagBar.Visible then
		table.insert(boxes, { bagBar.AbsolutePosition, bagBar.AbsolutePosition + bagBar.AbsoluteSize, CLEAR_GAP })
		for _, d in ipairs(bagBar:GetChildren()) do
			if d:IsA("TextLabel") and d.Visible and d.AbsoluteSize.X > 0 then
				table.insert(boxes, { d.AbsolutePosition, d.AbsolutePosition + d.AbsoluteSize, CLEAR_GAP })
			end
		end
	end
	local spots = {}
	for k = 0, LIFT_TRIES do
		for _, right in ipairs(rights) do
			table.insert(spots, Vector2.new(right, bottom - k * LIFT_STEP))
		end
	end
	local beside = slap.AbsolutePosition.Y + (slap.AbsoluteSize.Y + h) / 2
	for k = 0, LIFT_TRIES do
		table.insert(spots, Vector2.new(slapLeft - TOGGLE_GAP, beside - k * LIFT_STEP))
	end
	local side = player.PlayerGui:FindFirstChild("SideButtons")
	local column = side and side:FindFirstChild("Column")
	if column and column.Visible then
		local left, low = math.huge, -math.huge
		for _, d in ipairs(column:GetDescendants()) do
			if d:IsA("GuiButton") and d.Visible and d.AbsoluteSize.X > 0 then
				left = math.min(left, d.AbsolutePosition.X)
				low = math.max(low, d.AbsolutePosition.Y + d.AbsoluteSize.Y)
			end
		end
		if left < math.huge then
			for k = 0, LIFT_TRIES do
				table.insert(spots, Vector2.new(left - TOGGLE_GAP, low - k * LIFT_STEP))
			end
		end
	end
	local screen = gui.AbsoluteSize
	local origin = gui.AbsolutePosition
	table.insert(boxes, { origin + Vector2.new(0, screen.Y * STICK_TOP),
		origin + Vector2.new(screen.X * STICK_SHARE, screen.Y), 0 })
	local first = spots[1]
	local extra = {}
	local x = origin.X + screen.X - GRID_EDGE
	while x - w >= origin.X + screen.X * STICK_SHARE do
		local y = origin.Y + screen.Y - GRID_EDGE
		while y - h >= origin.Y + screen.Y * STICK_TOP do
			table.insert(extra, Vector2.new(x, y))
			y -= GRID_STEP
		end
		x -= GRID_STEP
	end
	table.sort(extra, function(a, b)
		return (a - first).Magnitude < (b - first).Magnitude
	end)
	for _, spot in ipairs(extra) do
		table.insert(spots, spot)
	end
	local pick, least = nil, math.huge
	for _, spot in ipairs(spots) do
		local a = Vector2.new(spot.X - w, spot.Y - h)
		if clearOf(a, spot, boxes) then
			pick = spot
			break
		end
		local o = a.X >= 0 and a.Y >= 0 and overlap(a, spot, boxes) or math.huge
		if o < least then
			pick, least = spot, o
		end
	end
	pick = pick or Vector2.new(slapLeft - TOGGLE_GAP, beside)
	local at = UDim2.fromOffset(pick.X - origin.X, pick.Y - origin.Y)
	if toggle.Position ~= at then
		toggle.Position = at
		ScreenButtons.moved()
	end
	placeAuto()
end

local viewIndex = nil

local function folderOf(index)
	local map = Workspace:FindFirstChild("Map")
	return index and map and map:FindFirstChild("Base" .. tostring(index))
end

local function baseFolder()
	return folderOf(viewIndex or player:GetAttribute("Base"))
end

local function watching()
	local own = player:GetAttribute("Base")
	return viewIndex ~= nil and viewIndex ~= own
end

local ARENA_STAGE = Formulas.stageOf("Base_Arena")
local function arenaStaged(folder)
	local id = ARENA_STAGE and folder:GetAttribute("OwnerUserId")
	local owner = id and Players:GetPlayerByUserId(id)
	return owner ~= nil and owner:GetAttribute("Staged" .. ARENA_STAGE) == true
end

local function nearBase()
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not root then
		return nil
	end
	local own = player:GetAttribute("Base")
	local best, bestDistance = nil, math.huge
	for index = 1, Config.Map.BaseCount do
		local folder = folderOf(index)
		local frame = folder and folder:GetAttribute("ArenaFrame")
		if typeof(frame) == "CFrame" and (index == own or folder:GetAttribute("OwnerUserId")) and not arenaStaged(folder) then
			local d = (root.Position - frame.Position).Magnitude
			if d <= Config.Placement.EditRange and (index == own or d < bestDistance) then
				if index == own then
					return own
				end
				best, bestDistance = index, d
			end
		end
	end
	return best
end

local function arena()
	local folder = baseFolder()
	local frame = folder and folder:GetAttribute("ArenaFrame")
	if typeof(frame) ~= "CFrame" then
		return nil
	end
	return frame, folder:GetAttribute("DefenseUnitTop") or 0, folder
end

local function rootNear()
	local frame = arena()
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	return frame ~= nil and root ~= nil and humanoid ~= nil and humanoid.Health > 0
		and (root.Position - frame.Position).Magnitude <= Config.Placement.EditRange
end

local function middle()
	local b = Config.Defense.MapBounds
	return Vector3.new(0, 0, (b.ZBack + b.ZFront) / 2)
end

local function height(camera)
	local b = Config.Defense.MapBounds
	local halfX, halfZ = b.X, (b.ZBack - b.ZFront) / 2
	local vertical = math.abs(up.Z) > 0.5
	local halfV, halfH = vertical and halfZ or halfX, vertical and halfX or halfZ
	local t = math.tan(math.rad(camera.FieldOfView) / 2)
	local aspect = camera.ViewportSize.X / math.max(camera.ViewportSize.Y, 1)
	return math.max(halfV / t, halfH / (t * aspect)) * FIT_MARGIN * zoom
end

local function clampPan(p)
	local b = Config.Defense.MapBounds
	local m = middle()
	local camera = Workspace.CurrentCamera
	local seenV = camera and height(camera) * math.tan(math.rad(camera.FieldOfView) / 2) or 0
	local seenH = camera and seenV * camera.ViewportSize.X / math.max(camera.ViewportSize.Y, 1) or 0
	local vertical = math.abs(up.Z) > 0.5
	local moreX = math.min((vertical and seenH or seenV) * PAN_BEYOND, PAN_BEYOND_MAX)
	local moreZ = math.min((vertical and seenV or seenH) * PAN_BEYOND, PAN_BEYOND_MAX)
	return Vector3.new(math.clamp(p.X, -b.X - moreX, b.X + moreX), 0,
		math.clamp(p.Z, b.ZFront - m.Z - moreZ, b.ZBack - m.Z + moreZ))
end

local function goal(camera)
	local frame, top = arena()
	if not frame then
		return nil
	end
	local d = height(camera)
	local target = middle() + pan + Vector3.new(0, top, 0)
	local eye = target - up * (d * math.sin(TILT)) + Vector3.new(0, d * math.cos(TILT), 0)
	return CFrame.lookAt(frame * eye, frame * target)
end

local function hideTitle()
	local title = arenaModel and arenaModel.Parent and arenaModel:FindFirstChild("Title")
	if title and title:IsA("BillboardGui") and title.Enabled then
		title.Enabled = false
		hiddenTitle = title
	end
end

local function step(dt)
	local camera = Workspace.CurrentCamera
	if not camera then
		return
	end
	hideTitle()
	if player:GetAttribute("Cinematic") or not rootNear() or (watching() and not baseFolder():GetAttribute("OwnerUserId")) then
		player:SetAttribute("TopView", nil)
		return
	end
	camera.CameraType = Enum.CameraType.Scriptable
	local want = goal(camera)
	if want then
		camera.CFrame = camera.CFrame:Lerp(want, 1 - math.exp(-EASE * dt))
	end
end

local grown = {}
local function restoreLabels()
	for gui, base in pairs(grown) do
		if gui.Parent then
			gui.Size = base.size
			gui.MaxDistance = base.far
		end
	end
	table.clear(grown)
end

local function growLabels()
	local folder = baseFolder()
	local units = folder and folder:FindFirstChild("DefenseUnits")
	for gui in pairs(grown) do
		if not gui.Parent then
			grown[gui] = nil
		end
	end
	for _, model in ipairs(units and units:GetChildren() or {}) do
		for _, gui in ipairs(model:IsA("Model") and model:GetChildren() or {}) do
			if gui:IsA("BillboardGui") and gui:FindFirstChild("Row1") and not grown[gui] then
				grown[gui] = { size = gui.Size, far = gui.MaxDistance }
				gui.MaxDistance = LABEL_SEE
			end
		end
	end
end

local function caption()
	local folder = baseFolder()
	if watching() then
		local owner = Players:GetPlayerByUserId(folder and folder:GetAttribute("OwnerUserId") or 0)
		words.Text = string.format("👀 %s님의 디펜스 구경 · 밀어서 둘러봐요", owner and owner.DisplayName or "?")
	elseif player:GetAttribute("PlacingUnit") then
		words.Text = "🗺️ 위에서 놓을 곳을 골라요"
	else
		words.Text = "🗺️ 공룡을 눌러 옮겨요 · 밀어서 둘러봐요"
	end
end

local function enter()
	if on then
		return
	end
	viewIndex = player:GetAttribute("PlacingUnit") and player:GetAttribute("Base") or nearBase()
	local frame = arena()
	local camera = Workspace.CurrentCamera
	if not frame or not camera or player:GetAttribute("Cinematic") then
		player:SetAttribute("TopView", nil)
		return
	end
	if not rootNear() then
		player:SetAttribute("TopView", nil)
		Notices.show(nil, "🦖 내 아레나 가까이에서 볼 수 있어요")
		return
	end
	on = true
	player:SetAttribute("TopViewBase", viewIndex or player:GetAttribute("Base"))
	caption()
	local folder = baseFolder()
	arenaModel = folder and folder:FindFirstChild("Base_Arena", true)
	hideTitle()
	local look = frame:VectorToObjectSpace(camera.CFrame.LookVector)
	up = math.abs(look.X) > math.abs(look.Z) and Vector3.new(look.X > 0 and 1 or -1, 0, 0)
		or Vector3.new(0, 0, look.Z > 0 and 1 or -1)
	zoom, pan, press, pinchFrom = 1, Vector3.zero, nil, nil
	savedType = camera.CameraType
	savedView = camera.CFrame
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	savedOffset = root and camera.CFrame.Position - root.Position
	camera.CameraType = Enum.CameraType.Scriptable
	bar.Visible = true
	rotate.Visible = true
	toggle.Text = "🗺️ 탑뷰 끄기"
	toggle.BackgroundColor3 = COLOR_TOGGLE_OFF
	mark.Adornee = player.Character
	mark.Enabled = true
	RunService:BindToRenderStep("TopView", Enum.RenderPriority.Camera.Value + 1, FrameMeter.wrap("TopView", step))
	enteredAt = (not watching() and not player:GetAttribute("PlacingUnit")) and os.clock() or nil
end

local function leave()
	if not on then
		return
	end
	on = false
	restoreLabels()
	if enteredAt and os.clock() - enteredAt >= Config.StarterMissions.TopViewLook then
		Net.request("TopViewUsed")
	end
	enteredAt = nil
	player:SetAttribute("TopViewBase", nil)
	RunService:UnbindFromRenderStep("TopView")
	if hiddenTitle and hiddenTitle.Parent then
		hiddenTitle.Enabled = true
	end
	hiddenTitle, arenaModel = nil, nil
	press, pinchFrom = nil, nil
	bar.Visible = false
	rotate.Visible = false
	toggle.Text = watching() and "👀 구경" or "🗺️ 탑뷰"
	toggle.BackgroundColor3 = COLOR_TOGGLE
	mark.Enabled = false
	mark.Adornee = nil
	local camera = Workspace.CurrentCamera
	if camera and not player:GetAttribute("Cinematic") then
		camera.CameraType = (savedType == nil or savedType == Enum.CameraType.Scriptable) and Enum.CameraType.Custom or savedType
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if savedView and savedOffset and root then
			camera.CFrame = savedView.Rotation + (root.Position + savedOffset)
		elseif savedView then
			camera.CFrame = savedView
		end
	end
	savedView, savedOffset = nil, nil
end

player:GetAttributeChangedSignal("TopView"):Connect(function()
	if player:GetAttribute("TopView") then
		enter()
	else
		leave()
	end
end)
player:GetAttributeChangedSignal("Base"):Connect(function()
	player:SetAttribute("TopView", nil)
end)
player:GetAttributeChangedSignal("PlacingUnit"):Connect(function()
	if on then
		caption()
	end
end)
player.CharacterAdded:Connect(function()
	player:SetAttribute("TopView", nil)
end)
exit.Activated:Connect(function()
	player:SetAttribute("TopView", nil)
end)
rotate.Activated:Connect(function()
	if on then
		up = Vector3.new(-up.Z, 0, up.X)
		press = nil
	end
end)
toggle.Activated:Connect(function()
	player:SetAttribute("TopView", not on or nil)
end)
local sinceToggle = 0
local placedFor = -1
RunService.Heartbeat:Connect(FrameMeter.wrap("TopView", function(dt)
	sinceToggle += dt
	if sinceToggle < TOGGLE_EVERY then
		return
	end
	sinceToggle = 0
	if not on then
		local index = nearBase()
		if index ~= viewIndex then
			viewIndex = index
			toggle.Text = watching() and "👀 구경" or "🗺️ 탑뷰"
		end
	end
	local step = player:GetAttribute("TutorialStep")
	local placing = player:GetAttribute("PlacingUnit") ~= nil
	local show = not placing and (on or (rootNear() and not Windows.anyOpen() and not player:GetAttribute("Cinematic")
		and (not step or step == TUTORIAL_STEP)))
	if show and (not toggle.Visible or ScreenButtons.version() ~= placedFor) then
		placedFor = ScreenButtons.version()
		placeToggle()
	end
	if toggle.Visible ~= show then
		toggle.Visible = show
	end
	Coach.mark(toggle, (on and enteredAt and os.clock() - enteredAt >= Config.StarterMissions.TopViewLook and "TopViewOff")
		or (not on and not watching() and "TopViewOn") or nil)
	if on then
		growLabels()
	end
	local auto = on and not watching() and not placing
	if auto then
		placeAuto()
	end
	if autoButton.Visible ~= auto then
		autoButton.Visible = auto
	end
end))
RunService.RenderStepped:Connect(FrameMeter.wrap("TopView", function()
	if not toggle.Visible then
		return
	end
	local wave = 0.5 + 0.5 * math.sin(os.clock() * SHINE_SPEED)
	shine.Transparency = 1 - wave
	pulse.Scale = on and 1 or 1 + PULSE_GROW * wave
end))

local function groundAt(screen)
	local frame, top = arena()
	local camera = Workspace.CurrentCamera
	if not frame or not camera then
		return nil
	end
	local ray = camera:ScreenPointToRay(screen.X, screen.Y)
	local planeY = (frame * Vector3.new(0, top, 0)).Y
	if math.abs(ray.Direction.Y) < 1e-4 then
		return nil
	end
	local t = (planeY - ray.Origin.Y) / ray.Direction.Y
	return t > 0 and ray.Origin + ray.Direction * t or nil
end

local function pick(screen)
	local hit = groundAt(screen)
	local _, _, folder = arena()
	local units = folder and folder:FindFirstChild("DefenseUnits")
	if not hit or not units then
		return
	end
	local best, bestDistance = nil, math.huge
	for _, model in ipairs(units:GetChildren()) do
		if model:IsA("Model") then
			local cf, size = model:GetBoundingBox()
			local d = Vector2.new(cf.Position.X - hit.X, cf.Position.Z - hit.Z).Magnitude
			if d < math.max(size.X, size.Z) / 2 + TAP_SLACK and d < bestDistance then
				best, bestDistance = model, d
			end
		end
	end
	if best then
		player:SetAttribute("TopViewPick", best.Name)
	end
end

local function inStick(position)
	local camera = Workspace.CurrentCamera
	return camera ~= nil and position.X < camera.ViewportSize.X * STICK_SHARE
		and position.Y > camera.ViewportSize.Y * STICK_TOP
end

local function fingers()
	local n = 0
	for _, free in pairs(touches) do
		if free then
			n += 1
		end
	end
	return n
end

UserInputService.InputBegan:Connect(function(input, processed)
	if input.UserInputType == Enum.UserInputType.Touch then
		touches[input] = not processed and not inStick(input.Position)
	end
	if not on then
		return
	end
	if input.KeyCode == Enum.KeyCode.Escape then
		player:SetAttribute("TopView", nil)
		return
	end
	if processed or player:GetAttribute("PlacingUnit") then
		return
	end
	local touch = input.UserInputType == Enum.UserInputType.Touch
	if not touch and input.UserInputType ~= Enum.UserInputType.MouseButton1 then
		return
	end
	local camera = Workspace.CurrentCamera
	if touch and inStick(input.Position) then
		return
	end
	press = { input = input, start = Vector2.new(input.Position.X, input.Position.Y), moved = false, pan = pan }
end)

UserInputService.InputChanged:Connect(function(input, processed)
	if not on then
		return
	end
	if input.UserInputType == Enum.UserInputType.MouseWheel then
		if not processed then
			zoom = math.clamp(zoom * WHEEL_STEP ^ input.Position.Z, ZOOM_MIN, ZOOM_MAX)
			pan = clampPan(pan)
		end
		return
	end
	if not press or pinchFrom or fingers() > 1 then
		return
	end
	local mouse = press.input.UserInputType == Enum.UserInputType.MouseButton1
		and input.UserInputType == Enum.UserInputType.MouseMovement
	if not mouse and input ~= press.input then
		return
	end
	local moved = Vector2.new(input.Position.X, input.Position.Y) - press.start
	if not press.moved and moved.Magnitude < TAP_PIXELS then
		return
	end
	press.moved = true
	local camera = Workspace.CurrentCamera
	local perPixel = 2 * height(camera) * math.tan(math.rad(camera.FieldOfView) / 2) / math.max(camera.ViewportSize.Y, 1)
	local right = Vector3.new(-up.Z, 0, up.X)
	pan = clampPan(press.pan - right * moved.X * perPixel + up * moved.Y * perPixel)
end)

UserInputService.InputEnded:Connect(function(input)
	touches[input] = nil
	if not press then
		return
	end
	local same = input == press.input or (press.input.UserInputType == Enum.UserInputType.MouseButton1
		and input.UserInputType == Enum.UserInputType.MouseButton1)
	if not same then
		return
	end
	local p = press
	press = nil
	if on and not p.moved and not pinchFrom and not player:GetAttribute("PlacingUnit") and not watching() then
		pick(p.start)
	end
end)

UserInputService.TouchPinch:Connect(function(positions, scale, _, state, processed)
	if state == Enum.UserInputState.End or state == Enum.UserInputState.Cancel then
		pinchFrom = nil
		return
	end
	if not on or processed or player:GetAttribute("PlacingUnit") or fingers() < 2 then
		pinchFrom = nil
		return
	end
	for _, at in ipairs(positions) do
		if inStick(at) then
			pinchFrom = nil
			return
		end
	end
	if state == Enum.UserInputState.Begin or not pinchFrom then
		pinchFrom, press = zoom * scale, nil
	end
	zoom = math.clamp(pinchFrom / math.max(scale, 0.05), ZOOM_MIN, ZOOM_MAX)
	pan = clampPan(pan)
end)
