local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local Lang = require(Shared:WaitForChild("Lang"))
local Notices = require(Shared:WaitForChild("Notices"))
local RarityFx = require(Shared:WaitForChild("RarityFx"))
local Unlock = require(Shared:WaitForChild("Unlock"))

local player = Players.LocalPlayer

local SHOW_HEIGHT = 5
local SIGN_GAP = 1.5
local RING_LIFT = 0.15
local BOARD_BOTTOM = 0.8
local HAND_GAP = 0.5
local POST_WIDTH = 0.3
local POST_INSET = 0.6
local POST_COLOR = Color3.fromRGB(110, 80, 50)
local SPIN = 1
local BOB = 0.4
local BOB_SPEED = 2
local DRAW_DISTANCE = 220
local LOOK_EVERY = 2
local NOTICE_GAP = 1.5
local BOARD_SIZE = Vector2.new(8, 3.2)
local BOARD_THICK = 0.1
local BOARD_PIXELS = 50
local BOARD_MAX_DISTANCE = 200
local PANEL_COLOR = Color3.fromRGB(25, 18, 42)
local PANEL_SEE_THROUGH = 0.12
local PANEL_CORNER = 0.2
local PANEL_EDGE = 3
local PANEL_PAD = 0.05
local TEXT_EDGE = 2
local TITLE_SHARE = 0.38
local SUB_SHARE = 0.24
local GUIDE_SHARE = 0.2
local SUB_COLOR = Color3.fromRGB(255, 255, 255)
local GUIDE_COLOR = Color3.fromRGB(140, 230, 255)
local PROMPT_DISTANCE = 14
local SHIMMER_SPEED = 120
local BAR_BACK = Color3.fromRGB(60, 45, 80)
local BAR_HEIGHT = 0.12
local DEFAULT_COLOR = Color3.fromRGB(255, 215, 90)
local GLOW_FILL = 0.7
local LIGHT_RANGE = 16
local LIGHT_BRIGHTNESS = 2.5
local SPARKLE = "rbxasset://textures/particles/sparkles_main.dds"
local SPARKLE_RATE = 14
local SPARKLE_SIZE = 0.9
local SPARKLE_LIFE = 1.4
local SPARKLE_SPEED = 2
local RING_RADIUS = 3.6
local RING_THICK = 0.25
local RING_SEE_THROUGH = 0.25
local ORBS = 4
local ORB_SIZE = 0.6
local ORB_SPIN = 1.6
local DISC_SEE_THROUGH = 0.8
local PULSE_EVERY = 1.6
local PULSE_GROW = 2.2
local PULSE_SEE_THROUGH = 0.3

local DEX_SKINS = {}
for _, s in ipairs(Config.Slap.Skins) do
	if s.Collection then
		table.insert(DEX_SKINS, s)
	end
end
table.sort(DEX_SKINS, function(a, b)
	return a.Collection < b.Collection
end)

local function nextSkin(count)
	for _, s in ipairs(DEX_SKINS) do
		if s.Collection > count then
			return s
		end
	end
	return nil
end

local function count()
	return player:GetAttribute("CollectionCount") or 0
end

local show = nil

local function drop()
	if show then
		show.model:Destroy()
		show.fx:Destroy()
		show.board:Destroy()
		show = nil
	end
end

local function light()
	return player:GetAttribute("LightMode") == true
end

local function fxPart(parent, shape, color, seeThrough)
	local p = Instance.new("Part")
	p.Shape = shape
	p.Material = Enum.Material.Neon
	p.Color = color
	p.Transparency = seeThrough
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
	p.Parent = parent
	return p
end

local function copyOf(name, color)
	local models = ReplicatedStorage:FindFirstChild("SlapModels")
	local source = models and models:FindFirstChild(name)
	if not source then
		return nil
	end
	local model = Instance.new("Model")
	model.Name = "DexAd_" .. name
	source:Clone().Parent = model
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
		elseif d:IsA("Script") or d:IsA("LocalScript") or d:IsA("ProximityPrompt") then
			d:Destroy()
		end
	end
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position)
	model:ScaleTo(SHOW_HEIGHT / math.max(size.Y, size.X, size.Z, 0.1))
	local glow = Instance.new("Highlight")
	glow.FillColor = color
	glow.FillTransparency = GLOW_FILL
	glow.OutlineColor = color
	glow.OutlineTransparency = 0
	glow.DepthMode = Enum.HighlightDepthMode.Occluded
	glow.Parent = model
	local core = fxPart(model, Enum.PartType.Ball, color, 1)
	core.Size = Vector3.new(SHOW_HEIGHT, SHOW_HEIGHT, SHOW_HEIGHT) * 0.6
	core.CFrame = model:GetPivot()
	if not light() then
		local lamp = Instance.new("PointLight")
		lamp.Color = color
		lamp.Range = LIGHT_RANGE
		lamp.Brightness = LIGHT_BRIGHTNESS
		lamp.Parent = core
	end
	do
		local sparkles = Instance.new("ParticleEmitter")
		sparkles.Texture = SPARKLE
		sparkles.Shape = Enum.ParticleEmitterShape.Sphere
		sparkles.Color = ColorSequence.new(Color3.new(1, 1, 1), color)
		sparkles.LightEmission = 1
		sparkles.Rate = SPARKLE_RATE
		sparkles.Lifetime = NumberRange.new(SPARKLE_LIFE * 0.6, SPARKLE_LIFE)
		sparkles.Speed = NumberRange.new(SPARKLE_SPEED * 0.5, SPARKLE_SPEED)
		sparkles.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.3, SPARKLE_SIZE),
			NumberSequenceKeypoint.new(1, 0) })
		sparkles.Rotation = NumberRange.new(0, 360)
		sparkles.RotSpeed = NumberRange.new(-120, 120)
		sparkles.Parent = core
	end
	return model
end

local function makeFx(center, ringY, color)
	local fx = Instance.new("Model")
	fx.Name = "DexAdFx"
	local flat = CFrame.Angles(0, 0, math.pi / 2)
	local ring = fxPart(fx, Enum.PartType.Cylinder, color, RING_SEE_THROUGH)
	ring.Size = Vector3.new(RING_THICK, RING_RADIUS * 2, RING_RADIUS * 2)
	ring.CFrame = CFrame.new(center.X, ringY, center.Z) * flat
	local disc = fxPart(fx, Enum.PartType.Cylinder, Color3.new(1, 1, 1), DISC_SEE_THROUGH)
	disc.Size = Vector3.new(RING_THICK * 0.5, RING_RADIUS * 1.6, RING_RADIUS * 1.6)
	disc.CFrame = ring.CFrame
	local orbs = {}
	for _ = 1, ORBS do
		local orb = fxPart(fx, Enum.PartType.Ball, Color3.new(1, 1, 1), 0)
		orb.Size = Vector3.new(ORB_SIZE, ORB_SIZE, ORB_SIZE)
		table.insert(orbs, orb)
	end
	local pulse = fxPart(fx, Enum.PartType.Cylinder, color, 1)
	pulse.Size = ring.Size
	pulse.CFrame = ring.CFrame
	fx.Parent = Workspace
	return fx, ring, pulse, orbs
end

local function floorAt(spot, fallback, ignore)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = ignore
	params.RespectCanCollide = true
	local hit = Workspace:Raycast(spot + Vector3.new(0, 20, 0), Vector3.new(0, -60, 0), params)
	return hit and hit.Position.Y or fallback
end

local function flatOf(v)
	return Vector3.new(v.X, 0, v.Z)
end

local function placeOf(spawn, sign, pedestal)
	if sign then
		local front = flatOf(sign.CFrame.LookVector).Unit
		local base = Vector3.new(sign.Position.X, spawn.Position.Y, sign.Position.Z)
		if pedestal then
			return base - flatOf(pedestal.Position - sign.Position), front
		end
		return base + flatOf(sign.CFrame.RightVector).Unit * (sign.Size.X / 2 + SIGN_GAP + RING_RADIUS), front
	end
	local look = flatOf(spawn.CFrame.LookVector)
	look = look.Magnitude > 1e-3 and look.Unit or Vector3.new(0, 0, -1)
	local side = Vector3.yAxis:Cross(look).Unit
	return spawn.Position + side * (math.max(spawn.Size.X, spawn.Size.Z) / 2 + SIGN_GAP + RING_RADIUS), look
end

local function standBoard(spot, front, ground)
	local holder = Instance.new("Model")
	holder.Name = "DexAdSign"
	local middle = Vector3.new(spot.X, ground + BOARD_BOTTOM + BOARD_SIZE.Y / 2, spot.Z)
	local board = Instance.new("Part")
	board.Name = "Board"
	board.Size = Vector3.new(BOARD_SIZE.X, BOARD_SIZE.Y, BOARD_THICK)
	board.CFrame = CFrame.lookAt(middle, middle + front)
	board.Transparency = 1
	board.Anchored, board.CanCollide, board.CanQuery, board.CanTouch, board.CastShadow = true, false, false, false, false
	board.Parent = holder
	for _, x in ipairs({ -BOARD_SIZE.X / 2 + POST_INSET, BOARD_SIZE.X / 2 - POST_INSET }) do
		local post = Instance.new("Part")
		post.Name = "Post"
		post.Size = Vector3.new(POST_WIDTH, BOARD_BOTTOM + BOARD_SIZE.Y / 2, POST_WIDTH)
		post.CFrame = board.CFrame * CFrame.new(x, -(BOARD_SIZE.Y / 2 + BOARD_BOTTOM) / 2, BOARD_THICK + POST_WIDTH / 2)
		post.Color = POST_COLOR
		post.Material = Enum.Material.Wood
		post.Anchored, post.CanCollide, post.CanQuery, post.CanTouch = true, false, false, false
		post.Parent = holder
	end
	holder.Parent = Workspace
	local surface = Instance.new("SurfaceGui")
	surface.Name = "DexAdBoard"
	surface.Face = Enum.NormalId.Front
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = BOARD_PIXELS
	surface.LightInfluence = 0
	surface.MaxDistance = BOARD_MAX_DISTANCE
	surface.Adornee = board
	surface.Parent = board
	return holder, surface
end

local function textLabel(parent, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = Enum.Font.GothamBlack
	l.TextScaled = true
	l.TextColor3 = color
	l.TextStrokeTransparency = 1
	local edge = Instance.new("UIStroke")
	edge.Thickness = TEXT_EDGE
	edge.Color = Color3.new(0, 0, 0)
	edge.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
	edge.Parent = l
	l.Parent = parent
	return l
end

local function refreshBoard()
	if not show then
		return
	end
	local n, skin = count(), show.skin
	Lang.set(show.title, string.format("👋 %s 스킨 무료!", skin.Name))
	Lang.set(show.text, string.format("📖 도감 %d/%d 모으면 받아요", n, skin.Collection))
	show.fill.Size = UDim2.fromScale(math.clamp(n / skin.Collection, 0, 1), 1)
end

local function build(spawn, sign, pedestal, skin)
	drop()
	local color = RarityFx.color(skin.Grade) or DEFAULT_COLOR
	local model = copyOf(skin.Model, color)
	if not model then
		return
	end
	model.Parent = Workspace
	local spot, front = placeOf(spawn, sign, pedestal)
	local toSpawn = flatOf(spawn.Position - spot)
	if toSpawn.Magnitude > 1e-3 then
		front = toSpawn.Unit
	end
	local ignore = { model }
	for _, other in ipairs(Players:GetPlayers()) do
		if other.Character then
			table.insert(ignore, other.Character)
		end
	end
	if sign then
		table.insert(ignore, sign.Parent)
	end
	local ground = floorAt(spot, spawn.Position.Y - spawn.Size.Y / 2, ignore)
	local center = Vector3.new(spot.X, ground + BOARD_BOTTOM + BOARD_SIZE.Y + HAND_GAP + SHOW_HEIGHT / 2, spot.Z)
	local fx, ring, pulse, orbs = makeFx(center, ground + RING_LIFT, color)
	local board, surface = standBoard(spot, front, ground)
	local panel = Instance.new("Frame")
	panel.AnchorPoint = Vector2.new(0.5, 0.5)
	panel.Position = UDim2.fromScale(0.5, 0.5)
	panel.Size = UDim2.fromScale(1, 1)
	panel.BackgroundColor3 = PANEL_COLOR
	panel.BackgroundTransparency = PANEL_SEE_THROUGH
	panel.Parent = surface
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(PANEL_CORNER, 0)
	corner.Parent = panel
	local edge = Instance.new("UIStroke")
	edge.Thickness = PANEL_EDGE
	edge.Color = Color3.new(1, 1, 1)
	edge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	edge.Parent = panel
	local shimmer = Instance.new("UIGradient")
	shimmer.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, color), ColorSequenceKeypoint.new(0.45, color),
		ColorSequenceKeypoint.new(0.5, Color3.new(1, 1, 1)), ColorSequenceKeypoint.new(0.55, color), ColorSequenceKeypoint.new(1, color) })
	shimmer.Parent = edge
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft, pad.PaddingRight = UDim.new(PANEL_PAD, 0), UDim.new(PANEL_PAD, 0)
	pad.PaddingTop, pad.PaddingBottom = UDim.new(PANEL_PAD, 0), UDim.new(PANEL_PAD, 0)
	pad.Parent = panel
	local title = textLabel(panel, color:Lerp(Color3.new(1, 1, 1), 0.35))
	title.Size = UDim2.fromScale(1, TITLE_SHARE)
	local text = textLabel(panel, SUB_COLOR)
	text.Position = UDim2.fromScale(0, TITLE_SHARE)
	text.Size = UDim2.fromScale(1, SUB_SHARE)
	local guide = textLabel(panel, GUIDE_COLOR)
	guide.Position = UDim2.fromScale(0, TITLE_SHARE + SUB_SHARE)
	guide.Size = UDim2.fromScale(1, GUIDE_SHARE)
	guide.Text = "🎒 받으면 인벤토리 → 👋 스킨에서 껴요"
	local prompt = Instance.new("ProximityPrompt")
	prompt.ActionText = "🎒 인벤토리 열기"
	prompt.ObjectText = "👋 스킨"
	prompt.HoldDuration = 0
	prompt.RequiresLineOfSight = false
	prompt.MaxActivationDistance = PROMPT_DISTANCE
	prompt.Parent = surface.Adornee
	prompt.Triggered:Connect(function()
		player:SetAttribute("OpenInventory", "skins")
	end)
	local back = Instance.new("Frame")
	back.AnchorPoint = Vector2.new(0.5, 1)
	back.Position = UDim2.fromScale(0.5, 1)
	back.Size = UDim2.fromScale(0.9, BAR_HEIGHT)
	back.BackgroundColor3 = BAR_BACK
	back.BorderSizePixel = 0
	back.Parent = panel
	local fill = Instance.new("Frame")
	fill.BackgroundColor3 = color
	fill.BorderSizePixel = 0
	fill.Parent = back
	for _, f in ipairs({ back, fill }) do
		local c = Instance.new("UICorner")
		c.CornerRadius = UDim.new(0.5, 0)
		c.Parent = f
	end
	local barEdge = Instance.new("UIStroke")
	barEdge.Thickness = 1.5
	barEdge.Color = Color3.new(1, 1, 1)
	barEdge.Parent = back
	show = { skin = skin, spawn = spawn, sign = sign, pedestal = pedestal, model = model, fx = fx, ring = ring, pulse = pulse, orbs = orbs, board = board,
		title = title, text = text, fill = fill, shimmer = shimmer, center = center }
	refreshBoard()
end

local function look()
	local skin = nextSkin(count())
	local map = Workspace:FindFirstChild("Map")
	local folder = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	local spawn = folder and folder:FindFirstChild("SpawnLocation", true)
	local signModel = folder and folder:FindFirstChild("RebirthSign")
	local sign = signModel and signModel:FindFirstChild("Board")
	local pedestalModel = folder and folder:FindFirstChild("MountPedestal")
	local pedestal = pedestalModel and pedestalModel:FindFirstChild("Pedestal")
	if not skin or not spawn or not spawn:IsA("BasePart") or not Unlock.usable("Enhance") then
		drop()
		return
	end
	if not show or show.skin ~= skin or show.spawn ~= spawn or show.sign ~= sign or show.pedestal ~= pedestal
		or not show.model.Parent or show.light ~= light() then
		build(spawn, sign, pedestal, skin)
		if show then
			show.light = light()
		end
	end
end

task.spawn(function()
	while true do
		local ok, err = pcall(look)
		if not ok then
			warn("[DexAd] " .. tostring(err))
		end
		task.wait(LOOK_EVERY)
	end
end)

local seen = player:GetAttribute("CollectionCount")
local pending = 0
player:GetAttributeChangedSignal("CollectionCount"):Connect(function()
	local n = count()
	task.defer(look)
	refreshBoard()
	if seen == nil then
		seen = n
		return
	end
	local gained = n - seen
	seen = n
	if gained <= 0 then
		return
	end
	pending += gained
	if pending > gained then
		return
	end
	task.delay(NOTICE_GAP, function()
		local got = pending
		pending = 0
		local skin = nextSkin(count())
		if skin then
			Notices.show(string.format("📖 도감 +%d", got), string.format("📖 %d/%d · 👋 %s 스킨까지 %d개 남았어요!", count(),
				skin.Collection, skin.Name, skin.Collection - count()))
		end
	end)
end)

RunService.Heartbeat:Connect(FrameMeter.wrap("DexAd", function()
	if not show then
		return
	end
	local camera = Workspace.CurrentCamera
	local eye = camera and camera.CFrame.Position
	if not eye or (show.center - eye).Magnitude > DRAW_DISTANCE then
		return
	end
	local t = os.clock()
	show.model:PivotTo(CFrame.new(show.center + Vector3.new(0, math.sin(t * BOB_SPEED) * BOB, 0)) * CFrame.Angles(0, t * SPIN, 0))
	local flat = CFrame.Angles(0, 0, math.pi / 2)
	local at = show.ring.Position
	for i, orb in ipairs(show.orbs) do
		local angle = t * ORB_SPIN + (i - 1) * 2 * math.pi / #show.orbs
		orb.Position = at + Vector3.new(math.cos(angle) * RING_RADIUS, 0, math.sin(angle) * RING_RADIUS)
	end
	local k = (t % PULSE_EVERY) / PULSE_EVERY
	local size = show.ring.Size
	show.pulse.Size = Vector3.new(size.X, size.Y * (1 + (PULSE_GROW - 1) * k), size.Z * (1 + (PULSE_GROW - 1) * k))
	show.pulse.CFrame = CFrame.new(at) * flat
	show.pulse.Transparency = PULSE_SEE_THROUGH + (1 - PULSE_SEE_THROUGH) * k
	show.shimmer.Rotation = (t * SHIMMER_SPEED) % 360
end))
