local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Notices = require(Shared:WaitForChild("Notices"))
local CocoVoice = require(Shared:WaitForChild("CocoVoice"))
local Unlock = require(Shared:WaitForChild("Unlock"))

local player = Players.LocalPlayer

local CHECK_EVERY = 5
local PULSE_SECONDS = 8
local PULSE_SPEED = 8
local PULSE_COLOR = Color3.fromRGB(255, 230, 90)
local PULSE_THICKNESS = 3
local PRIZE_PARTS = 2

local N = Config.Hints.PromoNudge
local shown = 0
local quietSince = os.clock()

local function promoButton()
	local top = player.PlayerGui:FindFirstChild("TopBar")
	return top and top:FindFirstChild("PromoButton", true)
end

local function pulse()
	local b = promoButton()
	if not b then
		return
	end
	local old = b:FindFirstChild("NudgeStroke")
	if old then
		old:Destroy()
	end
	local stroke = Instance.new("UIStroke")
	stroke.Name = "NudgeStroke"
	stroke.Color = PULSE_COLOR
	stroke.Thickness = PULSE_THICKNESS
	stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	stroke.Parent = b
	local started = os.clock()
	task.spawn(function()
		while stroke.Parent and os.clock() - started < PULSE_SECONDS and not player:GetAttribute("PromoLevel") do
			stroke.Transparency = 0.5 - 0.5 * math.sin((os.clock() - started) * PULSE_SPEED)
			RunService.Heartbeat:Wait()
		end
		stroke:Destroy()
	end)
end

local function quiet()
	quietSince = os.clock()
end
player:GetAttributeChangedSignal("PromoLevel"):Connect(quiet)
player:GetAttributeChangedSignal("DefenseLevel"):Connect(quiet)

local function ready()
	local level = player:GetAttribute("DefenseLevel")
	if not level or level >= N.UntilLevel or level >= Formulas.maxDefenseLevel(player:GetAttribute("Rebirths") or 0) then
		return false
	end
	if (player:GetAttribute("DefensePlaced") or 0) <= 0 or player:GetAttribute("HideTips") or not Unlock.shown("Base_Arena") then
		return false
	end
	if (player:GetAttribute("PromoRetryAt") or 0) > Workspace:GetServerTimeNow() then
		return false
	end
	if player:GetAttribute("PromoLevel") or player:GetAttribute("CocoIntro") or player:GetAttribute("FirstFight")
		or player:GetAttribute("TutorialStep") or player:GetAttribute("Cinematic") then
		return false
	end
	local minutes = shown == 0 and N.FirstMinutes or N.EveryMinutes
	return os.clock() - quietSince >= minutes * 60
end

task.spawn(function()
	while shown < N.Times do
		task.wait(CHECK_EVERY)
		if ready() then
			shown += 1
			quiet()
			local parts = Formulas.promotionPrizeParts((player:GetAttribute("DefenseLevel") or 1) + 1)
			local text = #parts > 0 and string.format("⚔️ 보스 도전 해 볼까? 이기면 %s",
				table.concat(parts, " · ", 1, math.min(#parts, PRIZE_PARTS))) or "⚔️ 보스 도전 해 볼까? 위의 ⚔️ 버튼!"
			Notices.show("🐣 코코", text)
			CocoVoice.babble(text)
			pulse()
		end
	end
end)
