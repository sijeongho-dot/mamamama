--[[
Zombies: draws the zombie dinos on this screen (the server's Zombies service decides where they are
and whom they hit; Workspace.Zombies holds one Configuration per zombie).

- Each wears the cute zombie dino (ReplicatedStorage.DinoModels.Dino_Zombie: sleepy half-closed eyes,
  patchy mint skin, stitches, a plaster on its head); without it, its species' model turned rotten
  (grey-green). A soft green glow and haze around it. It glides smoothly to the latest spot the server sent (P, H) and
  walks its legs with Shared/DinoMotion.
- "Rising" (RiseSeconds): a dirt mound bulges up, the snout pokes out pointing at the sky, it claws
  its way up in little jerks with its legs paddling, then pops out with a hop and shakes the dirt off
  (ZombieRise: the ground cracking, then "uh!"). "Sinking" (SinkSeconds): a sleepy shrug, then it spins
  down nose first into the mound, which closes over it (ZombieSink). "Under"/"Waiting": not drawn.
- Walking it shambles, rocking side to side.
- AttackAt: a lunge with the jaw open and its moan; the player hit (HitUserId) gets a soft bonk
  (ZombieHit) and their "oof". Now and then an idle, sleepy "uuuh~" (ZombieGroan).
- The night's boss (attribute Boss): BossScale times as big (its stage), a purple glow, a deep
  voice, seen from much farther, a purple light pillar over it so it can be found across the
  battlefield, and a "👑 보스 좀비" health bar (BossHP / BossMaxHP). Slapped (BossHitAt) it flashes
  and grunts; slapped down (DefeatedAt) it bursts in purple and sinks.
- Boss kinds (BossModel: Dino_ZombieRex / Dino_ZombieTrike / Dino_ZombiePtera in its own colors; BossHover:
  the pterosaur flies that high, flapping and gliding). Net push BossFx shows its big attack: "Roar" (it
  rears up and roars, then a purple shockwave ring sweeps out to the radius), "Charge" (a red stripe on the
  ground shows where it will charge while it paws the ground, then dust as it runs), "Bomb" (a dark
  shadow grows where a big dropping falls from it; a splat and a burst where it lands).
- The aurora boss (Configuration "AuroraBoss", attribute Aurora): the same, in the aurora's green glow,
  seen from even farther. Net push BossFx names the boss it is for.
- A player's slap (KnockAt): the zombie tumbles through the air in an arc to where the server put it
  (P), lands in a puff of dust, then lies on its side, dizzy and wriggling, until StunUntil.
- Speech bubbles, short (2026-10-01): a slapped zombie cries "아야!" and the like; a boss says a word now
  and then at its groans, sometimes "으윽!" when slapped, a line with each big attack and when it goes
  down; the aurora boss's lines are about the aurora (OUCH_LINES, BOSS_LINES, AURORA_LINES).
- (2026-10-02) A zombie now and then grumbles about the weather (WEATHER_LINES). Held by a poop bomb
  (PoopUntil) a zombie or boss stands buried in a poop pile like a player hit by one (Shared/PoopPile),
  grown to its size, till it is free (a splat). Struck by lightning (Lightning service: KnockAt) it
  flies like a slapped one.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TextService = game:GetService("TextService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local DinoMotion = require(Shared:WaitForChild("DinoMotion"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Lod = require(Shared:WaitForChild("Lod"))
local Fx = require(Shared:WaitForChild("Fx"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local PoopPile = require(Shared:WaitForChild("PoopPile"))

-- display only
local HEIGHT = 5.5 -- a zombie dino's height
local LENGTH = 11
local SKIN = Color3.fromRGB(110, 135, 100)
local SKIN_DARK = Color3.fromRGB(80, 95, 75)
local GLOW = Color3.fromRGB(120, 255, 120)
local FOLLOW = 5 -- how fast a drawn zombie catches up with the server's spot (per second; spots come every 0.3 s)
local DRAW_DISTANCE = 400
local DIRT = { Color3.fromRGB(110, 80, 50), Color3.fromRGB(80, 60, 40) }
local GROAN_EVERY = { 6, 16 }
local GROAN_DISTANCE = 70
local MOUND_RADIUS, MOUND_HEIGHT, MOUND_CLODS = 2.6, 0.7, 6 -- the dirt mound over its hole
local LEG_PADDLE = 14 -- the legs' walking speed while it claws in or out of the ground
local HOP_HEIGHT = 0.8 -- the little hop as it pops out
local SINK_SPIN = math.pi * 3 -- turns one and a half times going down
local SHAMBLE_ROLL, SHAMBLE_SPEED = 0.14, 5.5 -- rocking side to side as it walks
-- Map folders a zombie never stands on (only before the server gives its height, attribute Y)
local NOT_GROUND = { "Decor", "FieldDecor", "FieldGrass", "SafeGrass", "BattlefieldFlags" }
-- (2026-10-01) the height the server keeps each zombie at (attribute Y: the ground, or up where it jumped
-- after a player): a rise of more than JUMP_MIN studs is a jump (Config.Zombies.JumpSeconds long, at
-- least JUMP_ARC × its size over the line, JUMP_ARC_SHARE of the rise for a big one); going down it drops
local JUMP_MIN = 1.5
local JUMP_ARC = 3
local JUMP_ARC_SHARE = 0.3
local FALL_FOLLOW = 12 -- how fast it follows a lower height (1/seconds)
local KNOCK_ARC_SHARE = 0.35
local KNOCK_ARC_MIN, KNOCK_ARC_MAX = 2, 9
local ZOMBIE_YELP_PITCH = 0.85 -- its squeal (Sfx DinoYelp), a little lower than a wild one's
local KNOCK_TUMBLE = math.pi * 2 -- one somersault in the air
local DIZZY_ROLL, DIZZY_WOBBLE = 1.35, 0.12 -- lying on its side, wriggling
local DUST = { Color3.fromRGB(200, 190, 160), Color3.fromRGB(160, 150, 120) }
local BOSS_GLOW = Color3.fromRGB(190, 120, 255)
local BOSS_DEFAULT_SCALE = 2.4 -- until the server says its stage (BossScale)
local BOSS_DRAW_DISTANCE = 1200
local BOSS_VOICE = 0.6 -- its groans' pitch: deep
local BOSS_BAR_SIZE = UDim2.fromOffset(180, 36) -- (was 220 × 46)
local BOSS_BAR_TEXT = 14
local BOSS_BAR_COLOR = Color3.fromRGB(190, 110, 255)
local BOSS_PILLAR_HEIGHT, BOSS_PILLAR_WIDTH = 160, 3
local BOSS_FLASH_SECONDS = 0.25
local ROAR_RING_COLOR = Color3.fromRGB(200, 130, 255)
local ROAR_RING_SECONDS = 0.45
local CHARGE_STRIPE_COLOR = Color3.fromRGB(255, 70, 70)
local CHARGE_STRIPE_WIDTH = 6
local BOMB_COLOR = Color3.fromRGB(110, 80, 50)
local BOMB_SHADOW_COLOR = Color3.fromRGB(20, 15, 10)
local BOMB_SIZE = 3.5
local SPLAT = { Color3.fromRGB(120, 90, 55), Color3.fromRGB(90, 140, 70) }
local AURORA_GLOW = Color3.fromRGB(110, 255, 200) -- the aurora boss: its glow, outline, bar and pillar
local AURORA_DRAW_DISTANCE = 1600
local BOSS_BURST = { Color3.fromRGB(190, 120, 255), Color3.fromRGB(255, 220, 120), Color3.fromRGB(140, 220, 140) }
-- speech bubbles (2026-10-01, "a zombie slapped says 아야! in a bubble", "the bosses talk now and then", "the
-- aurora one about the aurora", "all of them short")
-- my hit on a boss paid (Net push BossHitMoney): "+n원 💰" rising over it (2026-10-01)
local HIT_MONEY_SECONDS = 1.2
local HIT_MONEY_RISE = 6 -- studs it floats up
local HIT_MONEY_START = 4 -- studs over where it was hit
local HIT_MONEY_SIZE = UDim2.fromOffset(150, 36)
local HIT_MONEY_COLOR = Color3.fromRGB(255, 220, 80)
local SAY_SECONDS = 1.6
local SAY_GAP = 0.8 -- studs over the top of its head
-- (2026-10-01, "the lines should be in speech bubbles") a white rounded bubble with a little tail under it,
-- its edge in the speaker's color, as wide as its words
local SAY_TEXT, SAY_TEXT_BOSS = 15, 20 -- text size
local SAY_PAD = Vector2.new(14, 8) -- inside the bubble, round the words
local SAY_MAX_WIDTH = 220 -- longer lines wrap
local SAY_TAIL = 10 -- the tail's size (pixels)
local SAY_DISTANCE = 90
local SAY_DISTANCE_BOSS = 260
local SAY_FILL = Color3.fromRGB(255, 255, 255)
local SAY_INK = Color3.fromRGB(35, 35, 50)
local SAY_COLOR = Color3.fromRGB(120, 200, 110) -- the edge: a zombie's green
local SAY_COLOR_BOSS = Color3.fromRGB(170, 110, 230)
local SAY_COLOR_AURORA = Color3.fromRGB(60, 200, 170)
local SAY_POP = 0.18 -- seconds to pop up
local BOSS_TALK_CHANCE = 0.45 -- at each of its groans
-- (2026-10-02) a plain zombie now and then grumbles about the weather, at its groans
-- held by a poop bomb (attribute PoopUntil): buried in a poop pile like a player (Shared/PoopPile, made for a
-- player's height and width); a zombie's pile is grown to cover it
local PILE_HEIGHT, PILE_WIDTH = 5, 4.6
local PILE_COVER_WIDTH = 0.7 -- share of its length the pile's base covers (its tail may stick out)
local WEATHER_TALK_CHANCE = 0.12
local WEATHER_LINES = {
	Clear = { "햇빛… 졸려…", "너무 밝아…" },
	Rain = { "비… 싫어…", "축축해…" },
	Storm = { "번개 무서워…", "으… 찌릿찌릿" },
	RainbowSky = { "무지개 눈부셔…", "알록달록 싫어…" },
	Aurora = { "빛이다… 힘이 난다…", "오로라… 좋아…" },
}
local BOSS_OUCH_CHANCE = 0.4 -- when slapped (not every slap: a crowd slaps it a lot)
local BOSS_OUCH_GAP = 3 -- seconds at least between its "ouch"es
local OUCH_LINES = { "아야!", "으악!", "아파~", "끄앙!", "히잉!" }
local BOSS_LINES = {
	talk = { "크르르…", "다 덤벼!", "배고파…", "내 밤이다!", "상자 내놔!" },
	ouch = { "으윽!", "감히?!", "간지러워!", "제법인데?" },
	down = { "내일 보자…" },
	Roar = { "크아앙!" }, Charge = { "비켜라!" }, Bomb = { "받아라~" },
}
local AURORA_LINES = {
	talk = { "오로라는 내 거!", "하늘이 빛나~", "초록빛 힘이다!", "빛을 지켜라!" },
	ouch = { "내 오로라가!", "빛이 흔들려!", "반짝 아파!" },
	down = { "빛이 꺼진다…" },
	Roar = { "오로라 폭풍!" }, Charge = { "빛처럼 간다!" }, Bomb = { "별똥 받아라!" },
}

-- (2026-10-04) 🦝 the key thieves (attribute Thief): a wild raptor in its own colors, no
-- zombie glow, a gold outline, a sign over it "🦝 열쇠 도둑" and the keys it carries (Loot); its own squeaks and lines
local THIEF_OUTLINE = Color3.fromRGB(255, 205, 60)
local THIEF_SIGN_SIZE = UDim2.fromScale(10.7, 3.3)
local THIEF_SIGN_UP = 2 -- studs over its head
local THIEF_SIGN_DISTANCE = 260
local THIEF_VOICE = 1.35 -- its squeaks' pitch: high
local THIEF_TALK_CHANCE = 0.5 -- at each of its "groans" (a giggle instead)
-- (2026-10-04, "얘네 잡아서 키 훔쳐가는 것도 쫄깃하게 재미로") a thief running off with keys: its sign seen from afar and
-- the seconds before it digs away (EscapeAt), red the last THIEF_HURRY; slapped with keys (CaughtAt): a gold burst
local THIEF_LOOT_DISTANCE = 400
-- (2026-10-04, "도둑이 계속 끊기듯이 도망가니까 잡을수가 없잖아 왜매끄럽게 못만드는거야") a thief's spots come every
-- server tick with their server time (PT): it is played back THIEF_PLAYBACK_DELAY seconds behind, straight between two
-- spots at their own pace (the zombies' glide toward the latest spot ran fast, then slow, then jumped: jerky at its
-- speed). A spot after a still spell (THIEF_GAP) starts from where it stood
local THIEF_PLAYBACK_DELAY = 0.15
local THIEF_SNAPS = 6
local THIEF_GAP = 0.25
local THIEF_FOLLOW = 25 -- (a light smoothing on top)
local PLAY_AHEAD = 0.25
local PLAY_SETTLE = 0.3
local PLAY_MARGIN = 0.05
local PLAY_MOST = 0.7
local PLAY_DECAY = 0.05
local PLAY_ADJUST = 2
local FACE_SPEED = 2
local THIEF_TURN = 10 -- how fast it turns to its heading (the zombies: FOLLOW)
local THIEF_HURRY = 3
local THIEF_HURRY_COLOR = Color3.fromRGB(255, 90, 80)
local THIEF_BEAM_HEIGHT, THIEF_BEAM_WIDTH = 180, 2.5
local THIEF_BEAM_COLOR = Color3.fromRGB(125, 110, 70)
local THIEF_BEAM_TRANSPARENCY = 0.5
-- (2026-10-04) the better keys a thief carries, shown before its count; the line in gold when it has any
local THIEF_KEY_MARKS = { King = "👑", Silver = "🥈", Gold = "🥇", Ruby = "❤️", Diamond = "💎", Rainbow = "🌈" }
local THIEF_SPECIAL_COLOR = Color3.fromRGB(255, 215, 70)
local SUPER_COLOR = Color3.fromRGB(255, 225, 60)
local SUPER_FILL = 0.55
local SUPER_SIGN_DISTANCE = 1200
local SUPER_SPARKS = 30
local SUPER_KEY_MATERIALS = { Ruby = Enum.Material.Glass, Diamond = Enum.Material.Glass, Rainbow = Enum.Material.Neon }
local SUPER_KEY_RAINBOW_SECONDS = 2
local SPARKLE = "rbxasset://textures/particles/sparkles_main.dds"
local THIEF_CAUGHT_BURST = { Color3.fromRGB(255, 215, 90), Color3.fromRGB(255, 245, 190), Color3.fromRGB(255, 170, 60) }
local SUPER_DASH_BURST = { Color3.fromRGB(255, 230, 120), Color3.fromRGB(255, 255, 220) }
local SUPER_DASH_LINES = { "⚡ 슝~ 못 잡지롱!", "⚡ 어림없지!", "⚡ 휙!" }
local THIEF_LINES = {
	talk = { "히히~ 열쇠 내 거!", "잡아 봐라~", "반짝반짝 열쇠!", "메롱~" },
	ouch = { "내 열쇠!!", "으앙 들켰다!", "아야!" },
	steal = { "내 거다~!", "히히 고마워!", "열쇠 냠!" },
	caught = { "으앙 내 열쇠!!", "안 돼~ 다 쏟아졌어!", "에잇 들켰다!" },
	run = { "못 잡지롱~", "메롱메롱~", "히히 빠르지?" },
}

local GUARD_OUTLINE = Color3.fromRGB(90, 170, 255)
local GUARD_CHASE_COLOR = Color3.fromRGB(255, 90, 80)
local GUARD_LINES = {
	talk = { "상자는 제단 거야!", "내가 지킨다!", "제단 지키기 중~", "반짝 상자 지켜!" },
	chase = { "거기 서라~!", "상자 두고 가!", "멈춰멈춰!" },
	ouch = { "아야! 그래도 지킨다!", "으앗 어지러워!", "반칙이야~!" },
	caught = { "잡았다! 제단으로 돌려놓을게!", "상자는 제단에!", "히히 돌려받았다!" },
}

local camera = Workspace.CurrentCamera
local drawn = {} -- [Configuration] = { model, rig, x, z, h, ground, lastAttack, nextGroan, height }

local function groundAt(x, z)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	local ignore = { Workspace:FindFirstChild("Zombies") }
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	local sky = Workspace:FindFirstChild("ZombieModels")
	if sky then
		table.insert(ignore, sky)
	end
	local map = Workspace:FindFirstChild("Map")
	for _, name in ipairs(NOT_GROUND) do
		local f = map and map:FindFirstChild(name)
		if f then
			table.insert(ignore, f)
		end
	end
	for _, name in ipairs({ "TreasureChests", "RideMounts" }) do
		local f = Workspace:FindFirstChild(name)
		if f then
			table.insert(ignore, f)
		end
	end
	params.FilterDescendantsInstances = ignore
	params.RespectCanCollide = true
	local hit = Workspace:Raycast(Vector3.new(x, 200, z), Vector3.new(0, -400, 0), params)
	return hit and hit.Position.Y or 0
end

local folder = Instance.new("Folder")
folder.Name = "ZombieModels"
folder.Parent = Workspace

local warnedModels = {} -- boss models found missing (warned once)
local function makeModel(species, isBoss, bossModel, aurora, thief, super, guardian) -- isBoss: the boss's scale, or nil; bossModel: its kind's model
	local models = ReplicatedStorage:FindFirstChild("DinoModels")
	if thief then -- (2026-10-04) 🦝 the key thief: the wild raptor in its own colors
		bossModel = super and models and models:FindFirstChild(Config.Zombies.SuperThief.Model, true)
			and Config.Zombies.SuperThief.Model or Config.Zombies.Guardians.Model
	end
	local superOwn = super and bossModel == Config.Zombies.SuperThief.Model
	-- the boss kind's own model, or (the others) the cute zombie dino, in their own colors; found anywhere
	-- inside DinoModels. A boss without its own model is its living species turned rotten (not the
	-- T-Rex-shaped zombie dino: a pterosaur boss must look like one)
	local own = models and (bossModel and models:FindFirstChild(bossModel, true)
		or not isBoss and not thief and models:FindFirstChild(Config.Zombies.Model, true))
	if thief and not own and models then -- (its own model not imported yet: the wild raptor, in its own colors)
		own = models:FindFirstChild(Config.Zombies.Guardians.FallbackModel, true)
	end
	if isBoss and bossModel and not own and not warnedModels[bossModel] then
		warnedModels[bossModel] = true
		warn(string.format("[Zombies] %s 모델이 없어 %s 모델을 썩은 색으로 대신 씁니다 (ServerStorage.Assets에 넣어 주세요)",
			bossModel, species))
	end
	local source = own or (models and models:FindFirstChild("Dino_" .. species))
	local model = Instance.new("Model")
	model.Name = "Zombie"
	if source then
		source:Clone().Parent = model
	else
		local p = Instance.new("Part")
		p.Size = Vector3.new(2.4, 3, 5)
		p.Parent = model
	end
	local first = nil
	for i, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
			if not own then -- a living species' model turned rotten
				d.Color = i % 3 == 0 and SKIN_DARK or SKIN
				d.Material = Enum.Material.Slate
				if d:IsA("MeshPart") then
					pcall(function()
						d.TextureID = ""
					end)
				end
			end
			first = first or d
		elseif not own and (d:IsA("SurfaceAppearance") or d:IsA("Decal") or d:IsA("Texture")) then
			d:Destroy()
		end
	end
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
	local scale = isBoss or (superOwn and Config.Zombies.SuperThief.ModelScale) or (super and Config.Zombies.SuperThief.Scale) or 1
	model:ScaleTo(scale * math.min(HEIGHT / math.max(size.Y, 0.1), LENGTH / math.max(size.X, size.Z, 0.1)))
	local glow = aurora and AURORA_GLOW or isBoss and BOSS_GLOW or GLOW
	if first and thief then
		local outline = Instance.new("Highlight")
		outline.FillTransparency = super and not superOwn and SUPER_FILL or 1
		outline.FillColor = SUPER_COLOR
		outline.OutlineColor = super and SUPER_COLOR or guardian and GUARD_OUTLINE or THIEF_OUTLINE
		outline.DepthMode = Enum.HighlightDepthMode.Occluded
		outline.Parent = model
		if super then
			local sparks = Instance.new("ParticleEmitter")
			sparks.Texture = SPARKLE
			sparks.Color = ColorSequence.new(SUPER_COLOR)
			sparks.LightEmission = 1
			sparks.Rate = SUPER_SPARKS
			sparks.Lifetime = NumberRange.new(0.8, 1.3)
			sparks.Speed = NumberRange.new(1, 3)
			sparks.SpreadAngle = Vector2.new(180, 180)
			sparks.Size = NumberSequence.new(0.7, 0)
			sparks.Parent = first
		end
	elseif first then
		local light = Instance.new("PointLight")
		light.Color = glow
		light.Range = 10 * scale
		light.Brightness = 1.5
		light.Parent = first
		local haze = Instance.new("ParticleEmitter")
		haze.Rate = 4
		haze.Lifetime = NumberRange.new(1.2, 2)
		haze.Speed = NumberRange.new(0.5, 1.5)
		haze.Size = NumberSequence.new(1.2 * scale, 2.4 * scale)
		haze.Transparency = NumberSequence.new(0.6, 1)
		haze.Color = ColorSequence.new(glow)
		haze.LightEmission = 0.5
		haze.Parent = first
	end
	model.Parent = folder
	return model
end

-- a short line in a bubble over its head for SAY_SECONDS (one at a time)
local function say(d, lines)
	local part = d.model:FindFirstChildWhichIsA("BasePart", true)
	if not part or not lines then
		return
	end
	if d.bubble then
		d.bubble:Destroy()
	end
	local words = lines[math.random(1, #lines)]
	local textSize = d.isBoss and SAY_TEXT_BOSS or SAY_TEXT
	local bounds = TextService:GetTextSize(words, textSize, Enum.Font.GothamBold, Vector2.new(SAY_MAX_WIDTH, 1000))
	local w, h = bounds.X + SAY_PAD.X * 2, bounds.Y + SAY_PAD.Y * 2
	local edge = d.thief and THIEF_OUTLINE or d.aurora and SAY_COLOR_AURORA or d.isBoss and SAY_COLOR_BOSS or SAY_COLOR
	local bubble = Instance.new("BillboardGui")
	bubble.Size = UDim2.fromOffset(w + 4, h + SAY_TAIL + 4)
	bubble.SizeOffset = Vector2.new(0, 0.5) -- (its bottom, the tail's tip, sits on the spot over the head)
	bubble.StudsOffsetWorldSpace = Vector3.new(0, d.ground + (d.hover or 0) + d.height + SAY_GAP - part.Position.Y, 0)
	bubble.AlwaysOnTop = true
	bubble.MaxDistance = d.isBoss and SAY_DISTANCE_BOSS or SAY_DISTANCE
	bubble.Adornee = part
	local holder = Instance.new("Frame") -- (scaled for the pop, about the tail's tip)
	holder.BackgroundTransparency = 1
	holder.AnchorPoint = Vector2.new(0.5, 1)
	holder.Position = UDim2.fromScale(0.5, 1)
	holder.Size = UDim2.fromScale(1, 1)
	holder.Parent = bubble
	local scale = Instance.new("UIScale")
	scale.Scale = 0.4
	scale.Parent = holder
	local tail = Instance.new("Frame") -- a turned square under the box: its lower half shows
	tail.AnchorPoint = Vector2.new(0.5, 0.5)
	tail.Size = UDim2.fromOffset(SAY_TAIL * 1.4, SAY_TAIL * 1.4)
	tail.Position = UDim2.new(0.5, 0, 0, h + 2)
	tail.Rotation = 45
	tail.BackgroundColor3 = SAY_FILL
	tail.BorderSizePixel = 0
	tail.Parent = holder
	local tailEdge = Instance.new("UIStroke")
	tailEdge.Color = edge
	tailEdge.Thickness = 2
	tailEdge.Parent = tail
	local box = Instance.new("TextLabel")
	box.Position = UDim2.fromOffset(2, 2)
	box.Size = UDim2.fromOffset(w, h)
	box.BackgroundColor3 = SAY_FILL
	box.Font = Enum.Font.GothamBold
	box.TextSize = textSize
	box.TextWrapped = true
	box.TextColor3 = SAY_INK
	box.Text = words
	box.ZIndex = 2 -- (over the tail's top half)
	box.Parent = holder
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 12)
	round.Parent = box
	local boxEdge = Instance.new("UIStroke")
	boxEdge.Color = edge
	boxEdge.Thickness = 2
	boxEdge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	boxEdge.Parent = box
	bubble.Parent = d.model
	TweenService:Create(scale, TweenInfo.new(SAY_POP, Enum.EasingStyle.Back), { Scale = 1 }):Play()
	d.bubble = bubble
	task.delay(SAY_SECONDS, function()
		if d.bubble == bubble then
			d.bubble = nil
		end
		bubble:Destroy()
	end)
end

local function bossLines(d)
	return d.aurora and AURORA_LINES or BOSS_LINES
end

local function remove(conf)
	local d = drawn[conf]
	if d then
		d.model:Destroy()
		if d.mound then
			d.mound:Destroy()
		end
		if d.pillar then
			d.pillar:Destroy()
		end
		if d.pile then
			d.pile:Destroy()
		end
		drawn[conf] = nil
	end
end

local function ease(t) -- smooth start and end
	t = math.clamp(t, 0, 1)
	return t * t * (3 - 2 * t)
end

-- the dirt mound over the hole while a zombie climbs out or sinks in: a low disc and a few clods,
-- grown (size 0..1) and gone at 0
local function mound(d, at, size)
	if size <= 0 then
		if d.mound then
			d.mound:Destroy()
			d.mound = nil
		end
		return
	end
	if not d.mound then
		local m = Instance.new("Model")
		m.Name = "ZombieMound"
		local disc = Instance.new("Part")
		disc.Name = "Disc"
		disc.Shape = Enum.PartType.Cylinder
		disc.Anchored, disc.CanCollide, disc.CanQuery, disc.CanTouch = true, false, false, false
		disc.Material = Enum.Material.Ground
		disc.Color = DIRT[1]
		disc.Parent = m
		for k = 1, MOUND_CLODS do
			local clod = Instance.new("Part")
			clod.Name = "Clod"
			clod.Shape = Enum.PartType.Ball
			clod.Anchored, clod.CanCollide, clod.CanQuery, clod.CanTouch = true, false, false, false
			clod.Material = Enum.Material.Ground
			clod.Color = DIRT[k % 2 + 1]
			clod:SetAttribute("Angle", k * 2 * math.pi / MOUND_CLODS + math.random() * 0.5)
			clod.Parent = m
		end
		m.Parent = folder
		d.mound = m
	end
	local r = MOUND_RADIUS * size * d.scale
	local height = MOUND_HEIGHT * size * d.scale
	for _, p in ipairs(d.mound:GetChildren()) do
		if p.Name == "Disc" then
			p.Size = Vector3.new(height, r * 2, r * 2)
			p.CFrame = CFrame.new(at + Vector3.new(0, height / 2 - 0.1, 0)) * CFrame.Angles(0, 0, math.pi / 2)
		else
			local a = p:GetAttribute("Angle")
			p.Size = Vector3.one * (0.7 * size * d.scale + 0.1)
			p.CFrame = CFrame.new(at + Vector3.new(math.cos(a) * r * 0.9, height, math.sin(a) * r * 0.9))
		end
	end
end

-- the boss's health bar (in its model) and the light pillar over it
local function bossExtras(d, conf)
	local _, size = d.model:GetBoundingBox()
	local anchor = d.model:FindFirstChildWhichIsA("BasePart", true)
	local bar = Instance.new("BillboardGui")
	bar.Name = "BossBar"
	bar.Size = BOSS_BAR_SIZE
	bar.StudsOffsetWorldSpace = Vector3.new(0, size.Y * 0.6 + 2, 0)
	bar.AlwaysOnTop = true
	bar.MaxDistance = BOSS_DRAW_DISTANCE
	bar.Adornee = anchor
	local title = Instance.new("TextLabel")
	title.BackgroundTransparency = 1
	title.Size = UDim2.new(1, 0, 0, 18)
	title.Font = Enum.Font.GothamBold
	title.TextSize = BOSS_BAR_TEXT
	title.TextColor3 = Color3.new(1, 1, 1)
	title.TextStrokeTransparency = 0.3
	title.Parent = bar
	local back = Instance.new("Frame")
	back.Position = UDim2.fromOffset(0, 22)
	back.Size = UDim2.new(1, 0, 0, 10)
	back.BackgroundColor3 = Color3.fromRGB(30, 25, 40)
	back.Parent = bar
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 5)
	corner.Parent = back
	local fill = Instance.new("Frame")
	local aurora = conf:GetAttribute("Aurora") == true
	fill.BackgroundColor3 = aurora and AURORA_GLOW or BOSS_BAR_COLOR
	fill.Size = UDim2.fromScale(1, 1)
	fill.Parent = back
	corner:Clone().Parent = fill
	bar.Parent = d.model
	local shownHp, shownMax, shownName = nil, nil, nil -- (2026-10-04: the words made again only when they change, not every frame)
	local function refresh()
		local hp, max = conf:GetAttribute("BossHP") or 0, math.max(1, conf:GetAttribute("BossMaxHP") or 1)
		local name = conf:GetAttribute("BossName") or "보스 좀비"
		if hp == shownHp and max == shownMax and name == shownName then
			return
		end
		shownHp, shownMax, shownName = hp, max, name
		title.Text = string.format("👑 %s %s / %s · 때린 만큼 💰", name, Formulas.shortNumber(math.ceil(hp)), Formulas.shortNumber(math.ceil(max)))
		fill.Size = UDim2.fromScale(math.clamp(hp / max, 0, 1), 1)
	end
	refresh()
	d.refreshBar = refresh
	local highlight = Instance.new("Highlight")
	highlight.FillColor = Color3.new(1, 1, 1)
	highlight.FillTransparency = 1
	highlight.OutlineColor = aurora and AURORA_GLOW or BOSS_GLOW
	highlight.OutlineTransparency = 0.4
	highlight.Parent = d.model
	d.highlight = highlight
	local pillar = Instance.new("Part")
	pillar.Name = "BossPillar"
	pillar.Anchored, pillar.CanCollide, pillar.CanQuery, pillar.CanTouch = true, false, false, false
	pillar.Material = Enum.Material.Neon
	pillar.Color = aurora and AURORA_GLOW or BOSS_GLOW
	pillar.Transparency = 0.55
	pillar.Shape = Enum.PartType.Cylinder
	pillar.Size = Vector3.new(BOSS_PILLAR_HEIGHT, BOSS_PILLAR_WIDTH, BOSS_PILLAR_WIDTH)
	pillar.Parent = folder
	d.pillar = pillar
end

-- (2026-10-04, "8명이 풀로 승급전 돌리고 배틀필드 밤에 돌아다닐때 문제없게 최적화 해 매끄럽게") each zombie's attributes kept
-- in a table, changed as they change (the render loop read some 20 a zombie every frame: about 600 calls a frame with
-- 40 zombies), and the folder's children listed once (not a new list every frame)
local attrCache = {} -- [Configuration] = { [name] = value }
local function attrs(conf)
	local a = attrCache[conf]
	if not a then
		a = conf:GetAttributes()
		attrCache[conf] = a
		conf.AttributeChanged:Connect(function(name)
			a[name] = conf:GetAttribute(name)
		end)
		conf.AncestryChanged:Connect(function()
			if not conf.Parent then
				attrCache[conf] = nil
			end
		end)
	end
	return a
end
local confList, confFolder = nil, nil
local function confsOf(folder)
	if confFolder ~= folder then
		confFolder = folder
		confList = folder:GetChildren()
		local function again()
			confList = folder:GetChildren()
		end
		folder.ChildAdded:Connect(again)
		folder.ChildRemoved:Connect(again)
	end
	return confList
end

local function addSnap(d, at, x, z, y, gap, step)
	local snaps = d.snaps
	if not snaps then
		d.snaps = { { at, x, z, y } }
		return
	end
	local last = snaps[#snaps]
	at = math.max(at, last[1] + 1e-3)
	if at - last[1] > gap then
		table.insert(snaps, { at - step, last[2], last[3], last[4] })
	end
	table.insert(snaps, { at, x, z, y })
	while #snaps > THIEF_SNAPS do
		table.remove(snaps, 1)
	end
end

local function between(s0, s1, f)
	return s0[2] + (s1[2] - s0[2]) * f, s0[3] + (s1[3] - s0[3]) * f, s1[4] or s0[4]
end

local function playback(snaps, playAt)
	local newest = snaps[#snaps]
	if playAt <= snaps[1][1] then
		return snaps[1][2], snaps[1][3], snaps[1][4]
	end
	if playAt >= newest[1] then
		local prev = snaps[#snaps - 1]
		local over = playAt - newest[1]
		if not prev or over >= PLAY_AHEAD + PLAY_SETTLE then
			return newest[2], newest[3], newest[4]
		end
		local reach = math.min(over, PLAY_AHEAD)
		if over > PLAY_AHEAD then
			reach *= 1 - (over - PLAY_AHEAD) / PLAY_SETTLE
		end
		local x, z = between(prev, newest, 1 + reach / math.max(1e-3, newest[1] - prev[1]))
		return x, z, newest[4]
	end
	for i = #snaps, 2, -1 do
		local s0, s1 = snaps[i - 1], snaps[i]
		if playAt >= s0[1] then
			return between(s0, s1, (playAt - s0[1]) / math.max(1e-3, s1[1] - s0[1]))
		end
	end
	return newest[2], newest[3], newest[4]
end

local thiefLate, thiefDelay = 0, THIEF_PLAYBACK_DELAY
local walkLate, walkDelay = 0, nil

RunService.RenderStepped:Connect(FrameMeter.wrap("Zombies", function(dt)
	local list = Workspace:FindFirstChild("Zombies")
	if not list then
		return
	end
	local serverNow = Workspace:GetServerTimeNow()
	local eye = camera and camera.CFrame.Position or Vector3.zero
	local c = Config.Zombies
	local listAt = list:GetAttribute("PT")
	thiefLate = math.max(0, thiefLate - dt * PLAY_DECAY)
	walkLate = math.max(0, walkLate - dt * PLAY_DECAY)
	local walkLeast = c.PublishSeconds + PLAY_MARGIN
	walkDelay = walkDelay or walkLeast
	local adjust = math.min(1, dt * PLAY_ADJUST)
	thiefDelay += (math.clamp(thiefLate + PLAY_MARGIN, THIEF_PLAYBACK_DELAY, PLAY_MOST) - thiefDelay) * adjust
	walkDelay += (math.clamp(walkLate + PLAY_MARGIN, walkLeast, PLAY_MOST) - walkDelay) * adjust
	for _, conf in ipairs(confsOf(list)) do
		local a = attrs(conf)
		local state = a.State
		local p = a.P -- (2026-10-04: x, the ground's height, z in one attribute; was X, Z and Y)
		local x, z = p and p.X or 0, p and p.Z or 0
		local isBoss = a.Boss == true
		local visible = (state == "Rising" or state == "Up" or state == "Sinking")
			and (Vector3.new(x, eye.Y, z) - eye).Magnitude <= (isBoss and (a.Aurora and AURORA_DRAW_DISTANCE or BOSS_DRAW_DISTANCE)
				or DRAW_DISTANCE)
		local d = drawn[conf]
		if d and isBoss and d.modelName ~= a.BossModel then -- another kind tonight (tests)
			remove(conf)
			d = nil
		end
		if not visible then
			if d then
				remove(conf)
			end
		else
			if not d then
				local bossScale = isBoss and (a.BossScale or BOSS_DEFAULT_SCALE) or nil
				local model = makeModel(a.Species or "TRex", bossScale, isBoss and a.BossModel,
					a.Aurora, a.Thief == true, a.Super == true, a.Guardian == true)
				d = { model = model, rig = DinoMotion.new(model), x = x, z = z, h = a.H or 0,
					ground = p and p.Y or groundAt(x, z), sinceGround = 0, lastAttack = a.AttackAt,
					nextGroan = os.clock() + math.random(GROAN_EVERY[1], GROAN_EVERY[2]), dirtShown = false,
					isBoss = isBoss, scale = bossScale or 1, voice = isBoss and BOSS_VOICE or 1,
					aurora = a.Aurora == true,
					lastBossHit = a.BossHitAt, lastDefeat = a.DefeatedAt,
					lastKnock = a.KnockAt, modelName = isBoss and a.BossModel or nil }
				local _, size = model:GetBoundingBox()
				d.height = size.Y
				if a.Thief then -- 🦝 its sign and the keys it carries
					d.thief = true
					d.voice = THIEF_VOICE
					local sign = Instance.new("BillboardGui")
					sign.Size = THIEF_SIGN_SIZE
					sign.StudsOffsetWorldSpace = Vector3.new(0, size.Y + THIEF_SIGN_UP, 0)
					sign.MaxDistance = THIEF_SIGN_DISTANCE
					sign.AlwaysOnTop = true
					sign.Adornee = model.PrimaryPart or model:FindFirstChildWhichIsA("BasePart", true)
					local name = Instance.new("TextLabel")
					name.Size = UDim2.fromScale(1, 0.5)
					name.BackgroundTransparency = 1
					name.Font = Enum.Font.GothamBlack
					name.TextScaled = true
					name.TextColor3 = THIEF_OUTLINE
					name.TextStrokeTransparency = 0.3
					name.Text = a.Super and "⚡ 슈퍼 도둑" or a.Guardian and "🛡️ 제단 지킴이" or "🦝 열쇠 도둑"
					if a.Guardian then
						name.TextColor3 = GUARD_OUTLINE
						d.guardian = true
					end
					if a.Super then
						name.TextColor3 = SUPER_COLOR
						sign.MaxDistance = SUPER_SIGN_DISTANCE
						d.super = true
					end
					name.Parent = sign
					local loot = name:Clone()
					loot.Position = UDim2.fromScale(0, 0.5)
					loot.TextColor3 = Color3.new(1, 1, 1)
					loot.Text = ""
					loot:SetAttribute("KeepText", true)
					loot.Parent = sign
					sign.Parent = model
					d.lootLabel = loot
					d.sign = sign
				end
				d.pileScale = math.max(size.Y / PILE_HEIGHT, math.max(size.X, size.Z) * PILE_COVER_WIDTH / PILE_WIDTH)
				if isBoss then
					bossExtras(d, conf)
				end
				drawn[conf] = d
			end
			-- slapped by a player: fly in an arc to the new spot (see the top)
			local knockAt = a.KnockAt
			if knockAt ~= d.lastKnock then
				d.lastKnock = knockAt
				if knockAt and serverNow - knockAt < 1 then
					local throw = math.sqrt((x - d.x) ^ 2 + (z - d.z) ^ 2)
					d.knock = { fromX = d.x, fromZ = d.z, start = os.clock(),
						seconds = d.guardian and c.Guardians.SlapFlightSeconds or c.SlapFlightSeconds,
						arc = math.clamp(throw * KNOCK_ARC_SHARE, KNOCK_ARC_MIN, KNOCK_ARC_MAX) }
					d.snaps, d.lastP = nil, p
					local here = Vector3.new(d.x, d.ground + d.height / 2, d.z)
					Sfx.play("ZombieHit", here)
					Sfx.play("DinoYelp", here, ZOMBIE_YELP_PITCH * d.voice) -- (2026-10-02) a short squeal ("비명울음 짧게")
					say(d, d.guardian and GUARD_LINES.ouch or d.thief and THIEF_LINES.ouch or OUCH_LINES)
				end
			end
			-- glide toward the server's spot
			local k = math.min(1, dt * FOLLOW)
			local ox, oz = d.x, d.z
			local flight = nil
			if d.knock then
				flight = (os.clock() - d.knock.start) / d.knock.seconds
				if flight >= 1 then
					d.knock, flight = nil, nil
					d.x, d.z = x, z
					d.ground = p and p.Y or groundAt(x, z)
					Fx.burst(Vector3.new(x, d.ground + 0.5, z), DUST, 18, 10, 0.6, 0.6)
				else
					d.x = d.knock.fromX + (x - d.knock.fromX) * flight
					d.z = d.knock.fromZ + (z - d.knock.fromZ) * flight
				end
			else
				if p ~= d.lastP then
					d.lastP = p
					local at = serverNow
					if d.thief then
						at = a.PT or serverNow
						thiefLate = math.max(thiefLate, serverNow - at)
					else
						local lastAt = d.snaps and d.snaps[#d.snaps][1]
						if listAt and (not lastAt or listAt > lastAt) then
							at = listAt
						end
						walkLate = math.max(walkLate, serverNow - at)
					end
					addSnap(d, at, x, z, p and p.Y, d.thief and THIEF_GAP or 2 * c.PublishSeconds,
						d.thief and c.TickSeconds or c.PublishSeconds)
				end
				if d.snaps then
					local tx, tz, ty = playback(d.snaps, serverNow - (d.thief and thiefDelay or walkDelay))
					local follow = math.min(1, dt * THIEF_FOLLOW)
					d.x += (tx - d.x) * follow
					d.z += (tz - d.z) * follow
					d.playY = ty
				end
			end
			local h = a.H or 0
			if d.thief and not d.knock and (d.x - ox) ^ 2 + (d.z - oz) ^ 2 > (FACE_SPEED * dt) ^ 2 then
				h = math.atan2(d.x - ox, d.z - oz)
			end
			local dh = (h - d.h + math.pi) % (2 * math.pi) - math.pi
			d.h += dh * (d.thief and math.min(1, dt * THIEF_TURN) or k)
			local wantY = (not d.knock and d.playY) or (p and p.Y)
			if wantY and d.jump then -- jumping up (onto a crystal)
				local t = (os.clock() - d.jump.at) / Config.Zombies.JumpSeconds
				if t >= 1 then
					d.ground, d.jump = d.jump.to, nil
				else
					local rise = d.jump.to - d.jump.from
					local arc = math.max(JUMP_ARC * d.scale, rise * JUMP_ARC_SHARE)
					d.ground = d.jump.from + rise * t + math.sin(math.pi * t) * arc
				end
			elseif wantY and wantY - d.ground > JUMP_MIN and not d.knock then
				d.jump = { from = d.ground, to = wantY, at = os.clock() }
			elseif wantY then
				d.ground += (wantY - d.ground) * math.min(1, dt * FALL_FOLLOW)
			else -- (no height from the server yet: the ground under it)
				d.sinceGround += dt
				if d.sinceGround > 0.5 then
					d.sinceGround = 0
					d.ground = groundAt(d.x, d.z)
				end
			end
			local speed = dt > 0 and math.sqrt((d.x - ox) ^ 2 + (d.z - oz) ^ 2) / dt or 0
			-- in and out of the ground (see the top): a height under the ground, a pitch, a roll, a spin
			local since = serverNow - (a.StateAt or serverNow)
			local at = Vector3.new(d.x, d.ground, d.z)
			if state ~= d.lastState then
				d.lastState = state
				if d.thief and since < 1 and (state == "Rising" or state == "Sinking") then -- (a squeak, no zombie voice)
					Sfx.play("DinoYelp", at, d.voice)
					if state == "Sinking" then
						Fx.burst(at + Vector3.new(0, 0.5, 0), DIRT, 16, 10, 0.5 * d.scale, 0.7)
					end
				elseif state == "Rising" and since < 1 then
					Sfx.play("ZombieRise", at, d.voice)
				elseif state == "Sinking" and since < 1 then
					Sfx.play("ZombieSink", at, d.voice)
					Fx.burst(at + Vector3.new(0, 0.5, 0), DIRT, 16, 10, 0.5 * d.scale, 0.7)
				end
			end
			local under, pitch, roll, spin, hop, legs = 0, 0, 0, 0, 0, speed
			local riseSeconds = d.isBoss and c.Boss.RiseSeconds or c.RiseSeconds
			local sinkSeconds = d.isBoss and c.Boss.SinkSeconds or c.SinkSeconds
			if state == "Rising" then
				local p = math.clamp(since / riseSeconds, 0, 1)
				mound(d, at, p < 0.85 and 1 or 1 - (p - 0.85) / 0.15)
				if p < 0.2 then -- the ground bulges; nothing to see yet
					under, pitch = 1, -1.2
				elseif p < 0.45 then -- the snout pokes out, looking at the sky, in little jerks
					local q = (p - 0.2) / 0.25
					under = 1 - 0.45 * (math.floor(q * 4) + ease(q * 4 % 1)) / 4
					pitch = -1.2
					roll = math.sin(os.clock() * 22) * 0.1
				elseif p < 0.85 then -- clawing up, legs paddling, wobbling hard
					local q = (p - 0.45) / 0.4
					under = 0.55 * (1 - ease(q))
					pitch = -1.2 + 0.95 * q
					roll = math.sin(os.clock() * 16) * 0.2 * (1 - q * 0.5)
					legs = LEG_PADDLE
				else -- out with a little hop, shaking the dirt off
					local q = (p - 0.85) / 0.15
					pitch = -0.25 * (1 - q)
					hop = math.sin(q * math.pi) * HOP_HEIGHT * d.scale
					roll = math.sin(os.clock() * 30) * 0.15 * (1 - q)
					if not d.poppedOut then
						d.poppedOut = true
						Fx.burst(at + Vector3.new(0, 1, 0), DIRT, 30, 16 * d.scale, 0.6 * d.scale, 0.9)
					end
				end
			elseif state == "Sinking" then
				local p = math.clamp(since / sinkSeconds, 0, 1)
				mound(d, at, math.min(1, p * 4))
				if p < 0.15 then -- a sleepy shrug and a look around
					pitch = -0.3 * math.sin(p / 0.15 * math.pi)
				else -- spinning down into the ground, nose first
					local q = (p - 0.15) / 0.85
					under = ease(q)
					spin = SINK_SPIN * ease(q)
					pitch = 0.35 * q
					roll = math.sin(os.clock() * 14) * 0.12
					legs = LEG_PADDLE * (1 - q)
				end
				if p >= 1 and not d.closed then
					d.closed = true
					Fx.burst(at + Vector3.new(0, 0.4, 0), DIRT, 20, 10, 0.5, 0.7)
				end
			else
				mound(d, at, 0)
				d.poppedOut, d.closed = nil, nil
				-- a shamble: rocking side to side as it walks
				local walk = math.min(1, speed / 5)
				roll = math.sin(os.clock() * SHAMBLE_SPEED + d.h) * SHAMBLE_ROLL * walk
			end
			if flight then -- tumbling through the air
				hop = math.sin(math.pi * flight) * d.knock.arc
				pitch = KNOCK_TUMBLE * flight
				legs = LEG_PADDLE
			elseif state == "Up" and serverNow < (a.StunUntil or 0) then -- dizzy on its side
				roll = DIZZY_ROLL + math.sin(os.clock() * 9) * DIZZY_WOBBLE
				legs = LEG_PADDLE * 0.5
			end
			local hover = d.isBoss and a.BossHover or 0 -- the pterosaur boss flies low
			if hover > 0 then
				hover *= state == "Up" and 1 or (state == "Rising" and math.clamp(since / riseSeconds * 2 - 1, 0, 1) or 0)
			end
			d.hover = hover
			local place = CFrame.new(d.x, d.ground - under * (d.height + 0.5) + hop + hover, d.z)
				* CFrame.Angles(0, d.h + math.pi + spin, 0) -- the model faces -Z; heading 0 = +Z
				* CFrame.Angles(-pitch, 0, roll) -- pitch < 0: nose up to the sky
			local attackAt = a.AttackAt
			if attackAt and attackAt ~= d.lastAttack then
				d.lastAttack = attackAt
				DinoMotion.attack(d.rig)
				if d.thief then
					Sfx.play("DinoYelp", at + Vector3.new(0, 2, 0), d.voice)
					say(d, d.guardian and GUARD_LINES.caught or THIEF_LINES.steal)
				else
					Sfx.play("ZombieGroan", at + Vector3.new(0, 2, 0), 1.15 * d.voice)
				end
				local hitPlayer = Players:GetPlayerByUserId(a.HitUserId or 0)
				local root = hitPlayer and hitPlayer.Character and hitPlayer.Character:FindFirstChild("HumanoidRootPart")
				if root then
					Sfx.play("ZombieHit", root.Position)
					Sfx.play("Oof", root.Position)
				end
			end
			if d.isBoss then -- slapped: a flash and a grunt; slapped down: a purple burst; the bar, the pillar
				local hitAt, downAt = a.BossHitAt, a.DefeatedAt
				if hitAt ~= d.lastBossHit then
					d.lastBossHit = hitAt
					d.flashUntil = os.clock() + BOSS_FLASH_SECONDS
					Sfx.play("ZombieHit", at + Vector3.new(0, d.height / 2, 0), 0.8)
					if hitAt and os.clock() - (d.lastOuch or -math.huge) >= BOSS_OUCH_GAP and math.random() < BOSS_OUCH_CHANCE then
						d.lastOuch = os.clock()
						say(d, bossLines(d).ouch)
					end
				end
				if downAt ~= d.lastDefeat then
					d.lastDefeat = downAt
					Fx.burst(at + Vector3.new(0, d.height / 2, 0), BOSS_BURST, 60, 30, 1.2, 1.2)
					Sfx.play("ZombieGroan", at + Vector3.new(0, 2, 0), BOSS_VOICE * 0.85)
					Sfx.play("GachaBig", at)
					if downAt then
						say(d, bossLines(d).down)
					end
				end
				d.highlight.FillTransparency = os.clock() < (d.flashUntil or 0) and 0.4 or 1
				d.refreshBar()
				d.pillar.Transparency = state == "Up" and 0.55 or 1
				d.pillar.CFrame = CFrame.new(d.x, d.ground + BOSS_PILLAR_HEIGHT / 2, d.z) * CFrame.Angles(0, 0, math.pi / 2)
			end
			if state == "Up" and os.clock() >= d.nextGroan then
				d.nextGroan = os.clock() + math.random(GROAN_EVERY[1], GROAN_EVERY[2])
				if not d.thief and (at - eye).Magnitude <= GROAN_DISTANCE * d.scale then
					Sfx.play("ZombieGroan", at + Vector3.new(0, 2, 0), (0.9 + math.random() * 0.25) * d.voice)
				end
				if d.thief then
					if math.random() < THIEF_TALK_CHANCE then
						say(d, d.guardian and (a.ChaseUserId and GUARD_LINES.chase or GUARD_LINES.talk)
							or (a.Loot or 0) > 0 and THIEF_LINES.run or THIEF_LINES.talk)
					end
				elseif d.isBoss and math.random() < BOSS_TALK_CHANCE then -- now and then a word with it
					say(d, bossLines(d).talk)
				elseif not d.isBoss and math.random() < WEATHER_TALK_CHANCE then
					say(d, WEATHER_LINES[ReplicatedStorage:GetAttribute("Weather") or "Clear"])
				end
			end
			if d.thief and a.GrabAt ~= d.lastGrab then -- 🦝 a key grabbed off the ground: a squeak and a word
				local fresh = d.lastGrab ~= nil or (a.GrabAt and serverNow - a.GrabAt < 1)
				d.lastGrab = a.GrabAt
				if fresh and a.GrabAt then
					Sfx.play("DinoYelp", at + Vector3.new(0, 2, 0), d.voice)
					say(d, THIEF_LINES.steal)
				end
			end
			if d.superKeyRainbow and d.superKeyRainbow:IsA("BasePart") then
				d.superKeyRainbow.Color = Color3.fromHSV(os.clock() / SUPER_KEY_RAINBOW_SECONDS % 1, 0.8, 1)
			end
			if d.guardian and d.lootLabel and d.chaseShown ~= a.ChaseUserId then
				d.chaseShown = a.ChaseUserId
				local target = a.ChaseUserId and Players:GetPlayerByUserId(a.ChaseUserId)
				if target == Players.LocalPlayer then
					d.lootLabel.Text = "❗ 나를 쫓아와요!"
				elseif target then
					d.lootLabel.Text = string.format("❗ %s 쫓는 중", target.DisplayName)
				else
					d.lootLabel.Text = ""
				end
				d.lootLabel.TextColor3 = GUARD_CHASE_COLOR
				if target then
					say(d, GUARD_LINES.chase)
				end
			end
			if d.lootLabel and not d.guardian then -- 🦝 the keys it carries, and how long before it digs away with them
				local left = (a.Loot or 0) > 0 and a.EscapeAt and math.max(0, math.ceil(a.EscapeAt - serverNow)) or nil
				if d.lootShown ~= a.Loot or d.leftShown ~= left or d.specialShown ~= a.LootSpecial then
					d.lootShown, d.leftShown, d.specialShown = a.Loot, left, a.LootSpecial
					-- (2026-10-04, "도둑공룡이 왕열쇠나 특별 열쇠 갖고 있으면 그것도 표시해줘") 👑 and the better keys first,
					-- each with its mark, then all its keys
					local marks = {}
					for kind, k in string.gmatch(a.LootSpecial or "", "(%w+):(%d+)") do
						table.insert(marks, string.format("%s×%s", THIEF_KEY_MARKS[kind] or "🔑", k))
					end
					table.sort(marks, function(x, y)
						return (string.find(x, "👑", 1, true) and 0 or 1) < (string.find(y, "👑", 1, true) and 0 or 1)
					end)
					local front = #marks > 0 and table.concat(marks, " ") .. "  " or ""
					d.lootLabel.Text = (a.Loot or 0) <= 0 and ""
						or left and front .. string.format("🔑 ×%d  ⏳ %d", a.Loot, left)
						or front .. string.format("🔑 ×%d", a.Loot)
					d.lootLabel.TextColor3 = left and left <= THIEF_HURRY and THIEF_HURRY_COLOR
						or #marks > 0 and THIEF_SPECIAL_COLOR or Color3.new(1, 1, 1)
					d.sign.MaxDistance = d.super and SUPER_SIGN_DISTANCE or (a.Loot or 0) > 0 and THIEF_LOOT_DISTANCE
						or THIEF_SIGN_DISTANCE
					local grade = d.super and string.match(a.LootSpecial or "", "^(%w+):")
					local keyType = grade and Formulas.keyType(grade)
					local glow = d.model:FindFirstChildOfClass("Highlight")
					if keyType and keyType.Rgb and glow then
						glow.FillColor = Color3.fromRGB(table.unpack(keyType.Rgb))
						glow.OutlineColor = glow.FillColor
						for _, e in ipairs(d.model:GetDescendants()) do
							if e:IsA("ParticleEmitter") then
								e.Color = ColorSequence.new(glow.FillColor)
							end
						end
					end
					d.superKey = d.super and d.model:FindFirstChild(Config.Zombies.SuperThief.Model .. "_Key", true)
					d.superKeyRainbow = keyType and keyType.Rainbow and d.superKey or nil
					if d.superKey and keyType and keyType.Rgb and keyType.Id ~= "Gold" and d.superKey:IsA("BasePart") then
						d.superKey.Color = Color3.fromRGB(table.unpack(keyType.Rgb))
						d.superKey.Material = SUPER_KEY_MATERIALS[keyType.Id] or d.superKey.Material
						if d.superKey:IsA("MeshPart") then
							pcall(function()
								d.superKey.TextureID = ""
							end)
						end
					end
				end
			end
			if d.thief and a.CaughtAt ~= d.lastCaught then -- 🦝 slapped with keys in it: they burst out
				local fresh = d.lastCaught ~= nil or (a.CaughtAt and serverNow - a.CaughtAt < 1)
				d.lastCaught = a.CaughtAt
				if fresh and a.CaughtAt then
					local here = at + Vector3.new(0, d.height / 2, 0)
					Fx.burst(here, THIEF_CAUGHT_BURST, 40, 24, 0.8, 0.9)
					Sfx.play("KeyDrop", here)
					Sfx.play("GachaBig", here)
					say(d, THIEF_LINES.caught)
				end
			end
			if d.super and a.DashAt ~= d.lastDash then
				local fresh = d.lastDash ~= nil or (a.DashAt and serverNow - a.DashAt < 1)
				d.lastDash = a.DashAt
				if fresh and a.DashAt then
					local here = at + Vector3.new(0, d.height / 2, 0)
					Fx.burst(here, SUPER_DASH_BURST, 24, 14, 0.5, 0.5)
					Sfx.play("FlyWhoosh", here)
					say(d, SUPER_DASH_LINES)
				end
			end
			-- held by a poop bomb: buried in a pile till PoopUntil (it moves with it if slapped away)
			local pileAt = Vector3.new(d.x, d.ground + hover, d.z)
			if state == "Up" and serverNow < (a.PoopUntil or 0) then
				if not d.pile then
					d.pile, d.pileAt = PoopPile.make(pileAt, folder, d.pileScale), pileAt
					Sfx.play("ZombieGroan", pileAt + Vector3.new(0, 2, 0), 1.4 * d.voice)
					say(d, OUCH_LINES)
				elseif (pileAt - d.pileAt).Magnitude > 0.05 then
					d.pile:PivotTo(d.pile:GetPivot() + (pileAt - d.pileAt))
					d.pileAt = pileAt
				end
			elseif d.pile then
				Fx.burst(d.pileAt + Vector3.new(0, d.pileScale, 0), SPLAT, 16, 10 * d.pileScale, 0.5 * d.pileScale, 0.6)
				d.pile:Destroy()
				d.pile = nil
			end
			local due, step = Lod.due(d, (place.Position - eye).Magnitude, dt) -- far ones less often (Shared/Lod)
			if due then
				d.pose = hover > 0.5 and DinoMotion.fly(d.rig, step) or DinoMotion.step(d.rig, step, legs)
				d.model:PivotTo(place * d.pose)
			elseif d.pose and (speed > 0 or state ~= "Up") then
				d.model:PivotTo(place * d.pose)
			end
		end
	end
	for conf in pairs(drawn) do
		if not conf.Parent then
			remove(conf)
		end
	end
end))

-- my hit on a boss paid money: "+n원 💰" floating up over where it was hit
Net.onPush("BossHitMoney", function(amount, at)
	local anchor = Instance.new("Part")
	anchor.Anchored, anchor.CanCollide, anchor.CanQuery, anchor.CanTouch = true, false, false, false
	anchor.Transparency = 1
	anchor.Size = Vector3.one * 0.2
	anchor.CFrame = CFrame.new(at + Vector3.new(0, HIT_MONEY_START, 0))
	anchor.Parent = folder
	local gui = Instance.new("BillboardGui")
	gui.Size = HIT_MONEY_SIZE
	gui.AlwaysOnTop = true
	gui.Parent = anchor
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBlack
	text.TextScaled = true
	text.TextColor3 = HIT_MONEY_COLOR
	text.TextStrokeTransparency = 0.2
	text.Text = string.format("+%s원 💰", Formulas.shortNumber(amount))
	text.Parent = gui
	local start = anchor.Position
	local t0 = os.clock()
	local connection
	connection = RunService.RenderStepped:Connect(FrameMeter.wrap("Zombies", function()
		local t = math.min(1, (os.clock() - t0) / HIT_MONEY_SECONDS)
		anchor.CFrame = CFrame.new(start + Vector3.new(0, HIT_MONEY_RISE * t, 0))
		text.TextTransparency = math.max(0, t * 2 - 1)
		text.TextStrokeTransparency = 0.2 + 0.8 * math.max(0, t * 2 - 1)
		if t >= 1 then
			connection:Disconnect()
			anchor:Destroy()
		end
	end))
end)

-- ---------------------------------------------------------------------------
-- The boss's big attacks (Net push BossFx)
-- ---------------------------------------------------------------------------

local function bossDrawn(name)
	for conf, d in pairs(drawn) do
		if d.isBoss and conf.Parent and (name == nil or conf.Name == name) then
			return d
		end
	end
	return nil
end

local function fxPart(shape, size, cf, color, transparency)
	local p = Instance.new("Part")
	p.Shape = shape
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch = true, false, false, false
	p.CastShadow = false
	p.Material = Enum.Material.Neon
	p.Color = color
	p.Transparency = transparency
	p.Size = size
	p.CFrame = cf
	p.Parent = folder
	return p
end

-- a flat disc on the ground at x, z (radius r)
local function disc(x, z, r, color, transparency)
	local y = groundAt(x, z) + 0.15
	return fxPart(Enum.PartType.Cylinder, Vector3.new(0.2, r * 2, r * 2),
		CFrame.new(x, y, z) * CFrame.Angles(0, 0, math.pi / 2), color, transparency)
end

-- runs fn(t) every frame for seconds (t 0..1), then done()
local function animate(seconds, fn, done)
	local start = os.clock()
	local connection
	connection = RunService.RenderStepped:Connect(FrameMeter.wrap("Zombies", function()
		local t = math.min(1, (os.clock() - start) / seconds)
		fn(t)
		if t >= 1 then
			connection:Disconnect()
			if done then
				done()
			end
		end
	end))
end

Net.onPush("BossFx", function(kind, x, z, a, b, bossName)
	local d = bossDrawn(bossName)
	if d then
		say(d, bossLines(d)[kind])
	end
	if kind == "Roar" then -- a = radius, b = windup
		if d then
			DinoMotion.roar(d.rig)
			Sfx.play("MountRoar", Vector3.new(x, d.ground + d.height / 2, z), 0.65)
		end
		task.delay(b, function()
			local ring = disc(x, z, 1, ROAR_RING_COLOR, 0.3)
			Fx.burst(Vector3.new(x, groundAt(x, z) + 1, z), DUST, 40, a, 1.2, 0.8)
			Sfx.play("DinoStomp", Vector3.new(x, groundAt(x, z) + 2, z), 0.6)
			animate(ROAR_RING_SECONDS, function(t)
				local r = math.max(1, a * t)
				ring.Size = Vector3.new(0.2, r * 2, r * 2)
				ring.Transparency = 0.3 + 0.7 * t
			end, function()
				ring:Destroy()
			end)
		end)
	elseif kind == "Charge" then -- from x, z to a, b
		local from, to = Vector3.new(x, 0, z), Vector3.new(a, 0, b)
		local length = (to - from).Magnitude
		if length < 0.5 then
			return
		end
		local mid = (from + to) / 2
		local y = groundAt(mid.X, mid.Z) + 0.15
		local stripe = fxPart(Enum.PartType.Block, Vector3.new(CHARGE_STRIPE_WIDTH, 0.2, length),
			CFrame.lookAt(Vector3.new(mid.X, y, mid.Z), Vector3.new(to.X, y, to.Z)), CHARGE_STRIPE_COLOR, 0.55)
		if d then
			Sfx.play("MountBellow", Vector3.new(x, d.ground + d.height / 2, z), 0.7)
		end
		local windUp = Config.Zombies.Boss.Charge.WindUp
		animate(windUp, function(t)
			stripe.Transparency = 0.35 + 0.3 * math.abs(math.sin(t * math.pi * 4))
			if d and math.random() < 0.2 then
				Fx.burst(Vector3.new(d.x, d.ground + 0.5, d.z), DUST, 4, 6, 0.6, 0.5) -- pawing the ground
			end
		end, function()
			Sfx.play("DinoStomp", Vector3.new(x, groundAt(x, z) + 2, z), 0.7)
			animate(length / Config.Zombies.Boss.Charge.Speed, function(t)
				stripe.Transparency = 0.6 + 0.4 * t
				if d and math.random() < 0.5 then
					Fx.burst(Vector3.new(d.x, d.ground + 0.5, d.z), DUST, 5, 8, 0.8, 0.5)
				end
			end, function()
				stripe:Destroy()
			end)
		end)
	elseif kind == "Bomb" then -- at x, z, radius a, falling b seconds
		local ground = groundAt(x, z)
		local shadow = disc(x, z, a, BOMB_SHADOW_COLOR, 0.9)
		shadow.Material = Enum.Material.SmoothPlastic
		local top = d and (d.model:GetPivot().Position + Vector3.new(0, d.height * 0.4, 0))
			or Vector3.new(x, ground + 30, z)
		local ball = fxPart(Enum.PartType.Ball, Vector3.one * BOMB_SIZE, CFrame.new(top), BOMB_COLOR, 0)
		ball.Material = Enum.Material.SmoothPlastic
		if d then
			Sfx.play("VoiceScreech", top, 0.8)
		end
		local landing = Vector3.new(x, ground + BOMB_SIZE / 2, z)
		animate(b, function(t)
			ball.CFrame = CFrame.new(top:Lerp(landing, t * t)) -- speeding up as it falls
			shadow.Transparency = 0.9 - 0.45 * t
		end, function()
			ball:Destroy()
			shadow:Destroy()
			Fx.burst(landing, SPLAT, 40, a * 2, 1, 0.8)
			Sfx.play("Splat", landing)
		end)
	end
end)

local thiefBeams = {}
RunService.RenderStepped:Connect(FrameMeter.wrap("Zombies", function()
	local list = Workspace:FindFirstChild("Zombies")
	for conf, beam in pairs(thiefBeams) do
		if not list or conf.Parent ~= list then
			beam:Destroy()
			thiefBeams[conf] = nil
		end
	end
	if not list then
		return
	end
	for _, conf in ipairs(confsOf(list)) do
		local a = attrs(conf)
		local p = a.P
		if a.Thief and p then
			local beam = thiefBeams[conf]
			if not beam then
				beam = Instance.new("Part")
				beam.Name = "ThiefBeam"
				beam.Anchored, beam.CanCollide, beam.CanQuery, beam.CanTouch, beam.CastShadow = true, false, false, false, false
				beam.Material = Enum.Material.Neon
				beam.Color = THIEF_BEAM_COLOR
				beam.Shape = Enum.PartType.Cylinder
				beam.Size = Vector3.new(THIEF_BEAM_HEIGHT, THIEF_BEAM_WIDTH, THIEF_BEAM_WIDTH)
				beam.Parent = folder
				thiefBeams[conf] = beam
			end
			local shown = (a.State == "Up" or a.State == "Rising") and (a.Loot or 0) > 0
			beam.Transparency = shown and THIEF_BEAM_TRANSPARENCY or 1
			if shown then
				local d = drawn[conf]
				local x, z, ground = p.X, p.Z, p.Y
				if d then
					x, z, ground = d.x, d.z, d.ground
				end
				beam.CFrame = CFrame.new(x, ground + THIEF_BEAM_HEIGHT / 2, z) * CFrame.Angles(0, 0, math.pi / 2)
			end
		end
	end
end))
