--[[
Wildlife: giant and little dinos roaming the safe land on this screen (display only, no collisions).

- Where: the land between and behind the bases, outside the battlefield, the race track and every
  base plot (worked out from Config.Map like roblox/MapBuilder.lua lays them out, so every screen
  agrees even before the far parts of the map have loaded), inside the map's wall.
- Who (2026-10-01: many kinds, was Argentinosaurs and wild raptors only; about as many as before): a few
  giant long-necks (GIANTS: Argentinosaurus, Brachiosaurus, Diplodocus, far bigger than any dino a player
  owns) wandering alone, small herds of grazers (HERDS: plant eaters, armored dinos, walking pterosaurs)
  and hunting packs (PACKS), using the models Dino_<species> in ReplicatedStorage.DinoModels. A model not
  there yet (the server copies them in when it starts) is looked for again a little later; after
  FALLBACK_AFTER tries it borrows its kind's FALLBACK model (a new species not imported yet).
- How they move: each has a home and walks from one random spot near it to the next (LEG seconds a
  leg: walking WALK_SHARE of it, then standing), worked out from the server's clock, so every screen
  sees them in about the same place without any messages. Standing, they often put their heads down
  and graze (DinoMotion.graze); giants now and then bellow, deep and slow.
- Hunting packs (PACKS): 4-5 small meat eaters of one species darting about together, running most of the time.
- "🦖 올라타기" prompt on every one near me, shown right beside my character (near the middle of the
  screen, not at the dino's far-off feet): I jump onto its back and sit there (my character's own sit
  pose; my screen holds me there, Net request
  WildRide), and RideSeconds later it rears up and roars and the server throws me off (Wildlife service,
  Net push Knockback). Not while riding my own dino, racing or knocked down.
- (2026-10-02) Slapped (Net push SlapFx: everyone's screen works out who was in the slapper's reach, as
  for trees, Trees.client): a little one flies off tumbling like a slapped zombie with a word in a bubble
  ("아야!"), lies dizzy, gets up and runs at the slapper ("거기 서!") to slap back: caught, it lunges and the
  slapper is thrown (their own screen asks: Net request WildCounter; Wildlife service). Past ChaseSeconds
  or once the slapper is ChaseLeash from where it was slapped it gives up ("흥!") and walks back onto its
  path, neutral again. A giant doesn't mind a slap, but a slap up close (bombs don't reach the safe land)
  makes it rear up and kick: the slapper flies off as from its back after a ride (Net request WildKick).
  The shopkeeper dinos roar at a slap (Npcs.client). Config.Wildlife has the numbers.
- Only the ones near the camera are drawn (DRAW_DISTANCE; the giants from much farther), and none at all
  while the view setting "야생 공룡" is off (player attribute HideWildlife, Settings): less lag on weak
  phones.
- (2026-10-03, "작은 야생동물들이 배틀필드에도 돌아다니게 하자 휑하다.. 많이") little ones on the battlefield too:
  FIELD_HERDS of small grazers and FIELD_PACKS of little raptors between the key altar's plaza and the flags
  (FIELD_RING), over a hundred in all. The battlefield is where phones work hardest, so only those within
  FIELD_DRAW_DISTANCE are drawn, and at most FIELD_DRAW_MAX of them at once (the nearest). No ride prompt
  there (riding a wild one is for the safe land: the Wildlife service checks it); slapped, one flies off
  and lies dizzy like the others, then runs away from the slapper (FLEE_*) instead of slapping back.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local DinoMotion = require(Shared:WaitForChild("DinoMotion"))
local Lod = require(Shared:WaitForChild("Lod"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Net = require(Shared:WaitForChild("Net"))
local DinoVoices = require(Shared:WaitForChild("DinoVoices"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Fx = require(Shared:WaitForChild("Fx"))
local SpeechBubble = require(Shared:WaitForChild("SpeechBubble"))

-- display only
local SEED = 4271
local RING = { 398, 725 } -- studs from the map center they may roam in
local TRACK_CLEAR = 14 -- studs kept off the race track's middle line (half its width + a little)
local PLOT_MARGIN = 12 -- studs kept outside the base plots
local BASE_ANGLE0 = 22.5 -- compass angle of Base1 (roblox/MapBuilder.lua BASE_ANGLE0)
-- (2026-10-01) about 90 in all, as before (5 giants, 14 packs of 4-6 raptors, 7 herds of 2-4), of many kinds now
local GIANTS = { Count = 7, Height = 80, -- (2026-10-02, "야생공룡들 … 좀 적어서": 5 → 7, herds 12 → 22, packs 11 → 14)
	Roam = 110, Leg = 55, -- (was 46 tall: much bigger)
	Species = { { "Argentino", 1 }, { "Brachio", 1 }, { "Diplo", 0.75 } } } -- (species, × Height: Diplo is long and low)
local RETRY_SECONDS = 5 -- a model not found yet: look again after this long
local FALLBACK_AFTER = 3 -- tries before borrowing the kind's fallback model
local FALLBACK = { giant = "Argentino", mini = "Trike", runner = "WildRaptor" } -- (Dino_WildRaptor: Config.Wildlife.RaptorModel)
local HERDS = {
	Count = 22, Size = { 2, 4 }, Height = 3.6, Roam = 26, Leg = 12, -- (2026-10-02: was 2.6, lost in the safe land's grass)
	Species = { "Parasaur", "Iguanodon", "Trike", "Stego", "Ankylo", "Kentro", "Pachy", "Edmonto", "Maia", "Styraco",
		"Huayango", "Stegoceras", "Euoplo", "Gastonia", "Nodo", "Therizino", "Quetzal" },
}
local PACKS = { Count = 14, Size = { 4, 5 }, Height = 4.2, Roam = 50, Leg = 7, -- (was 14 packs of 4-6 wild raptors)
	Species = { "WildRaptor", "Raptor", "Utahraptor", "Dilopho", "Carno", "Cerato", "Baryonyx", "Allo" },
	WalkShare = 0.8 } -- running most of the time
-- the battlefield's (see the top)
local FIELD_RING = { 70, 340 } -- studs from the map center: outside the key altar's plaza, inside the flags (Config.Battlefield.Radius)
local FIELD_HERDS = { Count = 26, Size = { 2, 4 }, Height = 3.2, Roam = 30, Leg = 11,
	Species = { "Pachy", "Stegoceras", "Parasaur", "Trike", "Ankylo", "Gastonia", "Iguanodon", "Maia", "Edmonto",
		"Kentro", "Nodo", "Huayango", "Saichania", "Euoplo" } }
local FIELD_PACKS = { Count = 9, Size = { 3, 5 }, Height = 3.6, Roam = 55, Leg = 7,
	Species = { "WildRaptor", "Raptor", "Dilopho", "Utahraptor", "Cerato" }, WalkShare = 0.8 }
local GIANT_SIZE = { 0.75, 1.2 } -- × a giant's height (2026-10-03)
-- (2026-10-03, "크기도 다양화 하고", then "안전지대 야생공룡들도 크기 다양화": the safe land's herds and packs too) each herd or pack its own size (× its Height, FIELD_GROUP_SIZE), and
-- within it each one a little different (FIELD_ONE_SIZE); now and then a little young one (FIELD_YOUNG)
local FIELD_GROUP_SIZE = { 0.6, 1.9 }
local FIELD_ONE_SIZE = { 0.85, 1.15 }
local FIELD_YOUNG = { Chance = 0.2, Size = 0.55 }
local FIELD_DRAW_DISTANCE = 190 -- studs from the camera (plus its roam)
local FIELD_DRAW_MAX = 28 -- drawn at once at most, the nearest
-- (2026-10-04, "지연도 확실히 해결해") in 🍃 light mode (player attribute LightMode): at most this many on the battlefield,
-- and the little ones of the safe land only this near (× DRAW_DISTANCE)
local LIGHT_FIELD_MAX = 10
local LIGHT_DISTANCE_SHARE = 0.5
local LOW_FIELD_MAX = 16
local LOW_DISTANCE_SHARE = 0.75
local FIELD_KEEP = 25 -- studs: one already drawn counts this much nearer (not made and taken away over and over at the edge)
local PRACTICE_DINO = { Species = "Trike", Height = 4.6, Roam = 14, Leg = 9, From = 8 }
local KEEP_IN = 3
local FLEE_SECONDS, FLEE_SPEED = 2.5, 18 -- a slapped one on the battlefield runs away this long, this fast
local FLEE_LINES = { "도망가자!", "무서워~", "살려줘!" }
-- (2026-10-03, "날씨에 배틀필드 내 야생공룡들도 한마디씩 못하나 드물게") in a weather (not a clear sky), now and then
-- (every WEATHER_SAY_EVERY seconds) one of the battlefield's little ones near the camera says a word about it
local WEATHER_SAY_EVERY = { 15, 30 }
local WEATHER_SAY_NEAR = 90 -- studs from the camera
local WEATHER_LINES = {
	Rain = { "비 온다! ☔", "빗물 시원해~", "풀이 촉촉해~", "웅덩이에서 첨벙!" },
	Storm = { "번개 무서워! ⚡", "쾅! 깜짝이야!", "숨을 곳 어디야?!", "천둥 소리 너무 커…" },
	RainbowSky = { "무지개다! 🌈", "무지개 따라가자!", "알록달록 예뻐~", "소원 빌자!" },
	Aurora = { "하늘이 춤춘다! 🌌", "우와… 반짝반짝!", "초록빛 너무 예뻐…", "밤하늘 최고~" },
}
local WALK_SHARE = 0.55 -- of each leg, walking; the rest standing
local BACK_SHARE = 0.72 -- a rider sits this share of the dino's height up
local RIDE_BACK_SECONDS = 2
local RIDE_KEY = Enum.KeyCode.E
local PROMPT_NEAR = 2.5 -- studs from my character toward the dino where its prompt shows
local PROMPT_UP = 1.5 -- and this far above my middle
-- (2026-10-02) a storm bolt beside one (Net push Lightning): it hops away and yelps, then walks back onto
-- its path (the giants only cry out: far too big to be thrown)
local JOLT_STUDS, JOLT_HEIGHT, JOLT_SECONDS, JOLT_BACK_SECONDS = 5, 2.5, 0.45, 2.5
local GIANT_ROAR = { "VoiceBellow", 0.45 } -- (the others roar in their species' own voice, Shared/DinoVoices)
-- (2026-10-02) slapped (see the top; the game's numbers are Config.Wildlife)
local SLAP_ARC = 5 -- studs high, a little one's flight
local SLAP_TUMBLE = math.pi * 2 -- one somersault in the air
local SLAP_BODY = 1.5 -- studs added to the slap's reach for a little one's body
local GIANT_BODY = 0.3 -- × a giant's height: its body round its middle (its legs are within reach)
local LIE_ROLL = 1.3 -- radians: lying on its side ...
local LIE_WRIGGLE, LIE_WRIGGLE_SPEED = 0.12, 14 -- ... wriggling
local CHASE_GROUND_EVERY = 0.25 -- seconds between looks at the ground under a running one
local KICK_SECONDS = 1.1
local KICK_HIT = 0.45 -- share of the kick when the foot comes down (the throw)
local KICK_REAR = 0.12 -- radians: it rears back, then stamps forward
local KICK_HIND = 0.4 -- × its height: its hind legs behind its middle
local KICK_PITCH = 0.6 -- its stamp, deep
-- (2026-10-02, "찰싹 맞을때 비명울음 짧게 … 거대공룡은 크르릉", "야생공룡타격음도 없네") the slap's smack on the dino
-- (wild dinos are drawn by each screen only: the server's hit sound never played for them), a little one's
-- short squeal (higher the smaller: YELP_PITCH_AT_1 at height 1 down YELP_PITCH_PER_STUD a stud), a giant's growl
local YELP_PITCH_AT_1, YELP_PITCH_PER_STUD, YELP_PITCH_MIN = 1.45, 0.1, 0.9
local SAY_GAP = 1 -- studs over its head
local SAY_EDGE = Color3.fromRGB(230, 150, 70) -- a wild dino's bubble edge
local DUST = { Color3.fromRGB(170, 150, 110), Color3.fromRGB(130, 115, 85) }
local OUCH_LINES = { "아야!", "끼잉!", "왜 때려!", "으앙!", "뭐야?!" }
local ANGRY_LINES = { "거기 서!", "복수다!", "가만 안 둬!", "크앙!" }
local HIT_LINES = { "받아라!", "메롱~", "이제 됐다!" }
local GIVE_UP_LINES = { "흥!", "다음엔 안 봐줘!", "헥헥…" }
local POOP_LINES = { "으악 똥이야!", "냄새나~", "꼼짝 못 하겠어!" }
local BOOM_LINES = { "펑?!", "깜짝이야!", "으앙!" }
local POOP_COLORS = { Color3.fromRGB(110, 70, 40), Color3.fromRGB(150, 100, 60) }
local POOP_TIERS = { { 1, 0.3 }, { 0.72, 0.75 }, { 0.45, 1.1 } }
local POOP_SIZE_SHARE, POOP_SIZE_MIN = 0.35, 0.8
local GRAZE_CHANCE = 0.65 -- standing, it grazes (else it looks around)
local DRAW_DISTANCE = { giant = 1100, mini = 240, runner = 240 }
local BELLOW_EVERY = { 14, 30 }
local BELLOW_DISTANCE = 220
local BELLOW_PITCH = 0.45
local CHECK_EVERY = 0.5 -- seconds between the checks of who is near enough to draw
local MAKE_PER_FRAME = 1
-- (2026-10-04, "가끔 땅에서 조금 떨어져 걷는거 같은") the ground under a walking one, looked at this often (seconds) and
-- eased in this fast (a second)
local GROUND_EVERY = 0.4
local GROUND_EASE = 4
-- Map folders a wild dino never stands on: it walks through trees, rocks and flags on the ground (2026-10-01:
-- it climbed on top of them, like the zombies once did; Zombies.client has the same list)
local NOT_GROUND = { "Decor", "FieldDecor", "FieldGrass", "SafeGrass", "BattlefieldFlags" }
local NOT_GROUND_TOP = { "TreasureChests", "RideMounts", "ZombieModels", "Zombies", "Minerals", "Keys", "SpeedPads",
	"HideSeek" } -- (in Workspace; the last five on the battlefield)

local player = Players.LocalPlayer
local folder = Instance.new("Folder")
folder.Name = "Wildlife"
folder.Parent = Workspace

local function inPlace(p)
	local r = Vector3.new(p.X, 0, p.Z).Magnitude
	if r < RING[1] or r > RING[2] or math.abs(r - Config.Race.Radius) < TRACK_CLEAR then
		return false
	end
	local m = Config.Map
	for i = 1, m.BaseCount do -- each plot: a PlotWidth × PlotDepth box BaseDistance out (compass: 0 = north / -Z)
		local a = math.rad(BASE_ANGLE0 + (i - 1) * 360 / m.BaseCount)
		local out, right = Vector3.new(math.sin(a), 0, -math.cos(a)), Vector3.new(math.cos(a), 0, math.sin(a))
		local rel = Vector3.new(p.X, 0, p.Z) - out * m.BaseDistance
		if math.abs(rel:Dot(right)) < m.PlotWidth / 2 + PLOT_MARGIN and math.abs(rel:Dot(out)) < m.PlotDepth / 2 + PLOT_MARGIN then
			return false
		end
	end
	return true
end

-- on the battlefield, away from the plaza and the flags
local function inField(p)
	local r = Vector3.new(p.X, 0, p.Z).Magnitude
	return r >= FIELD_RING[1] and r <= FIELD_RING[2]
end

-- the animals: { species, height, home, roam, leg, offset (seconds), kind ("giant" / "mini" / "runner"),
-- field (on the battlefield) }
local animals = {}
local function addAnimal(species, height, home, roam, leg, kind, walkShare, field)
	table.insert(animals, { species = species, height = height, home = home, roam = roam, leg = leg, kind = kind,
		offset = (#animals * 7.31) % leg, id = #animals + 1, walkShare = walkShare or WALK_SHARE, field = field,
		place = field and inField or inPlace })
end

local function homeSpot(rng, field)
	local ring, place = field and FIELD_RING or RING, field and inField or inPlace
	for _ = 1, 60 do
		local a, r = rng:NextNumber(0, 2 * math.pi), rng:NextNumber(ring[1] + 10, ring[2] - 15)
		local p = Vector3.new(math.cos(a) * r, 0, math.sin(a) * r)
		if place(p) then
			return p
		end
	end
	return nil
end

local function build()
	local rng = Random.new(SEED)
	for i = 1, GIANTS.Count do
		local home = homeSpot(rng)
		local giant = GIANTS.Species[(i - 1) % #GIANTS.Species + 1]
		if home then
			-- (2026-10-03, "안전지대 야생공룡들도 크기 다양화") each giant a little bigger or smaller (GIANT_SIZE)
			addAnimal(giant[1], GIANTS.Height * giant[2] * rng:NextNumber(GIANT_SIZE[1], GIANT_SIZE[2]), home, GIANTS.Roam,
				GIANTS.Leg, "giant")
		end
	end
	for i = 1, PACKS.Count do
		local home = homeSpot(rng)
		local species = PACKS.Species[(i - 1) % #PACKS.Species + 1] -- every kind at least once
		local size = PACKS.Height * rng:NextNumber(FIELD_GROUP_SIZE[1], FIELD_GROUP_SIZE[2]) -- (2026-10-03: as the battlefield's)
		for _ = 1, rng:NextInteger(PACKS.Size[1], PACKS.Size[2]) do
			if home then
				local near = home + Vector3.new(rng:NextNumber(-5, 5), 0, rng:NextNumber(-5, 5))
				local young = rng:NextNumber() < FIELD_YOUNG.Chance and FIELD_YOUNG.Size or 1
				addAnimal(species, size * young * rng:NextNumber(FIELD_ONE_SIZE[1], FIELD_ONE_SIZE[2]), near, PACKS.Roam,
					PACKS.Leg, "runner", PACKS.WalkShare)
			end
		end
	end
	local herdOrder = table.clone(HERDS.Species) -- different kinds first, in a mixed order
	for i = #herdOrder, 2, -1 do
		local j = rng:NextInteger(1, i)
		herdOrder[i], herdOrder[j] = herdOrder[j], herdOrder[i]
	end
	for i = 1, HERDS.Count do
		local home = homeSpot(rng)
		local species = herdOrder[(i - 1) % #herdOrder + 1]
		local size = HERDS.Height * rng:NextNumber(FIELD_GROUP_SIZE[1], FIELD_GROUP_SIZE[2]) -- (2026-10-03: as the battlefield's)
		for _ = 1, rng:NextInteger(HERDS.Size[1], HERDS.Size[2]) do
			if home then
				local near = home + Vector3.new(rng:NextNumber(-6, 6), 0, rng:NextNumber(-6, 6))
				local young = rng:NextNumber() < FIELD_YOUNG.Chance and FIELD_YOUNG.Size or 1
				addAnimal(species, size * young * rng:NextNumber(FIELD_ONE_SIZE[1], FIELD_ONE_SIZE[2]), near, HERDS.Roam,
					HERDS.Leg, "mini")
			end
		end
	end
	-- the battlefield's (2026-10-03, see the top; the same seed: the same on every screen)
	for i = 1, FIELD_PACKS.Count do
		local home = homeSpot(rng, true)
		local species = FIELD_PACKS.Species[(i - 1) % #FIELD_PACKS.Species + 1]
		local size = FIELD_PACKS.Height * rng:NextNumber(FIELD_GROUP_SIZE[1], FIELD_GROUP_SIZE[2])
		for _ = 1, rng:NextInteger(FIELD_PACKS.Size[1], FIELD_PACKS.Size[2]) do
			if home then
				local near = home + Vector3.new(rng:NextNumber(-5, 5), 0, rng:NextNumber(-5, 5))
				local young = rng:NextNumber() < FIELD_YOUNG.Chance and FIELD_YOUNG.Size or 1
				addAnimal(species, size * young * rng:NextNumber(FIELD_ONE_SIZE[1], FIELD_ONE_SIZE[2]), near, FIELD_PACKS.Roam,
					FIELD_PACKS.Leg, "runner", FIELD_PACKS.WalkShare, true)
			end
		end
	end
	for i = 1, FIELD_HERDS.Count do
		local home = homeSpot(rng, true)
		local species = FIELD_HERDS.Species[(i - 1) % #FIELD_HERDS.Species + 1]
		local size = FIELD_HERDS.Height * rng:NextNumber(FIELD_GROUP_SIZE[1], FIELD_GROUP_SIZE[2])
		for _ = 1, rng:NextInteger(FIELD_HERDS.Size[1], FIELD_HERDS.Size[2]) do
			if home then
				local near = home + Vector3.new(rng:NextNumber(-6, 6), 0, rng:NextNumber(-6, 6))
				local young = rng:NextNumber() < FIELD_YOUNG.Chance and FIELD_YOUNG.Size or 1
				addAnimal(species, size * young * rng:NextNumber(FIELD_ONE_SIZE[1], FIELD_ONE_SIZE[2]), near, FIELD_HERDS.Roam,
					FIELD_HERDS.Leg, "mini", nil, true)
			end
		end
	end
end

-- leg k's end spot for an animal: the same on every screen (a Random seeded by the animal and k)
local spots = {} -- [animal id] = { [k] = Vector3 }
local groundParams = RaycastParams.new()
groundParams.FilterType = Enum.RaycastFilterType.Exclude
groundParams.RespectCanCollide = true
local function groundY(p)
	local ignore = { folder, player.Character }
	local map = Workspace:FindFirstChild("Map")
	for _, name in ipairs(NOT_GROUND) do
		local f = map and map:FindFirstChild(name)
		if f then
			table.insert(ignore, f)
		end
	end
	for _, name in ipairs(NOT_GROUND_TOP) do
		local f = Workspace:FindFirstChild(name)
		if f then
			table.insert(ignore, f)
		end
	end
	for _, other in ipairs(Players:GetPlayers()) do
		if other.Character then
			table.insert(ignore, other.Character)
		end
	end
	groundParams.FilterDescendantsInstances = ignore
	local hit = Workspace:Raycast(Vector3.new(p.X, 200, p.Z), Vector3.new(0, -400, 0), groundParams)
	return hit and hit.Position.Y or 0.2
end
local function spot(a, k)
	local list = spots[a.id]
	if not list then
		list = {}
		spots[a.id] = list
	end
	if list[k] then
		return list[k]
	end
	local rng = Random.new(SEED + a.id * 7919 + k * 104729)
	local p = a.home
	for _ = 1, 8 do
		local angle, r = rng:NextNumber(0, 2 * math.pi), rng:NextNumber(0, a.roam)
		local q = a.home + Vector3.new(math.cos(angle) * r, 0, math.sin(angle) * r)
		if a.place(q) then
			p = q
			break
		end
	end
	p = Vector3.new(p.X, groundY(p), p.Z)
	list[k] = p
	list[k - 3] = nil -- old legs are not needed again
	return p
end

local function ease(t)
	return t * t * (3 - 2 * t)
end

-- where an animal is now: position, facing, walking speed, standing (grazing?)
local function where(a, now)
	local t = now + a.offset
	local k = math.floor(t / a.leg)
	local frac = (t % a.leg) / a.leg
	local from, to = spot(a, k - 1), spot(a, k)
	local flat = Vector3.new(to.X - from.X, 0, to.Z - from.Z)
	local dir = flat.Magnitude > 0.1 and flat.Unit or nil
	if frac < a.walkShare then
		local q = frac / a.walkShare
		return from:Lerp(to, ease(q)), dir, flat.Magnitude / (a.leg * a.walkShare) * 1.5 * math.sin(math.pi * q), nil
	end
	local grazing = Random.new(SEED + a.id * 31 + k):NextNumber() < GRAZE_CHANCE
	return to, dir, 0, grazing
end

local function makeModel(a)
	local models = ReplicatedStorage:FindFirstChild("DinoModels")
	local source = models and models:FindFirstChild("Dino_" .. a.species, true)
	if not source and (a.tries or 0) >= FALLBACK_AFTER then -- not imported: its kind's stand-in
		source = models and models:FindFirstChild("Dino_" .. FALLBACK[a.kind], true)
	end
	if not source then
		a.tries = (a.tries or 0) + 1
		return nil
	end
	local model = Instance.new("Model")
	model.Name = a.species
	source:Clone().Parent = model
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
			d.CastShadow = a.kind == "giant"
		elseif d:IsA("Script") or d:IsA("LocalScript") or d:IsA("ProximityPrompt") or d:IsA("BillboardGui") then
			d:Destroy()
		end
	end
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
	model:ScaleTo(a.height / math.max(size.Y, 0.1))
	model.Parent = folder
	return model
end

build()

local practice = nil
local function practiceHome()
	local at = player:GetAttribute("WildSpot")
	if typeof(at) ~= "Vector3" or ReplicatedStorage:GetAttribute("TutorialField") then
		return nil
	end
	return at + Vector3.new(PRACTICE_DINO.From, 0, 0)
end
local function placePractice()
	local home = practiceHome()
	if not home then
		return
	end
	if not practice then
		addAnimal(PRACTICE_DINO.Species, PRACTICE_DINO.Height, home, PRACTICE_DINO.Roam, PRACTICE_DINO.Leg, "mini")
		practice = animals[#animals]
		practice.practice = true
		practice.place = function(q)
			return Vector3.new(q.X - practice.home.X, 0, q.Z - practice.home.Z).Magnitude <= practice.roam
		end
	elseif (practice.home - home).Magnitude > 0.5 then
		practice.home = home
		spots[practice.id] = nil
	end
end
player:GetAttributeChangedSignal("WildSpot"):Connect(placePractice)
placePractice()

local areaText, areaRects = nil, nil
local function keepIn(p)
	local text = player:GetAttribute("OpenArea")
	if not text then
		return p
	end
	if text ~= areaText then
		areaText, areaRects = text, Formulas.rectsOf(text)
	end
	local map = Workspace:FindFirstChild("Map")
	local base = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	local zone = base and base:FindFirstChild("SafeZone")
	if not areaRects or not zone then
		return p
	end
	local q = zone.CFrame:PointToObjectSpace(p)
	if Formulas.inRects(areaRects, q.X, q.Z, KEEP_IN) then
		return p
	end
	local x, z = Formulas.intoRects(areaRects, q.X, q.Z, KEEP_IN)
	local w = zone.CFrame:PointToWorldSpace(Vector3.new(x, q.Y, z))
	return Vector3.new(w.X, p.Y, w.Z)
end

local drawn = {} -- [animal] = { model, rig, dir, nextBellow, prompt }

-- ---------------------------------------------------------------------------
-- Climbing onto one (see the top)
-- ---------------------------------------------------------------------------

local riding = nil -- { animal, untilTime }
local lastRide = -math.huge

local WILD = Formulas.unlockOf("Wild")

local function closedIn()
	if not WILD or ReplicatedStorage:GetAttribute("TutorialField") then
		return false
	end
	local state = player:GetAttribute("Facility" .. WILD.Id)
	return state == "Locked" or state == "Ready"
end

local function canRide()
	return not riding and not player:GetAttribute("Riding") and not player:GetAttribute("Racing")
		and (player:GetAttribute("StunnedUntil") or 0) <= Workspace:GetServerTimeNow()
		and os.clock() - lastRide >= Config.Wildlife.RideCooldown and not closedIn()
end

local function startRide(a)
	local d = drawn[a]
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not d or not humanoid or not canRide() then
		return
	end
	lastRide = os.clock()
	riding = { animal = a, untilTime = os.clock() + Config.Wildlife.RideSeconds, pos = d.at, dir = d.dir }
	player:SetAttribute("WildRiding", Config.Wildlife.RideSeconds)
	humanoid.PlatformStand = true -- held on its back by this screen until the throw
	-- sitting on its back: the character's own sit animation (its Animate script's "sit")
	local animator = humanoid:FindFirstChildOfClass("Animator")
	local animate = character:FindFirstChild("Animate")
	local sit = animate and animate:FindFirstChild("sit")
	local animation = sit and sit:FindFirstChildOfClass("Animation")
	if animator and animation then
		local track = animator:LoadAnimation(animation)
		track.Priority = Enum.AnimationPriority.Action
		track:Play(0.1)
		riding.sitTrack = track
	end
	Net.request("WildRide", a.kind == "giant") -- (2026-10-04: a giant's buck sounds heavy, a little one's light)
end

local function endRide()
	local r = riding
	riding = nil
	player:SetAttribute("WildRiding", nil)
	local back = r and drawn[r.animal]
	if back and r.pos and r.path then
		back.rideBack = { offset = r.pos - r.path, start = os.clock() }
	end
	if r and r.sitTrack then
		r.sitTrack:Stop(0.1)
	end
	local d = r and drawn[r.animal]
	if d then -- it rears up and roars (the server's throw comes with it)
		DinoMotion.roar(d.rig)
		local name, pitch = GIANT_ROAR[1], GIANT_ROAR[2]
		if r.animal.kind ~= "giant" then
			name, pitch = DinoVoices.voice(r.animal.species)
		end
		Sfx.play(name, d.model:GetPivot().Position + Vector3.new(0, r.animal.height * 0.8, 0), pitch)
	end
	-- the server's throw (Knockback) takes over from here; should it not come, stand up again anyway
	local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	task.delay(Config.Wildlife.ThrowFlight + 1, function()
		if humanoid and humanoid.Parent and humanoid.PlatformStand and not riding then
			humanoid.PlatformStand = false
		end
	end)
end

-- the prompt on a drawn dino, at its feet (bigger reach for the giants)
local function rideReach(a)
	return Config.Wildlife.RideRange * (a.kind == "giant" and Config.Wildlife.GiantRangeScale or 1)
end

-- the prompt of a drawn dino: on a point that follows my character (see the top)
local function addPrompt(a, d)
	local attachment = Instance.new("Attachment")
	attachment.Name = "RidePoint"
	attachment.Parent = Workspace.Terrain
	d.promptPoint = attachment
	local prompt = Instance.new("ProximityPrompt")
	prompt.ActionText = "🦖 올라타기"
	prompt.ObjectText = a.kind == "giant" and "거대 공룡" or "야생 공룡"
	prompt.KeyboardKeyCode = RIDE_KEY
	prompt.HoldDuration = 0
	prompt.RequiresLineOfSight = false
	prompt.MaxActivationDistance = PROMPT_NEAR + 6 -- (it is always right by me; the real reach is checked each frame)
	prompt:SetAttribute("Kind", "WildRide")
	prompt.Triggered:Connect(function()
		startRide(a)
	end)
	prompt.Parent = attachment
	d.prompt = prompt
end
-- ---------------------------------------------------------------------------
-- Slapped (see the top)
-- ---------------------------------------------------------------------------

local function slapperRoot(r)
	local slapper = Players:GetPlayerByUserId(r.slapperId)
	return slapper and slapper.Character and slapper.Character:FindFirstChild("HumanoidRootPart")
end

local function sayLine(a, d, lines)
	local part = d.model:FindFirstChildWhichIsA("BasePart", true)
	if part then
		local top = (d.at and d.at.Y or part.Position.Y) + a.height + SAY_GAP
		SpeechBubble.say(d, part, top - part.Position.Y, lines[math.random(1, #lines)], { edge = SAY_EDGE })
	end
end

local function voice(a, at, pitchTimes)
	local name, pitch = DinoVoices.voice(a.species)
	if a.kind == "giant" then
		name, pitch = GIANT_ROAR[1], GIANT_ROAR[2]
	end
	Sfx.play(name, at, pitch * (pitchTimes or 1))
end

-- back onto its path from where it is now (neutral again)
local function goBack(d)
	d.react = { phase = "back", start = os.clock(), from = d.at }
end

-- where a slapped little one is, and how: position, facing, leg speed, extra turn (nil: walking its path)
local function reactPose(a, d, pathPos, pathDir, dt)
	local w = Config.Wildlife
	local r = d.react
	local t = os.clock() - r.start
	local h = a.height
	if r.phase == "fly" then
		local q = math.min(1, t / w.SlapFlySeconds)
		if q >= 1 then
			Fx.burst(r.to + Vector3.new(0, 0.5, 0), DUST, 14, 8, 0.5, 0.5)
			d.react = { phase = "down", start = os.clock(), at = r.to, dir = r.dir, slapperId = r.slapperId, origin = r.origin,
				flee = r.flee }
		end
		-- (it faces the slapper and goes over backwards, about its middle)
		local spin = CFrame.new(0, h / 2, 0) * CFrame.Angles(SLAP_TUMBLE * q, 0, 0) * CFrame.new(0, -h / 2, 0)
		return r.from:Lerp(r.to, q) + Vector3.new(0, math.sin(math.pi * q) * SLAP_ARC, 0), r.dir, 0, spin
	elseif r.phase == "down" then
		if t >= w.SlapDownSeconds and (a.field or r.flee) then -- up, and away (on the battlefield: see the top)
			local root = slapperRoot(r)
			local away = root and Vector3.new(r.at.X - root.Position.X, 0, r.at.Z - root.Position.Z)
			r.phase, r.start, r.groundAt = "flee", os.clock(), 0
			r.dir = away and away.Magnitude > 0.1 and away.Unit or -r.dir
			sayLine(a, d, FLEE_LINES)
			voice(a, r.at, 1.2)
		elseif t >= w.SlapDownSeconds then -- up, and after them
			r.phase, r.start, r.groundAt = "chase", os.clock(), 0
			sayLine(a, d, ANGRY_LINES)
			voice(a, r.at)
			DinoMotion.roar(d.rig)
		end
		local roll = LIE_ROLL + LIE_WRIGGLE * math.sin(t * LIE_WRIGGLE_SPEED)
		return r.at, r.dir, 0, CFrame.new(0, h * 0.25, 0) * CFrame.Angles(0, 0, roll)
	elseif r.phase == "stuck" then
		if t >= Config.Bombs.RootSeconds then
			r.pile:Destroy()
			goBack(d)
			return r.at, r.dir, 0, nil
		end
		return r.at, r.dir, 0, CFrame.Angles(0, math.sin(t * LIE_WRIGGLE_SPEED) * LIE_WRIGGLE, 0)
	elseif r.phase == "flee" then
		if t >= FLEE_SECONDS then
			goBack(d)
			return r.at, r.dir, 0, nil
		end
		local ahead = r.at + r.dir * FLEE_SPEED * dt
		if inField(ahead) then
			r.at = ahead
		end
		r.groundAt -= dt
		if r.groundAt <= 0 then
			r.groundAt = CHASE_GROUND_EVERY
			r.at = Vector3.new(r.at.X, groundY(r.at), r.at.Z)
		end
		return r.at, r.dir, FLEE_SPEED, nil
	elseif r.phase == "chase" then
		local root = slapperRoot(r)
		if not root or t > w.ChaseSeconds
			or Vector3.new(root.Position.X - r.origin.X, 0, root.Position.Z - r.origin.Z).Magnitude > w.ChaseLeash then
			sayLine(a, d, GIVE_UP_LINES)
			goBack(d)
			return r.at, r.dir, 0, nil
		end
		local flat = Vector3.new(root.Position.X - r.at.X, 0, root.Position.Z - r.at.Z)
		if flat.Magnitude > 0.1 then
			r.dir = flat.Unit
		end
		if flat.Magnitude <= w.CounterReach then -- caught: the slap back
			DinoMotion.attack(d.rig)
			voice(a, r.at)
			Sfx.play("SlapHit", root.Position)
			sayLine(a, d, HIT_LINES)
			if r.slapperId == player.UserId then -- (my own screen asks; the server throws me)
				Net.request("WildCounter", r.dir.X, r.dir.Z)
			end
			goBack(d)
			return r.at, r.dir, 0, nil
		end
		local step = math.min(flat.Magnitude - w.CounterReach * 0.5, w.ChaseSpeed * dt)
		r.at += r.dir * step
		r.groundAt -= dt
		if r.groundAt <= 0 then
			r.groundAt = CHASE_GROUND_EVERY
			r.at = Vector3.new(r.at.X, groundY(r.at), r.at.Z)
		end
		return r.at, r.dir, w.ChaseSpeed, nil
	end
	-- back: walking from where it is to where its path has got to
	local q = t / JOLT_BACK_SECONDS
	if q >= 1 then
		d.react = nil
		return pathPos, pathDir, 0, nil
	end
	local flat = Vector3.new(pathPos.X - r.from.X, 0, pathPos.Z - r.from.Z)
	local dir = flat.Magnitude > 0.5 and flat.Unit or pathDir
	return r.from:Lerp(pathPos, ease(q)), dir, flat.Magnitude / JOLT_BACK_SECONDS * 1.5 * math.sin(math.pi * q), nil
end

-- a giant's kick: rears back, then stamps forward with a little shake
local function kickPose(a, d)
	local t = (os.clock() - d.kick.start) / KICK_SECONDS
	if t >= 1 then
		d.kick = nil
		return nil
	end
	if t >= KICK_HIT and not d.kick.landed then
		d.kick.landed = true
		local at = d.at or a.home
		Sfx.play("DinoStomp", at, KICK_PITCH)
		Fx.burst(at + Vector3.new(0, 1, 0), DUST, 20, 14, 1.2, 0.7)
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if d.kick.slapperId == player.UserId and root then -- (my own screen asks; the server throws me)
			local away = Vector3.new(root.Position.X - at.X, 0, root.Position.Z - at.Z)
			away = away.Magnitude > 0.1 and away.Unit or Vector3.xAxis
			Net.request("WildKick", away.X, away.Z)
		end
	end
	local tilt = t < KICK_HIT and KICK_REAR * math.sin(math.pi / 2 * t / KICK_HIT)
		or KICK_REAR * (1 - (t - KICK_HIT) / (1 - KICK_HIT)) * math.cos(t * 40)
	local hind = a.height * KICK_HIND -- (it rears up on its hind legs: turned about them)
	return CFrame.new(0, 0, hind) * CFrame.Angles(tilt, 0, 0) * CFrame.new(0, 0, -hind)
end

Net.onPush("SlapFx", function(slapperId, _, level)
	local slapper = Players:GetPlayerByUserId(slapperId)
	local root = slapper and slapper.Character and slapper.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end
	local w = Config.Wildlife
	local reach = Formulas.slapReach(math.clamp(tonumber(level) or 1, 1, #Config.Slap.Scale))
	local look = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z)
	look = look.Magnitude > 0.01 and look.Unit or Vector3.zAxis
	local yelped, kicked = false, false
	for a, d in pairs(drawn) do
		local at = d.at
		local busy = (riding and riding.animal == a)
			or (d.react and d.react.phase ~= "chase" and d.react.phase ~= "flee" and d.react.phase ~= "back")
		if at and not busy then
			local offset = Vector3.new(at.X - root.Position.X, 0, at.Z - root.Position.Z)
			local body = a.kind == "giant" and a.height * GIANT_BODY or SLAP_BODY
			local gap = math.max(0, offset.Magnitude - body)
			local away = offset.Magnitude > 0.1 and offset.Unit or look
			if gap <= reach and (gap < Config.Slap.CloseRadius or away:Dot(look) >= Config.Slap.FrontDot) then
				if a.kind == "giant" then
					if not kicked and not d.kick then -- (one giant kicks)
						kicked = true
						d.kick = { start = os.clock(), slapperId = slapperId }
						DinoMotion.attack(d.rig)
						Sfx.play("SlapHit", root.Position + away * reach * 0.5)
						Sfx.play("GiantGrowl", at + Vector3.new(0, a.height * 0.5, 0))
					end
				else
					local to = at + away * w.SlapFlyStuds
					d.react = { phase = "fly", start = os.clock(), from = at, to = Vector3.new(to.X, groundY(to), to.Z),
						dir = -away, slapperId = slapperId, origin = root.Position }
					sayLine(a, d, OUCH_LINES)
					if not yelped then -- (one smack and one squeal a slap, however many it hits)
						yelped = true
						Sfx.play("SlapHit", at)
						Sfx.play("DinoYelp", at, math.max(YELP_PITCH_MIN, YELP_PITCH_AT_1 - YELP_PITCH_PER_STUD * (a.height - 1)))
					end
				end
			end
		end
	end
end)

local sinceCheck = CHECK_EVERY
RunService.RenderStepped:Connect(FrameMeter.wrap("Wildlife", function(dt)
	local camera = Workspace.CurrentCamera
	local eye = camera and camera.CFrame.Position or Vector3.zero
	local now = Workspace:GetServerTimeNow()
	sinceCheck += dt
	if sinceCheck >= CHECK_EVERY then -- who is near enough to draw
		sinceCheck = 0
		local off = player:GetAttribute("HideWildlife") == true -- the view setting "야생 공룡" (less lag)
		local smallShare = player:GetAttribute("LightMode") == true and LIGHT_DISTANCE_SHARE
			or player:GetAttribute("LowDetail") and LOW_DISTANCE_SHARE or 1
		-- the battlefield's: the nearest FIELD_DRAW_MAX within FIELD_DRAW_DISTANCE (see the top)
		local fieldNear, allowed = {}, {}
		if not off then
			for _, a in ipairs(animals) do
				if a.field then
					local gap = (Vector3.new(a.home.X, eye.Y, a.home.Z) - eye).Magnitude
					if gap <= FIELD_DRAW_DISTANCE + a.roam then
						table.insert(fieldNear, { a, gap - (drawn[a] and FIELD_KEEP or 0) })
					end
				end
			end
			table.sort(fieldNear, function(x, y)
				return x[2] < y[2]
			end)
			local lightMode = player:GetAttribute("LightMode") == true
			local most = lightMode and LIGHT_FIELD_MAX or player:GetAttribute("LowDetail") and LOW_FIELD_MAX or FIELD_DRAW_MAX
			for i = 1, math.min(#fieldNear, most) do
				allowed[fieldNear[i][1]] = true
			end
		end
		local made = 0
		for _, a in ipairs(animals) do
			local near
			if a.practice then
				near = practiceHome() ~= nil
			elseif a.field then
				near = allowed[a] == true
			else
				local share = a.kind == "giant" and 1 or smallShare
				near = not off and (Vector3.new(a.home.X, eye.Y, a.home.Z) - eye).Magnitude <= DRAW_DISTANCE[a.kind] * share + a.roam
			end
			local d = drawn[a]
			if near and not d and os.clock() >= (a.retryAt or 0) and made >= MAKE_PER_FRAME then
				sinceCheck = CHECK_EVERY
			elseif near and not d and os.clock() >= (a.retryAt or 0) then
				made += 1
				local model = makeModel(a)
				if model then
					drawn[a] = { model = model, rig = DinoMotion.new(model), nextBellow = os.clock() + math.random(BELLOW_EVERY[1],
						BELLOW_EVERY[2]) }
					if not a.field then -- (no riding on the battlefield)
						addPrompt(a, drawn[a])
					end
				else
					a.retryAt = os.clock() + RETRY_SECONDS -- not loaded yet (or not imported): look again later
				end
			elseif not near and d and not (riding and riding.animal == a) and not (d.react and not off) then
				d.model:Destroy()
				if d.react and d.react.pile then
					d.react.pile:Destroy()
				end
				if d.promptPoint then
					d.promptPoint:Destroy()
				end
				drawn[a] = nil
			end
		end
	end
	local canNow = canRide()
	for a, d in pairs(drawn) do
		-- (2026-10-04, "또 렉있는 거 같은데 빡세게 최적화": every drawn dino's path, ground and grazing were worked out every
		-- frame and only the move skipped far away) a far one not due this frame (Shared/Lod) is left alone altogether
		local mine = riding and riding.animal == a
		local due, step = Lod.due(d, ((d.at or a.home) - eye).Magnitude, dt)
		if not (due or d.react or d.kick or d.jolt or mine) then
			continue
		end
		local dt = due and step or dt -- (its own: the time since it last moved)
		local pos, dir, speed, grazing = where(a, now)
		-- its path goes straight from one spot's ground to the next one's: over a dip between them it walked on air
		-- (in a rise, under the ground). Now on the ground under it, looked at every GROUND_EVERY and eased in
		d.groundAt = (d.groundAt or 0) - dt
		if d.groundAt <= 0 then
			d.groundAt = GROUND_EVERY
			d.groundGoal = speed > 0 and groundY(pos) - pos.Y or 0
		end
		d.groundFix = (d.groundFix or d.groundGoal) + (d.groundGoal - (d.groundFix or d.groundGoal)) * math.min(1, dt * GROUND_EASE)
		pos += Vector3.new(0, d.groundFix, 0)
		if d.jolt then -- thrown aside by a bolt, then back onto its path
			local t = os.clock() - d.jolt.start
			if t >= JOLT_SECONDS + JOLT_BACK_SECONDS then
				d.jolt = nil
			elseif t < JOLT_SECONDS then
				local q = t / JOLT_SECONDS
				pos += d.jolt.away * ease(q) + Vector3.new(0, math.sin(math.pi * q) * JOLT_HEIGHT, 0)
				speed = 0
			else
				pos += d.jolt.away * (1 - ease((t - JOLT_SECONDS) / JOLT_BACK_SECONDS))
			end
		end
		if mine and riding.pos then
			riding.path = pos
			local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
			local move = humanoid and humanoid.MoveDirection or Vector3.zero
			move = Vector3.new(move.X, 0, move.Z)
			if move.Magnitude > 0.1 then
				move = move.Unit
				riding.pos = keepIn(riding.pos + move * Config.Wildlife.RideSteerSpeed * dt)
				riding.dir = move
				speed = Config.Wildlife.RideSteerSpeed
			else
				speed = 0
			end
			pos = Vector3.new(riding.pos.X, groundY(riding.pos), riding.pos.Z)
			riding.pos = pos
			dir = riding.dir
			grazing = false
		elseif d.rideBack then
			local t = (os.clock() - d.rideBack.start) / RIDE_BACK_SECONDS
			if t >= 1 then
				d.rideBack = nil
			else
				pos += d.rideBack.offset * (1 - ease(t))
			end
		end
		local extra = nil
		if d.react then -- slapped: flying, lying, chasing or walking back (see the top)
			pos, dir, speed, extra = reactPose(a, d, pos, dir or d.dir, dt)
			grazing = false
		elseif d.kick then
			extra = kickPose(a, d)
		end
		d.at = pos
		d.dir = dir or d.dir or Vector3.new(0, 0, -1)
		DinoMotion.graze(d.rig, grazing == true)
		d.model:PivotTo(CFrame.lookAt(pos, pos + d.dir) * (extra or CFrame.identity) * DinoMotion.step(d.rig, dt, speed))
		if d.prompt then -- shown beside me while I am within reach of this dino
			local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
			local flat = root and Vector3.new(pos.X - root.Position.X, 0, pos.Z - root.Position.Z)
			local inReach = flat ~= nil and flat.Magnitude <= rideReach(a)
			if inReach then
				local toward = flat.Magnitude > 0.1 and flat.Unit or Vector3.zero
				d.promptPoint.WorldPosition = root.Position + toward * PROMPT_NEAR + Vector3.new(0, PROMPT_UP, 0)
			end
			d.prompt.Enabled = canNow and inReach
		end
		if riding and riding.animal == a then -- me on its back
			local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
			if root then
				local seat = pos + Vector3.new(0, a.height * BACK_SHARE + 1.5, 0)
				root.CFrame = CFrame.lookAt(seat, seat + d.dir)
				root.AssemblyLinearVelocity = Vector3.zero
			end
			if os.clock() >= riding.untilTime then
				endRide()
			end
		end
		if a.kind == "giant" and os.clock() >= d.nextBellow then
			d.nextBellow = os.clock() + math.random(BELLOW_EVERY[1], BELLOW_EVERY[2])
			if (pos - eye).Magnitude <= BELLOW_DISTANCE then
				Sfx.play("VoiceBellow", pos + Vector3.new(0, a.height * 0.8, 0), BELLOW_PITCH)
			end
		end
	end
end))

Net.onPush("WildFed", function(left)
	if riding then
		riding.untilTime = os.clock() + left
		local d = drawn[riding.animal]
		if d then
			local top = d.model:GetPivot().Position + Vector3.new(0, riding.animal.height, 0)
			Fx.burst(top, { Color3.fromRGB(255, 120, 160), Color3.fromRGB(255, 220, 120) }, 18, 10, 0.7, 0.8)
			Sfx.play("DinoBite", top, 1.4)
		end
	end
end)

-- (2026-10-02) a storm bolt (Lightning service): the wild dinos drawn within its reach hop away and yelp
Net.onPush("Lightning", function(x, y, z, warnSeconds, radius)
	task.delay(warnSeconds, function()
		local now = Workspace:GetServerTimeNow()
		local yelped = false
		for a, d in pairs(drawn) do
			if not (riding and riding.animal == a) then
				local pos = where(a, now)
				local off = Vector3.new(pos.X - x, 0, pos.Z - z)
				local reach = radius + (a.kind == "giant" and a.height * 0.3 or a.height * 0.5)
				if off.Magnitude <= reach then
					if a.kind ~= "giant" then
						d.jolt = { start = os.clock(), away = (off.Magnitude > 0.1 and off.Unit or Vector3.xAxis) * JOLT_STUDS }
					end
					if not yelped then
						yelped = true
						if a.kind == "giant" then -- (2026-10-02: the slapped ones' sounds)
							Sfx.play("GiantGrowl", pos + Vector3.new(0, a.height * 0.5, 0))
						else
							Sfx.play("DinoYelp", pos, math.max(YELP_PITCH_MIN, YELP_PITCH_AT_1 - YELP_PITCH_PER_STUD * (a.height - 1)))
						end
					end
				end
			end
		end
	end)
end)

-- a word about the weather now and then (see WEATHER_LINES)
task.spawn(function()
	while true do
		task.wait(math.random(WEATHER_SAY_EVERY[1], WEATHER_SAY_EVERY[2]))
		local lines = WEATHER_LINES[ReplicatedStorage:GetAttribute("Weather") or "Clear"]
		local camera = Workspace.CurrentCamera
		if lines and camera then
			local near = {}
			for a, d in pairs(drawn) do
				if a.field and d.at and not d.react and not d.kick and not (riding and riding.animal == a)
					and (d.at - camera.CFrame.Position).Magnitude <= WEATHER_SAY_NEAR then
					table.insert(near, { a, d })
				end
			end
			if #near > 0 then
				local pick = near[math.random(1, #near)]
				sayLine(pick[1], pick[2], lines)
			end
		end
	end
end)

local function poopPile(at, height)
	local pile = Instance.new("Model")
	pile.Name = "WildPoop"
	local size = math.max(POOP_SIZE_MIN, height * POOP_SIZE_SHARE)
	for i, tier in ipairs(POOP_TIERS) do
		local p = Instance.new("Part")
		p.Shape = Enum.PartType.Ball
		p.Size = Vector3.one * size * tier[1]
		p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
		p.Color = POOP_COLORS[(i - 1) % #POOP_COLORS + 1]
		p.Position = at + Vector3.new(0, height + size * tier[2], 0)
		p.Parent = pile
	end
	pile.Parent = Workspace
	return pile
end

Net.onPush("BombBlast", function(kind, at, _, _, _, reach, throwerId)
	if typeof(at) ~= "Vector3" then
		return
	end
	reach = tonumber(reach) or Config.Slap.ReachBase
	local w = Config.Wildlife
	local yelped = false
	for a, d in pairs(drawn) do
		local pos = d.at
		if pos and not (riding and riding.animal == a) then
			local offset = Vector3.new(pos.X - at.X, 0, pos.Z - at.Z)
			local body = a.kind == "giant" and a.height * GIANT_BODY or SLAP_BODY
			if offset.Magnitude - body <= reach then
				local away = offset.Magnitude > 0.1 and offset.Unit or Vector3.xAxis
				if d.react and d.react.pile then
					d.react.pile:Destroy()
				end
				if kind == "Poop" then
					d.kick = nil
					d.react = { phase = "stuck", start = os.clock(), at = pos, dir = d.dir or -away, pile = poopPile(pos, a.height) }
					sayLine(a, d, POOP_LINES)
				elseif a.kind == "giant" then
					DinoMotion.roar(d.rig)
					sayLine(a, d, BOOM_LINES)
				else
					local to = pos + away * w.SlapFlyStuds
					d.react = { phase = "fly", start = os.clock(), from = pos, to = Vector3.new(to.X, groundY(to), to.Z),
						dir = -away, slapperId = tonumber(throwerId) or 0, origin = at, flee = true }
					sayLine(a, d, OUCH_LINES)
				end
				if not yelped then
					yelped = true
					if a.kind == "giant" then
						Sfx.play("GiantGrowl", pos + Vector3.new(0, a.height * 0.5, 0))
					else
						Sfx.play("DinoYelp", pos, math.max(YELP_PITCH_MIN, YELP_PITCH_AT_1 - YELP_PITCH_PER_STUD * (a.height - 1)))
					end
				end
			end
		end
	end
end)
