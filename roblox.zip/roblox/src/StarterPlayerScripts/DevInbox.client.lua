local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(Shared:WaitForChild("Net"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer
if not Formulas.isDeveloper(player.Name) then
	return
end

local FONT = Enum.Font.GothamBold
local BUTTON_SIZE = UDim2.fromOffset(58, 30)
local BUTTON_POS = UDim2.new(0, 148, 1, -30)
local WINDOW_SIZE = Vector2.new(620, 380)
local ROW_HEIGHT = 74
local COLOR_BG = Color3.fromRGB(28, 32, 46)
local COLOR_ROW = Color3.fromRGB(44, 50, 70)
local COLOR_BUTTON = Color3.fromRGB(90, 110, 170)
local COLOR_TEXT = Color3.new(1, 1, 1)
local COLOR_SOFT = Color3.fromRGB(180, 190, 215)

local gui = Instance.new("ScreenGui")
gui.Name = "DevInbox"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local function corner(parent, r)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, r)
	c.Parent = parent
end

local function textButton(parent, text, size, pos)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 14
	b.TextColor3 = COLOR_TEXT
	b.BackgroundColor3 = COLOR_BUTTON
	b.Text = text
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 8)
	return b
end

local open = textButton(gui, "📬", BUTTON_SIZE, BUTTON_POS)
open.AnchorPoint = Vector2.new(0, 1)

local window = Instance.new("Frame")
window.Name = "DevInboxWindow"
window.AnchorPoint = Vector2.new(0.5, 0.5)
window.Position = UDim2.fromScale(0.5, 0.5)
window.Size = UDim2.fromOffset(WINDOW_SIZE.X, WINDOW_SIZE.Y)
window.BackgroundColor3 = COLOR_BG
window.Visible = false
window.Parent = gui
corner(window, 12)

local title = Instance.new("TextLabel")
title.BackgroundTransparency = 1
title.Font = FONT
title.TextSize = 18
title.TextColor3 = COLOR_TEXT
title.TextXAlignment = Enum.TextXAlignment.Left
title.Size = UDim2.new(1, -200, 0, 36)
title.Position = UDim2.fromOffset(14, 6)
title.Parent = window

local back = 0
local older = textButton(window, "◀", UDim2.fromOffset(40, 30), UDim2.new(1, -150, 0, 8))
local newer = textButton(window, "▶", UDim2.fromOffset(40, 30), UDim2.new(1, -104, 0, 8))

local list = Instance.new("ScrollingFrame")
list.BackgroundTransparency = 1
list.Size = UDim2.new(1, -20, 1, -56)
list.Position = UDim2.fromOffset(10, 48)
list.ScrollBarThickness = 6
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = window
local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 6)
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = list

local function show()
	for _, child in ipairs(list:GetChildren()) do
		if child:IsA("GuiObject") then
			child:Destroy()
		end
	end
	local reports = Net.ask("GetReports", back) or {}
	title.Text = string.format("📬 신고함 · %d일 전 · %d개", back, #reports)
	for i, r in ipairs(reports) do
		local row = Instance.new("TextLabel")
		row.BackgroundColor3 = COLOR_ROW
		row.Font = FONT
		row.TextSize = 13
		row.TextColor3 = i == 1 and COLOR_TEXT or COLOR_SOFT
		row.TextWrapped = true
		row.TextXAlignment = Enum.TextXAlignment.Left
		row.TextYAlignment = Enum.TextYAlignment.Top
		row.Size = UDim2.new(1, -8, 0, ROW_HEIGHT)
		row.LayoutOrder = i
		row:SetAttribute("KeepText", true)
		row.Text = string.format("%s  %s  [%s]  LV%d\n%s%s", os.date("!%m-%d %H:%M", r.Time or 0), tostring(r.Name),
			tostring(r.Kind), r.Level or 0, tostring(r.Text), r.Errors and ("\n⚠️ " .. tostring(r.Errors)) or "")
		row.Parent = list
		corner(row, 8)
		local pad = Instance.new("UIPadding")
		pad.PaddingLeft, pad.PaddingTop = UDim.new(0, 8), UDim.new(0, 6)
		pad.Parent = row
	end
end

open.Activated:Connect(function()
	window.Visible = not window.Visible
	if window.Visible then
		show()
	end
end)
older.Activated:Connect(function()
	back = math.min(back + 1, Config.Beta.InboxDays)
	show()
end)
newer.Activated:Connect(function()
	back = math.max(back - 1, 0)
	show()
end)
Windows.register(window)
Windows.fit(window)
