local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Unlock = require(Shared:WaitForChild("Unlock"))
local WitchTalk = require(Shared:WaitForChild("WitchTalk"))

local QUEUE_WAIT = 90
local QUEUE_CHECK = 0.5
local COOLDOWNS = { Twist = 45 }
local BUSY = { "HideSeekRole", "RaceProgress" }
local HOLD = { "Cinematic", "TopView" }

local player = Players.LocalPlayer
local lastAt = {}

local function any(names)
	for _, name in ipairs(names) do
		if player:GetAttribute(name) then
			return true
		end
	end
	return false
end

local function busy()
	return any(BUSY)
end

local function show(id, text, n, explain)
	local spec = Config.Story.Shows[id]
	text = text or Config.Story.Lines[id]
	if not spec or not text or text == "" or busy() or (spec.Unlock and not Unlock.usable(spec.Unlock)) then
		return
	end
	local now = os.clock()
	if COOLDOWNS[id] and now - (lastAt[id] or -math.huge) < COOLDOWNS[id] then
		return
	end
	lastAt[id] = now
	WitchTalk.say(text, WitchTalk.faceFor(id, n), { explain = explain, slot = spec.Slot or id, queue = true })
end

Net.onPush("WitchShow", function(id, text, n, explain)
	if any(HOLD) then
		task.spawn(function()
			local waited = 0
			while any(HOLD) and waited < QUEUE_WAIT do
				waited += task.wait(QUEUE_CHECK)
			end
			if not any(HOLD) then
				show(id, text, n, explain)
			end
		end)
		return
	end
	show(id, text, n, explain)
end)

for _, name in ipairs(BUSY) do
	player:GetAttributeChangedSignal(name):Connect(function()
		if busy() then
			WitchTalk.close(true)
		end
	end)
end
player:GetAttributeChangedSignal("TopView"):Connect(function()
	if player:GetAttribute("TopView") then
		WitchTalk.close(true)
	end
end)
