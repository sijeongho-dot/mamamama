--[[
Bombs: buying and throwing bombs on this client (the server's Bombs service decides everything).

- The bomb stall's prompt (Kind "BombShop", my own base): a small window with each kind (Config.Bombs.Kinds:
  💥 알 폭탄, 💩 똥 폭탄): its big picture, name and how many I hold ("🎒 3/20", player attributes BombsEgg /
  BombsPoop, at most MaxHeld), what it does in one short line led by pictures (its Short), the price at my level
  (Formulas.bombPrice) and what one pays on a boss, and "1개" / "가득" buttons with their prices (Net request
  BuyBombs). (2026-10-04, "폭탄 상점 정보도 정리해줘": shorter, pictures first.)
- A round button for each kind I hold, up and to the left of the slap button (clear of the pickaxe line over
  the bag bar), with the count; dim while the throw cooldown runs (attribute BombReadyAt). Keys 1 / 2 too.
- Aiming (2026-10-01, "hard to hit: hold the button, show the arc and where it lands, move to change the
  distance"): holding a bomb button shows the throw's arc (dots) and where it lands: a see-through white
  disc as wide as the blast (my slap reach; reddish off the battlefield, where it does nothing). It starts
  AIM_START_SHARE of the way out in front of the camera; dragging moves it like a stick (up = farther,
  down = nearer, sideways = round), never past Config.Bombs.ThrowRange. Letting go throws it there (Net
  request ThrowBomb(kind, aim)). With a mouse, holding key 1 / 2 aims where the mouse points; letting go
  throws.
- Cancelling (2026-10-03, "폭탄날릴때 폭탄 날리기 취소도 있어야"): while aiming, a red "✖ 취소" spot shows over the bomb
  buttons; letting go over it (the finger, the mouse, or the key with the mouse on it) throws nothing. A right click
  cancels too.
- Net push BombFx: the bomb (its model, Item_EggBomb / Item_PoopBomb, else a plain ball) flies in an arc to where it
  lands, a shadow growing there; BombBlast: the
  blast, a ring as wide as it reaches (the thrower's slap reach), a boom or a splat; off the battlefield
  only a puff ("배틀필드 밖이라 아무 일도 없어요" to the thrower).
]]

local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(Shared:WaitForChild("Windows"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Fx = require(Shared:WaitForChild("Fx"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local Coach = require(Shared:WaitForChild("Coach"))
local Unlock = require(Shared:WaitForChild("Unlock"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local BUTTON_SIZE = UDim2.fromOffset(48, 48)
-- (2026-10-01: were over the pickaxe line, hiding it) up and to the left of the slap button, left of the
-- "keys down" button's place, above the pickaxe line
local BUTTON_POS = { Egg = UDim2.new(1, -272, 1, -66), Poop = UDim2.new(1, -326, 1, -66) }
local BUTTON_COLOR = { Egg = Color3.fromRGB(230, 120, 50), Poop = Color3.fromRGB(140, 95, 55) }
local COLOR_WAIT = Color3.fromRGB(100, 100, 110)
local KEYS = { Egg = Enum.KeyCode.One, Poop = Enum.KeyCode.Two }
local CANCEL_SIZE = UDim2.fromOffset(84, 60) -- the "✖ 취소" spot while aiming ...
local CANCEL_POS = UDim2.new(1, -299, 1, -122) -- ... its bottom middle: over the two bomb buttons
local CANCEL_COLOR = Color3.fromRGB(200, 60, 60)
local CANCEL_OVER_COLOR = Color3.fromRGB(255, 80, 80) -- the finger over it
local CANCEL_SLACK = 10 -- pixels round it that still count
local WINDOW_SIZE = UDim2.fromOffset(340, 270) -- (narrow enough to keep clear of the 🔔 button on small phones)
local ROW_HEIGHT = 92
local PICTURE = 64 -- the bomb's big picture at the start of its row (its model, ReplicatedStorage.ItemModels; the emoji
-- until it arrives)
local FLIGHT_HEIGHT = 1.8 -- studs: a thrown bomb's model is this tall (2026-10-04: was a plain ball)
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_ROW = Color3.fromRGB(45, 50, 68)
local COLOR_BUY = Color3.fromRGB(80, 170, 90)
local COLOR_FULL = Color3.fromRGB(70, 130, 200)
local COLOR_CLOSE = Color3.fromRGB(235, 70, 80)
local COLOR_SOFT = Color3.fromRGB(190, 190, 200)
local CLOSE_SLACK = 6 -- studs past the prompt's reach that close the window
local LOOKS = { -- the bomb in flight: color, size
	Egg = { Color3.fromRGB(170, 220, 80), Vector3.new(1.3, 1.7, 1.3) },
	Poop = { Color3.fromRGB(110, 70, 40), Vector3.new(1.6, 1.4, 1.6) },
}
local ARC_HEIGHT = 9 -- studs over the straight line at the middle of the flight
local BLAST_COLORS = {
	Egg = { Color3.fromRGB(255, 200, 70), Color3.fromRGB(255, 120, 40), Color3.fromRGB(255, 255, 220) },
	Poop = { Color3.fromRGB(110, 70, 40), Color3.fromRGB(150, 100, 60) },
}
local RING_SECONDS = 0.5
local DRAW_DISTANCE = 400
-- the aiming guide
local AIM_START_SHARE = 0.6 -- of the throw range, straight ahead, before any drag
local AIM_DRAG_PIXELS = 140 -- a drag this long moves the landing spot a whole throw range
local AIM_DOTS = 16
local AIM_DOT_SIZE = 0.45
local AIM_DOT_COLOR = Color3.fromRGB(255, 255, 255)
local AIM_DISC_COLOR = Color3.fromRGB(255, 255, 255)
local AIM_DISC_OFF_COLOR = Color3.fromRGB(255, 110, 110) -- off the battlefield: it would do nothing
local AIM_DISC_TRANSPARENCY = 0.72
local AIM_DISC_EDGE = 0.18 -- the brighter rim's share of the disc
local AIM_MIN = 3 -- studs: never right on top of me
local GROUND_LOOK = 200 -- studs up and down for the ground under the landing spot (as the server's Bombs)

local gui = Instance.new("ScreenGui")
gui.Name = "Bombs"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.TextWrapped = true
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 13
	b.TextColor3 = Color3.new(1, 1, 1)
	b.BackgroundColor3 = color
	b.Text = text
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 8)
	return b
end

-- ---------------------------------------------------------------------------
-- Throwing
-- ---------------------------------------------------------------------------

local function myRoot()
	return player.Character and player.Character:FindFirstChild("HumanoidRootPart")
end

local function ready(kind)
	return (player:GetAttribute("Bombs" .. kind) or 0) > 0
		and (player:GetAttribute("BombReadyAt") or 0) <= Workspace:GetServerTimeNow()
end

-- the ground under a spot (players and the guide itself left out), as the server finds it
local guideFolder = Instance.new("Folder")
guideFolder.Name = "BombGuide"
local function groundAt(position)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true
	local ignore = { guideFolder }
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	params.FilterDescendantsInstances = ignore
	local hit = Workspace:Raycast(position + Vector3.new(0, GROUND_LOOK / 2, 0), Vector3.new(0, -GROUND_LOOK, 0), params)
	return hit and hit.Position or position
end

-- where a throw toward aim lands: at most ThrowRange away, on the ground (as the server works it out)
local function landing(root, aim)
	local flat = Vector3.new(aim.X - root.Position.X, 0, aim.Z - root.Position.Z)
	if flat.Magnitude < 0.1 then
		flat = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z)
	end
	local distance = math.clamp(flat.Magnitude, AIM_MIN, Config.Bombs.ThrowRange)
	return groundAt(root.Position + flat.Unit * distance)
end

-- the camera's forward and right along the ground
local function cameraAxes(root)
	local camera = Workspace.CurrentCamera
	local look = camera and camera.CFrame.LookVector or root.CFrame.LookVector
	local forward = Vector3.new(look.X, 0, look.Z)
	forward = forward.Magnitude > 1e-3 and forward.Unit or Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z).Unit
	return forward, forward:Cross(Vector3.yAxis)
end

-- where the mouse points on the ground
local function mousePoint()
	local mouse = UserInputService:GetMouseLocation()
	local ray = Workspace.CurrentCamera:ViewportPointToRay(mouse.X, mouse.Y)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { player.Character, guideFolder }
	local hit = Workspace:Raycast(ray.Origin, ray.Direction * 1000, params)
	return hit and hit.Position
end

-- the guide: dots along the arc and the disc where it lands
local dots = {}
for i = 1, AIM_DOTS do
	local d = Instance.new("Part")
	d.Name = "Dot"
	d.Shape = Enum.PartType.Ball
	d.Size = Vector3.one * AIM_DOT_SIZE
	d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
	d.Material = Enum.Material.Neon
	d.Color = AIM_DOT_COLOR
	d.Transparency = 0.15 + 0.5 * (i / AIM_DOTS) -- fainter toward the end
	d.Parent = guideFolder
	dots[i] = d
end
local function disc(name, transparency)
	local p = Instance.new("Part")
	p.Name = name
	p.Shape = Enum.PartType.Cylinder
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
	p.Material = Enum.Material.SmoothPlastic
	p.Color = AIM_DISC_COLOR
	p.Transparency = transparency
	p.Parent = guideFolder
	return p
end
local rim = disc("Rim", AIM_DISC_TRANSPARENCY) -- (the bigger one under: a brighter edge round the disc)
local fill = disc("Disc", 1 - (1 - AIM_DISC_TRANSPARENCY) * 0.6)

local function showGuide(from, to)
	if not guideFolder.Parent then
		guideFolder.Parent = Workspace
	end
	for i, d in ipairs(dots) do
		local k = i / (AIM_DOTS + 1)
		d.CFrame = CFrame.new(from:Lerp(to, k) + Vector3.new(0, ARC_HEIGHT * 4 * k * (1 - k), 0))
	end
	local radius = Formulas.slapReach(player:GetAttribute("TrainReal_Slap") or player:GetAttribute("SlapLevel") or 1)
	local map = Workspace:FindFirstChild("Map")
	local base = map and player:GetAttribute("Base") and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	local arena = base and base:GetAttribute("ArenaFrame")
	local onTrack = typeof(arena) == "CFrame" and (to - arena.Position).Magnitude <= Config.Placement.EditRange
	local color = SafeZones.isSafe(to) and not onTrack and AIM_DISC_OFF_COLOR or AIM_DISC_COLOR
	local flat = CFrame.new(to + Vector3.new(0, 0.12, 0)) * CFrame.Angles(0, 0, math.rad(90))
	rim.Size = Vector3.new(0.1, radius * 2, radius * 2)
	rim.CFrame = flat
	rim.Color = color
	local inner = radius * 2 * (1 - AIM_DISC_EDGE)
	fill.Size = Vector3.new(0.12, inner, inner)
	fill.CFrame = flat * CFrame.new(0.01, 0, 0)
	fill.Color = color
end

local function hideGuide()
	guideFolder.Parent = nil
end

-- aiming now: { kind, mode ("drag": a finger or the mouse held on the button; "mouse": key 1 / 2 held, aim
-- where the mouse points), touch (the finger's InputObject), start and now (Vector2, the drag), target (Vector3) }
local aiming = nil

local function aimTarget(root)
	if aiming.mode == "mouse" then
		return mousePoint() or (root.Position + root.CFrame.LookVector * Config.Bombs.ThrowRange * AIM_START_SHARE)
	end
	local forward, right = cameraAxes(root)
	if aiming.touch then
		aiming.now = Vector2.new(aiming.touch.Position.X, aiming.touch.Position.Y)
	end
	local offset = aiming.now - aiming.start
	local range = Config.Bombs.ThrowRange
	local out = forward * (range * AIM_START_SHARE) + (right * offset.X - forward * offset.Y) * (range / AIM_DRAG_PIXELS)
	if out.Magnitude > range then -- (as far as it goes, no farther)
		out = out.Unit * range
	end
	return root.Position + out
end

local bombsOpen = Unlock.usable("Bombs")
Unlock.watch(function()
	bombsOpen = Unlock.usable("Bombs")
end)

local function startAim(kind, mode, touch)
	if aiming or not bombsOpen or not ready(kind) or not myRoot() then
		return
	end
	local start = touch and Vector2.new(touch.Position.X, touch.Position.Y) or UserInputService:GetMouseLocation()
	aiming = { kind = kind, mode = mode, touch = touch, start = start, now = start }
end

-- the "✖ 취소" spot (shown while aiming)
local cancelSpot = Instance.new("TextLabel")
cancelSpot.Name = "BombCancel"
cancelSpot.AnchorPoint = Vector2.new(0.5, 1)
cancelSpot.Size = CANCEL_SIZE
cancelSpot.Position = CANCEL_POS
cancelSpot.BackgroundColor3 = CANCEL_COLOR
cancelSpot.BackgroundTransparency = 0.15
cancelSpot.Font = FONT
cancelSpot.TextSize = 15
cancelSpot.TextColor3 = Color3.new(1, 1, 1)
cancelSpot.Text = "✖ 취소"
cancelSpot.Visible = false
cancelSpot.Parent = gui
do
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 12)
	c.Parent = cancelSpot
	local stroke = Instance.new("UIStroke")
	stroke.Color = Color3.new(1, 1, 1)
	stroke.Thickness = 2
	stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	stroke.Parent = cancelSpot
end

-- the pointer now (GUI space: Roblox's top bar left out), for the cancel spot
local function pointer()
	if aiming and aiming.touch then
		return Vector2.new(aiming.touch.Position.X, aiming.touch.Position.Y)
	end
	return UserInputService:GetMouseLocation() - GuiService:GetGuiInset()
end

local function overCancel(at)
	local p, size = cancelSpot.AbsolutePosition, cancelSpot.AbsoluteSize
	return at.X >= p.X - CANCEL_SLACK and at.X <= p.X + size.X + CANCEL_SLACK
		and at.Y >= p.Y - CANCEL_SLACK and at.Y <= p.Y + size.Y + CANCEL_SLACK
end

local function endAim(throwIt)
	local a = aiming
	if throwIt and a and cancelSpot.Visible and overCancel(pointer()) then
		throwIt = false -- (let go on ✖ 취소)
	end
	aiming = nil
	cancelSpot.Visible = false
	hideGuide()
	local root = myRoot()
	if throwIt and a and a.target and root and ready(a.kind) then
		Net.request("ThrowBomb", a.kind, a.target)
	end
end

RunService.RenderStepped:Connect(FrameMeter.wrap("Bombs", function()
	if not aiming then
		return
	end
	local root = myRoot()
	if not root or not ready(aiming.kind) then
		return endAim(false)
	end
	aiming.target = landing(root, aimTarget(root))
	showGuide(root.Position, aiming.target)
	cancelSpot.Visible = true
	cancelSpot.BackgroundColor3 = overCancel(pointer()) and CANCEL_OVER_COLOR or CANCEL_COLOR
end))

local buttons = {}
for _, k in ipairs(Config.Bombs.Kinds) do
	local b = Instance.new("TextButton")
	b.Name = "Bomb" .. k.Id
	b.AnchorPoint = Vector2.new(1, 1)
	b.Size = BUTTON_SIZE
	b.Position = BUTTON_POS[k.Id]
	b.BackgroundColor3 = BUTTON_COLOR[k.Id]
	b.Font = FONT
	b.TextSize = 15
	b.TextColor3 = Color3.new(1, 1, 1)
	b.AutoButtonColor = false
	b.Visible = false
	b.Parent = gui
	Coach.mark(b, "Bomb" .. k.Id)
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = b
	b.InputBegan:Connect(function(input) -- held down: aim
		if input.UserInputType == Enum.UserInputType.Touch then
			startAim(k.Id, "drag", input)
		elseif input.UserInputType == Enum.UserInputType.MouseButton1 then
			startAim(k.Id, "drag", nil) -- (the mouse moving drags it: InputChanged below)
		end
	end)
	buttons[k.Id] = { button = b, kind = k }
end

-- a mouse held on the button moves the aim like a finger does
UserInputService.InputChanged:Connect(function(input)
	if aiming and aiming.mode == "drag" and not aiming.touch and input.UserInputType == Enum.UserInputType.MouseMovement then
		aiming.now = UserInputService:GetMouseLocation()
	end
end)

UserInputService.InputEnded:Connect(function(input) -- let go: throw
	if not aiming then
		return
	end
	local keyUp = input.KeyCode == KEYS[aiming.kind]
	local fingerUp = aiming.touch ~= nil and input == aiming.touch
	local mouseUp = aiming.mode == "drag" and not aiming.touch and input.UserInputType == Enum.UserInputType.MouseButton1
	if keyUp or fingerUp or mouseUp then
		endAim(true)
	end
end)

UserInputService.InputBegan:Connect(function(input, processed)
	if aiming and input.UserInputType == Enum.UserInputType.MouseButton2 then -- (a right click: no throw)
		endAim(false)
		return
	end
	if processed then
		return
	end
	for kind, key in pairs(KEYS) do
		if input.KeyCode == key then
			startAim(kind, UserInputService.MouseEnabled and "mouse" or "drag", nil)
		end
	end
end)

RunService.Heartbeat:Connect(FrameMeter.wrap("Bombs", function()
	local wait = (player:GetAttribute("BombReadyAt") or 0) - Workspace:GetServerTimeNow()
	for kind, entry in pairs(buttons) do
		local n = player:GetAttribute("Bombs" .. kind) or 0
		entry.button.Visible = bombsOpen and n > 0 and not Windows.anyOpen() and not player:GetAttribute("TopView")
		entry.button.Text = wait > 0 and string.format("%s\n%d", entry.kind.Icon, math.ceil(wait))
			or string.format("%s\n×%d", entry.kind.Icon, n)
		entry.button.BackgroundColor3 = wait > 0 and COLOR_WAIT or BUTTON_COLOR[kind]
	end
end))

-- ---------------------------------------------------------------------------
-- The bomb stall window
-- ---------------------------------------------------------------------------

local window = Instance.new("Frame")
window.AnchorPoint = Vector2.new(0.5, 0.5)
window.Position = UDim2.fromScale(0.5, 0.5)
window.Size = WINDOW_SIZE
window.BackgroundColor3 = COLOR_BG
window.Visible = false
window.Parent = gui
corner(window, 14)
Windows.fit(window)
local title = label(window, "💣 폭탄 상점", UDim2.new(1, -60, 0, 34), UDim2.fromOffset(14, 6), 20)
title.TextXAlignment = Enum.TextXAlignment.Left
local hint = label(window, "⚔️ 기지 밖 들판에서만 펑! · ⌨️ [1] [2]", UDim2.new(1, -28, 0, 18), UDim2.fromOffset(14, 38), 12)
hint.TextXAlignment = Enum.TextXAlignment.Left
hint.TextColor3 = COLOR_SOFT
local close = button(window, "X", COLOR_CLOSE, UDim2.fromOffset(34, 34), UDim2.new(1, -42, 0, 8))
close.TextSize = 16
local rows = {}
for i, k in ipairs(Config.Bombs.Kinds) do
	local row = Instance.new("Frame")
	row.Size = UDim2.new(1, -20, 0, ROW_HEIGHT)
	row.Position = UDim2.fromOffset(10, 60 + (i - 1) * (ROW_HEIGHT + 8))
	row.BackgroundColor3 = COLOR_ROW
	row.Parent = window
	corner(row, 10)
	local icon = label(row, k.Icon, UDim2.fromOffset(PICTURE, PICTURE), UDim2.fromOffset(4, (ROW_HEIGHT - PICTURE) / 2), 40)
	icon.TextScaled = true
	-- (2026-10-04, "폭탄 상점도 모델링 박고") its model instead of the emoji, once the models are there
	task.spawn(function()
		local models = ReplicatedStorage:WaitForChild("ItemModels", 60)
		local source = models and k.Model and models:WaitForChild(k.Model, 10)
		if source and icon.Parent then
			icon.Text = ""
			DinoPortrait.ofModel(source, UDim2.fromScale(1, 1)).Parent = icon
		end
	end)
	local name = label(row, "", UDim2.new(1, -180, 0, 22), UDim2.fromOffset(PICTURE + 8, 6), 15)
	name.TextXAlignment = Enum.TextXAlignment.Left
	local text = label(row, k.Short, UDim2.new(1, -180, 0, 34), UDim2.fromOffset(PICTURE + 8, 30), 12)
	text.TextXAlignment = Enum.TextXAlignment.Left
	text.TextYAlignment = Enum.TextYAlignment.Top
	text.TextColor3 = COLOR_SOFT
	local price = label(row, "", UDim2.new(1, -180, 0, 18), UDim2.fromOffset(PICTURE + 8, 66), 12)
	price.TextXAlignment = Enum.TextXAlignment.Left
	price.TextColor3 = Color3.fromRGB(255, 215, 90)
	local one = button(row, "", COLOR_BUY, UDim2.fromOffset(100, 38), UDim2.new(1, -108, 0, 6))
	Coach.mark(one, "BombBuy")
	local full = button(row, "", COLOR_FULL, UDim2.fromOffset(100, 38), UDim2.new(1, -108, 0, 48))
	one.Activated:Connect(function()
		Net.request("BuyBombs", k.Id, 1)
	end)
	full.Activated:Connect(function()
		Net.request("BuyBombs", k.Id, Config.Bombs.MaxHeld)
	end)
	rows[k.Id] = { name = name, price = price, kind = k, one = one, full = full }
end

local function refreshWindow()
	local level = player:GetAttribute("DefenseLevel") or 1
	for id, r in pairs(rows) do
		local held = player:GetAttribute("Bombs" .. id) or 0
		r.name.Text = string.format("%s · 🎒 %d/%d", r.kind.Name, held, Config.Bombs.MaxHeld)
		local price = Formulas.bombPrice(level, id)
		local onBoss = Formulas.bossHitMoney(level, Formulas.bombBossDamage(player:GetAttribute("TrainReal_Slap") or player:GetAttribute("SlapLevel") or 1, id))
		-- (2026-10-01, "would anyone buy bombs not knowing what they get") what one pays on a boss, at my level
		r.price.Text = onBoss > 0 and string.format("👑 보스에 맞히면 💰 +%s원", Formulas.shortNumber(onBoss)) or ""
		local room = Config.Bombs.MaxHeld - held
		r.one.Text = string.format("🛒 1개\n💰 %s원", Formulas.shortNumber(price))
		r.full.Text = room > 0 and string.format("🛒 가득 %d개\n💰 %s원", room, Formulas.shortNumber(price * room)) or "🎒 가득 찼어요"
		r.one.BackgroundColor3 = room > 0 and COLOR_BUY or COLOR_WAIT
		r.full.BackgroundColor3 = room > 0 and COLOR_FULL or COLOR_WAIT
	end
end
for _, k in ipairs(Config.Bombs.Kinds) do
	player:GetAttributeChangedSignal("Bombs" .. k.Id):Connect(function()
		if window.Visible then
			refreshWindow()
		end
	end)
end

local openedBy = nil
ProximityPromptService.PromptTriggered:Connect(function(prompt)
	if prompt:GetAttribute("Kind") == "BombShop" and prompt:GetAttribute("Base") == player:GetAttribute("Base") then
		if window.Visible then -- E again closes it
			window.Visible = false
			return
		end
		openedBy = prompt
		refreshWindow()
		window.Visible = true
	end
end)
close.Activated:Connect(function()
	window.Visible = false
end)
RunService.Heartbeat:Connect(FrameMeter.wrap("Bombs", function() -- walked away from the stall: close it
	if window.Visible and openedBy then
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		local holder = openedBy.Parent -- (a part, or an attachment: Bases.prompt, 2026-10-02)
		local at = holder and (holder:IsA("Attachment") and holder.WorldPosition or holder:IsA("BasePart") and holder.Position)
		if not root or not at or (root.Position - at).Magnitude > openedBy.MaxActivationDistance + CLOSE_SLACK then
			window.Visible = false
		end
	end
end))
Windows.register(window)

-- ---------------------------------------------------------------------------
-- Flight and blast, on every screen
-- ---------------------------------------------------------------------------

local function plain(props)
	local p = Instance.new("Part")
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
	p.Material = Enum.Material.SmoothPlastic
	for k, v in pairs(props) do
		p[k] = v
	end
	p.Parent = Workspace
	return p
end

local function near(position)
	local camera = Workspace.CurrentCamera
	return camera and (camera.CFrame.Position - position).Magnitude <= DRAW_DISTANCE
end

Net.onPush("BombFx", function(_, kind, from, to, seconds)
	if typeof(from) ~= "Vector3" or typeof(to) ~= "Vector3" or not near(to) then
		return
	end
	local look = LOOKS[kind] or LOOKS.Egg
	local bomb
	local models = ReplicatedStorage:FindFirstChild("ItemModels")
	local kindInfo = Formulas.bombKind(kind)
	local source = models and kindInfo and kindInfo.Model and models:FindFirstChild(kindInfo.Model)
	if source then -- its model, at FLIGHT_HEIGHT, turning about its middle
		local model = Instance.new("Model")
		local copy = source:Clone()
		copy.Parent = model
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") then
				d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
			end
		end
		local cf, size = model:GetBoundingBox()
		model.WorldPivot = CFrame.new(cf.Position)
		model:ScaleTo(FLIGHT_HEIGHT / math.max(size.Y, 0.1))
		model:PivotTo(CFrame.new(from))
		model.Parent = Workspace
		bomb = model
	else
		bomb = plain({ Name = "Bomb", Shape = Enum.PartType.Ball, Size = look[2], Color = look[1], CFrame = CFrame.new(from) })
	end
	local fuse = Instance.new("Sparkles")
	fuse.SparkleColor = Color3.fromRGB(255, 200, 80)
	fuse.Parent = bomb:IsA("Model") and bomb:FindFirstChildWhichIsA("BasePart", true) or bomb
	local shadow = plain({ Name = "BombShadow", Shape = Enum.PartType.Cylinder, Size = Vector3.new(0.1, 0.6, 0.6),
		CFrame = CFrame.new(to + Vector3.new(0, 0.08, 0)) * CFrame.Angles(0, 0, math.rad(90)), Color = Color3.new(0, 0, 0),
		Transparency = 0.6 })
	TweenService:Create(shadow, TweenInfo.new(seconds), { Size = Vector3.new(0.1, 3, 3) }):Play()
	Sfx.play("SlapSwing", from)
	local t0 = os.clock()
	local conn
	conn = RunService.RenderStepped:Connect(FrameMeter.wrap("Bombs", function()
		local k = math.min(1, (os.clock() - t0) / seconds)
		local at = from:Lerp(to, k) + Vector3.new(0, ARC_HEIGHT * 4 * k * (1 - k), 0)
		bomb:PivotTo(CFrame.new(at) * CFrame.Angles(k * 9, k * 5, 0)) -- tumbling
		if k >= 1 then
			conn:Disconnect()
			bomb:Destroy()
			shadow:Destroy()
		end
	end))
end)

Net.onPush("BombBlast", function(kind, at, hitIds, spots, _, reach)
	if typeof(at) ~= "Vector3" or not near(at) then
		return
	end
	local colors = BLAST_COLORS[kind] or BLAST_COLORS.Egg
	Fx.burst(at + Vector3.new(0, 1, 0), colors, 40, 22, 0.9, 0.7)
	Sfx.play(kind == "Poop" and "BombSplat" or "BombBoom", at)
	local width = (tonumber(reach) or 8) * 2
	local ring = plain({ Name = "BlastRing", Shape = Enum.PartType.Cylinder, Size = Vector3.new(0.2, 1, 1),
		CFrame = CFrame.new(at + Vector3.new(0, 0.2, 0)) * CFrame.Angles(0, 0, math.rad(90)), Color = colors[1],
		Material = Enum.Material.Neon, Transparency = 0.3 })
	TweenService:Create(ring, TweenInfo.new(RING_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{ Size = Vector3.new(0.2, width, width), Transparency = 1 }):Play()
	task.delay(RING_SECONDS, function()
		ring:Destroy()
	end)
	for _, spot in ipairs(type(spots) == "table" and spots or {}) do
		if typeof(spot) == "Vector3" then
			Fx.burst(spot, colors, 12, 10, 0.5, 0.4)
		end
	end
	for _, id in ipairs(type(hitIds) == "table" and hitIds or {}) do
		local p = type(id) == "number" and Players:GetPlayerByUserId(id)
		local head = p and p.Character and p.Character:FindFirstChild("Head")
		if head then
			Fx.burst(head.Position, colors, 16, 12, 0.6, 0.5)
		end
	end
end)
