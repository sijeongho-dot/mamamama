--[[
Training (client): while I stand at a training station (player attribute TrainStation, the server's Training
service), a small panel at the top middle of the screen shows each of its tracks: the level now → next and a bar of the
seconds trained toward it (TrainXP_<track>, Formulas.trainSeconds) and the friend bonus (TrainFriend), and two
buttons side by side, a plain tap each (2026-10-04, "훈련 중 때문에 내 캐릭터가 안 보여.. 밑에 업글 버튼도 왼 오로 나눠서
넣어. 꾹 눌러요 같은거 필요 없고": was a tall panel, the buttons one under the other and held down; now short and up
under the top line, so my character shows, and hidden while a window is open): ⚡ the training boost (Net request BuyTrainBoost; its time left from TrainBoostUntil; 2026-10-04 moved
here from the shop, now the ⛏️ 곡괭이 상점) and 🔧 the station's next gear level (BuyTrainGear; TrainGear_<station>).
(2026-10-04, "아이들 입장에서") when nothing more trains here (all at the top, or the power steps waiting for the next
pickaxe), the panel says so and a red arrow over my head points to the station of my base whose next level comes
soonest (Shared/PointerArrow). Display only, but the button. (2026-10-04) Each track's line ends with its look's mark on
the body (✨🟢 … ✨🌈, Formulas.trainLookGrade; StarterPlayerScripts/TrainingLook draws it).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local PointerArrow = require(Shared:WaitForChild("PointerArrow"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local PANEL_WIDTH = 290 -- (2026-10-04: about half as high as before, was 270 wide and about 165 high; clear of the
-- mission card at the left and the ♾️ button at the right on an iPhone SE)
local PANEL_TOP = 24 -- pixels under the top of the screen (under the top line; was 64)
local TITLE_HEIGHT = 18 -- (as tall as the station's picture beside the name)
local ROW_HEIGHT = 22 -- a track: its words and its bar (two tracks side by side)
local ROW_TEXT = 14
local BAR_HEIGHT = 6
local GEAR_HEIGHT = 30 -- the two buttons side by side (above the move stick's area: tools/check_phone_ui.py)
local PICTURE = 18 -- (2026-10-04, "모든 정보가 최대한 그림으로") the station's picture at the panel's top left
local PAD = 6
local REFRESH_EVERY = 0.25
local TAP_GAP = 0.6 -- seconds: a second tap this soon is a double tap, not a second buy
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_BAR_BACK = Color3.fromRGB(55, 60, 80)
local COLOR_BAR = Color3.fromRGB(160, 120, 255)
local COLOR_FRIEND = Color3.fromRGB(120, 220, 255)
local COLOR_DONE = Color3.fromRGB(130, 255, 140)
local COLOR_GEAR = Color3.fromRGB(70, 150, 230)
local COLOR_BOOST_BUTTON = Color3.fromRGB(200, 90, 200)
local COLOR_DISABLED = Color3.fromRGB(90, 90, 100)
local ARROW_COLOR = Color3.fromRGB(240, 50, 50)
local ARROW_UP = 4.5 -- studs over my character's middle
local ARROW_SIZES = { 15, 150, 1.6, 0.6 } -- (PointerArrow.point)

local REACH_Y = 8 -- studs above or below a station still count (as the Training service)

local LEVEL_ATTRIBUTE = { Speed = "PickaxeSpeed", Slap = "SlapLevel", MoveSpeed = "MoveSpeedLevel", Bag = "BagLevel" }

local gui = Instance.new("ScreenGui")
gui.Name = "Training"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(0.5, 0)
panel.Position = UDim2.new(0.5, 0, 0, PANEL_TOP)
panel.BackgroundColor3 = COLOR_BG
panel.BackgroundTransparency = 0.2
panel.Visible = false
panel.Parent = gui
do
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 10)
	c.Parent = panel
end

local function label(parent, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextSize = textSize
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextStrokeTransparency = 0.5
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.Size = size
	l.Position = pos
	l.TextScaled = true -- (a long line, in Spanish say, shrinks to fit the panel instead of running out of it)
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = textSize
	most.Parent = l
	l.Parent = parent
	return l
end

local title = label(panel, UDim2.new(1, -3 * PAD - PICTURE, 0, TITLE_HEIGHT), UDim2.fromOffset(2 * PAD + PICTURE, 2), 14)
local picture = Instance.new("Frame")
picture.BackgroundTransparency = 1
picture.Size = UDim2.fromOffset(PICTURE, PICTURE)
picture.Position = UDim2.fromOffset(PAD, 2)
picture.ZIndex = 2
picture.Parent = panel
local pictureOf = nil -- the station in the picture now
local function showPicture(st)
	if pictureOf == st.Id then
		return
	end
	local models = ReplicatedStorage:FindFirstChild("ItemModels")
	local source = models and models:FindFirstChild(st.Model)
	if not source then
		return -- (not there: the panel just has no picture; tried again next refresh)
	end
	pictureOf = st.Id
	picture:ClearAllChildren()
	DinoPortrait.ofModel(source, UDim2.fromScale(1, 1)).Parent = picture
end
local rows = {}
for i = 1, 2 do
	local text = label(panel, UDim2.new(1, -2 * PAD, 0, ROW_TEXT), UDim2.new(), 13)
	local back = Instance.new("Frame")
	back.Size = UDim2.new(1, -2 * PAD, 0, BAR_HEIGHT)
	back.BackgroundColor3 = COLOR_BAR_BACK
	back.Parent = panel
	local fill = Instance.new("Frame")
	fill.BackgroundColor3 = COLOR_BAR
	fill.Size = UDim2.fromScale(0, 1)
	fill.Parent = back
	for _, f in ipairs({ back, fill }) do
		local c = Instance.new("UICorner")
		c.CornerRadius = UDim.new(0, 4)
		c.Parent = f
	end
	rows[i] = { text = text, back = back, fill = fill }
end
-- (2026-10-04) the friend bonus and "all done here" go in the title line, so the panel keeps its height
local COLOR_TITLE = Color3.new(1, 1, 1)

local function panelButton()
	local b = Instance.new("TextButton")
	b.Size = UDim2.new(0.5, -PAD * 1.5, 0, GEAR_HEIGHT)
	b.Font = FONT
	b.TextScaled = true -- (half the panel: a long line shrinks)
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = 13
	most.Parent = b
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, 4), UDim.new(0, 4)
	pad.PaddingTop, pad.PaddingBottom = UDim.new(0, 3), UDim.new(0, 3)
	pad.Parent = b
	b.TextColor3 = Color3.new(1, 1, 1)
	b.TextStrokeTransparency = 0.6
	b.AutoButtonColor = true
	b.Parent = panel
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 8)
	c.Parent = b
	return b
end
local boostButton = panelButton()
local gear = panelButton()

local STATIONS = {}
for _, st in ipairs(Config.Training.Stations) do
	STATIONS[st.Id] = st
end

local function levelOf(track)
	if track == "Power" then
		return (player:GetAttribute("PickaxeTier") or 1) - 1, player:GetAttribute("PickaxePower") or 0
	end
	return nil, player:GetAttribute(LEVEL_ATTRIBUTE[track]) or 0
end

local function realOf(track)
	local _, level = levelOf(track)
	return player:GetAttribute("TrainReal_" .. track) or level
end

-- a track's seconds to its next level, or nil when it can't go up now (the top, or the power steps all done); then
-- the level shown, whether it waits for the next pickaxe, and (2026-10-04) its look's mark on the body (🟢 … 🌈,
-- StarterPlayerScripts/TrainingLook; "" before the first)
local function nextNeed(track)
	local tierBefore, level = levelOf(track)
	local trainLevel = tierBefore and tierBefore * Config.Pickaxe.PowerSteps + level or level
	local mark = Config.Training.LookMarks[Formulas.trainLookGrade(track, trainLevel)] or ""
	if track == "Power" and level >= Formulas.powerStepsCap(player:GetAttribute("PickaxeTier") or 1) then
		return nil, level, true, mark
	end
	return Formulas.trainSeconds(track, trainLevel), level, false, mark
end

-- where a station of my base is (as the server works it out: the plot's front edge, across and in)
local function stationSpot(st)
	local center = player:GetAttribute("BaseCenter")
	if typeof(center) ~= "Vector3" then
		return nil
	end
	local flat = Vector3.new(center.X, 0, center.Z)
	if flat.Magnitude < 1e-3 then
		return nil
	end
	local out = flat.Unit
	local right = out:Cross(Vector3.yAxis).Unit
	local front = flat - out * Config.Map.PlotDepth / 2
	local spot = front + right * st.Spot[1] + out * st.Spot[2]
	return Vector3.new(spot.X, center.Y, spot.Z)
end

-- the station (other than `here`) whose next level comes soonest, and where it is
local function nextStation(here)
	local best, bestNeed = nil, math.huge
	for _, st in ipairs(Config.Training.Stations) do
		if st.Id ~= here then
			for _, track in ipairs(st.Tracks) do
				local need = nextNeed(track)
				if need then
					local xp = player:GetAttribute("TrainXP_" .. track) or 0
					if need - xp < bestNeed then
						best, bestNeed = st, need - xp
					end
				end
			end
		end
	end
	return best and stationSpot(best)
end

local arrow = nil

local function showArrow(target)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not target or not root then
		if arrow then
			arrow:Destroy()
			arrow = nil
		end
		return
	end
	if not arrow then
		arrow = PointerArrow.make(ARROW_COLOR)
	end
	PointerArrow.point(arrow, root.Position + Vector3.new(0, ARROW_UP, 0), target, ARROW_SIZES)
end

local function money()
	return player:GetAttribute("Money") or 0
end

local function place(item, y, height, x)
	item.Visible = true
	item.Position = UDim2.new(x or 0, (x or 0) > 0 and PAD / 2 or PAD, 0, y) -- (a right column: half a gap from the middle)
	return y + height
end

-- the station I train at now: the server's TrainStation, but gone at once when I step out of its ring
-- (2026-10-04, "훈련 끝나면 창 바로 닫히게": the server notices only at its next step, up to a second later)
local function stationHere()
	local st = STATIONS[player:GetAttribute("TrainStation") or ""]
	local at = player:GetAttribute("TrainAt")
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not st or typeof(at) ~= "Vector3" or not root then
		return st
	end
	local d = root.Position - at
	if Vector3.new(d.X, 0, d.Z).Magnitude > Config.Training.Range or math.abs(d.Y) > REACH_Y then
		return nil
	end
	return st
end

local function refresh()
	local st = stationHere()
	panel.Visible = st ~= nil and not Windows.anyOpen()
	if not st then
		showArrow(nil)
		return
	end
	showPicture(st)
	local y = 2 + TITLE_HEIGHT + 1
	local anyGoing = false
	local columns = #st.Tracks -- (two tracks: side by side, half the width each)
	for i, row in ipairs(rows) do
		local track = st.Tracks[i]
		row.text.Visible, row.back.Visible = false, false
		if track then
			local need, level, waiting, mark = nextNeed(track)
			local xp = player:GetAttribute("TrainXP_" .. track) or 0
			local name = Config.Training.Tracks[track].Name
			local tierBefore = levelOf(track)
			local trainLevel = tierBefore and tierBefore * Config.Pickaxe.PowerSteps + level or level
			if waiting then
				local nextTier = (player:GetAttribute("PickaxeTier") or 1) + 1
				local shown = (Formulas.trainShown(track, trainLevel, 0))
				row.text.Text = Formulas.pickaxeOpen(nextTier, player:GetAttribute("DefenseLevel"))
						and string.format("%s Lv %d 끝! ⛏️ 곡괭이 상점으로", name, shown)
					or string.format("%s Lv %d 끝! 🔒 ⚔️ 디펜스 %s", name, shown,
						Formulas.levelText(Formulas.pickaxeNeedLevel(nextTier)))
				row.fill.Size = UDim2.fromScale(1, 1)
			elseif need then
				anyGoing = true
				-- (2026-10-04, "여기에 굳이 초를 띄워야하나": was "· 0:17" after it) the bar shows how far, no clock
				-- (2026-10-04, "훈련레벨을 아주아주 많이 늘리고") the training level (up to Config.Training.TopLevel) and
				-- the bar toward the next one
				local shown, part = Formulas.trainShown(track, trainLevel, xp)
				row.text.Text = string.format("%s Lv %d · %s", name, shown, Formulas.trainValueText(track, realOf(track)))
					.. (mark ~= "" and " ✨" .. mark or "")
				row.fill.Size = UDim2.fromScale(part, 1)
			else
				row.text.Text = string.format("%s 최고 단계!", name) .. (mark ~= "" and " ✨" .. mark or "")
				row.fill.Size = UDim2.fromScale(1, 1)
			end
			local x = columns > 1 and (i - 1) / columns or 0
			local width = columns > 1 and UDim2.new(1 / columns, -PAD * 1.5, 0, 0) or UDim2.new(1, -2 * PAD, 0, 0)
			row.text.Size = width + UDim2.fromOffset(0, ROW_TEXT)
			row.back.Size = width + UDim2.fromOffset(0, BAR_HEIGHT)
			place(row.text, y, ROW_TEXT, x)
			place(row.back, y + ROW_TEXT + 1, BAR_HEIGHT, x)
		end
	end
	y += ROW_HEIGHT
	if not anyGoing then
		title.Text = "✅ 여기는 다 했어요! 화살표를 따라가요"
		title.TextColor3 = COLOR_DONE
	elseif player:GetAttribute("TrainFriend") == true then
		title.Text = string.format("%s · 👥 친구와 +%d%%", st.Name, math.floor(Config.Training.FriendBonus * 100 + 0.5))
		title.TextColor3 = COLOR_FRIEND
	else
		title.Text = string.format("%s · 💪 훈련 중", st.Name)
		title.TextColor3 = COLOR_TITLE
	end
	showArrow(not anyGoing and nextStation(st.Id) or nil)
	-- 🔧 the station's gear
	local gearLevel = player:GetAttribute("TrainGear_" .. st.Id) or 0
	local price = Formulas.trainGearPrice(gearLevel, player:GetAttribute("DefenseLevel") or 1)
	local per = Config.Training.Gear.PerLevel
	if price then
		gear.Text = string.format("🔧 훈련장 Lv.%d → %d (+%d%%)", gearLevel, gearLevel + 1,
			math.floor(per * (gearLevel + 1) * 100 + 0.5)) .. "\n" .. string.format("💰 %s원", Formulas.shortNumber(price))
		gear.BackgroundColor3 = money() >= price and COLOR_GEAR or COLOR_DISABLED
	else
		gear.Text = string.format("🔧 훈련장 최고 Lv.%d", gearLevel) .. "\n" .. string.format("훈련 +%d%%", math.floor(per * gearLevel * 100 + 0.5))
		gear.BackgroundColor3 = COLOR_DISABLED
	end
	-- ⚡ the boost
	local T = Config.Training
	local boostPrice = Formulas.trainBoostPrice(player:GetAttribute("DefenseLevel") or 1)
	local left = (player:GetAttribute("TrainBoostUntil") or 0) - Workspace:GetServerTimeNow()
	if left > 0 then
		boostButton.Text = string.format("⚡ %d배 중 · %d:%02d", T.BoostMultiplier, math.floor(left / 60), math.floor(left % 60))
			.. "\n" .. string.format("💰 %s원 · +%d분", Formulas.shortNumber(boostPrice), T.BoostMinutes)
	else
		boostButton.Text = string.format("⚡ 훈련 %d배 · %d분", T.BoostMultiplier, T.BoostMinutes) .. "\n"
			.. string.format("💰 %s원", Formulas.shortNumber(boostPrice))
	end
	boostButton.BackgroundColor3 = money() >= boostPrice and COLOR_BOOST_BUTTON or COLOR_DISABLED
	-- (2026-10-04) the two buttons side by side: ⚡ left, 🔧 right
	place(boostButton, y + 2, GEAR_HEIGHT, 0)
	y = place(gear, y + 2, GEAR_HEIGHT, 0.5)
	panel.Size = UDim2.fromOffset(PANEL_WIDTH, y + 5)
end

-- (a quick double tap buys once: the second tap inside TAP_GAP is not sent)
local lastTap = 0
local function tapOnce()
	local now = os.clock()
	if now - lastTap < TAP_GAP then
		return false
	end
	lastTap = now
	return true
end
boostButton.Activated:Connect(function()
	if tapOnce() then
		Net.request("BuyTrainBoost")
	end
end)
gear.Activated:Connect(function()
	if not tapOnce() then
		return
	end
	local id = player:GetAttribute("TrainStation")
	if id and Formulas.trainGearPrice(player:GetAttribute("TrainGear_" .. id) or 0) then
		Net.request("BuyTrainGear", id)
	end
end)

RunService.Heartbeat:Connect(FrameMeter.wrap("Training", function() -- (hidden at once under an opened window, back when it closes)
	local want = stationHere() ~= nil and not Windows.anyOpen()
	if panel.Visible ~= want then
		refresh()
	end
end))

task.spawn(function()
	while true do
		refresh()
		task.wait(REFRESH_EVERY)
	end
end)

-- ---------------------------------------------------------------------------
-- (2026-10-04, "훈련레벨을 아주아주 많이 늘리고, 그에따라 레벨업 하는게 눈에 잘 띄게해줘") a training level-up (Net push
-- TrainLevelFx from the Training service): over the trainee's head a big "⬆️ Lv n" rising and fading with a burst of
-- sparks, on every screen within LEVEL_FX_DISTANCE; on mine also a pop in the middle of the screen and the level-up
-- jingle. A whole step (what it gives goes up too): bigger, gold, confetti, "능력 UP!"
-- ---------------------------------------------------------------------------

local LEVEL_FX_DISTANCE = 120
local LEVEL_FX_SECONDS = 1.6
local LEVEL_FX_RISE = 6 -- studs it floats up
local LEVEL_SIZE, STEP_SIZE = UDim2.fromOffset(260, 70), UDim2.fromOffset(340, 92)
local LEVEL_COLOR, STEP_COLOR = Color3.fromRGB(140, 255, 160), Color3.fromRGB(255, 215, 70)
local LEVEL_SPARKS = { Color3.fromRGB(140, 255, 160), Color3.fromRGB(255, 255, 255), Color3.fromRGB(120, 200, 255) }
local STEP_SPARKS = { Color3.fromRGB(255, 215, 70), Color3.fromRGB(255, 255, 255), Color3.fromRGB(255, 140, 60) }
local POP_SIZE = UDim2.fromOffset(420, 84)
local POP_SECONDS = 1.4
local TweenService = game:GetService("TweenService")
local Fx = require(Shared:WaitForChild("Fx"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Lang = require(Shared:WaitForChild("Lang"))

local popGui = Instance.new("ScreenGui")
popGui.Name = "TrainLevelPop"
popGui.ResetOnSpawn = false
popGui.DisplayOrder = 6
popGui.Parent = player:WaitForChild("PlayerGui")
local pop = Instance.new("TextLabel")
pop.AnchorPoint = Vector2.new(0.5, 0.5)
pop.Position = UDim2.fromScale(0.5, 0.36)
pop.Size = POP_SIZE
pop.BackgroundTransparency = 1
pop.Font = Enum.Font.GothamBlack
pop.TextScaled = true
pop.TextStrokeTransparency = 0.2
pop.Visible = false
pop.Parent = popGui
local popScale = Instance.new("UIScale")
popScale.Parent = pop
local popToken = 0

Net.onPush("TrainLevelFx", function(userId, track, level, step)
	local who = Players:GetPlayerByUserId(userId)
	local head = who and who.Character and who.Character:FindFirstChild("Head")
	local camera = Workspace.CurrentCamera
	if not head or not camera or (head.Position - camera.CFrame.Position).Magnitude > LEVEL_FX_DISTANCE then
		return
	end
	local mine = who == player
	local t = Config.Training.Tracks[track]
	-- over the head, for everyone near
	local gui = Instance.new("BillboardGui")
	gui.Size = step and STEP_SIZE or LEVEL_SIZE
	gui.StudsOffsetWorldSpace = Vector3.new(0, 3, 0)
	gui.AlwaysOnTop = true
	gui.LightInfluence = 0
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBlack
	text.TextScaled = true
	text.TextColor3 = step and STEP_COLOR or LEVEL_COLOR
	text.TextStrokeTransparency = 0.1
	text:SetAttribute("KeepText", true)
	text.Text = step and string.format("⬆️ Lv %d · 💪 UP!", level) or string.format("⬆️ Lv %d", level)
	text.Parent = gui
	gui.Adornee = head
	gui.Parent = head
	TweenService:Create(gui, TweenInfo.new(LEVEL_FX_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{ StudsOffsetWorldSpace = Vector3.new(0, 3 + LEVEL_FX_RISE, 0) }):Play()
	TweenService:Create(text, TweenInfo.new(LEVEL_FX_SECONDS * 0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In,
		0, false, LEVEL_FX_SECONDS * 0.5), { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
	task.delay(LEVEL_FX_SECONDS, function()
		gui:Destroy()
	end)
	Fx.burst(head.Position, step and STEP_SPARKS or LEVEL_SPARKS, step and 40 or 18, step and 22 or 14, 0.5, 0.8)
	if step then
		Fx.confetti(head.Position + Vector3.new(0, 2, 0))
	end
	Sfx.play("LevelUp", not mine and head.Position or nil, step and 1 or 1.2, mine and 1 or 0.6)
	-- on my own screen: the pop in the middle
	if mine and t then
		popToken += 1
		local token = popToken
		pop:SetAttribute("KeepText", true) -- (written in my language here)
		local before = Formulas.trainRealOf(track, level - 1)
		local after = Formulas.trainRealOf(track, level)
		if track == "Power" then
			local done = ((player:GetAttribute("PickaxeTier") or 1) - 1) * Config.Pickaxe.PowerSteps
			before, after = math.max(0, before - done), math.max(0, after - done)
		end
		local was, now = Formulas.trainValueText(track, before, true), Formulas.trainValueText(track, after, true)
		pop.Text = string.format("%s Lv %d!", Lang.t(t.Name, Lang.code(player)), level) .. (step and " 💪 UP!" or "")
			.. "\n" .. (was ~= now and was .. " → " .. now or now)
		pop.TextColor3 = step and STEP_COLOR or LEVEL_COLOR
		pop.Visible = true
		pop.TextTransparency, pop.TextStrokeTransparency = 0, 0.2
		popScale.Scale = 0.4
		TweenService:Create(popScale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
		task.delay(POP_SECONDS, function()
			if popToken == token then
				TweenService:Create(pop, TweenInfo.new(0.3), { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
				task.delay(0.3, function()
					if popToken == token then
						pop.Visible = false
					end
				end)
			end
		end)
	end
end)
