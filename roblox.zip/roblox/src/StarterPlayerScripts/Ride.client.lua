--[[
Ride: riding a dino, on this client (the server decides, ServerScriptService/Services/Ride).

- "🦖 타기" button left of 기지로 (or the R key): Net request Ride(on). Grey outside the safe land
  (inside the battlefield flags, Shared/SafeZones), "내리기" while riding (player attribute Riding).
- While I ride, my character sits (the sitting animation of its own Animate script).
- Every rider's mount is drawn on this screen, outside the character (Workspace.RideMounts): the
  player's Mount species from ReplicatedStorage.DinoModels, as big as on the defense track (player attribute
  RideSize) or Config.Ride.MountHeight tall without it, its feet
  RideDrop below the rider's root and RideForward ahead (attributes the server sets). Its legs walk
  with the rider's speed, measured from how far the rider moved (Shared/DinoMotion). (Inside the
  character, the character's Animator put its leg bones back to rest every frame.)
- "🦖 울부짖기" button beside 보기 설정 (or the T key) while I ride: Net request Roar. On Net push RoarFx
  every screen makes that rider's dino rear up and roar (DinoMotion.roar) in its species' own voice
  (Shared/DinoVoices: roar, bellow, honk, chirp, grunt, ...), with a "크아앙!" bubble and a puff of dust.
- Flying mounts (player attribute Flying, the Sky species): my character hovers (PlatformStand, a
  LinearVelocity and an AlignOrientation on its root) and flies at its WalkSpeed toward where the camera
  looks: the move keys / thumbstick forward and back follow the camera's pitch too, so looking up or
  down while moving climbs or dives (phones need nothing else); Space or the jump button climbs, Shift
  (or Ctrl) sinks, at Config.Ride.FlyClimbSpeed. Never below the mount's feet on the ground, never
  higher than Config.Ride.FlyMaxHeight. (2026-10-04) Over the battlefield only to look: never lower than
  Config.Ride.FieldMinHeight there (lifted up flying in low), every prompt off while I'm up there
  (ProximityPromptService); carrying keys or racing, held back Config.Ride.FlyEdgeMargin outside the
  battlefield flags instead (the server would get me off in there). Flying mounts flap and glide
  (DinoMotion.fly) on every screen. High up (WIND_HEIGHT over the ground) a gust of wind rushes past
  now and then (Sfx WindGust), more often the higher I fly.
- The mount pedestal behind my base's rebirth sign (prompt Kind "Mount") opens the window to choose
  which dino to ride: the default one and every species × rarity × size I own that walks (Formulas.rideable),
  each with its picture in its rarity's border, the rarity's aura going on the mount; Net request
  SetMount(species, rarity, size). Walking away closes it.
- Under the list (2026-10-02): the race records, road and sky: my wins and losses and best time, and the three
  fastest of all servers (Race, Leaderboards).
- Beside the pedestal's prompt (2026-10-02, were buttons under the list): the prompts "🏁 지상 레이스 연습" [Z]
  and "🦅 하늘 레이스 연습" [X]: Net request RacePractice("Road" / "Sky") races alone on the registered mount, same
  rules as a race, no record (Race service). Only the one for my mount's kind (walking / flying) shows, only at
  my own base and not while racing.
]]

local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Unlock = require(Shared:WaitForChild("Unlock"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local ScreenButtons = require(Shared:WaitForChild("ScreenButtons"))
local DinoMotion = require(Shared:WaitForChild("DinoMotion"))
local RarityFx = require(Shared:WaitForChild("RarityFx"))
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local Coach = require(Shared:WaitForChild("Coach"))
local DinoVoices = require(Shared:WaitForChild("DinoVoices"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Fx = require(Shared:WaitForChild("Fx"))
local Windows = require(Shared:WaitForChild("Windows"))
local WorldWatch = require(Shared:WaitForChild("WorldWatch"))
local LiveSet = require(Shared:WaitForChild("LiveSet"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local RIDE_KEY = Enum.KeyCode.R
local BUTTON_SIZE = UDim2.fromOffset(68, 40)
-- 타기 / 내리기 and 울부짖기 sit over the phone's jump button, clear of it and of the slap button (CombatFx,
-- its top 104 above the bottom). (2026-10-01: was 110 above the bottom, on a phone it touched the jump
-- button, which is bigger than Roblox's old 70: now 165, clear of a jump button up to 140 high)
local BUTTON_POS = UDim2.new(1, -25, 1, -165) -- its bottom right
local COLOR_RIDE = Color3.fromRGB(90, 170, 80)
local COLOR_OFF = Color3.fromRGB(200, 120, 50)
local COLOR_DISABLED = Color3.fromRGB(110, 110, 120)
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_ROW = Color3.fromRGB(45, 50, 68)
local COLOR_CHOSEN = Color3.fromRGB(60, 120, 70)
local COLOR_PICK_HINT = Color3.fromRGB(255, 220, 120)
local COLOR_HINT = Color3.fromRGB(190, 190, 200)
local WINDOW_SIZE = UDim2.fromOffset(340, 470) -- (2026-10-02: 380 → 420 → 470: the race records at the bottom)
-- (2026-10-02, "이 창 밑에는 자기 기록이랑 전 서버 기록 볼 수 있게 하자 지상이랑 공중") the records panel
local RECORDS_HEIGHT = 128
local RECORD_LINE = 14
local COLOR_RECORDS = Color3.fromRGB(40, 45, 62)
local COLOR_RECORD_HEAD = Color3.fromRGB(255, 220, 120)
local COLOR_RECORD_SOFT = Color3.fromRGB(190, 190, 200)
local MOUNT_CARD = UDim2.fromOffset(98, 130)
local MOUNT_CARD_GAP = 6
local PORTRAIT = 66
local SAFE_CHECK_EVERY = 0.3
local SPEED_SMOOTHING = 8 -- how fast the measured speed follows the real one
local LEG_SPEED_MAX = 22 -- studs a second: the mount's legs never cycle faster than at this speed
local CLOSE_SLACK = 8 -- studs past the prompt's reach before the window closes
local MOUNT_BOX_COLOR = Color3.fromRGB(120, 200, 110) -- a stand-in when the dino model is missing
local MOUNT_HALO_LIFT = 4
local STATUE_CHECK_EVERY = 1
local ROAR_KEY = Enum.KeyCode.T -- (G drops the carried keys)
local ROAR_POS = UDim2.new(1, -25 - 68 - 6, 1, -165) -- left of 타기 / 내리기; its bottom right
local JUMP_GAP = 10 -- pixels between the phone's jump button and the buttons over it
local CLEAR_GAP = 12 -- pixels kept free between 타기 / 울부짖기 and any other button
local LIFT_STEP = 50 -- pixels: each try higher over the jump button
local LIFT_TRIES = 3
local LEFT_TRIES = 4
local STICK_SHARE = 0.4
local STICK_TOP = 1 / 3
local GRID_STEP = 16
local GRID_EDGE = 8
local DROP_STEP = 20 -- pixels: on a computer, each try lower down the right edge (a short screen)
local EDGE_GAP = 12 -- pixels kept under 타기 at the bottom edge
local BUTTON_GAP = 6 -- pixels between 타기 and 울부짖기
local COLOR_ROAR = Color3.fromRGB(200, 90, 60)
local ROAR_LINES = { "크아아앙!", "쿠오오오!", "크르릉~!", "캬오오!" }
local ROAR_BUBBLE_SIZE = UDim2.fromOffset(150, 44)
local ROAR_BUBBLE_SECONDS = 1.4
local ROAR_BUBBLE_GAP = 1.5 -- studs over the top of the dino's head
local ROAR_VOLUME_PITCH = 0.95 -- a little lower than the arena dinos: it is a big one
local DUST = { Color3.fromRGB(200, 185, 150), Color3.fromRGB(160, 145, 115) }
local FLY_TURN = 12 -- how quickly a flyer turns to face where it flies (AlignOrientation responsiveness)
local FLY_GROUND_PUSH = 6 -- how hard a flyer below its riding height is lifted back (per stud, a second)
local FLY_EDGE_PUSH = 12 -- studs a second pushing a flyer back out past the battlefield flags (and in from the map's edge)
local FIELD_LIFT_MAX = 70 -- studs a second at most lifting a flyer up to the battlefield's lowest flight (flying in low)
local FLY_MAP_MARGIN = 15 -- studs inside the map's wall (Config.Map.Radius) a flyer is held (2026-10-01: it could fly off the map)
-- (2026-10-01: were math.huge, which can blow the physics up into impossible positions, and those can stall
-- this phone's connection) the flight's pull and turn, × the character's weight
local FLY_FORCE_PER_MASS = 1000 -- (gravity is 196: about 5 times what holding it up takes)
local FLY_TORQUE_PER_MASS = 1000
local FLY_DOWN_KEYS = { Enum.KeyCode.LeftShift, Enum.KeyCode.RightShift, Enum.KeyCode.LeftControl }
-- (2026-10-03, "익룡타고있으면 날개소리랑 하늘높이가면 바람소리 나는거에, 공룡 타고 있으면 육중한 발걸음 소리가 나야지")
-- flying: a steady wind (Sfx WindLoop) from WIND_LOOP_FROM studs over the ground, at full strength by WIND_LOOP_FULL
-- (louder still flying fast), fading in and out; gusts on top from WIND_HEIGHT (were from 35, every 4-10 seconds)
local WIND_HEIGHT = 25 -- studs over the ground before the wind gusts start
-- (2026-10-04, "공중에 익룡타고 있을때 바람소리 너무 자주 나. 드물게나게해줘": were 2.5-6, + up to 2 more) seconds
-- between gusts: the short end high up, the long end just above WIND_HEIGHT, + up to WIND_EVERY_RANDOM more
local WIND_EVERY = { 15, 25 }
local WIND_EVERY_RANDOM = 8
-- (2026-10-03, "익룡탈것 소리 조금 날카롭기도 하고.. 음을 좀 낮춰": the gusts were 0.85-1.2, the steady wind 0.9-1.15,
-- the wingbeats at the dino's size pitch) all lower
local WIND_PITCH = { 0.7, 0.9 }
local WIND_LOOP_PITCH = { 0.72, 0.85 } -- the steady wind's playback speed: at its quietest, at full strength
local MOUNT_FLAP_PITCH = 0.6 -- × a ridden pterosaur's wingbeat pitch ("음낮이도 더 낮게": was 0.75)
local WIND_LOOP_FROM, WIND_LOOP_FULL = 10, 80
local WIND_LOOP_FADE = 1.2 -- its loudness (0..1) rises this much a second at most ...
-- (2026-10-03, "익룡 타다가 땅에 떨어지면 소리 멈춰야지") ... and falls this fast: down on the ground (or off the dino)
-- the wind stops at once, a gust still blowing is stopped, and the dino's wingbeats stop (it walks: no flapping)
local WIND_LOOP_FADE_OUT = 6
local GROUND_CHECK_EVERY = 0.15 -- seconds between looks at the ground under a flying dino (every rider's)
local AIRBORNE_MARGIN = 1.5 -- studs over its riding height off the ground before it counts as flying
local WIND_LOOP_SPEED = 0.3 -- share of its loudness that comes from flying fast
-- the dino I ride (and the others'): its own steps and wingbeats (Shared/DinoMotion), never held back by the
-- other dinos' sounds. (2026-10-03, "익룡 탈것 날갯짓 소리 너무 커", "육지공룡 탈것 발소리 너무 깨지고 너무 늘어지고 커":
-- at 1.7 times, and as big again for its size, it went past full loudness and broke up; played at 0.85 speed it
-- dragged on) its steps at its size's own loudness and pitch, never the long stomp, at most one every
-- MOUNT_STEP_GAP; its wingbeats well under its steps
local MOUNT_SOUND_GAIN, OTHER_MOUNT_SOUND_GAIN = 0.6, 0.45 -- (2026-10-03, "소리도 너무커", "육지공룡 발소리 너무 커": were 1, 0.8, then 0.8, 0.6)
local MOUNT_FLAP_GAIN, OTHER_MOUNT_FLAP_GAIN = 0.55, 0.45 -- (2026-10-03, "날갯짓 소리도 좀 줄이고": were 0.5, 0.4 → 0.3, 0.25;
-- 2026-10-04, "익룡 날개소리 작다": the ridden one's wingbeats were under the wind and the flier's other sounds → 0.55, 0.45)
local MOUNT_STEP_PITCH = 1
local MOUNT_STOMP_FROM = math.huge -- (never: DinoStomp is the long, booming area attack)
local MOUNT_STEP_GAP = 0.3 -- seconds: at most one footfall sound this often

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local gui = Instance.new("ScreenGui")
gui.Name = "Ride"
gui.ResetOnSpawn = false
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.Parent = player:WaitForChild("PlayerGui")

-- ---------------------------------------------------------------------------
-- The ride button
-- ---------------------------------------------------------------------------

local button = Instance.new("TextButton")
button.AnchorPoint = Vector2.new(1, 1)
button.Size = BUTTON_SIZE
button.Position = BUTTON_POS
button.Font = FONT
button.TextSize = 14
button.TextColor3 = Color3.new(1, 1, 1)
button.Parent = gui
Coach.mark(button, "Ride")
corner(button, 12)

local roarButton -- (made below)

-- on a phone, sit right over Roblox's own jump button wherever it is (its size and place differ by
-- phone and by Roblox version: a fixed spot touched it on some phones); BUTTON_POS / ROAR_POS otherwise
-- is a box (screen pixels, top-left a, bottom-right b) clear of every other button by CLEAR_GAP?
local function clear(a, b, boxes)
	for _, box in ipairs(boxes) do
		if a.X < box[2].X + CLEAR_GAP and b.X > box[1].X - CLEAR_GAP and a.Y < box[2].Y + CLEAR_GAP
			and b.Y > box[1].Y - CLEAR_GAP then
			return false
		end
	end
	return a.X >= 0 and a.Y >= 0
end

local function overlap(a, b, boxes)
	local sum = 0
	for _, box in ipairs(boxes) do
		local w = math.min(b.X, box[2].X + CLEAR_GAP) - math.max(a.X, box[1].X - CLEAR_GAP)
		local h = math.min(b.Y, box[2].Y + CLEAR_GAP) - math.max(a.Y, box[1].Y - CLEAR_GAP)
		if w > 0 and h > 0 then
			sum += w * h
		end
	end
	return sum
end

local function hudBoxes(boxes)
	local bagGui = player.PlayerGui:FindFirstChild("BagBar")
	local bagBar = bagGui and bagGui:FindFirstChildWhichIsA("Frame")
	if bagBar and bagBar.Visible then
		table.insert(boxes, { bagBar.AbsolutePosition, bagBar.AbsolutePosition + bagBar.AbsoluteSize })
		for _, d in ipairs(bagBar:GetChildren()) do
			if d:IsA("TextLabel") and d.Visible and d.AbsoluteSize.X > 0 then
				table.insert(boxes, { d.AbsolutePosition, d.AbsolutePosition + d.AbsoluteSize })
			end
		end
	end
end

-- on a phone: right over Roblox's own jump button wherever it is (its size and place differ by phone
-- and by Roblox version), or, when that is crowded by other buttons (short screens), the first clear
-- spot of: up and to its left, then higher over it; without a jump button BUTTON_POS, or the first clear
-- spot lower down the right edge
local function placeOverJump()
	local touch = player.PlayerGui:FindFirstChild("TouchGui")
	local jump = touch and touch:FindFirstChild("JumpButton", true)
	local w, h = BUTTON_SIZE.X.Offset, BUTTON_SIZE.Y.Offset
	-- 타기, and 울부짖기 beside it only while riding (2026-10-01: room for both was kept even when 울부짖기
	-- was hidden, so on a short phone no spot was clear and 타기 fell back onto the side buttons)
	local pairWidth = roarButton.Visible and (2 * w + BUTTON_GAP) or w
	local origin = gui.AbsolutePosition -- our screen's corner (it may start below the top bar)
	local candidates -- (right, bottom) of 타기, in screen pixels
	local boxes0 = {}
	if not jump or not jump:IsA("GuiObject") or not jump.Visible or jump.AbsoluteSize.X < 1 then
		-- no jump button (a computer): BUTTON_POS, or lower down the right edge when the screen is short
		-- (2026-10-02, "화면 가로길이가 늘어나면 ui 겹침": a wide, low window put 타기 on 상점 and 기지로)
		local size = gui.AbsoluteSize
		local right = origin.X + size.X + BUTTON_POS.X.Offset
		local bottom = origin.Y + size.Y + BUTTON_POS.Y.Offset
		candidates = { { right, bottom } }
		for y = bottom + DROP_STEP, origin.Y + size.Y - EDGE_GAP, DROP_STEP do
			table.insert(candidates, { right, y })
		end
	else
		local jl, jt = jump.AbsolutePosition.X, jump.AbsolutePosition.Y
		local jr = jl + jump.AbsoluteSize.X
		candidates = {
			{ jr, jt - JUMP_GAP },
			{ jl - CLEAR_GAP, jt - JUMP_GAP },
		}
		for k = 1, LIFT_TRIES do
			table.insert(candidates, { jr, jt - JUMP_GAP - k * LIFT_STEP })
			table.insert(candidates, { jl - CLEAR_GAP, jt - JUMP_GAP - k * LIFT_STEP })
		end
		for k = 1, LEFT_TRIES do
			table.insert(candidates, { jl - CLEAR_GAP - k * (pairWidth + CLEAR_GAP), jt - JUMP_GAP })
		end
		for k = 1, LEFT_TRIES do
			table.insert(candidates, { jl - CLEAR_GAP - k * (pairWidth + CLEAR_GAP), jt - JUMP_GAP - LIFT_STEP })
		end
		local size = gui.AbsoluteSize
		table.insert(boxes0, { Vector2.new(origin.X, origin.Y + size.Y * STICK_TOP),
			Vector2.new(origin.X + size.X * STICK_SHARE, origin.Y + size.Y) })
		local first = candidates[1]
		local extra = {}
		local x = origin.X + size.X - GRID_EDGE
		while x - pairWidth >= origin.X + size.X * STICK_SHARE do
			local y = origin.Y + size.Y - GRID_EDGE
			while y - h >= origin.Y + size.Y * STICK_TOP do
				table.insert(extra, { x, y })
				y -= GRID_STEP
			end
			x -= GRID_STEP
		end
		table.sort(extra, function(a, b)
			return (a[1] - first[1]) ^ 2 + (a[2] - first[2]) ^ 2 < (b[1] - first[1]) ^ 2 + (b[2] - first[2]) ^ 2
		end)
		for _, c in ipairs(extra) do
			table.insert(candidates, c)
		end
	end
	local boxes = ScreenButtons.boxes(gui, 0)
	for _, box in ipairs(boxes0) do
		table.insert(boxes, box)
	end
	hudBoxes(boxes)
	local pick, least = nil, math.huge
	for _, c in ipairs(candidates) do
		local a, b = Vector2.new(c[1] - pairWidth, c[2] - h), Vector2.new(c[1], c[2])
		if clear(a, b, boxes) then
			pick = c
			break
		end
		local o = a.X >= 0 and a.Y >= 0 and overlap(a, b, boxes) or math.huge
		if o < least then
			pick, least = c, o
		end
	end
	pick = pick or candidates[1]
	local at = UDim2.fromOffset(pick[1] - origin.X, pick[2] - origin.Y)
	if button.Position ~= at then
		button.Position = at
		ScreenButtons.moved()
	end
	roarButton.Position = UDim2.fromOffset(pick[1] - origin.X - w - BUTTON_GAP, pick[2] - origin.Y)
end

local safeHere = true
local function riding()
	return player:GetAttribute("Riding") == true
end
-- (2026-10-03, "타기 내리기 울부짖기도 컴퓨터 키 지정해주자": the keys worked but nothing said so) with a keyboard the
-- buttons show their key under the name, like 찰싹 (F)
local showKeys = UserInputService.KeyboardEnabled
local function refreshButton()
	if riding() and player:GetAttribute("Watching") then -- (2026-10-04) caught in hide-and-seek: watching to the end
		button.Text = "👀 구경 중"
		button.BackgroundColor3 = COLOR_DISABLED
	elseif riding() then
		button.Text = showKeys and string.format("🚶 내리기\n(%s)", RIDE_KEY.Name) or "🚶 내리기"
		button.BackgroundColor3 = COLOR_OFF
	else
		button.Text = showKeys and string.format("🦖 타기\n(%s)", RIDE_KEY.Name) or "🦖 타기"
		button.BackgroundColor3 = safeHere and COLOR_RIDE or COLOR_DISABLED
	end
end
refreshButton()

-- the roar button, while I ride
roarButton = Instance.new("TextButton")
roarButton.AnchorPoint = Vector2.new(1, 1)
roarButton.Size = BUTTON_SIZE
roarButton.Position = ROAR_POS
roarButton.Font = FONT
roarButton.TextSize = 13
roarButton.TextColor3 = Color3.new(1, 1, 1)
roarButton.BackgroundColor3 = COLOR_ROAR
roarButton.Text = showKeys and string.format("🦖 울부짖기\n(%s)", ROAR_KEY.Name) or "🦖 울부짖기"
roarButton.Visible = false
roarButton.Parent = gui

task.spawn(function() -- follow the jump button: it appears late and moves when the screen turns
	local touch = player.PlayerGui:WaitForChild("TouchGui", 30)
	local jump = touch and touch:FindFirstChild("JumpButton", true)
	for _ = 1, 20 do
		if jump then
			break
		end
		task.wait(0.5)
		jump = touch and touch:FindFirstChild("JumpButton", true)
	end
	placeOverJump()
	if jump then
		jump:GetPropertyChangedSignal("AbsolutePosition"):Connect(placeOverJump)
		jump:GetPropertyChangedSignal("AbsoluteSize"):Connect(placeOverJump)
		jump:GetPropertyChangedSignal("Visible"):Connect(placeOverJump)
	end
	gui:GetPropertyChangedSignal("AbsoluteSize"):Connect(placeOverJump)
	ScreenButtons.onChange(placeOverJump)
end)
corner(roarButton, 12)
local lastRoarPress = -math.huge
local function roar()
	if riding() and os.clock() - lastRoarPress >= Config.Ride.RoarCooldown then
		lastRoarPress = os.clock()
		Net.request("Roar")
	end
end
roarButton.Activated:Connect(roar)

local function toggle()
	if player:GetAttribute("TopView") then
		return
	end
	if not riding() and not safeHere then
		return -- the server would say no too (inside the battlefield flags)
	end
	Net.request("Ride", not riding())
end
button.Activated:Connect(toggle)
UserInputService.InputBegan:Connect(function(input, processed)
	if not processed and input.KeyCode == RIDE_KEY then
		toggle()
	elseif not processed and input.KeyCode == ROAR_KEY then
		roar()
	end
end)

-- ---------------------------------------------------------------------------
-- My sitting pose while riding
-- ---------------------------------------------------------------------------

local sitTrack = nil
local function updatePose()
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local animator = humanoid and humanoid:FindFirstChildOfClass("Animator")
	if riding() and animator and not sitTrack then
		local animate = character:FindFirstChild("Animate")
		local sit = animate and animate:FindFirstChild("sit")
		local animation = sit and sit:FindFirstChildOfClass("Animation")
		if animation then
			sitTrack = animator:LoadAnimation(animation)
			sitTrack.Priority = Enum.AnimationPriority.Action
			sitTrack.Looped = true
			sitTrack:Play(0.2)
		end
	elseif not riding() and sitTrack then
		sitTrack:Stop(0.2)
		sitTrack = nil
	end
end
local function showRideButton()
	button.Visible = not player:GetAttribute("TopView") and (riding() or Unlock.usable("Ride"))
end
showRideButton()
Unlock.watch(function()
	showRideButton()
	placeOverJump()
end)
player:GetAttributeChangedSignal("TopView"):Connect(function()
	showRideButton()
	roarButton.Visible = riding() and not player:GetAttribute("TopView")
	placeOverJump()
end)
player:GetAttributeChangedSignal("Riding"):Connect(function()
	refreshButton()
	showRideButton()
	roarButton.Visible = riding() and not player:GetAttribute("TopView")
	placeOverJump() -- 울부짖기 came or went: the pair needs another spot
	updatePose()
end)
player:GetAttributeChangedSignal("Watching"):Connect(refreshButton)
player.CharacterAdded:Connect(function()
	sitTrack = nil -- the old character's track went with it
end)

-- ---------------------------------------------------------------------------
-- Flying (my own character, on a flying mount)
-- ---------------------------------------------------------------------------

local mountFolder = Instance.new("Folder")
mountFolder.Name = "RideMounts"
mountFolder.Parent = Workspace
local nextGust = 0 -- os.clock() of the next wind gust while flying high
local windLoop = nil -- the steady wind (Sfx.loop "WindLoop"; false: not uploaded, the gusts alone)
local windLevel = 0
-- (2026-10-03, "익룡타다가 떨어지면 소리 멈춘다는게 바람 소리 멈춘다는거야", "익룡에서 내려서 땅에 닿아도 바람 소리가
-- 멈춰야지": only the newest gust was stopped; the one before, played slow, blew on for 3 seconds more) every
-- gust still blowing, and the steady wind, stop at once when I'm off the dino or down by the ground
local gusts = {} -- the gusts blowing now (Sounds)
local function windTo(target, dt)
	if target <= 0 then
		for _, g in ipairs(gusts) do
			if g.Parent then
				g:Stop()
			end
		end
		table.clear(gusts)
		windLevel = 0
		if windLoop then
			windLoop.Volume = 0
		end
		return
	end
	if target > 0 and windLoop == nil then
		windLoop = Sfx.loop("WindLoop") or false
	end
	if not windLoop then
		return
	end
	windLevel += math.clamp(target - windLevel, -WIND_LOOP_FADE_OUT * dt, WIND_LOOP_FADE * dt)
	windLoop.Volume = Sfx.volume("WindLoop") * windLevel
	windLoop.PlaybackSpeed = WIND_LOOP_PITCH[1] + (WIND_LOOP_PITCH[2] - WIND_LOOP_PITCH[1]) * windLevel
end
local flight = nil -- { attachment, velocity, align, humanoid, root }
local controls = nil -- the PlayerModule's ControlModule, for the thumbstick / keys move vector
local groundRay = RaycastParams.new() -- (under every rider's flying dino)
groundRay.FilterType = Enum.RaycastFilterType.Exclude
groundRay.RespectCanCollide = true
local flyRay = RaycastParams.new()
flyRay.FilterType = Enum.RaycastFilterType.Exclude
flyRay.RespectCanCollide = true

local function flying()
	return riding() and player:GetAttribute("Flying") == true
end

local function flatLook(cf)
	local flat = Vector3.new(cf.LookVector.X, 0, cf.LookVector.Z)
	return flat.Magnitude > 0.01 and flat.Unit or Vector3.new(0, 0, -1)
end

local function stopFlight()
	if not flight then
		return
	end
	flight.attachment:Destroy() -- with it the velocity and the alignment
	if flight.humanoid.Parent then
		flight.humanoid.PlatformStand = false
	end
	flight = nil
end

local function startFlight()
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if flight or not humanoid or not root then
		return
	end
	if not controls then
		pcall(function()
			local module = player:FindFirstChild("PlayerScripts") and player.PlayerScripts:FindFirstChild("PlayerModule")
			controls = module and require(module):GetControls()
		end)
	end
	local attachment = Instance.new("Attachment")
	attachment.Name = "FlyAttachment"
	attachment.Parent = root
	local velocity = Instance.new("LinearVelocity")
	velocity.Attachment0 = attachment
	velocity.RelativeTo = Enum.ActuatorRelativeTo.World
	velocity.VelocityConstraintMode = Enum.VelocityConstraintMode.Vector
	velocity.MaxForce = root.AssemblyMass * FLY_FORCE_PER_MASS
	velocity.VectorVelocity = Vector3.zero
	velocity.Parent = attachment
	local align = Instance.new("AlignOrientation")
	align.Mode = Enum.OrientationAlignmentMode.OneAttachment
	align.Attachment0 = attachment
	align.MaxTorque = root.AssemblyMass * FLY_TORQUE_PER_MASS
	align.Responsiveness = FLY_TURN
	align.CFrame = CFrame.lookAt(Vector3.zero, flatLook(root.CFrame))
	align.Parent = attachment
	humanoid.PlatformStand = true -- the humanoid stops standing and walking; the velocity flies it
	flight = { attachment = attachment, velocity = velocity, align = align, humanoid = humanoid, root = root }
end

-- the move input: forward (+ = ahead) and right (+ = to the right), each -1..1
local function moveInput(humanoid, camera)
	local ok, move = pcall(function()
		return controls and controls:GetMoveVector()
	end)
	if ok and move then
		return -move.Z, move.X
	end
	local d = humanoid.MoveDirection -- world space, flat: back to the camera's frame
	return d:Dot(flatLook(camera.CFrame)), d:Dot(camera.CFrame.RightVector)
end

local function keyDown(keys)
	for _, k in ipairs(keys) do
		if UserInputService:IsKeyDown(k) then
			return true
		end
	end
	return false
end

local function fly(dt)
	if flight and (not flying() or not flight.root.Parent or flight.humanoid.Health <= 0) then
		stopFlight()
	end
	if not flight and flying() then
		startFlight()
	end
	if not flight then
		windTo(0, dt)
		return
	end
	local root, humanoid, camera = flight.root, flight.humanoid, Workspace.CurrentCamera
	local forward, right = moveInput(humanoid, camera)
	local cf = camera.CFrame
	local want = cf.LookVector * forward + cf.RightVector * right -- the camera's pitch climbs and dives too
	if want.Magnitude > 1 then
		want = want.Unit
	end
	local v = want * humanoid.WalkSpeed -- (its flat part is never faster than walking: the server checks that)
	local climb = 0
	if humanoid.Jump or UserInputService:IsKeyDown(Enum.KeyCode.Space) then
		climb += Config.Ride.FlyClimbSpeed
	end
	if keyDown(FLY_DOWN_KEYS) then
		climb -= Config.Ride.FlyClimbSpeed
	end
	local vy = v.Y + climb
	-- the ground under me: never lower than riding on it
	flyRay.FilterDescendantsInstances = { player.Character, mountFolder }
	local pos = root.Position
	local hit = Workspace:Raycast(pos, Vector3.new(0, -500, 0), flyRay)
	local drop = player:GetAttribute("RideDrop") or 3
	-- (no ground found below: measured from the map's floor, so the ceiling holds there too)
	local height = hit and pos.Y - hit.Position.Y or pos.Y
	if height < drop then
		vy = math.max(vy, (drop - height) * FLY_GROUND_PUSH)
	elseif height < drop + 0.3 and vy < 0 then
		vy = 0
	end
	-- (2026-10-04, "익룡타고 배틀필드도 날아보고 싶은데.. 날기만") over the battlefield only high up, looking: the dino's
	-- feet never under Config.Ride.FieldMinHeight over the map's floor (about Y 0), rising to it over FieldRamp studs
	-- in from the flags; flying in low lifts it up. Carrying keys or racing: held back outside the flags (below).
	local flat = Vector3.new(pos.X, 0, pos.Z)
	local heldBack = (player:GetAttribute("CarriedKeys") or 0) > 0 or player:GetAttribute("Racing") ~= nil
	local depth = Config.Battlefield.Radius - flat.Magnitude
	if not heldBack and depth > 0 then
		local floor = Config.Ride.FieldMinHeight * math.clamp(depth / Config.Ride.FieldRamp, 0, 1)
		local under = floor - (pos.Y - drop)
		if under > 0 then
			vy = math.max(vy, math.min(under * FLY_GROUND_PUSH, FIELD_LIFT_MAX))
		elseif under > -0.3 and vy < 0 then
			vy = 0
		end
	end
	if height - drop > Config.Ride.FlyMaxHeight and vy > 0 then
		vy = 0
	end
	v = Vector3.new(v.X, vy, v.Z)
	-- held back outside the battlefield flags (carrying keys or racing)
	local edge = Config.Battlefield.Radius + Config.Ride.FlyEdgeMargin
	if heldBack and flat.Magnitude > 0.01 and flat.Magnitude < edge + 2 then
		local out = flat.Unit
		local inward = v:Dot(out)
		if inward < 0 then
			v -= out * inward
		end
		if flat.Magnitude < edge then
			v += out * FLY_EDGE_PUSH
		end
	end
	-- held inside the map's wall
	local outer = Config.Map.Radius - FLY_MAP_MARGIN
	if flat.Magnitude > outer - 2 then
		local out = flat.Unit
		local outward = v:Dot(out)
		if outward > 0 then
			v -= out * outward
		end
		if flat.Magnitude > outer then
			v -= out * FLY_EDGE_PUSH
		end
	end
	if player:GetAttribute("Watching") then
		local inner = Config.Battlefield.Radius - Config.HideSeek.WatchEdgeIn
		if flat.Magnitude > inner - 2 and flat.Magnitude > 0.01 then
			local out = flat.Unit
			local outward = v:Dot(out)
			if outward > 0 then
				v -= out * outward
			end
			if flat.Magnitude > inner then
				v -= out * FLY_EDGE_PUSH
			end
		end
	end
	if v.X ~= v.X or v.Y ~= v.Y or v.Z ~= v.Z then -- never send the physics a NaN
		v = Vector3.zero
	end
	if player:GetAttribute("Racing") == "Countdown" then -- (the sky race's start: everyone waits in place)
		v = Vector3.zero
	end
	flight.velocity.VectorVelocity = v
	-- a gust of wind now and then high up, more often the higher
	local above = height - drop
	if above >= WIND_HEIGHT and os.clock() >= nextGust then
		local k = math.clamp((above - WIND_HEIGHT) / math.max(1, Config.Ride.FlyMaxHeight - WIND_HEIGHT), 0, 1)
		if nextGust > 0 then
			local g = Sfx.play("WindGust", nil, WIND_PITCH[1] + math.random() * (WIND_PITCH[2] - WIND_PITCH[1]))
			if g then
				for i = #gusts, 1, -1 do -- (the ones already over)
					if not gusts[i].Parent then
						table.remove(gusts, i)
					end
				end
				table.insert(gusts, g)
			end
		end
		nextGust = os.clock() + WIND_EVERY[2] - (WIND_EVERY[2] - WIND_EVERY[1]) * k + math.random() * WIND_EVERY_RANDOM
	elseif above < WIND_HEIGHT then
		nextGust = 0 -- the first gust comes a little after climbing past WIND_HEIGHT
	end
	local high = math.clamp((above - WIND_LOOP_FROM) / (WIND_LOOP_FULL - WIND_LOOP_FROM), 0, 1)
	local fast = math.clamp(root.AssemblyLinearVelocity.Magnitude / math.max(humanoid.WalkSpeed, 1), 0, 1)
	windTo(high * (1 - WIND_LOOP_SPEED + WIND_LOOP_SPEED * fast), dt)
	local flatV = Vector3.new(v.X, 0, v.Z)
	if flatV.Magnitude > 1 then
		flight.align.CFrame = CFrame.lookAt(Vector3.zero, flatV)
	end
end
player.CharacterRemoving:Connect(stopFlight)

-- ---------------------------------------------------------------------------
-- Every mount's legs, and whether I stand in the safe land
-- ---------------------------------------------------------------------------

local mounts = {} -- [player] = { model, rig, species, lastPos, speed }
local MOUNT_FOOTPRINT = 0.6 -- of the mount's narrower side: its aura's light column as wide as a defense dino's
local RIDE_PARTICLE_SCALE = 0.55
local MOUNT_BURN_SCALE = 0.55
local RIDE_BURN_SCALE = 1

local function makeMount(species, rarity, sizeId)
	local models = ReplicatedStorage:FindFirstChild("DinoModels")
	local source = models and models:FindFirstChild("Dino_" .. species)
	local model = Instance.new("Model")
	model.Name = "Mount"
	if source then
		source:Clone().Parent = model
	else
		local p = Instance.new("Part")
		p.Size = Vector3.new(2.4, 3, 5)
		p.Color = MOUNT_BOX_COLOR
		p.Parent = model
	end
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
		elseif d:IsA("Script") or d:IsA("LocalScript") or d:IsA("ProximityPrompt") or d:IsA("BillboardGui") then
			d:Destroy()
		end
	end
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0)) -- its feet, in the middle
	local c = Config.Ride
	local drawn = sizeId and Formulas.dinoSize(sizeId)
	local fit = math.min(c.MountHeight / math.max(size.Y, 0.1), c.MountLength / math.max(size.X, size.Z, 0.1))
	local scale = drawn and Formulas.drawnScale(drawn) or fit
	model:ScaleTo(scale)
	-- (2026-10-01) its rarity's aura, as on the defense track (the rider's best of that species, Ride service)
	-- (2026-10-01, "bubbles like the farm and defense dinos, not gas") a mount is drawn 2-3 times as big as a dino
	-- on the track, so its particles came out 2-3 times as big, like smoke: they are kept the track dinos' size,
	-- and go with the running mount instead of trailing behind
	local look = size * math.max(fit, scale)
	RarityFx.apply(model, rarity or "Common", math.min(look.X, look.Z) * MOUNT_FOOTPRINT,
		{ particleScale = RIDE_PARTICLE_SCALE, locked = true, haloLift = MOUNT_HALO_LIFT, burn = RIDE_BURN_SCALE, size = look,
			trail = true })
	model.Parent = mountFolder
	return model
end

local function dropMount(p)
	local m = mounts[p]
	if m then
		m.model:Destroy()
		mounts[p] = nil
	end
end

RunService.RenderStepped:Connect(FrameMeter.wrap("Ride", function(dt)
	fly(dt)
	for _, p in ipairs(Players:GetPlayers()) do
		local character = p.Character
		local root = character and character:FindFirstChild("HumanoidRootPart")
		local species = p:GetAttribute("Mount")
		local rarity = p:GetAttribute("MountRarity")
		local sizeId = p:GetAttribute("RideSize")
		local drop = p:GetAttribute("RideDrop")
		if root and p:GetAttribute("Riding") and drop and species and species ~= "" then
			local m = mounts[p]
			if m and (m.species ~= species or m.rarity ~= rarity or m.sizeId ~= sizeId) then
				dropMount(p)
				m = nil
			end
			if not m then
				local model = makeMount(species, rarity, sizeId)
				model:SetAttribute("RiderId", p.UserId) -- (2026-10-04: the race outlines a rival's mount too, Race.client)
				m = { model = model, rig = DinoMotion.new(model), species = species, rarity = rarity, sizeId = sizeId, speed = 0 }
				mounts[p] = m
				-- its own sounds (MOUNT_*): heavy steps on the ground, wingbeats in the air (a pterosaur never steps)
				m.rig.priority = p == player
				m.rig.soundGain = p == player and MOUNT_SOUND_GAIN or OTHER_MOUNT_SOUND_GAIN
				m.rig.flapGain = p == player and MOUNT_FLAP_GAIN or OTHER_MOUNT_FLAP_GAIN
				m.rig.flapPitch = MOUNT_FLAP_PITCH
				m.rig.stepPitch = MOUNT_STEP_PITCH
				m.rig.stompFrom = MOUNT_STOMP_FROM
				m.rig.minStepGap = MOUNT_STEP_GAP
				if Formulas.flies(species) then -- (a flyer never steps, even a model without wing bones)
					m.rig.winged = true
				end
			end
			local auraOff = player:GetAttribute("HideAuras") == true -- (the view setting "오라")
			local fxState = auraOff and "off" or player:GetAttribute("LightMode") == true and "lite" or "on"
			if m.fxState ~= fxState then
				m.fxState = fxState
				RarityFx.setLite(player:GetAttribute("LightMode") == true)
				RarityFx.setVisible(m.model, not auraOff)
			end
			-- the speed from how far the rider really moved (another player's velocity reads 0 on this
			-- screen), smoothed over a few frames
			local pos = Vector3.new(root.Position.X, 0, root.Position.Z)
			local moved = m.lastPos and dt > 0 and (pos - m.lastPos).Magnitude / dt or 0
			m.lastPos = pos
			m.speed += (moved - m.speed) * math.min(1, dt * SPEED_SMOOTHING)
			local speed = math.min(m.speed, LEG_SPEED_MAX) -- 3× walking would blur the legs
			local look = root.CFrame.LookVector
			local flat = Vector3.new(look.X, 0, look.Z)
			flat = flat.Magnitude > 0.01 and flat.Unit or Vector3.new(0, 0, -1)
			local feet = root.Position - Vector3.new(0, drop, 0) + flat * (p:GetAttribute("RideForward") or 0)
			-- a flying dino flaps (and is heard) only off the ground; down on it, it walks, silent (see WIND_LOOP_FADE)
			local airborne = false
			if p:GetAttribute("Flying") then
				m.groundCheck = (m.groundCheck or 0) - dt
				if m.groundCheck <= 0 then
					m.groundCheck = GROUND_CHECK_EVERY
					local ignore = { mountFolder }
					for _, other in ipairs(Players:GetPlayers()) do
						if other.Character then
							table.insert(ignore, other.Character)
						end
					end
					groundRay.FilterDescendantsInstances = ignore
					local hit = Workspace:Raycast(root.Position, Vector3.new(0, -500, 0), groundRay)
					m.airborne = not hit or root.Position.Y - hit.Position.Y > drop + AIRBORNE_MARGIN
				end
				airborne = m.airborne == true
				m.rig.silent = not airborne
				-- (2026-10-04, "익룡 타고 나는데 왜 발자국 소리가 나냐고") for Footsteps.client: a person's steps only while
				-- this flier is down on the ground (on this screen only: a client's attribute stays on it)
				if p:GetAttribute("RideAirborne") ~= airborne then
					p:SetAttribute("RideAirborne", airborne)
				end
			end
			local pose = airborne and DinoMotion.fly(m.rig, dt) or DinoMotion.step(m.rig, dt, speed)
			m.model:PivotTo(CFrame.lookAt(feet, feet + flat) * pose)
		elseif mounts[p] then
			dropMount(p)
		end
	end
	for p in pairs(mounts) do
		if not p.Parent then
			dropMount(p)
		end
	end
end))

-- a rider's dino roars (Net push RoarFx): rears up, its species' voice, a bubble and dust
Net.onPush("RoarFx", function(userId)
	local p = Players:GetPlayerByUserId(userId)
	local m = p and mounts[p]
	if not m then
		return
	end
	DinoMotion.roar(m.rig)
	local at = m.model:GetPivot().Position
	local name, pitch = DinoVoices.roar(m.species) -- its own big roar (MountRoar, MountHonk, ...)
	Sfx.play(name, at + Vector3.new(0, 3, 0), pitch * ROAR_VOLUME_PITCH)
	Fx.burst(at + Vector3.new(0, 0.5, 0), DUST, 20, 12, 0.6, 0.7)
	-- (2026-10-01, "the 울부짖기 text went too high") measured on the dino's own parts: its rarity aura (the
	-- bubble, a light pillar) is in the model too and made the box, and the bubble, far too tall
	local part, top = nil, -math.huge
	for _, d in ipairs(m.model:GetDescendants()) do
		if d:IsA("BasePart") and not d:FindFirstAncestor("RarityFx") then
			part = part or d
			local h = d.Size / 2
			local up = d.CFrame:VectorToObjectSpace(Vector3.yAxis)
			top = math.max(top, d.Position.Y + math.abs(up.X) * h.X + math.abs(up.Y) * h.Y + math.abs(up.Z) * h.Z)
		end
	end
	if part then
		local bubble = Instance.new("BillboardGui")
		bubble.Size = ROAR_BUBBLE_SIZE
		bubble.StudsOffsetWorldSpace = Vector3.new(0, top - part.Position.Y + ROAR_BUBBLE_GAP, 0)
		bubble.AlwaysOnTop = true
		bubble.MaxDistance = 120
		bubble.Adornee = part
		local text = label(bubble, "🦖 " .. ROAR_LINES[math.random(1, #ROAR_LINES)], UDim2.fromScale(1, 1), UDim2.new(), 20)
		text.TextScaled = true
		text.TextColor3 = Color3.fromRGB(255, 220, 120)
		text.TextStrokeTransparency = 0.2
		bubble.Parent = player:WaitForChild("PlayerGui")
		task.delay(ROAR_BUBBLE_SECONDS, bubble.Destroy, bubble)
	end
end)

local sinceSafe = 0
local skyHere = false -- (2026-10-04) on a flying dino over the battlefield: nothing there to press (Shared/SafeZones.inSky)
RunService.Heartbeat:Connect(FrameMeter.wrap("Ride", function(dt)
	sinceSafe += dt
	if sinceSafe >= SAFE_CHECK_EVERY then
		sinceSafe = 0
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		local now = root ~= nil and SafeZones.isSafe(root.Position)
		if now ~= safeHere then
			safeHere = now
			refreshButton()
		end
		local sky = root ~= nil and SafeZones.inSky(player, root.Position)
		if sky ~= skyHere then
			skyHere = sky
			ProximityPromptService.Enabled = not sky -- (no minerals, chests or race challenges from up there)
		end
	end
end))

-- ---------------------------------------------------------------------------
-- The pedestal window: which dino to ride
-- ---------------------------------------------------------------------------

local window = Instance.new("Frame")
window.AnchorPoint = Vector2.new(0.5, 0.5)
window.Position = UDim2.fromScale(0.5, 0.5)
window.Size = WINDOW_SIZE
window.BackgroundColor3 = COLOR_BG
window.Visible = false
window.Parent = gui
corner(window, 14)
Windows.fit(window) -- smaller on phones
label(window, "🦖 탈 공룡 고르기", UDim2.new(1, -60, 0, 34), UDim2.fromOffset(14, 6), 20).TextXAlignment =
	Enum.TextXAlignment.Left
local normalHint = string.format("안전한 곳에서 [%s]나 🦖 타기 버튼으로 타요! 걷기 속도 ×%d · 🦅 하늘 공룡은 날아요",
	RIDE_KEY.Name, Config.Ride.SpeedMultiplier)
local hint = label(window, normalHint, UDim2.new(1, -28, 0, 34), UDim2.fromOffset(14, 38), 12)
hint.TextWrapped = true
hint.TextXAlignment = Enum.TextXAlignment.Left
hint.TextColor3 = COLOR_HINT
local raceKind, raceRetry = nil, nil
local function fitsKind(species, kind)
	return species ~= nil and species ~= "" and (kind == "Sky") == (Formulas.flies(species) == true)
end
local function showHint()
	if raceKind then
		hint.Text = raceKind == "Sky" and "🦅 하늘 레이스는 나는 공룡만 나가요! 아래에서 골라요"
			or "🦖 길 레이스는 걷는 공룡만 나가요! 아래에서 골라요"
		hint.TextColor3 = COLOR_PICK_HINT
	else
		hint.Text = normalHint
		hint.TextColor3 = COLOR_HINT
	end
end
local close = Instance.new("TextButton")
close.Size = UDim2.fromOffset(34, 34)
close.Position = UDim2.new(1, -42, 0, 8)
close.Font = FONT
close.TextSize = 16
close.TextColor3 = Color3.new(1, 1, 1)
close.BackgroundColor3 = Color3.fromRGB(235, 70, 80)
close.Text = "X"
close.Parent = window
corner(close, 10)
local list = Instance.new("ScrollingFrame")
list.Position = UDim2.fromOffset(10, 78)
list.Size = UDim2.new(1, -20, 1, -88 - RECORDS_HEIGHT - 8)
list.BackgroundTransparency = 1
list.ScrollBarThickness = 6
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = window
local layout = Instance.new("UIGridLayout")
layout.CellSize = MOUNT_CARD
layout.CellPadding = UDim2.fromOffset(MOUNT_CARD_GAP, MOUNT_CARD_GAP)
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = list

local openedBy = nil -- the pedestal's prompt

-- the records: mine (wins, losses, best time) and the fastest of all servers, the road race and the sky race
-- (player attributes RaceWins … RaceBestRoad / RaceBestSky, ReplicatedStorage RaceTopRoad / RaceTopSky: Race,
-- Leaderboards)
local HttpService = game:GetService("HttpService")
local records = Instance.new("Frame")
records.Position = UDim2.new(0, 10, 1, -RECORDS_HEIGHT - 8)
records.Size = UDim2.new(1, -20, 0, RECORDS_HEIGHT)
records.BackgroundColor3 = COLOR_RECORDS
records.Parent = window
corner(records, 10)
local recordLines = {}
for column, kind in ipairs({ "Road", "Sky" }) do
	local x = (column - 1) * 0.5
	local lines = {}
	for i = 1, 7 do
		local l = label(records, "", UDim2.new(0.5, -12, 0, RECORD_LINE + 2), UDim2.new(x, 8, 0, 6 + (i - 1) * (RECORD_LINE + 3)),
			i == 1 and 13 or 11)
		l.TextXAlignment = Enum.TextXAlignment.Left
		l.TextTruncate = Enum.TextTruncate.AtEnd
		l.TextColor3 = (i == 1 or i == 4) and COLOR_RECORD_HEAD or i >= 5 and COLOR_RECORD_SOFT or Color3.new(1, 1, 1)
		lines[i] = l
	end
	recordLines[kind] = lines
end
local function showRecords()
	for kind, lines in pairs(recordLines) do
		local sky = kind == "Sky"
		local wins = player:GetAttribute(sky and "SkyWins" or "RaceWins") or 0
		local losses = player:GetAttribute(sky and "SkyLosses" or "RaceLosses") or 0
		local best = player:GetAttribute(sky and "RaceBestSky" or "RaceBestRoad")
		lines[1].Text = sky and "🦅 하늘 레이스" or "🏁 지상 레이스"
		lines[2].Text = string.format("내 기록 %d승 %d패", wins, losses)
		lines[3].Text = best and string.format("⏱️ 최고 %.1f초", best) or "⏱️ 최고 기록 없음"
		lines[4].Text = "🌏 전 서버 최고"
		local ok, top = pcall(HttpService.JSONDecode, HttpService, ReplicatedStorage:GetAttribute("RaceTop" .. kind) or "[]")
		top = ok and type(top) == "table" and top or {}
		for rank = 1, 3 do
			local entry = top[rank]
			lines[4 + rank].Text = entry and string.format("%d. %s %.1f초", rank, tostring(entry.Name), entry.Seconds or 0)
				or (rank == 1 and "아직 기록이 없어요" or "")
		end
	end
end
for _, name in ipairs({ "RaceWins", "RaceLosses", "SkyWins", "SkyLosses", "RaceBestRoad", "RaceBestSky" }) do
	player:GetAttributeChangedSignal(name):Connect(showRecords)
end
for _, kind in ipairs({ "Road", "Sky" }) do
	ReplicatedStorage:GetAttributeChangedSignal("RaceTop" .. kind):Connect(showRecords)
end
showRecords()

-- (2026-10-02, "연습은 오른쪽 창에 나오게 해줘 Pick a mount 처럼") race practice on the registered mount: the
-- pedestal's prompts (Kind RoadPractice / SkyPractice, Ride service), shown on this screen only at my own base
-- and only the one my mount can race (walking: road, flying: sky), not while I race
local practicePrompts = LiveSet.new()
local function showPractice(prompt)
	local mount = player:GetAttribute("Mount")
	local flies = mount ~= nil and Formulas.flies(mount) == true
	prompt.Enabled = mount ~= nil and player:GetAttribute("Racing") == nil and Unlock.usable("Ride")
		and prompt:GetAttribute("Base") == player:GetAttribute("Base")
		and (prompt:GetAttribute("Practice") == "Sky") == flies
end
local function refreshPractice()
	practicePrompts:each(showPractice)
end
local function watchPrompt(d)
	if d:IsA("ProximityPrompt") and d:GetAttribute("Practice") then
		practicePrompts:add(d)
		showPractice(d)
	end
end
WorldWatch.listen({ "ProximityPrompt" }, watchPrompt)
for _, name in ipairs({ "Racing", "Base" }) do
	player:GetAttributeChangedSignal(name):Connect(refreshPractice)
end
Unlock.watch(function()
	task.delay(0.5, refreshPractice)
end)

-- { { species, rarity, size }, ... }: the default dino (plain, unless owned) and every species × rarity × size I own
-- that walks, rarest and biggest first
local function choices(kind)
	local list2, seen = {}, {}
	local data = Net.ask("GetMyUnits")
	local ownsDefault = false
	for _, u in ipairs(data and data.Units or {}) do
		local key = u.Species .. "/" .. u.Rarity .. "/" .. tostring(u.Size)
		if not seen[key] and Formulas.rideable(u.Species) and (not kind or fitsKind(u.Species, kind)) then
			seen[key] = true
			table.insert(list2, { u.Species, u.Rarity, u.Size })
			ownsDefault = ownsDefault or u.Species == Config.Ride.DefaultSpecies
		end
	end
	if not ownsDefault and (not kind or fitsKind(Config.Ride.DefaultSpecies, kind)) then
		table.insert(list2, { Config.Ride.DefaultSpecies, "Common" })
	end
	local function look(sizeId)
		local size = sizeId and Formulas.dinoSize(sizeId)
		return size and (size.Look or size.Scale) or 0
	end
	table.sort(list2, function(a, b)
		local ra, rb = Formulas.rarityRank(a[2]), Formulas.rarityRank(b[2])
		if ra ~= rb then
			return ra > rb
		end
		if a[1] ~= b[1] then
			return a[1] < b[1]
		end
		return look(a[3]) > look(b[3])
	end)
	return list2
end

-- (2026-10-04, "왜 두개씩 뜸": registering a mount changes Mount and MountRarity together, two rebuilds ran at once,
-- each cleared the list, waited for the server and added its rows: every row twice) the rows are asked for first,
-- and only the newest rebuild puts them in
local rebuilding = 0
local function rebuild()
	rebuilding += 1
	local mine = rebuilding
	local kind = raceKind
	local rows = choices(kind)
	if mine ~= rebuilding then
		return -- (a newer one is on its way)
	end
	if kind and #rows == 0 then
		hint.Text = kind == "Sky" and "🦅 아직 나는 공룡이 없어요 · 🎰 뽑기에서 얻어요" or "🦖 아직 걷는 공룡이 없어요 · 🎰 뽑기에서 얻어요"
	end
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
	local current, currentRarity = player:GetAttribute("Mount"), player:GetAttribute("MountRarity")
	local currentSize = player:GetAttribute("MountSize")
	for i, choice in ipairs(rows) do
		local species, rarity, sizeId = choice[1], choice[2], choice[3]
		local info = Formulas.species(species)
		local chosen = species == current and rarity == (currentRarity or "Common") and sizeId == currentSize
		local row = Instance.new("TextButton")
		row.LayoutOrder = chosen and 0 or i
		row.BackgroundColor3 = chosen and COLOR_CHOSEN or COLOR_ROW
		row.Text = ""
		row.Parent = list
		Coach.mark(row, kind and "RaceMount" or (not chosen and "MountPick") or nil)
		corner(row, 8)
		local picture = DinoPortrait.new(species, UDim2.fromOffset(PORTRAIT, PORTRAIT))
		picture.AnchorPoint = Vector2.new(0.5, 0)
		picture.Position = UDim2.new(0.5, 0, 0, 4)
		picture.Parent = row
		DinoPortrait.border(row, rarity) -- its rarity at a glance (its aura goes on the mount)
		if Formulas.flies(species) then
			local wing = label(row, "🦅", UDim2.fromOffset(22, 22), UDim2.fromOffset(4, 4), 16)
			wing.TextXAlignment = Enum.TextXAlignment.Left
		end
		local rarityInfo = Formulas.rarity(rarity)
		local sizeInfo = sizeId and Formulas.dinoSize(sizeId)
		local name = label(row, info and info.Name or species, UDim2.new(1, -6, 0, 16), UDim2.fromOffset(3, PORTRAIT + 6), 13)
		name.TextScaled = true
		local gradeText = rarityInfo and rarityInfo.Name or rarity
		local grade = label(row, sizeInfo and string.format("%s · %s", gradeText, sizeInfo.Name) or gradeText, UDim2.new(1, -6, 0, 14),
			UDim2.fromOffset(3, PORTRAIT + 22), 12)
		grade.TextScaled = true
		grade.TextColor3 = DinoPortrait.gradeColor(rarity)
		local t = label(row, chosen and "✅ 내 탈 공룡" or species == Config.Ride.DefaultSpecies and "누구나" or "👆 눌러서 등록",
			UDim2.new(1, -6, 0, 18), UDim2.new(0, 3, 1, -22), 12)
		t.TextScaled = true
		row.Activated:Connect(function()
			if kind then
				Net.request("SetRaceMount", species, rarity, sizeId or "")
			elseif not chosen then
				Net.request("SetMount", species, rarity, sizeId or "")
			end
		end)
	end
end

local rebuildSoon = false -- (both attributes change in one go: one rebuild for the two)
for _, name in ipairs({ "Mount", "MountRarity", "MountSize" }) do
	player:GetAttributeChangedSignal(name):Connect(function()
		refreshPractice()
		if raceKind and name == "Mount" and fitsKind(player:GetAttribute("Mount"), raceKind) then
			local kind, retry = raceKind, raceRetry
			raceKind, raceRetry = nil, nil
			window.Visible = false
			showHint()
			if retry == "Ready" then
				Net.request("RaceRoomReady", true)
			elseif retry == "Practice" then
				Net.request("RacePractice", kind)
			end
			return
		end
		if window.Visible and not rebuildSoon then
			rebuildSoon = true
			task.defer(function()
				rebuildSoon = false
				if window.Visible then
					rebuild()
				end
			end)
		end
	end)
end

ProximityPromptService.PromptTriggered:Connect(function(prompt)
	local practice = prompt:GetAttribute("Practice")
	if practice and prompt:GetAttribute("Base") == player:GetAttribute("Base") then
		window.Visible = false
		Net.request("RacePractice", practice)
		return
	end
	if prompt:GetAttribute("Kind") == "Mount" and prompt:GetAttribute("Base") == player:GetAttribute("Base") then
		if window.Visible then -- E again closes it
			window.Visible = false
			return
		end
		openedBy = prompt
		raceKind, raceRetry = nil, nil
		showHint()
		window.Visible = true
		rebuild()
		showRecords()
	end
end)
Net.onPush("RaceMountPick", function(kind, retry)
	if kind ~= "Road" and kind ~= "Sky" then
		return
	end
	raceKind = kind
	raceRetry = retry ~= "" and retry or nil
	openedBy = nil
	showHint()
	window.Visible = true
	rebuild()
	showRecords()
end)
close.Activated:Connect(function()
	window.Visible = false
end)
window:GetPropertyChangedSignal("Visible"):Connect(function()
	if not window.Visible then
		raceKind, raceRetry = nil, nil
	end
end)
RunService.Heartbeat:Connect(FrameMeter.wrap("Ride", function() -- walked away from the pedestal: close it
	if window.Visible and openedBy then
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		local holder = openedBy.Parent -- (a part, or an attachment: Bases.prompt, 2026-10-02)
		local at = holder and (holder:IsA("Attachment") and holder.WorldPosition or holder:IsA("BasePart") and holder.Position)
		if not root or not at or (root.Position - at).Magnitude > openedBy.MaxActivationDistance + CLOSE_SLACK then
			window.Visible = false
		end
	end
end))
Windows.register(window)

task.spawn(function()
	local shown = {}
	while true do
		local map = Workspace:FindFirstChild("Map")
		local visible = player:GetAttribute("HideAuras") ~= true
		local lightMode = player:GetAttribute("LightMode") == true
		local state = visible and (lightMode and "lite" or "on") or "off"
		RarityFx.setLite(lightMode)
		for index = 1, Config.Map.BaseCount do
			local base = map and map:FindFirstChild("Base" .. index)
			local pedestal = base and base:FindFirstChild("MountPedestal")
			local statue = pedestal and pedestal:FindFirstChild("MountStatue")
			local s = shown[index]
			if statue and (not s or s.statue ~= statue) then
				local _, size = statue:GetBoundingBox()
				RarityFx.apply(statue, statue:GetAttribute("Rarity") or "Common", math.min(size.X, size.Z) * MOUNT_FOOTPRINT,
					{ locked = true, burnOnly = MOUNT_BURN_SCALE })
				s = { statue = statue }
				shown[index] = s
			elseif not statue then
				shown[index], s = nil, nil
			end
			local hidden = pedestal ~= nil and pedestal:GetAttribute("Hidden") == true
			local now = hidden and "hidden" or state
			if s and s.state ~= now then
				s.state = now
				RarityFx.setVisible(statue, visible and not hidden)
			end
		end
		task.wait(STATUE_CHECK_EVERY)
	end
end)
