--[[
LaunchGift (client): the launch gift's celebration (Net push LaunchGift, once a player; the server's LaunchGift service).
(2026-10-04, "웰컴 런칭기념 공룡 드립니다 이런식으로 모델링 보여주면서", "한정 공룡 막 대단한거 받은 거처럼")

Once Coco's opening is over (player attribute TutorialOpening): the legendary draw's show (Shared/GachaFx: a flash,
light rays, flying emoji, its fanfare), a dark screen with turning golden rays behind, and a window: "🎉 웰컴! 런칭 기념
선물!", the dino's model turning slowly in a big picture, its name, its rarity, size and attribute, one line a child
gets ("🎉 게임이 처음 열린 기념! 지금 온 친구들만 받는 한정 공룡이에요"), what it is good for ("⚡ 번개 한 방에 화석 여러
마리!"), where it is now, and a big "🎉 고마워요!" button.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TweenService = game:GetService("TweenService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local GachaFx = require(Shared:WaitForChild("GachaFx"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBlack
local WINDOW_SIZE = UDim2.fromOffset(360, 456)
local PICTURE = 200
local SHOW_GRADE = "Legendary" -- whose draw show plays (GachaFx)
local GOLD = Color3.fromRGB(255, 205, 60)
local VIOLET = Color3.fromRGB(138, 92, 255)
local COLOR_BG = Color3.fromRGB(30, 22, 52)
local COLOR_BUTTON = Color3.fromRGB(255, 170, 40)
local RAY_COUNT = 12
local RAY_SPIN = 0.35 -- radians a second
local DINO_SPIN = 0.9
local OPENING_WAIT = 180 -- seconds at most for Coco's opening (and the first fight after it) to end
local POP_SECONDS = 0.45

local function label(parent, text, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.Text = text
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextStrokeTransparency = 0.4
	l.TextScaled = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = textSize
	most.Parent = l
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function corner(object, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = object
end

local function celebrate(speciesId, rarityId, sizeId)
	local started = os.clock()
	while (player:GetAttribute("TutorialOpening") or player:GetAttribute("CocoIntro") or player:GetAttribute("FirstFight"))
		and os.clock() - started < OPENING_WAIT do
		task.wait(0.5)
	end
	started = os.clock()
	while Windows.anyOpen() and os.clock() - started < OPENING_WAIT do
		task.wait(0.5)
	end
	local species = Formulas.species(speciesId)
	if not species then
		player:SetAttribute("LaunchGiftUp", nil)
		return
	end
	local gui = Instance.new("ScreenGui")
	gui.Name = "LaunchGift"
	gui.ResetOnSpawn = false
	gui.IgnoreGuiInset = true
	gui.DisplayOrder = 40
	gui.Parent = player:WaitForChild("PlayerGui")

	-- the dark screen and the turning golden rays behind the window
	local dim = Instance.new("Frame")
	dim.Size = UDim2.fromScale(1, 1)
	dim.BackgroundColor3 = Color3.new(0, 0, 0)
	dim.BackgroundTransparency = 1
	dim.Active = true -- (presses don't go through to the game)
	dim.Parent = gui
	TweenService:Create(dim, TweenInfo.new(0.4), { BackgroundTransparency = 0.35 }):Play()
	local rays = Instance.new("Frame")
	rays.AnchorPoint = Vector2.new(0.5, 0.5)
	rays.Position = UDim2.fromScale(0.5, 0.5)
	rays.Size = UDim2.fromOffset(900, 900)
	rays.BackgroundTransparency = 1
	rays.Parent = dim
	for i = 1, RAY_COUNT do
		local ray = Instance.new("Frame")
		ray.AnchorPoint = Vector2.new(0.5, 0.5)
		ray.Position = UDim2.fromScale(0.5, 0.5)
		ray.Size = UDim2.new(0, 46, 1, 0)
		ray.Rotation = (i - 1) * 180 / RAY_COUNT
		ray.BackgroundColor3 = i % 2 == 0 and GOLD or VIOLET
		ray.BackgroundTransparency = 0.75
		ray.BorderSizePixel = 0
		ray.Parent = rays
	end

	-- the window
	local window = Instance.new("Frame")
	window.AnchorPoint = Vector2.new(0.5, 0.5)
	window.Position = UDim2.fromScale(0.5, 0.5)
	window.Size = WINDOW_SIZE
	window.BackgroundColor3 = COLOR_BG
	window.Parent = gui
	corner(window, 18)
	local edge = Instance.new("UIStroke")
	edge.Color = GOLD
	edge.Thickness = 4
	edge.Parent = window
	local scale = Instance.new("UIScale")
	scale.Scale = 0.2
	scale.Parent = window
	-- (smaller on a short screen: the window fits)
	local camera = workspace.CurrentCamera
	local fit = camera and math.min(1, (camera.ViewportSize.Y - 20) / WINDOW_SIZE.Y.Offset) or 1
	TweenService:Create(scale, TweenInfo.new(POP_SECONDS, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = fit }):Play()

	label(window, "🎉 웰컴! 런칭 기념 선물!", UDim2.new(1, -24, 0, 34), UDim2.fromOffset(12, 10), 26, GOLD)
	-- the dino, big and turning
	local holder = Instance.new("Frame")
	holder.AnchorPoint = Vector2.new(0.5, 0)
	holder.Position = UDim2.new(0.5, 0, 0, 46)
	holder.Size = UDim2.fromOffset(PICTURE, PICTURE)
	holder.BackgroundColor3 = VIOLET
	holder.BackgroundTransparency = 0.6
	holder.Parent = window
	corner(holder, PICTURE // 2)
	local picture = DinoPortrait.new(speciesId, UDim2.fromScale(1, 1))
	picture.Parent = holder
	local model = picture:IsA("ViewportFrame") and picture:FindFirstChildOfClass("Model")
	local rarity = Formulas.rarity(rarityId)
	local size = Formulas.dinoSize(sizeId)
	local attribute = Config.Attributes[species.Attribute]
	label(window, "🎉 " .. species.Name, UDim2.new(1, -24, 0, 30), UDim2.fromOffset(12, 52 + PICTURE), 24)
	label(window, string.format("⭐ %s · %s · %s", rarity and rarity.Name or "", size and size.Name or "",
		attribute and (attribute.Icon .. " " .. attribute.Name) or ""), UDim2.new(1, -24, 0, 20),
		UDim2.fromOffset(12, 84 + PICTURE), 16, GOLD)
	label(window, "🎉 게임이 처음 열린 기념! 지금 온 친구들만 받는 한정 공룡이에요", UDim2.new(1, -24, 0, 36),
		UDim2.fromOffset(12, 106 + PICTURE), 15)
	-- (2026-10-04, "웰컴렉스는 초반에 유용하게") what it is good for, in a child's words
	label(window, "⚡ 번개 한 방에 화석 여러 마리! 디펜스에 놓아 봐요", UDim2.new(1, -24, 0, 20), UDim2.fromOffset(12, 146 + PICTURE),
		15, GOLD)
	label(window, "📦 내 공룡 목록에 넣어 뒀어요", UDim2.new(1, -24, 0, 20), UDim2.fromOffset(12, 170 + PICTURE), 14,
		Color3.fromRGB(190, 230, 255))
	local thanks = Instance.new("TextButton")
	thanks.AnchorPoint = Vector2.new(0.5, 1)
	thanks.Position = UDim2.new(0.5, 0, 1, -12)
	thanks.Size = UDim2.fromOffset(220, 46)
	thanks.Font = FONT
	thanks.TextSize = 22
	thanks.Text = "🎉 고마워요!"
	thanks.TextColor3 = Color3.new(1, 1, 1)
	thanks.TextStrokeTransparency = 0.4
	thanks.BackgroundColor3 = COLOR_BUTTON
	thanks.Parent = window
	corner(thanks, 14)

	-- the show
	GachaFx.burst(SHOW_GRADE, GOLD, window)
	task.delay(0.6, Sfx.play, "Victory")
	local spin
	spin = RunService.RenderStepped:Connect(FrameMeter.wrap("LaunchGift", function(dt)
		rays.Rotation += math.deg(RAY_SPIN * dt)
		if model and model.Parent then
			model:PivotTo(model:GetPivot() * CFrame.Angles(0, DINO_SPIN * dt, 0))
		end
	end))
	thanks.Activated:Connect(function()
		spin:Disconnect()
		Sfx.play("UiClick")
		TweenService:Create(scale, TweenInfo.new(0.2), { Scale = 0 }):Play()
		TweenService:Create(dim, TweenInfo.new(0.3), { BackgroundTransparency = 1 }):Play()
		task.delay(0.35, function()
			gui:Destroy()
			player:SetAttribute("LaunchGiftUp", nil)
		end)
	end)
end

Net.onPush("LaunchGift", function(speciesId, rarityId, sizeId)
	if type(speciesId) == "string" then
		player:SetAttribute("LaunchGiftUp", true)
		task.spawn(celebrate, speciesId, rarityId, sizeId)
	end
end)
