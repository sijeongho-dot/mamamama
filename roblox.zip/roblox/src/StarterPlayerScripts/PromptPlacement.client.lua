--[[
PromptPlacement (2026-10-02, "모든 이 창들이 대상 중심에 생겨서 대상이 원래 무슨 내용인지 읽기가 힘들어. 레이스신청때도
유저 모습을 볼수가 없고 … 위치 조정해봐"): Roblox draws a ProximityPrompt over the middle of what it is on,
right over a sign's words or a player's body. While a prompt is shown, this screen moves it (UIOffset, display
only) to just beside the thing it belongs to (its right, else its left; level with its middle): a sign, a stall or a player whole (a character, a model up to
WHOLE_MODEL_MAX studs: their full box; anything bigger: the prompt's own part), kept on the screen. An offset the
server gave a prompt (the ride pedestal's stacked practice prompts, Ride service) is kept and added to.
]]

local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TextService = game:GetService("TextService")
local Workspace = game:GetService("Workspace")

-- display only
local PROMPT_HALF_HEIGHT = 36 -- pixels: half of Roblox's prompt
local PROMPT_KEY_WIDTH = 72 -- pixels: Roblox's prompt = its key square + its longest text + TEXT_PAD
local PROMPT_TEXT_PAD = 24
local ACTION_TEXT_SIZE, OBJECT_TEXT_SIZE = 19, 14 -- (Roblox's prompt: GothamMedium)
local GAP = 4 -- pixels between the thing's side and the prompt
local EDGE = 8 -- pixels kept from the screen's edges
local WIDE_SHARE = 0.3 -- a thing wider than this share of the screen: measured by the prompt's own part
local SPOT_BOX = Vector3.new(3, 5, 3) -- studs: the small box round a prompt's own spot
local WHOLE_MODEL_MAX = 40 -- studs: a model up to this big is measured whole (a sign with its posts, a character)
local BUTTONS_EVERY = 0.5 -- seconds between looks at where the screen's buttons are
local BUTTON_MAX_SHARE = 0.4 -- a button wider or taller than this share of the screen is a window's, not the HUD's
local WINDOW_ORDER = 5 -- (Shared/Windows) an open window's ScreenGui is raised to this: not the HUD

local player = Players.LocalPlayer
local shown = {} -- [prompt] = true while on the screen
local given = {} -- [prompt] = the UIOffset the server gave it
local applied = {} -- [prompt] = the UIOffset this screen set

-- the box the prompt belongs to: CFrame, size of the thing (the outermost model round its part up to
-- WHOLE_MODEL_MAX studs, or a character), then CFrame, size of a small box round the prompt's own spot
-- (2026-10-02, "왤케 멀어": the fallback was the whole part it hangs on, a stall's back wall, far from the stall's
-- front) for things too wide on the screen
local function boxOf(prompt)
	local holder = prompt.Parent
	local spot
	if holder and holder:IsA("Attachment") then
		spot = holder.WorldPosition
		holder = holder.Parent
	end
	if not holder or not holder:IsA("BasePart") then
		return nil
	end
	spot = spot or holder.Position
	local smallCf, smallSize = CFrame.new(spot), SPOT_BOX
	local best = nil
	local model = holder:FindFirstAncestorOfClass("Model")
	while model do
		local cf, size = model:GetBoundingBox()
		if model:FindFirstChildOfClass("Humanoid") then
			return cf, size, smallCf, smallSize
		end
		if math.max(size.X, size.Y, size.Z) > WHOLE_MODEL_MAX then
			break
		end
		best = { cf, size }
		model = model:FindFirstAncestorOfClass("Model")
	end
	if best then
		return best[1], best[2], smallCf, smallSize
	end
	return smallCf, smallSize, smallCf, smallSize
end

-- (2026-10-02, "너무 멀지 않니 일반적으로": a fixed 130 pixels was wider than most prompts, so a short one like
-- 환생 sat far off) half the prompt's own width, worked out from its texts the way Roblox's prompt does
local function halfWidthOf(prompt)
	local function width(text, size)
		if text == "" then
			return 0
		end
		return TextService:GetTextSize(text, size, Enum.Font.GothamMedium, Vector2.new(1000, 1000)).X
	end
	local text = math.max(width(prompt.ActionText, ACTION_TEXT_SIZE), width(prompt.ObjectText, OBJECT_TEXT_SIZE))
	if text == 0 then
		return PROMPT_KEY_WIDTH / 2
	end
	return (PROMPT_KEY_WIDTH + text + PROMPT_TEXT_PAD) / 2
end

-- where Roblox draws the prompt (its middle, before the offset)
local function anchorOf(prompt)
	local holder = prompt.Parent
	if holder and holder:IsA("Attachment") then
		return holder.WorldPosition
	elseif holder and holder:IsA("BasePart") then
		return holder.Position
	end
	return nil
end

-- (2026-10-02, "너무 위에있어": a prompt's UIOffset is up-positive, like a BillboardGui's; then "이건 너무 아랜데 그냥
-- 옆에 띄워줄 순 없나 왼쪽 … 오른쪽이나") beside the thing: to the right of its box on the screen, or to the left
-- when there is no room on the right, level with its middle; X is right-positive
-- a box's rectangle on the screen: left, right, top, bottom (-math.huge right when it is all behind the camera)
local function screenBox(camera, cf, size)
	local left, right, top, bottom = math.huge, -math.huge, math.huge, -math.huge
	for _, x in ipairs({ -0.5, 0.5 }) do
		for _, y in ipairs({ -0.5, 0.5 }) do
			for _, z in ipairs({ -0.5, 0.5 }) do
				local p = camera:WorldToViewportPoint((cf * CFrame.new(size.X * x, size.Y * y, size.Z * z)).Position)
				if p.Z > 0 then
					left, right = math.min(left, p.X), math.max(right, p.X)
					top, bottom = math.min(top, p.Y), math.max(bottom, p.Y)
				end
			end
		end
	end
	return left, right, top, bottom
end

-- (2026-10-03, "Ui에 버튼이 겹치네. 왼편으로 옮겨야 할듯": riding by the ride pedestal, its prompts on the right sat
-- under 울부짖기 / 내리기 and the slap button) the HUD's buttons on the screen (viewport pixels), looked at now and then.
-- (2026-10-03, "배틀필드 내에서 렉이 좀 걸리는거 같다": on the battlefield a mineral's prompt is nearly always up, and
-- going through the whole PlayerGui every half second was a hitch) the buttons are kept in a list as they come and
-- go; a look reads only theirs, and skips the windows' (their ScreenGui raised to WINDOW_ORDER and over)
local tracked = {} -- [GuiButton] = its ScreenGui
local function track(d)
	if d:IsA("GuiButton") then
		tracked[d] = d:FindFirstAncestorOfClass("ScreenGui") or false
	end
end
task.spawn(function()
	local gui = player:WaitForChild("PlayerGui")
	gui.DescendantAdded:Connect(track)
	gui.DescendantRemoving:Connect(function(d)
		tracked[d] = nil
	end)
	for _, d in ipairs(gui:GetDescendants()) do
		track(d)
	end
end)

local buttonRects, buttonsAt = {}, -math.huge
local function hudButtons()
	if os.clock() - buttonsAt < BUTTONS_EVERY then
		return buttonRects
	end
	buttonsAt = os.clock()
	buttonRects = {}
	local camera = Workspace.CurrentCamera
	if not camera then
		return buttonRects
	end
	local inset = GuiService:GetGuiInset()
	local screen = camera.ViewportSize
	for d, sg in pairs(tracked) do
		if sg and sg.Enabled and sg.DisplayOrder < WINDOW_ORDER and d.Visible and d.AbsoluteSize.X > 0
			and d.AbsoluteSize.X < screen.X * BUTTON_MAX_SHARE and d.AbsoluteSize.Y < screen.Y * BUTTON_MAX_SHARE then
			local shownUp = true
			local a = d.Parent
			while shownUp and a and a ~= sg do
				shownUp = not a:IsA("GuiObject") or a.Visible
				a = a.Parent
			end
			if shownUp then
				local down = sg.IgnoreGuiInset and 0 or inset.Y
				local p, size = d.AbsolutePosition, d.AbsoluteSize
				table.insert(buttonRects, { p.X, p.Y + down, p.X + size.X, p.Y + down + size.Y })
			end
		end
	end
	return buttonRects
end

-- how much of the HUD's buttons a prompt (or a stack of them) at x would cover, in square pixels
local function covered(x, halfWidth, top, bottom)
	local area = 0
	for _, r in ipairs(hudButtons()) do
		local w = math.min(x + halfWidth, r[3]) - math.max(x - halfWidth, r[1])
		local h = math.min(bottom, r[4]) - math.max(top, r[2])
		if w > 0 and h > 0 then
			area += w * h
		end
	end
	return area
end

local function place(prompt, camera)
	local base = given[prompt] or Vector2.zero
	local cf, size, partCf, partSize = boxOf(prompt)
	local anchor = anchorOf(prompt)
	if not cf or not anchor then
		return
	end
	local center = camera:WorldToViewportPoint(anchor)
	if center.Z <= 0 then
		return -- (behind the camera)
	end
	local screen = camera.ViewportSize
	local halfWidth = halfWidthOf(prompt)
	local left, right, top, bottom = screenBox(camera, cf, size)
	-- (2026-10-02, "이건 너무 오른편" → "캐릭터 옆 말고 대상 옆": a big thing, the whole ride pedestal with its
	-- statue, pushed it far off) a thing wider than WIDE_SHARE of the screen: beside the prompt's own part instead
	if right ~= -math.huge and right - left > screen.X * WIDE_SHARE then
		left, right, top, bottom = screenBox(camera, partCf, partSize)
	end
	if right == -math.huge then
		return
	end
	-- prompts stacked on one spot by the server (the ride pedestal's practice ones: a row each) stay in rows,
	-- the group level with the thing's middle, all on the screen
	local depth = 0
	for other in pairs(shown) do
		if other.Parent == prompt.Parent then
			depth = math.max(depth, math.abs((given[other] or Vector2.zero).Y))
		end
	end
	local middle = (math.max(top, 0) + math.min(bottom, screen.Y)) / 2
	local firstRow = math.clamp(middle - depth / 2, EDGE + PROMPT_HALF_HEIGHT,
		math.max(EDGE + PROMPT_HALF_HEIGHT, screen.Y - EDGE - PROMPT_HALF_HEIGHT - depth))
	-- the side: right if it fits, else left if it fits, else the side with more room (kept on the screen);
	-- (2026-10-03) and the side that covers fewer of the HUD's buttons (the slap, ride and jump buttons sit right)
	local function clampX(v)
		return math.clamp(v, EDGE + halfWidth, screen.X - EDGE - halfWidth)
	end
	local rightX, leftX = clampX(right + GAP + halfWidth), clampX(left - GAP - halfWidth)
	local x = right + GAP + halfWidth
	if x > screen.X - EDGE - halfWidth then
		if left - GAP - halfWidth >= EDGE + halfWidth or (screen.X - right) < left then
			x = left - GAP - halfWidth
		end
	end
	x = clampX(x)
	local rowsTop, rowsBottom = firstRow - PROMPT_HALF_HEIGHT, firstRow + depth + PROMPT_HALF_HEIGHT
	local onRight = covered(rightX, halfWidth, rowsTop, rowsBottom)
	if x == rightX and onRight > 0 and covered(leftX, halfWidth, rowsTop, rowsBottom) < onRight then
		x = leftX
	end
	local y = firstRow + math.abs(base.Y)
	local offset = Vector2.new(math.floor(x - center.X + 0.5), math.floor(center.Y - y + 0.5))
	if prompt.UIOffset ~= offset then
		applied[prompt] = offset
		prompt.UIOffset = offset
	end
end

local function remember(prompt)
	if prompt.UIOffset ~= applied[prompt] then -- (a new offset from the server, not ours)
		given[prompt] = prompt.UIOffset
	end
end

-- (2026-10-03, "보물상자 꾹 누르고있는데 계속 놔지네") a prompt being held stays where it is: moved under the finger
-- every frame (the shaking chest), its hold could drop
local holding = {}
ProximityPromptService.PromptButtonHoldBegan:Connect(function(prompt)
	holding[prompt] = true
end)
ProximityPromptService.PromptButtonHoldEnded:Connect(function(prompt)
	holding[prompt] = nil
end)

ProximityPromptService.PromptShown:Connect(function(prompt)
	remember(prompt)
	shown[prompt] = true
end)
ProximityPromptService.PromptHidden:Connect(function(prompt)
	shown[prompt] = nil
	holding[prompt] = nil
	if given[prompt] and prompt.Parent then
		prompt.UIOffset = given[prompt] -- (back as the server gave it)
	end
	applied[prompt], given[prompt] = nil, nil
end)

RunService.RenderStepped:Connect(FrameMeter.wrap("PromptPlacement", function()
	local camera = Workspace.CurrentCamera
	if not camera or not next(shown) then
		return
	end
	for prompt in pairs(shown) do
		if prompt.Parent and holding[prompt] then -- (left where it is while held)
			continue
		elseif prompt.Parent then
			remember(prompt)
			place(prompt, camera)
		else
			shown[prompt] = nil
		end
	end
end))
