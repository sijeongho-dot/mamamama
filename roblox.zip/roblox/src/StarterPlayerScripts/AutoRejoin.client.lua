--[[
AutoRejoin: back into the game by itself after the connection is lost (2026-10-05, "휴대폰에서 화면 잠시 나갔다 들어오면
게임이 나가져 있는데 알아서 재접속 하게 해주면 안됨? 게임에서 안나가지는게 베스트인데..").

A phone puts Roblox to sleep while its screen is off or another app is in front; past a short while the Roblox server
counts the player as gone (error 277, "lost connection"), and no game code can keep the link open meanwhile. What this
does instead: when the link is lost (the network's replicator goes, or Roblox's error message comes) for a reason in
REJOIN_CODES - never a kick by the game (a full server, a save held elsewhere), the 20-minute idle kick or a teleport's
own failure - it says "🔄 다시 들어가는 중…" and asks Roblox to teleport this player back: to the same server first
(it may still be up, with the friends in it), else to any server of the game. At most TRIES tries. The save follows on
its own (PlayerData: the new server waits for the old one's leaving save, or asks it to let go). Not in Studio.
]]

local GuiService = game:GetService("GuiService")
local NetworkClient = game:GetService("NetworkClient")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Stats = game:GetService("Stats")
local TeleportService = game:GetService("TeleportService")

local player = Players.LocalPlayer

-- display only (how the reconnecting goes; no game rule)
local SETTLE_SECONDS = 4 -- after the link goes, how long Roblox's error code is waited for (none: left alone)
local TRY_GAP = 3 -- seconds between tries
local TRIES = 5 -- the first one to the same server, the rest to any server
local DEAD_SECONDS = 7
local DEAD_SECONDS_LOADING = 25
local DEAD_KBPS = 6
local PAUSE_GAP = 2
local LABEL_SIZE = UDim2.fromOffset(320, 44)
local LABEL_POS = UDim2.new(0.5, 0, 0, 12)
local COLOR_BG = Color3.fromRGB(30, 40, 70)
local REJOIN_CODES = { -- (Enum.ConnectionError names: the link lost, not a kick)
	"DisconnectConnectionLost", "DisconnectTimeout", "DisconnectErrors", "DisconnectRaknetErrors",
	"DisconnectReceivePacketError", "DisconnectReceivePacketStreamError", "DisconnectSendPacketError",
}

if RunService:IsStudio() then
	return
end

local rejoinCodes = {}
for _, name in ipairs(REJOIN_CODES) do
	local ok, code = pcall(function()
		return Enum.ConnectionError[name]
	end)
	if ok and code then
		rejoinCodes[code] = true
	end
end

local serverId = game.JobId
local started = false

local function showLabel()
	local gui = Instance.new("ScreenGui")
	gui.Name = "AutoRejoin"
	gui.ResetOnSpawn = false
	gui.DisplayOrder = 100
	gui.IgnoreGuiInset = true
	local label = Instance.new("TextLabel")
	label.AnchorPoint = Vector2.new(0.5, 0)
	label.Size = LABEL_SIZE
	label.Position = LABEL_POS
	label.BackgroundColor3 = COLOR_BG
	label.TextColor3 = Color3.new(1, 1, 1)
	label.Font = Enum.Font.GothamBold
	label.TextSize = 18
	label.Text = "🔄 다시 들어가는 중…"
	label.Parent = gui
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 10)
	corner.Parent = label
	pcall(function()
		gui.Parent = player:FindFirstChildOfClass("PlayerGui")
	end)
end

local function rejoin()
	if started then
		return
	end
	started = true
	showLabel()
	for try = 1, TRIES do
		pcall(function()
			if try == 1 and serverId ~= "" then
				TeleportService:TeleportToPlaceInstance(game.PlaceId, serverId, player)
			else
				TeleportService:Teleport(game.PlaceId, player)
			end
		end)
		task.wait(TRY_GAP) -- (a teleport that works ends this script; one that fails is tried again)
	end
end

local teleporting = false -- (a teleport of the game's own, the tutorial field's: the link goes then too)
player.OnTeleport:Connect(function(state)
	teleporting = state ~= Enum.TeleportState.Failed
end)

local function errorCode()
	local ok, code = pcall(function()
		return GuiService:GetErrorCode()
	end)
	return ok and code or nil
end

-- the replicator went: a rejoin only once Roblox names a lost link (a kick or a teleport is left alone)
local function linkLost()
	local waited = 0
	while waited < SETTLE_SECONDS and not started do
		if rejoinCodes[errorCode()] and not teleporting then
			rejoin()
			return
		end
		waited += task.wait(0.25)
	end
end

NetworkClient.ChildRemoved:Connect(function(child)
	if child:IsA("ClientReplicator") then
		task.spawn(linkLost)
	end
end)
GuiService.ErrorMessageChanged:Connect(function()
	if rejoinCodes[errorCode()] and not teleporting then
		task.spawn(rejoin)
	end
end)

local lastSignal = nil
ReplicatedStorage:GetAttributeChangedSignal("ServerClock"):Connect(function()
	lastSignal = os.clock()
end)
local lastFrame = os.clock()
RunService.Heartbeat:Connect(function()
	local now = os.clock()
	if lastSignal and now - lastFrame > PAUSE_GAP then
		lastSignal = math.max(lastSignal, now)
	end
	lastFrame = now
end)

local function receiving()
	local ok, kbps = pcall(function()
		return Stats.DataReceiveKbps
	end)
	return ok and kbps / 8 >= DEAD_KBPS
end

task.spawn(function()
	while not started do
		task.wait(0.5)
		local limit = player:GetAttribute("Loading") and DEAD_SECONDS_LOADING or DEAD_SECONDS
		if lastSignal and not teleporting and os.clock() - lastSignal > limit and not receiving() then
			rejoin()
		end
	end
end)
