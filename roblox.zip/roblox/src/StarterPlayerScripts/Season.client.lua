--[[
Season: the "🏆 시즌" button and the season pass window on this client
(2026-10-02, design 2.15; the server's Season service decides: Net ask GetSeason, request ClaimSeason).

- The button (in the right column, right of 💎 상점) and its red badge: rewards waiting (player attribute SeasonReady).
- The window: the season and its theme, the days left, the season level and the XP bar to the next, how
  XP is earned (2026-10-04: in picture chips, ⏱️ 놀기 · ✅ 임무 · 📆 출석 · 📅 주간 · ⚔️ 승급전); then a row for every level: its free reward on the left, the pass reward on the right,
  each "받기" when ready, ✔ taken, 🔒 not reached (the pass ones 💎 without the pass). It opens scrolled
  to the level reached. "🎁 모두 받기" takes all that wait; "💎 패스" buys this season's pass (the Robux
  product SeasonPass; Studio grants it while it has no id), hidden where paid random items are restricted.
Sized in pixels and fitted to the screen's free part (Shared/Windows: smaller on phones).
]]

local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(Shared:WaitForChild("Windows"))
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local Prices = require(Shared:WaitForChild("Prices"))

local player = Players.LocalPlayer
local C = Config.Season

-- display only
local FONT = Enum.Font.GothamBold
local OPEN_SIZE = UDim2.fromOffset(68, 36)
local OPEN_POS = UDim2.new(1, -12, 0, 178)
local CELL_TEXT_MAX, CELL_TEXT_MIN = 13, 8 -- a cell's words: this size, smaller only when long
local WINDOW_SIZE = UDim2.fromOffset(470, 390)
local HEAD_TOP = 44
local BAR_HEIGHT = 10
local LIST_TOP = 132
local ROW_HEIGHT = 58 -- (2026-10-04, "시즌 패스 창도 그림 위주로": was 52, the pictures 30)
local LEVEL_WIDTH = 44
local CELL_GAP = 6
local ICON = 42
local CLAIM_WIDTH = 54
local HOW_CHIP_WIDTH = 66
local COLOR_OPEN = Color3.fromRGB(150, 90, 210)
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_ROW = Color3.fromRGB(45, 50, 68)
local COLOR_PAID = Color3.fromRGB(70, 55, 95)
local COLOR_REACHED = Color3.fromRGB(255, 205, 60)
local COLOR_SOFT = Color3.fromRGB(190, 190, 200)
local COLOR_READY = Color3.fromRGB(70, 180, 90)
local COLOR_WAIT = Color3.fromRGB(110, 110, 120)
local COLOR_DONE = Color3.fromRGB(110, 210, 120)
local COLOR_BAR_BACK = Color3.fromRGB(55, 60, 80)
local COLOR_BAR = Color3.fromRGB(190, 120, 255)
local COLOR_BADGE = Color3.fromRGB(235, 50, 60)
local COLOR_BUY = Color3.fromRGB(60, 160, 230)
local COLOR_MONEY = Color3.fromRGB(240, 190, 60)
local COLOR_LUCK = Color3.fromRGB(90, 190, 110)
local COLOR_SKIN = Color3.fromRGB(230, 120, 160)
local COLOR_BOMB = Color3.fromRGB(200, 110, 60)

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.TextWrapped = true
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 14
	b.TextColor3 = Color3.new(1, 1, 1)
	b.TextWrapped = true
	b.Text = text
	b.BackgroundColor3 = color
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 10)
	return b
end

local open = button(nil, "🏆 시즌", COLOR_OPEN, OPEN_SIZE, OPEN_POS)
require(Shared:WaitForChild("SideButtons")).register(open)
open.AnchorPoint = Vector2.new(1, 0.5)
open.TextSize = 13
local badge = label(open, "", UDim2.fromOffset(18, 18), UDim2.new(1, -10, 0, -6), 11)
badge.BackgroundTransparency = 0
badge.BackgroundColor3 = COLOR_BADGE
badge.ZIndex = 2
corner(badge, 9)
local function refreshBadge()
	local n = player:GetAttribute("SeasonReady") or 0
	badge.Visible = n > 0
	badge.Text = tostring(n)
end
player:GetAttributeChangedSignal("SeasonReady"):Connect(refreshBadge)
refreshBadge()

local gui = Instance.new("ScreenGui")
gui.Name = "Season"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")
local window = Instance.new("Frame")
window.Size = WINDOW_SIZE
window.BackgroundColor3 = COLOR_BG
window.Visible = false
window.Parent = gui
corner(window, 14)
Windows.fit(window)
local title = label(window, "🏆 시즌 패스", UDim2.new(1, -60, 0, 34), UDim2.fromOffset(14, 6), 18)
title.TextXAlignment = Enum.TextXAlignment.Left
local levelLine = label(window, "", UDim2.new(1, -230, 0, 20), UDim2.fromOffset(14, HEAD_TOP), 14)
levelLine.TextXAlignment = Enum.TextXAlignment.Left
local barBack = Instance.new("Frame")
barBack.Position = UDim2.fromOffset(14, HEAD_TOP + 24)
barBack.Size = UDim2.new(1, -244, 0, BAR_HEIGHT)
barBack.BackgroundColor3 = COLOR_BAR_BACK
barBack.Parent = window
corner(barBack, BAR_HEIGHT // 2)
local barFill = Instance.new("Frame")
barFill.BackgroundColor3 = COLOR_BAR
barFill.Parent = barBack
corner(barFill, BAR_HEIGHT // 2)
-- (2026-10-04, "그림 위주로", "아이들도 금방 이해할만한 설명이 주가") how the stars (XP) come, in pictures: was one long line
-- with every number
local howTo = label(window, "⭐ 이렇게 모아요", UDim2.fromOffset(96, 26), UDim2.fromOffset(14, HEAD_TOP + 40), 12)
howTo.TextXAlignment = Enum.TextXAlignment.Left
howTo.TextColor3 = COLOR_SOFT
for i, word in ipairs({ "⏱️ 놀기", "✅ 임무", "📆 출석", "📅 주간", "👑 보스" }) do
	local chip = label(window, word, UDim2.fromOffset(HOW_CHIP_WIDTH, 26),
		UDim2.fromOffset(110 + (i - 1) * (HOW_CHIP_WIDTH + 4), HEAD_TOP + 40), 12)
	chip.BackgroundTransparency = 0.3
	chip.BackgroundColor3 = COLOR_ROW
	corner(chip, 8)
end
local claimAll = button(window, "🎁 모두 받기", COLOR_READY, UDim2.fromOffset(104, 34), UDim2.new(1, -220, 0, HEAD_TOP - 2))
claimAll.TextSize = 13
claimAll.Visible = false -- (until the season is known)
local buy = button(window, "", COLOR_BUY, UDim2.fromOffset(104, 34), UDim2.new(1, -110, 0, HEAD_TOP - 2))
buy.TextSize = 13
buy.Visible = false
-- the column heads
local listWidth = WINDOW_SIZE.X.Offset - 20
local cellWidth = (listWidth - 8 - LEVEL_WIDTH - 2 * CELL_GAP) / 2
label(window, "🎁 무료", UDim2.fromOffset(cellWidth, 18), UDim2.fromOffset(10 + LEVEL_WIDTH + CELL_GAP, LIST_TOP - 20), 12)
	.TextColor3 = COLOR_SOFT
local paidHead = label(window, "💎 시즌 패스", UDim2.fromOffset(cellWidth, 18),
	UDim2.fromOffset(10 + LEVEL_WIDTH + 2 * CELL_GAP + cellWidth, LIST_TOP - 20), 12)
paidHead.TextColor3 = COLOR_SOFT
local list = Instance.new("ScrollingFrame")
list.Position = UDim2.fromOffset(10, LIST_TOP)
list.Size = UDim2.new(1, -20, 1, -LIST_TOP - 10)
list.BackgroundTransparency = 1
list.ScrollBarThickness = 6
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = window
local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 5)
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = list

-- a reward's picture: the dino, a key, or an emoji on a colored circle
local function picture(parent, icon)
	local p
	if type(icon) == "table" then
		p = DinoPortrait.new(icon.dino, UDim2.fromOffset(ICON, ICON))
		p.Parent = parent
	elseif icon == "Money" or icon == "Luck" or icon == "Skin" or icon == "Bombs" then
		local look = { Money = { "💰", COLOR_MONEY }, Luck = { "🍀", COLOR_LUCK }, Skin = { "👋", COLOR_SKIN },
			Bombs = { "💣", COLOR_BOMB } }
		p = label(parent, look[icon][1], UDim2.fromOffset(ICON, ICON), UDim2.new(), math.floor(ICON * 0.6))
		p.BackgroundTransparency = 0.5
		p.BackgroundColor3 = look[icon][2]
		corner(p, ICON // 2)
	else
		p = DinoPortrait.key(icon, UDim2.fromOffset(ICON, ICON))
		p.Parent = parent
	end
	p.AnchorPoint = Vector2.new(0, 0.5)
	p.Position = UDim2.new(0, 4, 0.5, 0)
	return p
end

local data = nil
local backdropAsked = false

local function cell(row, x, track, tier, info, premium)
	local c = Instance.new("Frame")
	c.Position = UDim2.fromOffset(x, 0)
	c.Size = UDim2.new(0, cellWidth, 1, 0)
	c.BackgroundColor3 = track == "Paid" and COLOR_PAID or COLOR_ROW
	c.Parent = row
	corner(c, 8)
	picture(c, info.Icon)
	local words = label(c, info.Text, UDim2.new(1, -ICON - CLAIM_WIDTH - 14, 1, -4), UDim2.fromOffset(ICON + 8, 2), 11)
	words.TextXAlignment = Enum.TextXAlignment.Left
	words.TextScaled = true -- (only smaller for long words: "Key ×3" stays this size, not the cell's height)
	local cap = Instance.new("UITextSizeConstraint")
	cap.MaxTextSize, cap.MinTextSize = CELL_TEXT_MAX, CELL_TEXT_MIN
	cap.Parent = words
	local size, pos = UDim2.fromOffset(CLAIM_WIDTH, 28), UDim2.new(1, -CLAIM_WIDTH - 4, 0.5, -14)
	if info.Taken then
		label(c, "✔ 받음", size, pos, 12).TextColor3 = COLOR_DONE
	elseif info.Ready then
		local b = button(c, "받기", COLOR_READY, size, pos)
		b.TextSize = 13
		b.Activated:Connect(function()
			Net.request("ClaimSeason", track, tier)
		end)
	elseif track == "Paid" and not premium then
		label(c, "💎", size, pos, 16)
	else
		label(c, "🔒", size, pos, 14).TextColor3 = COLOR_WAIT
	end
end

local passShown = nil
Prices.onChanged(function()
	if passShown then
		buy.Text = string.format("💎 패스 %d R$", Prices.get(Config.Monetization.ProductIds.SeasonPass, false, passShown))
	end
end)

local function rebuild(scrollToTier)
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
	if not data then
		return
	end
	if data.Id < 1 then
		title.Text = "🏆 시즌 패스"
		levelLine.Text = string.format("첫 시즌까지 %d일!", data.DaysLeft)
		barFill.Size = UDim2.fromScale(0, 1)
		claimAll.Visible, buy.Visible = false, false
		return
	end
	title.Text = string.format("🏆 시즌 %d · %s", data.Id, data.Theme)
	if not window:FindFirstChild("Backdrop") and not backdropAsked then -- the season theme's dino, faint behind
		backdropAsked = true
		DinoPortrait.backdrop(window, C.Themes[data.ThemeIndex].Dino)
	end
	local top = data.Tier >= C.Tiers
	levelLine.Text = top and string.format("⭐ Lv %d/%d 끝! · ⏰ %d일", data.Tier, C.Tiers, data.DaysLeft)
		or string.format("⭐ Lv %d/%d · ⏰ %d일", data.Tier, C.Tiers, data.DaysLeft)
	barFill.Size = UDim2.fromScale(top and 1 or data.Into / math.max(data.Need, 1), 1)
	local ready = player:GetAttribute("SeasonReady") or 0
	claimAll.Visible = ready > 0
	buy.Visible = not data.Restricted
	passShown = not data.Premium and data.PassRobux or nil
	buy.Text = data.Premium and "✅ 패스 있음"
		or string.format("💎 패스 %d R$", Prices.get(Config.Monetization.ProductIds.SeasonPass, false, data.PassRobux))
	buy.BackgroundColor3 = data.Premium and COLOR_WAIT or COLOR_BUY
	buy.AutoButtonColor = not data.Premium
	local waiting = 0
	for _, t in ipairs(data.Tiers) do
		if not data.Premium and t.Tier <= data.Tier and not t.Paid.Taken then
			waiting += 1
		end
	end
	paidHead.Text = waiting > 0 and not data.Restricted and string.format("💎 시즌 패스 · 🎁 %d개 바로", waiting) or "💎 시즌 패스"
	for _, t in ipairs(data.Tiers) do
		local row = Instance.new("Frame")
		row.LayoutOrder = t.Tier
		row.Size = UDim2.new(1, -8, 0, ROW_HEIGHT)
		row.BackgroundTransparency = 1
		row.Parent = list
		local reached = t.Tier <= data.Tier
		local lv = label(row, string.format("Lv\n%d", t.Tier), UDim2.new(0, LEVEL_WIDTH, 1, 0), UDim2.new(), 13)
		lv.BackgroundTransparency = 0
		lv.BackgroundColor3 = reached and COLOR_REACHED or COLOR_ROW
		lv.TextColor3 = reached and COLOR_BG or COLOR_SOFT
		corner(lv, 8)
		cell(row, LEVEL_WIDTH + CELL_GAP, "Free", t.Tier, t.Free, data.Premium)
		cell(row, LEVEL_WIDTH + 2 * CELL_GAP + cellWidth, "Paid", t.Tier, t.Paid, data.Premium)
	end
	if scrollToTier then -- (the level reached near the top)
		list.CanvasPosition = Vector2.new(0, math.max(0, scrollToTier - 2) * (ROW_HEIGHT + 5))
	end
end

local function reload(scroll)
	local answer = Net.ask("GetSeason")
	if answer then
		data = answer
	end
	rebuild(scroll and data and data.Tier or nil)
end

open.Activated:Connect(function()
	window.Visible = not window.Visible
	if window.Visible then
		reload(true)
	end
end)
claimAll.Activated:Connect(function()
	Net.request("ClaimSeason", "All", 0)
end)
buy.Activated:Connect(function()
	if not data or data.Premium or data.Restricted or ReplicatedStorage:GetAttribute("TutorialField") then
		return -- (2026-10-03: nothing is bought on the practice field)
	end
	local id = Config.Monetization.ProductIds.SeasonPass or 0
	if id > 0 then
		MarketplaceService:PromptProductPurchase(player, id)
	elseif RunService:IsStudio() then
		Net.request("StudioBuy", "SeasonPass") -- (no id yet: Studio grants it to test)
	end
end)
player:GetAttributeChangedSignal("SeasonVersion"):Connect(function()
	if window.Visible then
		reload(false)
	end
end)
Windows.register(window)
