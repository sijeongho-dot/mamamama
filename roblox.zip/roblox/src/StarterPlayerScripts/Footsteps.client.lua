--[[
Footsteps: "자박자박" steps for every walking character near the camera (display only).

A step sounds each time a character on the ground has walked STRIDE studs (so faster walkers, speed
pads included, step faster), from its feet, a little different in pitch and loudness every time
(Shared/Sfx "Footstep", made by tools/make_sounds.py). Flying from a slap, jumping or standing still:
no steps. Once the Footstep sound is uploaded, Roblox's own running sound is turned down on this
screen so the two do not play together; until then Roblox's own stays. Riding a dino, neither: the dino's
own steps (or wingbeats) and the wind instead (Shared/DinoMotion, Ride.client) — but a flying mount walking on the
ground (it makes no steps of its own) steps like a person (2026-10-04, "익룡 타고 걸어다닐땐 사람 발자국소리나고").
Up in the air, none (2026-10-04, "익룡 타고 나는데 왜 발자국 소리가 나냐고": the flier hovers its rider on PlatformStand,
and Roblox's own running sound, left playing from the ground, went on while flying; whether the flier is down on the
ground is the player attribute RideAirborne, set on this screen by Ride.client).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local Workspace = game:GetService("Workspace")

local Sfx = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Sfx"))

-- display only
local STRIDE = 4.6 -- studs walked per step
local MIN_SPEED = 2 -- studs per second: slower than this is standing
local HEARD_WITHIN = 70 -- studs from the camera
local PITCH_MIN, PITCH_MAX = 0.88, 1.12
local FEET = 2.8 -- studs from the root part down to the feet
-- (2026-10-03, "내 발소리 아직 작은데": at 0.9 they were still faint, played from the feet a dozen studs below the
-- camera, fading with the distance) my own steps are heard as they are (not from a spot in the world), louder;
-- the others' from their feet, a little louder too
local MY_GAIN = 2 -- × Footstep's volume (Shared/Sfx)
local OTHER_GAIN = 1.4
-- (2026-10-04, "사람익룡발소리 … 조금 올려도 될듯") walking on a flying mount: a little louder (the wingbeats go over it)
local RIDER_GAIN = 1.3 -- × the gains above
-- until our Footstep is uploaded Roblox's own running sound is the step: louder than its own 0.65 or so
local STANDIN_RUNNING_VOLUME = 1.6

local walked = setmetatable({}, { __mode = "k" }) -- [character] = studs since its last step

local rng = Random.new()

local player = Players.LocalPlayer

-- riding a flying dino that is down on the ground now (Ride.client's RideAirborne; unknown yet: not)
local function flierOnGround(p)
	return p:GetAttribute("Flying") == true and p:GetAttribute("RideAirborne") == false
end

RunService.Heartbeat:Connect(FrameMeter.wrap("Footsteps", function(dt)
	if not Sfx.hasOwn("Footstep") then -- nothing of ours to play yet: Roblox's own running sound does it, louder
		for _, p in ipairs(Players:GetPlayers()) do
			local root = p.Character and p.Character:FindFirstChild("HumanoidRootPart")
			local running = root and root:FindFirstChild("Running")
			-- (2026-10-03, "탈것 타는 중에 소리가 다 그냥 발소리잖아": riding, Roblox's running sound went on at 1.6 over
			-- the dino's own steps and wings) riding a dino: no person's steps at all, the dino's own (Shared/DinoMotion)
			local riding = p:GetAttribute("Riding")
			-- (2026-10-04, "트레드밀 아직도 발소리 너무 커": Roblox's running sound at 1.6 went on under the treadmill's own
			-- soft steps, TrainingFx) training at a station: none
			local want = ((riding and not flierOnGround(p)) or p:GetAttribute("TrainStation")) and 0
				or STANDIN_RUNNING_VOLUME * (riding and RIDER_GAIN or 1)
			if running and running:IsA("Sound") and running.Volume ~= want then
				running.Volume = want
			end
		end
		return
	end
	local camera = Workspace.CurrentCamera
	local eye = camera and camera.CFrame.Position or Vector3.zero
	for _, p in ipairs(Players:GetPlayers()) do
		local character = p.Character
		local humanoid = character and character:FindFirstChildOfClass("Humanoid")
		local root = character and character:FindFirstChild("HumanoidRootPart")
		local running = root and root:FindFirstChild("Running") -- Roblox's own (RbxCharacterSounds): ours instead
		if running and running:IsA("Sound") and running.Volume > 0 then
			running.Volume = 0
		end
		-- (2026-10-03) riding a dino: its own feet thud instead (Shared/DinoMotion)
		-- (2026-10-04) a flying mount walking on the ground steps like a person (it has no steps of its own)
		-- (a flier hovers its rider on PlatformStand, off the floor: down on the ground is RideAirborne false)
		local onFlier = p:GetAttribute("Riding") and flierOnGround(p)
		local stepsAllowed = (not p:GetAttribute("Riding") or onFlier) and not p:GetAttribute("TrainStation") -- (training: TrainingFx's)
		if humanoid and root and humanoid.Health > 0 and stepsAllowed
			and (onFlier or (not humanoid.PlatformStand and humanoid.FloorMaterial ~= Enum.Material.Air))
			and (root.Position - eye).Magnitude <= HEARD_WITHIN then
			local v = root.AssemblyLinearVelocity
			local speed = Vector3.new(v.X, 0, v.Z).Magnitude
			if speed >= MIN_SPEED then
				local d = (walked[character] or 0) + speed * dt
				if d >= STRIDE then
					d -= STRIDE
					local rider = p:GetAttribute("Riding") and RIDER_GAIN or 1
					if p == player then
						Sfx.play("Footstep", nil, rng:NextNumber(PITCH_MIN, PITCH_MAX), MY_GAIN * rider)
					else
						Sfx.play("Footstep", root.Position - Vector3.new(0, FEET, 0), rng:NextNumber(PITCH_MIN, PITCH_MAX),
							OTHER_GAIN * rider)
					end
				end
				walked[character] = d
			else
				walked[character] = STRIDE * 0.6 -- the first step comes soon after starting to walk
			end
		end
	end
end))
