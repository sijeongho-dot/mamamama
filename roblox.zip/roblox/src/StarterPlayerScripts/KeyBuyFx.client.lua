local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Fx = require(Shared:WaitForChild("Fx"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))

local player = Players.LocalPlayer

local DISPLAY_ORDER = 26
local CARD_SIZE = UDim2.fromOffset(330, 132)
local CARD_POS = UDim2.fromScale(0.5, 0.34)
local KEY_SIZE = 112
local TEXT_LEFT = KEY_SIZE + 20
local POP_FROM = 0.35
local POP_SECONDS = 0.4
local STAY_SECONDS = 1.7
local OUT_SECONDS = 0.3
local FLY_MAX = 8
local FLY_SECONDS = 0.65
local FLY_GAP = 0.07
local FLY_SIZE = 36
local FLY_END = 0.5
local COUNTER_AT = Vector2.new(0.85, 0.5)
local BURST_COLORS = { Color3.fromRGB(255, 220, 90), Color3.fromRGB(255, 250, 200), Color3.fromRGB(255, 170, 60) }
local BURST_UP = 3
local BG_COLOR = Color3.fromRGB(45, 34, 16)
local EDGE_COLOR = Color3.fromRGB(255, 205, 80)
local BIG_COLOR = Color3.fromRGB(255, 228, 110)
local LINE_COLOR = Color3.fromRGB(255, 255, 255)
local EDGE_THICKNESS = 3
local SHINE_SECONDS = 0.9

local gui = Instance.new("ScreenGui")
gui.Name = "KeyBuyFx"
gui.ResetOnSpawn = false
gui.DisplayOrder = DISPLAY_ORDER
gui.Parent = player:WaitForChild("PlayerGui")

local showing = nil

local function text(parent, value, size, position, color, font)
	local label = Instance.new("TextLabel")
	label.BackgroundTransparency = 1
	label.Size = size
	label.Position = position
	label.Font = font or Enum.Font.GothamBold
	label.TextScaled = true
	label.TextColor3 = color
	label.TextStrokeTransparency = 0.3
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Text = value
	label.Parent = parent
	return label
end

local function counterSpot()
	local barGui = player.PlayerGui:FindFirstChild("BagBar")
	local bar = barGui and barGui:FindFirstChildWhichIsA("Frame")
	if not bar or not bar.Visible then
		return nil
	end
	return bar.AbsolutePosition + bar.AbsoluteSize * COUNTER_AT
end

local function fly(from, count)
	local to = counterSpot()
	if not to then
		return
	end
	local n = math.min(count, FLY_MAX)
	for i = 1, n do
		task.delay((i - 1) * FLY_GAP, function()
			local icon = Instance.new("TextLabel")
			icon.BackgroundTransparency = 1
			icon.AnchorPoint = Vector2.new(0.5, 0.5)
			icon.Size = UDim2.fromOffset(FLY_SIZE, FLY_SIZE)
			icon.Position = UDim2.fromOffset(from.X, from.Y)
			icon.TextScaled = true
			icon.Text = "🔑"
			icon.Parent = gui
			local tween = TweenService:Create(icon, TweenInfo.new(FLY_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				Position = UDim2.fromOffset(to.X, to.Y),
				Size = UDim2.fromOffset(FLY_SIZE * FLY_END, FLY_SIZE * FLY_END),
				Rotation = 360,
			})
			tween.Completed:Connect(function()
				icon:Destroy()
				if i == n then
					Sfx.play("Deposit")
				end
			end)
			tween:Play()
		end)
	end
end

local function show(grade, count, total, line)
	if showing then
		showing:Destroy()
	end
	local t = Formulas.keyType(grade)
	local card = Instance.new("Frame")
	card.AnchorPoint = Vector2.new(0.5, 0.5)
	card.Size = CARD_SIZE
	card.Position = CARD_POS
	card.BackgroundColor3 = BG_COLOR
	card.BackgroundTransparency = 0.1
	card.Parent = gui
	showing = card
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 16)
	round.Parent = card
	local edge = Instance.new("UIStroke")
	edge.Color = EDGE_COLOR
	edge.Thickness = EDGE_THICKNESS
	edge.Parent = card
	local shine = Instance.new("UIGradient")
	shine.Color = ColorSequence.new(EDGE_COLOR, Color3.new(1, 1, 1))
	shine.Rotation = 0
	shine.Parent = edge
	local scale = Instance.new("UIScale")
	scale.Scale = POP_FROM
	scale.Parent = card
	local key = DinoPortrait.key(grade, UDim2.fromOffset(KEY_SIZE, KEY_SIZE))
	key.AnchorPoint = Vector2.new(0, 0.5)
	key.Position = UDim2.new(0, 10, 0.5, 0)
	key.Parent = card
	text(card, string.format("🔑 +%d", count), UDim2.new(1, -TEXT_LEFT - 10, 0.46, 0), UDim2.fromOffset(TEXT_LEFT, 8), BIG_COLOR,
		Enum.Font.GothamBlack)
	text(card, line or string.format("%s %d개 샀어요!", t and t.Name or "🔑", count), UDim2.new(1, -TEXT_LEFT - 10, 0.22, 0),
		UDim2.new(0, TEXT_LEFT, 0.5, 2), LINE_COLOR)
	text(card, string.format("🎰 이제 %s번 뽑을 수 있어요", Formulas.shortNumber(total)), UDim2.new(1, -TEXT_LEFT - 10, 0.2, 0),
		UDim2.new(0, TEXT_LEFT, 0.74, 0), LINE_COLOR)
	TweenService:Create(scale, TweenInfo.new(POP_SECONDS, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
	TweenService:Create(shine, TweenInfo.new(SHINE_SECONDS, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, -1),
		{ Rotation = 360 }):Play()
	Sfx.play("SpecialKey")
	Sfx.play("KeysHome")
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if root then
		Fx.burst(root.Position + Vector3.new(0, BURST_UP, 0), BURST_COLORS, 36, 16, 0.6, 0.9)
	end
	task.delay(STAY_SECONDS, function()
		if not card.Parent then
			return
		end
		fly(card.AbsolutePosition + card.AbsoluteSize / 2, count)
		local out = TweenService:Create(scale, TweenInfo.new(OUT_SECONDS, Enum.EasingStyle.Back, Enum.EasingDirection.In), { Scale = 0 })
		out.Completed:Connect(function()
			card:Destroy()
			if showing == card then
				showing = nil
			end
		end)
		out:Play()
	end)
end

Net.onPush("KeysBought", function(grade, count, total)
	if type(grade) == "string" and type(count) == "number" and type(total) == "number" then
		show(grade, count, total)
	end
end)

Net.onPush("KeysTraded", function(from, used, to, made, total)
	local a, b = Formulas.keyType(from), Formulas.keyType(to)
	if a and b and type(used) == "number" and type(made) == "number" and type(total) == "number" then
		show(to, made, total, string.format("%s %d개 → %s %d개로 교환했어요!", a.Name, used, b.Name, made))
	end
end)
