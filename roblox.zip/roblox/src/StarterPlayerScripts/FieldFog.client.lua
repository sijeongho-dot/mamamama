local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Unlock = require(Shared:WaitForChild("Unlock"))

local player = Players.LocalPlayer

local WALL_HEIGHT = 220
local FADE_HEIGHT = 60
local WALL_THICK = 3
local SEGMENT_LENGTH = 36
local WALL_COLOR = Color3.fromRGB(28, 32, 50)
local WALL_SEE_THROUGH = 0.04
local FADE_SEE_THROUGH = 0.55
local BAND_COLOR = Color3.fromRGB(255, 205, 90)
local READY_BAND_COLOR = Color3.fromRGB(120, 255, 150)
local BAND_HEIGHT = 1.2
local BAND_UP = 8
local SIGN_SIZE = UDim2.fromScale(46, 13)
local SIGN_UP = 24
local SIGN_OUT = 6
local SIGN_DISTANCE = 420
local TITLE_COLOR = Color3.fromRGB(255, 215, 100)
local READY_COLOR = Color3.fromRGB(140, 255, 160)
local LINE_COLOR = Color3.fromRGB(235, 240, 255)
local OPEN_SECONDS = 2.2

local folder = Instance.new("Folder")
folder.Name = "FieldFog"
folder.Parent = Workspace

local ring = nil

local function part(props)
	local p = Instance.new("Part")
	p.Anchored, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false
	p.Material = Enum.Material.SmoothPlastic
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	for k, v in pairs(props) do
		p[k] = v
	end
	return p
end

local function baseOut()
	local map = Workspace:FindFirstChild("Map")
	local base = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	local zone = base and base:FindFirstChild("SafeZone")
	local flat = zone and Vector3.new(zone.Position.X, 0, zone.Position.Z)
	return flat and flat.Magnitude > 1e-3 and flat.Unit or nil
end

local function signText(u)
	if Unlock.ready(u.Id) then
		return string.format("🔓 %s", u.Name), "👉 여기로 오면 열려요!", READY_COLOR
	end
	return string.format("🔒 %s", u.Name), Unlock.whyText(u), TITLE_COLOR
end

local function isNext(u)
	local nextOne = Unlock.nextOne()
	return nextOne ~= nil and u ~= nil and nextOne.Id == u.Id
end

local function makeSign(model, from, u)
	local out = baseOut()
	if not out or not u then
		return
	end
	local at = out * (from + SIGN_OUT)
	local holder = part({ Name = "Sign", Size = Vector3.one, Transparency = 1, CanCollide = false,
		CFrame = CFrame.new(at.X, SIGN_UP, at.Z) })
	holder.Parent = model
	local gui = Instance.new("BillboardGui")
	gui.Size = SIGN_SIZE
	gui.MaxDistance = SIGN_DISTANCE
	gui.LightInfluence = 0
	gui.Adornee = holder
	local function line(top, share, color)
		local l = Instance.new("TextLabel")
		l.BackgroundTransparency = 1
		l.Position = UDim2.fromScale(0, top)
		l.Size = UDim2.fromScale(1, share)
		l.Font = Enum.Font.GothamBlack
		l.TextScaled = true
		l.TextColor3 = color
		l.TextStrokeTransparency = 0.15
		l.Parent = gui
		return l
	end
	local title, why = line(0, 0.56, TITLE_COLOR), line(0.6, 0.4, LINE_COLOR)
	gui.Parent = holder
	local function refresh()
		local a, b, color = signText(u)
		title.Text, why.Text, title.TextColor3 = a, b, color
		gui.Enabled = isNext(u)
	end
	refresh()
	return refresh
end

local function build(from)
	local model = Instance.new("Model")
	model.Name = "Fog"
	local u = Formulas.zoneUnlockAt(from)
	local ready = u ~= nil and Unlock.ready(u.Id)
	local n = math.max(12, math.ceil(2 * math.pi * from / SEGMENT_LENGTH))
	local width = 2 * math.pi * from / n + 1
	for i = 1, n do
		local a = (i - 0.5) / n * 2 * math.pi
		local dir = Vector3.new(math.cos(a), 0, math.sin(a))
		local at = dir * (from + WALL_THICK / 2)
		local face = CFrame.lookAt(at, at + dir)
		part({ Name = "Wall", Size = Vector3.new(width, WALL_HEIGHT, WALL_THICK), Color = WALL_COLOR,
			Transparency = WALL_SEE_THROUGH, CanCollide = true, CFrame = face * CFrame.new(0, WALL_HEIGHT / 2 - 10, 0) }).Parent = model
		part({ Name = "Fade", Size = Vector3.new(width, FADE_HEIGHT, WALL_THICK), Color = WALL_COLOR,
			Transparency = FADE_SEE_THROUGH, CanCollide = false, CFrame = face * CFrame.new(0, WALL_HEIGHT - 10 + FADE_HEIGHT / 2, 0) }).Parent = model
		local band = part({ Name = "Band", Size = Vector3.new(width, BAND_HEIGHT, WALL_THICK + 0.4), Color = ready and READY_BAND_COLOR
			or BAND_COLOR, Material = Enum.Material.Neon, CanCollide = false, CFrame = face * CFrame.new(0, BAND_UP, 0) })
		band.Parent = model
	end
	local refresh = makeSign(model, from, u)
	model.Parent = folder
	return { model = model, from = from, refresh = refresh, ready = ready, unlock = u }
end

local function dissolve(r)
	local model = r.model
	model.Name = "FogOpening"
	for _, p in ipairs(model:GetDescendants()) do
		if p:IsA("BasePart") then
			p.CanCollide = false
			TweenService:Create(p, TweenInfo.new(OPEN_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				Transparency = 1, CFrame = p.CFrame - Vector3.new(0, WALL_HEIGHT * 0.6, 0) }):Play()
		elseif p:IsA("BillboardGui") then
			p.Enabled = false
		end
	end
	task.delay(OPEN_SECONDS, function()
		model:Destroy()
	end)
end

local function refresh()
	local from = player:GetAttribute("FieldOpen")
	if type(from) ~= "number" then
		return
	end
	local u = Formulas.zoneUnlockAt(from)
	local ready = u ~= nil and Unlock.ready(u.Id)
	if ring and ring.from == from and ring.ready == ready then
		if ring.refresh then
			ring.refresh()
		end
		return
	end
	local opening = ring ~= nil and from < ring.from
	if ring then
		if opening then
			dissolve(ring)
		else
			ring.model:Destroy()
		end
		ring = nil
	end
	if from > 0 then
		ring = build(from)
	end
end

Unlock.watch(refresh)
player:GetAttributeChangedSignal("Base"):Connect(refresh)
refresh()
