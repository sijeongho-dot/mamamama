--[[
Climb: climbing trees (2026-10-04, "유저가 나무위 등반해서 숨으니까 재밌네. 기본적으로 나무위 등반할 수있게 하자";
Config.Climb, the trees made climbable: ServerScriptService/Services/TreeClimb).

- Walking into a tree's trunk (a part named TrunkCollider or Trunk) with my own stick or keys for PushSeconds starts
  the climb (brushing past, or the auto-mining's walk, doesn't): straight up at Config.Climb.Speed, held against the
  trunk, the character's own climb animation playing.
- At the trunk's top (its highest end, or a palm's ClimbTop disc) a short hop onto it (HopSeconds): standing in the
  leaves, hidden.
- Jumping lets go (a little push away from the trunk), so does letting go of the stick or turning away. Not while
  riding, racing or sitting.
- MoveGuard (server) leaves a climber beside a trunk alone (TreeClimb.nearTrunk).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))

local player = Players.LocalPlayer
local C = Config.Climb

-- display only
local HUG_SPEED = 3 -- studs a second pulled into the trunk while climbing (it stays touching)
local LET_GO_PUSH = 10 -- studs a second away from the trunk on a jump off it
local INTO = 0.5 -- how straight into the trunk the stick must point (dot of the move and the way in)
local CLIMB_ANIM_SPEED = 1.4

local TRUNK_NAMES = { TrunkCollider = true, Trunk = true }

local ray = RaycastParams.new()
ray.FilterType = Enum.RaycastFilterType.Exclude

local controls = nil -- the PlayerModule's ControlModule: my own stick or keys (as TrainingFx)
local function pushing()
	if not controls then
		pcall(function()
			local module = player:FindFirstChild("PlayerScripts") and player.PlayerScripts:FindFirstChild("PlayerModule")
			controls = module and require(module):GetControls()
		end)
	end
	local ok, v = pcall(function()
		return controls and controls:GetMoveVector()
	end)
	return ok and v ~= nil and v.Magnitude > 0.1
end

local function flat(v)
	return Vector3.new(v.X, 0, v.Z)
end

-- the top of a tree's trunk: a palm's disc, else the highest end of its trunk parts
local tops = setmetatable({}, { __mode = "k" })
local function topOf(model)
	if tops[model] then
		return tops[model]
	end
	local disc = model:FindFirstChild("ClimbTop")
	local best = nil
	if disc and disc:IsA("BasePart") then
		best = disc.Position + Vector3.new(0, disc.Size.X / 2, 0)
	else
		for _, p in ipairs(model:GetChildren()) do
			if p:IsA("BasePart") and TRUNK_NAMES[p.Name] then
				for _, side in ipairs({ -1, 1 }) do -- (a cylinder's length is along its X)
					local e = p.CFrame * Vector3.new(side * p.Size.X / 2, 0, 0)
					if not best or e.Y > best.Y then
						best = e
					end
				end
			end
		end
	end
	tops[model] = best
	return best
end

local climbing = nil -- { model, axis (a point on the trunk), top }
local pushSince, pushModel = nil, nil
local hopping = false
local track, trackFor = nil, nil

local function climbTrack(character, humanoid)
	if trackFor == character then
		return track
	end
	trackFor, track = character, nil
	local animate = character:FindFirstChild("Animate")
	local holder = animate and animate:FindFirstChild("climb")
	local anim = holder and holder:FindFirstChildWhichIsA("Animation")
	local animator = humanoid:FindFirstChildOfClass("Animator")
	if anim and animator then
		pcall(function()
			track = animator:LoadAnimation(anim)
			track.Priority = Enum.AnimationPriority.Action
			track.Looped = true
		end)
	end
	return track
end

local function stop()
	climbing = nil
	if track and track.IsPlaying then
		track:Stop(0.15)
	end
end

local function hop(root, humanoid, top)
	stop()
	hopping = true
	local stand = humanoid.HipHeight + root.Size.Y / 2 + 0.1
	local from = root.CFrame
	local look = flat(from.LookVector)
	local at = top + Vector3.new(0, stand, 0)
	local to = CFrame.lookAt(at, at + (look.Magnitude > 1e-3 and look.Unit or Vector3.new(0, 0, -1)))
	local started = os.clock()
	task.spawn(function()
		while root.Parent and os.clock() - started < C.HopSeconds do
			root.CFrame = from:Lerp(to, (os.clock() - started) / C.HopSeconds)
			root.AssemblyLinearVelocity = Vector3.zero
			RunService.Heartbeat:Wait()
		end
		if root.Parent then
			root.CFrame = to
			root.AssemblyLinearVelocity = Vector3.zero
		end
		hopping = false
	end)
end

RunService.Heartbeat:Connect(FrameMeter.wrap("Climb", function()
	if hopping then
		return
	end
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not root or not humanoid or humanoid.Health <= 0 or humanoid.Sit or player:GetAttribute("Riding")
		or player:GetAttribute("Racing") then
		pushSince = nil
		if climbing then
			stop()
		end
		return
	end
	ray.FilterDescendantsInstances = { character }
	local move = flat(humanoid.MoveDirection)
	local reach = root.Size.X / 2 + C.Reach
	if climbing then
		local inward = flat(climbing.axis - root.Position)
		inward = inward.Magnitude > 1e-3 and inward.Unit or flat(root.CFrame.LookVector).Unit
		if humanoid.Jump then -- let go: a little push off the trunk
			stop()
			root.AssemblyLinearVelocity = -inward * LET_GO_PUSH + Vector3.new(0, C.Speed * 0.5, 0)
			return
		end
		if not pushing() or move.Magnitude < 0.1 or move.Unit:Dot(inward) < INTO * 0.5 then
			stop()
			return
		end
		local dist = flat(climbing.axis - root.Position).Magnitude
		local hit = Workspace:Raycast(root.Position, inward * (dist + 1), ray)
		local part = hit and hit.Instance
		if part and TRUNK_NAMES[part.Name] and part.Parent == climbing.model then
			climbing.axis = part.Position -- (a palm's next piece up)
		elseif root.Position.Y < climbing.top.Y then
			stop() -- (off the trunk somehow)
			return
		end
		if root.Position.Y >= climbing.top.Y then
			hop(root, humanoid, climbing.top)
			return
		end
		root.AssemblyLinearVelocity = Vector3.new(0, C.Speed, 0) + inward * HUG_SPEED
		return
	end
	-- not climbing: pushing into a trunk for PushSeconds?
	if not pushing() or move.Magnitude < 0.1 then
		pushSince = nil
		return
	end
	local hit = Workspace:Raycast(root.Position, move.Unit * reach, ray)
	local part = hit and hit.Instance
	local model = part and TRUNK_NAMES[part.Name] and part.Parent
	local top = model and topOf(model)
	local facing = hit and flat(hit.Normal)
	if not top or top.Y <= root.Position.Y or facing.Magnitude < 0.3 or move.Unit:Dot(-facing.Unit) < INTO then
		pushSince = nil
		return
	end
	if pushModel ~= model or not pushSince then
		pushSince, pushModel = os.clock(), model
		return
	end
	if os.clock() - pushSince >= C.PushSeconds then
		pushSince = nil
		climbing = { model = model, axis = part.Position, top = top }
		local t = climbTrack(character, humanoid)
		if t then
			t:Play(0.1)
			t:AdjustSpeed(CLIMB_ANIM_SPEED)
		end
	end
end))

player.CharacterAdded:Connect(function()
	climbing, pushSince, hopping = nil, nil, false
end)
