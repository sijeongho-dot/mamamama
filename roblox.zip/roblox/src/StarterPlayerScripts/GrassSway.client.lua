--[[
GrassSway (2026-10-02, "풀은 밟고 지나갈때 흔들리게 하자. 공룡이나 몬스터들이 밟고 지나가도 흔들리게 해도 되나?"):
the grass bends away from whatever walks through it and springs back with a little wobble, on this screen
only (display; the grass never collides and the server never sees this).

The grass: every tuft (a Model) in Map.FieldGrass (the battlefield), Map.SafeGrass (the safe land) and the
bases' FarmGrass (the farm pens), kept in a grid of CELL studs. Tufts coming and going (streaming, a pen
replanted) are picked up.
What bends it: every player's character, the wild dinos (Workspace.Wildlife), the zombies
(Workspace.ZombieModels) and the farm dinos (each base's FarmUnits), within NEAR_CAMERA studs of the camera.
A tuft within a walker's reach (its own half width + REACH) and at its feet leans away from it, more the
closer it is (up to MAX_TILT degrees); left alone it swings back on a spring (STIFFNESS, DAMPING).
]]

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local Workspace = game:GetService("Workspace")

-- display only
local CELL = 12 -- studs: the grid the tufts are kept in
local MAX_TILT = math.rad(55) -- the most a tuft leans
local REACH = 1.8 -- studs past a walker's own half width that still bend grass
local CHARACTER_HALF = 1.2 -- a player's half width
local CHARACTER_FEET = 3 -- studs from a character's root down to its feet
local FEET_SLACK = 2.5 -- studs: a walker's feet this far over a tuft's top (or under its base) miss it
local NEAR_CAMERA = 140 -- studs: walkers farther from the camera bend nothing (nobody sees it)
local STIFFNESS = 60 -- the spring back
local DAMPING = 7
local REST_EPSILON = 0.004 -- radians: settled
local RESCAN_SECONDS = 3 -- the walkers' lists and new grass folders looked for again this often
local TUFTS_PER_FRAME = 150
-- (2026-10-02, "혼자하는데 렉이 좀 있는거 같은데 최적화 해봐 8인기준으로": every wild, zombie and farm dino of all eight
-- bases was looked at every frame) the dinos near the camera are listed this often; only those are followed each frame
local NEAR_LIST_EVERY = 0.25
local NEAR_LIST_SLACK = 40 -- studs past NEAR_CAMERA still listed (they may come closer before the next listing)

local cells = {} -- ["x,z"] = { tuft, ... }
local tufts = {} -- [model] = { model, rest, base, top, cellKey, angle, speed, axis, push, pushAxis }
local active = {} -- [tuft] = true while bent or swinging

local function cellKey(x, z)
	return math.floor(x / CELL) .. "," .. math.floor(z / CELL)
end

local function addTuft(model)
	if tufts[model] or not model:IsA("Model") then
		return
	end
	local ok, cf, size = pcall(function()
		return model:GetBoundingBox()
	end)
	if not ok or not cf then
		return
	end
	local rest = model:GetPivot()
	local base = Vector3.new(cf.Position.X, cf.Position.Y - size.Y / 2, cf.Position.Z)
	local key = cellKey(base.X, base.Z)
	local t = { model = model, rest = rest, base = base, top = base.Y + size.Y, key = key, angle = 0, speed = 0,
		axis = Vector3.xAxis, push = 0, pushAxis = Vector3.xAxis }
	tufts[model] = t
	cells[key] = cells[key] or {}
	table.insert(cells[key], t)
end

local function removeTuft(model)
	local t = tufts[model]
	if not t then
		return
	end
	tufts[model] = nil
	active[t] = nil
	local list = cells[t.key]
	if list then
		local i = table.find(list, t)
		if i then
			table.remove(list, i)
		end
	end
end

local watched = {} -- [folder] = true
local function watchFolder(folder)
	if watched[folder] then
		return
	end
	watched[folder] = true
	task.spawn(function()
		for i, m in ipairs(folder:GetChildren()) do
			addTuft(m)
			if i % TUFTS_PER_FRAME == 0 then
				task.wait()
			end
		end
	end)
	folder.ChildAdded:Connect(function(m)
		task.defer(addTuft, m) -- (its parts may arrive a moment later)
	end)
	folder.ChildRemoved:Connect(removeTuft)
	folder.AncestryChanged:Connect(function(_, parent)
		if not parent then
			watched[folder] = nil
			for _, m in ipairs(folder:GetChildren()) do
				removeTuft(m)
			end
		end
	end)
end

-- the walkers: { position of the feet, half width } (models' sizes measured once)
local sizes = setmetatable({}, { __mode = "k" }) -- [model] = { down (pivot to feet), half }
local wildFolders, farmFolders = {}, {}
local baseFolders = {} -- [base] = { grass = FarmGrass, units = FarmUnits }: found once (a deep search of a base is slow)
local function rescan()
	local map = Workspace:FindFirstChild("Map")
	if map then
		for _, name in ipairs({ "FieldGrass", "SafeGrass" }) do
			local f = map:FindFirstChild(name)
			if f then
				watchFolder(f)
			end
		end
		table.clear(farmFolders)
		for _, base in ipairs(map:GetChildren()) do
			if string.match(base.Name, "^Base%d+$") then
				local known = baseFolders[base] or {}
				baseFolders[base] = known
				if not (known.grass and known.grass:IsDescendantOf(base)) then
					known.grass = base:FindFirstChild("FarmGrass", true)
				end
				if not (known.units and known.units:IsDescendantOf(base)) then
					known.units = base:FindFirstChild("FarmUnits", true)
				end
				if known.grass then
					watchFolder(known.grass)
				end
				if known.units then
					table.insert(farmFolders, known.units)
				end
			end
		end
	end
	table.clear(wildFolders)
	for _, name in ipairs({ "Wildlife", "ZombieModels" }) do
		local f = Workspace:FindFirstChild(name)
		if f then
			table.insert(wildFolders, f)
		end
	end
end

local function modelWalker(model, list, camPos)
	local pivot = model:GetPivot().Position
	if (pivot - camPos).Magnitude > NEAR_CAMERA then
		return
	end
	local s = sizes[model]
	if not s then
		local ok, cf, size = pcall(function()
			return model:GetBoundingBox()
		end)
		if not ok or not cf then
			return
		end
		s = { down = pivot.Y - (cf.Position.Y - size.Y / 2), half = math.max(size.X, size.Z) / 2 * 0.6 }
		sizes[model] = s
	end
	table.insert(list, { feet = Vector3.new(pivot.X, pivot.Y - s.down, pivot.Z), half = s.half })
end

local nearModels, listedAt = {}, -math.huge -- the dinos near the camera (listed every NEAR_LIST_EVERY)
local function listNear(camPos)
	table.clear(nearModels)
	local within = NEAR_CAMERA + NEAR_LIST_SLACK
	for _, list in ipairs({ wildFolders, farmFolders }) do
		for _, folder in ipairs(list) do
			for _, m in ipairs(folder:GetChildren()) do
				if m:IsA("Model") and (m:GetPivot().Position - camPos).Magnitude <= within then
					table.insert(nearModels, m)
				end
			end
		end
	end
end

local function walkers(camPos)
	local list = {}
	for _, p in ipairs(Players:GetPlayers()) do
		local root = p.Character and p.Character:FindFirstChild("HumanoidRootPart")
		if root and (root.Position - camPos).Magnitude <= NEAR_CAMERA then
			local half = CHARACTER_HALF
			if p:GetAttribute("Riding") then
				half *= 2.5 -- (a mount is wider)
			end
			table.insert(list, { feet = root.Position - Vector3.new(0, CHARACTER_FEET, 0), half = half })
		end
	end
	if os.clock() - listedAt >= NEAR_LIST_EVERY then
		listedAt = os.clock()
		listNear(camPos)
	end
	for _, m in ipairs(nearModels) do
		if m.Parent then
			modelWalker(m, list, camPos)
		end
	end
	return list
end

rescan()
task.spawn(function()
	while true do
		task.wait(RESCAN_SECONDS)
		rescan()
	end
end)

local light = Players.LocalPlayer:GetAttribute("LightMode") == true
Players.LocalPlayer:GetAttributeChangedSignal("LightMode"):Connect(function()
	light = Players.LocalPlayer:GetAttribute("LightMode") == true
end)

RunService.Heartbeat:Connect(FrameMeter.wrap("GrassSway", function(dt)
	local camera = Workspace.CurrentCamera
	if not camera or (light and next(active) == nil) then
		return
	end
	dt = math.min(dt, 1 / 20)
	-- who is pushing what this frame
	for _, w in ipairs(light and {} or walkers(camera.CFrame.Position)) do
		local reach = w.half + REACH
		local x0, x1 = math.floor((w.feet.X - reach) / CELL), math.floor((w.feet.X + reach) / CELL)
		local z0, z1 = math.floor((w.feet.Z - reach) / CELL), math.floor((w.feet.Z + reach) / CELL)
		for cx = x0, x1 do
			for cz = z0, z1 do
				local list = cells[cx .. "," .. cz]
				if list then
					for _, t in ipairs(list) do
						if w.feet.Y <= t.top + FEET_SLACK and w.feet.Y >= t.base.Y - FEET_SLACK then
							local away = Vector3.new(t.base.X - w.feet.X, 0, t.base.Z - w.feet.Z)
							local d = away.Magnitude
							if d < reach then
								local push = MAX_TILT * (1 - d / reach)
								if push > t.push then
									t.push = push
									t.pushAxis = Vector3.yAxis:Cross(d > 0.05 and away.Unit or Vector3.xAxis)
								end
								active[t] = true
							end
						end
					end
				end
			end
		end
	end
	-- springs
	for t in pairs(active) do
		if not t.model.Parent then
			active[t] = nil
		else
			local target = t.push
			if target > 0 then
				t.axis = t.pushAxis
			end
			local force = (target - t.angle) * STIFFNESS - t.speed * DAMPING
			t.speed += force * dt
			t.angle += t.speed * dt
			t.push = 0
			if target == 0 and math.abs(t.angle) < REST_EPSILON and math.abs(t.speed) < REST_EPSILON * 10 then
				t.angle, t.speed = 0, 0
				active[t] = nil
				t.model:PivotTo(t.rest)
			else
				local turn = CFrame.new(t.base) * CFrame.fromAxisAngle(t.axis, t.angle) * CFrame.new(-t.base)
				t.model:PivotTo(turn * t.rest)
			end
		end
	end
end))
