--[[
DefenseMaps: the 🗺️ defense map window (2026-10-06, "환생하면 다른 맵이 생기고, 배치도 바꿔볼 수 있는 전략성";
"아레나 공룡 옆 표지판으로 맵변경도 있게해줘. 들어가면 맵의 모습을 2d로 보여주고 3대4 가로세로 비율로, 아직 선택 못하는 맵이면
잠겨있고 언제부터 열린다고 적혀있는거지"). Display only: the 🗺️ map board beside the arena's board (PlaceBoards, prompt Kind
MapBoard, Net push OpenMaps) opens it. Every map of Config.Defense.Maps
is a 3:4 card: its road seen from above, its name, and a button; a locked one is dimmed with when it opens (its level,
or its rebirths). 🎁 on a card: the first promotion won there gives keys (MapWins). Choosing one sends SetDefenseMap
(the Defense service checks it and moves the dinos: each map keeps its own layout).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(Shared:WaitForChild("Windows"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Coach = require(Shared:WaitForChild("Coach"))

local player = Players.LocalPlayer

local FONT = Enum.Font.GothamBold
local PANEL_SIZE = UDim2.fromOffset(584, 440)
local CARD_SIZE = UDim2.fromOffset(132, 176)
local CARD_GAP = 8
local PICTURE = 120
local FIELD_HALF = 52.5
local FIELD_BACK, FIELD_FRONT = 54, -51
local GATE_DOT = 12
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_CARD = Color3.fromRGB(40, 44, 60)
local COLOR_NOW = Color3.fromRGB(50, 90, 60)
local COLOR_GRASS = Color3.fromRGB(110, 175, 90)
local COLOR_ROAD = Color3.fromRGB(205, 165, 110)
local COLOR_ROAD_EDGE = Color3.fromRGB(245, 235, 210)
local COLOR_POND = Color3.fromRGB(70, 160, 235)
local COLOR_ROCK = Color3.fromRGB(120, 116, 110)
local COLOR_NEST = Color3.fromRGB(255, 216, 74)
local ROCK_DOT = 4
local NEST_DOT = 9
local COLOR_PERCH = Color3.fromRGB(150, 220, 255)
local PERCH_DOT = 9
local COLOR_START = Color3.fromRGB(90, 210, 90)
local COLOR_END = Color3.fromRGB(235, 70, 70)
local COLOR_PICK = Color3.fromRGB(70, 180, 90)
local COLOR_LOCK = Color3.fromRGB(90, 90, 100)
local COLOR_CLOSE = Color3.fromRGB(235, 70, 80)
local COLOR_NOTE = Color3.fromRGB(255, 205, 60)
local COLOR_PRIZE = Color3.fromRGB(255, 215, 90)
local LOCK_SHADE = 0.35
local NOW_STROKE = Color3.fromRGB(120, 255, 140)

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextSize = textSize
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.TextWrapped = true
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local gui = Instance.new("ScreenGui")
gui.Name = "DefenseMaps"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(0.5, 0.5)
panel.Position = UDim2.fromScale(0.5, 0.5)
panel.Size = PANEL_SIZE
panel.BackgroundColor3 = COLOR_BG
panel.Visible = false
panel.Parent = gui
corner(panel, 14)
Windows.fit(panel)

label(panel, "🗺️ 디펜스 맵", UDim2.new(1, -60, 0, 34), UDim2.fromOffset(14, 6), 20)
local close = Instance.new("TextButton")
close.Size = UDim2.fromOffset(34, 34)
close.Position = UDim2.new(1, -42, 0, 8)
close.BackgroundColor3 = COLOR_CLOSE
close.Font = FONT
close.TextSize = 18
close.TextColor3 = Color3.new(1, 1, 1)
close.Text = "X"
close.Parent = panel
corner(close, 10)
close.Activated:Connect(function()
	panel.Visible = false
end)
label(panel, "📍 맵마다 배치가 따로 저장돼요 · 처음 가는 맵은 공룡을 알아서 놓아요",
	UDim2.new(1, -28, 0, 30), UDim2.fromOffset(14, 40), 12, COLOR_NOTE)

local list = Instance.new("ScrollingFrame")
list.Position = UDim2.fromOffset(10, 74)
list.Size = UDim2.new(1, -20, 1, -84)
list.BackgroundTransparency = 1
list.ScrollBarThickness = 6
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = panel
local grid = Instance.new("UIGridLayout")
grid.CellSize = CARD_SIZE
grid.CellPadding = UDim2.fromOffset(CARD_GAP, CARD_GAP)
grid.SortOrder = Enum.SortOrder.LayoutOrder
grid.Parent = list

local function toPicture(x, z)
	return (FIELD_HALF - x) / (FIELD_HALF * 2) * PICTURE, (FIELD_BACK - z) / (FIELD_BACK - FIELD_FRONT) * PICTURE
end

local function road(parent, points, width, color)
	for i = 1, #points - 1 do
		local ax, ay = toPicture(points[i][1], points[i][2])
		local bx, by = toPicture(points[i + 1][1], points[i + 1][2])
		local len = math.sqrt((bx - ax) ^ 2 + (by - ay) ^ 2)
		local seg = Instance.new("Frame")
		seg.AnchorPoint = Vector2.new(0.5, 0.5)
		seg.Position = UDim2.fromOffset((ax + bx) / 2, (ay + by) / 2)
		seg.Size = UDim2.fromOffset(len + width, width)
		seg.Rotation = math.deg(math.atan2(by - ay, bx - ax))
		seg.BackgroundColor3 = color
		seg.BorderSizePixel = 0
		seg.Parent = parent
		corner(seg, width / 2)
	end
end

local function dot(parent, point, color)
	local x, y = toPicture(point[1], point[2])
	local d = Instance.new("Frame")
	d.AnchorPoint = Vector2.new(0.5, 0.5)
	d.Position = UDim2.fromOffset(x, y)
	d.Size = UDim2.fromOffset(GATE_DOT, GATE_DOT)
	d.BackgroundColor3 = color
	d.Parent = parent
	corner(d, GATE_DOT / 2)
end

local cards = {}

local function build()
	local roadWidth = Config.Defense.TrackHalfWidth * 2 / (FIELD_HALF * 2) * PICTURE
	for i, map in ipairs(Config.Defense.Maps) do
		local card = Instance.new("Frame")
		card.LayoutOrder = i
		card.BackgroundColor3 = COLOR_CARD
		card.Parent = list
		corner(card, 10)
		local stroke = Instance.new("UIStroke")
		stroke.Color = NOW_STROKE
		stroke.Thickness = 3
		stroke.Enabled = false
		stroke.Parent = card
		local picture = Instance.new("Frame")
		picture.Position = UDim2.fromOffset(6, 6)
		picture.Size = UDim2.fromOffset(PICTURE, PICTURE)
		picture.BackgroundColor3 = COLOR_GRASS
		picture.ClipsDescendants = true
		picture.Parent = card
		corner(picture, 8)
		local pondSize = Config.Defense.Pond.Radius * 2 / (FIELD_HALF * 2) * PICTURE
		for _, p in ipairs(map.Ponds or {}) do
			local px, py = toPicture(p[1], p[2])
			local pond = Instance.new("Frame")
			pond.AnchorPoint = Vector2.new(0.5, 0.5)
			pond.Position = UDim2.fromOffset(px, py)
			pond.Size = UDim2.fromOffset(pondSize, pondSize)
			pond.BackgroundColor3 = COLOR_POND
			pond.Parent = picture
			corner(pond, pondSize / 2)
		end
		for _, n in ipairs(map.Nests or {}) do
			local nx, ny = toPicture(n[1], n[2])
			local nest = Instance.new("Frame")
			nest.AnchorPoint = Vector2.new(0.5, 0.5)
			nest.Position = UDim2.fromOffset(nx, ny)
			nest.Size = UDim2.fromOffset(NEST_DOT, NEST_DOT)
			nest.BackgroundColor3 = COLOR_NEST
			nest.Parent = picture
			corner(nest, NEST_DOT / 2)
		end
		for _, p in ipairs(map.Perches or {}) do
			local px, py = toPicture(p[1], p[2])
			local perch = Instance.new("Frame")
			perch.AnchorPoint = Vector2.new(0.5, 0.5)
			perch.Position = UDim2.fromOffset(px, py)
			perch.Size = UDim2.fromOffset(PERCH_DOT, PERCH_DOT)
			perch.BackgroundColor3 = COLOR_PERCH
			perch.Rotation = 45
			perch.Parent = picture
		end
		local rockSize = math.max(ROCK_DOT, Config.Defense.Rocks.Radius * 2 / (FIELD_HALF * 2) * PICTURE)
		for _, p in ipairs(Formulas.mapRocks(map.Id)) do
			local rx, ry = toPicture(p[1], p[2])
			local rock = Instance.new("Frame")
			rock.AnchorPoint = Vector2.new(0.5, 0.5)
			rock.Position = UDim2.fromOffset(rx, ry)
			rock.Size = UDim2.fromOffset(rockSize, rockSize)
			rock.BackgroundColor3 = COLOR_ROCK
			rock.Parent = picture
			corner(rock, rockSize / 2)
		end
		road(picture, map.Points, roadWidth + 2, COLOR_ROAD_EDGE)
		road(picture, map.Points, roadWidth, COLOR_ROAD)
		dot(picture, map.Points[1], COLOR_START)
		dot(picture, map.Points[#map.Points], COLOR_END)
		local shade = Instance.new("TextLabel")
		shade.Size = UDim2.fromScale(1, 1)
		shade.BackgroundColor3 = Color3.new(0, 0, 0)
		shade.BackgroundTransparency = LOCK_SHADE
		shade.Font = FONT
		shade.TextSize = 34
		shade.Text = "🔒"
		shade.ZIndex = 3
		shade.Parent = picture
		local prize = Instance.new("TextLabel")
		prize.AnchorPoint = Vector2.new(1, 0)
		prize.Position = UDim2.new(1, -3, 0, 3)
		prize.Size = UDim2.fromOffset(52, 18)
		prize.BackgroundColor3 = Color3.new(0, 0, 0)
		prize.BackgroundTransparency = 0.35
		prize.Font = FONT
		prize.TextSize = 12
		prize.TextColor3 = COLOR_PRIZE
		prize.ZIndex = 4
		prize.Parent = picture
		corner(prize, 6)
		local name = label(card, string.format("%s %s", map.Icon, map.Name), UDim2.fromOffset(PICTURE, 18),
			UDim2.fromOffset(6, PICTURE + 8), 14)
		name.TextScaled = true
		local pick = Instance.new("TextButton")
		pick.Position = UDim2.fromOffset(6, PICTURE + 28)
		pick.Size = UDim2.fromOffset(PICTURE, 26)
		pick.Font = FONT
		pick.TextSize = 13
		pick.TextColor3 = Color3.new(1, 1, 1)
		pick.TextScaled = true
		pick.Parent = card
		corner(pick, 8)
		pick.Activated:Connect(function()
			if pick:GetAttribute("Open") then
				Net.request("SetDefenseMap", map.Id)
				panel.Visible = false
			end
		end)
		cards[map.Id] = { card = card, stroke = stroke, shade = shade, prize = prize, pick = pick }
	end
end

local function refresh()
	if not next(cards) then
		build()
	end
	local rebirths = player:GetAttribute("Rebirths") or 0
	local level = player:GetAttribute("DefenseLevel") or 1
	local now = player:GetAttribute("DefenseMap") or Config.Defense.Maps[1].Id
	local won = {}
	for id in string.gmatch(player:GetAttribute("MapWins") or "", "[^,]+") do
		won[id] = true
	end
	for i, map in ipairs(Config.Defense.Maps) do
		local c = cards[map.Id]
		local open = Formulas.mapOpen(map.Id, rebirths, level)
		local here = map.Id == now
		c.card.BackgroundColor3 = here and COLOR_NOW or COLOR_CARD
		c.stroke.Enabled = here
		c.shade.Visible = not open
		local prize = i > 1 and not won[map.Id] and Formulas.mapFirstWin(map)
		c.prize.Visible = prize and true or false
		if prize then
			c.prize.Text = string.format("🎁🔑×%d", prize.Count)
		end
		c.pick:SetAttribute("Open", open and not here)
		Coach.mark(c.pick, open and not here and "MapPick" or nil)
		c.pick.AutoButtonColor = open and not here
		c.pick.BackgroundColor3 = open and not here and COLOR_PICK or COLOR_LOCK
		c.pick.Text = here and "✅ 지금 맵" or open and "▶️ 고르기"
			or map.Level and string.format("🔒 %s부터", Formulas.levelText(Formulas.mapUnlockLevel(map)))
			or string.format("🔒 환생 %d번", map.Rebirths)
	end
end

local function openWindow()
	refresh()
	panel.Visible = true
end
panel:GetPropertyChangedSignal("Visible"):Connect(function()
	if panel.Visible then
		refresh()
	end
end)

Net.onPush("OpenMaps", openWindow)
for _, name in ipairs({ "DefenseMap", "DefenseLevel", "Rebirths", "MapWins" }) do
	player:GetAttributeChangedSignal(name):Connect(function()
		if panel.Visible then
			refresh()
		end
	end)
end
Windows.register(panel)
