--[[
Client: starts the player's side. It shows the server's notices ("너무 멀어요…") in a small stack at
the left middle of the screen (Shared/Notices: clear of the phone's move stick below and the buttons on the right),
and prints the player's own saved values once they are loaded. It never changes game values: it
only asks and requests.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TextChatService = game:GetService("TextChatService")

local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))
local Formulas = require(ReplicatedStorage.Shared:WaitForChild("Formulas"))
local Lang = require(ReplicatedStorage.Shared:WaitForChild("Lang"))
local DinoPortrait = require(ReplicatedStorage.Shared:WaitForChild("DinoPortrait"))
local Pictures = require(ReplicatedStorage.Shared:WaitForChild("Pictures"))
local Config = require(ReplicatedStorage:WaitForChild("Config"))

local CHAT_WAIT = 15
local PICTURE_SIZE = UDim2.fromOffset(48, 48)
local TIP_PICTURES = {
	BagFull = { "Item", Config.Bag.Looks[1] }, Slapped = { "Slap", Config.Slap.Looks[1] }, Slap = { "Slap", Config.Slap.Looks[1] },
	SlotsFull = { "Dino", "Dino_TRex" }, Merge = { "Dino", "Dino_TRex" }, Enhance = { "Dino", "Dino_TRex" },
	EnhanceBulk = { "Dino", "Dino_Raptor" }, NewRarities = { "Dino", "Dino_Raptor" }, RidePractice = { "Dino", "Dino_Pteranodon" },
	Night = { "Dino", Config.Zombies.Model }, Boss = { "Dino", Config.Zombies.Boss.Kinds[1].Model },
	Wild = { "Dino", Config.Wildlife.RaptorModel }, WildFeed = { "Dino", Config.Wildlife.RaptorModel },
	KingKey = { "Key", "Key_Gold" }, Bombs = { "Item", Config.Bombs.Kinds[1].Model }, PoopBomb = { "Item", Config.Bombs.Kinds[2].Model },
	Mine = { "Item", "Pickaxe_T1" }, PromoBoss = { "Fossil", "Boss" }, Leak = { "Fossil" }, Group = { "Fossil", "Group" },
	Immune = { "Fossil", "Stone" }, Coco = { "Tutorial", "Guide_Coco" }, DamageBoard = { "Dino", "Dino_TRex" },
	HelpSlap = { "Slap", Config.Slap.Looks[1] },
}
local CHAT_ESCAPES = { ["<"] = "&lt;", [">"] = "&gt;", ["&"] = "&amp;", ['"'] = "&quot;" }

local player = Players.LocalPlayer

-- phones play it sideways (landscape), either way round
pcall(function()
	player:WaitForChild("PlayerGui").ScreenOrientation = Enum.ScreenOrientation.LandscapeSensor
end)

-- the server's notices: the stack at the left middle (Shared/Notices, also the announcements)
local Notices = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Notices"))
local function pictureOf(id)
	if id == "Limited" then
		local species = ReplicatedStorage:GetAttribute("LimitedSpecies")
		return species and Pictures.of({ "Dino", "Dino_" .. species }, PICTURE_SIZE)
	end
	local spec = TIP_PICTURES[id] or (Formulas.fossilKind(id) and { "Fossil", id })
	return spec and Pictures.of(spec, PICTURE_SIZE) or nil
end

local function notify(title, text, key, pinned, picture)
	Notices.show(title, text, { key = key, pin = key ~= nil and pinned == true, picture = picture and pictureOf(picture) })
end

Net.onPush("Notice", notify)

local chatChannel = nil
task.spawn(function()
	pcall(function()
		local channels = TextChatService:WaitForChild("TextChannels", CHAT_WAIT)
		chatChannel = channels and channels:WaitForChild("RBXSystem", CHAT_WAIT)
	end)
end)
Net.onPush("BigFind", function(name, kind, rarityId, speciesId)
	local rarity = Formulas.rarity(rarityId)
	if not chatChannel or not rarity then
		return
	end
	local species = speciesId and Formulas.species(speciesId)
	local text
	if kind == "Box" then
		text = string.format("🎁 %s님이 %s 상자를 뽑았어요!", tostring(name), rarity.Name)
	elseif not species then
		return
	elseif kind == "Merge" then
		text = string.format("🧬 %s님이 합성으로 %s %s 탄생!", tostring(name), rarity.Name, species.Name)
	else
		text = string.format("🎉 %s님이 %s %s 뽑았어요!", tostring(name), rarity.Name, species.Name)
	end
	local color = DinoPortrait.gradeColor(rarityId):ToHex()
	local shown = string.gsub(Lang.t(text, Lang.code(player)), "[<>&\"]", CHAT_ESCAPES)
	pcall(function()
		chatChannel:DisplaySystemMessage(string.format('<font color="#%s">%s</font>', color, shown))
	end)
end)
player:GetAttributeChangedSignal("PromoLevel"):Connect(function()
	if player:GetAttribute("PromoLevel") == nil then
		Notices.hide("BossWave")
	end
end)
player:GetAttributeChangedSignal("HideDefenseNotices"):Connect(function()
	if player:GetAttribute("HideDefenseNotices") then
		Notices.hide("BossWave")
	end
end)

task.spawn(function()
	for _ = 1, 20 do -- the server answers once the profile is loaded
		local data = Net.ask("GetMyData")
		if data then
			print(string.format("[Client] 내 데이터: 돈 %d, 열쇠 %d, 레벨 %d, 공룡 %d마리", data.Money, data.Keys,
				data.DefenseLevel, data.UnitCount))
			if not data.Saved then
				notify("저장 안 됨", "스튜디오 API 접근이 꺼져 있어 이번 플레이는 저장되지 않아요.")
			end
			return
		end
		task.wait(0.5)
	end
end)
