--[[
KeyArrow: while I carry keys (player attribute CarriedKeys), the sky race's arrow over my head points the
way home: at my base's entrance (the gap in the front fence), big when near,
small when far (Shared/PointerArrow; 2026-10-02, "공중 레이스때 사용하는 화살표를 열쇠주웠을때 기지쪽으로 향하는
시스템으로 똑같이 넣어주자"). Gold, kept level (it points across, not down into the ground). My base: player
attributes BaseCenter (its plot's ground middle, Bases) - there before its parts stream in. Display only.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local PointerArrow = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("PointerArrow"))

local player = Players.LocalPlayer

-- display only (the race arrow's: StarterPlayerScripts/Race ARROW_*)
local ARROW_UP = 4.5 -- studs over my character's middle
local SIZES = { 40, 500, 1.9, 0.5 } -- big at 40 studs or nearer, small at 500 or farther (PointerArrow.point)
local COLOR = Color3.fromRGB(240, 50, 50) -- red (2026-10-02, "겹쳐서 화살표가 잘 안보인다 화살표를 빨간색으로": gold was lost among the crowns and names)
local ENTRANCE_IN = 4 -- studs inside the front fence: the entrance's spot

local arrow = nil

local function clear()
	if arrow then
		arrow:Destroy()
		arrow = nil
	end
end

-- where home is: my plot's entrance (the keys count the moment I step into my base: the arrow goes then)
local function homeSpot(from)
	local center = player:GetAttribute("BaseCenter")
	if typeof(center) ~= "Vector3" then
		return nil
	end
	local flat = Vector3.new(center.X, 0, center.Z)
	local out = flat.Magnitude > 1e-3 and flat.Unit or Vector3.zAxis -- (plots face the map's middle)
	local entrance = flat - out * (Config.Map.PlotDepth / 2 - ENTRANCE_IN)
	return Vector3.new(entrance.X, from.Y, entrance.Z) -- (level with the arrow)
end

RunService.RenderStepped:Connect(FrameMeter.wrap("KeyArrow", function()
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if (player:GetAttribute("CarriedKeys") or 0) <= 0 or not root or player:GetAttribute("Racing") then
		clear()
		return
	end
	local at = root.Position + Vector3.new(0, ARROW_UP, 0)
	local target = homeSpot(at)
	if not target then
		clear()
		return
	end
	if not arrow then
		arrow = PointerArrow.make(COLOR)
		arrow.Name = "KeyHomeArrow"
	end
	PointerArrow.point(arrow, at, target, SIZES)
end))
