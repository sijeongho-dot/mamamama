local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Sfx = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Sfx"))
local HeartPulse = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("HeartPulse"))
local PoopPile = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("PoopPile"))

local player = Players.LocalPlayer

local TIMER_SIZE = UDim2.fromOffset(320, 40)
local TIMER_POS = UDim2.new(0.5, 0, 0, 96)
local TIMER_COLOR = Color3.fromRGB(30, 34, 52)
local TIMER_TEXT = Color3.fromRGB(255, 235, 150)
local TIMER_FAR = Color3.fromRGB(140, 255, 140)
local HEART_SIZE = UDim2.fromOffset(230, 32)
local HEART_POS = UDim2.new(0.5, 0, 0, 142)
local HEART_COLOR = Color3.fromRGB(70, 20, 35)
local HEART_TEXT = Color3.fromRGB(255, 170, 190)
local HEART_CHECK = 0.1
local HEART_POP = 1.12
local SURVIVE_TEXTS = {
	Hidden = "🙈 숨었어요! ⏳ %d초 더",
	Open = "🎭 변신하거나 🌳 나무에 숨어요 · ⏳ %d초",
	Away = "🏃 술래 가까이에서 숨어요 · ⏳ %d초",
	Seen = "👀 들켰다! 다시 ⏳ %d초",
}
local WATCHED = { "Practice", "PracticeTrees", "TreasureChests", "Keys" }

local piles = {}
local movers = {}
local seeker = nil

local function moveAt(model, now)
	local start, seconds = model:GetAttribute("MoveAt"), model:GetAttribute("MoveSeconds")
	local from, to = model:GetAttribute("MoveFrom"), model:GetAttribute("MoveTo")
	if type(start) ~= "number" or type(seconds) ~= "number" or typeof(from) ~= "CFrame" or typeof(to) ~= "CFrame" then
		return nil, true
	end
	local t = seconds > 0 and math.clamp((now - start) / seconds, 0, 1) or 1
	local a = model:GetAttribute("MoveLinear") and t or 1 - (1 - t) * (1 - t)
	local up = CFrame.new(0, model:GetAttribute("MoveMid") or 0, 0)
	return from:Lerp(to, a) * CFrame.new(0, math.sin(a * math.pi) * (model:GetAttribute("MoveArc") or 0), 0) * up
		* CFrame.Angles(0, 0, (model:GetAttribute("MoveSpin") or 0) * a) * up:Inverse(), t >= 1
end

RunService.RenderStepped:Connect(function()
	local now = Workspace:GetServerTimeNow()
	for model, state in pairs(movers) do
		if not model.Parent then
			movers[model] = nil
		elseif model:GetAttribute("MoveAt") ~= state.done then
			local cf, finished = moveAt(model, now)
			if cf then
				model:PivotTo(cf)
			end
			if finished then
				state.done = model:GetAttribute("MoveAt")
			end
		end
	end
end)

local function bury(model)
	if piles[model] then
		piles[model]:Destroy()
		piles[model] = nil
	end
	local left = (model:GetAttribute("PoopUntil") or 0) - Workspace:GetServerTimeNow()
	if left <= 0 or not model.Parent then
		return
	end
	local pile = PoopPile.make(model:GetPivot().Position, Workspace, model:GetAttribute("PoopScale") or 1)
	piles[model] = pile
	task.delay(left, function()
		if piles[model] == pile then
			pile:Destroy()
			piles[model] = nil
		end
	end)
end

local function check(child)
	local only = child:GetAttribute("OnlyFor")
	if only ~= nil and only ~= player.UserId then
		child:Destroy()
		return
	end
	if child:IsA("Model") and child.Parent and child.Parent.Name == "Practice" then
		movers[child] = { done = false }
		if child:GetAttribute("Kind") == "Seeker" then
			seeker = child
		end
	end
	if child:IsA("Model") and child:GetAttribute("PoopScale") then
		child:GetAttributeChangedSignal("PoopUntil"):Connect(function()
			bury(child)
		end)
		child.AncestryChanged:Connect(function()
			if not child.Parent and piles[child] then
				piles[child]:Destroy()
				piles[child] = nil
			end
		end)
	end
end

local function watch(name)
	task.spawn(function()
		local folder = Workspace:WaitForChild(name, 60)
		if not folder then
			return
		end
		for _, child in ipairs(folder:GetChildren()) do
			check(child)
		end
		folder.ChildAdded:Connect(function(child)
			task.defer(check, child)
		end)
	end)
end

for _, name in ipairs(WATCHED) do
	watch(name)
end

local gui = Instance.new("ScreenGui")
gui.Name = "PracticeView"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local timer = Instance.new("TextLabel")
timer.AnchorPoint = Vector2.new(0.5, 0)
timer.Size = TIMER_SIZE
timer.Position = TIMER_POS
timer.BackgroundColor3 = TIMER_COLOR
timer.BackgroundTransparency = 0.2
timer.Font = Enum.Font.GothamBlack
timer.TextColor3 = TIMER_TEXT
timer.TextScaled = true
timer.Visible = false
timer.Parent = gui
local round = Instance.new("UICorner")
round.CornerRadius = UDim.new(0, 12)
round.Parent = timer

local function refresh()
	local left = player:GetAttribute("HidePracticeLeft")
	local count = player:GetAttribute("HideCountLeft")
	timer.Visible = type(left) == "number" or type(count) == "number"
	if type(count) == "number" then
		local far, need = player:GetAttribute("HideCountFar") or 0, Config.Practice.RunDistance
		timer.Text = string.format("🙈 %d초 · 🏃 %d/%d칸 멀리!", count, math.min(far, need), need)
		timer.TextColor3 = far >= need and TIMER_FAR or TIMER_TEXT
	elseif timer.Visible then
		local state = player:GetAttribute("HidePracticeState")
		timer.Text = string.format(SURVIVE_TEXTS[state] or SURVIVE_TEXTS.Open, left)
		timer.TextColor3 = state == "Hidden" and TIMER_FAR or TIMER_TEXT
	end
end

player:GetAttributeChangedSignal("HidePracticeLeft"):Connect(refresh)
player:GetAttributeChangedSignal("HidePracticeState"):Connect(refresh)
player:GetAttributeChangedSignal("HideCountLeft"):Connect(refresh)
local lastCount = nil
player:GetAttributeChangedSignal("HideCountLeft"):Connect(function()
	local count = player:GetAttribute("HideCountLeft")
	if type(count) == "number" and count > 0 and count ~= lastCount then
		Sfx.play("CountTick")
	elseif count == nil and type(lastCount) == "number" then
		Sfx.play("CountGo")
	end
	lastCount = count
end)
player:GetAttributeChangedSignal("HideCountFar"):Connect(refresh)
refresh()

local heart = Instance.new("TextLabel")
heart.AnchorPoint = Vector2.new(0.5, 0)
heart.Size = HEART_SIZE
heart.Position = HEART_POS
heart.BackgroundColor3 = HEART_COLOR
heart.BackgroundTransparency = 0.15
heart.Font = Enum.Font.GothamBlack
heart.TextColor3 = HEART_TEXT
heart.TextScaled = true
heart.Text = "💓 술래가 가까워요!"
heart.Visible = false
heart.Parent = gui
local heartRound = Instance.new("UICorner")
heartRound.CornerRadius = UDim.new(0, 12)
heartRound.Parent = heart
local heartScale = Instance.new("UIScale")
heartScale.Parent = heart

task.spawn(function()
	local beat = HeartPulse.beater(heartScale, HEART_POP)
	while true do
		task.wait(HEART_CHECK)
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		local body = seeker and seeker.Parent and (seeker.PrimaryPart or seeker:FindFirstChild("HumanoidRootPart"))
		local near = root and body and HeartPulse.nearness((body.Position - root.Position).Magnitude) or nil
		heart.Visible = near ~= nil
		beat(near)
	end
end)
