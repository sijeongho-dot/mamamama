local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))

local player = Players.LocalPlayer

local HEIGHT = 30
local LEFT = 8
local PAD = 10
local TEXT_SIZE = 15
local CONFIRM_SECONDS = 3
local DISPLAY_ORDER = 90
local COLOR_BG = Color3.fromRGB(70, 40, 40)
local COLOR_CONFIRM = Color3.fromRGB(190, 60, 50)
local TEXT_IDLE = "🔄 처음부터"
local TEXT_CONFIRM = "한 번 더 누르면 처음부터"
local TEXT_SENT = "🔄 다시 들어가는 중…"

if not Formulas.isDeveloper(player.Name) then
	return
end

local gui = Instance.new("ScreenGui")
gui.Name = "DevRestart"
gui.ResetOnSpawn = false
gui.DisplayOrder = DISPLAY_ORDER

local button = Instance.new("TextButton")
button.AnchorPoint = Vector2.new(0, 0.5)
button.Position = UDim2.new(0, LEFT, 0.5, 0)
button.Size = UDim2.fromOffset(0, HEIGHT)
button.AutomaticSize = Enum.AutomaticSize.X
button.BackgroundColor3 = COLOR_BG
button.BackgroundTransparency = 0.2
button.TextColor3 = Color3.new(1, 1, 1)
button.Font = Enum.Font.GothamBold
button.TextSize = TEXT_SIZE
button.Text = TEXT_IDLE
button.Parent = gui
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 6)
corner.Parent = button
local padding = Instance.new("UIPadding")
padding.PaddingLeft = UDim.new(0, PAD)
padding.PaddingRight = UDim.new(0, PAD)
padding.Parent = button

local sent = false
local armedAt = nil
button.Activated:Connect(function()
	if sent then
		return
	end
	if armedAt and os.clock() - armedAt <= CONFIRM_SECONDS then
		sent = true
		button.Text = TEXT_SENT
		Net.request("DevRestart")
		return
	end
	local at = os.clock()
	armedAt = at
	button.Text = TEXT_CONFIRM
	button.BackgroundColor3 = COLOR_CONFIRM
	task.delay(CONFIRM_SECONDS, function()
		if not sent and armedAt == at then
			armedAt = nil
			button.Text = TEXT_IDLE
			button.BackgroundColor3 = COLOR_BG
		end
	end)
end)

gui.Parent = player:WaitForChild("PlayerGui")
