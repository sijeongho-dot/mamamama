--[[
ControlGuard: puts the phone's controls back when they get stuck, and tells the server's log what it
found (2026-10-02, "갑자기 폰에서 밀어서 시점 옮기는 게 안 되네, 조작키도 안 뜨고, 간헐적으로 … 공룡 타고
있었어"). Display only: nothing here is judged by the server.

Every CHECK_EVERY seconds, while my character is alive:
- the camera held still (Scriptable) with no race countdown holding it (Race), or looking at something
  other than my character: back to Roblox's own camera on my character;
- Roblox's touch controls (TouchGui: the move stick and the jump button) switched off, touch controls
  turned off for the game (GuiService.TouchControlsEnabled) or the screen made modal
  (UserInputService.ModalEnabled): back on;
- my character left lying down (PlatformStand: no walking) for STUCK_STAND seconds while not flying:
  standing again (a slap's throw, a wild raptor's ride and the rebirth show all end well before);
- an invisible button over a big part of the screen (it would take every touch: no stick, no camera
  turning) is only reported, with its path, so it can be found and fixed (dragging a dino into place
  covers the screen on purpose: its layers are skipped).
Each fix or finding goes to the server's log once a minute at most (Net request ClientError,
"[ControlGuard] ...").
]]

local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))

local player = Players.LocalPlayer

-- display only
local CHECK_EVERY = 1 -- seconds between looks
local STUCK_CAMERA = 2 -- seconds the camera may stay held with nothing holding it
local STUCK_TOUCH = 2 -- seconds the touch controls may stay off
local STUCK_STAND = 8 -- seconds lying down (PlatformStand) while not flying
local COVER_SHARE = 0.3 -- an invisible button over this share of the screen is reported
local COVER_EVERY = 10 -- seconds between looks for such a button (it walks the shown screen)
local REPORT_EVERY = 60 -- seconds between two reports of the same thing

local reported = {} -- [what] = os.clock() of its last report
local function report(what, detail)
	if reported[what] and os.clock() - reported[what] < REPORT_EVERY then
		return
	end
	reported[what] = os.clock()
	pcall(Net.request, "ClientError", ("[ControlGuard] " .. what):sub(1, Config.Net.MaxStringLength),
		tostring(detail or ""):sub(1, Config.Net.MaxStringLength))
end

local since = {} -- [what] = os.clock() it was first seen wrong (cleared when it is right)
local function stuckFor(what, wrong)
	if not wrong then
		since[what] = nil
		return 0
	end
	since[what] = since[what] or os.clock()
	return os.clock() - since[what]
end

-- (2026-10-02, "1초 조금 안돼서 톡톡 끊기는듯": every second every object of every window, closed ones too, was
-- looked at: a hitch a second on a phone) only what is shown (a hidden frame is skipped whole), every COVER_EVERY
local function invisibleCover(screenArea)
	local found = nil
	local function walk(inst)
		for _, d in ipairs(inst:GetChildren()) do
			if found then
				return
			end
			if d:IsA("GuiObject") then
				if d.Visible then
					if (d:IsA("GuiButton") or d.Active) and d.Name ~= "DragCatcher" and d.BackgroundTransparency >= 0.99
						and not (d:IsA("TextButton") and d.Text ~= "") and not (d:IsA("ImageButton") and d.Image ~= "")
						and d.AbsoluteSize.X * d.AbsoluteSize.Y > screenArea * COVER_SHARE then
						found = d
						return
					end
					walk(d)
				end
			elseif d:IsA("Folder") then
				walk(d)
			end
		end
	end
	for _, gui in ipairs(player.PlayerGui:GetChildren()) do
		if gui:IsA("LayerCollector") and gui.Enabled and gui.Name ~= "TouchGui" then
			walk(gui)
		end
	end
	return found
end

local controls = nil
local function controlModule()
	if controls == nil then
		local scripts = player:FindFirstChild("PlayerScripts")
		local module = scripts and scripts:FindFirstChild("PlayerModule")
		if module then
			local ok, found = pcall(function()
				return require(module):GetControls()
			end)
			controls = ok and found or false
		end
	end
	return controls or nil
end

local coverCheckedAt = 0
local function check()
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not humanoid or humanoid.Health <= 0 then
		return
	end
	local camera = Workspace.CurrentCamera
	if camera then
		local held = camera.CameraType == Enum.CameraType.Scriptable and player:GetAttribute("Racing") ~= "Countdown"
			and not player:GetAttribute("Cinematic") and not player:GetAttribute("TopView")
		if stuckFor("camera", held) > STUCK_CAMERA then
			camera.CameraType = Enum.CameraType.Custom
			report("camera held", "Scriptable outside a race countdown")
		end
		local subject = camera.CameraSubject
		if stuckFor("subject", subject ~= humanoid) > STUCK_CAMERA then
			camera.CameraSubject = humanoid
			report("camera subject", subject and subject:GetFullName() or "nil")
		end
	end
	local c = controlModule()
	if c and stuckFor("controls", c.humanoid ~= humanoid) > STUCK_TOUCH then
		report("controls lost character", c.humanoid and c.humanoid:GetFullName() or "nil")
		pcall(c.OnCharacterAdded, c, character)
		since.controls = nil
	end
	if UserInputService.TouchEnabled then
		local touchGui = player.PlayerGui:FindFirstChild("TouchGui")
		local off = (touchGui and not touchGui.Enabled) or not GuiService.TouchControlsEnabled
			or UserInputService.ModalEnabled
		if stuckFor("touch", off) > STUCK_TOUCH then
			report("touch controls off", string.format("TouchGui %s, TouchControlsEnabled %s, ModalEnabled %s",
				touchGui and tostring(touchGui.Enabled) or "none", tostring(GuiService.TouchControlsEnabled),
				tostring(UserInputService.ModalEnabled)))
			GuiService.TouchControlsEnabled = true
			UserInputService.ModalEnabled = false
			if touchGui then
				touchGui.Enabled = true
			end
		end
		if os.clock() - coverCheckedAt >= COVER_EVERY then
			coverCheckedAt = os.clock()
			local screen = camera and camera.ViewportSize
			local cover = screen and invisibleCover(screen.X * screen.Y)
			if cover then
				report("invisible cover", cover:GetFullName())
			end
		end
	end
	local flying = player:GetAttribute("Riding") == true and player:GetAttribute("Flying") == true
	if stuckFor("stand", humanoid.PlatformStand and not flying) > STUCK_STAND then
		humanoid.PlatformStand = false
		since.stand = nil
		report("left lying down", string.format("Riding %s", tostring(player:GetAttribute("Riding"))))
	end
end

task.spawn(function()
	while true do
		task.wait(CHECK_EVERY)
		local ok, err = pcall(check)
		if not ok then
			report("check failed", err)
		end
	end
end)
