--[[
WeatherFx: the sky, drawn on each client only (display only, no server parts, no lag for others).

- Clouds: soft white clusters drifting high over the map with the wind, wrapping around; greyer in
  rain and dark in a storm.
- Flying reptiles: a few pterosaur models (ReplicatedStorage.DinoModels, the flying species) circle
  high above, banking into their turns, wings flapping (Shared/DinoMotion).
- Weather (ReplicatedStorage attributes Weather and WeatherUntil, from the Weather service): in rain
  and in a storm (heavier) thin streaks fall around the camera, a grey cloud deck thickens overhead and hides the sun, the sunlight
  softens (exposure, shadow softness, the Sky's sun), the light dims and the view gets a little shorter (Atmosphere density or
  fog), back to the place's own when it clears; a storm rains harder, gets darker and lightning flashes
  and strikes nearby now and then. The aurora (night only): green and violet curtains of light wave all
  round the sky, most to the north. The rarest, the rainbow sky (RainbowSky): a giant rainbow covers
  the northern sky (it keeps its place around the camera, like the sun), colors get brighter and
  warmer, the clouds stay white (thunder a moment after, later the farther away). The rain is heard
  too: a rain loop, or a heavier storm loop with wind, fading in and out with the weather
  (Shared/Sfx; silent until the sounds are uploaded). The sun and moon are drawn huge, and at night
  (DayNight service) a milky way of twinkling stars crosses the sky, more stars all over it (bigger, brighter). A small line at the top says the weather,
  its defense bonus and the time left.
]]

local Lighting = game:GetService("Lighting")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local DinoMotion = require(Shared:WaitForChild("DinoMotion"))
local Lod = require(Shared:WaitForChild("Lod"))
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Fx = require(Shared:WaitForChild("Fx"))
local PoopPile = require(Shared:WaitForChild("PoopPile"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))

local player = Players.LocalPlayer

-- display only
local K = {}
K.CLOUD_COUNT = 60
K.LIGHT_CLOUD_EVERY = 3
K.CINEMA_HAZE = 0.3
K.CLOUD_HEIGHT = { 130, 190 }
K.CLOUD_SPREAD = 650
K.CLOUD_WIND = Vector3.new(8, 0, 3) -- studs per second: they visibly drift
-- (2026-10-02, "혼자하는데 렉이 좀 있는거 같은데 최적화 해봐 8인기준으로": 100 clouds of ~10 puffs each were all moved
-- every frame, about a thousand parts) each cloud moves every CLOUD_SLICES-th frame, by the time that passed
K.CLOUD_SLICES = 12 -- (2026-10-04: was 6; each moved every 0.2 s, under 2 studs far overhead)
K.CLOUD_PUFFS = { 4, 7 } -- the bottom row of puffs; a second row sits on its middle (fat clouds)
K.CLOUD_PUFF_SIZE = { 28, 46 } -- (was 18-34)
K.CLOUD_OVERLAP = 0.42 -- puffs this much of a size apart, packed tight
K.CLOUD_TOP_SCALE = 0.85 -- the upper row's puffs, × the size
K.CLOUD_COLORS = { Clear = Color3.fromRGB(255, 255, 255), Rain = Color3.fromRGB(175, 180, 190),
	Storm = Color3.fromRGB(95, 98, 110), RainbowSky = Color3.fromRGB(255, 255, 255), Aurora = Color3.fromRGB(215, 255, 235) }
K.FLYER_SPECIES = { -- 20 (was 10), some lower and closer
	"Pteranodon", "Quetzal", "Rhampho", "Pteranodon", "Quetzal", "Pteranodon", "Rhampho", "Quetzal", "Pteranodon", "Rhampho",
	"Pteranodon", "Quetzal", "Rhampho", "Pteranodon", "Rhampho", "Quetzal", "Pteranodon", "Rhampho", "Quetzal", "Pteranodon",
}
K.FLYER_SCALE = 3 -- bigger than life so they read from the ground
K.LIGHT_FLYERS = 8
K.FLYER_HEIGHT = { 75, 150 }
K.FLYER_RADIUS = { 180, 520 }
K.FLYER_CENTER_SPREAD = 500
K.FLYER_SPEED = { 22, 34 } -- studs per second along the circle
K.FLYER_BANK = math.rad(18)
-- streaks falling around the camera (2026-10-04, "날씨 있을때 ... 지연": were 220 and 380, every one moved every frame)
K.RAIN_DROPS = { Rain = 120, Storm = 200 }
K.RAIN_DROPS_LIGHT = { Rain = 60, Storm = 100 }
K.RAIN_DROP_SIZE = Vector3.new(0.08, 3, 0.08)
K.RAIN_DROP_TRANSPARENCY = 0.35
K.RAIN_RANGE = 70 -- studs around the camera where it rains
K.RAIN_TOP, K.RAIN_BOTTOM = 55, -25 -- studs above / below the camera a streak starts / ends
K.RAIN_SPEED = 120 -- studs per second
K.RAIN_SLANT = Vector3.new(0.12, 0, 0.05) -- the wind tilts the streaks a little
K.RAIN_COLOR = Color3.fromRGB(200, 220, 255)
K.HIDDEN_Y = -2000
-- a streak's long side (Y) along its fall: down, tilted by the wind
K.RAIN_TURN = CFrame.lookAt(Vector3.zero, Vector3.new(0, -1, 0) + K.RAIN_SLANT) * CFrame.Angles(math.rad(90), 0, 0)
K.TINT = {
	Clear = { Brightness = 0, Saturation = 0, TintColor = Color3.new(1, 1, 1) },
	Rain = { Brightness = -0.1, Saturation = -0.25, TintColor = Color3.fromRGB(215, 225, 245) },
	Storm = { Brightness = -0.2, Saturation = -0.4, TintColor = Color3.fromRGB(190, 195, 225) },
	RainbowSky = { Brightness = 0.04, Saturation = 0.3, TintColor = Color3.fromRGB(255, 248, 240) },
	Aurora = { Brightness = 0.03, Saturation = 0.25, TintColor = Color3.fromRGB(225, 255, 240) },
}
-- the aurora (night only): wide curtains of green light with violet tops waving over the sky
-- (2026-10-01, "the aurora doesn't show"): the curtains were 350-750 studs north and 260 up, about 900 studs
-- away, where the place's Atmosphere haze hid them at 55% see-through. Now nearer, brighter, and all
-- round the sky (north the most), so it shows wherever one looks
-- (2026-10-04, "오로라 날씨 오로라가 너무 낮게 떠있는데": the lower edges were 55-105 studs up, about 13° over the eye,
-- hanging by the horizon like a wall) up in the sky now: the curtains' lower edges about 24° over the eye, their tops
-- about 50-57°, and taller (were 120-170 up, 130 + 85 tall) — the lower part still shows at a phone's usual camera
-- angle, the whole of it looking up
K.AURORA_PLACES = { -- per curtain: { degrees round from north (clockwise), studs out, studs up (its green part's middle) }
	{ 0, 260, 200 }, { 0, 380, 255 }, { 65, 300, 220 }, { -65, 300, 220 }, { 180, 340, 235 },
}
K.AURORA_CURTAINS = #K.AURORA_PLACES
K.AURORA_COLUMNS = 30 -- slabs per curtain
K.AURORA_WIDTH = 700 -- studs, one curtain from end to end
K.AURORA_HEIGHT = { 170, 110 } -- the green lower part, the violet top
K.AURORA_COLORS = { Color3.fromRGB(80, 255, 170), Color3.fromRGB(170, 110, 255) }
K.AURORA_SHOWN = 0.3 -- transparency when out (glowing light; was 0.55)
K.AURORA_FADE = 6
K.AURORA_WAVE, K.AURORA_WAVE_SPEED = 60, 0.25 -- how far and how fast the curtains ripple
K.AURORA_SHIMMER = 0.12
-- the rainbow sky: seven bands in a half circle, far off in the north, around the camera
K.RAINBOW_COLORS = {
	Color3.fromRGB(255, 70, 70), Color3.fromRGB(255, 150, 60), Color3.fromRGB(255, 230, 80), Color3.fromRGB(90, 220, 110),
	Color3.fromRGB(70, 160, 255), Color3.fromRGB(90, 90, 230), Color3.fromRGB(170, 90, 230),
}
K.RAINBOW_RADIUS = 900 -- the outer band: one giant arc that covers the whole northern sky
K.RAINBOW_BAND = 34 -- studs per band
K.RAINBOW_SEGMENTS = 72
K.RAINBOW_DISTANCE = 380 -- studs north of the camera (2026-10-01: was 520, "too far to see": nearer, clear of the haze)
K.RAINBOW_DROP = 120 -- its middle this far below the camera, so it rises out of the land
K.RAINBOW_SHOWN = 0.2 -- transparency when out (it glows, a little see-through)
K.RAINBOW_FADE = 5
-- less light and a slightly shorter view in bad weather (back to the place's own values when clear)
K.LIGHT = { Rain = 0.75, Storm = 0.6 } -- × Lighting.Brightness
K.FOG_END = { Rain = 900, Storm = 650 } -- studs, when the place has no Atmosphere
K.FOG_COLOR = Color3.fromRGB(150, 155, 165)
K.HAZE_DENSITY = { Rain = 0.08, Storm = 0.15 } -- added to the Atmosphere's density
K.HAZE_HAZE = { Rain = 1, Storm = 2 } -- added to its haze
-- the sun goes behind the clouds: a grey cloud deck thickens overhead, the sunlight softens
-- a round sheet far wider than the view (2026-10-01: a 2,400-stud square, its corners showed as a box
-- in the sky in a storm); its edge is lost in the haze. A part is at most 2,048 studs a side, so a round
-- mesh scaled up draws it 9,000 across (X is its thickness, Y and Z across)
K.DECK_SIZE = Vector3.new(4, 2048, 2048)
K.DECK_MESH_SCALE = Vector3.new(1, 9000 / 2048, 9000 / 2048)
K.DECK_TURN = CFrame.Angles(0, 0, math.pi / 2) -- the round faces up and down
K.DECK_HEIGHT = 250
K.DECK_TRANSPARENCY = { Clear = 1, Rain = 0.35, Storm = 0.12 }
K.DECK_COLOR = { Clear = Color3.fromRGB(200, 200, 205), Rain = Color3.fromRGB(150, 153, 162),
	Storm = Color3.fromRGB(70, 72, 82) }
K.EXPOSURE = { Rain = -0.25, Storm = -0.5 } -- added to Lighting.ExposureCompensation
K.SHADOW_SOFTNESS = { Rain = 0.8, Storm = 1 } -- soft, sunless shadows
-- at night the darkening above (less light, lower exposure, the darker tint, the cloud deck hiding the
-- moon and stars, the thicker haze) counts only this much: night is dark already, a storm on top of it
-- made the screen nearly black
K.NIGHT_DIM_SHARE = 0.25
K.SUN_SIZE = { Rain = 0.3, Storm = 0 } -- × the Sky's sun size
K.SUN_ANGULAR_SIZE = 60 -- degrees (Roblox's usual 21): a huge sun ...
-- (2026-10-01, "the sun a little less bright") the sun's own picture can't be dimmed in Roblox: our own,
-- a warm disc at about 80% (tools/make_sun_texture.py → exports/textures/Sun_Soft.png). Put its uploaded id
-- here ("rbxassetid://123..."); "" keeps Roblox's sun. And the glare round it (Atmosphere) is cut down
K.SUN_TEXTURE = ""
K.SUN_GLARE_SHARE = 0.22 -- × the place's Atmosphere glare (2026-10-01: was 0.35, "the sun's flash a little less")
K.SUN_RAYS_SHARE = 0.6 -- × the place's SunRays intensity, when it has them (the rays flashing round the sun)
K.MOON_ANGULAR_SIZE = 45 -- ... and moon (usual 11)
K.STAR_COUNT = 5000 -- the most the Sky draws
-- the milky way at night: a band of twinkling stars across the sky, around the camera
K.MILKY_STARS = 450 -- (2026-10-04, "렉이 특히 밤에 더 걸리는거 같군": was 900; every one a part following the camera)
K.MILKY_RADIUS = 600 -- studs from the camera
K.MILKY_WIDTH = 70 -- how far stars stray from the band's middle line
K.MILKY_TILT = math.rad(35) -- the band's slant
K.MILKY_COLORS = { Color3.fromRGB(255, 255, 255), Color3.fromRGB(200, 220, 255), Color3.fromRGB(255, 240, 200),
	Color3.fromRGB(255, 200, 230) }
K.MILKY_GLOWS = 0 -- faint big glows along the band (2026-10-04, "공중에 이건 뭐야": was 40 balls 60-100 studs across;
-- on phones they showed as a chain of blue circles, and their overlapping see-through size cost the most to draw)
K.MILKY_GLOW_COLOR = Color3.fromRGB(150, 140, 255)
K.MILKY_FADE = 6 -- seconds to fade in at night and out at dawn
-- (2026-10-02, the lag pass) the ~940 milky-way parts follow the camera only when it moved this far (they are
-- 600 studs out: a step this small can't be seen), and a fade sets MILKY_FADE_PER_FRAME stars a frame
K.MILKY_FOLLOW = 12 -- (2026-10-04: was 8)
K.MILKY_FOLLOW_GAP = 0.25 -- seconds: it follows at most this often (flying fast it moved every few frames)
K.MILKY_FADE_PER_FRAME = 60
-- (2026-10-03, "밤 하늘이 오늘 만든 배경 안으로 보이는데"): the stars are parts MILKY_RADIUS from the camera, nearer than
-- the far scenery (the waterfall, mountains, volcano past 790 from the middle), so they were drawn over it. Each star
-- whose line from the camera meets the scenery (Workspace.Map.Boundary) is hidden; looked at again (STAR_CULL_PER_FRAME
-- stars a frame) each time the stars follow the camera
K.STAR_CULL_REACH = 4000 -- studs: far past every piece of scenery
K.STAR_CULL_PER_FRAME = 30 -- (2026-10-04: was 80 rays a frame)
-- (2026-10-03, the 8-player pass) the scenery is 800+ studs off: what it hides barely changes over a short walk. The
-- stars are looked at again only once the camera is this far from where they last were (was every 8-stud follow: a
-- walk at night kept ~80 rays a frame going)
K.STAR_CULL_MOVE = 80 -- (2026-10-04: was 40)
-- (2026-10-02 "은하수 빼면 별이 잘 안보이는데") stars all over the sky, not just the band: the Sky's own
-- are a pixel each on a phone. Bigger and brighter than the band's, a few big bright ones
K.SKY_STARS = 300 -- (2026-10-04: was 650)
K.SKY_STAR_SIZE = { 1.6, 3.4 }
K.SKY_STAR_LOW = math.rad(10) -- above the horizon (the hills hide the lowest)
K.BRIGHT_STARS = 45
K.BRIGHT_STAR_SIZE = { 4, 6 }
K.SKY_STAR_DIM = 0.3 -- at most this see-through (the band's 0.5): brighter
K.TWINKLE_PER_FRAME = 20 -- stars that change brightness each frame (2026-10-04: was 60)
K.TINT_SECONDS = 3
K.RAIN_SOUND_FADE = 4 -- seconds for the rain sound to fade in or out
K.LIGHTNING_EVERY = { 4, 10 } -- seconds between far-off strikes in a storm (only seen: the server's land near players)
K.LIGHTNING_NEAR, K.LIGHTNING_RANGE = 120, 220 -- studs from the camera where a far-off bolt hits
-- (2026-10-02) a bolt from the server (Lightning service, Net push Lightning): the spot crackles first
K.STRIKE_DRAW_DISTANCE = 600
K.WARN_COLOR = Color3.fromRGB(190, 200, 255)
K.WARN_THICKNESS = 0.15
K.SCORCH_COLOR = Color3.fromRGB(40, 35, 45)
K.SCORCH_SECONDS = 3
K.SPARKS = { Color3.fromRGB(230, 230, 255), Color3.fromRGB(255, 240, 150), Color3.fromRGB(170, 190, 255) }
K.LIGHTNING_TOP = 220
K.LIGHTNING_SEGMENTS = 8
K.LIGHTNING_JITTER = 10
K.LIGHTNING_SECONDS = 0.25
K.LIGHTNING_COLOR = Color3.fromRGB(220, 215, 255)
K.FLASH_BRIGHTNESS = 0.6
K.POOP_SIZE = 1.6
K.POOP_SHADOW = 5 -- studs across when it lands (a direct hit is within Config.Poop.HitRadius)
K.POOP_COLOR = Color3.fromRGB(110, 70, 35)
K.POOP_DRAW_DISTANCE = 300
K.PILE_CHECK_EVERY = 0.15
K.BOMBER_SPECIES = { "Pteranodon", "Quetzal", "Rhampho" } -- the one that drops it (picked by the heading: the same everywhere)
K.BOMBER_SPEED = 28 -- studs per second, straight over the spot
K.BOMBER_LEAVE = 4 -- seconds it flies on after letting go, climbing away
K.BOMBER_CLIMB = 6 -- studs per second up while leaving
K.BOMBER_SCREECH_BEFORE = 1.2 -- seconds before letting go it screeches
K.NIGHT_LINE_COLOR = Color3.fromRGB(170, 180, 255)
K.LINE_NARROW, K.LINE_WIDE = 260, 520 -- the line's width: one of weather / night, or both
K.LINE_TOP = 4
K.LINE_TOP_RACE = 46 -- under the race bar (Race, 6..42)
K.LINE_GAP_FIGHT = 4 -- pixels under the promotion fight bar (Placement; its height changes with the boss gauge)

local rng = Random.new()
local function between(range)
	return rng:NextNumber(range[1], range[2])
end

local sky = Instance.new("Folder")
sky.Name = "Sky"
sky.Parent = Workspace

local function plainPart(props)
	local p = Instance.new("Part")
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	for k, v in pairs(props) do
		p[k] = v
	end
	return p
end

-- ---------------------------------------------------------------------------
-- Clouds
-- ---------------------------------------------------------------------------

local clouds = {} -- { model, position }
for _ = 1, K.CLOUD_COUNT do
	local model = Instance.new("Model")
	model.Name = "Cloud"
	local puffs = rng:NextInteger(K.CLOUD_PUFFS[1], K.CLOUD_PUFFS[2])
	local base = between(K.CLOUD_PUFF_SIZE)
	local function puff(x, y, z, size)
		plainPart({ Name = "Puff", Shape = Enum.PartType.Ball, Size = Vector3.one * size,
			Material = Enum.Material.SmoothPlastic, Color = K.CLOUD_COLORS.Clear, Transparency = 0,
			CFrame = CFrame.new(x, y, z), Parent = model })
	end
	for i = 1, puffs do -- the bottom row: the middle puffs biggest, packed tight
		local middle = 1 - math.abs((i - (puffs + 1) / 2) / puffs)
		local size = base * (0.75 + 0.35 * middle) * rng:NextNumber(0.9, 1.1)
		puff((i - (puffs + 1) / 2) * base * K.CLOUD_OVERLAP * 1.3, rng:NextNumber(-2, 2), rng:NextNumber(-6, 6), size)
	end
	for i = 1, math.max(1, puffs - 2) do -- the fat upper row over the middle
		local size = base * K.CLOUD_TOP_SCALE * rng:NextNumber(0.85, 1.1)
		puff((i - (puffs - 1) / 2) * base * K.CLOUD_OVERLAP * 1.2, base * 0.35 + rng:NextNumber(-2, 3),
			rng:NextNumber(-5, 5), size)
	end
	model.WorldPivot = CFrame.new()
	local position = Vector3.new(rng:NextNumber(-K.CLOUD_SPREAD, K.CLOUD_SPREAD), between(K.CLOUD_HEIGHT),
		rng:NextNumber(-K.CLOUD_SPREAD, K.CLOUD_SPREAD))
	model:PivotTo(CFrame.new(position) * CFrame.Angles(0, rng:NextNumber(0, math.pi), 0))
	model.Parent = sky
	-- (2026-10-04, a slow phone: WeatherFx 3.3 ms a frame on a clear day) its puffs and where each sits from its pivot, so
	-- a frame's clouds move in one Workspace:BulkMoveTo (was PivotTo on each cloud model)
	local pivot = model:GetPivot()
	local parts, offsets = {}, {}
	for _, part in ipairs(model:GetChildren()) do
		table.insert(parts, part)
		table.insert(offsets, pivot:ToObjectSpace(part.CFrame))
	end
	table.insert(clouds, { model = model, position = position, turn = pivot.Rotation, parts = parts, offsets = offsets })
end

-- (2026-10-04, "지연도 확실히 해결해") 🍃 light mode (player attribute LightMode, StarterPlayerScripts/LightMode): no clouds
-- (not drawn, not moved); they drift on from where they were when it is switched off
local cloudsHidden = false
local function lightClouds()
	local hidden = Players.LocalPlayer:GetAttribute("LightMode") == true
	if hidden == cloudsHidden then
		return
	end
	cloudsHidden = hidden
	for i, c in ipairs(clouds) do
		c.hidden = hidden and i % K.LIGHT_CLOUD_EVERY ~= 0
		for _, part in ipairs(c.parts) do
			part.LocalTransparencyModifier = c.hidden and 1 or 0
		end
		c.movedAt = nil
	end
end
Players.LocalPlayer:GetAttributeChangedSignal("LightMode"):Connect(lightClouds)
task.defer(lightClouds)

local function recolorClouds(weatherId)
	local color = K.CLOUD_COLORS[weatherId] or K.CLOUD_COLORS.Clear
	for _, c in ipairs(clouds) do
		for _, p in ipairs(c.model:GetChildren()) do
			TweenService:Create(p, TweenInfo.new(K.TINT_SECONDS), { Color = color }):Play()
		end
	end
end

-- ---------------------------------------------------------------------------
-- Flying reptiles
-- ---------------------------------------------------------------------------

local flyers = {} -- { model, rig, center, radius, height, angle, speed, direction }

-- a pterosaur model for the sky: wrapped in a fresh model with an upright pivot (an imported pivot
-- can be turned), bigger than life; nil without the species' model
local function makeFlyer(speciesId)
	local models = ReplicatedStorage:FindFirstChild("DinoModels")
	local source = models and models:FindFirstChild("Dino_" .. speciesId)
	if not source then
		return nil
	end
	local model = Instance.new("Model")
	model.Name = "Flyer"
	source:Clone().Parent = model
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
		end
	end
	local center = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(center.Position)
	model:ScaleTo(K.FLYER_SCALE)
	model.Parent = sky
	return model
end

task.spawn(function()
	if not ReplicatedStorage:WaitForChild("DinoModels", 30) then
		return
	end
	for _, speciesId in ipairs(K.FLYER_SPECIES) do
		local model = makeFlyer(speciesId)
		if model then
			table.insert(flyers, {
				model = model,
				rig = DinoMotion.new(model),
				center = Vector3.new(rng:NextNumber(-K.FLYER_CENTER_SPREAD, K.FLYER_CENTER_SPREAD), 0,
					rng:NextNumber(-K.FLYER_CENTER_SPREAD, K.FLYER_CENTER_SPREAD)),
				radius = between(K.FLYER_RADIUS),
				height = between(K.FLYER_HEIGHT),
				angle = rng:NextNumber(0, 2 * math.pi),
				speed = between(K.FLYER_SPEED),
				direction = rng:NextNumber() < 0.5 and 1 or -1,
			})
		end
	end
	local boned = 0
	for _, f in ipairs(flyers) do
		boned += f.rig.hasBones and 1 or 0
	end
	-- a flyer without bones only bobs and rocks: its model was imported without the rig
	print(string.format("[WeatherFx] 하늘의 익룡 %d마리 (날개 뼈 있음 %d마리)", #flyers, boned))
end)

-- ---------------------------------------------------------------------------
-- Weather: rain, tint, lightning, the weather line
-- ---------------------------------------------------------------------------

-- rain: thin falling streaks around the camera (parts moved together each frame with BulkMoveTo),
-- in rain and in a storm (more)
local drops = {} -- { part, position }
for _ = 1, math.max(K.RAIN_DROPS.Rain, K.RAIN_DROPS.Storm) do
	local drop = plainPart({ Name = "Drop", Size = K.RAIN_DROP_SIZE, Material = Enum.Material.SmoothPlastic,
		Color = K.RAIN_COLOR, Transparency = K.RAIN_DROP_TRANSPARENCY, CFrame = CFrame.new(0, K.HIDDEN_Y, 0), Parent = sky })
	table.insert(drops, { part = drop, position = nil })
end
local activeDrops = 0

local tint = Lighting:FindFirstChild("WeatherTint") or Instance.new("ColorCorrectionEffect")
tint.Name = "WeatherTint"
tint.Parent = Lighting

local gui = Instance.new("ScreenGui")
gui.Name = "Weather"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.DisplayOrder = 4
gui.Parent = player:WaitForChild("PlayerGui")
local lineGui = Instance.new("ScreenGui") -- under the top bar, like the defense line it sits below
lineGui.Name = "WeatherLine"
lineGui.ResetOnSpawn = false
lineGui.DisplayOrder = 4
lineGui.Parent = gui.Parent
local line = Instance.new("TextLabel")
line.AnchorPoint = Vector2.new(0.5, 0)
line.Position = UDim2.new(0.5, 0, 0, K.LINE_TOP)
line.Size = UDim2.fromOffset(260, 20)
line.BackgroundTransparency = 1
line.Font = Enum.Font.GothamBold
line.TextSize = 14
line.TextStrokeTransparency = 0.3
line.Visible = false
line.Parent = lineGui

-- how far down the line goes: under whatever shows at the top middle
local function lineTop()
	local playerGui = player:FindFirstChild("PlayerGui")
	local arena = playerGui and playerGui:FindFirstChild("ArenaLine")
	local fight = arena and arena.Enabled and arena:FindFirstChild("FightBar", true)
	if fight and fight.Visible then
		local inset = arena.IgnoreGuiInset and GuiService:GetGuiInset().Y or 0
		return math.max(K.LINE_TOP, fight.Position.Y.Offset + fight.Size.Y.Offset + K.LINE_GAP_FIGHT - inset)
	end
	local race = playerGui and playerGui:FindFirstChild("Race")
	local raceBar = race and race:FindFirstChild("RaceBar")
	if raceBar and raceBar.Visible then
		return K.LINE_TOP_RACE
	end
	local hideSeek = playerGui and playerGui:FindFirstChild("HideSeek") -- (2026-10-03) its bar is where the race bar is
	local hideBar = hideSeek and hideSeek:FindFirstChild("HideSeekBar")
	if hideBar and hideBar.Visible then
		return K.LINE_TOP_RACE
	end
	return K.LINE_TOP
end

local current = "Clear"
local nextStrike = 0

-- the place's own light and view, to go back to
local base = { Brightness = Lighting.Brightness, FogEnd = Lighting.FogEnd, FogColor = Lighting.FogColor,
	Exposure = Lighting.ExposureCompensation, ShadowSoftness = Lighting.ShadowSoftness }
local atmosphere = Lighting:FindFirstChildOfClass("Atmosphere")
if atmosphere then
	base.Density, base.Haze = atmosphere.Density, atmosphere.Haze
end
-- a huge sun by day, a huge moon and a sky full of stars by night (the day turns on the server's
-- Lighting.ClockTime, DayNight service); a Sky of our own on this screen when the place has none
local skyObject = Lighting:FindFirstChildOfClass("Sky")
if not skyObject then
	skyObject = Instance.new("Sky")
	skyObject.Parent = Lighting
end
skyObject.SunAngularSize = K.SUN_ANGULAR_SIZE
if K.SUN_TEXTURE ~= "" then
	skyObject.SunTextureId = K.SUN_TEXTURE
end
if atmosphere then
	atmosphere.Glare *= K.SUN_GLARE_SHARE
end
local sunRays = Lighting:FindFirstChildOfClass("SunRaysEffect")
if sunRays and not sunRays:GetAttribute("Softened") then -- (once, like the glare above)
	sunRays.Intensity *= K.SUN_RAYS_SHARE
	sunRays:SetAttribute("Softened", true)
end
skyObject.MoonAngularSize = K.MOON_ANGULAR_SIZE
skyObject.StarCount = K.STAR_COUNT
skyObject.CelestialBodiesShown = true
base.SunSize = skyObject.SunAngularSize
local deck = plainPart({ Name = "CloudDeck", Size = K.DECK_SIZE, Material = Enum.Material.SmoothPlastic,
	Color = K.DECK_COLOR.Clear, Transparency = 1, Parent = sky })
local deckMesh = Instance.new("SpecialMesh")
deckMesh.MeshType = Enum.MeshType.Cylinder
deckMesh.Scale = K.DECK_MESH_SCALE
deckMesh.Parent = deck

-- how much of the bad weather's darkening applies now: all of it by day, a little at night
local function dimShare()
	return ReplicatedStorage:GetAttribute("Night") == true and K.NIGHT_DIM_SHARE or 1
end

-- the color correction for this weather now (its darkening eased at night)
local function tintFor(id)
	local t = K.TINT[id] or K.TINT.Clear
	if t.Brightness >= 0 then
		return t
	end
	return { Brightness = t.Brightness * dimShare(), Saturation = t.Saturation, TintColor = t.TintColor }
end

local function applyView(id)
	local info = TweenInfo.new(K.TINT_SECONDS)
	local share = dimShare()
	TweenService:Create(Lighting, info, { Brightness = base.Brightness * (1 - (1 - (K.LIGHT[id] or 1)) * share),
		ExposureCompensation = base.Exposure + (K.EXPOSURE[id] or 0) * share,
		ShadowSoftness = K.SHADOW_SOFTNESS[id] or base.ShadowSoftness }):Play()
	TweenService:Create(deck, info, { Transparency = 1 - (1 - (K.DECK_TRANSPARENCY[id] or 1)) * share,
		Color = K.DECK_COLOR[id] or K.DECK_COLOR.Clear }):Play()
	if skyObject then
		TweenService:Create(skyObject, info, { SunAngularSize = base.SunSize * (K.SUN_SIZE[id] or 1) }):Play()
	end
	local cinematic = player:GetAttribute("Cinematic") == true
	if atmosphere then -- fog settings do nothing while an Atmosphere is there
		TweenService:Create(atmosphere, info, cinematic and { Density = base.Density * K.CINEMA_HAZE, Haze = 0 } or {
			Density = math.min(1, base.Density + (K.HAZE_DENSITY[id] or 0) * share),
			Haze = base.Haze + (K.HAZE_HAZE[id] or 0) * share }):Play()
	else
		TweenService:Create(Lighting, info, { FogEnd = cinematic and base.FogEnd or math.min(base.FogEnd, K.FOG_END[id] or base.FogEnd),
			FogColor = (K.FOG_END[id] and not cinematic) and K.FOG_COLOR or base.FogColor }):Play()
	end
end

-- the rain heard: one loop per kind of weather, faded in for the current one and out for the others
K.LOOPS = { Rain = "RainLoop", Storm = "StormLoop" }
local loops = {} -- [weather id] = Sound
local function applyRainSound(id)
	for weatherId, name in pairs(K.LOOPS) do
		local sound = loops[weatherId]
		if weatherId == id and not sound then
			sound = Sfx.loop(name)
			loops[weatherId] = sound
		end
		if sound then
			TweenService:Create(sound, TweenInfo.new(K.RAIN_SOUND_FADE), { Volume = weatherId == id and Sfx.volume(name) or 0 }):Play()
		end
	end
end

-- the rainbow: one giant arc over the northern sky, built once, faded in for the rainbow sky and out
-- otherwise
local rainbowParts = {}
local function makeRainbow()
	local model = Instance.new("Model")
	model.Name = "Rainbow"
	for band, color in ipairs(K.RAINBOW_COLORS) do
		local r = K.RAINBOW_RADIUS - (band - 0.5) * K.RAINBOW_BAND
		local step = math.pi / K.RAINBOW_SEGMENTS
		for i = 0, K.RAINBOW_SEGMENTS - 1 do
			local a = (i + 0.5) * step
			local p = plainPart({ Name = "Band", Size = Vector3.new(r * step * 1.04, K.RAINBOW_BAND, 2), Material = Enum.Material.Neon,
				Color = color, Transparency = 1, CastShadow = false,
				CFrame = CFrame.new(math.cos(a) * r, math.sin(a) * r, 0) * CFrame.Angles(0, 0, a - math.pi / 2),
				Parent = model })
			table.insert(rainbowParts, p)
		end
	end
	model.WorldPivot = CFrame.new()
	model.Parent = sky
	return model
end
local rainbow = makeRainbow()

-- the aurora: built once, waved and faded in for the aurora (see AURORA_*)
local aurora = Instance.new("Model")
aurora.Name = "Aurora"
local auroraSlabs = {} -- { part, curtain, column, top }
for c = 1, K.AURORA_CURTAINS do
	for i = 1, K.AURORA_COLUMNS do
		for top = 0, 1 do
			local slab = plainPart({ Name = "Light", Size = Vector3.new(K.AURORA_WIDTH / K.AURORA_COLUMNS * 1.15,
				K.AURORA_HEIGHT[top + 1], 2), Material = Enum.Material.Neon, Color = K.AURORA_COLORS[top + 1], Transparency = 1,
				CastShadow = false, Parent = aurora })
			table.insert(auroraSlabs, { part = slab, curtain = c, column = i, top = top })
		end
	end
end
aurora.WorldPivot = CFrame.new()
aurora.Parent = sky
local auroraLevel, auroraOn = 0, false

-- each frame while it shows: the curtains ripple and shimmer around the camera's northern sky
local function waveAurora(eye, dt)
	local target = auroraOn and 1 or 0
	auroraLevel += math.clamp(target - auroraLevel, -dt / K.AURORA_FADE, dt / K.AURORA_FADE)
	if auroraLevel <= 0 and not auroraOn then
		return
	end
	local t = os.clock() * K.AURORA_WAVE_SPEED
	for _, s in ipairs(auroraSlabs) do
		local k = (s.column - 0.5) / K.AURORA_COLUMNS - 0.5
		local place = K.AURORA_PLACES[s.curtain]
		local turn = CFrame.Angles(0, -math.rad(place[1]), 0)
		local x = k * K.AURORA_WIDTH
		local z = -place[2] + math.sin(k * 5 + t * 2 + s.curtain) * K.AURORA_WAVE
		local y = place[3] + s.top * (K.AURORA_HEIGHT[1] + K.AURORA_HEIGHT[2]) / 2 + math.sin(k * 9 + t * 3) * 12
		s.part.CFrame = CFrame.new(eye) * turn * CFrame.new(x, y, z) * CFrame.Angles(0, math.sin(k * 6 + t) * 0.5, 0)
		local shimmer = K.AURORA_SHIMMER * (0.5 + 0.5 * math.sin(t * 7 + s.column * 0.9 + s.curtain))
		s.part.Transparency = 1 - auroraLevel * (1 - K.AURORA_SHOWN - shimmer + (s.top == 1 and 0.12 or 0))
	end
end
local rainbowOut = false
local function showRainbow(on)
	if on == rainbowOut then
		return
	end
	rainbowOut = on
	for _, p in ipairs(rainbowParts) do
		TweenService:Create(p, TweenInfo.new(K.RAINBOW_FADE), { Transparency = on and K.RAINBOW_SHOWN or 1 }):Play()
	end
end

-- the milky way: built once, shown at night (ReplicatedStorage attribute Night)
local milky = Instance.new("Model")
milky.Name = "MilkyWay"
local milkyStars, milkyGlows = {}, {}
local glowOffsets = {} -- [glow] = its place from the camera
local glowHidden = {} -- [glow] = true while the scenery is in front of it
do
	-- the band: a great circle turned by MILKY_TILT, stars scattered across it (thicker in the middle)
	local u = Vector3.new(1, 0, 0)
	local v = Vector3.new(0, math.cos(K.MILKY_TILT), math.sin(K.MILKY_TILT))
	local n = u:Cross(v)
	for _ = 1, K.MILKY_STARS do
		local a = rng:NextNumber(0, math.pi) -- the half above the horizon
		local off = (rng:NextNumber() - 0.5) * (rng:NextNumber() + rng:NextNumber()) * K.MILKY_WIDTH
		local p = (u * math.cos(a) + v * math.sin(a)) * K.MILKY_RADIUS + n * off
		local size = rng:NextNumber(1, 3) -- (2026-10-04: was 0.8-2.6, half as many now)
		-- (2026-10-04: a block, not a ball: a few pixels across 600 studs off either way, far fewer triangles to draw)
		local star = plainPart({ Name = "Star", Shape = Enum.PartType.Block, Size = Vector3.one * size,
			Material = Enum.Material.Neon, Color = K.MILKY_COLORS[rng:NextInteger(1, #K.MILKY_COLORS)], Transparency = 1,
			CFrame = CFrame.new(p), Parent = milky })
		table.insert(milkyStars, { part = star, bright = rng:NextNumber(0, 0.4), dim = 0.5, offset = p })
	end
	-- the rest of the sky: evenly over the dome above SKY_STAR_LOW
	for k = 1, K.SKY_STARS + K.BRIGHT_STARS do
		local big = k > K.SKY_STARS
		local around = rng:NextNumber(0, 2 * math.pi)
		local up = math.asin(rng:NextNumber(math.sin(K.SKY_STAR_LOW), 1)) -- (even over the dome, not crowded at the top)
		local p = Vector3.new(math.cos(up) * math.cos(around), math.sin(up), math.cos(up) * math.sin(around)) * K.MILKY_RADIUS
		local range = big and K.BRIGHT_STAR_SIZE or K.SKY_STAR_SIZE
		local star = plainPart({ Name = "Star", Shape = big and Enum.PartType.Ball or Enum.PartType.Block, -- (the small ones blocks)
			Size = Vector3.one * rng:NextNumber(range[1], range[2]),
			Material = Enum.Material.Neon, Color = big and K.MILKY_COLORS[1] or K.MILKY_COLORS[rng:NextInteger(1, #K.MILKY_COLORS)],
			Transparency = 1, CFrame = CFrame.new(p), Parent = milky })
		table.insert(milkyStars, { part = star, bright = big and 0 or rng:NextNumber(0, K.SKY_STAR_DIM), dim = big and 0.1 or K.SKY_STAR_DIM,
			offset = p })
	end
	for k = 1, K.MILKY_GLOWS do
		local a = (k - 0.5) / K.MILKY_GLOWS * math.pi
		local p = (u * math.cos(a) + v * math.sin(a)) * (K.MILKY_RADIUS + 30)
		local glow = plainPart({ Name = "Glow", Shape = Enum.PartType.Ball, Size = Vector3.one * rng:NextNumber(60, 100),
			Material = Enum.Material.Neon, Color = K.MILKY_GLOW_COLOR, Transparency = 1, CFrame = CFrame.new(p), Parent = milky })
		table.insert(milkyGlows, glow)
		glowOffsets[glow] = p
	end
end
milky.WorldPivot = CFrame.new()
milky.Parent = sky
local milkyOn, milkyLevel = false, 0 -- 0 hidden ... 1 fully shown
local milkyAt = nil -- where the camera was when the milky way last followed it
local milkyMovedAt = 0 -- os.clock() of that
local fadeNext, fadeLevel = nil, 0
local cloudSlice = 0
local cullNext = nil -- the next star (index; past the stars: the glows) to look at, nil when all are done
local culledFrom = nil -- where the camera was for the last look over every star
local cullRay = RaycastParams.new()
cullRay.FilterType = Enum.RaycastFilterType.Include
local cullScenery = nil -- (the folder the rays look for; set once it is there)

-- a star's (or glow's) brightness now: hidden behind the scenery, or the night's level
local function starTransparency(s)
	return s.hidden and 1 or 1 - milkyLevel * (1 - s.bright)
end

-- (2026-10-03, "아직 별이 바깥 배경 안으로 들어온다": the far scenery, the mountains, the volcano, the waterfall and
-- their trees, is built with CanQuery off (nothing to look for out there), and a ray passes through such a part:
-- only the invisible walls at the map's edge hid any star) on this screen alone the scenery can be found by a ray
-- again, as it streams in; each new piece looks at every star again
local function queryable(d)
	if d:IsA("BasePart") and not d.CanQuery then
		d.CanQuery = true
		culledFrom = nil -- (looked at again from wherever the camera is)
		if milkyOn then
			cullNext = 1
		end
	end
end

-- look at the next few stars: is the scenery between the camera and each?
local function cullStars(eye)
	if not cullScenery or not cullScenery.Parent then
		local map = Workspace:FindFirstChild("Map")
		cullScenery = map and map:FindFirstChild("Boundary")
		if not cullScenery then
			cullNext = nil
			return
		end
		cullRay.FilterDescendantsInstances = { cullScenery }
		for _, d in ipairs(cullScenery:GetDescendants()) do
			queryable(d)
		end
		cullScenery.DescendantAdded:Connect(queryable)
		cullNext = 1
	end
	local total = #milkyStars + #milkyGlows
	for _ = 1, K.STAR_CULL_PER_FRAME do
		local i = cullNext
		if not i or i > total then
			cullNext = nil
			return
		end
		cullNext = i + 1
		if i <= #milkyStars then
			local s = milkyStars[i]
			local hidden = Workspace:Raycast(eye, s.offset.Unit * K.STAR_CULL_REACH, cullRay) ~= nil
			if hidden ~= (s.hidden == true) then
				s.hidden = hidden
				s.part.Transparency = starTransparency(s)
			end
		else
			local g = milkyGlows[i - #milkyStars]
			local hidden = Workspace:Raycast(eye, glowOffsets[g].Unit * K.STAR_CULL_REACH, cullRay) ~= nil
			if hidden ~= (glowHidden[g] == true) then
				glowHidden[g] = hidden or nil
				g.Transparency = hidden and 1 or 1 - milkyLevel * 0.12
			end
		end
	end
end

-- the view setting "날씨 효과" off (player attribute HideWeather, Settings: less lag on weak phones): no
-- rain, lightning, rainbow, aurora, milky way, cloud deck or darkening on this screen; the sounds, the
-- weather line and the weather's game effects stay
local function weatherFxOff()
	-- (2026-10-04, "지연도 확실히 해결해") 🍃 light mode too (StarterPlayerScripts/LightMode): the stars at night are thousands
	return player:GetAttribute("HideWeather") == true or player:GetAttribute("LightMode") == true
end

local function shownWeather()
	if player:GetAttribute("HideWeather") == true then
		return "Clear"
	elseif player:GetAttribute("LightMode") == true then
		return K.RAIN_DROPS_LIGHT[current] and current or "Clear"
	end
	return current
end

local function applyWeather()
	current = ReplicatedStorage:GetAttribute("Weather") or "Clear"
	local shown = shownWeather()
	applyRainSound(current)
	showRainbow(shown == "RainbowSky")
	auroraOn = shown == "Aurora"
	local w = Formulas.weather(current)
	activeDrops = (player:GetAttribute("LightMode") == true and K.RAIN_DROPS_LIGHT or K.RAIN_DROPS)[shown] or 0
	for i = activeDrops + 1, #drops do -- the unused ones out of sight
		drops[i].position = nil
		drops[i].part.CFrame = CFrame.new(0, K.HIDDEN_Y, 0)
	end
	TweenService:Create(tint, TweenInfo.new(K.TINT_SECONDS), tintFor(shown)):Play()
	recolorClouds(shown)
	applyView(shown)
	line.TextColor3 = w.Rgb and Color3.fromRGB(table.unpack(w.Rgb)) or K.NIGHT_LINE_COLOR
	nextStrike = os.clock() + between(K.LIGHTNING_EVERY)
end
ReplicatedStorage:GetAttributeChangedSignal("Weather"):Connect(applyWeather)
player:GetAttributeChangedSignal("HideWeather"):Connect(applyWeather)
player:GetAttributeChangedSignal("LightMode"):Connect(applyWeather)
player:GetAttributeChangedSignal("Cinematic"):Connect(applyWeather)
applyWeather()
-- nightfall and dawn: the same weather darkens less (night) or fully (day)
ReplicatedStorage:GetAttributeChangedSignal("Night"):Connect(function()
	local shown = shownWeather()
	TweenService:Create(tint, TweenInfo.new(K.TINT_SECONDS), tintFor(shown)):Play()
	applyView(shown)
end)

-- a bolt down to `ground`, the sky flashing, thunder after `thunderDelay`
local function bolt(ground, thunderDelay)
	local bolt = Instance.new("Model")
	bolt.Name = "Lightning"
	local from = Vector3.new(ground.X, K.LIGHTNING_TOP, ground.Z)
	for i = 1, K.LIGHTNING_SEGMENTS do
		local t = i / K.LIGHTNING_SEGMENTS
		local to = Vector3.new(ground.X, K.LIGHTNING_TOP * (1 - t), ground.Z)
		if i < K.LIGHTNING_SEGMENTS then
			to += Vector3.new(rng:NextNumber(-K.LIGHTNING_JITTER, K.LIGHTNING_JITTER), 0, rng:NextNumber(-K.LIGHTNING_JITTER, K.LIGHTNING_JITTER))
		end
		local length = (to - from).Magnitude
		plainPart({ Size = Vector3.new(0.8, 0.8, length), CFrame = CFrame.lookAt((from + to) / 2, to), Material = Enum.Material.Neon,
			Color = K.LIGHTNING_COLOR, Parent = bolt })
		from = to
	end
	bolt.Parent = sky
	task.delay(thunderDelay, Sfx.play, "Thunder")
	tint.Brightness = K.FLASH_BRIGHTNESS
	TweenService:Create(tint, TweenInfo.new(K.LIGHTNING_SECONDS * 2),
		{ Brightness = tintFor(shownWeather()).Brightness }):Play() -- (;bolt: any weather)
	task.delay(K.LIGHTNING_SECONDS, function()
		bolt:Destroy()
	end)
end

local function strike(cameraPosition) -- a far-off one, only to be seen
	local angle = rng:NextNumber(0, 2 * math.pi)
	local r = rng:NextNumber(K.LIGHTNING_NEAR, K.LIGHTNING_RANGE)
	bolt(Vector3.new(cameraPosition.X + math.cos(angle) * r, 0, cameraPosition.Z + math.sin(angle) * r),
		r / K.LIGHTNING_RANGE * 0.6) -- farther strikes are heard a little later
end

-- the server's bolt (Lightning service): a crackling ring on the ground for warnSeconds (get out!), then
-- the bolt, the thunder right away, sparks and a scorch mark; whoever stood in the ring is thrown
Net.onPush("Lightning", function(x, y, z, warnSeconds, radius)
	local ground = Vector3.new(x, y, z)
	local camera = Workspace.CurrentCamera
	if camera and (camera.CFrame.Position - ground).Magnitude > K.STRIKE_DRAW_DISTANCE then -- (shown even with the weather hidden: it throws)
		return
	end
	local ring = plainPart({ Name = "LightningWarn", Shape = Enum.PartType.Cylinder,
		Size = Vector3.new(K.WARN_THICKNESS, radius * 2, radius * 2),
		CFrame = CFrame.new(ground + Vector3.new(0, 0.1, 0)) * CFrame.Angles(0, 0, math.rad(90)),
		Material = Enum.Material.Neon, Color = K.WARN_COLOR, Transparency = 0.75, Parent = sky })
	TweenService:Create(ring, TweenInfo.new(warnSeconds / 4, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
		{ Transparency = 0.4 }):Play()
	Fx.burst(ground + Vector3.new(0, 0.5, 0), K.SPARKS, 8, 6, 0.3, 0.4)
	task.delay(warnSeconds, function()
		ring:Destroy()
		bolt(ground, 0)
		Fx.burst(ground + Vector3.new(0, 1, 0), K.SPARKS, 30, 22, 0.5, 0.6)
		local scorch = plainPart({ Name = "Scorch", Shape = Enum.PartType.Cylinder, Size = Vector3.new(0.1, radius, radius),
			CFrame = CFrame.new(ground + Vector3.new(0, 0.06, 0)) * CFrame.Angles(0, 0, math.rad(90)),
			Material = Enum.Material.SmoothPlastic, Color = K.SCORCH_COLOR, Transparency = 0.35, Parent = sky })
		TweenService:Create(scorch, TweenInfo.new(K.SCORCH_SECONDS), { Transparency = 1 }):Play()
		task.delay(K.SCORCH_SECONDS, function()
			scorch:Destroy()
		end)
	end)
end)

-- ---------------------------------------------------------------------------
-- Every frame
-- ---------------------------------------------------------------------------

-- a pterosaur in the sky: round its circle by dt, wings beating
local function flyerStep(f, dt)
	f.angle += f.direction * f.speed / f.radius * dt
	local pos = f.center + Vector3.new(math.cos(f.angle) * f.radius, f.height + math.sin(f.angle * 3) * 3,
		math.sin(f.angle) * f.radius)
	local tangent = Vector3.new(-math.sin(f.angle), 0, math.cos(f.angle)) * f.direction
	local place = CFrame.lookAt(pos, pos + tangent) * CFrame.Angles(0, 0, K.FLYER_BANK * f.direction)
	f.model:PivotTo(place * DinoMotion.fly(f.rig, dt))
	f.pos = pos
end

K.LINE_EVERY = 0.25 -- seconds between rewrites of the weather line
local lineIn = 0
local rainParts, rainFrames = {}, {}
local lightOn = Players.LocalPlayer:GetAttribute("LightMode") == true
Players.LocalPlayer:GetAttributeChangedSignal("LightMode"):Connect(function()
	lightOn = Players.LocalPlayer:GetAttribute("LightMode") == true
end)
RunService.RenderStepped:Connect(FrameMeter.wrap("WeatherFx", function(dt)
	local camera = Workspace.CurrentCamera
	local eye = camera and camera.CFrame.Position or Vector3.zero
	-- the milky way: fades with the night, follows the camera like the sky does, stars twinkle
	local wantMilky = ReplicatedStorage:GetAttribute("Night") == true and current ~= "Storm" and not weatherFxOff()
	milkyLevel = math.clamp(milkyLevel + (wantMilky and 1 or -1) * dt / K.MILKY_FADE, 0, 1)
	if milkyLevel > 0 or milkyOn or fadeNext or milkyLevel ~= fadeLevel then
		milkyOn = milkyLevel > 0
		if not milkyAt or (eye - milkyAt).Magnitude > K.MILKY_FOLLOW and os.clock() - milkyMovedAt >= K.MILKY_FOLLOW_GAP then
			milkyAt = eye
			milkyMovedAt = os.clock()
			milky:PivotTo(CFrame.new(eye))
			if not culledFrom or (eye - culledFrom).Magnitude > K.STAR_CULL_MOVE then
				culledFrom = eye
				cullNext = 1 -- (looked at again from here)
			end
		end
		if cullNext then
			cullStars(milkyAt)
		end
		if milkyLevel ~= fadeLevel and not fadeNext then
			fadeNext, fadeLevel = 1, milkyLevel
			for _, g in ipairs(milkyGlows) do
				g.Transparency = glowHidden[g] and 1 or 1 - milkyLevel * 0.12
			end
		end
		if fadeNext then
			local last = math.min(#milkyStars, fadeNext + K.MILKY_FADE_PER_FRAME - 1)
			for i = fadeNext, last do
				local s = milkyStars[i]
				s.part.Transparency = starTransparency(s)
			end
			fadeNext = last < #milkyStars and last + 1 or nil
		end
		for _ = 1, K.TWINKLE_PER_FRAME do -- a few stars change brightness each frame
			local s = milkyStars[rng:NextInteger(1, #milkyStars)]
			s.bright = rng:NextNumber(0, s.dim)
			s.part.Transparency = starTransparency(s)
		end
	end

	waveAurora(eye, dt)
	if rainbowOut then -- stays in the northern sky wherever the player goes
		rainbow:PivotTo(CFrame.new(eye.X, eye.Y - K.RAINBOW_DROP, eye.Z - K.RAINBOW_DISTANCE))
	end

	cloudSlice = cloudSlice % K.CLOUD_SLICES + 1
	local cloudNow = os.clock()
	local cloudParts, cloudFrames = {}, {}
	for i = cloudSlice, #clouds, K.CLOUD_SLICES do
		local c = clouds[i]
		if c.hidden then
			continue
		end
		local p = c.position + K.CLOUD_WIND * (cloudNow - (c.movedAt or cloudNow - dt))
		c.movedAt = cloudNow
		local around = camera and camera.CFrame.Position or Vector3.zero
		local dx, dz = p.X - around.X, p.Z - around.Z
		if dx > K.CLOUD_SPREAD then
			p -= Vector3.new(2 * K.CLOUD_SPREAD, 0, 0)
		elseif dx < -K.CLOUD_SPREAD then
			p += Vector3.new(2 * K.CLOUD_SPREAD, 0, 0)
		end
		if dz > K.CLOUD_SPREAD then
			p -= Vector3.new(0, 0, 2 * K.CLOUD_SPREAD)
		elseif dz < -K.CLOUD_SPREAD then
			p += Vector3.new(0, 0, 2 * K.CLOUD_SPREAD)
		end
		c.position = p
		local at = CFrame.new(p) * c.turn
		for k, part in ipairs(c.parts) do
			table.insert(cloudParts, part)
			table.insert(cloudFrames, at * c.offsets[k])
		end
	end
	if #cloudParts > 0 then
		Workspace:BulkMoveTo(cloudParts, cloudFrames, Enum.BulkMoveMode.FireCFrameChanged)
	end

	local flyerCount = lightOn and math.min(#flyers, K.LIGHT_FLYERS) or #flyers
	for i, f in ipairs(flyers) do
		local shown = i <= flyerCount
		if f.shown ~= shown then
			f.shown = shown
			f.model.Parent = shown and sky or nil
		end
		if not shown then
			continue
		end
		-- (2026-10-02, the lag pass) far ones move less often (Shared/Lod), by the time that passed
		-- (2026-10-04, "또 렉있는 거 같은데 빡세게 최적화": measured to its circle's nearest point, which was close for most of
		-- the 20 (big circles round the camera): nearly all moved every frame) measured to where it is
		local due, step = Lod.due(f, ((f.pos or f.center) - eye).Magnitude, dt)
		if due then
			flyerStep(f, step)
		end
	end

	if activeDrops > 0 then
		local parts, frames = rainParts, rainFrames
		for i = activeDrops + 1, #parts do
			parts[i], frames[i] = nil, nil
		end
		local fall = (Vector3.new(0, -1, 0) + K.RAIN_SLANT) * K.RAIN_SPEED * dt
		for i = 1, activeDrops do
			local d = drops[i]
			local p = d.position
			if not p or p.Y < eye.Y + K.RAIN_BOTTOM or math.abs(p.X - eye.X) > K.RAIN_RANGE or math.abs(p.Z - eye.Z) > K.RAIN_RANGE then
				p = Vector3.new(eye.X + rng:NextNumber(-K.RAIN_RANGE, K.RAIN_RANGE),
					eye.Y + rng:NextNumber(K.RAIN_BOTTOM, K.RAIN_TOP), eye.Z + rng:NextNumber(-K.RAIN_RANGE, K.RAIN_RANGE))
			else
				p += fall
			end
			d.position = p
			parts[i] = d.part
			frames[i] = CFrame.new(p) * K.RAIN_TURN
		end
		Workspace:BulkMoveTo(parts, frames, Enum.BulkMoveMode.FireCFrameChanged)
	end
	if deck.Transparency < 1 then -- the cloud deck stays overhead wherever the camera goes
		deck.CFrame = CFrame.new(eye.X, K.DECK_HEIGHT, eye.Z) * K.DECK_TURN
	end
	if current == "Storm" and os.clock() >= nextStrike and shownWeather() == "Storm" then
		nextStrike = os.clock() + between(K.LIGHTNING_EVERY)
		strike(eye)
	end
	-- the weather line: the weather (not clear), the night and the boss's day buff, each with its time left
	-- (2026-10-04, "날씨 때 지연": worked out and written every frame) LINE_EVERY seconds apart (its seconds count down)
	lineIn -= dt
	if lineIn > 0 then
		return
	end
	lineIn = K.LINE_EVERY
	local isNight = ReplicatedStorage:GetAttribute("Night") == true
	local dayBuff = Config.DayBuffs[ReplicatedStorage:GetAttribute("DayBuff") or ""] -- the boss's gift for the day
	line.Visible = current ~= "Clear" or isNight or dayBuff ~= nil
	line.Position = UDim2.new(0.5, 0, 0, lineTop())
	if line.Visible then
		local parts = {}
		if current ~= "Clear" then
			local w = Formulas.weather(current)
			local left = math.max(0, math.ceil((ReplicatedStorage:GetAttribute("WeatherUntil") or 0) - Workspace:GetServerTimeNow()))
			table.insert(parts, string.format("%s %s · 디펜스 x%g · 채굴 x%g · 이동 x%g · %d초", w.Icon, w.Name,
				w.DefenseMoneyMultiplier, w.MiningYieldMultiplier, w.MoveSpeedMultiplier or 1, left))
		end
		if isNight then
			local left = math.max(0, math.ceil((ReplicatedStorage:GetAttribute("PhaseEndsAt") or 0) - Workspace:GetServerTimeNow()))
			table.insert(parts, string.format("🌙 밤 · 채굴 x%g · 좀비 조심 · %d:%02d", Config.DayNight.NightMiningYield,
				left // 60, left % 60))
		end
		if dayBuff then
			local left = math.max(0, math.ceil((ReplicatedStorage:GetAttribute("DayBuffEndsAt") or 0) - Workspace:GetServerTimeNow()))
			table.insert(parts, string.format("👑 보스 버프 · %s +%d%% · %d:%02d", dayBuff.Name,
				math.floor((dayBuff.Multiplier - 1) * 100 + 0.5), left // 60, left % 60))
		end
		line.Text = table.concat(parts, "  |  ")
		line.Size = UDim2.fromOffset(#parts > 1 and K.LINE_WIDE or K.LINE_NARROW, 20)
	end
end))

-- ---------------------------------------------------------------------------
-- Pterosaur droppings (Poop service): a shadow grows where it will land while it falls; it bursts
-- on the ground and is gone
-- ---------------------------------------------------------------------------

-- the pterosaur that drops it: flies straight in along heading at the dropping's height, over the spot
-- when it lets go (after approach seconds), then on and up and away
local bombers = {} -- { model, rig, release (CFrame at the letting go), start (os.clock) , approach }
local function sendBomber(release, heading, approach)
	local species = K.BOMBER_SPECIES[math.floor(heading * 1000) % #K.BOMBER_SPECIES + 1]
	local model = makeFlyer(species)
	if not model then
		return
	end
	local dir = Vector3.new(math.cos(heading), 0, math.sin(heading))
	local b = { model = model, rig = DinoMotion.new(model), release = release, dir = dir, start = os.clock(),
		approach = approach, screeched = false }
	table.insert(bombers, b)
end

RunService.Heartbeat:Connect(FrameMeter.wrap("WeatherFx", function(dt)
	for i = #bombers, 1, -1 do
		local b = bombers[i]
		local t = os.clock() - b.start - b.approach -- < 0 flying in, > 0 leaving
		if t > K.BOMBER_LEAVE then
			b.model:Destroy()
			table.remove(bombers, i)
		else
			local pos = b.release + b.dir * (K.BOMBER_SPEED * t) + Vector3.new(0, math.max(0, t) * K.BOMBER_CLIMB, 0)
			local ahead = b.dir + Vector3.new(0, t > 0 and K.BOMBER_CLIMB / K.BOMBER_SPEED or 0, 0)
			b.model:PivotTo(CFrame.lookAt(pos, pos + ahead) * DinoMotion.fly(b.rig, dt))
			if not b.screeched and t > -K.BOMBER_SCREECH_BEFORE then
				b.screeched = true
				Sfx.play("VoiceScreech", pos, 1 + math.random() * 0.15)
			end
		end
	end
end))

-- a player hit by a dropping (StunReason "Poop", StunnedUntil in server time; MoveGuard) stands buried
-- up to the chest in a poop pile until the stun ends; everyone sees it
local piles = {} -- [player] = the pile model
local function makePile(ground)
	return PoopPile.make(ground, sky) -- (Shared/PoopPile, the zombies' piles too)
end
local sincePiles = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("WeatherFx", function(dt)
	sincePiles += dt
	if sincePiles < K.PILE_CHECK_EVERY then
		return
	end
	sincePiles = 0
	local now = Workspace:GetServerTimeNow()
	for _, p in ipairs(Players:GetPlayers()) do
		local character = p.Character
		local root = character and character:FindFirstChild("HumanoidRootPart")
		local humanoid = character and character:FindFirstChildOfClass("Humanoid")
		local buried = root and humanoid and p:GetAttribute("StunReason") == "Poop" and (p:GetAttribute("StunnedUntil") or 0) > now
		if buried and not piles[p] then
			local ground = root.Position - Vector3.new(0, humanoid.HipHeight + root.Size.Y / 2, 0)
			piles[p] = makePile(ground)
		elseif not buried and piles[p] then
			piles[p]:Destroy()
			piles[p] = nil
		end
	end
	for p, pile in pairs(piles) do
		if not p.Parent then
			pile:Destroy()
			piles[p] = nil
		end
	end
end))

Net.onPush("Poop", function(x, y, z, fallSeconds, height, approach, heading)
	local landing = Vector3.new(x, y, z)
	local camera = Workspace.CurrentCamera
	if camera and (camera.CFrame.Position - landing).Magnitude > K.POOP_DRAW_DISTANCE then
		return
	end
	approach = approach or 0
	sendBomber(landing + Vector3.new(0, height, 0), heading or 0, approach)
	task.wait(approach) -- it lets go right over the spot
	local shadow = plainPart({ Name = "PoopShadow", Shape = Enum.PartType.Cylinder, Size = Vector3.new(0.1, 0.5, 0.5),
		CFrame = CFrame.new(landing + Vector3.new(0, 0.08, 0)) * CFrame.Angles(0, 0, math.rad(90)),
		Material = Enum.Material.SmoothPlastic, Color = Color3.new(0, 0, 0), Transparency = 0.6, Parent = sky })
	TweenService:Create(shadow, TweenInfo.new(fallSeconds), { Size = Vector3.new(0.1, K.POOP_SHADOW, K.POOP_SHADOW) }):Play()
	local drop = plainPart({ Name = "Poop", Shape = Enum.PartType.Ball, Size = Vector3.one * K.POOP_SIZE,
		Material = Enum.Material.SmoothPlastic, Color = K.POOP_COLOR, CFrame = CFrame.new(landing + Vector3.new(0, height, 0)),
		Parent = sky })
	local top = plainPart({ Shape = Enum.PartType.Ball, Size = Vector3.one * K.POOP_SIZE * 0.6, Material = Enum.Material.SmoothPlastic,
		Color = K.POOP_COLOR, CFrame = drop.CFrame * CFrame.new(0, K.POOP_SIZE * 0.45, 0), Parent = drop })
	local weld = Instance.new("WeldConstraint")
	weld.Part0, weld.Part1 = drop, top
	weld.Parent = drop
	top.Anchored = false
	TweenService:Create(drop, TweenInfo.new(fallSeconds, Enum.EasingStyle.Quad, Enum.EasingDirection.In),
		{ CFrame = CFrame.new(landing + Vector3.new(0, K.POOP_SIZE / 2, 0)) }):Play()
	task.delay(fallSeconds, function()
		drop:Destroy()
		shadow:Destroy()
		Fx.burst(landing + Vector3.new(0, 0.5, 0), { K.POOP_COLOR, Color3.fromRGB(150, 100, 60) }, 24, 16, 0.6, 0.6)
		Sfx.play("Splat", landing)
	end)
end)
