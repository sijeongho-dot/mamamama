local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local FrameMeter = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("FrameMeter"))

local FOLDERS = { "FieldGrass", "SafeGrass" }
local CELL = 48
local DRAW_RADIUS = 170
local KEEP_RADIUS = 210
local LOW_SHARE = 0.65
local LOOK_EVERY = 0.4
local BUILD_PER_FRAME = 24
local DATA_WAIT = 60
local XZ_STEP = 0.05
local Y_STEP = 0.02
local SCALE_STEP = 0.02
local SCALE_BUCKET = 0.1
local RECORD = 9
local DIGITS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local FLOWER_SHARE = 0.3
local FLOWER_MOST = 3
local FLOWER_HEIGHT = { 0.9, 1.4 }
local FLOWER_HEAD = 0.42
local FLOWER_SPREAD = 0.45
local FLOWER_STEM = 0.12
local STEM_COLOR = Color3.fromRGB(96, 178, 70)
local FLOWER_COLORS = {
	Color3.fromRGB(255, 120, 170), Color3.fromRGB(250, 248, 240), Color3.fromRGB(170, 110, 235),
	Color3.fromRGB(235, 70, 70), Color3.fromRGB(110, 180, 255), Color3.fromRGB(255, 160, 60),
	Color3.fromRGB(255, 220, 70),
}

local player = Players.LocalPlayer
local data = ReplicatedStorage:FindFirstChild("GrassData") or ReplicatedStorage:WaitForChild("GrassData", DATA_WAIT)
if not data then
	return
end
while not data:GetAttribute("Ready") do
	data:GetAttributeChangedSignal("Ready"):Wait()
end
local map = Workspace:FindFirstChild("Map") or Workspace:WaitForChild("Map", DATA_WAIT)
if not map then
	return
end

local lookup = {}
for i = 1, #DIGITS do
	lookup[string.byte(DIGITS, i)] = i - 1
end
local function decode(text)
	local out = table.create(#text // 4)
	for i = 1, #text - 3, 4 do
		local a, b, c, d = string.byte(text, i, i + 3)
		local n = lookup[a] * 262144 + lookup[b] * 4096 + lookup[c] * 64 + lookup[d]
		table.insert(out, string.char(n // 65536, n // 256 % 256, n % 256))
	end
	return table.concat(out)
end

local templates = {}
for _, t in ipairs(data:WaitForChild("Templates"):GetChildren()) do
	local index = tonumber(t.Name)
	if index and t:IsA("Model") then
		templates[index] = { model = t, part = t:GetAttribute("Part") == true, scaled = {} }
		for _, d in ipairs(t:GetDescendants()) do
			if d:IsA("BasePart") then
				d.CastShadow = false
			end
		end
	end
end

local folders = {}
local cells = {}
local function cellOf(x, z)
	local ix, iz = math.floor(x / CELL), math.floor(z / CELL)
	local key = ix * 65536 + iz
	local cell = cells[key]
	if not cell then
		cell = { x = (ix + 0.5) * CELL, z = (iz + 0.5) * CELL, items = {}, models = nil, queued = false }
		cells[key] = cell
	end
	return cell
end

local count = 0
for _, name in ipairs(FOLDERS) do
	local folder = map:FindFirstChild(name)
	if not folder or folder:GetAttribute("Built") == nil then
		folder = Instance.new("Folder")
		folder.Name = name
		folder:SetAttribute("Built", true)
		folder.Parent = map
	end
	folders[name] = folder
	local chunk = 0
	while true do
		chunk += 1
		local value = data:FindFirstChild(name .. "_" .. chunk)
		if not value then
			break
		end
		local bytes = decode(value.Value)
		for at = 1, #bytes - RECORD + 1, RECORD do
			local t, x, y, z, yaw, s = string.unpack("<BhhhBB", bytes, at)
			count += 1
			local rec = { i = count, t = t, x = x * XZ_STEP, y = y * Y_STEP, z = z * XZ_STEP, yaw = yaw * 2 * math.pi / 256,
				s = s * SCALE_STEP, folder = folder }
			table.insert(cellOf(rec.x, rec.z).items, rec)
		end
	end
end

local function scaledTemplate(t, s)
	if t.part then
		return t.model
	end
	local bucket = math.max(1, math.floor(s / SCALE_BUCKET + 0.5))
	local m = t.scaled[bucket]
	if not m then
		m = t.model:Clone()
		m:ScaleTo(bucket * SCALE_BUCKET)
		t.scaled[bucket] = m
	end
	return m
end

local function part(props)
	local p = Instance.new("Part")
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
	for k, v in pairs(props) do
		p[k] = v
	end
	return p
end

local function flowers(model, rec)
	local rng = Random.new(rec.i)
	if rng:NextNumber() >= FLOWER_SHARE then
		return
	end
	local s = rec.s
	local color = FLOWER_COLORS[rng:NextInteger(1, #FLOWER_COLORS)]
	for _ = 1, rng:NextInteger(1, FLOWER_MOST) do
		local a, r = rng:NextNumber(0, 2 * math.pi), rng:NextNumber() * FLOWER_SPREAD * s
		local at = Vector3.new(rec.x + math.cos(a) * r, rec.y, rec.z + math.sin(a) * r)
		local h = (FLOWER_HEIGHT[1] + rng:NextNumber() * (FLOWER_HEIGHT[2] - FLOWER_HEIGHT[1])) * s
		part({ Name = "FlowerStem", Size = Vector3.new(FLOWER_STEM, h, FLOWER_STEM), CFrame = CFrame.new(at + Vector3.new(0, h / 2, 0)),
			Color = STEM_COLOR, Parent = model })
		local head = FLOWER_HEAD * (0.8 + rng:NextNumber() * 0.4) * math.sqrt(s)
		part({ Name = "Flower", Shape = Enum.PartType.Ball, Size = Vector3.one * head,
			CFrame = CFrame.new(at + Vector3.new(0, h + head * 0.3, 0)), Color = color, Parent = model })
	end
end

local function build(rec)
	local t = templates[rec.t]
	if not t then
		return nil
	end
	local model = scaledTemplate(t, rec.s):Clone()
	model:PivotTo(CFrame.new(rec.x, rec.y, rec.z) * CFrame.Angles(0, rec.yaw, 0))
	flowers(model, rec)
	model.Parent = rec.folder
	return model
end

local queue = {}
local function clear(cell)
	cell.queued = false
	if cell.models then
		for _, m in ipairs(cell.models) do
			m:Destroy()
		end
		cell.models = nil
	end
end

local lookAt = -math.huge
RunService.Heartbeat:Connect(FrameMeter.wrap("GrassField", function()
	local now = os.clock()
	if now - lookAt >= LOOK_EVERY then
		lookAt = now
		local camera = Workspace.CurrentCamera
		local eye = camera and camera.CFrame.Position
		local light = player:GetAttribute("LightMode") == true
		local share = player:GetAttribute("LowDetail") and LOW_SHARE or 1
		for _, cell in pairs(cells) do
			local d = eye and math.sqrt((cell.x - eye.X) ^ 2 + (cell.z - eye.Z) ^ 2) or math.huge
			if not light and d <= DRAW_RADIUS * share then
				if not cell.models and not cell.queued then
					cell.queued = true
					cell.next = 1
					cell.models = {}
					table.insert(queue, cell)
				end
			elseif (cell.models or cell.queued) and (light or d > KEEP_RADIUS * share) then
				clear(cell)
			end
		end
	end
	local budget = BUILD_PER_FRAME
	while budget > 0 and #queue > 0 do
		local cell = queue[1]
		if not cell.queued then
			table.remove(queue, 1)
		else
			local rec = cell.items[cell.next]
			if rec then
				local model = build(rec)
				if model then
					table.insert(cell.models, model)
				end
				cell.next += 1
				budget -= 1
			else
				cell.queued = false
				table.remove(queue, 1)
			end
		end
	end
end))
