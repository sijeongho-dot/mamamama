--[[
Translate: the English and Spanish versions on this screen (2026-10-02; Shared/Lang, Shared/LangEn, LangEs).
The game's code writes Korean; while this player plays in another language (Lang.code: English by default,
한국어 or Español picked in the settings) every Korean text that shows is put in it as it comes: labels and buttons on the
screen (PlayerGui), signs and labels in the world (BillboardGuis and SurfaceGuis in the Workspace), a text
box's grey hint, and the words on Roblox's press prompts (ProximityPrompt). The Korean is kept
(Lang.remember) so code that looks for its own words (the tutorial's finger) still finds them, and so
switching language puts it in the new one (or back in Korean) at once.
A label with the attribute KeepText is left as it is (the language button: each name in its own language).

Fitting (2026-10-02, "번역본이 틀에 맞도록 언어를 바꾸면 틀들도 알아서 조정되게, 어쩔 수 없는 경우에만"): the
English is written to fit (tools/lang/make.py), and only where it still doesn't (the label's TextFits is
false) its writing gets smaller, a step a frame, down to MIN_SHARE of its size (at least MIN_TEXT); still too
long, it shrinks to fit the box (TextScaled, never bigger than it was). Back in 한국어 every label gets
its own size again. Boxes themselves never move or grow (the layout stays as it is).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Lang = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Lang"))
local WorldWatch = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("WorldWatch"))
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)

-- display only
local MIN_SHARE = 0.75 -- writing shrinks to at most this share of its own size before it scales to the box
local MIN_TEXT = 9 -- pixels: never smaller than this by stepping

local player = Players.LocalPlayer

local function keepPlayer(p)
	Lang.keep(p.DisplayName)
	Lang.keep(p.Name)
end
Players.PlayerAdded:Connect(keepPlayer)
for _, p in ipairs(Players:GetPlayers()) do
	keepPlayer(p)
end

local HttpService = game:GetService("HttpService")
local function keepNames(value, depth)
	if type(value) ~= "table" or depth > 4 then
		return
	end
	if type(value.Name) == "string" then
		Lang.keep(value.Name)
	end
	for _, v in pairs(value) do
		keepNames(v, depth + 1)
	end
end
local function keepFrom(name)
	local value = ReplicatedStorage:GetAttribute(name)
	if type(value) == "string" and (string.sub(value, 1, 1) == "[" or string.sub(value, 1, 1) == "{") then
		local ok, data = pcall(HttpService.JSONDecode, HttpService, value)
		if ok then
			keepNames(data, 0)
		end
	end
end
ReplicatedStorage.AttributeChanged:Connect(keepFrom)
for name in pairs(ReplicatedStorage:GetAttributes()) do
	keepFrom(name)
end

local PROPS = {
	TextLabel = { "Text" },
	TextButton = { "Text" },
	TextBox = { "PlaceholderText" },
	ProximityPrompt = { "ActionText", "ObjectText" },
}

local code = Lang.code(player) -- "en" / "ko" / "es"
local korean = setmetatable({}, { __mode = "k" }) -- [obj] = { [prop] = the Korean the code wrote }
local shown = setmetatable({}, { __mode = "k" }) -- [obj] = { [prop] = the English put there }
local hooked = setmetatable({}, { __mode = "k" })
local own = setmetatable({}, { __mode = "k" }) -- [label] = { size, scaled, constraint }: before any fitting
local fitting = {} -- [label] = true: checked a frame at a time

local function fits(obj)
	local ok, result = pcall(function()
		return obj.TextFits
	end)
	return not ok or result ~= false
end

local function fit(obj)
	if obj:IsA("TextLabel") or obj:IsA("TextButton") then
		if not obj.TextScaled or (own[obj] and own[obj].constraint) then
			fitting[obj] = true
		end
	end
end

-- its own size back (한국어)
local function unfit(obj)
	local o = own[obj]
	if o then
		own[obj] = nil
		obj.TextSize, obj.TextScaled = o.size, o.scaled
		if o.constraint then
			o.constraint:Destroy()
		end
	end
	fitting[obj] = nil
end

RunService.Heartbeat:Connect(FrameMeter.wrap("Translate", function()
	for obj in pairs(fitting) do
		if not obj.Parent or code == "ko" then
			fitting[obj] = nil
		elseif obj.AbsoluteSize.X > 0 and not fits(obj) then
			local o = own[obj]
			if not o then
				o = { size = obj.TextSize, scaled = obj.TextScaled }
				own[obj] = o
			end
			local floor = math.max(MIN_TEXT, math.floor(o.size * MIN_SHARE))
			if not obj.TextScaled and obj.TextSize > floor then
				obj.TextSize -= 1
			else -- (no room even so: fit the box, never bigger than it was)
				if not o.constraint then
					o.constraint = Instance.new("UITextSizeConstraint")
					o.constraint.MaxTextSize = o.size
					o.constraint.Parent = obj
				end
				obj.TextScaled = true
				fitting[obj] = nil
			end
		else
			fitting[obj] = nil
		end
	end
end))

local function apply(obj, prop)
	local value = obj[prop]
	local mine = shown[obj] and shown[obj][prop]
	if value == mine then
		return -- (our own English coming back as a change)
	end
	if not Lang.hasHangul(value) then
		if korean[obj] then
			korean[obj][prop] = nil
		end
		if prop == "Text" then
			Lang.remember(obj, nil) -- (no Korean behind it now: Lang.set compares with what shows)
		end
		return
	end
	korean[obj] = korean[obj] or {}
	korean[obj][prop] = value
	if prop == "Text" then
		Lang.remember(obj, value)
	end
	if code ~= "ko" then
		local en = Lang.t(value, code)
		if en ~= value then
			shown[obj] = shown[obj] or {}
			shown[obj][prop] = en
			obj[prop] = en
			if prop == "Text" then
				fit(obj)
			end
		end
	end
end

local function hook(obj)
	local props = PROPS[obj.ClassName]
	if not props or hooked[obj] or obj:GetAttribute("KeepText") then
		return
	end
	hooked[obj] = true
	for _, prop in ipairs(props) do
		apply(obj, prop)
		obj:GetPropertyChangedSignal(prop):Connect(function()
			apply(obj, prop)
		end)
	end
end

local function added(d)
	if PROPS[d.ClassName] then
		task.defer(hook, d) -- (after its maker has set it up: KeepText, its first text)
	elseif d:IsA("GuiBase2d") and #d:GetChildren() > 0 then -- (a frame put up whole: its labels too)
		task.defer(function()
			for _, x in ipairs(d:GetDescendants()) do
				hook(x)
			end
		end)
	end
end

local function watch(root)
	for _, d in ipairs(root:GetDescendants()) do
		hook(d)
	end
	root.DescendantAdded:Connect(added)
end

-- the language switched: everything shown again in it
local function relanguage()
	code = Lang.code(player)
	for obj in pairs(hooked) do
		local ko = korean[obj]
		if ko and obj.Parent then
			for prop, value in pairs(ko) do
				if code ~= "ko" then
					local en = Lang.t(value, code)
					if prop == "Text" then
						unfit(obj) -- (its own size first: the new words are fitted again)
					end
					shown[obj] = shown[obj] or {}
					shown[obj][prop] = en
					obj[prop] = en
					if prop == "Text" then
						fit(obj)
					end
				else
					if shown[obj] then
						shown[obj][prop] = nil
					end
					obj[prop] = value
					unfit(obj)
				end
			end
		end
	end
end

player:GetAttributeChangedSignal("Language"):Connect(relanguage)
watch(player:WaitForChild("PlayerGui"))
WorldWatch.listen({ "GuiBase2d", "ProximityPrompt" }, function(d, existing)
	if existing then
		hook(d)
	else
		added(d)
	end
end)
