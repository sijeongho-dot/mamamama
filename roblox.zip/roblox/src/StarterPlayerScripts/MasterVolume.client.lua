--[[
MasterVolume: the "🔊 전체 소리" bar of 보기 설정 (player attribute MasterVolume, 0 to 1, saved by the
Settings service; 2026-10-01). Display only, this player's screen.

Every sound this screen plays goes through one SoundGroup "MasterVolume" in SoundService whose Volume is the
bar: a sound with no group joins it, and a sound that has its own group keeps it, that group moving
under this one (groups inside groups multiply). Sounds that come later (effects, voices, characters'
footsteps) join as they appear.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local SoundService = game:GetService("SoundService")

local WorldWatch = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("WorldWatch"))

local player = Players.LocalPlayer

local master = Instance.new("SoundGroup")
master.Name = "MasterVolume"
master.Parent = SoundService

local function volume()
	local v = player:GetAttribute("MasterVolume")
	return type(v) == "number" and math.clamp(v, 0, 1) or 1
end
master.Volume = volume()
player:GetAttributeChangedSignal("MasterVolume"):Connect(function()
	master.Volume = volume()
end)

local function join(d)
	if not d:IsA("Sound") then
		return
	end
	local group = d.SoundGroup
	if group == nil then
		d.SoundGroup = master
	elseif group ~= master and group.Parent ~= master and not group:IsDescendantOf(master) then
		group.Parent = master
	end
end

for _, root in ipairs({ SoundService, player:WaitForChild("PlayerGui") }) do
	for _, d in ipairs(root:GetDescendants()) do
		join(d)
	end
	root.DescendantAdded:Connect(join)
end
WorldWatch.listen({ "Sound" }, join)
