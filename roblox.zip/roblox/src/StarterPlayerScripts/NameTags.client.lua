local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local WorldWatch = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("WorldWatch"))

local TAG_SIZE = UDim2.fromScale(11.4, 1.57)
local TAG_UP = 1.2
local TAG_DISTANCE = 100
local TAG_COLOR = Color3.new(1, 1, 1)
local NONE = Enum.HumanoidDisplayDistanceType.None

local player = Players.LocalPlayer
local tags = setmetatable({}, { __mode = "k" })
local seen = setmetatable({}, { __mode = "k" })
local want = setmetatable({}, { __mode = "k" })

local function nameOf(humanoid)
	local model = humanoid.Parent
	return humanoid.DisplayName ~= "" and humanoid.DisplayName or (model and model.Name) or ""
end

local function anchorOf(humanoid)
	local model = humanoid.Parent
	return model and (model:FindFirstChild("Head") or model:FindFirstChild("HumanoidRootPart")
		or model.PrimaryPart)
end

local function makeTag(humanoid)
	local tag = Instance.new("BillboardGui")
	tag.Name = "NameTag"
	tag.Size = TAG_SIZE
	tag.StudsOffsetWorldSpace = Vector3.new(0, TAG_UP, 0)
	tag.SizeOffset = Vector2.new(0, 0.5)
	tag.MaxDistance = TAG_DISTANCE
	tag.AlwaysOnTop = true
	tag.LightInfluence = 0
	local text = Instance.new("TextLabel")
	text.Name = "Label"
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBold
	text.TextScaled = true
	text.TextColor3 = TAG_COLOR
	text.TextStrokeTransparency = 0.3
	text:SetAttribute("KeepText", true)
	text.Text = nameOf(humanoid)
	text.Parent = tag
	return { gui = tag, text = text }
end

local function place(humanoid, show)
	want[humanoid] = show
	local t = tags[humanoid]
	local anchor = anchorOf(humanoid)
	if not anchor then
		return
	end
	if not t then
		t = makeTag(humanoid)
		tags[humanoid] = t
	end
	t.gui.Adornee = anchor
	t.gui.Enabled = show
	t.text.Text = nameOf(humanoid)
	if t.gui.Parent ~= anchor then
		t.gui.Parent = anchor
	end
end

local function watch(humanoid)
	if seen[humanoid] then
		return
	end
	seen[humanoid] = true
	local model = humanoid.Parent
	local own = model ~= nil and model == player.Character
	local wants = humanoid.DisplayDistanceType ~= NONE and not own
	humanoid.DisplayDistanceType = NONE
	humanoid.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
	if wants then
		place(humanoid, true)
	end
	humanoid:GetPropertyChangedSignal("DisplayDistanceType"):Connect(function()
		if humanoid.DisplayDistanceType ~= NONE then
			humanoid.DisplayDistanceType = NONE
			if not own then
				place(humanoid, true)
			end
		end
	end)
	if not model then
		return
	end
	humanoid:GetPropertyChangedSignal("DisplayName"):Connect(function()
		local t = tags[humanoid]
		if t then
			t.text.Text = nameOf(humanoid)
		end
	end)
	model.ChildAdded:Connect(function(child)
		if child.Name == "Head" and child:IsA("BasePart") and want[humanoid] then
			place(humanoid, true)
		end
	end)
end

WorldWatch.listen({ "Humanoid" }, function(humanoid, existing)
	if existing then
		watch(humanoid)
	else
		task.defer(function()
			if humanoid.Parent then
				watch(humanoid)
			end
		end)
	end
end)
