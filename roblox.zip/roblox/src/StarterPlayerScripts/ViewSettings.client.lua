--[[
ViewSettings: "설정" (right edge; "보기 설정" before 2026-10-01) opens switches (two columns) that hide things on this screen to
cut lag: my dinos on the platform and on the farm, my fossils, other players' (the same three), the
mineral names, the wild dinos, the rarity auras, the weather effects, the farm dinos' labels (FarmBuff over
each farm dino, from the Farm service: turned off here on this screen). Each switch sends
SetSetting(name, on); the server saves it and mirrors it as a player attribute, which
StarterPlayerScripts/DefenseView follows.
Two sound bars (2026-10-01, at the end of the right column; the music's on/off switch was here): 🎵 배경음악
(MusicVolume, StarterPlayerScripts/Music) and 🔊 전체 소리 (MasterVolume, every sound:
StarterPlayerScripts/MasterVolume). Press or drag along a bar: the sound follows at once (the attribute is
set here too), and letting go sends SetVolume(name, 0..1) to be saved.
The last rows: 튜토리얼 다시 하기 (2026-10-02, "튜토리얼 다시보기 파트별로 가능하게": it opens a small window with
"📖 처음부터 전부" and each of Config.Tutorial.Parts; Net request TutorialReplay(part)) and the language; 📰 업데이트 소식 and 🐞 버그 신고 (2026-10-02, the closed
beta: Shared/BetaWindows).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))
local Lang = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Lang"))
local WorldWatch = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("WorldWatch"))
local LiveSet = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("LiveSet"))
local Unlock = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Unlock"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local OPEN_SIZE = UDim2.fromOffset(68, 36)
local OPEN_POS = UDim2.new(1, -12, 0, 86) -- right edge, above the "기지로" button (Hud); its middle
local COLUMNS = 2
local ROW_HEIGHT, ROW_GAP = 34, 5 -- (2026-10-01: were 38, 6; a 7th row for 농장 글씨)
local COLUMN_WIDTH, COLUMN_GAP = 186, 8
local PANEL_SIZE = UDim2.fromOffset(24 + COLUMNS * COLUMN_WIDTH + (COLUMNS - 1) * COLUMN_GAP, 44 + 13 * (ROW_HEIGHT + ROW_GAP) + 6) -- (PER_COLUMN + 2 rows: 튜토리얼 다시 하기, then the beta row)
local COLOR_NEWS = Color3.fromRGB(80, 130, 190)
local COLOR_FIXES = Color3.fromRGB(110, 120, 170)
local COLOR_REPORT = Color3.fromRGB(200, 110, 60)
local COLOR_REPLAY = Color3.fromRGB(90, 160, 140)
local COLOR_PART = Color3.fromRGB(60, 120, 110)
local COLOR_PART_DONE = Color3.fromRGB(95, 98, 110) -- (2026-10-04) a tutorial part already finished: gray, ✅ at the right
local COLOR_REWARD = Color3.fromRGB(215, 160, 40) -- (2026-10-04) "처음부터 전부" while its reward is still due
local PARTS_WIDTH = 300
local COLOR_LANGUAGE = Color3.fromRGB(70, 120, 200)
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_SHOWN = Color3.fromRGB(80, 190, 110)
local COLOR_HIDDEN = Color3.fromRGB(110, 110, 120)
local COLOR_OPEN = Color3.fromRGB(90, 100, 130)
local COLOR_CLOSE = Color3.fromRGB(235, 70, 80)
local SWITCHES = { -- left column: mine and others' on the bases; right: the rest
	{ "HideMyDinos", "🛡️ 내 디펜스 공룡" },
	{ "HideMyFarm", "🌿 내 농장 공룡" },
	{ "HideMyFossils", "🦴 내 화석" },
	{ "HideOtherDinos", "🛡️ 남의 디펜스 공룡" },
	{ "HideOtherFarm", "🌾 남의 농장 공룡" },
	{ "HideOtherFossils", "💀 남의 화석" },
	{ "HideMineralNames", "💎 광물 이름" },
	{ "HideWildlife", "🦕 야생 공룡" },
	{ "HideAuras", "✨ 공룡 오라", "끔", "켬" },
	{ "HideReach", "📏 내 공룡 사거리", "끔", "켬" }, -- [3]/[4]: words for on/off (default 숨김/보임)
	{ "HideWeather", "🌧️ 날씨 효과", "끔", "켬" },
	{ "HideFarmLabels", "🏷️ 농장 효과 글씨", "끔", "켬" },
	{ "HideTips", "🐣 코코의 팁", "끔", "켬" }, -- (2026-10-02)
	{ "HideNotices", "📢 왼쪽 알림", "끔", "켬" },
	{ "HideDefenseNotices", "🛡️ 디펜스 알림", "끔", "켬" },
	-- (2026-10-04, "위는 너 추천대로 다 해": a slow phone) StarterPlayerScripts/LightMode
	{ "LightMode", "🍃 가벼운 모드", "켬", "끔", true }, -- [5]: on is the green one
	-- (2026-10-04, "on off 넣어서 줄 안보이게 할지 선택도 가능하게") StarterPlayerScripts/MissionGuide
	{ "HideMissionGuide", "🧭 미션 길 안내", "끔", "켬" },
	-- (2026-10-04, "내 vip나 도감, 승패기록도 설정에서 키고 끌 수 있게 하자") the parts of the line over my head, for everyone
	-- (StarterPlayerScripts/Race recordLine)
	{ "HideMyVIP", "⭐ 내 머리 위 VIP", "끔", "켬" },
	{ "HideMyDex", "📖 내 머리 위 도감", "끔", "켬" },
	{ "HideMyRecord", "🏆 내 머리 위 승패", "끔", "켬" },
}
local BARS = { -- after the switches, in the same grid
	{ "MusicVolume", "🎵 배경음악" },
	{ "MasterVolume", "🔊 전체 소리" },
}
local COLOR_BAR_BACK = Color3.fromRGB(55, 60, 80)
local COLOR_BAR_FILL = Color3.fromRGB(90, 170, 240)
local COLOR_BAR_KNOB = Color3.fromRGB(240, 240, 250)
local BAR_TRACK_HEIGHT = 8
local BAR_KNOB = 18
local BAR_LABEL_WIDTH = 0.52 -- of the row: the name and %, then the bar
local PER_COLUMN = 11 -- (2026-10-04: 7, then 🍃 가벼운 모드, then 🧭 미션 길 안내)

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 16
	b.TextColor3 = Color3.new(1, 1, 1)
	b.Text = text
	b.BackgroundColor3 = color
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 10)
	return b
end

local gui = Instance.new("ScreenGui")
gui.Name = "ViewSettings"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local open = button(gui, "⚙️ 설정", COLOR_OPEN, OPEN_SIZE, OPEN_POS)
require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("SideButtons")).register(open) -- folds with the right column
open.TextSize = 13
open.TextWrapped = true
open.AnchorPoint = Vector2.new(1, 0.5)

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(1, 0.5)
panel.Position = UDim2.new(1, -170, 0.5, 0) -- left of the right edge columns (보기 설정, 기지로, 타기)
panel.Size = PANEL_SIZE
panel.BackgroundColor3 = COLOR_BG
panel.Visible = false
panel.Parent = gui
corner(panel, 14)
local title = Instance.new("TextLabel")
title.BackgroundTransparency = 1
title.Font = FONT
title.TextSize = 18
title.TextColor3 = Color3.new(1, 1, 1)
title.Text = "설정"
title.Size = UDim2.new(1, -50, 0, 36)
title.Position = UDim2.fromOffset(12, 4)
title.TextXAlignment = Enum.TextXAlignment.Left
title.Parent = panel
local close = button(panel, "X", COLOR_CLOSE, UDim2.fromOffset(32, 32), UDim2.new(1, -40, 0, 6))

local switches = {}
for i, s in ipairs(SWITCHES) do
	local row, column = (i - 1) % PER_COLUMN, (i - 1) // PER_COLUMN
	local b = button(panel, "", COLOR_SHOWN, UDim2.fromOffset(COLUMN_WIDTH, ROW_HEIGHT),
		UDim2.fromOffset(12 + column * (COLUMN_WIDTH + COLUMN_GAP), 44 + row * (ROW_HEIGHT + ROW_GAP)))
	b.TextSize = 14
	switches[s[1]] = { button = b, label = s[2] }
	b.Activated:Connect(function()
		local want = not player:GetAttribute(s[1])
		Net.request("SetSetting", s[1], want)
		if s[1] == "LightMode" then
			Net.request("SetSetting", "LightModeManual", want)
			player:SetAttribute("LightMode", want)
		end
	end)
	local function show()
		local hide = player:GetAttribute(s[1]) == true
		b.Text = string.format("%s: %s", s[2], hide and (s[3] or "숨김") or (s[4] or "보임"))
		b.BackgroundColor3 = (hide ~= (s[5] == true)) and COLOR_HIDDEN or COLOR_SHOWN
	end
	player:GetAttributeChangedSignal(s[1]):Connect(show)
	show()
end

-- the sound bars: the name and percent, then a bar to press or drag
for k, bar in ipairs(BARS) do
	local i = #SWITCHES + k
	local row, column = (i - 1) % PER_COLUMN, (i - 1) // PER_COLUMN
	local name = bar[1]
	local frame = Instance.new("Frame")
	frame.Size = UDim2.fromOffset(COLUMN_WIDTH, ROW_HEIGHT)
	frame.Position = UDim2.fromOffset(12 + column * (COLUMN_WIDTH + COLUMN_GAP), 44 + row * (ROW_HEIGHT + ROW_GAP))
	frame.BackgroundColor3 = COLOR_HIDDEN
	frame.Parent = panel
	corner(frame, 10)
	local text = Instance.new("TextLabel")
	text.BackgroundTransparency = 1
	text.Font = FONT
	text.TextSize = 13
	text.TextColor3 = Color3.new(1, 1, 1)
	text.TextXAlignment = Enum.TextXAlignment.Left
	text.Size = UDim2.new(BAR_LABEL_WIDTH, -8, 1, 0)
	text.Position = UDim2.fromOffset(8, 0)
	text.Parent = frame
	-- the touch area: the bar's half of the row, all its height (a finger needs room)
	local hit = Instance.new("TextButton")
	hit.Text = ""
	hit.BackgroundTransparency = 1
	hit.AutoButtonColor = false
	hit.Size = UDim2.new(1 - BAR_LABEL_WIDTH, -10, 1, 0)
	hit.Position = UDim2.fromScale(BAR_LABEL_WIDTH, 0)
	hit.Parent = frame
	local track = Instance.new("Frame")
	track.AnchorPoint = Vector2.new(0, 0.5)
	track.Size = UDim2.new(1, -BAR_KNOB, 0, BAR_TRACK_HEIGHT)
	track.Position = UDim2.new(0, BAR_KNOB / 2, 0.5, 0)
	track.BackgroundColor3 = COLOR_BAR_BACK
	track.Active = false
	track.Parent = hit
	corner(track, BAR_TRACK_HEIGHT // 2)
	local fill = Instance.new("Frame")
	fill.BackgroundColor3 = COLOR_BAR_FILL
	fill.Active = false
	fill.Parent = track
	corner(fill, BAR_TRACK_HEIGHT // 2)
	local knob = Instance.new("Frame")
	knob.AnchorPoint = Vector2.new(0.5, 0.5)
	knob.Size = UDim2.fromOffset(BAR_KNOB, BAR_KNOB)
	knob.BackgroundColor3 = COLOR_BAR_KNOB
	knob.Active = false
	knob.Parent = track
	corner(knob, BAR_KNOB // 2)
	local function value()
		local v = player:GetAttribute(name)
		return type(v) == "number" and math.clamp(v, 0, 1) or 1
	end
	local function show()
		local v = value()
		fill.Size = UDim2.fromScale(v, 1)
		knob.Position = UDim2.fromScale(v, 0.5)
		text.Text = string.format("%s %d%%", bar[2], math.floor(v * 100 + 0.5))
	end
	player:GetAttributeChangedSignal(name):Connect(show)
	show()
	local dragging = nil
	local function setFrom(x)
		local v = math.clamp((x - track.AbsolutePosition.X) / math.max(track.AbsoluteSize.X, 1), 0, 1)
		player:SetAttribute(name, math.floor(v * 20 + 0.5) / 20) -- heard at once; the server saves it on release
	end
	hit.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging = input
			setFrom(input.Position.X)
		end
	end)
	UserInputService.InputChanged:Connect(function(input)
		if dragging and (input == dragging or (dragging.UserInputType == Enum.UserInputType.MouseButton1
			and input.UserInputType == Enum.UserInputType.MouseMovement)) then
			setFrom(input.Position.X)
		end
	end)
	UserInputService.InputEnded:Connect(function(input)
		if dragging and (input == dragging or input.UserInputType == dragging.UserInputType) then
			dragging = nil
			Net.request("SetVolume", name, value())
		end
	end)
end

-- the last row: the tutorial again (only showing the way; Tutorial service), and the language
local replay = button(panel, "📖 튜토리얼 다시 하기", COLOR_REPLAY,
	UDim2.fromOffset(COLUMN_WIDTH, ROW_HEIGHT),
	UDim2.fromOffset(12, 44 + PER_COLUMN * (ROW_HEIGHT + ROW_GAP)))
-- (2026-10-02, the English version) the language now, in its own language (StarterPlayerScripts/LanguagePick)
local language = button(panel, "", COLOR_LANGUAGE, UDim2.fromOffset(COLUMN_WIDTH, ROW_HEIGHT),
	UDim2.fromOffset(12 + COLUMN_WIDTH + COLUMN_GAP, 44 + PER_COLUMN * (ROW_HEIGHT + ROW_GAP)))
language.TextSize = 15
language:SetAttribute("KeepText", true) -- (Translate leaves it: each name is in its own language)
local function showLanguage()
	language.Text = "🌐 " .. Lang.NAMES[Lang.code(player)]
end
player:GetAttributeChangedSignal("Language"):Connect(showLanguage)
showLanguage()
language.Activated:Connect(function()
	player:SetAttribute("LanguageMenu", true)
end)
-- (2026-10-02, the closed beta) the last row: the update news again, and the bug report (Shared/BetaWindows)
local BetaWindows = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("BetaWindows"))
local betaY = 44 + (PER_COLUMN + 1) * (ROW_HEIGHT + ROW_GAP)
local betaWidth = (COLUMNS * COLUMN_WIDTH + (COLUMNS - 1) * COLUMN_GAP - 3 * COLUMN_GAP) / 4
local betaButtons = {
	{ "📰 업데이트", COLOR_NEWS, function()
		BetaWindows.openNews(false, 1)
	end },
	{ "🔧 고친 것", COLOR_FIXES, function()
		BetaWindows.openNews(false, 2)
	end },
	{ "🐞 버그 신고", COLOR_REPORT, function()
		BetaWindows.openReport()
	end },
	{ "🎬 코코 이야기", COLOR_REPLAY, function()
		Net.request("ReplayIntro")
	end, "Story" },
}
local storyButton = nil
for k, b in ipairs(betaButtons) do
	local x = button(panel, b[1], b[2], UDim2.fromOffset(betaWidth, ROW_HEIGHT),
		UDim2.fromOffset(12 + (k - 1) * (betaWidth + COLUMN_GAP), betaY))
	x.TextSize = 14
	x.Activated:Connect(function()
		panel.Visible = false
		b[3]()
	end)
	if b[4] == "Story" then
		storyButton = x
	end
end
local function showStory()
	storyButton.Visible = Unlock.has("GameRooms") and player:GetAttribute("InTutorial") ~= true
		and ReplicatedStorage:GetAttribute("TutorialField") ~= true
end
Unlock.watch(showStory)
showStory()
replay.TextSize = 15
local function showReplay()
	local running = player:GetAttribute("TutorialStep") ~= nil or player:GetAttribute("TutorialTravel") == true
		or ReplicatedStorage:GetAttribute("TutorialField") == true -- (2026-10-03: on the field, or on the way there)
	-- (2026-10-04) 🎁 while the skipped first run's reward is still due (player attribute TutorialCoreDue)
	local due = player:GetAttribute("TutorialCoreDue") == true
	replay.Text = running and "📖 튜토리얼 하는 중" or due and "🎁 코코에게 배우기" or "📖 코코에게 배우기" -- (2026-10-03: was 튜토리얼 다시 하기)
	replay.BackgroundColor3 = running and COLOR_HIDDEN or due and COLOR_REWARD or COLOR_REPLAY
	replay.AutoButtonColor = not running
end
player:GetAttributeChangedSignal("TutorialStep"):Connect(showReplay)
player:GetAttributeChangedSignal("TutorialCoreDue"):Connect(showReplay)
player:GetAttributeChangedSignal("TutorialTravel"):Connect(showReplay)
showReplay()
-- the parts to replay: the whole, or one part
local partsPanel = Instance.new("Frame")
partsPanel.Name = "TutorialParts"
partsPanel.AnchorPoint = Vector2.new(0.5, 0.5)
partsPanel.Position = UDim2.fromScale(0.5, 0.5)
partsPanel.Size = UDim2.fromOffset(PARTS_WIDTH, 44 + (#Config.Tutorial.Parts + 1) * (ROW_HEIGHT + ROW_GAP) + 6)
partsPanel.BackgroundColor3 = COLOR_BG
partsPanel.Visible = false
partsPanel.Parent = gui
corner(partsPanel, 14)
do
	local partsTitle = title:Clone()
	partsTitle.Text = "📖 무엇을 다시 볼까요? (보상 없음)" -- (2026-10-03: the lessons' rewards are the missions' now)
	partsTitle.Parent = partsPanel
	local wholeButton = nil -- (2026-10-04) "처음부터 전부" pays the skipped first run's reward (player attribute TutorialCoreDue)
	local partsClose = button(partsPanel, "X", COLOR_CLOSE, UDim2.fromOffset(32, 32), UDim2.new(1, -40, 0, 6))
	partsClose.Activated:Connect(function()
		partsPanel.Visible = false
	end)
	local choices = { { nil, "📖 처음부터 전부" } }
	for _, part in ipairs(Config.Tutorial.Parts) do
		table.insert(choices, { part.Id, part.Name, part })
	end
	-- (2026-10-03) the lessons (Config.Tutorial.Parts Lesson): 🎁 while their reward is still to come
	-- (player attribute LessonsDue), ✅ once learned
	local marks = {}
	local rows = {} -- (2026-10-04) [i] = { button, its ✅ }
	for i, choice in ipairs(choices) do
		local b = button(partsPanel, choice[2], i == 1 and COLOR_REPLAY or COLOR_PART,
			UDim2.new(1, -24, 0, ROW_HEIGHT), UDim2.fromOffset(12, 44 + (i - 1) * (ROW_HEIGHT + ROW_GAP)))
		b.TextSize = 15
		if i == 1 then
			wholeButton = b
		end
		local tick = Instance.new("TextLabel")
		tick.AnchorPoint = Vector2.new(1, 0.5)
		tick.Position = UDim2.new(1, -6, 0.5, 0)
		tick.Size = UDim2.fromOffset(22, 22)
		tick.BackgroundTransparency = 1
		tick.Font = Enum.Font.GothamBold
		tick.TextSize = 16
		tick.Text = "✅"
		tick.Visible = false
		tick.Parent = b
		rows[i] = { b, tick }
		b.Activated:Connect(function()
			partsPanel.Visible = false
			if player:GetAttribute("TutorialStep") == nil then
				Net.request("TutorialReplay", choice[1])
			end
		end)
		if choice[3] and choice[3].Lesson and choice[3].Reward then -- (2026-10-03: none now, the missions teach them)
			marks[choice[1]] = b
		end
	end
	local function showMarks()
		local due = {}
		for id in string.gmatch(player:GetAttribute("LessonsDue") or "", "[^,]+") do
			due[id] = true
		end
		for _, choice in ipairs(choices) do
			local b = marks[choice[1]]
			if b then
				b.Text = (due[choice[1]] and "🎁 " or "✅ ") .. choice[2] -- (Translate puts it in the language)
			end
		end
	end
	-- (2026-10-04, "클리어한 튜토리얼 파트는 회색버튼으로") the parts finished (player attribute TutorialPartsDone): gray
	-- with ✅, still pressable to see again; the whole when every part is; gold while the first run's reward is due
	local function showDone()
		local done, all = {}, true
		for id in string.gmatch(player:GetAttribute("TutorialPartsDone") or "", "[^,]+") do
			done[id] = true
		end
		for i, choice in ipairs(choices) do
			if i > 1 then
				local finished = done[choice[1]] == true
				all = all and finished
				rows[i][1].BackgroundColor3 = finished and COLOR_PART_DONE or COLOR_PART
				rows[i][2].Visible = finished
			end
		end
		local due = player:GetAttribute("TutorialCoreDue") == true
		partsTitle.Text = due and "📖 무엇을 볼까요?" or "📖 무엇을 다시 볼까요? (보상 없음)"
		wholeButton.Text = due and "🎁 처음부터 전부 (보상 받기)" or "📖 처음부터 전부"
		wholeButton.BackgroundColor3 = due and COLOR_REWARD or all and COLOR_PART_DONE or COLOR_REPLAY
		rows[1][2].Visible = all and not due
	end
	player:GetAttributeChangedSignal("LessonsDue"):Connect(showMarks)
	showMarks()
	player:GetAttributeChangedSignal("TutorialCoreDue"):Connect(showDone)
	player:GetAttributeChangedSignal("TutorialPartsDone"):Connect(showDone)
	showDone()
end
replay.Activated:Connect(function()
	if replay.AutoButtonColor then
		panel.Visible = false
		partsPanel.Visible = true
	end
end)

open.Activated:Connect(function()
	panel.Visible = not panel.Visible
end)
close.Activated:Connect(function()
	panel.Visible = false
end)

-- Esc / Backspace / gamepad B closes the last opened window (Shared/Windows)
local Windows = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Windows"))
Windows.fit(panel) -- in the screen's free part, smaller on phones
Windows.register(panel)
Windows.fit(partsPanel)
Windows.register(partsPanel)

-- the farm dinos' labels (HideFarmLabels): every FarmBuff tag shown or not on this screen
local farmTags = LiveSet.new()
local function showFarmTag(tag)
	tag.Enabled = player:GetAttribute("HideFarmLabels") ~= true
end
local function watchTag(d)
	if d:IsA("BillboardGui") and d.Name == "FarmBuff" then
		farmTags:add(d)
		showFarmTag(d)
	end
end
WorldWatch.listen({ "BillboardGui" }, watchTag)
player:GetAttributeChangedSignal("HideFarmLabels"):Connect(function()
	farmTags:each(showFarmTag)
	if player:GetAttribute("HideFarmLabels") then -- a farm dino's talk bubble up now goes too (DefenseView)
		for _, d in ipairs(player:WaitForChild("PlayerGui"):GetChildren()) do
			if d:IsA("BillboardGui") and d.Name == "DinoChat" and d.Adornee and d.Adornee:FindFirstAncestor("FarmUnits") then
				d:Destroy()
			end
		end
	end
end)
