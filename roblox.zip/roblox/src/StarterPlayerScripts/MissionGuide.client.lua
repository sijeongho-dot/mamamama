--[[
MissionGuide (client): where the beginner mission at hand is done (design 10 초보 미션; the StarterMissions service sets
the player attributes MissionTarget (Vector3) or MissionButton (a button's text) from the mission's Guide / Button).
(2026-10-04, "처음 30초에 뭘 해야 할지 모름: 화살표나 짧은 안내가 없으면 바로 나가요" → "추천 다 적용해봐")

- MissionTarget: a glowing line from the player to the spot and a big bouncing ⬇️ over it (seen through walls), like the
  tutorial's.
- MissionButton: that button shines and a 👆 bounces under it (👇 over it when it sits low), as in the tutorial; the
  button is found by its Korean text (Shared/Lang.source: the same in English and Spanish).
- Nothing while the tutorial runs (TutorialStep), a window is open, a race is on, or keys are carried (the red arrow home
  is enough then), or 보기 설정 "🧭 미션 길 안내" is off (player attribute HideMissionGuide; 2026-10-04, "on off 넣어서 줄
  안보이게 할지 선택도 가능하게"). "Wild" (MissionGuideKind) is the nearest wild dino drawn here. A mission reached: the
  finger at the board (its MissionButton). Display only.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Lang = require(Shared:WaitForChild("Lang"))
local ScreenButtons = require(Shared:WaitForChild("ScreenButtons"))
local FoldHint = require(Shared:WaitForChild("FoldHint"))
local Windows = require(Shared:WaitForChild("Windows"))
local Unlock = require(Shared:WaitForChild("Unlock"))
local Coach = require(Shared:WaitForChild("Coach"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local Config = require(ReplicatedStorage:WaitForChild("Config"))

local player = Players.LocalPlayer

-- display only
local BEAM_COLOR = Color3.fromRGB(110, 230, 255)
local BEAM_WIDTH = 0.5
local ARROW_SIZE = UDim2.fromOffset(56, 56)
local ARROW_UP = 8 -- studs over the spot
local ARROW_BOUNCE, ARROW_SPEED = 1.2, 4
local FINGER_SIZE = UDim2.fromOffset(96, 96)
local FINGER_BOUNCE, FINGER_SPEED = 14, 5
local GLOW_PAD = 5
local GLOW_COLOR = Color3.fromRGB(255, 240, 150)
local BUTTON_LOOK_EVERY = 1 -- seconds between looks for the button (it may move or appear)
local DISPLAY_ORDER = Windows.ABOVE_WINDOWS
local DIM_COLOR = Color3.new(0, 0, 0)
local DIM_TRANSPARENCY = 0.45
local DIM_SECONDS = 6
local DIM_FADE = 1
local DIM_TOP_EXTRA = 80
local TAP_LOOK_EVERY = 0.25
local CAPTION_HEIGHT = 34
local CAPTION_TEXT = 18
local CAPTION_PAD = 12
local CAPTION_GAP = 4
local CAPTION_BACK = Color3.fromRGB(30, 30, 45)
local CAPTION_COLOR = Color3.fromRGB(255, 240, 150)
local SLAP_NEAR = 30
local SWIPE_SECONDS = 1.4
local SWIPE_FROM, SWIPE_TO = 0.78, 0.22
local SWIPE_MOVE = 0.75
local SWIPE_FINGERS = { Up = "👆", Down = "👇", Left = "👈", Right = "👉" }
local SWIPE_ANCHORS = { Up = Vector2.new(0.5, 0), Down = Vector2.new(0.5, 1), Left = Vector2.new(0, 0.5), Right = Vector2.new(1, 0.5) }
local SWIPE_WORDS = {
	Up = "⬆️ 위로 밀어서 더 보기",
	Down = "⬇️ 아래로 밀어서 더 보기",
	Left = "⬅️ 옆으로 밀어서 더 보기",
	Right = "➡️ 옆으로 밀어서 더 보기",
}
local CLOSE_AFTER = 1.5
local CLOSE_WORDS = "❌ 창을 닫아요"
local DISMOUNT_WORDS = "🚶 내려서 걸어가요! 하늘에선 미션을 못 해요"
local FINGER_ANCHOR = Vector2.new(0.5, 0)
local TAP_WORDS = {
	Slap = "👋 이 버튼으로 찰싹!",
	AutoPlace = "✨ 두 번 눌러요",
	DrawOne = "🎲 1번 뽑기",
	DrawOk = "✅ 확인 → 🎲 또 뽑기",
	BoxesButton = "📦 상자 보러 가기",
	BoxFree = "🎟️ 무료로 열기",
	BoxOpen = "📦 상자 열기",
	BoxOpenAll = "📦 상자 열기",
	BoxPill = "📦 여기서도 상자를 열어요",
	PillOpenAll = "📦 나머지 모두 열기",
	BoxOk = "✅ 확인",
	PlaceCard = "이 공룡 놓기",
	SkyCard = "🦅 하늘 공룡 놓기",
	SkyMove = "🦅 하늘 공룡 옮기기",
	PlaceOk = "✅ 여기에 놓기",
	PlaceSpot = "🎯 여기를 눌러 옮겨요",
	FarmCard = "🌾 농장에 넣기",
	KeyBuyTab = "🛒 사기 탭",
	KeyBuy = "🔑 열쇠 1개 사기",
	KeyTradeTab = "🔁 교환 탭",
	KeyTrade = "🔁 좋은 열쇠로 바꾸기",
	BuyPickaxe = "⛏️ 새 곡괭이 사기",
	MapPick = "🗺️ 이 맵 고르기",
	TopViewOn = "🗺️ 탑뷰 켜기",
	TopViewOff = "↩️ 이제 탑뷰 끄기",
	RewardTab = "🎁 받을 보상이 있는 탭",
	RewardClaim = "🎁 보상 받기",
	Aim = "🎯 누를 때마다 공격 대상이 바뀌어요",
	BombBuy = "💣 폭탄 1개 사기",
	BombEgg = "꾹 누르고 끌어서 겨눈 뒤 떼요",
	BombPoop = "꾹 누르고 끌어서 겨눈 뒤 떼요",
	MountPick = "🦖 탈 공룡 고르기",
	Ride = "🦖 눌러서 공룡 타기",
	RaceTab = "🏁 레이스 탭",
	RaceSolo = "🏃 혼자 달려 보기",
	RaceSoloSky = "🦅 하늘 레이스 혼자 달려 보기",
	RaceMount = "🦖 달릴 공룡 고르기",
	EnhanceTab = "⬆️ 강화 탭",
	EnhanceCard = "강화할 공룡 고르기",
	EnhanceFodder = "재료로 쓸 공룡 고르기",
	EnhanceAuto = "✨ 재료 자동으로 고르기",
	EnhanceGo = "⬆️ 강화하기!",
	FeedTab = "🍎 먹이 탭",
	FeedCard = "키울 공룡 고르기",
	FeedGo = "🍎 먹이 주기!",
	MergeTab = "🧬 합성 탭",
	MergeCard = string.format("같은 등급 %d마리 고르기", Config.Merge.Count),
	MergeGo = "🧬 합성하기!",
}

local gui = Instance.new("ScreenGui")
gui.Name = "MissionGuide"
gui.ResetOnSpawn = false
gui.DisplayOrder = DISPLAY_ORDER
gui.Parent = player:WaitForChild("PlayerGui")

local finger = Instance.new("TextLabel")
finger.AnchorPoint = Vector2.new(0.5, 0)
finger.Size = FINGER_SIZE
finger.BackgroundTransparency = 1
finger.Font = Enum.Font.GothamBlack
finger.TextScaled = true
finger.Text = "👆"
finger:SetAttribute("KeepText", true)
finger.Visible = false
finger.Parent = gui
local dims = {}
for i = 1, 4 do
	local d = Instance.new("Frame")
	d.BackgroundColor3 = DIM_COLOR
	d.BackgroundTransparency = 1
	d.BorderSizePixel = 0
	d.Active = false
	d.Visible = false
	d.ZIndex = 0
	d.Parent = gui
	dims[i] = d
end
local dimFor, dimSince = nil, 0
local caption = Instance.new("TextLabel")
caption.AnchorPoint = Vector2.new(0.5, 0)
caption.AutomaticSize = Enum.AutomaticSize.X
caption.Size = UDim2.fromOffset(0, CAPTION_HEIGHT)
caption.BackgroundColor3 = CAPTION_BACK
caption.BackgroundTransparency = 0.1
caption.Font = Enum.Font.GothamBlack
caption.TextSize = CAPTION_TEXT
caption.TextColor3 = CAPTION_COLOR
caption.ZIndex = 2
caption.Visible = false
caption.Parent = gui
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 10)
	round.Parent = caption
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, CAPTION_PAD), UDim.new(0, CAPTION_PAD)
	pad.Parent = caption
	local edge = Instance.new("UIStroke")
	edge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	edge.Color = CAPTION_COLOR
	edge.Thickness = 2
	edge.Parent = caption
end
local glow = Instance.new("Frame")
glow.BackgroundColor3 = GLOW_COLOR
glow.BackgroundTransparency = 0.75
glow.Active = false
glow.Visible = false
glow.Parent = gui
local glowRound = Instance.new("UICorner")
glowRound.CornerRadius = UDim.new(0, 12)
glowRound.Parent = glow
local glowEdge = Instance.new("UIStroke")
glowEdge.Color = GLOW_COLOR
glowEdge.Thickness = 3
glowEdge.Parent = glow

-- the line and the arrow
local beam, fromA, toA, arrow = nil, nil, nil, nil
local function clearBeam()
	for _, x in ipairs({ beam, fromA, toA, arrow }) do
		if x then
			x:Destroy()
		end
	end
	beam, fromA, toA, arrow = nil, nil, nil, nil
end
local function aim(root, spot)
	if not beam or fromA.Parent ~= root then
		clearBeam()
		fromA = Instance.new("Attachment")
		fromA.Parent = root
		toA = Instance.new("Attachment")
		toA.Parent = Workspace.Terrain
		beam = Instance.new("Beam")
		beam.Attachment0, beam.Attachment1 = fromA, toA
		beam.Color = ColorSequence.new(BEAM_COLOR)
		beam.Width0, beam.Width1 = BEAM_WIDTH, BEAM_WIDTH
		beam.FaceCamera = true
		beam.LightEmission = 1
		beam.Transparency = NumberSequence.new(0.2)
		beam.Parent = Workspace.Terrain
		arrow = Instance.new("BillboardGui")
		arrow.Size = ARROW_SIZE
		arrow.AlwaysOnTop = true
		arrow.Adornee = toA
		local a = Instance.new("TextLabel")
		a.Size = UDim2.fromScale(1, 1)
		a.BackgroundTransparency = 1
		a.TextScaled = true
		a.Text = "⬇️"
		a:SetAttribute("KeepText", true)
		a.Parent = arrow
		arrow.Parent = gui
	end
	toA.WorldPosition = spot + Vector3.new(0, 1.5, 0)
	arrow.StudsOffsetWorldSpace = Vector3.new(0, ARROW_UP + math.sin(os.clock() * ARROW_SPEED) * ARROW_BOUNCE, 0)
end

-- the button with that Korean text, shown on the screen (as the tutorial looks for one)
local buttonCache = { text = nil, button = nil, at = 0 }
local function findButton(text)
	local c = buttonCache
	if c.text == text and os.clock() - c.at < BUTTON_LOOK_EVERY and (not c.button or c.button.Parent) then
		return c.button
	end
	local best = ScreenButtons.find(function(d)
		return d.AbsoluteSize.X < 200 and string.find(Lang.source(d), text, 1, true) ~= nil
	end)
	c.text, c.button, c.at = text, best, os.clock()
	return best
end

local tapText, tapList = nil, {}
local tapCache = { at = -math.huge, button = nil, key = nil, lost = nil }
local function tapTarget(text)
	if text ~= tapText then
		tapText, tapList = text, {}
		for name in string.gmatch(type(text) == "string" and text or "", "[^,]+") do
			table.insert(tapList, name)
		end
		tapCache.at = -math.huge
	end
	if #tapList == 0 then
		return nil, nil, nil
	end
	local c = tapCache
	if os.clock() - c.at >= TAP_LOOK_EVERY or (c.button and not Coach.visible(c.button)) then
		c.button, c.key, c.lost = Coach.first(tapList)
		c.at = os.clock()
	end
	return c.button, c.key, c.lost
end

local GUIDES = { "MissionTaps", "MissionButton", "MissionTarget", "MissionGuideKind", "UnlockTarget", "UnlockButton" }
local function guiding()
	for _, name in ipairs(GUIDES) do
		if player:GetAttribute(name) ~= nil then
			return true
		end
	end
	return false
end

-- (2026-10-04) "Wild" (player attribute MissionGuideKind): the nearest wild dino drawn on this screen (Workspace.Wildlife,
-- StarterPlayerScripts/Wildlife), looked for every WILD_LOOK_EVERY seconds
local WILD_LOOK_EVERY = 1
local wildSpot, wildAt = nil, -math.huge
local function nearestWild(root)
	if os.clock() - wildAt < WILD_LOOK_EVERY then
		return wildSpot
	end
	wildAt = os.clock()
	local folder = Workspace:FindFirstChild("Wildlife")
	local best, bestD = nil, math.huge
	for _, m in ipairs(folder and folder:GetChildren() or {}) do
		if m:IsA("Model") then
			local at = m:GetPivot().Position
			local d = (at - root.Position).Magnitude
			if d < bestD and Unlock.reachable(at) then
				best, bestD = at, d
			end
		end
	end
	wildSpot = best
	return best
end

local BOX_LOOK_EVERY = 0.5
local boxSpot, boxAt = nil, -math.huge
local function nearestBox(root)
	if os.clock() - boxAt < BOX_LOOK_EVERY then
		return boxSpot
	end
	boxAt = os.clock()
	local keys = Workspace:FindFirstChild("Keys")
	local level = player:GetAttribute("DefenseLevel") or 1
	local mine, mineD, shared, sharedD = nil, math.huge, nil, math.huge
	for _, part in ipairs(keys and keys:GetChildren() or {}) do
		if part:IsA("BasePart") and part.Name == "AltarBox" then
			local owner = part:GetAttribute("OnlyFor")
			local d = (part.Position - root.Position).Magnitude
			if owner == player.UserId then
				if d < mineD then
					mine, mineD = part.Position, d
				end
			elseif owner == nil and d < sharedD and Formulas.boxPickable({ Rarity = part:GetAttribute("Rarity"),
				Grade = part:GetAttribute("Grade"), King = part:GetAttribute("King") }, level) then
				shared, sharedD = part.Position, d
			end
		end
	end
	boxSpot = mine or (not player:GetAttribute("InTutorial") and shared) or nil
	return boxSpot
end

local myDinoSpot, myDinoAt = nil, -math.huge
local function nearestMyDino(root)
	if os.clock() - myDinoAt < WILD_LOOK_EVERY then
		return myDinoSpot
	end
	myDinoAt = os.clock()
	local map = Workspace:FindFirstChild("Map")
	local folder = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	local units = folder and folder:FindFirstChild("DefenseUnits")
	local best, bestD = nil, math.huge
	for _, m in ipairs(units and units:GetChildren() or {}) do
		if m:IsA("Model") then
			local at = m:GetPivot().Position
			local d = (at - root.Position).Magnitude
			if d < bestD then
				best, bestD = at, d
			end
		end
	end
	myDinoSpot = best
	return best
end

local function billboardOf(obj)
	local node = obj.Parent
	while node and not node:IsA("LayerCollector") do
		node = node.Parent
	end
	return node ~= nil and node:IsA("BillboardGui") and node or nil
end

local function screenRect(obj)
	local bb = billboardOf(obj)
	if not bb then
		return obj.AbsolutePosition, obj.AbsoluteSize
	end
	local adornee = bb.Adornee or bb.Parent
	local at = nil
	if adornee and adornee:IsA("BasePart") then
		at = adornee.Position
	elseif adornee and adornee:IsA("Attachment") then
		at = adornee.WorldPosition
	elseif adornee and adornee:IsA("Model") then
		at = adornee:GetBoundingBox().Position
	end
	local camera = Workspace.CurrentCamera
	local canvasAt, canvas = bb.AbsolutePosition, bb.AbsoluteSize
	if not at or not camera or canvas.X <= 0 or canvas.Y <= 0 then
		return nil, nil
	end
	local look = camera.CFrame
	local lift = bb.StudsOffset
	at += bb.StudsOffsetWorldSpace + look.RightVector * lift.X + look.UpVector * lift.Y - look.LookVector * lift.Z
	local point = camera:WorldToScreenPoint(at)
	if point.Z <= 0 then
		return nil, nil
	end
	local perStud = camera.ViewportSize.Y / (2 * point.Z * math.tan(math.rad(camera.FieldOfView) / 2))
	local w = bb.Size.X.Scale * perStud + bb.Size.X.Offset
	local h = bb.Size.Y.Scale * perStud + bb.Size.Y.Offset
	local left = point.X - w / 2 + bb.SizeOffset.X * w
	local top = point.Y - h / 2 - bb.SizeOffset.Y * h
	local kx, ky = w / canvas.X, h / canvas.Y
	local p, s = obj.AbsolutePosition - canvasAt, obj.AbsoluteSize
	return Vector2.new(left + p.X * kx, top + p.Y * ky), Vector2.new(s.X * kx, s.Y * ky)
end

local STEP_ATTRIBUTES = { "MissionStep", "MissionTaps", "MissionButton", "MissionGuideKind", "UnlockButton", "UnlockQuest",
	"UnlockQuestStep", "UnlockNext" }
local function guideStep()
	local parts = {}
	for i, name in ipairs(STEP_ATTRIBUTES) do
		local v = player:GetAttribute(name)
		parts[i] = v == nil and "" or tostring(v)
	end
	return table.concat(parts, "|")
end

local usedBy = setmetatable({}, { __mode = "k" })
local step, stepAt, insideAt, busyAt, touchAt = nil, -math.huge, -math.huge, -math.huge, -math.huge
UserInputService.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
		touchAt = os.clock()
	end
end)
UserInputService.InputChanged:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseWheel then
		touchAt = os.clock()
	end
end)

local function closeTarget(top, x, openedAt, tapped, lost, blocked)
	local now = os.clock()
	local current = guideStep()
	if current ~= step then
		step, stepAt = current, now
	end
	if top ~= nil and ((tapped ~= nil and tapped:IsDescendantOf(top)) or (lost ~= nil and lost:IsDescendantOf(top))) then
		usedBy[top] = current
		insideAt = now
		return nil
	end
	if not top or not x or blocked or lost or not x.Visible or x.AbsoluteSize.X <= 0 or not guiding() then
		return nil
	end
	if top:GetAttribute("Busy") then
		busyAt = now
		return nil
	end
	if tapped then
		local p, s = screenRect(tapped)
		if not p or not Windows.covered(tapped, p.X + s.X / 2, p.Y + s.Y / 2) then
			return nil
		end
	elseif usedBy[top] == current then
		return nil
	end
	if now - math.max(openedAt, insideAt, busyAt, stepAt, touchAt) >= CLOSE_AFTER then
		return x
	end
	return nil
end

local function hideAll()
	finger.Visible, glow.Visible, caption.Visible = false, false, false
	for _, d in ipairs(dims) do
		d.Visible = false
	end
	dimFor = nil
end

local forced = true
local function refreshForced()
	forced = Unlock.nextOne() ~= nil
end
Unlock.watch(refreshForced)
refreshForced()

local function slapButton(root, spot)
	local mode = player:GetAttribute("MissionSlap")
	local on = mode == "Fight" and player:GetAttribute("PromoLevel") ~= nil
		or mode == "Near" and root ~= nil and typeof(spot) == "Vector3"
			and Vector3.new(spot.X - root.Position.X, 0, spot.Z - root.Position.Z).Magnitude <= SLAP_NEAR
	if not on then
		return nil
	end
	local b = Coach.find("Slap")
	return Coach.visible(b) and b or nil
end

RunService.RenderStepped:Connect(FrameMeter.wrap("MissionGuide", function()
	-- (2026-10-04) 보기 설정 "🧭 미션 길 안내" off (player attribute HideMissionGuide): nothing
	local quiet = player:GetAttribute("TutorialStep") ~= nil or Windows.anyOpen() or player:GetAttribute("Racing")
		or (player:GetAttribute("CarriedKeys") or 0) > 0 or (player:GetAttribute("HideMissionGuide") == true and not forced)
	local unlockSpot = player:GetAttribute("UnlockTarget")
	local spot = unlockSpot or player:GetAttribute("MissionTarget")
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local kind = unlockSpot == nil and player:GetAttribute("MissionGuideKind") or nil
	if spot == nil and root and kind == "Wild" then
		spot = nearestWild(root)
	elseif root and kind == "AltarBox" then
		spot = nearestBox(root) or spot
	elseif spot == nil and root and kind == "MyDino" then
		spot = nearestMyDino(root)
	end
	if typeof(spot) == "Vector3" and root and not quiet then
		aim(root, spot)
	elseif beam then
		clearBeam()
	end
	local tapped, tapKey, lost = nil, nil, nil
	local racing = player:GetAttribute("Racing")
	local hidden = player:GetAttribute("HideMissionGuide") == true and not forced
	local near = not player:GetAttribute("MissionTapsNear") or root ~= nil and typeof(spot) == "Vector3"
		and Vector3.new(spot.X - root.Position.X, 0, spot.Z - root.Position.Z).Magnitude <= SLAP_NEAR
	local flyingOver = player:GetAttribute("InTutorial") == true and player:GetAttribute("Flying") == true
		and player:GetAttribute("Riding") == true and root ~= nil and not SafeZones.isSafe(root.Position) and not hidden
		and not racing and guiding()
	if racing == "Gather" and not player:GetAttribute("Riding") and not hidden then
		local ride = Coach.find("Ride")
		if Coach.visible(ride) then
			tapped, tapKey = ride, "Ride"
		end
	elseif flyingOver then
		local off = Coach.find("Ride")
		if Coach.visible(off) then
			tapped, tapKey = off, "Dismount"
		end
	elseif near and not (player:GetAttribute("TutorialStep") ~= nil or racing
		or (player:GetAttribute("CarriedKeys") or 0) > 0 or hidden) then
		tapped, tapKey, lost = tapTarget(player:GetAttribute("MissionTaps"))
	end
	local slap = not tapped and not quiet and unlockSpot == nil and slapButton(root, spot) or nil
	if slap then
		tapped, tapKey = slap, "Slap"
	end
	local scroller, swipeWay = nil, nil
	if not tapped and lost then
		scroller, swipeWay = Coach.swipeFor(lost)
	end
	local top, topX, openedAt = Windows.top()
	local closing = not swipeWay and closeTarget(top, topX, openedAt, tapped, lost, player:GetAttribute("TutorialStep") ~= nil
		or racing or (player:GetAttribute("CarriedKeys") or 0) > 0 or hidden) or nil
	if closing then
		tapped, tapKey = closing, "Close"
	end
	local text = player:GetAttribute("UnlockButton") or (unlockSpot == nil and near and player:GetAttribute("MissionButton") or nil)
	local button = tapped or (type(text) == "string" and not quiet and findButton(text) or nil)
	local holder = not button and not quiet and FoldHint.holderFor(text) or nil
	FoldHint.show(holder, false)
	button = button or holder
	local hold = (tapped ~= nil or swipeWay ~= nil) and Windows.anyOpen()
	if swipeWay then
		button, text = scroller, "Swipe:" .. swipeWay
	elseif tapped then
		text = "Tap:" .. tapKey
	end
	local p, s = nil, nil
	if button then
		p, s = screenRect(button)
	end
	if not p or Windows.covered(button, p.X + s.X / 2, p.Y + s.Y / 2) then
		hideAll()
		return
	end
	local origin = gui.AbsolutePosition
	if dimFor ~= text then
		dimFor, dimSince = text, os.clock()
	end
	local age = os.clock() - dimSince
	local shade = slap and 1 or (hold or age < DIM_SECONDS) and DIM_TRANSPARENCY
		or DIM_TRANSPARENCY + (1 - DIM_TRANSPARENCY) * math.min(1, (age - DIM_SECONDS) / DIM_FADE)
	local size = gui.AbsoluteSize
	local wide, high = math.ceil(size.X), math.ceil(size.Y)
	local x0, y0 = math.floor(p.X - origin.X - GLOW_PAD), math.floor(p.Y - origin.Y - GLOW_PAD)
	local x1, y1 = math.ceil(p.X - origin.X + s.X + GLOW_PAD), math.ceil(p.Y - origin.Y + s.Y + GLOW_PAD)
	local rects = { { 0, -DIM_TOP_EXTRA, wide, y0 + DIM_TOP_EXTRA }, { 0, y1, wide, high - y1 }, { 0, y0, x0, y1 - y0 }, { x1, y0, wide - x1, y1 - y0 } }
	for i, d in ipairs(dims) do
		local r = rects[i]
		d.Position = UDim2.fromOffset(r[1], r[2])
		d.Size = UDim2.fromOffset(math.max(0, r[3]), math.max(0, r[4]))
		d.BackgroundTransparency = shade
		d.Visible = shade < 1
	end
	glow.Position = UDim2.fromOffset(x0, y0)
	glow.Size = UDim2.fromOffset(x1 - x0, y1 - y0)
	glow.BackgroundTransparency = 0.6 + 0.3 * (math.sin(os.clock() * FINGER_SPEED) + 1) / 2
	glow.Visible = swipeWay == nil
	local bounce = math.abs(math.sin(os.clock() * FINGER_SPEED)) * FINGER_BOUNCE
	local below = p.Y - origin.Y + s.Y + 2 + bounce
	local words = swipeWay and SWIPE_WORDS[swipeWay] or closing and CLOSE_WORDS or tapKey == "Dismount" and DISMOUNT_WORDS
		or tapped and TAP_WORDS[Coach.nameOf(tapped) or ""]
	local captionY
	finger.AnchorPoint = FINGER_ANCHOR
	finger.TextTransparency = 0
	if swipeWay then
		local t = (os.clock() % SWIPE_SECONDS) / SWIPE_SECONDS
		local from, to = SWIPE_FROM, SWIPE_TO
		if swipeWay == "Down" or swipeWay == "Right" then
			from, to = to, from
		end
		local k = from + (to - from) * math.min(1, t / SWIPE_MOVE)
		local left, upper = p.X - origin.X, p.Y - origin.Y
		finger.AnchorPoint = SWIPE_ANCHORS[swipeWay]
		finger.Text = SWIPE_FINGERS[swipeWay]
		finger.TextTransparency = t > SWIPE_MOVE and (t - SWIPE_MOVE) / (1 - SWIPE_MOVE) or 0
		if swipeWay == "Up" or swipeWay == "Down" then
			finger.Position = UDim2.fromOffset(left + s.X / 2, upper + s.Y * k)
		else
			finger.Position = UDim2.fromOffset(left + s.X * k, upper + s.Y / 2)
		end
		captionY = upper + s.Y + CAPTION_GAP
	elseif p.Y - origin.Y + s.Y + 2 + FINGER_BOUNCE + FINGER_SIZE.Y.Offset <= gui.AbsoluteSize.Y then
		finger.Text = "👆"
		finger.Position = UDim2.fromOffset(p.X - origin.X + s.X / 2, below)
		captionY = p.Y - origin.Y + s.Y + 2 + FINGER_SIZE.Y.Offset + CAPTION_GAP
	else -- (a button at the bottom, like 🔔: the finger above it)
		finger.Text = "👇"
		finger.Position = UDim2.fromOffset(p.X - origin.X + s.X / 2, p.Y - origin.Y - FINGER_SIZE.Y.Offset - 2 - bounce)
		captionY = p.Y - origin.Y - FINGER_SIZE.Y.Offset - 2 - CAPTION_GAP - CAPTION_HEIGHT
	end
	finger.Visible = true
	caption.Visible = words ~= nil
	if words then
		Lang.set(caption, words)
		local half = caption.AbsoluteSize.X / 2
		caption.Position = UDim2.fromOffset(math.clamp(p.X - origin.X + s.X / 2, half + CAPTION_GAP, math.max(half + CAPTION_GAP,
			size.X - half - CAPTION_GAP)), math.clamp(captionY, CAPTION_GAP, math.max(CAPTION_GAP, size.Y - CAPTION_HEIGHT - CAPTION_GAP)))
	end
end))
