local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local PILLAR_HEIGHT = 400
local CORE_WIDTH = 4
local SLEEVE_WIDTH = 16
local CORE_COLOR = Color3.fromRGB(255, 240, 170)
local SLEEVE_COLOR = Color3.fromRGB(255, 170, 40)
local CORE_TRANSPARENCY, CORE_PULSED = 0.45, 0.7
local SLEEVE_TRANSPARENCY, SLEEVE_PULSED = 0.8, 0.92
local PULSE_SECONDS = 1
local LIGHT_RANGE = 40
local LIGHT_LOW, LIGHT_HIGH = 1, 4
local COIN_EVERY = 0.25
local COIN_SIZE = Vector3.new(0.25, 1.4, 1.4)
local COIN_COLOR = Color3.fromRGB(255, 200, 50)
local COIN_RISE = { 5, 9 }
local COIN_SPREAD = 4
local COIN_SECONDS = 1.1
local COIN_DISTANCE = 250
local COUNT_SIZE = UDim2.fromOffset(120, 26)
local COUNT_SHIFT = -1.35
local COUNT_ABOVE = 4
local COUNT_DISTANCE = 2000
local COUNT_COLOR = Color3.fromRGB(255, 220, 120)
local UPDATE_EVERY = 0.25

local player = Players.LocalPlayer
local rng = Random.new()
local shown = nil

local function part(props, parent)
	local p = Instance.new("Part")
	p.Anchored = true
	p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = false, false, false, false
	p.Material = Enum.Material.Neon
	for k, v in pairs(props) do
		p[k] = v
	end
	p.Parent = parent
	return p
end

local function clear()
	if shown then
		shown.folder:Destroy()
		shown = nil
	end
end

local function build(spot, height, endsAt)
	clear()
	local light = player:GetAttribute("LightMode") == true
	local folder = Instance.new("Folder")
	folder.Name = "TreasureGlow"
	local up = CFrame.new(spot + Vector3.new(0, PILLAR_HEIGHT / 2, 0)) * CFrame.Angles(0, 0, math.rad(90))
	local core = part({ Name = "Core", Shape = Enum.PartType.Cylinder, Size = Vector3.new(PILLAR_HEIGHT, CORE_WIDTH, CORE_WIDTH),
		CFrame = up, Color = CORE_COLOR, Transparency = CORE_TRANSPARENCY }, folder)
	local sleeve = part({ Name = "Sleeve", Shape = Enum.PartType.Cylinder,
		Size = Vector3.new(PILLAR_HEIGHT, SLEEVE_WIDTH, SLEEVE_WIDTH), CFrame = up, Color = SLEEVE_COLOR,
		Transparency = SLEEVE_TRANSPARENCY }, folder)
	local top = spot + Vector3.new(0, height, 0)
	local anchor = part({ Name = "Anchor", Size = Vector3.one, CFrame = CFrame.new(spot + Vector3.new(0, height / 2, 0)),
		Transparency = 1 }, folder)
	local pulse = TweenInfo.new(PULSE_SECONDS, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true)
	if not light then
		TweenService:Create(core, pulse, { Transparency = CORE_PULSED }):Play()
		TweenService:Create(sleeve, pulse, { Transparency = SLEEVE_PULSED }):Play()
		local glow = Instance.new("PointLight")
		glow.Color = SLEEVE_COLOR
		glow.Range = LIGHT_RANGE
		glow.Brightness = LIGHT_LOW
		glow.Parent = anchor
		TweenService:Create(glow, pulse, { Brightness = LIGHT_HIGH }):Play()
	end
	local gui = Instance.new("BillboardGui")
	gui.Size = COUNT_SIZE
	gui.SizeOffset = Vector2.new(0, COUNT_SHIFT)
	gui.StudsOffsetWorldSpace = Vector3.new(0, height / 2 + COUNT_ABOVE, 0)
	gui.AlwaysOnTop = true
	gui.MaxDistance = COUNT_DISTANCE
	gui.LightInfluence = 0
	gui.Adornee = anchor
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBlack
	text.TextScaled = true
	text.TextColor3 = COUNT_COLOR
	text.TextStrokeTransparency = 0.2
	text:SetAttribute("KeepText", true)
	text.Parent = gui
	gui.Parent = folder
	folder.Parent = Workspace
	shown = { folder = folder, text = text, top = top, endsAt = endsAt, light = light, nextCoin = 0 }
end

local function coin(top)
	local c = part({ Name = "Coin", Shape = Enum.PartType.Cylinder, Size = COIN_SIZE, Color = COIN_COLOR,
		CFrame = CFrame.new(top) * CFrame.Angles(0, rng:NextNumber(0, math.pi * 2), 0) }, shown.folder)
	local angle = rng:NextNumber(0, math.pi * 2)
	local to = top + Vector3.new(math.cos(angle) * COIN_SPREAD, rng:NextNumber(COIN_RISE[1], COIN_RISE[2]), math.sin(angle) * COIN_SPREAD)
	TweenService:Create(c, TweenInfo.new(COIN_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		CFrame = CFrame.new(to) * CFrame.Angles(0, angle + math.pi * 4, 0), Transparency = 1 }):Play()
	task.delay(COIN_SECONDS, function()
		c:Destroy()
	end)
end

local function refresh()
	local spot = ReplicatedStorage:GetAttribute("TreasureSpot")
	local endsAt = ReplicatedStorage:GetAttribute("TreasureEndsAt")
	if typeof(spot) ~= "Vector3" or type(endsAt) ~= "number" then
		clear()
		return
	end
	if shown and shown.endsAt == endsAt and shown.light == (player:GetAttribute("LightMode") == true) then
		return
	end
	build(spot, ReplicatedStorage:GetAttribute("TreasureHeight") or 0, endsAt)
end

ReplicatedStorage:GetAttributeChangedSignal("TreasureEndsAt"):Connect(refresh)
ReplicatedStorage:GetAttributeChangedSignal("TreasureSpot"):Connect(refresh)
player:GetAttributeChangedSignal("LightMode"):Connect(refresh)
refresh()

local since = 0
RunService.Heartbeat:Connect(function(dt)
	if not shown then
		return
	end
	local now = Workspace:GetServerTimeNow()
	local camera = Workspace.CurrentCamera
	if not shown.light and os.clock() >= shown.nextCoin and camera
		and (camera.CFrame.Position - shown.top).Magnitude < COIN_DISTANCE then
		shown.nextCoin = os.clock() + COIN_EVERY
		coin(shown.top)
	end
	since += dt
	if since < UPDATE_EVERY then
		return
	end
	since = 0
	local left = math.max(0, math.ceil(shown.endsAt - now))
	if left <= 0 then
		clear()
		return
	end
	shown.text.Text = string.format("⏳ %d:%02d", left // 60, left % 60)
end)
