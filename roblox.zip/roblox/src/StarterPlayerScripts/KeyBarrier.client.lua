--[[
KeyBarrier: while I carry keys (player attribute CarriedKeys), a force-field dome covers every base
but mine, on my screen only, big and see-through enough to spot from far away. Invisible walls along
each base's edge are solid for me (my own character's physics), so I bump into them instead of
walking in; the server also puts a carrier back out of another player's base (Keys service),
whatever this screen shows. My own base glows instead, to find the way home from anywhere: a tall
pulsing green light pillar, a soft green dome and a "🏠 내 기지" marker with the distance, seen through
everything. All of it goes when I have no keys.
]]

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Lang = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Lang")) -- (Lang.set: set every frame, only when it changes)

local player = Players.LocalPlayer

-- display only
local WALL_HEIGHT = 14 -- the invisible walls that block
local WALL_THICKNESS = 1
local DOME_HEIGHT = 70 -- studs from the ground to the top of the dome
local DOME_OVERSIZE = 1.42 -- × the base's size: about √2, so the dome's edge passes over the base's corners
local DOME_COLOR = Color3.fromRGB(255, 110, 110)
local DOME_TRANSPARENCY = 0.5 -- (the walls were 0.7) seen from afar
local HOME_COLOR = Color3.fromRGB(110, 255, 140) -- my own base, while I carry keys
local HOME_DOME_TRANSPARENCY = 0.6
local HOME_PILLAR_HEIGHT, HOME_PILLAR_WIDTH = 400, 8
local HOME_PILLAR_TRANSPARENCY = { 0.25, 0.6 } -- pulsing between these
local HOME_PULSE_SPEED = 3
local HOME_MARKER_SIZE = UDim2.fromOffset(150, 44)
local HOME_MARKER_ABOVE = 30 -- studs over the ground

local folder = nil
local pillar, markerText = nil, nil

local function clear()
	if folder then
		folder:Destroy()
		folder = nil
	end
	pillar, markerText = nil, nil
end

-- my own base glows: the way home with the keys
-- zone: my base's SafeZone part, or a stand-in { CFrame, Size } from the player attributes BaseCenter and
-- BaseSize (far away, its parts may not have streamed in yet)
local function homeGlow(zone)
	local ground = zone.CFrame * CFrame.new(0, -zone.Size.Y / 2, 0)
	local dome = Instance.new("Part")
	dome.Name = "HomeGlow"
	dome.Anchored = true
	dome.CanCollide, dome.CanQuery, dome.CanTouch, dome.CastShadow = false, false, false, false
	dome.Material = Enum.Material.ForceField
	dome.Color = HOME_COLOR
	dome.Transparency = HOME_DOME_TRANSPARENCY
	dome.Size = Vector3.new(zone.Size.X * DOME_OVERSIZE, DOME_HEIGHT * 2, zone.Size.Z * DOME_OVERSIZE)
	dome.CFrame = ground
	local mesh = Instance.new("SpecialMesh")
	mesh.MeshType = Enum.MeshType.Sphere
	mesh.Parent = dome
	dome.Parent = folder
	pillar = Instance.new("Part")
	pillar.Name = "HomePillar"
	pillar.Anchored = true
	pillar.CanCollide, pillar.CanQuery, pillar.CanTouch, pillar.CastShadow = false, false, false, false
	pillar.Material = Enum.Material.Neon
	pillar.Color = HOME_COLOR
	pillar.Shape = Enum.PartType.Cylinder
	pillar.Size = Vector3.new(HOME_PILLAR_HEIGHT, HOME_PILLAR_WIDTH, HOME_PILLAR_WIDTH)
	pillar.CFrame = CFrame.new(ground.Position + Vector3.new(0, HOME_PILLAR_HEIGHT / 2, 0)) * CFrame.Angles(0, 0, math.pi / 2)
	pillar.Parent = folder
	local anchor = Instance.new("Part")
	anchor.Name = "HomeMarker"
	anchor.Anchored = true
	anchor.CanCollide, anchor.CanQuery, anchor.CanTouch = false, false, false
	anchor.Transparency = 1
	anchor.Size = Vector3.one
	anchor.CFrame = CFrame.new(ground.Position + Vector3.new(0, HOME_MARKER_ABOVE, 0))
	anchor.Parent = folder
	local marker = Instance.new("BillboardGui")
	marker.Size = HOME_MARKER_SIZE
	marker.AlwaysOnTop = true
	marker.LightInfluence = 0
	marker.Adornee = anchor
	marker.Parent = anchor
	markerText = Instance.new("TextLabel")
	markerText.Size = UDim2.fromScale(1, 1)
	markerText.BackgroundTransparency = 1
	markerText.Font = Enum.Font.GothamBold
	markerText.TextScaled = true
	markerText.TextColor3 = HOME_COLOR
	markerText.TextStrokeTransparency = 0.2
	markerText.Text = "🏠 내 기지"
	markerText.Parent = marker
end

local function wall(zone, localCenter, size)
	local p = Instance.new("Part")
	p.Name = "KeyBarrier"
	p.Anchored = true
	p.CanCollide = true
	p.CanQuery, p.CanTouch, p.CastShadow = false, false, false
	p.Transparency = 1
	p.Size = size
	p.CFrame = zone.CFrame * CFrame.new(localCenter)
	p.Parent = folder
end

local function build()
	clear()
	local map = Workspace:FindFirstChild("Map")
	if not map then
		return
	end
	folder = Instance.new("Folder")
	folder.Name = "KeyBarriers"
	local glowing = false
	for _, base in ipairs(map:GetChildren()) do
		local zone = base:FindFirstChild("SafeZone")
		local mine = base.Name == "Base" .. tostring(player:GetAttribute("Base"))
		if zone and mine then
			homeGlow(zone)
			glowing = true
		elseif zone then
			local hx, hz = zone.Size.X / 2, zone.Size.Z / 2
			local y = -zone.Size.Y / 2 + WALL_HEIGHT / 2 -- standing on the ground (the zone's bottom)
			wall(zone, Vector3.new(0, y, hz), Vector3.new(zone.Size.X, WALL_HEIGHT, WALL_THICKNESS))
			wall(zone, Vector3.new(0, y, -hz), Vector3.new(zone.Size.X, WALL_HEIGHT, WALL_THICKNESS))
			wall(zone, Vector3.new(hx, y, 0), Vector3.new(WALL_THICKNESS, WALL_HEIGHT, zone.Size.Z))
			wall(zone, Vector3.new(-hx, y, 0), Vector3.new(WALL_THICKNESS, WALL_HEIGHT, zone.Size.Z))
			-- the dome: a stretched sphere centered on the ground, its lower half under the floor
			local dome = Instance.new("Part")
			dome.Name = "KeyBarrierDome"
			dome.Anchored = true
			dome.CanCollide, dome.CanQuery, dome.CanTouch, dome.CastShadow = false, false, false, false
			dome.Material = Enum.Material.ForceField
			dome.Color = DOME_COLOR
			dome.Transparency = DOME_TRANSPARENCY
			dome.Size = Vector3.new(zone.Size.X * DOME_OVERSIZE, DOME_HEIGHT * 2, zone.Size.Z * DOME_OVERSIZE)
			dome.CFrame = zone.CFrame * CFrame.new(0, -zone.Size.Y / 2, 0)
			local mesh = Instance.new("SpecialMesh")
			mesh.MeshType = Enum.MeshType.Sphere
			mesh.Parent = dome
			dome.Parent = folder
		end
	end
	local center, size = player:GetAttribute("BaseCenter"), player:GetAttribute("BaseSize")
	if not glowing and center and size then
		homeGlow({ CFrame = CFrame.new(center + Vector3.new(0, size.Y / 2, 0)), Size = size })
	end
	folder.Parent = Workspace
end

local function update()
	local carrying = (player:GetAttribute("CarriedKeys") or 0) > 0
	if carrying and not folder then
		build()
	elseif not carrying then
		clear()
	end
end

-- the pillar pulses; the marker says how far home is
RunService.Heartbeat:Connect(FrameMeter.wrap("KeyBarrier", function()
	if pillar and pillar.Parent then
		local t = (math.sin(os.clock() * HOME_PULSE_SPEED) + 1) / 2
		pillar.Transparency = HOME_PILLAR_TRANSPARENCY[1] + (HOME_PILLAR_TRANSPARENCY[2] - HOME_PILLAR_TRANSPARENCY[1]) * t
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if root and markerText then
			local here = Vector3.new(root.Position.X, 0, root.Position.Z)
			local home = Vector3.new(pillar.Position.X, 0, pillar.Position.Z)
			Lang.set(markerText, string.format("🏠 내 기지 %dm", math.floor((here - home).Magnitude)))
		end
	end
end))

player:GetAttributeChangedSignal("CarriedKeys"):Connect(update)
player:GetAttributeChangedSignal("Base"):Connect(function()
	if folder then
		build()
	end
end)
update()
