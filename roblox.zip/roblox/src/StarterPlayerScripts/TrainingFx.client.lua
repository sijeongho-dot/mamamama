--[[
TrainingFx: what training looks like (display only; the server's Training service decides the training).
(2026-10-04, "훈련하는 모션은 넣은거지?" / "트레드밀이나 sack은 모션이 있어야 할거 아니냐")

- Every character standing still at a training station (its player's attribute TrainStation, which replicates) does
  that station's motion, posed on every screen the way MiningFx does the mining swing (R15 joints set in
  RunService.Stepped over the character's own animation, blended in and out; nothing uploaded):
    Rock       ⛏️ the pickaxe swing at the rock: a clink and chips flying off it at every strike
    Dummy      👋 slaps, right then left: a smack, a puff, and the dummy rocks back (on this screen)
    Treadmill  👟 running in place on the belt, arms pumping: a step at every foot, in time with the legs (2026-10-04,
               "뛸때 훈련 발자국 소리 넣어줘야 뛰는 속도에맞춰서", "작게라도": was the dirt Footstep, silent until uploaded,
               and only every other step: Shared/Sfx "TreadStep" now, a built-in knock standing in), mine heard as is
    Sacks      🎒 squatting for a sack and lifting it high overhead, then down again: a sack in the hands, a thud
  Walking, the motion fades out (the character's own walk shows). The pickaxe in hand is hidden for every motion but
  the rock's.
- My own character, whenever it stops in a station's ring away from its spot: it walks the last steps to the station
  (onto the treadmill's belt, up to the rock, the dummy, the sacks; slid there if it can't walk there in WALK_TIMEOUT)
  and turns to face it (along the belt to the treadmill's screen); any move of mine takes over. (2026-10-04: was once
  each time I came in, and walking only: on the treadmill it often ran beside the belt)
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Fx = require(Shared:WaitForChild("Fx"))
local Sfx = require(Shared:WaitForChild("Sfx"))

local player = Players.LocalPlayer

-- display only
local DISTANCE = 150 -- characters farther than this from the camera are not animated
local SOUND_DISTANCE = 60 -- nor heard
local BLEND_SECONDS = 0.15 -- (was 0.25: in at once)
local STILL_SPEED = 1.5 -- studs a second: slower than this counts as standing
local RING_REACH_Y = 8
-- training goes on and on: quieter than the real thing (was 0.45; 0.38 for the twice as many hits, 2026-10-04; 0.32 for
-- the faster ones)
local SOUND_GAIN = 0.32
-- seconds of one round of each motion (2026-10-04, "훈련 모션 속이 뻥뚫리게 빠르게 돌려": about twice as fast; were 0.95,
-- 1.1, 0.62, 2.6) (2026-10-04, "훈련모션 더거 빠르게 / 더더": about 2.3 times as fast again; were 0.45, 0.5, 0.34, 1.2)
-- (2026-10-04, "트레드밀 볼륨 좋은데 달리는 발에맞춰서 발자국 소리가 나야지": its legs went round every 0.15 s, too fast for
-- a step at each foot; a sprint now, every foot heard as it lands)
-- (2026-10-04, "트레드밀 왤케 느리게 뛰나": was 0.42) a fast run, a foot down every 0.14 s
-- (2026-10-05, "모션들도 지금보다 3배 빠르게 하고 달리기랑 가방 훈련": were Treadmill 0.28, Sacks 0.5)
local CYCLE = { Rock = 0.2, Dummy = 0.22, Treadmill = 0.093, Sacks = 0.167 }
-- seconds at least between one character's training sounds and bits flying (the quick slaps and steps: every other one)
local SOUND_GAP = 0.12
-- (2026-10-04) the treadmill's steps: one at every foot (two a stride, CYCLE.Treadmill), never closer than TREAD_GAP (a
-- hitch must not play two at once); my own heard as is, louder, the others' from their feet; left and right a little
-- apart in pitch
-- (2026-10-04, "트레드밀 발자국 소리 존나 크다고 개 줄이라고": a stride is CYCLE.Treadmill 0.15 s, so a step every foot
-- knocked about 13 times a second, a drumroll however soft each was) a step at most every TREAD_GAP seconds (a brisk
-- run's pace), the others' quieter still
local TREAD_GAP = 0.1 -- (under half a stride: every foot plant sounds, in time with the legs)
local TREAD_GAIN, TREAD_MY_GAIN = 0.5, 1 -- × Shared/Sfx TreadStep (2026-10-04, "트레드밀 발소리 너무 크다": mine was 1.4)
local TREAD_PITCH = { 0.95, 1.05 } -- the left foot, the right
local TREAD_PITCH_JITTER = 0.04
local WORK_DISTANCE = { Rock = 3.4, Dummy = 2.6, Sacks = 3.3, Treadmill = 0 } -- studs from the station's middle
local DECK_TOP = 0.62 -- the treadmill's belt over the ground (tools/make_training.py)
-- (2026-10-04, "트레드밀 위치로 가서 뛰는게 아니라 그냥 구역 안에서만 뛰네": it walked up only once each time I came in,
-- and gave up when it couldn't get there) seconds to walk there, else it is slid there (SLIDE_SECONDS)
local WALK_TIMEOUT = 1.5
local SLIDE_SECONDS = 0.2
local SETTLE_SECONDS = 0.3 -- standing this long in the ring before walking up
local TURN_RATE = 8 -- how fast my character turns to face the station
local CHIP_COLORS = { Color3.fromRGB(170, 160, 150), Color3.fromRGB(87, 184, 255) }
local SLAP_COLORS = { Color3.fromRGB(255, 230, 120), Color3.fromRGB(255, 255, 255) }
local SACK_COLOR = Color3.fromRGB(216, 178, 122)
local SACK_SIZE = Vector3.new(1.5, 1.7, 1.3)
local SACK_UP = 0.35 -- studs over the hands' middle
-- (2026-10-04: a smaller kick and a stiffer spring for the slaps twice as quick again: it shakes back and forth, not stays
-- leaned back; were 2.6, 110, 8)
local DUMMY_KICK = 2.0 -- radians a second a slap gives the dummy
local DUMMY_SPRING = 200 -- (springs back quicker for the quicker slaps; was 60)
local DUMMY_DAMP = 12
local DUMMY_MAX = 0.3
local ROCK_HIT_UP = 1.8 -- the chips fly from this high on the rock's side toward the swinger ...
local ROCK_HIT_OUT = 2.2 -- ... this far out from its middle

-- key poses: joint -> { pitch (about its X: + lifts a limb forward, leans the upper body back), yaw (about its Y: +
-- turns toward the character's left), drop (studs down, Root only) }. Characters face -Z.
local POSES = {
	rest = {},
	-- ⛏️ (MiningFx's swing)
	windup = {
		RightShoulder = { 2.75, 0.25 }, LeftShoulder = { 2.75, -0.25 }, RightElbow = { 0.5 }, LeftElbow = { 0.5 },
		Waist = { 0.2 }, Neck = { 0.2 }, RightHip = { 0.05 }, LeftHip = { 0.05 },
	},
	strike = {
		RightShoulder = { 0.85, 0.35 }, LeftShoulder = { 0.85, -0.35 }, RightElbow = { 0.1 }, LeftElbow = { 0.1 },
		Waist = { -0.55 }, Neck = { -0.35 }, Root = { -0.12, 0, 0.35 }, RightHip = { 0.55 }, LeftHip = { 0.55 },
		RightKnee = { -0.9 }, LeftKnee = { -0.9 }, RightAnkle = { 0.35 }, LeftAnkle = { 0.35 },
	},
	-- 👋 (CombatFx's slap, then the same with the left hand)
	windRight = { RightShoulder = { 1.4, -1.1 }, RightElbow = { 0.8 }, Waist = { 0, -0.35 } },
	hitRight = { RightShoulder = { 1.55, 0.95 }, RightElbow = { 0.1 }, Waist = { 0, 0.4 } },
	windLeft = { LeftShoulder = { 1.4, 1.1 }, LeftElbow = { 0.8 }, Waist = { 0, 0.35 } },
	hitLeft = { LeftShoulder = { 1.55, -0.95 }, LeftElbow = { 0.1 }, Waist = { 0, -0.4 } },
	-- 🎒 a sack: held at the chest, down in a squat, high overhead
	chest = {
		RightShoulder = { 1.25, 0.3 }, LeftShoulder = { 1.25, -0.3 }, RightElbow = { 0.6 }, LeftElbow = { 0.6 },
	},
	squat = {
		Root = { -0.2, 0, 0.9 }, Waist = { -0.5 }, Neck = { -0.2 },
		RightHip = { 1.4 }, LeftHip = { 1.4 }, RightKnee = { -1.9 }, LeftKnee = { -1.9 },
		RightAnkle = { 0.5 }, LeftAnkle = { 0.5 },
		RightShoulder = { 0.55, 0.25 }, LeftShoulder = { 0.55, -0.25 }, RightElbow = { 0.3 }, LeftElbow = { 0.3 },
	},
	overhead = {
		RightShoulder = { 2.9, 0.15 }, LeftShoulder = { 2.9, -0.15 }, RightElbow = { 0.25 }, LeftElbow = { 0.25 },
		Waist = { 0.12 }, Neck = { 0.35 },
	},
}
-- each motion: { time (0-1 of its CYCLE), pose }, eased between; `hits`: the moments something lands
local MOTIONS = {
	Rock = { keys = { { 0, "rest" }, { 0.45, "windup" }, { 0.6, "strike" }, { 0.75, "strike" }, { 1, "rest" } },
		fast = { windup = true }, hits = { 0.6 } },
	Dummy = { keys = { { 0, "rest" }, { 0.18, "windRight" }, { 0.32, "hitRight" }, { 0.5, "rest" }, { 0.68, "windLeft" },
		{ 0.82, "hitLeft" }, { 1, "rest" } }, fast = { windRight = true, windLeft = true }, hits = { 0.32, 0.82 } },
	Sacks = { keys = { { 0, "chest" }, { 0.25, "squat" }, { 0.45, "chest" }, { 0.62, "overhead" }, { 0.78, "overhead" },
		{ 1, "chest" } }, fast = {}, hits = { 0.25 } },
}
local JOINTS = { "RightShoulder", "LeftShoulder", "RightElbow", "LeftElbow", "Waist", "Neck", "Root",
	"RightHip", "LeftHip", "RightKnee", "LeftKnee", "RightAnkle", "LeftAnkle" }

local rigs = setmetatable({}, { __mode = "k" }) -- [character] = { joints, weight, clock, station, soundAt }
local triedAt = setmetatable({}, { __mode = "k" }) -- [character] = os.clock() of the last search that found none
local RIG_RETRY = 1

local function rigOf(character)
	local r = rigs[character]
	if r then
		return r
	end
	if triedAt[character] and os.clock() - triedAt[character] < RIG_RETRY then
		return nil
	end
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not humanoid or humanoid.RigType ~= Enum.HumanoidRigType.R15 then
		triedAt[character] = os.clock()
		return nil
	end
	local joints, count = {}, 0
	for _, d in ipairs(character:GetDescendants()) do
		if (d:IsA("Motor6D") or d:IsA("AnimationConstraint")) and table.find(JOINTS, d.Name) and not joints[d.Name] then
			joints[d.Name] = d
			count += 1
		end
	end
	-- still loading (a few joints, or the body not all there): look again in a moment; a whole body moves what it has
	if count == 0 or (count < #JOINTS and not (character:FindFirstChild("UpperTorso") and character:FindFirstChild("LeftFoot"))) then
		triedAt[character] = os.clock()
		return nil
	end
	r = { joints = joints, weight = 0, clock = 0 }
	rigs[character] = r
	return r
end

local function smooth(t)
	return t * t * (3 - 2 * t)
end

local function poseAt(motion, phase)
	local keys = motion.keys
	for i = 1, #keys - 1 do
		local a, b = keys[i], keys[i + 1]
		if phase <= b[1] then
			local t = (phase - a[1]) / (b[1] - a[1])
			t = motion.fast[a[2]] and t * t or smooth(t) -- (a strike is fast at its end)
			return POSES[a[2]], POSES[b[2]], t
		end
	end
	local last = POSES[keys[#keys][2]]
	return last, last, 0
end

local function jointCFrame(pitch, yaw, drop)
	return CFrame.new(0, -(drop or 0), 0) * CFrame.fromAxisAngle(Vector3.yAxis, yaw or 0)
		* CFrame.fromAxisAngle(Vector3.xAxis, pitch or 0)
end

local function keyed(name, from, to, t)
	local a, b = from[name] or {}, to[name] or {}
	local function mix(i)
		return (a[i] or 0) + ((b[i] or 0) - (a[i] or 0)) * t
	end
	return jointCFrame(mix(1), mix(2), mix(3))
end

-- 👟 running in place: one stride a round (phase 0-1), worked out rather than keyed
local function running(name, phase)
	local s = math.sin(phase * 2 * math.pi)
	if name == "RightShoulder" then
		return jointCFrame(-0.9 * s)
	elseif name == "LeftShoulder" then
		return jointCFrame(0.9 * s)
	elseif name == "RightElbow" or name == "LeftElbow" then
		return jointCFrame(1.3)
	elseif name == "RightHip" then
		return jointCFrame(0.8 * s)
	elseif name == "LeftHip" then
		return jointCFrame(-0.8 * s)
	elseif name == "RightKnee" then
		return jointCFrame(-0.3 - 0.9 * (1 - s) / 2)
	elseif name == "LeftKnee" then
		return jointCFrame(-0.3 - 0.9 * (1 + s) / 2)
	elseif name == "Waist" then
		return jointCFrame(-0.15)
	elseif name == "Neck" then
		return jointCFrame(0.1)
	elseif name == "Root" then
		return jointCFrame(0, 0, 0.12 * (1 - math.abs(s)))
	end
	return CFrame.identity
end

local function flat(v)
	return Vector3.new(v.X, 0, v.Z)
end

local function inRing(root, at)
	if typeof(at) ~= "Vector3" then
		return false
	end
	local d = root.Position - at
	return flat(d).Magnitude <= Config.Training.Range and math.abs(d.Y) <= RING_REACH_Y
end

local function hidePickaxe(character, hidden)
	local held = character:FindFirstChild("HeldPickaxe")
	if held then
		for _, d in ipairs(held:GetDescendants()) do
			if d:IsA("BasePart") then
				d.LocalTransparencyModifier = hidden and 1 or 0
			end
		end
	end
end

-- ---------------------------------------------------------------------------
-- The dummy rocking back from a slap (this screen only)
-- ---------------------------------------------------------------------------

local dummies = {} -- [model] = { home pivot, angle, speed, axis }

local function dummyNear(at)
	local map = Workspace:FindFirstChild("Map")
	for _, folder in ipairs(map and map:GetChildren() or {}) do
		local model = folder:FindFirstChild("TrainDummy")
		if model then
			local d = dummies[model]
			local pivot = d and d.home or model:GetPivot()
			if (pivot.Position - at).Magnitude < 1 then
				return model
			end
		end
	end
	return nil
end

local function kickDummy(at, from)
	local model = dummyNear(at)
	if not model then
		return
	end
	local d = dummies[model]
	if not d then
		d = { home = model:GetPivot(), angle = 0, speed = 0 }
		dummies[model] = d
	end
	local away = flat(at - from)
	if away.Magnitude < 1e-3 then
		return
	end
	d.axis = Vector3.yAxis:Cross(away.Unit) -- tips away from the slapper
	d.speed += DUMMY_KICK
end

RunService.Heartbeat:Connect(FrameMeter.wrap("TrainingFx", function(dt)
	for model, d in pairs(dummies) do
		if not model.Parent then
			dummies[model] = nil
		else
			d.speed += (-DUMMY_SPRING * d.angle - DUMMY_DAMP * d.speed) * dt
			d.angle = math.clamp(d.angle + d.speed * dt, -DUMMY_MAX, DUMMY_MAX)
			if math.abs(d.angle) < 1e-3 and math.abs(d.speed) < 1e-2 then
				model:PivotTo(d.home)
				dummies[model] = nil
			else
				local p = d.home.Position
				model:PivotTo(CFrame.new(p) * CFrame.fromAxisAngle(d.axis, d.angle) * (d.home - p))
			end
		end
	end
end))

-- ---------------------------------------------------------------------------
-- The motions, on every training character in sight
-- ---------------------------------------------------------------------------

local sacks = {} -- [character] = the sack Part in its hands

local function sackFor(character)
	local sack = sacks[character]
	if not sack then
		sack = Instance.new("Part")
		sack.Name = "TrainingSack"
		sack.Size = Vector3.one
		sack.Color = SACK_COLOR
		sack.Material = Enum.Material.Fabric
		sack.Anchored, sack.CanCollide, sack.CanQuery, sack.CanTouch, sack.CastShadow = true, false, false, false, false
		local mesh = Instance.new("SpecialMesh")
		mesh.MeshType = Enum.MeshType.Sphere
		mesh.Scale = SACK_SIZE
		mesh.Parent = sack
		sack.Parent = Workspace
		sacks[character] = sack
	end
	return sack
end

local function dropSack(character)
	if sacks[character] then
		sacks[character]:Destroy()
		sacks[character] = nil
	end
end

-- something lands: the sound and the bits, at the station (the dummy rocks at every slap; the sound and bits at most every
-- SOUND_GAP for one character, r its rig)
local function landed(station, character, root, at, r)
	local camera = Workspace.CurrentCamera
	if not camera or (root.Position - camera.CFrame.Position).Magnitude > SOUND_DISTANCE then
		return
	end
	if station == "Dummy" then
		kickDummy(at, root.Position)
	end
	local now = os.clock()
	if now - (r.soundAt or -math.huge) < SOUND_GAP then
		return
	end
	r.soundAt = now
	if station == "Rock" then
		local side = flat(root.Position - at)
		local hit = side.Magnitude > 1e-3 and at + side.Unit * ROCK_HIT_OUT + Vector3.new(0, ROCK_HIT_UP, 0)
			or root.Position + root.CFrame.LookVector * 3
		Sfx.play("MineHit", hit, nil, SOUND_GAIN)
		Fx.burst(hit, CHIP_COLORS, 10, 16, 0.35, 0.4)
	elseif station == "Dummy" then
		local hit = root.Position + root.CFrame.LookVector * 2 + Vector3.new(0, 0.5, 0)
		Sfx.play("SlapHit", hit, 0.9 + math.random() * 0.2, SOUND_GAIN)
		Fx.burst(hit, SLAP_COLORS, 8, 14, 0.3, 0.35)
	elseif station == "Sacks" then
		local sack = sacks[character]
		Sfx.play("FruitThud", sack and sack.Position or root.Position, 0.8, SOUND_GAIN)
	end
end

RunService.Stepped:Connect(FrameMeter.wrap("TrainingFx", function(_, dt)
	local camera = Workspace.CurrentCamera
	local eye = camera and camera.CFrame.Position
	for _, other in ipairs(Players:GetPlayers()) do
		local character = other.Character
		local root = character and character:FindFirstChild("HumanoidRootPart")
		local station = other:GetAttribute("TrainStation")
		if root and eye and (rigs[character] or station) and (root.Position - eye).Magnitude <= DISTANCE then
			local r = rigOf(character)
			if r then
				local still = flat(root.AssemblyLinearVelocity).Magnitude < STILL_SPEED and not other:GetAttribute("Mining")
				local on = station ~= nil and still and inRing(root, other:GetAttribute("TrainAt"))
				if on and r.station ~= station then -- a new station: start its motion from the top
					r.station, r.clock = station, 0
				end
				local was = r.weight
				r.weight = math.clamp(r.weight + (on and dt or -dt) / BLEND_SECONDS, 0, 1)
				if r.weight <= 0 then
					if was > 0 then -- joints no animation moves would keep the last pose: put them back
						for _, joint in pairs(r.joints) do
							joint.Transform = CFrame.identity
						end
						hidePickaxe(character, false)
						dropSack(character)
					end
					r.station, r.clock = nil, 0
				else
					local kind = r.station
					local before = r.clock
					if on then
						r.clock = (r.clock + dt / CYCLE[kind]) % 1
					end
					local at = other:GetAttribute("TrainAt")
					local motion = MOTIONS[kind]
					if motion and on and typeof(at) == "Vector3" then
						for _, h in ipairs(motion.hits) do
							if before < h and (r.clock >= h or r.clock < before) then
								landed(kind, character, root, at, r)
							end
						end
					elseif kind == "Treadmill" and on then -- a step at every foot: the half strides (the body lowest)
						if (math.floor(before * 2) ~= math.floor(r.clock * 2) or r.clock < before)
							and (root.Position - eye).Magnitude <= SOUND_DISTANCE and os.clock() - (r.soundAt or -math.huge) >= TREAD_GAP then
							r.soundAt = os.clock()
							r.foot = r.foot == 1 and 2 or 1
							local pitch = TREAD_PITCH[r.foot] + (math.random() * 2 - 1) * TREAD_PITCH_JITTER
							if other == player then
								Sfx.play("TreadStep", nil, pitch, TREAD_MY_GAIN)
							else
								Sfx.play("TreadStep", root.Position - Vector3.new(0, 2.5, 0), pitch, TREAD_GAIN)
							end
						end
					end
					local from, to, t
					if motion then
						from, to, t = poseAt(motion, r.clock)
					end
					for name, joint in pairs(r.joints) do
						local target = motion and keyed(name, from, to, t) or running(name, r.clock)
						joint.Transform = joint.Transform:Lerp(target, r.weight)
					end
					hidePickaxe(character, kind ~= "Rock" and r.weight > 0.3)
				end
			end
		end
	end
end))

-- the sack follows the hands (after Stepped moved the arms)
RunService.Heartbeat:Connect(FrameMeter.wrap("TrainingFx", function()
	for _, other in ipairs(Players:GetPlayers()) do
		local character = other.Character
		local r = character and rigs[character]
		if r and r.station == "Sacks" and r.weight > 0.3 then
			local left, right = character:FindFirstChild("LeftHand"), character:FindFirstChild("RightHand")
			local root = character:FindFirstChild("HumanoidRootPart")
			if left and right and root then
				local mid = (left.Position + right.Position) / 2 + Vector3.new(0, SACK_UP, 0)
				sackFor(character).CFrame = CFrame.lookAt(mid, mid + root.CFrame.LookVector)
			end
		elseif character and sacks[character] then
			dropSack(character)
		end
	end
	for character in pairs(sacks) do
		if not character.Parent then
			dropSack(character)
		end
	end
end))

-- ---------------------------------------------------------------------------
-- My character: up to the station and facing it
-- ---------------------------------------------------------------------------

local stillSince = nil
local walking = nil -- { started, spot } while walking up
local tries = 0 -- walks up that didn't get there (the next time: slid)
local sliding = false
local groundRay = RaycastParams.new()
groundRay.FilterType = Enum.RaycastFilterType.Exclude

player:GetAttributeChangedSignal("TrainStation"):Connect(function()
	stillSince, walking, tries = nil, nil, 0
end)

local controls = nil -- the PlayerModule's ControlModule: am I pushing the stick or the keys? (as AutoMine)
local function pushing()
	if not controls then
		pcall(function()
			local module = player:FindFirstChild("PlayerScripts") and player.PlayerScripts:FindFirstChild("PlayerModule")
			controls = module and require(module):GetControls()
		end)
	end
	local ok, v = pcall(function()
		return controls and controls:GetMoveVector()
	end)
	return ok and v ~= nil and v.Magnitude > 0.1
end

local function workSpot(station, at, out, root)
	if station == "Treadmill" then
		return at + Vector3.new(0, DECK_TOP, 0), out
	end
	local side = flat(root.Position - at)
	side = side.Magnitude > 1e-3 and side.Unit or -out
	return at + side * WORK_DISTANCE[station], -side
end

RunService.Heartbeat:Connect(FrameMeter.wrap("TrainingFx", function(dt)
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local station = player:GetAttribute("TrainStation")
	local at, out = player:GetAttribute("TrainAt"), player:GetAttribute("TrainOut")
	if not root or not humanoid or not station or typeof(at) ~= "Vector3" or typeof(out) ~= "Vector3" then
		if walking and root and humanoid then
			walking = nil
			humanoid:MoveTo(root.Position)
		end
		return
	end
	if not inRing(root, at) then
		if walking then
			walking = nil
			humanoid:MoveTo(root.Position)
		end
		stillSince, tries = nil, 0
		return
	end
	local mine = pushing()
	if walking then
		if mine then -- my own move takes over
			walking = nil
			humanoid:MoveTo(root.Position)
		elseif os.clock() > walking.started + WALK_TIMEOUT or flat(root.Position - walking.spot).Magnitude < 0.8 then
			walking = nil
		end
		return
	end
	if mine or humanoid.MoveDirection.Magnitude > 0.1 then
		stillSince = nil
		if mine then
			tries = 0
		end
		return
	end
	stillSince = stillSince or os.clock()
	local spot, face = workSpot(station, at, out, root)
	if os.clock() - stillSince >= SETTLE_SECONDS and flat(root.Position - spot).Magnitude > 1 then
		if sliding then
			return
		end
		if tries >= 1 then -- (walked and didn't get there: slid onto the spot, standing as high over it as now)
			tries = 0
			local ground = Workspace:Raycast(root.Position, Vector3.new(0, -12, 0), groundRay)
			local over = ground and root.Position.Y - ground.Position.Y or humanoid.HipHeight + root.Size.Y / 2
			local from = root.CFrame
			local to = CFrame.lookAt(Vector3.new(spot.X, spot.Y + over, spot.Z),
				Vector3.new(spot.X, spot.Y + over, spot.Z) + (face.Magnitude > 1e-3 and face.Unit or from.LookVector))
			sliding = true
			local started = os.clock()
			task.spawn(function()
				while os.clock() - started < SLIDE_SECONDS and root.Parent and not pushing() do
					local k = (os.clock() - started) / SLIDE_SECONDS
					root.CFrame = from:Lerp(to, k)
					root.AssemblyLinearVelocity = Vector3.zero
					RunService.Heartbeat:Wait()
				end
				if root.Parent and not pushing() then
					root.CFrame = to
				end
				sliding = false
			end)
			return
		end
		tries += 1
		walking = { started = os.clock(), spot = spot }
		humanoid:MoveTo(spot)
		return
	end
	if flat(root.Position - spot).Magnitude <= 1 then
		tries = 0
	end
	-- turn to face it
	local look = flat(root.CFrame.LookVector)
	if look.Magnitude > 1e-3 and face.Magnitude > 1e-3 and look.Unit:Dot(face.Unit) < 0.995 then
		local want = CFrame.lookAt(root.Position, root.Position + face.Unit)
		root.CFrame = root.CFrame:Lerp(want, math.min(1, dt * TURN_RATE))
	end
end))

player.CharacterAdded:Connect(function(character)
	stillSince, walking, tries = nil, nil, 0
	groundRay.FilterDescendantsInstances = { character }
end)
if player.Character then
	groundRay.FilterDescendantsInstances = { player.Character }
end
