local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local CocoVoice = require(Shared:WaitForChild("CocoVoice"))
local Lang = require(Shared:WaitForChild("Lang"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

local FONT = Enum.Font.GothamBlack
local DISPLAY_ORDER = 30
local CARD_SIZE = UDim2.fromOffset(460, 430)
local COLOR_BG = Color3.fromRGB(22, 26, 46)
local COLOR_TOP = Color3.fromRGB(255, 180, 80)
local COLOR_BOTTOM = Color3.fromRGB(225, 95, 165)
local COLOR_GO = Color3.fromRGB(80, 190, 95)
local COLOR_SENT = Color3.fromRGB(110, 115, 135)
local GOLD = Color3.fromRGB(255, 215, 90)
local NOTE_COLOR = Color3.fromRGB(255, 240, 200)
local ICON_SIZE = 84
local ICON_TOP = 60
local TITLE_TEXT = 34
local LINE_TEXT = 26
local NOTE_TEXT = 21
local LINE_HEIGHT = 64
local LINE2_HEIGHT = 34
local NOTE_HEIGHT = 28
local LINE_GAP = 4
local NOTE_GAP = 6
local BIG_TEXT = 40
local BIG_HEIGHT = 100
local BIG_PAD = 6
local BIG_COLOR = Color3.fromRGB(255, 236, 120)
local BIG_BOX = Color3.fromRGB(40, 20, 55)
local BIG_BOX_SEE = 0.25
local GO_TEXT = 30
local GO_SIZE = UDim2.fromOffset(300, 58)
local ICON_BOUNCE, ICON_SPEED = 6, 4
local BUTTON_PULSE, PULSE_SPEED = 0.06, 5
local WAIT_STEP = 0.3
local TEXT_SENT = "🔄 다시 들어가는 중…"

local CARDS = {
	Hello = {
		Icon = "🐣",
		Title = "👋 오랜만에 오셨네요!",
		Lines = { "📦 예전 플레이 데이터는 제가 잘 보관해 뒀어요!", "🎮 게임 방법을 알아볼까요?" },
		Big = true,
		Note = "🎓 튜토리얼을 마치면 돌려드리고 맵이 모두 열려요",
		Go = "🎮 알아보기!",
	},
	Ready = {
		Icon = "🎉",
		Title = "🎉 다 배웠어요!",
		Lines = { "📦 보관해 둔 예전 데이터를 돌려드릴게요", "🗺️ 맵도 모두 열려요!" },
		Note = "🔄 잠깐 다시 들어가요",
		Go = "📦 돌려받기!",
		Keep = true,
	},
	Back = {
		Icon = "📦",
		Title = "📦 예전 데이터가 돌아왔어요!",
		Lines = { "🗺️ 이제 맵이 모두 열렸어요!", "🎬 섬을 한 바퀴 구경해 볼까요?" },
		Go = "🎬 구경하기!",
	},
	Fresh = {
		Icon = "🐣",
		Title = "👋 오랜만에 오셨네요!",
		Lines = { "🆕 게임이 새로 바뀌어서 처음부터 같이 해요!", "🎮 게임 방법을 알아볼까요?" },
		Note = "🎓 튜토리얼을 마치면 섬 전체가 열려요",
		Go = "🎮 알아보기!",
	},
	Kept = {
		Icon = "🎓",
		Title = "🎓 지금 하던 그대로 해요!",
		Lines = { "📦 예전 데이터 대신 지금 것을 그대로 가져가요", "🎓 튜토리얼을 마치면 섬 전체가 열려요" },
		Go = "✅ 확인",
	},
}

if ReplicatedStorage:GetAttribute("TutorialField") then
	return
end

local gui = Instance.new("ScreenGui")
gui.Name = "Welcome"
gui.ResetOnSpawn = false
gui.DisplayOrder = DISPLAY_ORDER
gui.Parent = player:WaitForChild("PlayerGui")

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.Text = ""
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextStrokeTransparency = 0.3
	l.TextScaled = true
	l.TextWrapped = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = textSize
	most.Parent = l
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function arrange(ui, big)
	local top = ICON_TOP + ICON_SIZE + 10
	local first = big and BIG_HEIGHT or LINE_HEIGHT
	local pad = big and BIG_PAD or 0
	ui.box.Visible = big
	ui.box.Size = UDim2.new(1, -20, 0, first)
	ui.box.Position = UDim2.fromOffset(10, top)
	ui.lines[1].Size = UDim2.new(1, -30 - 2 * pad, 0, first - 2 * pad)
	ui.lines[1].Position = UDim2.fromOffset(15 + pad, top + pad)
	ui.lines[1].TextColor3 = big and BIG_COLOR or Color3.new(1, 1, 1)
	ui.lines[1]:FindFirstChildOfClass("UITextSizeConstraint").MaxTextSize = big and BIG_TEXT or LINE_TEXT
	ui.lines[2].Position = UDim2.fromOffset(15, top + first + LINE_GAP)
	ui.note.Position = UDim2.fromOffset(15, top + first + LINE_GAP + LINE2_HEIGHT + NOTE_GAP)
end

local function build(keep)
	local card = Instance.new("Frame")
	card.AnchorPoint = Vector2.new(0.5, 0.5)
	card.Position = UDim2.fromScale(0.5, 0.5)
	card.Size = CARD_SIZE
	card.BackgroundColor3 = Color3.new(1, 1, 1)
	card.Visible = false
	card.Parent = gui
	corner(card, 16)
	local shade = Instance.new("UIGradient")
	shade.Rotation = 90
	shade.Color = ColorSequence.new(COLOR_TOP, COLOR_BOTTOM)
	shade.Parent = card
	local veil = Instance.new("Frame")
	veil.Size = UDim2.fromScale(1, 1)
	veil.BackgroundColor3 = COLOR_BG
	veil.BackgroundTransparency = 0.45
	veil.ZIndex = 0
	veil.Parent = card
	corner(veil, 16)
	local edge = Instance.new("UIStroke")
	edge.Color = GOLD
	edge.Thickness = 3
	edge.Parent = card
	local ring = Instance.new("Frame")
	ring.AnchorPoint = Vector2.new(0.5, 0)
	ring.Size = UDim2.fromOffset(ICON_SIZE + 12, ICON_SIZE + 12)
	ring.Position = UDim2.new(0.5, 0, 0, ICON_TOP - 6)
	ring.BackgroundColor3 = COLOR_BG
	ring.BackgroundTransparency = 0.3
	ring.Parent = card
	corner(ring, (ICON_SIZE + 12) / 2)
	local ringEdge = Instance.new("UIStroke")
	ringEdge.Color = GOLD
	ringEdge.Thickness = 3
	ringEdge.Parent = ring
	local go = Instance.new("TextButton")
	go.AnchorPoint = Vector2.new(0.5, 1)
	go.Position = UDim2.new(0.5, 0, 1, -14)
	go.Size = GO_SIZE
	go.BackgroundColor3 = COLOR_GO
	go.Font = FONT
	go.Text = ""
	go.TextColor3 = Color3.new(1, 1, 1)
	go.TextScaled = true
	local goMost = Instance.new("UITextSizeConstraint")
	goMost.MaxTextSize = GO_TEXT
	goMost.Parent = go
	go.Parent = card
	corner(go, 12)
	local goEdge = Instance.new("UIStroke")
	goEdge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	goEdge.Color = Color3.new(1, 1, 1)
	goEdge.Thickness = 2
	goEdge.Parent = go
	local pulse = Instance.new("UIScale")
	pulse.Parent = go
	local box = Instance.new("Frame")
	box.BackgroundColor3 = BIG_BOX
	box.BackgroundTransparency = BIG_BOX_SEE
	box.Visible = false
	box.Parent = card
	corner(box, 12)
	local boxEdge = Instance.new("UIStroke")
	boxEdge.Color = GOLD
	boxEdge.Thickness = 2
	boxEdge.Parent = box
	local ui = {
		card = card,
		go = go,
		pulse = pulse,
		box = box,
		title = label(card, UDim2.new(1, -60, 0, 44), UDim2.fromOffset(30, 10), TITLE_TEXT, GOLD),
		icon = label(card, UDim2.fromOffset(ICON_SIZE, ICON_SIZE), UDim2.new(0.5, -ICON_SIZE / 2, 0, ICON_TOP), 60),
		lines = {
			label(card, UDim2.new(1, -30, 0, LINE_HEIGHT), UDim2.fromOffset(15, 0), LINE_TEXT),
			label(card, UDim2.new(1, -30, 0, LINE2_HEIGHT), UDim2.fromOffset(15, 0), LINE_TEXT),
		},
		note = label(card, UDim2.new(1, -30, 0, NOTE_HEIGHT), UDim2.fromOffset(15, 0), NOTE_TEXT, NOTE_COLOR),
	}
	arrange(ui, false)
	Windows.fit(card)
	Windows.register(card, nil, keep and { Keep = true } or nil)
	return ui
end

local plain = build(false)
local kept = build(true)
local current = nil
local shown = {}
local sent = false

local function busy(def)
	if player:GetAttribute("Loading") then
		return true
	end
	return not def.Keep and (player:GetAttribute("LanguagePick") or player:GetAttribute("CocoIntro")
		or player:GetAttribute("TutorialStep") or player:GetAttribute("Racing"))
end

local function show(kind)
	local def = CARDS[kind]
	if not def or shown[kind] then
		return
	end
	shown[kind] = true
	while busy(def) do
		task.wait(WAIT_STEP)
	end
	if player:GetAttribute("Welcome") ~= kind then
		return
	end
	local ui = def.Keep and kept or plain
	if current and current ~= ui then
		current.card.Visible = false
	end
	current = ui
	arrange(ui, def.Big == true)
	ui.icon.Text = def.Icon
	ui.title.Text = def.Title
	ui.lines[1].Text = def.Lines[1]
	ui.lines[2].Text = def.Lines[2] or ""
	ui.note.Text = def.Note or ""
	ui.go.Text = def.Go
	ui.go.BackgroundColor3 = COLOR_GO
	ui.kind = kind
	ui.card.Visible = true
	player:SetAttribute("WelcomeUp", true)
	Sfx.play("Victory")
	CocoVoice.babble(Lang.t(def.Lines[1]))
	while ui.card.Visible and current == ui do
		local t = os.clock()
		ui.icon.Position = UDim2.new(0.5, -ICON_SIZE / 2, 0, ICON_TOP + math.sin(t * ICON_SPEED) * ICON_BOUNCE)
		ui.pulse.Scale = sent and 1 or 1 + math.sin(t * PULSE_SPEED) * BUTTON_PULSE
		RunService.RenderStepped:Wait()
	end
	if current == ui then
		player:SetAttribute("WelcomeUp", nil)
	end
end

local function pressed(ui)
	local kind = ui.kind
	if kind == "Ready" then
		if sent then
			return
		end
		sent = true
		ui.go.Text = TEXT_SENT
		ui.go.BackgroundColor3 = COLOR_SENT
		Net.request("WelcomeHome")
		return
	end
	ui.card.Visible = false
	if kind == "Back" then
		Net.request("ReplayIntro")
	end
end

for _, ui in ipairs({ plain, kept }) do
	ui.go.Activated:Connect(function()
		pressed(ui)
	end)
end

local function check()
	local kind = player:GetAttribute("Welcome")
	if kind then
		task.spawn(show, kind)
	end
end
player:GetAttributeChangedSignal("Welcome"):Connect(check)
check()
