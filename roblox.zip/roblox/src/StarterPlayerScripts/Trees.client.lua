--[[
Trees: slapping a tree shakes it; the fruit trees drop fruit that anyone can pick up and carry home (2026-10-01;
the fruit is real since 2026-10-02, 공룡 사육).

Every slap anyone makes (Net push SlapFx: who, their slap level) reaches the trees in front of them
within their slap reach (Formulas.slapReach) and a little: each such tree shakes and its leaves rustle (the
sound "TreeRustle", one a slap). Every tree on the map shakes when slapped (any model named like a tree, the
border hills' too), and the big mushrooms and bushes too. The trees are found once in Workspace.Map.

The fruit (Fruits service): the server decides what falls (Net push FruitDrop, to everyone: where, which kind,
which size, how long it stays, who put it down) and every screen draws it falling from the leaves (or from a
player's hands): an apple from the round trees, a pine cone from the firs, a coconut from the palms, bigger for
a bigger size (Config.Fruit.Sizes Scale; the big ones sparkle). Walking within Config.Fruit.PickRange of one asks
for it (Net request PickFruit; anyone may, the one who put it down only after DropperPickupDelay); Net push
FruitGone(id, who) takes it off every screen, flying to whoever got it ("+1 🍎" over my head when it is me).
- "🍎⬇️ 내려놓기" (bottom right, left of the keys' one), only while I carry fruit (player attribute
  CarriedFruit): it opens a picker (− n +, "⬇️ 내려놓기", "전부"; 2026-10-02, "갯수 정해서 내려놓기") that sends Net
  request DropFruit(count); key H puts all of it down. (Unlike keys, a slap never scatters carried fruit.)
- Net push FruitStored(food): the fruit I picked became food (2026-10-05: at once, Fruits): "+3 🍎" over my head, the
  food it is worth (the pick's own "+1 🍎" is left out).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)

local player = Players.LocalPlayer

-- display only
local KINDS = { Tree = "Apple", Prop_Tree_Round = "Apple", Prop_Tree_Pine = "Pinecone", Prop_Tree_Palm = "Coconut",
	Mushroom = "None", Bush = "None" } -- (2026-10-01) the big mushrooms and the bushes on the ground shake too
local TRUNK_SLACK = 3 -- studs past the slap's reach that still reach a trunk (it is thick)
local COLLECT_PER_FRAME = 3000
local DRAW_DISTANCE = 220 -- studs from the camera: farther slaps drop nothing on this screen
local SHAKE_SECONDS, SHAKE_ANGLE, SHAKE_SPEED = 0.6, math.rad(3), 30
local FADE_SECONDS = 1 -- a fruit left lying fades away this long
local FALL_SECONDS = { 0.55, 0.85 }
local PICK_CHECK = 0.1 -- seconds between looks for my fruit underfoot
local PICK_FLY_SECONDS = 0.25 -- a picked fruit flies to me and shrinks
local SPARKLE_FROM = 3 -- fruit size number (Big) and up sparkle
local POP_SIZE = UDim2.fromOffset(120, 40) -- "+2 🍎" over my head
local POP_RISE, POP_SECONDS = 3, 1.1
local POP_COLOR = Color3.fromRGB(255, 120, 110)
local PICK_PITCH = 1.4 -- the pick-up ping, higher than a key's
local PICK_RETRY = 1 -- seconds before asking again for a fruit the server did not give
local DROP_BUTTON_SIZE = UDim2.fromOffset(64, 40) -- "🍎⬇️ 내려놓기": left of the keys' one (CombatFx) ...
local DROP_BUTTON_POS = UDim2.new(1, -272, 1, -120) -- ... above and left of the slap button
local COLOR_DROP = Color3.fromRGB(200, 70, 60)
local PICKER_SIZE = UDim2.fromOffset(132, 80) -- the "how many" picker above it
local PICKER_GAP = 6
local COLOR_PICKER = Color3.fromRGB(40, 44, 60)
local COLOR_STEP_BUTTON = Color3.fromRGB(90, 96, 120)
local FRUITS = { -- the fruit's parts: { shape, size, color, offset, material }
	Apple = {
		{ "Ball", Vector3.new(1.1, 1.1, 1.1), Color3.fromRGB(220, 40, 40), Vector3.zero },
		{ "Block", Vector3.new(0.12, 0.35, 0.12), Color3.fromRGB(100, 70, 40), Vector3.new(0, 0.62, 0) },
		{ "Block", Vector3.new(0.35, 0.08, 0.2), Color3.fromRGB(70, 170, 60), Vector3.new(0.18, 0.7, 0) },
	},
	Pinecone = {
		{ "Ball", Vector3.new(0.8, 1.3, 0.8), Color3.fromRGB(130, 85, 45), Vector3.zero },
		{ "Cylinder", Vector3.new(0.12, 0.85, 0.85), Color3.fromRGB(95, 60, 30), Vector3.new(0, 0.15, 0) },
		{ "Cylinder", Vector3.new(0.12, 0.75, 0.75), Color3.fromRGB(95, 60, 30), Vector3.new(0, -0.25, 0) },
	},
	Coconut = {
		{ "Ball", Vector3.new(1.5, 1.4, 1.5), Color3.fromRGB(110, 75, 45), Vector3.zero },
		{ "Ball", Vector3.new(0.22, 0.22, 0.22), Color3.fromRGB(45, 30, 20), Vector3.new(0.25, 0.45, -0.55) },
		{ "Ball", Vector3.new(0.22, 0.22, 0.22), Color3.fromRGB(45, 30, 20), Vector3.new(-0.25, 0.45, -0.55) },
	},
}

local trees = {} -- { model, kind, at (trunk's foot), top (canopy height), width }

-- every tree on the map: the ones in KINDS drop their fruit, any other model named like a tree only shakes
-- where a tree stands, once its parts are on this screen. (2026-10-01) A far tree not streamed in yet is an
-- empty model whose box sits at the map's middle: it was taken for a tree on the key altar, and slapping there
-- shook every tree out on the hills. Such a tree is measured when its parts arrive.
local function measure(tree)
	if not tree.model:FindFirstChildWhichIsA("BasePart", true) then
		return false
	end
	local cf, size = tree.model:GetBoundingBox()
	local trunk = tree.model:FindFirstChild("Trunk") or tree.model:FindFirstChild("TrunkCollider")
	local foot = trunk and trunk.Position or cf.Position
	tree.at = Vector3.new(foot.X, cf.Position.Y - size.Y / 2, foot.Z)
	tree.top = cf.Position.Y + size.Y / 2
	tree.width = math.max(size.X, size.Z)
	return true
end

local function collect(folder)
	for i, model in ipairs(folder:GetDescendants()) do
		if i % COLLECT_PER_FRAME == 0 then
			task.wait()
		end
		local kind = model:IsA("Model") and KINDS[model.Name] -- (only these names: no folders or other "…Tree…")
		if kind then
			local tree = { model = model, kind = kind }
			table.insert(trees, tree)
			if not measure(tree) then
				local conn
				conn = model.DescendantAdded:Connect(function(d)
					if d:IsA("BasePart") then
						conn:Disconnect()
						task.defer(measure, tree)
					end
				end)
			end
		end
	end
end

task.spawn(function()
	local map = Workspace:WaitForChild("Map")
	task.wait(3) -- (the map streams in)
	collect(map) -- (2026-10-01, "every tree shakes a little when hit": the border hills' and the bases' too)
end)

local function groundBelow(position, ignore)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = ignore
	local hit = Workspace:Raycast(position, Vector3.new(0, -200, 0), params)
	return hit and hit.Position.Y or position.Y - 10
end

local shaking = {} -- [tree] = true while it shakes
local function shake(tree)
	if shaking[tree] or not tree.model.Parent or not tree.model:FindFirstChildWhichIsA("BasePart", true) then
		return
	end
	shaking[tree] = true
	local rest = tree.model:GetPivot()
	local foot = CFrame.new(tree.at)
	local fromFoot = foot:ToObjectSpace(rest)
	local t0 = os.clock()
	task.spawn(function()
		while os.clock() - t0 < SHAKE_SECONDS and tree.model.Parent do
			local k = 1 - (os.clock() - t0) / SHAKE_SECONDS
			local a = SHAKE_ANGLE * k * math.sin((os.clock() - t0) * SHAKE_SPEED)
			tree.model:PivotTo(foot * CFrame.Angles(a, 0, a * 0.6) * fromFoot)
			task.wait()
		end
		if tree.model.Parent then
			tree.model:PivotTo(rest)
		end
		shaking[tree] = nil
	end)
end

local function makeFruit(kind, at, scale)
	scale = scale or 1
	local model = Instance.new("Model")
	model.Name = "Fruit"
	local main
	for i, p in ipairs(FRUITS[kind]) do
		local part = Instance.new("Part")
		part.Anchored, part.CanCollide, part.CanQuery, part.CanTouch = true, false, false, false
		part.Shape = Enum.PartType[p[1]]
		part.Size = p[2] * scale
		part.Color = p[3]
		part.Material = Enum.Material.SmoothPlastic
		part.CFrame = CFrame.new(at + p[4] * scale) * (p[1] == "Cylinder" and CFrame.Angles(0, 0, math.rad(90)) or CFrame.identity)
		part.Parent = model
		main = main or part
	end
	model.PrimaryPart = main
	model.Parent = Workspace
	return model
end

local function fade(model)
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			TweenService:Create(d, TweenInfo.new(FADE_SECONDS), { Transparency = 1 }):Play()
		end
	end
	task.delay(FADE_SECONDS, function()
		model:Destroy()
	end)
end

Net.onPush("SlapFx", function(slapperId, _, level)
	local slapper = Players:GetPlayerByUserId(slapperId)
	local root = slapper and slapper.Character and slapper.Character:FindFirstChild("HumanoidRootPart")
	local camera = Workspace.CurrentCamera
	if not root or not camera or (root.Position - camera.CFrame.Position).Magnitude > DRAW_DISTANCE then
		return
	end
	local reach = Formulas.slapReach(math.clamp(tonumber(level) or 1, 1, #Config.Slap.Scale)) + TRUNK_SLACK
	local look = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z)
	look = look.Magnitude > 0.01 and look.Unit or Vector3.zAxis
	local rustled = false -- one rustle a slap, however many trees it reaches
	for _, tree in ipairs(trees) do
		local offset = tree.at and Vector3.new(tree.at.X - root.Position.X, 0, tree.at.Z - root.Position.Z) or Vector3.one * math.huge
		local d = offset.Magnitude
		if d <= reach and (d < Config.Slap.CloseRadius + TRUNK_SLACK or offset.Unit:Dot(look) >= Config.Slap.FrontDot)
			and tree.model.Parent then
			shake(tree)
			if not rustled then
				rustled = true
				Sfx.play("TreeRustle", tree.at + Vector3.new(0, 4, 0))
			end
		end
	end
end)

-- ---------------------------------------------------------------------------
-- (2026-10-02, 공룡 사육) the fruit on the ground: anyone's, picked up by walking over it
-- ---------------------------------------------------------------------------

local onGround = {} -- [id] = { model, at, landed, asked (os.clock), blockedUntil (server time, for me) }

local function dropOne(info)
	local size = Formulas.fruitSize(info.Size) or Config.Fruit.Sizes[1]
	if not FRUITS[info.Kind] or typeof(info.At) ~= "Vector3" or onGround[info.Id] then
		return
	end
	local at = info.At
	local top = typeof(info.Top) == "number" and info.Top or at.Y + 8
	local from = Vector3.new(at.X, math.max(at.Y + 2, top - 2), at.Z)
	local ground = groundBelow(at + Vector3.new(0, 4, 0), {})
	local half = FRUITS[info.Kind][1][2].Y * size.Scale / 2
	local land = Vector3.new(at.X, ground + half, at.Z)
	local fruit = makeFruit(info.Kind, from, size.Scale)
	if (Formulas.fruitSize(size.Id .. "#") or 1) >= SPARKLE_FROM and fruit.PrimaryPart then
		local sparkle = Instance.new("Sparkles")
		sparkle.SparkleColor = Color3.fromRGB(255, 240, 150)
		sparkle.Parent = fruit.PrimaryPart
	end
	local entry = { model = fruit, at = land,
		blockedUntil = info.BlockedUser == player.UserId and tonumber(info.BlockedUntil) or nil }
	onGround[info.Id] = entry
	local seconds = FALL_SECONDS[1] + math.random() * (FALL_SECONDS[2] - FALL_SECONDS[1])
	local spin = math.random() * 2 * math.pi
	local t0 = os.clock()
	task.spawn(function()
		while fruit.Parent and onGround[info.Id] == entry do
			local k = math.min(1, (os.clock() - t0) / seconds)
			local y = from.Y + (land.Y - from.Y) * k * k -- falling faster and faster
			fruit:PivotTo(CFrame.new(from.X, y, from.Z) * CFrame.Angles(0, spin * k, k * 1.5))
			if k >= 1 then
				break
			end
			task.wait()
		end
		entry.landed = true
	end)
	task.delay(tonumber(info.Life) or Config.Fruit.LifeSeconds, function()
		if onGround[info.Id] == entry then
			onGround[info.Id] = nil
			fade(fruit)
		end
	end)
end

Net.onPush("FruitDrop", function(list)
	for _, info in ipairs(type(list) == "table" and list or {}) do
		if type(info) == "table" and type(info.Id) == "string" then
			task.delay(math.random() * 0.25, dropOne, info)
		end
	end
end)

-- a little line over my head ("+1 🍎", "🏠 +12 🍎")
local function pop(text)
	local head = player.Character and player.Character:FindFirstChild("Head")
	if not head then
		return
	end
	local board = Instance.new("BillboardGui")
	board.Size = POP_SIZE
	board.StudsOffsetWorldSpace = Vector3.new(0, 2, 0)
	board.AlwaysOnTop = true
	board.Adornee = head
	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.Text = text
	label.TextScaled = true
	label.Font = Enum.Font.GothamBold
	label.TextColor3 = POP_COLOR
	label.TextStrokeTransparency = 0.3
	label.Parent = board
	board.Parent = head
	TweenService:Create(board, TweenInfo.new(POP_SECONDS), { StudsOffsetWorldSpace = Vector3.new(0, 2 + POP_RISE, 0) }):Play()
	TweenService:Create(label, TweenInfo.new(POP_SECONDS), { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
	task.delay(POP_SECONDS, function()
		board:Destroy()
	end)
end

-- someone got it: it flies to them and shrinks (or just fades when they are not on this screen)
Net.onPush("FruitGone", function(id, userId)
	local entry = onGround[id]
	if not entry then
		return
	end
	onGround[id] = nil
	local picker = Players:GetPlayerByUserId(tonumber(userId) or 0)
	local root = picker and picker.Character and picker.Character:FindFirstChild("HumanoidRootPart")
	local fruit = entry.model
	if picker == player then
		Sfx.play("KeyPickup", nil, PICK_PITCH) -- (the food it is worth pops with FruitStored)
	end
	if not root then
		fade(fruit)
		return
	end
	local t0, from = os.clock(), fruit:GetPivot()
	task.spawn(function()
		while fruit.Parent do
			local k = math.min(1, (os.clock() - t0) / PICK_FLY_SECONDS)
			local to = root.Parent and root.Position or from.Position
			fruit:PivotTo(from:Lerp(CFrame.new(to), k))
			fruit:ScaleTo(math.max(0.05, 1 - k))
			if k >= 1 then
				break
			end
			task.wait()
		end
		fruit:Destroy()
	end)
end)

Net.onPush("FruitStored", function(food)
	pop(string.format("+%d 🍎", tonumber(food) or 0))
end)

-- walking over a fruit asks for it (the server decides who gets it)
local lastCheck = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("Trees", function()
	local now = os.clock()
	if now - lastCheck < PICK_CHECK or next(onGround) == nil then
		return
	end
	lastCheck = now
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end
	local serverNow = Workspace:GetServerTimeNow()
	for id, entry in pairs(onGround) do
		local flat = Vector3.new(entry.at.X - root.Position.X, 0, entry.at.Z - root.Position.Z).Magnitude
		if entry.landed and flat <= Config.Fruit.PickRange and (not entry.asked or now - entry.asked >= PICK_RETRY)
			and (not entry.blockedUntil or serverNow >= entry.blockedUntil) then
			entry.asked = now
			Net.request("PickFruit", id)
		end
	end
end))

-- "🍎⬇️ 내려놓기": only while carrying fruit
local gui = Instance.new("ScreenGui")
gui.Name = "Fruit"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")
local dropButton = Instance.new("TextButton")
dropButton.AnchorPoint = Vector2.new(1, 1)
dropButton.Size = DROP_BUTTON_SIZE
dropButton.Position = DROP_BUTTON_POS
dropButton.BackgroundColor3 = COLOR_DROP
dropButton.Font = Enum.Font.GothamBold
dropButton.TextSize = 12
dropButton.TextWrapped = true
dropButton.TextColor3 = Color3.new(1, 1, 1)
dropButton.Visible = false
dropButton.Parent = gui
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 10)
	round.Parent = dropButton
end
-- (2026-10-02, "갯수 정해서 내려놓기") pressing it opens a little picker above it: − n + , "⬇️ 내려놓기" puts n
-- down, "전부" all of it (key H: all)
local picker = Instance.new("Frame")
picker.AnchorPoint = Vector2.new(1, 1)
picker.Size = PICKER_SIZE
picker.Position = DROP_BUTTON_POS - UDim2.fromOffset(0, DROP_BUTTON_SIZE.Y.Offset + PICKER_GAP)
picker.BackgroundColor3 = COLOR_PICKER
picker.BackgroundTransparency = 0.1
picker.Visible = false
picker.Parent = gui
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 10)
	round.Parent = picker
end
local function small(text, size, pos, color)
	local b = Instance.new("TextButton")
	b.Size = size
	b.Position = pos
	b.BackgroundColor3 = color
	b.Font = Enum.Font.GothamBold
	b.TextSize = 14
	b.TextColor3 = Color3.new(1, 1, 1)
	b.Text = text
	b.Parent = picker
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 8)
	round.Parent = b
	return b
end
local minus = small("−", UDim2.fromOffset(32, 32), UDim2.fromOffset(6, 6), COLOR_STEP_BUTTON)
local countLabel = small("1", UDim2.fromOffset(48, 32), UDim2.fromOffset(42, 6), COLOR_PICKER)
countLabel.AutoButtonColor = false
local plus = small("+", UDim2.fromOffset(32, 32), UDim2.fromOffset(94, 6), COLOR_STEP_BUTTON)
local dropSome = small("⬇️ 내려놓기", UDim2.fromOffset(78, 30), UDim2.fromOffset(6, 44), COLOR_DROP)
local dropAll = small("전부", UDim2.fromOffset(40, 30), UDim2.fromOffset(88, 44), COLOR_DROP)
local chosen = 1

local function carriedNow()
	return player:GetAttribute("CarriedFruit") or 0
end
local function refreshPicker()
	chosen = math.clamp(chosen, 1, math.max(1, carriedNow()))
	countLabel.Text = tostring(chosen)
end
local function refreshDrop()
	local n = carriedNow()
	dropButton.Visible = n > 0
	dropButton.Text = string.format("🍎%d⬇️ 내려놓기\n(H)", n)
	if n == 0 then
		picker.Visible = false
	end
	refreshPicker()
end
player:GetAttributeChangedSignal("CarriedFruit"):Connect(refreshDrop)
refreshDrop()
local function drop(count)
	if carriedNow() > 0 and count >= 1 then
		Net.request("DropFruit", math.min(count, carriedNow()))
		picker.Visible = false
	end
end
dropButton.Activated:Connect(function()
	picker.Visible = not picker.Visible
	chosen = math.min(chosen, carriedNow())
	refreshPicker()
end)
minus.Activated:Connect(function()
	chosen -= 1
	refreshPicker()
end)
plus.Activated:Connect(function()
	chosen += 1
	refreshPicker()
end)
dropSome.Activated:Connect(function()
	drop(chosen)
end)
dropAll.Activated:Connect(function()
	drop(carriedNow())
end)
game:GetService("UserInputService").InputBegan:Connect(function(input, processed)
	if not processed and input.KeyCode == Enum.KeyCode.H then
		drop(carriedNow())
	end
end)
