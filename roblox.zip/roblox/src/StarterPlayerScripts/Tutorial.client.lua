--[[
Tutorial: Coco, the baby dino who shows a new player around their own base (design 10; the
server's Tutorial service decides the steps). Display and input only.

- Follows the player attributes the server sets: TutorialStep (the step's Id, none when not in the
  tutorial), TutorialIndex, TutorialCount, TutorialTarget (Vector3), TutorialTargetKind, TutorialReplay.
- Coco (TutorialModels.Guide_Coco, a mint ball without it) floats beside the player with a speech
  bubble: the step's one short line (Config.Tutorial.Steps Text) and the count for counted steps. The
  same line shows under the defense line at the top only while Coco is off the screen (2026-10-02: not twice).
- A glowing beam runs from the player to the target (TutorialTarget; "Mineral": the nearest mineral,
  found here) with a bouncing arrow over it. A step with a Button makes that button shine (2026-10-03) and gets a
  pointing finger 👆 under it where that fits on the screen (not under 🔔 at the bottom); the button is found
  by its text (the top bar's 뽑기 / 공룡 배치 / 승급전, the side 보상); the last step
  (Rewards) ends when that button is pressed.
- Each step done: Coco says "잘했어!", sparkles and a jingle.
- (2026-10-02, "튜토리얼에 디테일한 설명이 부족해 … 어디로 가서 뭘하라고") a step with Guide lines: the same card when the
  step starts, saying where to go and what to press; "✅ 확인" only closes it (the step goes on).
- (2026-10-02, "공룡 먹이 먹이기나 공룡 합성, 공룡 업그레이드 … 튜토가 제대로 설명 안하고") a step with Info lines (the
  shop and the stalls): once there (TutorialCount 1) Coco's card shows its title and lines, and "✅ 확인" (or closing
  it) sends TutorialStepDone.
- (2026-10-02) a Client step with Info lines (the special fossils, what to grow, what more to do): its card at once.
  A step the server marks TutorialSkip ("did": a replay's hands-on step done before; "cant": not possible now)
  shows its Guide (or Info) card with a line saying so, and reading it moves on.
- (2026-10-03, the tutorial field: TutorialField) on the way to the field (player attribute TutorialTravel) a card says
  so; back in the game, Coco's welcome-back card (player attribute TutorialWelcome: "paid" with the reward,
  "done", "skipped", "failed") says what now: the beginner missions, and 설정's replay.
- "⏩ 건너뛰기" at the top left (hidden while a window is open), held down (Shared/HoldButton) like every button that can't be undone:
  Net request TutorialSkip. On a replay only of what was finished before (2026-10-03: player attribute TutorialCanSkip);
  (2026-10-04, "튜토리얼 스킵도 가능하게 하자") on the first run too, its reward got later from 설정's "처음부터 전부".
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TextService = game:GetService("TextService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Lang = require(Shared:WaitForChild("Lang")) -- (a button's own Korean, when it shows English)
local FoldHint = require(Shared:WaitForChild("FoldHint"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Unlock = require(Shared:WaitForChild("Unlock"))
local Fx = require(Shared:WaitForChild("Fx"))
local ShowCrowd = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("ShowCrowd"))
local MeteorShow = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("MeteorShow"))
local WitchTalk = require(Shared:WaitForChild("WitchTalk"))
local BoxFall = require(Shared:WaitForChild("BoxFall"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local CocoVoice = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("CocoVoice"))
local HoldButton = require(Shared:WaitForChild("HoldButton"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

-- Coco's explanation card (display only)
local K = {}
K.CARD_SIZE = UDim2.fromOffset(340, 0) -- its height follows the lines (2026-10-03: was 380, then 420; "가로길이가 좀 기네")
K.CARD_LINE = 22
K.CARD_LINE_PAD = 6 -- pixels under a line's wrapped words
K.CARD_PAGE_LINES = 2 -- a card's lines a page (under its title)
K.CARD_TITLE_TEXT, K.CARD_TEXT = 20, 16 -- (2026-10-03: were 18 and 14, too small)
K.CARD_COLOR = Color3.fromRGB(30, 34, 50)
K.CARD_TRANSPARENCY = 0.25 -- (2026-10-03, "투명도 좀 올려놔줘봐": was 0) the world shows a little through
K.CARD_TITLE = Color3.fromRGB(150, 255, 220)
K.CARD_OK_COLOR = Color3.fromRGB(70, 180, 90)
K.CARD_BACK_COLOR = Color3.fromRGB(90, 100, 130) -- "◀ 이전"
K.CARD_GAP = 6 -- (2026-10-03) pixels between the skip button and the card under it
K.CARD_BOTTOM_ROOM = 90 -- pixels kept free at the bottom (the 🔔 button): a taller card gets smaller
K.CARD_HISTORY = 20 -- cards kept to page back through
K.CARD_START_HEIGHT = 160 -- before the first card is drawn
-- (2026-10-03, "튜토리얼 창 스트로크가 반짝이게 하자 유저들이 잘 볼 수 있게") a bright edge with a band of light going round
K.CARD_STROKE = 3
K.CARD_STROKE_COLORS = { Color3.fromRGB(150, 255, 220), Color3.fromRGB(255, 255, 255), Color3.fromRGB(255, 225, 90) }
K.CARD_SHINE_TURN = 140 -- degrees a second the light goes round
K.CARD_SHINE_PULSE = 2.4 -- radians a second: the edge brightens and dims

-- display only
K.FONT = Enum.Font.GothamBold
K.COCO_HEIGHT = 4 -- (2026-10-03, "코코 너무 작아서 시작할때 안 보여": was 2.6; a player is about 5)
-- studs from my character: right, up, forward (was 3.2 to the side; 2026-10-03, "코코가 조금 더 멀리 떠있게 하자
-- 방해되는 경우가 있네": was 4.2, 1.2, 1.5)
K.COCO_SIDE, K.COCO_UP, K.COCO_AHEAD = 6.5, 2.8, 1
K.COCO_BOB, K.COCO_BOB_SPEED = 0.35, 2.2
K.COCO_FOLLOW = 6 -- how quickly Coco catches up (per second)
K.COCO_COLOR = Color3.fromRGB(127, 224, 196) -- the stand-in ball
K.BUBBLE_SIZE = UDim2.fromOffset(230, 54)
K.BUBBLE_HINT_HEIGHT = 18 -- (2026-10-03) the small line under the bubble while the card is closed
K.BUBBLE_HINT_TEXT = 11
K.BUBBLE_HINT_COLOR = Color3.fromRGB(90, 90, 110)
K.COCO_TAP_REACH = 1.3 -- a tap within this many of Coco's half heights (on the screen) of its middle is on Coco
K.TAP_MOVE = 12 -- pixels a click may move and still be a click (not a camera drag)
K.TAP_SECONDS = 0.4
K.BUBBLE_COLOR = Color3.fromRGB(255, 255, 255)
K.BUBBLE_TEXT = Color3.fromRGB(40, 40, 60)
K.LINE_SIZE = UDim2.fromOffset(300, 30)
K.LINE_POS = UDim2.new(0.5, 0, 0, 74) -- under the defense line (Placement), its top
K.LINE_COLOR = Color3.fromRGB(30, 34, 50)
K.LINE_TEXT = Color3.fromRGB(150, 255, 220)
K.BEAM_COLOR = Color3.fromRGB(255, 230, 90)
K.BEAM_WIDTH = 0.6
K.ARROW_SIZE = UDim2.fromOffset(64, 64)
K.ARROW_UP = 9 -- studs over the target
K.ARROW_BOUNCE = 1.2
K.TUTORIAL_GRADE = "Droplet" -- (2026-10-03) the Mine step's stone: the blue one (its Event is MineDroplet)
K.FINGER_SIZE = UDim2.fromOffset(96, 96)
K.FINGER_BOUNCE = 14 -- pixels
K.FINGER_LAYER = Windows.ABOVE_WINDOWS
K.GLOW_PAD = 6 -- (2026-10-03) the shine round the button to press: pixels past its edge
K.GLOW_COLOR = Color3.fromRGB(255, 230, 90)
K.GLOW_SPEED = 6 -- the shine's pulse
K.GLOW_STROKE = { 2, 5 } -- its edge's thickness, low and high
K.GLOW_FILL = { 0.9, 0.55 } -- its light's transparency over the button, dim and bright
K.SKIP_SIZE = UDim2.fromOffset(150, 34) -- (2026-10-01: was 92 × 26 in grey, hard to see)
K.SKIP_POS = UDim2.new(0, 12, 0, 8) -- the top left, under Roblox's top bar (free of the windows)
-- (2026-10-03, "갤럭시 폴드 기준 튜토 창이 카메라홀에 가려짐 튜토 창을 오른쪽으로 조금만 옮기자": was the skip button's 12)
K.CARD_LEFT = 48 -- pixels from the left of the safe area to Coco's card
K.SKIP_UNDER_TOPBAR = 6
K.SKIP_COLOR = Color3.fromRGB(255, 120, 40) -- bright orange, a white edge: easy to find when you want out
K.SKIP_STROKE = Color3.fromRGB(255, 255, 255)
K.SKIP_PULSE_SECONDS = 6 -- the first seconds of the tutorial it breathes once a second, so it is noticed
K.HATCH_SAY_SECONDS = 3.5
K.INTRO_BAR = 0.12 -- the black bars, a share of the screen's height each
K.INTRO_BAR_SECONDS = 0.6
K.INTRO_DISPLAY_ORDER = 6 -- over the HUD while the opening plays
K.INTRO_SKIP_SIZE = UDim2.fromOffset(130, 40)
K.INTRO_SKIP_RIGHT = 16
K.INTRO_SKIP_COLOR = Color3.fromRGB(60, 64, 80)
K.INTRO_SKIP_TEXT = 16
K.INTRO_LAND_AHEAD = 7 -- studs in front of the player where Coco lands
K.INTRO_FROM_AHEAD, K.INTRO_FROM_SIDE, K.INTRO_FROM_HIGH = 60, 25, 45 -- where it comes from (studs)
K.INTRO_FLIGHT_SECONDS = 3.2
K.INTRO_SPINS = 2 -- turns while it flies
K.INTRO_TRAIL_CHANCE = 0.5 -- a sparkle puff behind it on this share of frames
K.INTRO_CAMERA_BACK, K.INTRO_CAMERA_UP = 9, 4 -- the camera behind and over the player
K.INTRO_CLOSE_BACK = 12 -- then this far in front of Coco, looking at it
K.INTRO_CLOSE_UP = 2.4
K.INTRO_CLOSE_LOOK = 2.4
-- each story line (a tap: sooner, after INTRO_MIN_LINE); (2026-10-03, "코코 말이 좀 빠른 듯": was 3.2, then 5,
-- "코코 말 죤나 빨라")
K.INTRO_LINE_SECONDS = 5
K.INTRO_MIN_LINE = 1.5
K.INTRO_HOP = 0.6
K.INTRO_START_DELAY = 1.5 -- seconds after the game, Coco's model and the world around have loaded
K.INTRO_MODEL_WAIT = 10 -- seconds to wait for Coco's model (then the mint ball)
K.INTRO_LOADING_WAIT = 80
K.INTRO_BYE_SECONDS = 1.2
K.STREAM_STEP = 90
K.STREAM_WORKERS = 8
K.STREAM_KEEP_WORKERS = 2
K.STREAM_TIMEOUT = 6
K.STREAM_WAIT = 40
K.STREAM_SETTLE_RATE = 30
K.STREAM_SETTLE_FOR = 2
K.STREAM_SETTLE_MAX = 12
K.STREAM_SETTLE_STEP = 0.25
K.STREAM_AGAIN = 0.4
K.FOCUS_AHEAD = 120
K.SHOT_MOVE_SECONDS = 1
K.CRATER_FROM, K.CRATER_TO, K.CRATER_LOOK_UP = { 70, -25, 30 }, { 38, -12, 14 }, 3
K.CRATER_FOSSILS = 6
K.CRATER_RING = { 22, 30 }
K.CRATER_SINK = 7
K.CRATER_RISE_SECONDS = 0.9
K.CRATER_RISE_GAP = 0.45
K.BONE_COLORS = { Color3.fromRGB(245, 240, 225), Color3.fromRGB(190, 120, 255) }
K.MAP_SHOTS = {
	Map = { anchor = "Center", look = { 0, 0, 0 }, from = { 420, 230, 300 }, to = { 300, 170, 210 } },
	Field = { anchor = "Center", look = { 150, 0, 0 }, from = { 300, 70, 95 }, to = { 225, 24, 42 } },
	Altar = { anchor = "Center", look = { 0, 0, 8 }, from = { 110, 40, 70 }, to = { 55, 15, 28 } },
	Base = { anchor = "Arena", look = { 0, 0, 0 }, from = { -260, 80, 170 }, to = { -140, 30, 90 } },
}
K.WITCH_SHOT = { from = { 75, 22, 40 }, to = { 44, 14, 24 }, lookUp = 4, sayAfter = 1.2 }
K.TOUR_SHOTS = {
	Tour = { ring = 1.35, up = 300, turn = { -70, 60 }, look = 0, lead = 0, lookUp = 0 },
	Bases = { ring = 1, out = 45, up = 55, turn = { -30, 45 }, look = 1, lead = 28, lookUp = 6 },
	Battle = { field = 0.8, up = 40, turn = { 50, 115 }, look = 0, lead = 0, lookUp = 0 },
	Wild = { edge = 0.92, up = 120, turn = { 130, 215 }, look = 0.5, lead = 0, lookUp = 0 },
}
K.ALTAR_BOXES = { sayAfter = 0.6, boxes = 8, first = 0.8, every = 0.55, spread = { 6, 24 }, edge = { 2.2, 3.6 },
	ground = 200, sky = 110, skySpread = 40,
	colors = { Color3.fromRGB(110, 200, 120), Color3.fromRGB(90, 160, 255), Color3.fromRGB(180, 110, 255),
		Color3.fromRGB(255, 200, 70) } }
K.CROWD = { Altar = { Count = 7, Back = 9, Spread = 26 } }
K.RAID = { count = 9, gap = 0.35, rise = 0.8, sink = 6, speed = 11, lane = 2.5, from = { 0, 75, 100 }, to = { 0, 48, 62 },
	burst = 14 }
K.SPARKLES = { Color3.fromRGB(255, 240, 120), Color3.fromRGB(150, 255, 220), Color3.fromRGB(255, 255, 255) }
K.PRAISE = "잘했어! 🎉"
K.MINERAL_EVERY = 1 -- seconds between looks for the nearest mineral

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function stepInfo(id)
	for _, s in ipairs(Config.Tutorial.Steps) do
		if s.Id == id then
			return s
		end
	end
	return nil
end

-- ---------------------------------------------------------------------------
-- The screen: the line at the top, the finger, the skip button
-- ---------------------------------------------------------------------------

local gui = Instance.new("ScreenGui")
gui.Name = "Tutorial"
gui.ResetOnSpawn = false
gui.DisplayOrder = 4 -- over the HUD's lines, under any open window (Shared/Windows: 5)
gui.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets -- (2026-10-03) clear of a phone's camera hole and notch too
gui.Parent = player:WaitForChild("PlayerGui")

local line = Instance.new("TextLabel")
line.AnchorPoint = Vector2.new(0.5, 0)
line.Size = K.LINE_SIZE
line.Position = K.LINE_POS
line.BackgroundColor3 = K.LINE_COLOR
line.BackgroundTransparency = 0.2
line.Font = K.FONT
line.TextSize = 16
line.TextColor3 = K.LINE_TEXT
line.Text = ""
line.Visible = false
line.Parent = gui
corner(line, 10)

local pointGui = Instance.new("ScreenGui")
pointGui.Name = "TutorialFinger"
pointGui.ResetOnSpawn = false
pointGui.DisplayOrder = K.FINGER_LAYER
pointGui.ScreenInsets = gui.ScreenInsets
pointGui.Parent = gui.Parent

local finger = Instance.new("TextLabel")
finger.AnchorPoint = Vector2.new(0.5, 0)
finger.Size = K.FINGER_SIZE
finger.BackgroundTransparency = 1
finger.Font = K.FONT
finger.TextScaled = true
finger.Text = "👆"
finger.Visible = false
finger.ZIndex = 20
finger.Parent = pointGui

-- (2026-10-03, "종울리기 파트 튜토에서는 손가락이 화면 밑에 위치한 종에 위치돼서 안 보여. 차라리 종울림 버튼이
-- 반짝이게해") the button to press shines: a pulsing light and a gold edge over it (taps go through to the button)
local glow = Instance.new("Frame")
glow.BackgroundColor3 = K.GLOW_COLOR
glow.Active = false
glow.Visible = false
glow.ZIndex = 19
glow.Parent = pointGui
corner(glow, 12)
local glowStroke = Instance.new("UIStroke")
glowStroke.Color = K.GLOW_COLOR
glowStroke.Parent = glow

local skip = Instance.new("TextButton")
skip.AnchorPoint = Vector2.new(0, 0)
skip.Size = K.SKIP_SIZE
local function skipTop()
	return math.max(K.SKIP_POS.Y.Offset, game:GetService("GuiService"):GetGuiInset().Y + K.SKIP_UNDER_TOPBAR)
end
skip.Position = UDim2.new(0, K.SKIP_POS.X.Offset, 0, skipTop())
skip.BackgroundColor3 = K.SKIP_COLOR
skip.BackgroundTransparency = 0
skip.Font = K.FONT
skip.TextSize = 14
skip.TextColor3 = Color3.new(1, 1, 1)
skip.TextStrokeTransparency = 0.5
skip.Text = "⏩ 튜토리얼 건너뛰기 (꾹)"
skip.Visible = false
skip.Parent = gui
corner(skip, 8)
local skipStroke = Instance.new("UIStroke")
skipStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
skipStroke.Color = K.SKIP_STROKE
skipStroke.Thickness = 2
skipStroke.Parent = skip
local skipScale = Instance.new("UIScale")
skipScale.Parent = skip
local skipShownAt = nil -- when the button first showed this session (it breathes for a few seconds)
-- (2026-10-03, "완전 처음 시작하는 사람들은 튜토리얼 건너뛰기를 없애줘" → "튜토리얼 건너뛰기는 이미 그파트 완료한 사람만
-- 가능하게") the button shows only on a replay of what was finished before (player attribute TutorialCanSkip; the
-- server checks again), and skips at once. (2026-10-04) the first run has it again: held down, it skips; the reward
-- waits for 설정's "처음부터 전부" (Coco's welcome-back card says so).
HoldButton.connect(skip, function()
	Net.request("TutorialSkip")
end)

-- ---------------------------------------------------------------------------
-- Coco
-- ---------------------------------------------------------------------------

local folder = Instance.new("Folder")
folder.Name = "TutorialCoco"
folder.Parent = Workspace

local coco = nil -- { model, bubble, text, hint, tap, pos }
local reopenCard = nil -- (set with the card below) pressing Coco shows the card closed last again

local function modelFrom(name)
	local models = ReplicatedStorage:FindFirstChild("TutorialModels")
	local source = models and models:FindFirstChild(name)
	if not source then
		return nil
	end
	local m = source:Clone()
	for _, d in ipairs(m:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
		end
	end
	return m
end

local function sizeTo(model, height)
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
	model:ScaleTo(height / math.max(size.Y, 0.1))
end

local function makeCoco(at)
	local model = modelFrom("Guide_Coco")
	if not model then -- a mint ball with a face until the model is imported
		model = Instance.new("Model")
		local ball = Instance.new("Part")
		ball.Shape = Enum.PartType.Ball
		ball.Size = Vector3.one * K.COCO_HEIGHT
		ball.Color = K.COCO_COLOR
		ball.Anchored, ball.CanCollide, ball.CanQuery, ball.CanTouch = true, false, false, false
		ball.Parent = model
		model.PrimaryPart = ball
	end
	model.Name = "Coco"
	sizeTo(model, K.COCO_HEIGHT)
	model:PivotTo(CFrame.new(at))
	model.Parent = folder
	local anchor = model.PrimaryPart or model:FindFirstChildWhichIsA("BasePart", true)
	local bubble = Instance.new("BillboardGui")
	bubble.Size = K.BUBBLE_SIZE
	bubble.StudsOffsetWorldSpace = Vector3.new(0, K.COCO_HEIGHT + 1.6, 0)
	bubble.AlwaysOnTop = true
	bubble.MaxDistance = 200
	bubble.Adornee = anchor
	-- (2026-10-03, "창이 닫혔을 시 코코 말풍선에 작은 폰트로 (채팅을 다시보려면 코코를 클릭하세요) 를 띄워주자. 코코 누르면
	-- 닫힌 튜토리얼 창이 다시 열리게" → "코코가 원래 하는말에 추가된다는 거야 같은 말풍선에") one white bubble: Coco's
	-- words, and while the card is closed a small line under them in the same bubble (it grows by that line)
	local box = Instance.new("Frame")
	box.Size = UDim2.fromScale(1, 1)
	box.BackgroundColor3 = K.BUBBLE_COLOR
	box.Parent = bubble
	corner(box, 14)
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, 8), UDim.new(0, 8)
	pad.PaddingTop, pad.PaddingBottom = UDim.new(0, 4), UDim.new(0, 4)
	pad.Parent = box
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = K.FONT
	text.TextScaled = true
	text.TextColor3 = K.BUBBLE_TEXT
	text.Text = ""
	text.Parent = box
	local hint = Instance.new("TextLabel")
	hint.AnchorPoint = Vector2.new(0.5, 1)
	hint.Position = UDim2.fromScale(0.5, 1)
	hint.Size = UDim2.new(1, 0, 0, K.BUBBLE_HINT_HEIGHT)
	hint.BackgroundTransparency = 1
	hint.Font = K.FONT
	hint.TextSize = K.BUBBLE_HINT_TEXT
	hint.TextColor3 = K.BUBBLE_HINT_COLOR
	hint.TextWrapped = true
	hint.Text = Lang.t("💬 채팅을 다시 보려면 코코를 누르세요")
	hint.Visible = false
	hint.Parent = box
	-- (2026-10-03, "튜토때 코코 때문에 스마트폰에서 시점 돌리기 어려워. 코코가 막고있으면 오른손으로 드래그해서 시점
	-- 옮기는게 막혀") no buttons on Coco or its bubble: they took every touch, so a camera drag starting there did
	-- nothing. A tap or a click on either is caught below (tappedCoco) and a drag turns the camera
	bubble.Active = false
	bubble:SetAttribute("KeepSize", true)
	bubble.Parent = gui
	coco = { model = model, bubble = bubble, box = box, text = text, hint = hint, anchor = anchor, pos = at }
end

local function removeCoco()
	if coco then
		coco.model:Destroy()
		coco.bubble:Destroy()
		coco = nil
	end
end

-- is this screen point (GUI inset left out, as taps and clicks give it) on Coco or its bubble?
local function onCoco(point)
	local camera = Workspace.CurrentCamera
	if not coco or not camera or not coco.anchor or not coco.anchor.Parent then
		return false
	end
	local middle = coco.anchor.Position
	local center, seen = camera:WorldToScreenPoint(middle)
	if not seen then
		return false
	end
	local top = camera:WorldToScreenPoint(middle + Vector3.new(0, K.COCO_HEIGHT / 2, 0))
	local reach = (Vector2.new(top.X, top.Y) - Vector2.new(center.X, center.Y)).Magnitude * K.COCO_TAP_REACH
	if (point - Vector2.new(center.X, center.Y)).Magnitude <= reach then
		return true
	end
	local box = coco.box -- the bubble, drawn round its spot over Coco
	local spot = camera:WorldToScreenPoint(middle + coco.bubble.StudsOffsetWorldSpace)
	local half = box.AbsoluteSize / 2
	return math.abs(point.X - spot.X) <= half.X and math.abs(point.Y - spot.Y) <= half.Y
end

local function tappedCoco(point)
	if reopenCard and onCoco(point) then
		reopenCard()
	end
end
UserInputService.TouchTapInWorld:Connect(function(position, processedByUI)
	if not processedByUI then
		tappedCoco(position)
	end
end)
local pressAt, pressTime = nil, 0
UserInputService.InputBegan:Connect(function(input, processed)
	if input.UserInputType == Enum.UserInputType.MouseButton1 and not processed then
		pressAt, pressTime = Vector2.new(input.Position.X, input.Position.Y), os.clock()
	end
end)
UserInputService.InputEnded:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 and pressAt then
		local at = Vector2.new(input.Position.X, input.Position.Y)
		if (at - pressAt).Magnitude <= K.TAP_MOVE and os.clock() - pressTime <= K.TAP_SECONDS then
			tappedCoco(at)
		end
		pressAt = nil
	end
end)

local sayUntil = 0 -- a praise or greeting showing over the step's line until then
local function say(text, seconds)
	if coco then
		if text ~= coco.said then
			coco.said = text
			CocoVoice.babble(Lang.t(text))
		end
		coco.text.Text = Lang.t(text)
	end
	sayUntil = os.clock() + (seconds or 0)
end

-- ---------------------------------------------------------------------------
-- The beam and the arrow over the target
-- ---------------------------------------------------------------------------

local beam, fromAttachment, toAttachment, arrow = nil, nil, nil, nil

local function clearBeam()
	for _, x in ipairs({ beam, fromAttachment, toAttachment, arrow }) do
		if x then
			x:Destroy()
		end
	end
	beam, fromAttachment, toAttachment, arrow = nil, nil, nil, nil
end

local function aimBeam(target)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not target or not root then
		clearBeam()
		return
	end
	if not beam or fromAttachment.Parent ~= root then
		clearBeam()
		fromAttachment = Instance.new("Attachment")
		fromAttachment.Name = "TutorialFrom"
		fromAttachment.Parent = root
		toAttachment = Instance.new("Attachment")
		toAttachment.Name = "TutorialTo"
		toAttachment.Parent = Workspace.Terrain
		beam = Instance.new("Beam")
		beam.Attachment0, beam.Attachment1 = fromAttachment, toAttachment
		beam.Color = ColorSequence.new(K.BEAM_COLOR)
		beam.Width0, beam.Width1 = K.BEAM_WIDTH, K.BEAM_WIDTH
		beam.FaceCamera = true
		beam.LightEmission = 1
		beam.Transparency = NumberSequence.new(0.15)
		beam.Parent = Workspace.Terrain
		arrow = Instance.new("BillboardGui")
		arrow.Size = K.ARROW_SIZE
		arrow.AlwaysOnTop = true
		arrow.Adornee = toAttachment
		local a = Instance.new("TextLabel")
		a.Size = UDim2.fromScale(1, 1)
		a.BackgroundTransparency = 1
		a.TextScaled = true
		a.Text = "⬇️"
		a.Parent = arrow
		arrow.Parent = gui
	end
	toAttachment.WorldPosition = target + Vector3.new(0, 1, 0)
	arrow.StudsOffsetWorldSpace = Vector3.new(0, K.ARROW_UP + math.sin(os.clock() * 4) * K.ARROW_BOUNCE, 0)
end

-- the nearest mineral to me (the "Mineral" target)
local nearestMineral, mineralAt = nil, 0
local function findMineral()
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local minerals = Workspace:FindFirstChild("Minerals")
	if not root or not minerals then
		return nil
	end
	-- (2026-10-03) the nearest blue droplet stone (the Mine step counts only those: the quickest to mine), else any
	local best, bestD, any, anyD = nil, math.huge, nil, math.huge
	for _, m in ipairs(minerals:GetChildren()) do
		if (m:IsA("Model") or m:IsA("BasePart")) and Unlock.mineable(m) then
			local p = m:GetPivot().Position
			local d = (p - root.Position).Magnitude
			if m:GetAttribute("Grade") == K.TUTORIAL_GRADE and d < bestD then
				best, bestD = p, d
			end
			if d < anyD then
				any, anyD = p, d
			end
		end
	end
	return best or any
end

-- ---------------------------------------------------------------------------
-- The finger under a button
-- ---------------------------------------------------------------------------

local buttonCache = { text = nil, button = nil, at = 0 }
K.BUTTON_LOOK_EVERY = 0.5 -- seconds between searches of the screen for the button (there are many objects)
-- (2026-10-04) exact: a button with exactly that text (a step's Buttons { Exact = "배치" } is not "🦖 공룡 배치")
local function searchButton(text, exact)
	exact = exact and text or nil
	return require(Shared:WaitForChild("ScreenButtons")).find(function(d)
		return d.AbsoluteSize.X < 200 and d ~= skip
			and (if exact then Lang.source(d) == exact else string.find(Lang.source(d), text, 1, true) ~= nil)
	end)
end
local function findButton(text)
	local c = buttonCache
	if c.text ~= text or os.clock() - c.at >= K.BUTTON_LOOK_EVERY or (c.button and not c.button.Parent) then
		c.text, c.button, c.at = text, searchButton(text), os.clock()
	end
	return c.button
end

-- (2026-10-04) for a step's Buttons: each text looked up on its own (the cache above keeps one)
local buttonCaches = {} -- [text] = { button, at }
local function findButtonIn(entry) -- (a text, or { Exact = text })
	local text = type(entry) == "table" and entry.Exact or entry
	local key = (type(entry) == "table" and "=" or "") .. text
	local c = buttonCaches[key]
	if not c or os.clock() - c.at >= K.BUTTON_LOOK_EVERY or (c.button and not (c.button.Parent and c.button.Visible)) then
		c = { button = searchButton(text, type(entry) == "table"), at = os.clock() }
		buttonCaches[key] = c
	end
	return c.button
end

local pointed = nil -- the button the finger is under
local pointedConn = nil
local function pointAt(button, onPress)
	if pointed ~= button then
		if pointedConn then
			pointedConn:Disconnect()
			pointedConn = nil
		end
		pointed = button
		if button and onPress then
			pointedConn = button.Activated:Connect(onPress)
		end
	end
	if not button then
		finger.Visible = false
		glow.Visible = false
		return
	end
	local origin = pointGui.AbsolutePosition
	local p, s = button.AbsolutePosition, button.AbsoluteSize
	if Windows.covered(button, p.X + s.X / 2, p.Y + s.Y / 2) then
		finger.Visible = false
		glow.Visible = false
		return
	end
	-- the shine over the button (round like it)
	local pulse = (math.sin(os.clock() * K.GLOW_SPEED) + 1) / 2
	glow.Position = UDim2.fromOffset(p.X - origin.X - K.GLOW_PAD, p.Y - origin.Y - K.GLOW_PAD)
	glow.Size = UDim2.fromOffset(s.X + K.GLOW_PAD * 2, s.Y + K.GLOW_PAD * 2)
	local round = button:FindFirstChildOfClass("UICorner")
	glow:FindFirstChildOfClass("UICorner").CornerRadius = round
		and UDim.new(round.CornerRadius.Scale, round.CornerRadius.Offset + K.GLOW_PAD) or UDim.new(0, 12)
	glow.BackgroundTransparency = K.GLOW_FILL[1] + (K.GLOW_FILL[2] - K.GLOW_FILL[1]) * pulse
	glowStroke.Thickness = K.GLOW_STROKE[1] + (K.GLOW_STROKE[2] - K.GLOW_STROKE[1]) * pulse
	glow.Visible = true
	local bounce = math.abs(math.sin(os.clock() * 5)) * K.FINGER_BOUNCE
	local y = p.Y - origin.Y + s.Y + 2 + bounce
	if p.Y - origin.Y + s.Y + 2 + K.FINGER_BOUNCE + K.FINGER_SIZE.Y.Offset <= pointGui.AbsoluteSize.Y then
		finger.Text = "👆"
	else
		finger.Text = "👇"
		y = p.Y - origin.Y - K.FINGER_SIZE.Y.Offset - 2 - bounce
	end
	finger.Position = UDim2.fromOffset(p.X - origin.X + s.X / 2, y)
	finger.Visible = true
end

local hatching = false
-- (2026-10-03, "블랙 레터박스가 위쪽이 끝까지 안 차 있는데") the bars and the caption on their own layer that covers
-- Roblox's top bar strip and the phone's notch too (the tutorial's layer starts under the top bar)
local introGui = Instance.new("ScreenGui")
introGui.Name = "TutorialIntro"
introGui.ResetOnSpawn = false
introGui.IgnoreGuiInset = true
introGui.ScreenInsets = Enum.ScreenInsets.None
introGui.DisplayOrder = K.INTRO_DISPLAY_ORDER
introGui.Parent = player:WaitForChild("PlayerGui")
local introBars = {}
for _, top in ipairs({ true, false }) do
	local bar = Instance.new("Frame")
	bar.BackgroundColor3 = Color3.new(0, 0, 0)
	bar.BorderSizePixel = 0
	bar.Size = UDim2.new(1, 0, K.INTRO_BAR, 0)
	bar.AnchorPoint = Vector2.new(0, top and 1 or 0)
	bar.Position = UDim2.fromScale(0, top and 0 or 1)
	bar.ZIndex = 30
	bar.Visible = false
	bar.Parent = introGui
	introBars[top and "top" or "bottom"] = bar
end
local caption = Instance.new("TextLabel")
caption.BackgroundTransparency = 1
caption.Font = K.FONT
caption.TextColor3 = Color3.new(1, 1, 1)
caption.TextScaled = true
caption.AnchorPoint = Vector2.new(0.5, 0.5)
caption.Size = UDim2.new(0.9, 0, K.INTRO_BAR * 0.55, 0)
caption.Position = UDim2.fromScale(0.5, 1 - K.INTRO_BAR / 2)
caption.ZIndex = 31
caption.Text = ""
caption.Visible = false
caption.Parent = introGui
local introSkip = Instance.new("TextButton")
introSkip.Name = "IntroSkip"
introSkip.AnchorPoint = Vector2.new(1, 0.5)
introSkip.Position = UDim2.new(1, -K.INTRO_SKIP_RIGHT, K.INTRO_BAR / 2, 0)
introSkip.Size = K.INTRO_SKIP_SIZE
introSkip.BackgroundColor3 = K.INTRO_SKIP_COLOR
introSkip.BackgroundTransparency = 0.15
introSkip.Font = K.FONT
introSkip.TextColor3 = Color3.new(1, 1, 1)
introSkip.TextSize = K.INTRO_SKIP_TEXT
introSkip.Text = "⏩ 건너뛰기"
introSkip.ZIndex = 32
introSkip.Visible = false
introSkip.Parent = introGui
do
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 10)
	c.Parent = introSkip
end

local function bars(on)
	local top, bottom = introBars.top, introBars.bottom
	top.Visible, bottom.Visible = true, true
	local info = TweenInfo.new(K.INTRO_BAR_SECONDS, Enum.EasingStyle.Quad)
	TweenService:Create(top, info, { Position = UDim2.fromScale(0, on and K.INTRO_BAR or 0) }):Play()
	TweenService:Create(bottom, info, { Position = UDim2.fromScale(0, on and 1 - K.INTRO_BAR or 1) }):Play()
	if not on then
		task.delay(K.INTRO_BAR_SECONDS, function()
			top.Visible, bottom.Visible = false, false
		end)
	end
end

-- a point on the quadratic curve a → b → c
local function curve(a, b, c, t)
	return a:Lerp(b, t):Lerp(b:Lerp(c, t), t)
end

local function startReady()
	while player:GetAttribute("LanguagePick") do
		task.wait(0.2)
	end
	local loadingSince = os.clock()
	while player:GetAttribute("Loading") and os.clock() - loadingSince < K.INTRO_LOADING_WAIT do
		task.wait(0.2)
	end
	if not game:IsLoaded() then
		game.Loaded:Wait()
	end
end

local function waitCocoModel()
	local models = ReplicatedStorage:WaitForChild("TutorialModels", K.INTRO_MODEL_WAIT)
	if models then
		models:WaitForChild("Guide_Coco", K.INTRO_MODEL_WAIT)
	end
end

local arriving = false
local function arrive(lines, step)
	if hatching or arriving then
		return
	end
	arriving, hatching = true, true
	startReady()
	waitCocoModel()
	if not coco then
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		makeCoco(root and root.Position or Vector3.zero)
	end
	hatching = false
	for _, text in ipairs(lines) do
		if not coco then
			break
		end
		say(text, K.INTRO_LINE_SECONDS)
		task.wait(K.INTRO_LINE_SECONDS)
	end
	if step then
		task.wait(K.HATCH_SAY_SECONDS)
		Net.request("TutorialStepDone", step)
	end
	arriving = false
end

local function streamIsland(y)
	local reach = Config.Map.Radius
	local points = {}
	for x = -reach, reach, K.STREAM_STEP do
		for z = -reach, reach, K.STREAM_STEP do
			if x * x + z * z <= reach * reach then
				table.insert(points, Vector3.new(x, y, z))
			end
		end
	end
	table.sort(points, function(a, b)
		return a.Magnitude < b.Magnitude
	end)
	local state = { total = #points, done = 0, on = true }
	local nextOne = 0
	for worker = 1, K.STREAM_WORKERS do
		task.spawn(function()
			while state.on do
				nextOne += 1
				local i = nextOne
				if i > #points and worker > K.STREAM_KEEP_WORKERS then
					break
				end
				pcall(function()
					player:RequestStreamAroundAsync(points[(i - 1) % #points + 1], K.STREAM_TIMEOUT)
				end)
				if i <= #points then
					state.done += 1
				else
					task.wait(K.STREAM_AGAIN)
				end
			end
		end)
	end
	return state
end

local cinemaHidden = {}
local cinemaIsland = nil

local function cinemaRestore()
	if cinemaIsland then
		cinemaIsland.on = false
		cinemaIsland = nil
	end
	introSkip.Visible = false
	caption.Text, caption.Visible = "", false
	bars(false)
	pcall(function()
		RunService:UnbindFromRenderStep("IntroHideBodies")
	end)
	WitchTalk.close(true)
	removeCoco()
	for _, d in ipairs(player.Character and player.Character:GetDescendants() or {}) do
		if d:IsA("BasePart") or d:IsA("Decal") then
			d.LocalTransparencyModifier = 0
		end
	end
	for _, other in ipairs(cinemaHidden) do
		if other.Parent then
			other.Enabled = true
		end
	end
	cinemaHidden = {}
	pcall(function()
		game:GetService("StarterGui"):SetCore("TopbarEnabled", true)
	end)
	local camera = Workspace.CurrentCamera
	if camera and camera.CameraType == Enum.CameraType.Scriptable then
		camera.CameraType = Enum.CameraType.Custom
	end
	Net.request("CinemaFocus", false)
	player:SetAttribute("Cinematic", nil)
end

local function playCinematic()
	startReady()
	waitCocoModel()
	local character = player.Character or player.CharacterAdded:Wait()
	local root = character:WaitForChild("HumanoidRootPart", 10)
	local island = nil
	if root then
		pcall(function() -- the ground around the player (streaming)
			player:RequestStreamAroundAsync(root.Position)
		end)
		island = streamIsland(root.Position.Y)
		cinemaIsland = island
		task.wait(K.INTRO_START_DELAY)
		root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	end
	if not root then
		if island then
			island.on = false
		end
		cinemaIsland = nil
		return
	end
	local look = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z)
	look = look.Magnitude > 0.01 and look.Unit or Vector3.new(0, 0, -1)
	local right = look:Cross(Vector3.yAxis)
	local land = root.Position + look * K.INTRO_LAND_AHEAD + Vector3.new(0, K.COCO_UP - 1.5, 0)
	local from = land + look * K.INTRO_FROM_AHEAD + right * K.INTRO_FROM_SIDE + Vector3.new(0, K.INTRO_FROM_HIGH, 0)
	local bend = land + right * (K.INTRO_FROM_SIDE * -0.6) + Vector3.new(0, K.INTRO_FROM_HIGH * 0.45, 0)
	-- the camera: behind and a little over the player, looking up toward where Coco comes from
	local camera = Workspace.CurrentCamera
	local oldType = camera.CameraType
	player:SetAttribute("Cinematic", true)
	Net.request("CinemaFocus", true)
	camera.CameraType = Enum.CameraType.Scriptable
	local eye = root.Position - look * K.INTRO_CAMERA_BACK + Vector3.new(0, K.INTRO_CAMERA_UP, 0)
	camera.CFrame = CFrame.lookAt(eye, from:Lerp(land, 0.35))
	bars(true)
	WitchTalk.close(true)
	WitchTalk.preload()
	cinemaHidden = {}
	for _, other in ipairs(player.PlayerGui:GetChildren()) do
		if other:IsA("ScreenGui") and other.Enabled and other ~= introGui and other ~= gui then
			other.Enabled = false
			table.insert(cinemaHidden, other)
		end
	end
	pcall(function()
		game:GetService("StarterGui"):SetCore("TopbarEnabled", false)
	end)
	removeCoco()
	makeCoco(from)
	if coco then
		coco.bubble.Enabled = false
	end
	Sfx.play("WindGust")
	local started = os.clock()
	while os.clock() - started < K.INTRO_FLIGHT_SECONDS do
		local t = (os.clock() - started) / K.INTRO_FLIGHT_SECONDS
		local eased = 1 - (1 - t) ^ 2
		local at = curve(from, bend, land, eased)
		local ahead = curve(from, bend, land, math.min(1, eased + 0.02))
		local facing = (ahead - at).Magnitude > 0.01 and ahead or at - look
		coco.pos = at
		coco.model:PivotTo(CFrame.lookAt(at, facing) * CFrame.Angles(0, 0, t * K.INTRO_SPINS * 2 * math.pi))
		if math.random() < K.INTRO_TRAIL_CHANCE then
			Fx.burst(at, K.SPARKLES, 3, 4, 0.4, 0.5)
		end
		camera.CFrame = camera.CFrame:Lerp(CFrame.lookAt(eye, at:Lerp(land, 0.5)), 0.08)
		RunService.RenderStepped:Wait()
	end
	-- landed: a hop, sparkles, hello
	coco.pos = land
	coco.model:PivotTo(CFrame.lookAt(land, land - look))
	Sfx.play("GachaBig", land)
	Fx.burst(land + Vector3.new(0, 1, 0), K.SPARKLES, 30, 16, 0.6, 0.8)
	Sfx.play("NpcHello", land, 1.2)
	local closeShot = CFrame.lookAt(land + look * K.INTRO_CLOSE_BACK + Vector3.new(0, K.INTRO_CLOSE_UP, 0) + right * 1.5,
		land + Vector3.new(0, K.INTRO_CLOSE_LOOK, 0))
	TweenService:Create(camera, TweenInfo.new(0.8, Enum.EasingStyle.Quad), {
		CFrame = closeShot,
	}):Play()
	local skipLine = false
	local tap = UserInputService.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
			skipLine = true
		end
	end)
	local hideBodies = false
	local function bodiesHidden(hidden)
		for _, holder in ipairs({ player.Character, coco and coco.model }) do
			for _, d in ipairs(holder and holder:GetDescendants() or {}) do
				if d:IsA("BasePart") or d:IsA("Decal") then
					d.LocalTransparencyModifier = hidden and 1 or 0
				end
			end
		end
	end
	RunService:BindToRenderStep("IntroHideBodies", Enum.RenderPriority.Camera.Value + 2, function()
		if hideBodies then
			bodiesHidden(true)
		end
	end)
	caption.Visible = true
	local story = Config.Tutorial.IslandIntro
	local shots = Config.Tutorial.IslandShots
	local skipAll = false
	local skipConn = introSkip.Activated:Connect(function()
		skipAll = true
	end)
	introSkip.Visible = true
	local streamFrom = os.clock()
	if coco then
		coco.bubble.Enabled = true
	end
	for _, line in ipairs(Config.Tutorial.IslandHello) do
		if not coco or skipAll then
			break
		end
		say(line, K.INTRO_LINE_SECONDS + 1)
		caption.Text = Lang.t(line)
		skipLine = false
		local shown = os.clock()
		while os.clock() - shown < K.INTRO_LINE_SECONDS and not skipAll and not (skipLine and os.clock() - shown > K.INTRO_MIN_LINE) do
			RunService.RenderStepped:Wait()
		end
	end
	caption.Text = ""
	while island and island.done < island.total and os.clock() - streamFrom < K.STREAM_WAIT and not skipAll do
		RunService.RenderStepped:Wait()
	end
	do
		local map = Workspace:FindFirstChild("Map")
		local arrived = 0
		local watch = map and map.DescendantAdded:Connect(function(d)
			if d:IsA("BasePart") then
				arrived += 1
			end
		end)
		local settleFrom, calmSince = os.clock(), os.clock()
		local lastCount, lastAt = 0, os.clock()
		while watch and not skipAll and os.clock() - settleFrom < K.STREAM_SETTLE_MAX
			and os.clock() - calmSince < K.STREAM_SETTLE_FOR do
			task.wait(K.STREAM_SETTLE_STEP)
			local rate = (arrived - lastCount) / math.max(os.clock() - lastAt, 0.01)
			lastCount, lastAt = arrived, os.clock()
			if rate >= K.STREAM_SETTLE_RATE then
				calmSince = os.clock()
			end
		end
		if watch then
			watch:Disconnect()
		end
	end
	caption.Text = ""
	local shotParts = {}
	local shotCount = 0
	local meteor, shotTween, shotOrbit = nil, nil, nil
	local function clearShot()
		shotCount += 1
		if shotOrbit then
			shotOrbit:Disconnect()
			shotOrbit = nil
		end
		for _, part in ipairs(shotParts) do
			part:Destroy()
		end
		shotParts = {}
	end
	local function gateSpot()
		local map = Workspace:FindFirstChild("Map")
		local base = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
		local frame = base and base:GetAttribute("ArenaFrame")
		if not frame then
			return nil
		end
		local path = Formulas.lanePath(base:GetAttribute("DefenseMap"))
		return frame * CFrame.new(0, base:GetAttribute("DefenseUnitTop") or 0, 0), path
	end
	local function groundAt(at)
		local params = RaycastParams.new()
		params.FilterType = Enum.RaycastFilterType.Exclude
		local skip = { player.Character }
		for _, part in ipairs(shotParts) do
			table.insert(skip, part)
		end
		params.FilterDescendantsInstances = skip
		local a = K.ALTAR_BOXES
		local hit = Workspace:Raycast(at + Vector3.new(0, a.ground, 0), Vector3.new(0, -2 * a.ground, 0), params)
		return hit and hit.Position or at
	end
	local function witchSays(id)
		WitchTalk.say(Config.Story.Lines[id], WitchTalk.faceFor(id), { lift = K.INTRO_BAR })
	end
	local function altarBoxes(look)
		local a = K.ALTAR_BOXES
		local map = Workspace:FindFirstChild("Map")
		local zone = map and map:FindFirstChild("KeyZone")
		local altar = zone and zone:FindFirstChild("Zone_KeyAltar")
		local center = altar and altar:GetPivot().Position or look
		local mine = shotCount
		task.delay(a.sayAfter, function()
			if shotCount == mine then
				witchSays("Drop")
			end
		end)
		for i = 1, a.boxes do
			task.delay(a.first + (i - 1) * a.every, function()
				if shotCount ~= mine then
					return
				end
				local angle = math.random() * 2 * math.pi
				local r = a.spread[1] + math.random() * (a.spread[2] - a.spread[1])
				local ground = groundAt(center + Vector3.new(math.cos(angle) * r, 0, math.sin(angle) * r))
				local box = BoxFall.box(a.colors[math.random(1, #a.colors)], a.edge[1] + math.random() * (a.edge[2] - a.edge[1]))
				local land = CFrame.new(ground) * CFrame.Angles(0, math.random() * 2 * math.pi, 0)
				local from = ground
					+ Vector3.new((math.random() * 2 - 1) * a.skySpread, a.sky, (math.random() * 2 - 1) * a.skySpread)
				BoxFall.fall(box, land, from, function()
					if shotCount == mine then
						box:PivotTo(land)
						box.Parent = Workspace
						table.insert(shotParts, box)
					end
				end)
			end)
		end
	end
	local function raid()
		local frame, path = gateSpot()
		if not frame or not path then
			return nil
		end
		local r = K.RAID
		local center = frame.Position
		local models = ReplicatedStorage:FindFirstChild("DefenseModels")
		local mine = shotCount
		for i = 1, r.count do
			task.delay(r.gap * (i - 1), function()
				local source = models and models:FindFirstChild(Config.Monsters.Models[(i - 1) % #Config.Monsters.Models + 1])
				if shotCount ~= mine or not source then
					return
				end
				local fossil = source:Clone()
				for _, d in ipairs(fossil:GetDescendants()) do
					if d:IsA("BasePart") then
						d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
					end
				end
				local offset = (math.random() * 2 - 1) * r.lane
				local function place(s, sink)
					local x, z, tx, tz = Formulas.lanePoint(path, s, offset)
					local at = frame * Vector3.new(x, 0, z)
					local way = frame:VectorToWorldSpace(Vector3.new(tx, 0, tz))
					fossil:PivotTo(CFrame.lookAt(at, at + way) - Vector3.new(0, sink, 0))
					return at
				end
				local start = place(0, r.sink)
				fossil.Parent = Workspace
				table.insert(shotParts, fossil)
				Fx.burst(start + Vector3.new(0, 1, 0), K.BONE_COLORS, r.burst, 10, 0.7, 0.7)
				Sfx.play("ZombieRise", start)
				local t0 = os.clock()
				while fossil.Parent and shotCount == mine do
					local age = os.clock() - t0
					local s = math.max(0, age - r.rise) * r.speed
					place(s, age < r.rise and r.sink * (1 - age / r.rise) ^ 2 or 0)
					if s >= path.length then
						break
					end
					RunService.RenderStepped:Wait()
				end
			end)
		end
		local function point(v)
			return (frame * CFrame.new(v[1], v[2], v[3])).Position
		end
		return CFrame.lookAt(point(r.from), center), CFrame.lookAt(point(r.to), center)
	end
	local function startShot(kind, seconds)
		clearShot()
		if shotTween then
			shotTween:Cancel()
			shotTween = nil
		end
		if meteor then
			meteor:SetAttribute("Drive", false)
			if kind ~= "Field" and kind ~= "Witch" then
				meteor:Destroy()
				meteor = nil
			end
		end
		local goal = closeShot
		local moveSeconds, moveStyle = K.SHOT_MOVE_SECONDS, Enum.EasingStyle.Quad
		local crater = kind == "Field" and meteor and meteor:GetAttribute("Impact")
		local overview = not crater and K.MAP_SHOTS[kind]
		local tour = K.TOUR_SHOTS[kind]
		if tour then
			local frame = gateSpot()
			local arena = frame and frame.Position or root.Position
			local flat = Vector3.new(arena.X, 0, arena.Z)
			local home = flat.Magnitude > 1 and math.atan2(flat.Z, flat.X) or 0
			local ring = flat.Magnitude > 1 and flat.Magnitude or Config.Battlefield.Radius
			local radius = tour.edge and Config.Map.Radius * tour.edge or tour.field and Config.Battlefield.Radius * tour.field
				or ring * tour.ring + (tour.out or 0)
			local lookRadius = tour.edge and Config.Battlefield.Radius * tour.look or ring * tour.look
			local function at(deg, r, up)
				local a = home + math.rad(deg)
				return Vector3.new(math.cos(a) * r, arena.Y + up, math.sin(a) * r)
			end
			local function pose(q)
				local deg = tour.turn[1] + (tour.turn[2] - tour.turn[1]) * q
				return CFrame.lookAt(at(deg, radius, tour.up), at(deg + tour.lead, lookRadius, tour.lookUp))
			end
			for _, deg in ipairs({ tour.turn[1], (tour.turn[1] + tour.turn[2]) / 2, tour.turn[2] }) do
				task.spawn(function()
					pcall(function()
						player:RequestStreamAroundAsync(at(deg, radius, 0), K.STREAM_TIMEOUT)
					end)
				end)
			end
			camera.CFrame = pose(0)
			local began = os.clock()
			shotOrbit = RunService.RenderStepped:Connect(function()
				local q = math.clamp((os.clock() - began) / math.max(seconds, 0.1), 0, 1)
				camera.CFrame = pose((1 - math.cos(q * math.pi)) / 2)
			end)
			return
		elseif crater then
			local frame = gateSpot()
			local arena = frame and frame.Position or root.Position
			local flat = Vector3.new(arena.X, 0, arena.Z)
			local out = meteor:GetAttribute("Out")
			local dir = typeof(out) == "Vector3" and out or flat.Magnitude > 1 and flat.Unit or look
			local side = dir:Cross(Vector3.yAxis)
			local function point(v)
				return crater + dir * v[1] + side * v[2] + Vector3.new(0, v[3], 0)
			end
			local target = crater + Vector3.new(0, K.CRATER_LOOK_UP, 0)
			camera.CFrame = CFrame.lookAt(point(K.CRATER_FROM), target)
			goal = CFrame.lookAt(point(K.CRATER_TO), target)
			moveSeconds, moveStyle = seconds, Enum.EasingStyle.Sine
			local models = ReplicatedStorage:FindFirstChild("DefenseModels")
			for i = 1, K.CRATER_FOSSILS do
				local source = models and models:FindFirstChild(Config.Monsters.Models[(i - 1) % #Config.Monsters.Models + 1])
				if source then
					local fossil = source:Clone()
					for _, d in ipairs(fossil:GetDescendants()) do
						if d:IsA("BasePart") then
							d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
						end
					end
					local a = (i - 0.5) / K.CRATER_FOSSILS * 2 * math.pi + math.random() * 0.4
					local at = crater + Vector3.new(math.cos(a), 0, math.sin(a))
						* (K.CRATER_RING[1] + math.random() * (K.CRATER_RING[2] - K.CRATER_RING[1]))
					local facing = CFrame.lookAt(at, Vector3.new(point(K.CRATER_TO).X, at.Y, point(K.CRATER_TO).Z))
					fossil:PivotTo(facing - Vector3.new(0, K.CRATER_SINK, 0))
					fossil.Parent = meteor
					task.delay(K.CRATER_RISE_GAP * (i - 1), function()
						if not fossil.Parent then
							return
						end
						Fx.burst(at + Vector3.new(0, 1, 0), K.BONE_COLORS, 16, 12, 0.8, 0.8)
						Sfx.play("ZombieRise", at)
						local t0 = os.clock()
						while fossil.Parent and os.clock() - t0 < K.CRATER_RISE_SECONDS do
							local q = (os.clock() - t0) / K.CRATER_RISE_SECONDS
							fossil:PivotTo(facing - Vector3.new(0, K.CRATER_SINK * (1 - q) ^ 2, 0))
							RunService.RenderStepped:Wait()
						end
						if fossil.Parent then
							fossil:PivotTo(facing)
						end
					end)
				end
			end
		elseif kind == "Witch" then
			local w = K.WITCH_SHOT
			local frame = gateSpot()
			local arena = frame and frame.Position or root.Position
			local flat = Vector3.new(arena.X, 0, arena.Z)
			local out = meteor and meteor:GetAttribute("Out")
			local dir = typeof(out) == "Vector3" and out or flat.Magnitude > 1 and flat.Unit or look
			local side = dir:Cross(Vector3.yAxis)
			local map = Workspace:FindFirstChild("Map")
			local zone = map and map:FindFirstChild("KeyZone")
			local altar = zone and zone:FindFirstChild("Zone_KeyAltar")
			local impact = meteor and meteor:GetAttribute("Impact")
			local base = typeof(impact) == "Vector3" and impact
				or altar and altar:GetPivot().Position or Vector3.new(0, arena.Y, 0)
			local function point(v)
				return base + dir * v[1] + side * v[2] + Vector3.new(0, v[3], 0)
			end
			local target = base + Vector3.new(0, w.lookUp, 0)
			camera.CFrame = CFrame.lookAt(point(w.from), target)
			goal = CFrame.lookAt(point(w.to), target)
			moveSeconds, moveStyle = seconds, Enum.EasingStyle.Sine
			Fx.burst(target, K.BONE_COLORS, 40, 26, 1.6, 1.2)
			local mine = shotCount
			task.delay(w.sayAfter, function()
				if shotCount == mine then
					witchSays("Crater")
				end
			end)
		elseif kind == "Raid" then
			local from, to = raid()
			if from then
				camera.CFrame = from
				goal = to
				moveSeconds, moveStyle = seconds, Enum.EasingStyle.Sine
			end
		elseif overview then
			local frame = gateSpot()
			if frame then
				local arena = frame.Position
				local flat = Vector3.new(arena.X, 0, arena.Z)
				local dir = flat.Magnitude > 1 and flat.Unit or look
				local side = dir:Cross(Vector3.yAxis)
				local anchor = overview.anchor == "Arena" and arena or Vector3.new(0, arena.Y, 0)
				local function point(v)
					return anchor + dir * v[1] + side * v[2] + Vector3.new(0, v[3], 0)
				end
				local target = point(overview.look)
				camera.CFrame = CFrame.lookAt(point(overview.from), target)
				goal = CFrame.lookAt(point(overview.to), target)
				moveSeconds, moveStyle = seconds, Enum.EasingStyle.Sine
				local crowd = K.CROWD[kind]
				local fans = crowd and ShowCrowd.spawn(target, point(overview.to), crowd.Count, crowd.Back, crowd.Spread)
				if fans then
					table.insert(shotParts, fans)
				end
				if kind == "Altar" then
					altarBoxes(target)
				end
			end
		elseif kind == "Sky" then
			local frame = gateSpot()
			local arena = frame and frame.Position or root.Position
			local flat = Vector3.new(arena.X, 0, arena.Z)
			local dir = flat.Magnitude > 1 and flat.Unit or look
			local models = ReplicatedStorage:FindFirstChild("TutorialModels")
			local map = Workspace:FindFirstChild("Map")
			local zone = map and map:FindFirstChild("KeyZone")
			local altar = zone and zone:FindFirstChild("Zone_KeyAltar")
			meteor = MeteorShow.play(introGui, models and models:FindFirstChild("Fx_BoneStar"),
				altar and altar:GetPivot().Position or Vector3.new(0, arena.Y, 0), dir)
			witchSays("Throw")
			return
		end
		if goal == closeShot and kind ~= "Coco" then
			local o = K.MAP_SHOTS.Map
			local anchor = Vector3.new(0, root.Position.Y, 0)
			local side = look:Cross(Vector3.yAxis)
			local function point(v)
				return anchor + look * v[1] + side * v[2] + Vector3.new(0, v[3], 0)
			end
			camera.CFrame = CFrame.lookAt(point(o.from), point(o.look))
			goal = CFrame.lookAt(point(o.to), point(o.look))
			moveSeconds, moveStyle = seconds, Enum.EasingStyle.Sine
		end
		local focus = goal.Position + goal.LookVector * K.FOCUS_AHEAD
		Net.request("CinemaFocusAt", focus)
		task.spawn(function()
			pcall(function()
				player:RequestStreamAroundAsync(focus, K.STREAM_TIMEOUT)
			end)
		end)
		shotTween = TweenService:Create(camera, TweenInfo.new(moveSeconds, moveStyle), { CFrame = goal })
		shotTween:Play()
	end
	for i, line in ipairs(story) do
		if not coco or skipAll then
			break
		end
		if shots[i] then
			coco.bubble.Enabled = shots[i] == "Coco"
		end
		if shots[i] and shots[i] ~= shots[i - 1] then
			local run = 1
			while shots[i + run] == shots[i] do
				run += 1
			end
			startShot(shots[i], K.INTRO_LINE_SECONDS * run)
		end
		if shots[i] then
			local hide = shots[i] ~= "Coco"
			if hideBodies and not hide then
				bodiesHidden(false)
			end
			hideBodies = hide
		end
		say(line, K.INTRO_LINE_SECONDS + 1)
		caption.Text = Lang.t(line)
		skipLine = false
		local shown = os.clock()
		while os.clock() - shown < K.INTRO_LINE_SECONDS and not skipAll and not (skipLine and os.clock() - shown > K.INTRO_MIN_LINE) do
			RunService.RenderStepped:Wait()
		end
		if coco then
			coco.model:PivotTo(coco.model:GetPivot() + Vector3.new(0, K.INTRO_HOP, 0))
			task.delay(0.15, function()
				if coco then
					coco.model:PivotTo(coco.model:GetPivot() - Vector3.new(0, K.INTRO_HOP, 0))
				end
			end)
		end
	end
	tap:Disconnect()
	skipConn:Disconnect()
	introSkip.Visible = false
	if shotOrbit then
		shotOrbit:Disconnect()
		shotOrbit = nil
	end
	if island then
		island.on = false
	end
	cinemaIsland = nil
	Net.request("CinemaFocus", false)
	if shotTween then
		shotTween:Cancel()
	end
	if meteor then
		meteor:Destroy()
	end
	RunService:UnbindFromRenderStep("IntroHideBodies")
	hideBodies = false
	bodiesHidden(false)
	clearShot()
	WitchTalk.close(true)
	caption.Text, caption.Visible = "", false
	bars(false)
	if coco then
		coco.bubble.Enabled = true
	end
	for _, other in ipairs(cinemaHidden) do
		if other.Parent then
			other.Enabled = true
		end
	end
	cinemaHidden = {}
	pcall(function()
		game:GetService("StarterGui"):SetCore("TopbarEnabled", true)
	end)
	camera.CameraType = oldType == Enum.CameraType.Scriptable and Enum.CameraType.Custom or oldType
	player:SetAttribute("Cinematic", nil)
end

local function cinematic()
	if hatching then
		return
	end
	hatching = true
	local ok, problem = xpcall(playCinematic, debug.traceback)
	if not ok then
		warn("[Tutorial] island cinematic: " .. tostring(problem))
		cinemaRestore()
	end
	hatching = false
end

-- ---------------------------------------------------------------------------
-- Following the steps
-- ---------------------------------------------------------------------------

local lastIndex = nil
local openingShown = false
local function onStep()
	local id = player:GetAttribute("TutorialStep")
	local index = player:GetAttribute("TutorialIndex")
	if not id then
		if coco then -- the end: one last cheer
			say("최고야! 🎉", 2)
			Fx.burst(coco.model:GetPivot().Position + Vector3.new(0, 1.5, 0), K.SPARKLES, 40, 18, 0.7, 1)
			Sfx.play("Promotion")
			task.delay(2, removeCoco)
		end
		line.Visible, skip.Visible = false, false
		clearBeam()
		pointAt(nil)
		lastIndex = nil
		return
	end
	skip.Visible = player:GetAttribute("TutorialCanSkip") == true
	if lastIndex and index and index > lastIndex and coco then -- a step done
		say(K.PRAISE, Config.Tutorial.PraiseSeconds)
		Fx.burst(coco.model:GetPivot().Position + Vector3.new(0, 1.5, 0), K.SPARKLES, 24, 14, 0.6, 0.7)
		Sfx.play("LevelUp")
	end
	lastIndex = index
	if id == "Hatch" then
		task.spawn(arrive, {}, "Hatch")
	elseif not coco and not hatching and not openingShown and Config.Tutorial.Openings[player:GetAttribute("TutorialOpening") or ""] then
		openingShown = true
		task.spawn(arrive, Config.Tutorial.Openings[player:GetAttribute("TutorialOpening")])
	elseif not coco and not hatching then
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		makeCoco(root and root.Position or Vector3.zero)
	end
end
player:GetAttributeChangedSignal("TutorialStep"):Connect(onStep)
player:GetAttributeChangedSignal("TutorialIndex"):Connect(onStep)
onStep()

local introPlayed = false
local function firstIntro()
	if introPlayed or not player:GetAttribute("CocoIntro") then
		return
	end
	introPlayed = true
	startReady()
	Net.request("CocoIntroDone")
	introPlayed = false
end
player:GetAttributeChangedSignal("CocoIntro"):Connect(function()
	task.spawn(firstIntro)
end)
task.spawn(firstIntro)

local islandWaiting = false
local function islandIntro()
	if islandWaiting then
		return
	end
	islandWaiting = true
	while hatching or arriving or player:GetAttribute("CocoIntro") or player:GetAttribute("TutorialStep") do
		task.wait(0.5)
	end
	cinematic()
	local ok, problem = pcall(function()
		if coco then
			say("가자! 🦖", K.INTRO_BYE_SECONDS)
			task.wait(K.INTRO_BYE_SECONDS)
			if coco then
				Fx.burst(coco.model:GetPivot().Position + Vector3.new(0, 1.5, 0), K.SPARKLES, 30, 16, 0.6, 0.8)
				Sfx.play("WindGust")
				removeCoco()
			end
		end
	end)
	if not ok then
		warn("[Tutorial] island cinematic goodbye: " .. tostring(problem))
		removeCoco()
	end
	islandWaiting = false
end
Net.onPush("IslandCinematic", function()
	task.spawn(islandIntro)
end)

-- ---------------------------------------------------------------------------
-- Coco's card (steps with Info)
-- ---------------------------------------------------------------------------

local cardGui = Instance.new("ScreenGui")
cardGui.Name = "TutorialCard"
cardGui.ResetOnSpawn = false
cardGui.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets -- (2026-10-03, Galaxy Fold: clear of the camera hole)
cardGui.Parent = player:WaitForChild("PlayerGui")
local card = Instance.new("Frame")
card.Name = "Card"
-- (2026-10-03, "기본 튜토창은 저기다 놔주면 좋겠음, 튜토리얼 건너뛰기 나오는 칸 바로 밑에": was the screen's middle)
card.AnchorPoint = Vector2.new(0, 0)
card.Position = UDim2.fromOffset(K.CARD_LEFT, skipTop() + K.SKIP_SIZE.Y.Offset + K.CARD_GAP)
card.BackgroundColor3 = K.CARD_COLOR
card.BackgroundTransparency = K.CARD_TRANSPARENCY
card.Size = UDim2.fromOffset(K.CARD_SIZE.X.Offset, K.CARD_START_HEIGHT) -- (each card sets its own height)
card.Visible = false
card.Parent = cardGui
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 14)
	round.Parent = card
end
local cardStroke = Instance.new("UIStroke")
cardStroke.Thickness = K.CARD_STROKE
cardStroke.Color = Color3.new(1, 1, 1)
cardStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
cardStroke.Parent = card
local cardShine = Instance.new("UIGradient")
cardShine.Color = ColorSequence.new({
	ColorSequenceKeypoint.new(0, K.CARD_STROKE_COLORS[1]), ColorSequenceKeypoint.new(0.45, K.CARD_STROKE_COLORS[1]),
	ColorSequenceKeypoint.new(0.5, K.CARD_STROKE_COLORS[2]), ColorSequenceKeypoint.new(0.55, K.CARD_STROKE_COLORS[3]),
	ColorSequenceKeypoint.new(1, K.CARD_STROKE_COLORS[1]),
})
cardShine.Parent = cardStroke
RunService.RenderStepped:Connect(FrameMeter.wrap("Tutorial", function()
	if card.Visible then
		local t = os.clock()
		cardShine.Rotation = (t * K.CARD_SHINE_TURN) % 360
		cardStroke.Transparency = 0.15 * (1 + math.sin(t * K.CARD_SHINE_PULSE)) / 2
	end
end))
local cardLines = {}
local cardOk = Instance.new("TextButton")
cardOk.Font = Enum.Font.GothamBold
cardOk.TextSize = 16
cardOk.TextColor3 = Color3.new(1, 1, 1)
cardOk.BackgroundColor3 = K.CARD_OK_COLOR
cardOk.Text = "✅ 확인"
cardOk.AnchorPoint = Vector2.new(0.5, 1)
cardOk.Size = UDim2.fromOffset(140, 36)
cardOk.Position = UDim2.new(0.5, 0, 1, -10) -- (renderCard moves it right when "◀ 이전" shows)
cardOk.Parent = card
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 10)
	round.Parent = cardOk
end
-- (2026-10-03, "창에 다음, 이전이 있어서 이전을 누르면 전에 뭔말했는지도 다시 볼 수 있게") back a page, and past the
-- first page to the cards before
local cardBack = cardOk:Clone()
cardBack.BackgroundColor3 = K.CARD_BACK_COLOR
cardBack.Text = "◀ 이전"
cardBack.Size = UDim2.fromOffset(110, 36)
cardBack.AnchorPoint = Vector2.new(0, 1)
cardBack.Position = UDim2.new(0, 14, 1, -10)
cardBack.Visible = false
cardBack.Parent = card
local cardScale = Instance.new("UIScale")
cardScale.Parent = card
local cardFor = nil -- the step Id the card shows
local cardEnds = false -- true: an Info card (reading it ends the step); false: a Guide card (it only explains)
local guided = {} -- [step Id] = true: its Guide card was shown (once a run of the tutorial)
-- (2026-10-03, "나 영어인데 한국어로 말했잖아") Coco's words are put in the player's language here, as they are written
-- (the bubble and the line are rewritten every frame: the Translate script could lose to that)
local function T(text)
	return Lang.t(text)
end

-- (2026-10-03, "coco asks favor 이렇게 길면 읽겠냐.. 조금씩 나눠서 읽게 해야지 창에 다음 버튼을 넣든가") a card shows its
-- title and CARD_PAGE_LINES lines at a time; "다음 ▶ (1/3)" turns the page, the last page's button closes it.
-- "◀ 이전" goes back a page, and from a first page to the card before (the last CARD_HISTORY cards are kept)
local cardHistory = {} -- { { title, pages = { { lines } } } }, the one showing (or last shown) last
local cardPages = nil -- the card being looked at: { title, pages, page, index (in cardHistory) }
local renderCard -- (defined below)
local function cardDone()
	cardPages = nil
	card.Visible = false
	if cardFor then -- (a card opened again by pressing Coco only closes)
		local id = cardFor
		cardFor = nil
		if cardEnds then
			Net.request("TutorialStepDone", id)
		end
	end
end
local function lookAt(index, page)
	local c = cardHistory[index]
	cardPages = { title = c.title, pages = c.pages, page = page, index = index }
	renderCard(true)
	Sfx.play("UiClick")
end
cardOk.Activated:Connect(function()
	if not cardPages then
		return
	end
	if cardPages.page < #cardPages.pages then
		lookAt(cardPages.index, cardPages.page + 1)
	elseif cardPages.index < #cardHistory then -- (looking back: on to the next card, the current one last)
		lookAt(cardPages.index + 1, 1)
	else
		cardDone()
	end
end)
cardBack.Activated:Connect(function()
	if not cardPages then
		return
	end
	if cardPages.page > 1 then
		lookAt(cardPages.index, cardPages.page - 1)
	elseif cardPages.index > 1 then
		lookAt(cardPages.index - 1, #cardHistory[cardPages.index - 1].pages)
	end
end)
-- (2026-10-03, "튜토리얼 창은 이전 다음 확인만 있게 하자. X버튼 잘못누르면 골때리니까") no X, and Esc doesn't close it
Windows.register(card, cardDone, { Keep = true })
-- (2026-10-03, "튜토창때부터 줘야지 폭탄으로 해봐요 라고할때") the buttons the card talks about stay on the screen
card:SetAttribute("LeavesButtons", true)
local placeCard -- (defined below)
-- pressing Coco (or its bubble) while the card is closed: the card shown last, from its first page
reopenCard = function()
	if card.Visible or #cardHistory == 0 or hatching then
		return
	end
	cardPages = { title = cardHistory[#cardHistory].title, pages = cardHistory[#cardHistory].pages, page = 1,
		index = #cardHistory }
	renderCard(true)
	placeCard()
	card.Visible = true
	Sfx.play("UiClick")
end
-- under the skip button; smaller when the screen can't hold it (above the 🔔, left of the right column)
function placeCard()
	local screenY = cardGui.AbsoluteSize.Y
	local _, _, freeW = Windows.freeArea(cardGui)
	skip.Position = UDim2.new(0, K.SKIP_POS.X.Offset, 0, skipTop())
	local top = skipTop() + K.SKIP_SIZE.Y.Offset + K.CARD_GAP
	local room = if screenY >= 1 then screenY - top - K.CARD_BOTTOM_ROOM else math.huge
	card.Position = UDim2.fromOffset(K.CARD_LEFT, top)
	local leftFree = Windows.freeArea(cardGui)
	local width = math.max(1, freeW - math.max(0, K.CARD_LEFT - leftFree)) -- (it starts CARD_LEFT in)
	cardScale.Scale = math.min(1, width / K.CARD_SIZE.X.Offset, math.max(room, 1) / math.max(card.Size.Y.Offset, 1))
end
cardGui:GetPropertyChangedSignal("AbsoluteSize"):Connect(placeCard)
card:GetPropertyChangedSignal("Size"):Connect(placeCard)

function renderCard(speak)
	for _, l in ipairs(cardLines) do
		l:Destroy()
	end
	cardLines = {}
	local lines = { cardPages.title }
	for _, l in ipairs(cardPages.pages[cardPages.page]) do
		table.insert(lines, l)
	end
	local last = cardPages.page >= #cardPages.pages
	local current = cardPages.index >= #cardHistory
	if last and current then
		cardOk.Text = T("✅ 확인") -- (2026-10-03: was "알겠어! ▶"; the buttons: 이전 · 다음 · 확인)
	elseif last then
		cardOk.Text = T("다음 ▶")
	else
		cardOk.Text = T(string.format("다음 ▶ (%d/%d)", cardPages.page, #cardPages.pages))
	end
	cardBack.Text = T("◀ 이전")
	cardBack.Visible = cardPages.page > 1 or cardPages.index > 1
	-- with "◀ 이전": the two at the sides; alone: "다음" in the middle
	if cardBack.Visible then
		cardOk.AnchorPoint = Vector2.new(1, 1)
		cardOk.Position = UDim2.new(1, -14, 1, -10)
	else
		cardOk.AnchorPoint = Vector2.new(0.5, 1)
		cardOk.Position = UDim2.new(0.5, 0, 1, -10)
	end
	-- (2026-10-03) each line as tall as its words wrap to, in the player's language (a long translation never spills)
	local width = K.CARD_SIZE.X.Offset - 28
	local y = 10
	for i, text in ipairs(lines) do
		local l = Instance.new("TextLabel")
		l.BackgroundTransparency = 1
		l.Font = Enum.Font.GothamBold
		l.TextSize = i == 1 and K.CARD_TITLE_TEXT or K.CARD_TEXT
		l.TextColor3 = i == 1 and K.CARD_TITLE or Color3.new(1, 1, 1)
		l.TextXAlignment = Enum.TextXAlignment.Left
		l.TextWrapped = true
		local shown = T(text)
		l.Text = shown
		local fits = TextService:GetTextSize(shown, l.TextSize, l.Font, Vector2.new(width, 1000))
		local h = math.max(fits.Y + K.CARD_LINE_PAD, i == 1 and K.CARD_LINE + 6 or K.CARD_LINE)
		l.Size = UDim2.new(1, -28, 0, h)
		l.Position = UDim2.fromOffset(14, y)
		l.Parent = card
		table.insert(cardLines, l)
		y += h + (i == 1 and 4 or 0)
	end
	card.Size = UDim2.fromOffset(K.CARD_SIZE.X.Offset, y + 54)
	if speak then
		local said = {}
		for _, l in ipairs(cardLines) do
			table.insert(said, l.Text)
		end
		CocoVoice.babble(table.concat(said, " "))
	end
end

local function showCard(s, lines, ends)
	cardEnds = ends
	local pages, pageLines = {}, nil
	for i = 2, #lines do
		if not pageLines or #pageLines >= K.CARD_PAGE_LINES then
			pageLines = {}
			table.insert(pages, pageLines)
		end
		table.insert(pageLines, lines[i])
	end
	if #pages == 0 then
		pages = { {} }
	end
	table.insert(cardHistory, { title = lines[1], pages = pages })
	if #cardHistory > K.CARD_HISTORY then
		table.remove(cardHistory, 1)
	end
	cardPages = { title = lines[1], pages = pages, page = 1, index = #cardHistory }
	renderCard(true)
	placeCard()
	cardFor = s.Id
	card.Visible = true
	Sfx.play("LevelUp")
end
player:GetAttributeChangedSignal("Language"):Connect(function() -- (the card in the new language)
	if card.Visible and cardPages then
		renderCard()
	end
end)

K.SKIP_LINES = {
	did = "✅ 전에 직접 해 봤으니 읽고 넘어가요",
	cant = "📖 지금은 해 볼 수 없으니 읽고 넘어가요",
	done = "✅ 벌써 했어요! 읽고 넘어가요",
}

local function checkCard()
	local id = player:GetAttribute("TutorialStep")
	local s = id and stepInfo(id)
	local skipped = K.SKIP_LINES[player:GetAttribute("TutorialSkip") or ""]
	if s and skipped then -- (a hands-on step done before, or not possible now: its card, then on)
		if cardFor ~= s.Id or not cardEnds then
			local from = s.Guide or s.Info or { s.Text }
			local lines = { from[1], skipped }
			for i = 2, #from do
				table.insert(lines, from[i])
			end
			showCard(s, lines, true)
		end
	elseif s and s.Info and ((player:GetAttribute("TutorialCount") or 0) >= 1 or s.Client) then
		if cardFor ~= s.Id or not cardEnds then
			showCard(s, s.Info, true)
		end
	elseif s and s.Guide and not guided[s.Id] then
		guided[s.Id] = true
		showCard(s, s.Guide, false)
	elseif card.Visible and (not s or cardFor ~= s.Id) then
		cardFor = nil
		card.Visible = false
	end
end
player:GetAttributeChangedSignal("TutorialStep"):Connect(checkCard)
player:GetAttributeChangedSignal("TutorialCount"):Connect(checkCard)
player:GetAttributeChangedSignal("TutorialSkip"):Connect(checkCard)
checkCard()

RunService.RenderStepped:Connect(FrameMeter.wrap("Tutorial", function(dt)
	local id = player:GetAttribute("TutorialStep")
	if not id then
		return
	end
	local s = stepInfo(id)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	-- (a big window on a small phone covers its corner; the last step points at the mission board there)
	skip.Visible = player:GetAttribute("TutorialCanSkip") == true and not Windows.anyOpen(card) and id ~= "Missions"
		-- (the card sits under it: 2026-10-03)
	if skip.Visible then
		skipShownAt = skipShownAt or os.clock()
		local t = os.clock() - skipShownAt
		skipScale.Scale = t < K.SKIP_PULSE_SECONDS and 1 + 0.08 * math.max(0, math.sin(t * math.pi * 2)) or 1
	end
	-- Coco beside me, bobbing, looking at my character (2026-10-03, "코코가 계속 화면으로 시선을 보고 있는데, 게임 속
	-- 캐릭터에 시선을 고정해야지": was the camera)
	if coco and root and not hatching then
		local look = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z)
		look = look.Magnitude > 0.01 and look.Unit or Vector3.new(0, 0, -1)
		local right = look:Cross(Vector3.yAxis)
		local want = root.Position + right * K.COCO_SIDE + look * K.COCO_AHEAD
			+ Vector3.new(0, K.COCO_UP - 3 + math.sin(os.clock() * K.COCO_BOB_SPEED) * K.COCO_BOB, 0)
		coco.pos = coco.pos:Lerp(want, math.min(1, dt * K.COCO_FOLLOW))
		local face = Vector3.new(root.Position.X, coco.pos.Y, root.Position.Z)
		if (face - coco.pos).Magnitude < 0.01 then
			face = coco.pos - look
		end
		coco.model:PivotTo(CFrame.lookAt(coco.pos, face))
	end
	-- the line (and Coco's bubble when not praising)
	if s then
		local count = player:GetAttribute("TutorialCount") or 0
		local text = Lang.t(s.Text) .. ((s.Count or 1) > 1 and string.format(" (%d/%d)", math.min(count, s.Count), s.Count) or "")
		if line.Text ~= "🦖 " .. text then
			line.Text = "🦖 " .. text
		end
		-- (2026-10-02, "코코가 이걸 중복으로 말 안 해도 되지, 그냥 말풍선만") the line at the top only while Coco's
		-- bubble is off the screen
		local camera = Workspace.CurrentCamera
		local cocoSeen = false
		if coco and camera then
			local _, onScreen = camera:WorldToViewportPoint(coco.pos)
			cocoSeen = onScreen
		end
		line.Visible = not cocoSeen
		if coco and os.clock() >= sayUntil and coco.text.Text ~= text then
			coco.text.Text = text
			if coco.voiced ~= s.Id and not card.Visible then
				CocoVoice.babble(text)
			end
			coco.voiced = s.Id
		end
	end
	-- the small "press Coco" line in the bubble, while a card can be seen again (2026-10-03)
	if coco then
		local showHint = not card.Visible and #cardHistory > 0 and not hatching
		if coco.hint.Visible ~= showHint then
			coco.hint.Visible = showHint
			coco.hint.Text = Lang.t("💬 채팅을 다시 보려면 코코를 누르세요")
			coco.text.Size = showHint and UDim2.new(1, 0, 1, -K.BUBBLE_HINT_HEIGHT) or UDim2.fromScale(1, 1)
			coco.bubble.Size = showHint and K.BUBBLE_SIZE + UDim2.fromOffset(0, K.BUBBLE_HINT_HEIGHT) or K.BUBBLE_SIZE
		end
	end
	-- the beam
	local kind = player:GetAttribute("TutorialTargetKind")
	local target = player:GetAttribute("TutorialTarget")
	if kind == "Mineral" then
		if os.clock() - mineralAt >= K.MINERAL_EVERY then
			mineralAt = os.clock()
			nearestMineral = findMineral()
		end
		target = nearestMineral
	end
	aimBeam(typeof(target) == "Vector3" and target or nil)
	-- the finger
	if s and s.Buttons and not player:GetAttribute("TutorialSkip") then
		-- (2026-10-04) a row of buttons: the finger under the furthest one along that is on the screen now
		local found = nil
		for i = #s.Buttons, 1, -1 do
			found = found or findButtonIn(s.Buttons[i])
		end
		local holder = nil
		for i = 1, #s.Buttons do
			local entry = s.Buttons[i]
			holder = holder or not found and FoldHint.holderFor(type(entry) == "table" and entry.Exact or entry, type(entry) == "table")
		end
		FoldHint.show(holder or nil, true)
		pointAt(found or holder or nil)
	elseif s and s.Button and not player:GetAttribute("TutorialSkip") and not (s.Busy and player:GetAttribute(s.Busy) ~= nil) then -- (a skipped step: only its card)
		local found = findButton(s.Button)
		local holder = not found and FoldHint.holderFor(s.Button) or nil
		FoldHint.show(holder, true)
		pointAt(found or holder, found and s.Client and function()
			Net.request("TutorialStepDone", s.Id)
		end or nil)
	else
		FoldHint.show(nil)
		pointAt(nil)
	end
end))

-- ---------------------------------------------------------------------------
-- (2026-10-03) The tutorial field: on the way there, and Coco's welcome back in the game
-- ---------------------------------------------------------------------------

K.WELCOME = {
	-- (2026-10-03) the rest is learned on the beginner missions (Config.StarterMissions Learn), not on trips to the field
	paid = { "🏠 진짜 시작!", "REWARD", "🏠 이제 내 기지에서 처음부터 시작해요",
		"📋 나머지는 왼쪽 위 초보 미션으로 배워요 (미션마다 🎁)" },
	done = { "🏠 진짜 시작!", "🏠 이제 내 기지에서 처음부터 시작해요",
		"📋 나머지는 왼쪽 위 초보 미션으로 배워요 (미션마다 🎁)" },
	-- (2026-10-04) skipped: the reward waits for 설정's "처음부터 전부"
	skipped = { "🏠 내 기지", "⏩ 튜토리얼을 건너뛰어서 보상은 아직 안 받았어요",
		"🎁 ⚙️ 설정 → 📖 코코에게 배우기 → 처음부터 전부를 끝까지 하면 받아요", "📋 왼쪽 위 초보 미션을 하나씩 따라가요" },
	-- (2026-10-03) a lesson learned the first time (player attribute TutorialLesson: the part)
	lesson = { "📖 배움 완료!", "LESSON", "🏠 배운 걸 내 기지에서 써 봐요!", "📖 다른 배움도 ⚙️ 설정 → 📖 코코에게 배우기" },
	failed = { "🐣 튜토리얼", "⚠️ 튜토리얼 필드로 가지 못했어요", "⚙️ 설정 → 📖 코코에게 배우기로 다시 해 보세요" },
}
local function welcomeBack()
	local kind = player:GetAttribute("TutorialWelcome")
	local lines = kind and K.WELCOME[kind]
	if not lines then
		return
	end
	local shown = {}
	for _, l in ipairs(lines) do
		if l == "REWARD" then
			local f = Config.Tutorial.Field
			l = string.format("🎁 튜토리얼 완료 보상: %s · 🍀 행운 %d분", Formulas.rewardShortText(f.Reward),
				f.RewardLuckMinutes)
		elseif l == "LESSON" then
			local id = player:GetAttribute("TutorialLesson")
			local part
			for _, p in ipairs(Config.Tutorial.Parts) do
				part = p.Id == id and p or part
			end
			l = part and string.format("%s · 🎁 %s", part.Name, Formulas.rewardShortText(part.Reward)) or ""
		end
		table.insert(shown, l)
	end
	showCard({ Id = "WelcomeBack" }, shown, false)
end
player:GetAttributeChangedSignal("TutorialWelcome"):Connect(welcomeBack)
task.defer(welcomeBack)

local function travel()
	if player:GetAttribute("TutorialTravel") then
		showCard({ Id = "Travel" }, { "🐣 튜토리얼 필드로 가요!", "🚀 나만의 연습 필드로 이동하는 중이에요. 잠시만 기다려요" }, false)
	elseif cardFor == "Travel" then
		cardFor = nil
		card.Visible = false
	end
end
player:GetAttributeChangedSignal("TutorialTravel"):Connect(travel)
travel()

