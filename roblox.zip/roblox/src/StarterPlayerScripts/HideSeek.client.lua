--[[
HideSeek: 🙈 hide-and-seek on this screen (2026-10-03; the server's HideSeek service decides everything).

- The rooms (the board's prompt by the key altar, the corner button): the 🎮 놀이방 window's 🙈 tab,
  StarterPlayerScripts/GameRooms (2026-10-04: with the 🏁 race rooms; it was here).
- In a game (player attributes HideSeekRoom, HideSeekRole, HideSeekPhase, HideSeekUntil, HideSeekLeft): a bar at the
  top middle (where the race bar goes) with my role, the phase, the time left, the hiders left and 🏳️ 기권.
- ⏱️ (2026-10-04) a beep each of the last 5 seconds of the hiding time and of the game, a chime when the seeker sets off.
- Win or lose (Net push HideSeekResult, 2026-10-03, "승패 이후 승리! 패배! 같은 효과와 효과음"): a big "🏆 승리!" or
  "😢 패배!" pops up in the middle with why under it, the Victory or Defeat sound, confetti on a win. (2026-10-04) Under
  it the room's mode: 🏆 랭킹전 with this week's ranked wins (or that a win over the same rival no longer counts), or
  🎈 일반전 (nothing kept).
- Hiders don't show: the labels over a hider's head, their auras and lights are turned off on every other screen
  while they hide (and back on after).
- 🕸️ 함정 (2026-10-03): a hider's button where the slap button was (CombatFx hides that one for hiders), or Q: Net
  request HideSeekTrap (the server puts it down at my feet and says why not); how many are left (player attribute
  HideSeekTraps) on it. Net push HideSeekTrapFx(kind, position, caught, owner): the trap's sound there, for everyone
  near; on a snap ("함정도 사람 걸려서 닫힐때 소리나야해") the caught seeker hears it loud in their ears, the trap's owner
  wherever they hide, and a "🕸️ 철컥!" pops over it with a puff of dust.
- 💓 (2026-10-03, "술래가 가까워지면 심장박동 소리가 들리고 숨은 사람에게, 술래가 멀어지면 심장박동 줄어들게"): while
  seeking, a hider hears a heartbeat once the seeker is within Shared/HeartPulse's range: faster and louder the nearer, slower and
  softer going away, with a beating 💓 in the bar.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Fx = require(Shared:WaitForChild("Fx"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local HeartPulse = require(Shared:WaitForChild("HeartPulse"))
local Lang = require(Shared:WaitForChild("Lang")) -- (Lang.set: a text set every frame, only when it changes)
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer
local C = Config.HideSeek

-- display only
local FONT = Enum.Font.GothamBold
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_QUIT = Color3.fromRGB(200, 80, 80)
local COLOR_SEEKER = Color3.fromRGB(255, 120, 110)
local COLOR_HIDER = Color3.fromRGB(130, 220, 140)
local BAR_TOP = 6 -- the race bar's place (Race): the defense line hides meanwhile
local BAR_SIZE = UDim2.fromOffset(330, 36)
local QUIT_SIZE = UDim2.fromOffset(60, 30)
local RESULT_SIZE = UDim2.fromOffset(360, 130) -- the 🏆 승리! / 😢 패배! banner (2026-10-04: with the room's mode line)
local RESULT_TOP = 0.28 -- its middle, this share down the screen
local RESULT_SECONDS = 3.5 -- shown this long, then it fades
local RESULT_POP = 0.35 -- seconds to pop in
local COLOR_WIN = Color3.fromRGB(255, 215, 80)
local COLOR_LOSE = Color3.fromRGB(150, 170, 220)
local HIDE_EVERY = 0.25 -- seconds between turning hiders' labels off again
-- (2026-10-03, "술래가 멀리서 윤곽으로 안 보이게 해줘") the seeker's red mark (Highlight HideSeekMark) only when they
-- are this near my camera (and not behind something: the server makes it Occluded)
local SEEKER_MARK_NEAR = 45
local HIDDEN_CLASSES = { "BillboardGui", "ParticleEmitter", "Beam", "Trail", "PointLight", "SpotLight", "Highlight" }
local TRAP_SIZE = UDim2.fromOffset(84, 84) -- 🕸️ 함정: the slap button's size and place (CombatFx), hidden for a hider
local TRAP_POS = UDim2.new(1, -112, 1, -20)
local TRAP_KEY = Enum.KeyCode.Q
local COLOR_TRAP = Color3.fromRGB(126, 143, 60)
local COLOR_DIM = Color3.fromRGB(110, 110, 120)
local SNAP_GAIN_CAUGHT = 0.9 -- the caught seeker hears the snap right in their ears ... (2026-10-04: was 1.4, too loud)
local SNAP_GAIN_OWNER = 0.6 -- (was 0.8) ... the trap's owner wherever they hide (the rest: from the trap, fading with distance)
local SNAP_POP_SIZE = UDim2.fromOffset(150, 50) -- "🕸️ 철컥!" over the trap
local SNAP_POP_UP = 3 -- studs over it
local SNAP_POP_SECONDS = 1.2
local SNAP_POP_RANGE = 150 -- studs it shows from
local COLOR_SNAP = Color3.fromRGB(255, 225, 110)
local SNAP_DUST = { Color3.fromRGB(160, 130, 90), Color3.fromRGB(235, 235, 235) }
local COUNTDOWN = 5 -- (2026-10-04) seconds: a beep each of the last ones before the seeker sets off and before the end
local HEART_CHECK = 0.1 -- seconds between looks at how near the seeker is
local HEART_SIZE = 26 -- the 💓 in the bar
local HEART_POP = 1.5 -- its size on a beat

local gui = Instance.new("ScreenGui")
gui.Name = "HideSeek"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.TextWrapped = true
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 13
	b.TextColor3 = Color3.new(1, 1, 1)
	b.BackgroundColor3 = color
	b.Text = text
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 8)
	return b
end

-- ---------------------------------------------------------------------------
-- The game bar
-- ---------------------------------------------------------------------------

local bar = Instance.new("Frame")
bar.Name = "HideSeekBar" -- (WeatherFx puts its line under it while it shows)
bar.AnchorPoint = Vector2.new(0.5, 0)
bar.Position = UDim2.new(0.5, 0, 0, BAR_TOP)
bar.Size = BAR_SIZE
bar.BackgroundColor3 = COLOR_BG
bar.BackgroundTransparency = 0.15
bar.Visible = false
bar.Parent = gui
corner(bar, 10)
local barText = label(bar, "", UDim2.new(1, -QUIT_SIZE.X.Offset - HEART_SIZE - 18, 1, 0), UDim2.fromOffset(8, 0), 14)
barText.TextXAlignment = Enum.TextXAlignment.Left
barText.TextScaled = true
local quit = button(bar, "🏳️ 기권", COLOR_QUIT, QUIT_SIZE, UDim2.new(1, -QUIT_SIZE.X.Offset - 3, 0.5, -QUIT_SIZE.Y.Offset / 2))
quit.Activated:Connect(function()
	Net.request("HideSeekLeave")
end)
local heart = label(bar, "💓", UDim2.fromOffset(HEART_SIZE, HEART_SIZE),
	UDim2.new(1, -QUIT_SIZE.X.Offset - HEART_SIZE - 6, 0.5, -HEART_SIZE / 2), 20)
heart.Visible = false
local heartScale = Instance.new("UIScale")
heartScale.Parent = heart

-- 🕸️ 함정: in the slap button's place while I hide
local trapButton = button(gui, "", COLOR_TRAP, TRAP_SIZE, TRAP_POS)
trapButton.Name = "HideSeekTrap"
trapButton.AnchorPoint = Vector2.new(1, 1)
trapButton.TextSize = 16
trapButton.Visible = false
trapButton:FindFirstChildOfClass("UICorner").CornerRadius = UDim.new(0.5, 0)
local trapPressed = -math.huge
local function practicingTraps()
	return player:GetAttribute("HideSeekTrapPractice") == true and player:GetAttribute("HideSeekRoom") == nil
end
local function putTrap()
	if (player:GetAttribute("HideSeekRole") ~= "Hider" and not practicingTraps())
		or (player:GetAttribute("HideSeekTraps") or 0) <= 0 or os.clock() - trapPressed < C.TrapCooldown then
		return
	end
	trapPressed = os.clock()
	Net.request("HideSeekTrap")
end
trapButton.Activated:Connect(putTrap)
UserInputService.InputBegan:Connect(function(input, processed)
	if not processed and input.KeyCode == TRAP_KEY then
		putTrap()
	end
end)
Net.onPush("HideSeekTrapFx", function(kind, at, caught, owner)
	if typeof(at) ~= "Vector3" then
		return
	elseif kind ~= "Snap" then
		Sfx.play("TrapSet", at)
		return
	end
	if caught == player.UserId then
		Sfx.play("TrapSnap", nil, 1, SNAP_GAIN_CAUGHT)
	elseif owner == player.UserId then
		Sfx.play("TrapSnap", nil, 1, SNAP_GAIN_OWNER)
	else
		Sfx.play("TrapSnap", at)
	end
	Fx.burst(at + Vector3.new(0, 0.5, 0), SNAP_DUST, 18, 10, 0.5, 0.5)
	local spot = Instance.new("Attachment")
	spot.WorldPosition = at
	spot.Parent = Workspace.Terrain
	local pop = Instance.new("BillboardGui")
	pop.Adornee = spot
	pop.Size = SNAP_POP_SIZE
	pop.StudsOffsetWorldSpace = Vector3.new(0, SNAP_POP_UP, 0)
	pop.AlwaysOnTop = true
	pop.MaxDistance = SNAP_POP_RANGE
	local text = label(pop, "🕸️ 철컥!", UDim2.fromScale(1, 1), UDim2.new(), 24)
	text.Font = Enum.Font.FredokaOne
	text.TextScaled = true
	text.TextColor3 = COLOR_SNAP
	text.TextStrokeTransparency = 0
	text.TextStrokeColor3 = Color3.fromRGB(40, 30, 20)
	local scale = Instance.new("UIScale")
	scale.Scale = 0.4
	scale.Parent = text
	pop.Parent = gui
	TweenService:Create(scale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
	task.delay(SNAP_POP_SECONDS, function()
		pop:Destroy()
		spot:Destroy()
	end)
end)

local function clock(seconds)
	seconds = math.max(0, math.ceil(seconds))
	return string.format("%d:%02d", seconds // 60, seconds % 60)
end

local function inGame()
	return player:GetAttribute("HideSeekRoom") ~= nil
end

local countShown = nil -- "phase:seconds" of the last countdown second heard (one beep each)
RunService.Heartbeat:Connect(FrameMeter.wrap("HideSeek", function()
	local on = inGame()
	bar.Visible = on
	local traps = player:GetAttribute("HideSeekTraps") or 0
	trapButton.Visible = (on and player:GetAttribute("HideSeekRole") == "Hider") or practicingTraps()
	if trapButton.Visible then
		Lang.set(trapButton, string.format("🕸️ 함정\n%d개 (Q)", traps))
		trapButton.BackgroundColor3 = (traps > 0 and os.clock() - trapPressed >= C.TrapCooldown) and COLOR_TRAP or COLOR_DIM
	end
	if not on then
		countShown = nil
		return
	end
	local seeker = player:GetAttribute("HideSeekRole") == "Seeker"
	local hiding = player:GetAttribute("HideSeekPhase") == "Hiding"
	-- (2026-10-04, "술래가 찾으러가기 5초 타임카운트 사운드도 넣고, 끝나기5초 전 카운트 사운드도 넣자") a beep each of the last
	-- COUNTDOWN seconds of the hiding time and of the seeking time; a chime when the seeker sets off
	local phase = player:GetAttribute("HideSeekPhase") or ""
	local count = math.ceil((player:GetAttribute("HideSeekUntil") or 0) - Workspace:GetServerTimeNow())
	local key = phase .. ":" .. count
	if count >= 1 and count <= COUNTDOWN and key ~= countShown then
		Sfx.play("CountTick")
	end
	if countShown and string.sub(countShown, 1, 7) == "Hiding:" and phase == "Seeking" then
		Sfx.play("CountGo")
	end
	countShown = key
	local left = clock((player:GetAttribute("HideSeekUntil") or 0) - Workspace:GetServerTimeNow())
	local n = player:GetAttribute("HideSeekLeft") or 0
	if seeker then
		Lang.set(barText, hiding and string.format("😈 술래 · 숨는 시간 %s · %d명", left, n)
			or string.format("😈 술래 · 찾기 %s · 남은 %d명", left, n))
	else
		Lang.set(barText, hiding and string.format("🙈 숨어요! %s · 찰싹 금지", left)
			or string.format("🙈 버티기 %s · 남은 %d명", left, n))
	end
	barText.TextColor3 = seeker and COLOR_SEEKER or COLOR_HIDER
end))

local function seekerNearness()
	if player:GetAttribute("HideSeekRole") ~= "Hider" or player:GetAttribute("HideSeekPhase") ~= "Seeking" then
		return nil
	end
	local room = player:GetAttribute("HideSeekRoom")
	local me = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	for _, other in ipairs(Players:GetPlayers()) do
		if me and other:GetAttribute("HideSeekRoom") == room and other:GetAttribute("HideSeekRole") == "Seeker" then
			local root = other.Character and other.Character:FindFirstChild("HumanoidRootPart")
			local d = root and (root.Position - me.Position).Magnitude
			return HeartPulse.nearness(d)
		end
	end
	return nil
end

task.spawn(function()
	local beat = HeartPulse.beater(heartScale, HEART_POP)
	while true do
		task.wait(HEART_CHECK)
		local near = seekerNearness()
		heart.Visible = near ~= nil
		beat(near)
	end
end)

-- the defense line (Placement) sits where the bar is: off while I play
local function toggleLine()
	local line = player.PlayerGui:FindFirstChild("ArenaLine")
	if line and line:IsA("ScreenGui") and player:GetAttribute("Racing") == nil then
		line.Enabled = not inGame()
	end
end
player:GetAttributeChangedSignal("HideSeekRoom"):Connect(toggleLine)

-- ---------------------------------------------------------------------------
-- Hiders don't show on other screens
-- ---------------------------------------------------------------------------

local turnedOff = {} -- [instance] = true: what this script turned off (to turn back on)

local function hideable(item)
	for _, class in ipairs(HIDDEN_CLASSES) do
		if item:IsA(class) then
			return true
		end
	end
	return false
end

local function hiding(other)
	return other ~= player and other:GetAttribute("HideSeekRole") == "Hider"
end

task.spawn(function()
	while true do
		task.wait(HIDE_EVERY)
		local still = {}
		for _, other in ipairs(Players:GetPlayers()) do
			if hiding(other) and other.Character then
				for _, item in ipairs(other.Character:GetDescendants()) do
					if hideable(item) then
						still[item] = true
						if item.Enabled then
							item.Enabled = false
							turnedOff[item] = true
						end
					end
				end
			end
		end
		local camera = Workspace.CurrentCamera
		for _, other in ipairs(Players:GetPlayers()) do -- the seeker's mark: only up close (see SEEKER_MARK_NEAR)
			local mark = other.Character and other.Character:FindFirstChild("HideSeekMark")
			local root = other.Character and other.Character:FindFirstChild("HumanoidRootPart")
			if mark and mark:IsA("Highlight") and root and camera then
				local near = other == player or (root.Position - camera.CFrame.Position).Magnitude <= SEEKER_MARK_NEAR
				if mark.Enabled ~= near then
					mark.Enabled = near
				end
			end
		end
		for item in pairs(turnedOff) do
			if not still[item] then
				turnedOff[item] = nil
				if item.Parent then
					item.Enabled = true
				end
			end
		end
	end
end)

-- ---------------------------------------------------------------------------
-- 🏆 승리! / 😢 패배!
-- ---------------------------------------------------------------------------

local banner = Instance.new("Frame")
banner.Name = "HideSeekResult"
banner.AnchorPoint = Vector2.new(0.5, 0.5)
banner.Position = UDim2.fromScale(0.5, RESULT_TOP)
banner.Size = RESULT_SIZE
banner.BackgroundTransparency = 1
banner.Visible = false
banner.Parent = gui
local bannerScale = Instance.new("UIScale")
bannerScale.Parent = banner
local bannerTitle = label(banner, "", UDim2.new(1, 0, 0, 70), UDim2.new(), 56)
bannerTitle.Font = Enum.Font.FredokaOne
bannerTitle.TextStrokeTransparency = 0
bannerTitle.TextStrokeColor3 = Color3.fromRGB(40, 30, 20)
local bannerWhy = label(banner, "", UDim2.new(1, 0, 0, 30), UDim2.fromOffset(0, 72), 20)
bannerWhy.TextStrokeTransparency = 0.3
bannerWhy.TextScaled = true
local bannerMode = label(banner, "", UDim2.new(1, 0, 0, 22), UDim2.fromOffset(0, 104), 15)
bannerMode.TextStrokeTransparency = 0.3
bannerMode.TextScaled = true
for _, l in ipairs({ bannerWhy, bannerMode }) do
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = l.TextSize
	most.Parent = l
end
local shownAt = 0

local function popBig(title, color, why, mode, sound)
	bannerTitle.Text = title
	bannerTitle.TextColor3 = color
	bannerWhy.Text = why or ""
	bannerMode.Text = mode or ""
	bannerTitle.TextTransparency, bannerWhy.TextTransparency, bannerMode.TextTransparency = 0, 0, 0
	bannerTitle.TextStrokeTransparency, bannerWhy.TextStrokeTransparency, bannerMode.TextStrokeTransparency = 0, 0.3, 0.3
	bannerScale.Scale = 0.3
	banner.Visible = true
	TweenService:Create(bannerScale, TweenInfo.new(RESULT_POP, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
		{ Scale = 1 }):Play()
	if sound then
		Sfx.play(sound)
	end
	local mark = os.clock()
	shownAt = mark
	task.delay(RESULT_SECONDS, function()
		if shownAt ~= mark then
			return -- (a newer one)
		end
		local fade = TweenInfo.new(0.6)
		TweenService:Create(bannerTitle, fade, { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
		TweenService:Create(bannerWhy, fade, { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
		TweenService:Create(bannerMode, fade, { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
		task.delay(0.6, function()
			if shownAt == mark then
				banner.Visible = false
			end
		end)
	end)
end

Net.onPush("HideSeekResult", function(outcome, why, ranked, counted, weekWins)
	local won = outcome == "Win"
	popBig(won and "🏆 승리!" or "😢 패배!", won and COLOR_WIN or COLOR_LOSE, type(why) == "string" and why or "",
		not ranked and "🎈 일반전 · 기록은 남지 않아요"
		or (won and not counted) and string.format("🏆 같은 상대는 한 주에 %d승까지만 순위에 들어가요", Config.Ranked.SameRivalWins)
		or string.format("🏆 랭킹전 · 이번 주 %d승", tonumber(weekWins) or 0), won and "Victory" or "Defeat")
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if won and root then
		Fx.confetti(root.Position + Vector3.new(0, 4, 0))
	end
end)

local function seekerName()
	local room = player:GetAttribute("HideSeekRoom")
	for _, p in ipairs(Players:GetPlayers()) do
		if p:GetAttribute("HideSeekRoom") == room and p:GetAttribute("HideSeekRole") == "Seeker" then
			return p.DisplayName
		end
	end
	return nil
end

local alertedPhase = player:GetAttribute("HideSeekPhase")
player:GetAttributeChangedSignal("HideSeekPhase"):Connect(function()
	local phase = player:GetAttribute("HideSeekPhase")
	if phase == alertedPhase then
		return
	end
	alertedPhase = phase
	if phase == "Hiding" then
		task.defer(function()
			if player:GetAttribute("HideSeekRole") == "Seeker" then
				popBig("😈 술래예요!", COLOR_SEEKER, string.format("🔍 %d초 뒤에 찾으러 가요", C.HideSeconds),
					"👋 숨은 사람을 찰싹 잡아요!", "CountGo")
			else
				local name = seekerName()
				popBig("🙈 숨어요!", COLOR_HIDER, string.format("⏱️ %d초 안에 숨어요!", C.HideSeconds),
					name and string.format("이번 술래는 %s님이에요!", name) or "", "CountGo")
			end
		end)
	elseif phase == "Seeking" then
		if player:GetAttribute("HideSeekRole") == "Seeker" then
			popBig("🔍 찾아라!", COLOR_SEEKER, "👋 숨은 사람을 찰싹 잡아요!")
		else
			popBig("🤫 술래 출발!", COLOR_HIDER, "👀 들키지 마요!")
		end
	end
end)

-- ---------------------------------------------------------------------------
-- (2026-10-04, "술래잡기때 술래가 게임 시작 전에는 시야가 열쇠제단만으로 제한되게 해줘. 시작하면 다 보이게") 😈 the seeker,
-- while the others hide: a dark ring wall round the key altar on this screen only (nobody else sees it), and the
-- camera kept close (it stays inside the ring); both gone the moment seeking starts. (Fog does nothing under the
-- map's Atmosphere, so a wall.)
-- ---------------------------------------------------------------------------

local SEEKER_ZOOM = 18 -- studs: the farthest the camera goes out meanwhile
local VEIL_MARGIN = 8 -- studs past the farthest the camera can be
local VEIL_HEIGHT = 160 -- studs up from below the ground: no looking over it from inside
local VEIL_DEPTH = 20
local VEIL_SIDES = 32
local VEIL_COLOR = Color3.fromRGB(28, 32, 48)

local veil, keptZoom = nil, nil

local function altarCenter()
	local map = Workspace:FindFirstChild("Map")
	local zone = map and map:FindFirstChild("KeyZone")
	local altar = zone and zone:FindFirstChild("Zone_KeyAltar", true)
	return altar and (altar:IsA("Model") and altar:GetPivot().Position or altar.Position) or Vector3.zero
end

local function buildVeil()
	local center = altarCenter()
	local radius = C.SeekerSpawnRadius + SEEKER_ZOOM + VEIL_MARGIN
	local width = 2 * math.pi * radius / VEIL_SIDES * 1.08 -- (a little overlap: no gaps at the joins)
	local model = Instance.new("Model")
	model.Name = "HideSeekVeil"
	for i = 1, VEIL_SIDES do
		local angle = (i - 0.5) / VEIL_SIDES * 2 * math.pi
		local at = center + Vector3.new(math.cos(angle) * radius, VEIL_HEIGHT / 2 - VEIL_DEPTH, math.sin(angle) * radius)
		local side = Instance.new("Part")
		side.Anchored, side.CanCollide, side.CanQuery, side.CanTouch, side.CastShadow = true, false, false, false, false
		side.Material = Enum.Material.SmoothPlastic
		side.Color = VEIL_COLOR
		side.Size = Vector3.new(width, VEIL_HEIGHT, 1)
		side.CFrame = CFrame.lookAt(at, Vector3.new(center.X, at.Y, center.Z))
		side.Parent = model
	end
	model.Parent = Workspace
	return model
end

local function updateVeil()
	local want = inGame() and player:GetAttribute("HideSeekRole") == "Seeker"
		and player:GetAttribute("HideSeekPhase") == "Hiding"
	if want and not veil then
		veil = buildVeil()
		keptZoom = player.CameraMaxZoomDistance
		player.CameraMaxZoomDistance = math.min(keptZoom, SEEKER_ZOOM)
	elseif not want and veil then
		veil:Destroy()
		veil = nil
		if keptZoom then
			player.CameraMaxZoomDistance = keptZoom
			keptZoom = nil
		end
	end
end
for _, name in ipairs({ "HideSeekRoom", "HideSeekRole", "HideSeekPhase" }) do
	player:GetAttributeChangedSignal(name):Connect(updateVeil)
end
updateVeil()
player:GetAttributeChangedSignal("HideSeekPhase"):Connect(function()
	if player:GetAttribute("HideSeekPhase") ~= nil then
		Windows.closeAll()
	end
end)

-- ---------------------------------------------------------------------------
-- (2026-10-04, "숨바꼭질 맵이 넓어졌으니 술래에게도 이점이 좀 있어야겠는데") 📡 the seeker's radar (Net push HideSeekRadar,
-- every Config.HideSeek.RadarEvery seconds while seeking): the seeker sees for RadarSeconds a big arrow under the bar
-- toward the nearest hider (turning with the camera; the way as it was at the ping) and how far; the hiders a line
-- that it went, the nearest one that it found them
-- ---------------------------------------------------------------------------

local RADAR_TOP = BAR_TOP + 44 -- under the bar
local RADAR_SIZE = UDim2.fromOffset(320, 112)
local RADAR_ARROW = 56
local RADAR_WORDS_HEIGHT = 48
local RADAR_COLORS = { Near = Color3.fromRGB(255, 90, 80), Mid = Color3.fromRGB(255, 190, 70), Far = Color3.fromRGB(140, 200, 255) }
local RADAR_WORDS = { Near = "📡 가까워요!", Mid = "📡 조금 멀어요", Far = "📡 멀어요" }
local RADAR_CAUGHT_COLOR = Color3.fromRGB(255, 110, 100)
local RADAR_WARN_COLOR = Color3.fromRGB(255, 225, 120)
local RADAR_SAFE_COLOR = Color3.fromRGB(140, 235, 150)
local RADAR_NONE_COLOR = Color3.fromRGB(200, 200, 210)
local RADAR_HIDER_WORDS = {
	Caught = "📡 움직여서 들켰어요!\n술래가 내 쪽을 알아요",
	Moved = "📡 움직였지만\n이번엔 안 들켰어요",
	Still = "📡 잘 멈췄어요!\n안 들켰어요",
}
local NEAR_MISS_SECONDS = 2.5
local NEAR_MISS_COLOR = Color3.fromRGB(150, 255, 170)
local NEAR_MISS_PITCH = 1.3
local RADAR_SLACK = 1
local RADAR_TEXT_MAX = 18

local radarFrame = Instance.new("Frame")
radarFrame.AnchorPoint = Vector2.new(0.5, 0)
radarFrame.Position = UDim2.new(0.5, 0, 0, RADAR_TOP)
radarFrame.Size = RADAR_SIZE
radarFrame.BackgroundTransparency = 1
radarFrame.Visible = false
radarFrame.Parent = gui
local radarArrow = label(radarFrame, "⬆", UDim2.fromOffset(RADAR_ARROW, RADAR_ARROW),
	UDim2.new(0.5, -RADAR_ARROW / 2, 0, 0), RADAR_ARROW)
radarArrow.TextStrokeTransparency = 0.2
radarArrow:SetAttribute("KeepText", true)
local radarWords = label(radarFrame, "", UDim2.new(1, 0, 0, RADAR_WORDS_HEIGHT), UDim2.fromOffset(0, RADAR_ARROW + 4), 18)
radarWords.TextStrokeTransparency = 0.2
radarWords.TextScaled = true
local radarWordsMax = Instance.new("UITextSizeConstraint")
radarWordsMax.MaxTextSize = RADAR_TEXT_MAX
radarWordsMax.Parent = radarWords
local nearMiss = label(gui, "", UDim2.fromOffset(RADAR_SIZE.X.Offset, RADAR_WORDS_HEIGHT),
	UDim2.new(0.5, -RADAR_SIZE.X.Offset / 2, 0, RADAR_TOP + RADAR_SIZE.Y.Offset), 18)
nearMiss.TextColor3 = NEAR_MISS_COLOR
nearMiss.TextStrokeTransparency = 0.2
nearMiss.TextScaled = true
nearMiss.Visible = false
local nearMissMax = Instance.new("UITextSizeConstraint")
nearMissMax.MaxTextSize = RADAR_TEXT_MAX
nearMissMax.Parent = nearMiss

local radarWay, radarUntil = nil, 0
local warnUntil, warnSeeker, warnShown = nil, false, nil
local nearMissUntil = 0

local function showWords(text, color)
	radarWay = nil
	radarArrow.Visible = false
	radarWords.Position = UDim2.fromOffset(0, 0)
	radarWords.TextColor3 = color
	radarWords.Text = text
	radarFrame.Visible = true
end

Net.onPush("HideSeekRadarWarn", function(seconds, isSeeker)
	warnUntil = os.clock() + (tonumber(seconds) or C.RadarWarnSeconds)
	warnSeeker = isSeeker == true
	warnShown = nil
	radarUntil = warnUntil + C.RadarSampleSeconds + RADAR_SLACK
end)

Net.onPush("HideSeekRadar", function(kind, a, b, band)
	warnUntil = nil
	radarUntil = os.clock() + C.RadarSeconds
	radarFrame.Visible = true
	if kind == "Seeker" and a ~= nil then
		radarWay = Vector3.new(tonumber(a) or 0, 0, tonumber(b) or -1)
		radarArrow.Visible = true
		radarWords.Position = UDim2.fromOffset(0, RADAR_ARROW + 4)
		radarArrow.TextColor3 = RADAR_COLORS[band] or RADAR_COLORS.Far
		radarWords.TextColor3 = radarArrow.TextColor3
		radarWords.Text = RADAR_WORDS[band] or RADAR_WORDS.Far
		Sfx.play("CountGo")
	elseif kind == "Seeker" then
		showWords("📡 아무도 안 움직였어요", RADAR_NONE_COLOR)
	else
		showWords(RADAR_HIDER_WORDS[a] or RADAR_HIDER_WORDS.Still,
			a == "Caught" and RADAR_CAUGHT_COLOR or a == "Moved" and RADAR_WARN_COLOR or RADAR_SAFE_COLOR)
		if a == "Caught" then
			Sfx.play("CountTick")
		end
	end
end)

Net.onPush("HideSeekNearMiss", function()
	nearMissUntil = os.clock() + NEAR_MISS_SECONDS
	nearMiss.Text = "😮 아슬아슬!\n술래가 바로 옆을 지나갔어요"
	nearMiss.Visible = true
	Sfx.play("MinePop", nil, NEAR_MISS_PITCH)
end)

RunService.Heartbeat:Connect(FrameMeter.wrap("HideSeekRadar", function()
	local now = os.clock()
	if nearMiss.Visible and (now >= nearMissUntil or not inGame()) then
		nearMiss.Visible = false
	end
	if warnUntil and inGame() then
		local left = math.ceil(warnUntil - now)
		if left > 0 and left ~= warnShown then
			warnShown = left
			if warnSeeker then
				showWords("📡 탐지기 켜는 중...", RADAR_WARN_COLOR)
			else
				showWords(string.format("📡 %d초 뒤 탐지기!\n멈추면 안 들켜요", left), RADAR_WARN_COLOR)
				Sfx.play("CountTick")
			end
		elseif left <= 0 and warnShown ~= 0 then
			warnShown = 0
			if warnSeeker then
				showWords("📡 탐지 중...", RADAR_WARN_COLOR)
			else
				showWords("📡 탐지 중! 움직이지 마요", RADAR_CAUGHT_COLOR)
			end
		end
	end
	if not radarFrame.Visible then
		return
	end
	if now >= radarUntil or not inGame() then
		radarFrame.Visible = false
		warnUntil = nil
		return
	end
	local camera = Workspace.CurrentCamera
	if radarWay and camera then -- (screen up = where the camera looks; turned toward the way, clockwise to the right)
		local look = camera.CFrame.LookVector
		local flat = Vector3.new(look.X, 0, look.Z)
		if flat.Magnitude > 1e-3 then
			flat = flat.Unit
			local right = -radarWay.X * flat.Z + radarWay.Z * flat.X
			local forward = radarWay:Dot(flat)
			radarArrow.Rotation = math.deg(math.atan2(right, forward))
		end
	end
end))
