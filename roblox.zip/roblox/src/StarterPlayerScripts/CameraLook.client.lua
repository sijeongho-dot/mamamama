--[[
CameraLook: what turns see-through between the camera and me (2026-10-04, "이거 왜 투명화 돼서 안 보이는거", "바위가 아니라
광산차야", "바로 앞이였고": the dig camp's mine cart right in front of the character faded out though it hid nothing).

Main.server sets Invisicam (2026-10-02: the camera keeps its distance, what is in the way turns see-through). Roblox's
Invisicam starts in its SMART_CIRCLE mode: it fades everything in a ring of rays around the character too, so what
stands right in front of or beside me (the dig camp's mine cart) went half invisible. Here it is put in LIMBS mode: only what really stands between the camera
and my body fades. (The PlayerModule keeps one Invisicam: set again after each new character, and now and then, in
case it was made anew.)
(2026-10-05, "아니 이 새 지형지물들은 왜 다 투명이 된거야. 다 복구 안 할래??" + a screenshot: the nest at the character's
feet see-through) even LIMBS fades what is between the camera and the feet: from above, the low props round the
character. Now, every frame right after the camera, whatever Invisicam fades that is a field or base decoration (not a
tree), or whose top is under my head, is put back as it was: only what really hides me (trees, buildings, big walls)
turns see-through.
]]

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local player = Players.LocalPlayer

-- display only
local LIMBS = 2 -- the PlayerModule's Invisicam MODE.LIMBS
local CHECK_EVERY = 5 -- seconds between looks that it is still so

local HEAD_MARGIN = 1 -- studs: a part whose top is under my head + this never fades
local PROP_FOLDERS = { Decor = true, FieldDecor = true, BaseProps = true } -- the map's decorations (MapBuilder)

local cameras = nil
local function apply()
	pcall(function()
		if not cameras then
			local module = player:WaitForChild("PlayerScripts"):WaitForChild("PlayerModule", 10)
			cameras = module and require(module):GetCameras()
		end
		local occlusion = cameras and cameras.activeOcclusionModule
		if occlusion and occlusion.SetMode and occlusion.mode ~= LIMBS
			and occlusion.GetOcclusionMode and occlusion:GetOcclusionMode() == Enum.DevCameraOcclusionMode.Invisicam then
			occlusion:SetMode(LIMBS)
		end
	end)
end

-- a decoration of the map (under Decor, FieldDecor or a base's BaseProps), not a tree in it (cached)
local isProp = setmetatable({}, { __mode = "k" })
local function propPart(part)
	local known = isProp[part]
	if known == nil then
		known = false
		local node = part.Parent
		while node and node ~= Workspace do
			if string.find(node.Name, "Tree") then -- (trees still fade: they do hide me)
				break
			end
			if PROP_FOLDERS[node.Name] then
				known = true
				break
			end
			node = node.Parent
		end
		isProp[part] = known
	end
	return known
end

RunService:BindToRenderStep("KeepPropsSolid", Enum.RenderPriority.Camera.Value + 1, function()
	local occlusion = cameras and cameras.activeOcclusionModule
	local faded = occlusion and occlusion.savedHits -- [part] = its own LocalTransparencyModifier (Invisicam's)
	if type(faded) ~= "table" or next(faded) == nil then
		return
	end
	local head = player.Character and player.Character:FindFirstChild("Head")
	local headY = head and head.Position.Y + HEAD_MARGIN or -math.huge
	for part, own in pairs(faded) do
		if typeof(part) == "Instance" and part:IsA("BasePart")
			and (part.Position.Y + part.Size.Y / 2 < headY or propPart(part)) then
			-- (as it was before the fade; never left half see-through, whatever Invisicam keeps there)
			part.LocalTransparencyModifier = (type(own) == "number" and own < 0.5) and own or 0
		end
	end
end)

player.CharacterAdded:Connect(function()
	task.wait(1) -- (after the camera module has picked up the new character)
	apply()
end)
task.spawn(function()
	while true do
		apply()
		task.wait(CHECK_EVERY)
	end
end)

local GROUND_CLEARANCE = 1.5
local GROUND_PROBE = 300
local groundParams = RaycastParams.new()
groundParams.FilterType = Enum.RaycastFilterType.Include
local groundFolder = nil
RunService:BindToRenderStep("CameraAboveGround", Enum.RenderPriority.Camera.Value + 2, function()
	local camera = Workspace.CurrentCamera
	if not camera or camera.CameraType ~= Enum.CameraType.Custom then
		return
	end
	if not groundFolder or not groundFolder.Parent then
		local map = Workspace:FindFirstChild("Map")
		groundFolder = map and map:FindFirstChild("Ground")
		if not groundFolder then
			return
		end
		groundParams.FilterDescendantsInstances = { groundFolder, Workspace.Terrain }
	end
	local at = camera.CFrame.Position
	local hit = Workspace:Raycast(at + Vector3.new(0, GROUND_PROBE, 0), Vector3.new(0, -GROUND_PROBE * 2, 0), groundParams)
	if hit and at.Y < hit.Position.Y + GROUND_CLEARANCE then
		local lifted = Vector3.new(at.X, hit.Position.Y + GROUND_CLEARANCE, at.Z)
		camera.CFrame = CFrame.lookAt(lifted, camera.Focus.Position)
	end
end)
