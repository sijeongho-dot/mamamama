--[[
TreasureFx: the treasure chests' motion on this screen (the server's Treasure service decides).

- While someone holds the chest's prompt (chest attribute Opening), it shakes harder and harder and
  sparkles, rattling (the sound "ChestRattle" every second, a little higher each time).
- When it is opened (attribute Opened, the opener's UserId; Money), the lid swings open about its
  back edge (attribute Hinge), gold coins burst out and "+n원" floats up; the server then removes it.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Fx = require(Shared:WaitForChild("Fx"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))


-- display only
local SHAKE_ANGLE = { 0.03, 0.12 } -- radians, from the start of the hold to its end
local SHAKE_SPEED = 38
local SPARKLE_RATE = 25
local LID_OPEN_ANGLE = math.rad(110)
local LID_OPEN_SECONDS = 0.35
local CREAK_EVERY = 1 -- seconds between the rattles while it shakes (the sound "ChestRattle" is 1 s)
local RATTLE_RISE = 0.3 -- the rattle this much higher at the end of the hold
local COIN_COLORS = { Color3.fromRGB(255, 215, 60), Color3.fromRGB(255, 240, 150), Color3.fromRGB(230, 170, 40) }
local POP_SECONDS = 1.6
local POP_RISE = 6
local POP_COLOR = Color3.fromRGB(255, 225, 90)

local chests = {} -- [model] = { rest, holdStart, sparkles, lidStart, lidRest, lastCreak, body }
local waiting = setmetatable({}, { __mode = "k" }) -- [model] = true while its parts are still on the way
local mine = setmetatable({}, { __mode = "k" })

local function hideMine(model)
	local m = mine[model]
	if m then
		m.hidden = true
	end
	chests[model] = nil
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.LocalTransparencyModifier = 1
		elseif d:IsA("ProximityPrompt") or d:IsA("ParticleEmitter") or d:IsA("Light") then
			d.Enabled = false
		end
	end
end

local track
-- (2026-10-01, "a chest gave its reward but never shook, opened or rattled") a chest may arrive before its
-- parts (streaming): it is tracked once its body and lid are there, and again if they stream out and back
local function waitForParts(model)
	if waiting[model] then
		return
	end
	waiting[model] = true
	local connection
	connection = model.ChildAdded:Connect(function()
		if model:FindFirstChild("Body") and model:FindFirstChild("Lid") then
			connection:Disconnect()
			waiting[model] = nil
			task.defer(track, model)
		end
	end)
end

function track(model)
	if chests[model] or not model:IsA("Model") or not model.Parent then
		return
	end
	if mine[model] and mine[model].hidden then
		hideMine(model)
		return
	end
	local body = model:FindFirstChild("Body")
	local lid = model:FindFirstChild("Lid")
	if not body or not lid then
		waitForParts(model)
		return
	end
	local sparkles = Instance.new("ParticleEmitter")
	sparkles.Rate = 0
	sparkles.Lifetime = NumberRange.new(0.5, 0.9)
	sparkles.Speed = NumberRange.new(3, 7)
	sparkles.SpreadAngle = Vector2.new(180, 180)
	sparkles.Size = NumberSequence.new(0.4, 0)
	sparkles.LightEmission = 1
	sparkles.Color = ColorSequence.new(COIN_COLORS[1], Color3.new(1, 1, 1))
	sparkles.Parent = body
	-- the lid and its gold bands, each as an offset from the lid, to swing together
	local lidParts = { { lid, CFrame.identity } }
	for _, d in ipairs(lid:GetDescendants()) do
		if d:IsA("BasePart") then
			table.insert(lidParts, { d, lid.CFrame:ToObjectSpace(d.CFrame) })
		end
	end
	-- (2026-10-02, "상자를 치면 상자가 바닥에 빠지는 버그") the chest's pivot on this screen may be its body's middle
	-- (not the bottom the server set): it is put back exactly where it stood (pivot), and shaken about the
	-- bottom middle (Rest) without caring which its pivot is
	local rest = model:GetAttribute("Rest") or model:GetPivot()
	local spot = model:FindFirstChild("PromptSpot") -- (2026-10-03) the open prompt's spot: never shaken
	chests[model] = { rest = rest, pivot = model:GetPivot(), sparkles = sparkles, lastCreak = 0,
		lidRest = lid.CFrame, lidParts = lidParts, body = body, spot = spot, spotRest = spot and spot.CFrame }
end

local function pop(position, text)
	local anchor = Instance.new("Part")
	anchor.Anchored, anchor.CanCollide, anchor.CanQuery, anchor.CanTouch = true, false, false, false
	anchor.Transparency = 1
	anchor.Size = Vector3.one * 0.2
	anchor.CFrame = CFrame.new(position)
	anchor.Parent = Workspace
	local gui = Instance.new("BillboardGui")
	gui.Size = UDim2.fromOffset(200, 50)
	gui.AlwaysOnTop = true
	gui.Parent = anchor
	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.Font = Enum.Font.GothamBlack
	label.TextScaled = true
	label.TextColor3 = POP_COLOR
	label.TextStrokeTransparency = 0.2
	label.Text = text
	label.Parent = gui
	local start = os.clock()
	local conn
	conn = RunService.RenderStepped:Connect(FrameMeter.wrap("TreasureFx", function()
		local t = (os.clock() - start) / POP_SECONDS
		if t >= 1 then
			conn:Disconnect()
			anchor:Destroy()
			return
		end
		anchor.CFrame = CFrame.new(position + Vector3.new(0, POP_RISE * t, 0))
		label.TextTransparency = math.max(0, t * 2 - 1)
	end))
end

RunService.RenderStepped:Connect(FrameMeter.wrap("TreasureFx", function()
	local now = os.clock()
	for model, c in pairs(chests) do
		if not model.Parent then
			chests[model] = nil
		elseif not c.body.Parent then -- its parts streamed out: tracked again when they come back
			chests[model] = nil
			waitForParts(model)
		elseif model:GetAttribute("Opened") or mine[model] then
			if not c.lidStart then -- just opened: the lid swings up, coins fly
				local m = mine[model]
				c.lidStart = now
				c.sparkles.Rate = 0
				model:PivotTo(c.pivot)
				local at = c.rest.Position + Vector3.new(0, 3, 0)
				Fx.burst(at, COIN_COLORS, 40, 22, 0.7, 0.9)
				Sfx.play("Deposit", at)
				Sfx.play("GachaBig", at)
				pop(at + Vector3.new(0, 2, 0), (m and m.label) or model:GetAttribute("Label") -- a key or mineral chest's own
					or "+" .. Formulas.shortNumber((m and m.money) or model:GetAttribute("Money") or 0) .. "원")
			end
			local hinge = model:GetAttribute("Hinge")
			if hinge then
				local t = math.min(1, (now - c.lidStart) / LID_OPEN_SECONDS)
				local eased = 1 - (1 - t) * (1 - t)
				-- turn about the back edge: the front swings up and back
				local lidCf = hinge * CFrame.Angles(-LID_OPEN_ANGLE * eased, 0, 0) * hinge:ToObjectSpace(c.lidRest)
				for _, entry in ipairs(c.lidParts) do
					if entry[1].Parent then
						entry[1].CFrame = lidCf * entry[2]
					end
				end
			end
		elseif model:GetAttribute("Opening") then
			c.holdStart = c.holdStart or now
			local k = math.min(1, (now - c.holdStart) / Config.Treasure.OpenSeconds)
			local angle = SHAKE_ANGLE[1] + (SHAKE_ANGLE[2] - SHAKE_ANGLE[1]) * k
			local shake = CFrame.Angles(0, 0, angle * math.sin(now * SHAKE_SPEED))
				* CFrame.Angles(angle * 0.5 * math.sin(now * SHAKE_SPEED * 1.3), 0, 0)
			model:PivotTo(c.rest * shake * c.rest:ToObjectSpace(c.pivot)) -- (rocking on its bottom)
			if c.spot and c.spot.Parent then -- (the prompt's spot stays still: a moving prompt drops the hold)
				c.spot.CFrame = c.spotRest
			end
			c.sparkles.Rate = SPARKLE_RATE * (0.4 + k)
			if now - c.lastCreak > CREAK_EVERY then -- (2026-10-01) the wood rattling and coins jingling, higher as it goes
				c.lastCreak = now
				Sfx.play("ChestRattle", c.rest.Position, 1 + RATTLE_RISE * k)
			end
		elseif c.holdStart then -- the hold broke (slapped away, let go): still again
			c.holdStart = nil
			c.sparkles.Rate = 0
			model:PivotTo(c.pivot)
		end
	end
end))

Net.onPush("ChestMine", function(model, money, label)
	if typeof(model) ~= "Instance" or not model:IsA("Model") or mine[model] then
		return
	end
	mine[model] = { money = tonumber(money) or 0, label = type(label) == "string" and label or nil }
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("ProximityPrompt") then
			d.Enabled = false
		end
	end
	local beam = model:FindFirstChild("Beam")
	if beam then
		beam.LocalTransparencyModifier = 1
		for _, d in ipairs(beam:GetDescendants()) do
			if d:IsA("ParticleEmitter") then
				d.Enabled = false
			end
		end
	end
	task.delay(Config.Treasure.VanishSeconds, function()
		if model.Parent then
			hideMine(model)
		end
	end)
end)

task.spawn(function()
	local folder = Workspace:WaitForChild("TreasureChests")
	folder.ChildAdded:Connect(function(model)
		task.defer(track, model) -- its parts may still be arriving
	end)
	for _, model in ipairs(folder:GetChildren()) do
		track(model)
	end
end)
