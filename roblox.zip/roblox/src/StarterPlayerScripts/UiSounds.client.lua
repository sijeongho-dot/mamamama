--[[
UiSounds: a small click on every button press (display only).

Every TextButton and ImageButton in the player's screens, now and later, plays Sfx UiClick when it is
activated (mouse, touch or gamepad). A button with the attribute NoClickSound = true stays quiet
(one with its own sound, or pressed all the time: the slap button), and so do Roblox's own touch controls
(TouchGui: the jump button) (2026-10-01, "no button sound on the jump and slap buttons"). At most one click every MIN_GAP seconds, so a press that opens a window full
of buttons never clatters.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Sfx = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Sfx"))

-- display only
local MIN_GAP = 0.05
local PITCH = { 0.95, 1.08 } -- a little different each time

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local hooked = setmetatable({}, { __mode = "k" })
local last = 0

local function hook(button)
	if hooked[button] or not button:IsA("GuiButton") or button:FindFirstAncestor("TouchGui") then
		return
	end
	hooked[button] = true
	button.Activated:Connect(function()
		if button:GetAttribute("NoClickSound") or os.clock() - last < MIN_GAP then
			return
		end
		last = os.clock()
		Sfx.play("UiClick", nil, PITCH[1] + math.random() * (PITCH[2] - PITCH[1]))
	end)
end

for _, d in ipairs(playerGui:GetDescendants()) do
	hook(d)
end
playerGui.DescendantAdded:Connect(hook)
