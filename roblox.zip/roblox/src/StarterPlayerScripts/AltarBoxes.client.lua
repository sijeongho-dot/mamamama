local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local Lang = require(Shared:WaitForChild("Lang"))
local RarityFx = require(Shared:WaitForChild("RarityFx"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Unlock = require(Shared:WaitForChild("Unlock"))
local BoxFall = require(Shared:WaitForChild("BoxFall"))

local LOCK_SIZE = UDim2.fromOffset(130, 22)
local LOCK_ABOVE_LABEL = 1.9
local LOCK_DISTANCE = 220
local LOCK_COLOR = Color3.fromRGB(255, 110, 110)
local LOCKED_SEE_THROUGH = 0.45
local PILL_HEIGHT = 30
local PILL_PAD = 14
local PILL_GAP = 4
local PILL_TEXT = 15
local PILL_TOP = 4
local PILL_FILL = Color3.fromRGB(30, 22, 40)
local PILL_FILL_SEE = 0.15
local PILL_STROKE = 2.5
local PILL_PULSE_SECONDS = 0.6
local PILL_PULSE_SEE = 0.6
local PILL_EVERY = 0.25
local FALL_FRESH = 3
local FALL_SEEN = 450
local FALL_DELAY = 0.55
local FALL_SKY = 110
local FALL_SPREAD = 40
local PICK_OUTLINE = Color3.new(1, 1, 1)
local PICK_FILL = Color3.new(1, 1, 1)
local PICK_FILL_HOLD = 0.7

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local function myLevel()
	return player:GetAttribute("DefenseLevel") or 1
end

local function boxOf(part)
	return { Rarity = part:GetAttribute("Rarity"), Size = part:GetAttribute("Size"), Grade = part:GetAttribute("Grade"),
		King = part:GetAttribute("King") }
end

local function seeThrough(part, amount)
	for _, d in ipairs(part:GetDescendants()) do
		if d:IsA("BasePart") and d.Name ~= "Beam" then
			d.LocalTransparencyModifier = amount
		end
	end
end

local function tutorialAway(part)
	return player:GetAttribute("InTutorial") == true and part:GetAttribute("OnlyFor") ~= player.UserId
end

local function showParts(part, shown)
	for _, d in ipairs(part:GetDescendants()) do
		if d:IsA("BasePart") then
			d.LocalTransparencyModifier = shown and 0 or 1
		elseif d:IsA("BillboardGui") or d:IsA("Light") or d:IsA("Sparkles") or d:IsA("ProximityPrompt") then
			d.Enabled = shown
		end
	end
end

local function refreshBox(part)
	if part.Name ~= "AltarBox" then
		return
	end
	if tutorialAway(part) then
		part:SetAttribute("TutorialAway", true)
		showParts(part, false)
		return
	elseif part:GetAttribute("TutorialAway") then
		part:SetAttribute("TutorialAway", nil)
		showParts(part, true)
	end
	local box = boxOf(part)
	local locked = box.Rarity ~= nil and not Formulas.boxPickable(box, myLevel())
	local prompt = part:FindFirstChild("TakeBox")
	if prompt then
		local only = part:GetAttribute("OnlyFor")
		prompt.Enabled = not locked and (only == nil or only == player.UserId)
			and (player:GetAttribute("CarriedKeys") or 0) < Config.AltarBoxes.MaxCarry and not part:GetAttribute("Falling")
	end
	local sign = part:FindFirstChild("BoxLock")
	if not locked then
		if sign then
			sign:Destroy()
			seeThrough(part, 0)
		end
		return
	end
	if not sign then
		local label = part:FindFirstChild("BoxLabel")
		sign = Instance.new("BillboardGui")
		sign.Name = "BoxLock"
		sign.Size = LOCK_SIZE
		sign.StudsOffsetWorldSpace = (label and label.StudsOffsetWorldSpace or Vector3.zero) + Vector3.new(0, LOCK_ABOVE_LABEL, 0)
		sign.MaxDistance = LOCK_DISTANCE
		local text = Instance.new("TextLabel")
		text.Size = UDim2.fromScale(1, 1)
		text.BackgroundTransparency = 1
		text.Font = Enum.Font.GothamBold
		text.TextScaled = true
		text.TextColor3 = LOCK_COLOR
		text.TextStrokeTransparency = 0
		text.Parent = sign
		sign.Parent = part
	end
	Lang.set(sign.TextLabel, string.format("🔒 환생 %d번부터", Formulas.boxLockRebirths(box)))
	seeThrough(part, LOCKED_SEE_THROUGH)
end

local function hideBox(part, hidden)
	part:SetAttribute("Falling", hidden or nil)
	for _, d in ipairs(part:GetDescendants()) do
		if d:IsA("BasePart") then
			d.LocalTransparencyModifier = hidden and 1 or 0
		elseif d:IsA("BillboardGui") or d:IsA("Light") or d:IsA("Sparkles") or d:IsA("ProximityPrompt") then
			d.Enabled = not hidden
		end
	end
end

local function skyRide(part)
	if tutorialAway(part) then
		return
	end
	local at = part:GetAttribute("FallAt")
	local camera = Workspace.CurrentCamera
	local box = part:FindFirstChild("GiftBox")
	if not at or Workspace:GetServerTimeNow() - at > FALL_FRESH or not box or not camera
		or (part.Position - camera.CFrame.Position).Magnitude > FALL_SEEN then
		return
	end
	hideBox(part, true)
	task.delay(FALL_DELAY, function()
		if not part.Parent then
			return
		end
		local land = box:GetPivot()
		local from = land.Position
			+ Vector3.new((math.random() * 2 - 1) * FALL_SPREAD, FALL_SKY, (math.random() * 2 - 1) * FALL_SPREAD)
		BoxFall.fall(box, land, from, function()
			if part.Parent then
				hideBox(part, false)
				refreshBox(part)
			end
		end)
	end)
end

local keysFolder = nil
local function refreshAll()
	for _, part in ipairs(keysFolder and keysFolder:GetChildren() or {}) do
		refreshBox(part)
	end
end

task.spawn(function()
	keysFolder = Workspace:WaitForChild("Keys")
	keysFolder.ChildAdded:Connect(function(part)
		task.defer(refreshBox, part)
		task.defer(skyRide, part)
	end)
	refreshAll()
end)
player:GetAttributeChangedSignal("DefenseLevel"):Connect(refreshAll)
player:GetAttributeChangedSignal("CarriedKeys"):Connect(refreshAll)
player:GetAttributeChangedSignal("InTutorial"):Connect(refreshAll)

local picking = {}
local function boxPrompt(prompt)
	local part = prompt.Parent
	return prompt.Name == "TakeBox" and part ~= nil and part.Name == "AltarBox" and part or nil
end
ProximityPromptService.PromptShown:Connect(function(prompt)
	local part = boxPrompt(prompt)
	if not part or picking[prompt] then
		return
	end
	local mark = Instance.new("Highlight")
	mark.Adornee = part:FindFirstChild("GiftBox") or part
	mark.FillColor = PICK_FILL
	mark.FillTransparency = 1
	mark.OutlineColor = PICK_OUTLINE
	mark.OutlineTransparency = 0
	mark.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
	mark.Parent = part
	picking[prompt] = mark
	prompt.Destroying:Once(function()
		picking[prompt] = nil
	end)
end)
ProximityPromptService.PromptHidden:Connect(function(prompt)
	local mark = picking[prompt]
	picking[prompt] = nil
	if mark then
		mark:Destroy()
	end
end)
ProximityPromptService.PromptButtonHoldBegan:Connect(function(prompt)
	local mark = picking[prompt]
	if mark then
		mark.FillTransparency = PICK_FILL_HOLD
	end
end)
ProximityPromptService.PromptButtonHoldEnded:Connect(function(prompt)
	local mark = picking[prompt]
	if mark then
		mark.FillTransparency = 1
	end
end)

local gui = Instance.new("ScreenGui")
gui.Name = "AltarRare"
gui.ResetOnSpawn = false
gui.DisplayOrder = 4
gui.Parent = playerGui
local pill = Instance.new("TextLabel")
pill.Name = "AltarRarePill"
pill.AnchorPoint = Vector2.new(0.5, 0)
pill.Position = UDim2.new(0.5, 0, 0, PILL_TOP)
pill.Size = UDim2.fromOffset(0, PILL_HEIGHT)
pill.AutomaticSize = Enum.AutomaticSize.X
pill.BackgroundColor3 = PILL_FILL
pill.BackgroundTransparency = PILL_FILL_SEE
pill.Font = Enum.Font.GothamBold
pill.TextSize = PILL_TEXT
pill.TextColor3 = Color3.new(1, 1, 1)
pill.Text = ""
pill.Visible = false
pill.Parent = gui
local round = Instance.new("UICorner")
round.CornerRadius = UDim.new(0.5, 0)
round.Parent = pill
local pad = Instance.new("UIPadding")
pad.PaddingLeft = UDim.new(0, PILL_PAD)
pad.PaddingRight = UDim.new(0, PILL_PAD)
pad.Parent = pill
local stroke = Instance.new("UIStroke")
stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
stroke.Thickness = PILL_STROKE
stroke.Parent = pill
TweenService:Create(stroke, TweenInfo.new(PILL_PULSE_SECONDS, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
	{ Transparency = PILL_PULSE_SEE }):Play()

local function parseRare()
	local value = ReplicatedStorage:GetAttribute("AltarRare")
	if type(value) ~= "string" then
		return nil
	end
	local rarityId, sizeId, grade, carrier = string.match(value, "^([^|]*)|([^|]*)|([^|]*)|(%-?%d+)$")
	local r = rarityId and Formulas.rarity(rarityId)
	if not r then
		return nil
	end
	return { Rarity = rarityId, Size = sizeId, Grade = grade, rarity = r, carrier = tonumber(carrier) or 0 }
end

local function rareText(rare)
	local size = Formulas.dinoSize(rare.Size)
	local sizeName = size and size.Name or rare.Size
	if rare.carrier == player.UserId then
		return string.format("🎁 내가 %s 상자를 들었어요! 🏠 기지로!", rare.rarity.Name)
	elseif rare.carrier ~= 0 then
		local who = Players:GetPlayerByUserId(rare.carrier)
		return string.format("🏃 %s님이 %s 상자를 들고 가요! 👋 찰싹!", who and who.DisplayName or "?", rare.rarity.Name)
	elseif not Formulas.boxPickable(rare, myLevel()) then
		return string.format("🔒 %s · %s 상자가 제단에 (환생 %d번부터)", rare.rarity.Name, sizeName, Formulas.boxLockRebirths(rare))
	end
	return string.format("🎁 %s · %s 상자가 제단에! 🏃 먼저 줍기!", rare.rarity.Name, sizeName)
end

local lastValue = nil
local function refreshPill()
	local value = ReplicatedStorage:GetAttribute("AltarRare")
	local rare = Unlock.usable("Altar") and not player:GetAttribute("InTutorial") and parseRare() or nil
	pill.Visible = rare ~= nil
	if not rare then
		lastValue = nil
		return
	end
	Lang.set(pill, rareText(rare))
	stroke.Color = RarityFx.color(rare.Rarity) or Color3.new(1, 1, 1)
	if lastValue == nil and rare.carrier == 0 then
		Sfx.play("SpecialKey")
	end
	lastValue = value
end
ReplicatedStorage:GetAttributeChangedSignal("AltarRare"):Connect(refreshPill)
player:GetAttributeChangedSignal("DefenseLevel"):Connect(refreshPill)
Unlock.watch(refreshPill)
refreshPill()

local function pillTop()
	local lineGui = playerGui:FindFirstChild("WeatherLine")
	local line = lineGui and lineGui:FindFirstChildOfClass("TextLabel")
	if not line then
		return PILL_TOP
	end
	local top = line.Position.Y.Offset
	return line.Visible and top + line.Size.Y.Offset + PILL_GAP or top
end

local since = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("AltarBoxes", function(dt)
	since += dt
	if since < PILL_EVERY or not pill.Visible then
		return
	end
	since = 0
	local top = pillTop()
	if pill.Position.Y.Offset ~= top then
		pill.Position = UDim2.new(0.5, 0, 0, top)
	end
end))
