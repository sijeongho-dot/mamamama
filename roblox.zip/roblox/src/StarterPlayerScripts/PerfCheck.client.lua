--[[
PerfCheck (2026-10-04, "버벅임이 좀 있는거 같은데"): when this screen gets slow, a small banner at the top says how slow
and what took the time, so a screenshot names the cause (LagCheck does it for the server). Display only.

- Frames a second, and hitches: a frame longer than HITCH_SECONDS (the stutter one feels).
- Shown while the frame rate stays under LOW_FPS for LOW_FOR seconds, or HITCHES_SHOW hitches come within
  HITCH_WINDOW seconds; gone after CALM_FOR calm seconds. Not in the first JOIN_GRACE seconds (the map still
  coming in), and a gap longer than PAUSE_GAP (the phone's screen off) is no hitch.
- Its lines: the frame rate and the hitches; the screen scripts that took the most time a frame (Shared/FrameMeter:
  every RunService connection of the screen scripts goes through it), the screen's memory and number of things; the
  longest hitch and the script that took most of it, or, when the scripts took little of it, the rest (drawing,
  physics, what streams in).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Stats = game:GetService("Stats")

local FrameMeter = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("FrameMeter"))

local player = Players.LocalPlayer
-- (2026-10-04) a tool for the developers: only in Studio or for them (Config.Developers), never for the players; and
-- (2026-10-04) only while turned on with TestCommands ;perf
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))
if not RunService:IsStudio() and not Formulas.isDeveloper(player.Name) then
	return
end

-- display only
-- (2026-10-04, "화면이 느려요 알림 뜨는데" + a screenshot: FPS 28, the scripts 4 ms a frame, one 158 ms hitch: a phone
-- that draws at 30 a second showed it all the time) only clearly slow screens: under 20 a second, hitches of 0.25 s
local HITCH_SECONDS = 0.25 -- a frame this long is a hitch (was 0.1)
local PAUSE_GAP = 2 -- seconds: a longer gap is the game stopped (the phone's screen off), not a hitch
local LOW_FPS = 20 -- (was 30: many phones draw at 30 a second at most)
local LOW_FOR = 3 -- seconds under LOW_FPS before the banner shows
local HITCH_WINDOW = 10 -- seconds the hitches are counted over
local HITCHES_SHOW = 3 -- this many hitches in HITCH_WINDOW show the banner
local CALM_FOR = 8 -- calm seconds before it goes again
local JOIN_GRACE = 20 -- seconds after joining it never shows
local TOP_SCRIPTS = 3 -- scripts named on its second line
local MAIN_SHARE = 0.4 -- a hitch's biggest script took at least this share of it: it is named as the cause
local BANNER_SIZE = UDim2.fromOffset(400, 66)
local BANNER_TOP = 44 -- (LagCheck's banner's place; under it when that one is up)
local LAG_BANNER_ROOM = 120
local COLOR_BG = Color3.fromRGB(40, 30, 60)
local COLOR_TEXT = Color3.fromRGB(200, 220, 255)

local gui = Instance.new("ScreenGui")
gui.Name = "PerfCheck"
gui.ResetOnSpawn = false
gui.DisplayOrder = 7
gui.Parent = player:WaitForChild("PlayerGui")
local banner = Instance.new("TextLabel")
banner.AnchorPoint = Vector2.new(0.5, 0)
banner.Size = BANNER_SIZE
banner.Position = UDim2.new(0.5, 0, 0, BANNER_TOP)
banner.BackgroundColor3 = COLOR_BG
banner.BackgroundTransparency = 0.2
banner.TextColor3 = COLOR_TEXT
banner.Font = Enum.Font.GothamBold
banner.TextScaled = true
banner.Visible = false
banner.Parent = gui
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 8)
	round.Parent = banner
end

local joinedAt = os.clock()
local lastFrame = os.clock()
local frames = 0
local hitches = {} -- { at, seconds, scripts (seconds), name, nameSeconds }, the last HITCH_WINDOW seconds

-- (first thing every frame: all the scripts' time since the last frame is this frame's)
RunService:BindToRenderStep("PerfCheck", Enum.RenderPriority.First.Value, function()
	local now = os.clock()
	local dt = now - lastFrame
	lastFrame = now
	frames += 1
	local spent = FrameMeter.frame()
	if dt < HITCH_SECONDS or dt > PAUSE_GAP or now - joinedAt < JOIN_GRACE then
		return
	end
	local scripts, name, most = 0, nil, 0
	for n, s in pairs(spent) do
		scripts += s
		if s > most then
			name, most = n, s
		end
	end
	table.insert(hitches, { at = now, seconds = dt, scripts = scripts, name = name, nameSeconds = most })
end)

-- (2026-10-04, "낮에도 버벅인 밤 이후에": slower the longer one plays?) this screen's memory and its number of things:
-- growing from one screenshot to the next means something piles up
local function memoryText()
	local okMb, mb = pcall(function()
		return Stats:GetTotalMemoryUsageMb()
	end)
	local okCount, count = pcall(function()
		return Stats.InstanceCount
	end)
	return (okMb and mb and string.format(" · 🧠 %dMB", math.floor(mb + 0.5)) or "")
		.. (okCount and count and string.format(" · 🧩 %d", count) or "")
end

local function ms(seconds)
	return math.floor(seconds * 1000 + 0.5)
end

local lowSince, calmSince = nil, nil
task.spawn(function()
	local last = os.clock()
	while true do
		task.wait(1)
		local now = os.clock()
		local elapsed = now - last
		last = now
		local fps = frames / math.max(elapsed, 1e-3)
		local count = math.max(frames, 1)
		local spent = FrameMeter.take()
		while hitches[1] and now - hitches[1].at > HITCH_WINDOW do
			table.remove(hitches, 1)
		end
		-- (no frame at all: the game is not being drawn - stopped, or the layout checker's mock - not slow)
		local drawn = frames > 0
		local slow = drawn and now - joinedAt >= JOIN_GRACE and elapsed < PAUSE_GAP and fps < LOW_FPS
		lowSince = slow and (lowSince or now) or nil
		frames = 0
		-- (2026-10-04, "저 지연은 왜 자꾸 뜨는거야": it showed by itself on a slow phone) only while turned on: Studio ;perf
		-- (player attribute PerfBanner)
		-- (2026-10-04, "3- 4명 있으니까 서버 지연 한 번 걸리는데") and the server's last stall, while it says one (Watchdog:
		-- the third line of ServerStats, "최근 멈춤 …", for two minutes)
		local serverStall = select(3, string.match(ReplicatedStorage:GetAttribute("ServerStats") or "", "^([^\n]*)\n([^\n]*)\n[^\n]*\n?(.*)$"))
		serverStall = serverStall ~= "" and serverStall or nil
		local bad = drawn and player:GetAttribute("PerfBanner") == true
			and ((lowSince and now - lowSince >= LOW_FOR) or #hitches >= HITCHES_SHOW or serverStall ~= nil)
		if bad then
			calmSince = nil
		elseif banner.Visible then
			calmSince = calmSince or now
		end
		if bad then
			-- the scripts that took the most, a frame on average
			local list = {}
			for n, s in pairs(spent) do
				table.insert(list, { n, s / count })
			end
			table.sort(list, function(a, b)
				return a[2] > b[2]
			end)
			local parts = {}
			for i = 1, math.min(TOP_SCRIPTS, #list) do
				table.insert(parts, string.format("%s %.1fms", list[i][1], list[i][2] * 1000))
			end
			local worst = nil
			for _, h in ipairs(hitches) do
				if not worst or h.seconds > worst.seconds then
					worst = h
				end
			end
			local lines = {
				string.format("🐢 화면이 느려요 · FPS %d · 끊김 %d번 (%d초 동안)", math.floor(fps + 0.5), #hitches, HITCH_WINDOW),
				"⏱️ " .. (#parts > 0 and table.concat(parts, " · ") or "-") .. memoryText(),
			}
			if worst and worst.name and worst.nameSeconds >= worst.seconds * MAIN_SHARE then
				table.insert(lines, string.format("💥 가장 긴 끊김 %dms · %s %dms", ms(worst.seconds), worst.name, ms(worst.nameSeconds)))
			elseif worst then
				table.insert(lines, string.format("💥 가장 긴 끊김 %dms · 스크립트 %dms (나머지는 그리기·물리·네트워크)",
					ms(worst.seconds), ms(worst.scripts)))
			end
			if serverStall then
				table.insert(lines, "🖥️ " .. serverStall)
			end
			banner.Text = table.concat(lines, "\n")
			banner.Visible = true
		elseif banner.Visible and ((calmSince and now - calmSince >= CALM_FOR) or player:GetAttribute("PerfBanner") ~= true) then
			banner.Visible = false
		end
		if banner.Visible then -- (under the server's banner when that one is up too)
			local lag = player.PlayerGui:FindFirstChild("LagCheck")
			local lagBanner = lag and lag:FindFirstChildOfClass("TextLabel")
			local below = lagBanner and lagBanner.Visible
			banner.Position = UDim2.new(0.5, 0, 0, BANNER_TOP + (below and LAG_BANNER_ROOM or 0))
		end
	end
end)
