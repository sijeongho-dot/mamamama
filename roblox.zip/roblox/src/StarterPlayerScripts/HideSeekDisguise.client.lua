local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local DinoMotion = require(Shared:WaitForChild("DinoMotion"))
local Fx = require(Shared:WaitForChild("Fx"))
local Lang = require(Shared:WaitForChild("Lang"))
local Net = require(Shared:WaitForChild("Net"))
local ScreenButtons = require(Shared:WaitForChild("ScreenButtons"))
local Sfx = require(Shared:WaitForChild("Sfx"))

local player = Players.LocalPlayer
local C = Config.HideSeek

local FONT = Enum.Font.GothamBold
local BUTTON_SIZE = UDim2.fromOffset(84, 84)
local BUTTON_POS = UDim2.new(1, -112, 1, -112)
local BUTTON_GAP = 10
local CLEAR_GAP = 4
local LIFT_STEP = 46
local LIFT_TRIES = 4
local COLOR_ON = Color3.fromRGB(70, 160, 110)
local COLOR_DIM = Color3.fromRGB(90, 95, 110)
local DISGUISE_KEY = Enum.KeyCode.Z
local PRESS_GAP = 0.5
local POOF_COLORS = { Color3.fromRGB(255, 255, 255), Color3.fromRGB(190, 255, 200) }
local THING_PREFIX = "Thing_"
local OWN_THING_SEE_THROUGH = 0.45
local STILL_MOVE = 0.01
local STILL_TURN = 0.999

local gui = Instance.new("ScreenGui")
gui.Name = "HideSeekDisguise"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local button = Instance.new("TextButton")
button.Name = "HideSeekDisguise"
button.AnchorPoint = Vector2.new(1, 1)
button.Size = BUTTON_SIZE
button.Position = BUTTON_POS
button.Font = FONT
button.TextSize = 15
button.TextColor3 = Color3.new(1, 1, 1)
button.BackgroundColor3 = COLOR_ON
button.Visible = false
button.Parent = gui
local round = Instance.new("UICorner")
round.CornerRadius = UDim.new(0.5, 0)
round.Parent = button

local function clearOf(a, b, boxes)
	for _, box in ipairs(boxes) do
		local g = box[3]
		if a.X < box[2].X + g and b.X > box[1].X - g and a.Y < box[2].Y + g and b.Y > box[1].Y - g then
			return false
		end
	end
	return a.X >= 0 and a.Y >= 0
end

local function shownButton(name)
	local found = player.PlayerGui:FindFirstChild(name, true)
	return found and found:IsA("GuiObject") and found.Visible and found.AbsoluteSize.X > 0 and found or nil
end

local function place()
	local ref = shownButton("HideSeekTrap") or shownButton("SlapButton")
	if not ref then
		button.Position = BUTTON_POS
		return
	end
	local w, h = BUTTON_SIZE.X.Offset, BUTTON_SIZE.Y.Offset
	local refRight = ref.AbsolutePosition.X + ref.AbsoluteSize.X
	local bottom = ref.AbsolutePosition.Y - BUTTON_GAP
	local boxes = ScreenButtons.boxes(gui, CLEAR_GAP)
	local rights = { refRight }
	local touch = player.PlayerGui:FindFirstChild("TouchGui")
	local jump = touch and touch:FindFirstChild("JumpButton", true)
	if jump and jump:IsA("GuiObject") and jump.Visible and jump.AbsoluteSize.X > 0 then
		table.insert(boxes, { jump.AbsolutePosition, jump.AbsolutePosition + jump.AbsoluteSize, BUTTON_GAP })
		table.insert(rights, math.min(refRight, jump.AbsolutePosition.X - BUTTON_GAP))
	end
	local pick = nil
	for k = 0, LIFT_TRIES do
		for _, right in ipairs(rights) do
			local y = bottom - k * LIFT_STEP
			if not pick and clearOf(Vector2.new(right - w, y - h), Vector2.new(right, y), boxes) then
				pick = Vector2.new(right, y)
			end
		end
	end
	if not pick then
		local y = ref.AbsolutePosition.Y + ref.AbsoluteSize.Y
		local right = ref.AbsolutePosition.X - BUTTON_GAP
		pick = clearOf(Vector2.new(right - w, y - h), Vector2.new(right, y), boxes) and Vector2.new(right, y)
			or Vector2.new(rights[#rights], bottom)
	end
	local origin = gui.AbsolutePosition
	local at = UDim2.fromOffset(pick.X - origin.X, pick.Y - origin.Y)
	if button.Position ~= at then
		button.Position = at
		ScreenButtons.moved()
	end
end

local placedFor = nil
local function waitLeft()
	return (player:GetAttribute("HideSeekDisguiseReady") or 0) - workspace:GetServerTimeNow()
end

local pressedAt = -math.huge
local function canDisguise()
	return (player:GetAttribute("HideSeekRole") == "Hider" and player:GetAttribute("HideSeekRoom") ~= nil)
		or player:GetAttribute("HideSeekPractice") == true
end

local function press()
	if not canDisguise() then
		return
	end
	if os.clock() - pressedAt < PRESS_GAP then
		return
	end
	pressedAt = os.clock()
	Net.request("HideSeekDisguise")
end
button.Activated:Connect(press)
UserInputService.InputBegan:Connect(function(input, processed)
	if not processed and input.KeyCode == DISGUISE_KEY then
		press()
	end
end)

local shown = {}

local function isThing(look)
	return string.sub(look, 1, #THING_PREFIX) == THING_PREFIX
end

local function makeThing(look, mine)
	local folder = ReplicatedStorage:FindFirstChild("HideSeekDisguises")
	local source = folder and folder:FindFirstChild(look)
	if not source then
		return nil
	end
	local model = source:Clone()
	model.Name = "Disguise"
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
			if mine then
				d.Transparency = math.max(d.Transparency, OWN_THING_SEE_THROUGH)
			end
		end
	end
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2 - (source:GetAttribute("Sink") or 0), 0))
	model.Parent = workspace
	return model
end

local function makeModel(species)
	local models = ReplicatedStorage:FindFirstChild("DinoModels")
	local source = models and (models:FindFirstChild("Dino_" .. species, true) or models:FindFirstChild("Dino_Raptor", true))
	if not source then
		return nil
	end
	local model = Instance.new("Model")
	model.Name = "Disguise"
	source:Clone().Parent = model
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
		elseif d:IsA("Script") or d:IsA("LocalScript") or d:IsA("ProximityPrompt") or d:IsA("BillboardGui") then
			d:Destroy()
		end
	end
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
	model:ScaleTo(C.DisguiseHeight / math.max(size.Y, 0.1))
	model.Parent = workspace
	return model
end

local function setHidden(character, hidden)
	for _, d in ipairs(character:GetDescendants()) do
		if d:IsA("BasePart") or d:IsA("Decal") then
			d.LocalTransparencyModifier = hidden and 1 or 0
		elseif d:IsA("BillboardGui") then
			if hidden then
				if d:GetAttribute("DisguiseWasOn") == nil then
					d:SetAttribute("DisguiseWasOn", d.Enabled)
				end
				d.Enabled = false
			elseif d:GetAttribute("DisguiseWasOn") ~= nil then
				d.Enabled = d:GetAttribute("DisguiseWasOn")
				d:SetAttribute("DisguiseWasOn", nil)
			end
		end
	end
end

local function drop(p)
	local s = shown[p]
	if not s then
		return
	end
	shown[p] = nil
	if s.model then
		local at = s.model:GetPivot().Position
		Fx.burst(at + Vector3.new(0, 1.5, 0), POOF_COLORS, 16, 10, 0.5, 0.6)
		Sfx.play("MinePop", at)
		s.model:Destroy()
	end
	if s.character and s.character.Parent then
		setHidden(s.character, false)
	end
end

RunService.RenderStepped:Connect(FrameMeter.wrap("HideSeekDisguise", function(dt)
	local mine = canDisguise()
	if mine and (not button.Visible or ScreenButtons.version() ~= placedFor) then
		placedFor = ScreenButtons.version()
		place()
	end
	button.Visible = mine
	if mine then
		local on = player:GetAttribute("HideSeekDisguise") ~= nil
		local left = player:GetAttribute("HideSeekDisguises") or 0
		local wait = waitLeft()
		if on then
			Lang.set(button, "🎭 변신 풀기\n(Z)")
		elseif wait > 0 and left > 0 then
			Lang.set(button, string.format("⏳ %d초\n(Z)", math.ceil(wait)))
		else
			Lang.set(button, string.format("🎭 변신\n%d번 (Z)", left))
		end
		button.BackgroundColor3 = (on or (left > 0 and wait <= 0)) and COLOR_ON or COLOR_DIM
	end
	for _, p in ipairs(Players:GetPlayers()) do
		local species = p:GetAttribute("HideSeekDisguise")
		local character = p.Character
		local root = character and character:FindFirstChild("HumanoidRootPart")
		local s = shown[p]
		if not species or not root then
			if s then
				drop(p)
			end
		else
			if s and (s.species ~= species or s.character ~= character) then
				drop(p)
				s = nil
			end
			if not s then
				local thing = isThing(species)
				local model = if thing then makeThing(species, p == player) else makeModel(species)
				if model then
					s = { species = species, character = character, model = model,
						rig = if thing then nil else DinoMotion.new(model) }
					shown[p] = s
					Fx.burst(root.Position, POOF_COLORS, 16, 10, 0.5, 0.6)
					Sfx.play("MinePop", root.Position)
				end
			end
			if s then
				setHidden(character, true)
				local v = root.AssemblyLinearVelocity
				local flat = Vector3.new(v.X, 0, v.Z)
				local look = root.CFrame.LookVector
				look = Vector3.new(look.X, 0, look.Z)
				if look.Magnitude < 0.01 then
					look = Vector3.new(0, 0, -1)
				end
				local humanoid = character:FindFirstChildOfClass("Humanoid")
				local feet = root.Position - Vector3.new(0, (humanoid and humanoid.HipHeight or 2) + root.Size.Y / 2, 0)
				local at = CFrame.lookAt(feet, feet + look.Unit)
				if s.rig then
					s.model:PivotTo(at * DinoMotion.step(s.rig, dt, flat.Magnitude))
				elseif not s.at or (s.at.Position - at.Position).Magnitude > STILL_MOVE
					or s.at.LookVector:Dot(at.LookVector) < STILL_TURN then
					s.at = at
					s.model:PivotTo(at)
				end
			end
		end
	end
	for p in pairs(shown) do
		if not p.Parent then
			drop(p)
		end
	end
end))
