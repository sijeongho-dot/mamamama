--[[
CombatFx: the player's side of PvP (display and input only; the server's Combat and Keys decide).

- "찰싹" button (bottom right, left of the phone jump button), key F or gamepad X: Net request Slap.
  Out on the battlefield it hits players; in the player's own base, next to their defense track, it
  hits the fossils there (a bone "찰싹!" where it lands).
- "내려놓기" (above it, only while carrying), key G or gamepad Y: Net request DropKeys (all of them).
  The slap button dims during the cooldown, while mining and outside the battlefield (carrying keys
  is fine).
- SlapFx pushes: the slapper grips the slap toy (ReplicatedStorage.SlapModels, the level's look and
  size; a skin is drawn SKIN_SIZE times as big, with sparkles, so it stands out) in the right hand and
  swings it; the pickaxe in that hand (HeldPickaxe, Minerals service) is hidden for the swing: every client turns that character's R15 joints itself (right
  shoulder and elbow, and the waist twisting with it: wind-up to the right, a fast sweep across the
  front, back to rest), on top of whatever it is playing, set in RunService.Stepped like the mining
  swing. A rig without those joints swings the toy around the body instead; a hit pops "찰싹!" over every target hit (a slap hits everything in reach), and flashes the screen if it is me.
- Knockback pushes: my own character is pushed away (a short LinearVelocity; the server told
  MoveGuard to allow it).
- A character that died (fell off the world, reset): stars spin over its head; for me a countdown to starting again at
  the base (player attribute KnockedOutAt + Players.RespawnTime).
- Banners at the top for key drops ("열쇠가 생성되었습니다!") and, bigger, for better key grades;
  rainbow keys cycle their colors.
- "⚡ 속도 x1.8!" when a speed pad speeds me up (player attribute SpeedBoost, SpeedPads service).
- "위험 지역!" / "안전 지역" when I go in past the battlefield flags or come out (Shared/SafeZones); "열쇠 n개 운반 중" while carrying; a
  "현상금 1등" crown over the server's #1 (attribute Bounty).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local Lang = require(Shared:WaitForChild("Lang")) -- (Lang.set: a text set every frame, only when it changes)
local Fx = require(Shared:WaitForChild("Fx"))
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait")) -- (a grade's color)
local Sfx = require(Shared:WaitForChild("Sfx"))
local Coach = require(Shared:WaitForChild("Coach"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local SLAP_BUTTON_SIZE = UDim2.fromOffset(84, 84)
local SLAP_BUTTON_POS = UDim2.new(1, -112, 1, -20) -- left of the phone jump button
local COLOR_SLAP = Color3.fromRGB(255, 120, 150)
local COLOR_DIM = Color3.fromRGB(110, 110, 120)
local COLOR_DROP = Color3.fromRGB(200, 150, 40)
local DROP_BUTTON_SIZE = UDim2.fromOffset(64, 40)
local DROP_GAP = 8
local CARRY_TOP = -146
local CARRY_HEIGHT = 26
-- (2026-10-04) the keys' drop picker over the button
local EDGE_COLOR = Color3.fromRGB(255, 200, 50) -- the screen edges while carrying keys
local EDGE_WIDTH = 70
local EDGE_FLASH_SECONDS = 0.8
local EDGE_PULSE_MIN, EDGE_PULSE_MAX, EDGE_PULSE_SPEED = 0.55, 0.85, 3
local HIT_COLORS = { Color3.fromRGB(255, 240, 120), Color3.fromRGB(255, 255, 255), Color3.fromRGB(255, 150, 90) }
local BONE_COLORS = { Color3.fromRGB(245, 240, 225), Color3.fromRGB(210, 200, 180), Color3.fromRGB(255, 240, 120) }
local MAX_HIT_FX = 8 -- a slap that hits many things shows at most this many spots (the nearest)
local TRACK_SLACK = 3 -- studs: the slap button lights up this much past reach of the fossil lane
local KEY_BURST_COLORS = { Color3.fromRGB(255, 215, 80), Color3.fromRGB(255, 255, 220) }
local KEY_BURST_DISTANCE = 200 -- studs from the camera within which new keys sparkle
local HAND_SIZE = 3.2 -- studs, the level-1 slap toy's longest side: a character's upper body, waist to head
-- (bigger levels × Config.Slap.Scale)
local SKIN_SIZE = 2 -- a skin is drawn this many times as big as the plain toy of that level (2026-10-01; 1.4 → 2:
-- "bigger when a skin slaps, the reach the same": the look only, the hit is the server's Config.Slap)
local SKIN_SPARKLE_RATE = 25 -- sparkles a second off a skin while it swings
local SKIN_SPARKLE_COLORS = { Color3.fromRGB(255, 255, 255), Color3.fromRGB(255, 225, 120) }
-- (2026-10-02, "찰싹 스킨들도 등급별로 이펙트 넣어주자") a skin's effects by its grade (Config.Slap.Skins Grade),
-- in the grade's color: sparkles a second while it swings; a trail behind it; a glow; extra sparks at each
-- hit; a ring spreading from the hit. A better grade has everything the one below has, and more
local SKIN_FX = {
	Rare = { sparkle = 25 },
	Epic = { sparkle = 35, trail = true },
	Legendary = { sparkle = 50, trail = true, light = true, sparks = 14 },
	Mythic = { sparkle = 70, trail = true, light = true, sparks = 26, ring = true },
}
local SKIN_SIGNS = {
	Slap_RexClaw = { emoji = { "🦖", "💢" }, color = Color3.fromRGB(255, 110, 70) },
	Slap_LeafHand = { emoji = { "🍃", "🌿" }, color = Color3.fromRGB(110, 220, 90) },
	Slap_ShellGlove = { emoji = { "🛡️", "🐢" }, color = Color3.fromRGB(190, 150, 90) },
	Slap_WingHand = { emoji = { "🐦", "💨" }, color = Color3.fromRGB(150, 210, 255) },
	Slap_FinHand = { emoji = { "💧", "🐟" }, color = Color3.fromRGB(70, 160, 255) },
	Slap_BoneHand = { emoji = { "💀", "🦴" }, color = Color3.fromRGB(230, 225, 200) },
	Slap_Pizza = { emoji = { "🍕", "🧀" }, color = Color3.fromRGB(255, 200, 60) },
	Slap_IceHand = { emoji = { "❄️", "🧊" }, color = Color3.fromRGB(160, 235, 255) },
	Slap_Octopus = { emoji = { "🐙", "💦" }, color = Color3.fromRGB(230, 110, 200) },
	Slap_Crown = { emoji = { "👑", "💎", "✨" }, color = Color3.fromRGB(255, 220, 80) },
	Slap_Jade = { emoji = { "💚", "🍀" }, color = Color3.fromRGB(80, 220, 150) },
	Slap_Amethyst = { emoji = { "💜", "🔮" }, color = Color3.fromRGB(180, 110, 255) },
	Slap_PhoenixHand = { emoji = { "🔥", "✨" }, color = Color3.fromRGB(255, 140, 40) },
	Slap_EggShell = { emoji = { "🥚", "🐣" }, color = Color3.fromRGB(255, 240, 200) },
	Slap_LavaFist = { emoji = { "🌋", "🔥" }, color = Color3.fromRGB(255, 90, 30) },
	Slap_CoralHand = { emoji = { "🐠", "🐚" }, color = Color3.fromRGB(255, 130, 150) },
	Slap_StarGlove = { emoji = { "⭐", "🌟" }, color = Color3.fromRGB(255, 235, 120) },
	Slap_CatPaw = { emoji = { "🐾", "🐱" }, color = Color3.fromRGB(255, 170, 200) },
	Slap_RoboArm = { emoji = { "⚙️", "🔩", "🤖" }, color = Color3.fromRGB(170, 190, 210) },
	Slap_Neon = { emoji = { "⚡", "💡" }, color = Color3.fromRGB(80, 255, 230) },
	Slap_DragonClaw = { emoji = { "🐉", "🔥" }, color = Color3.fromRGB(255, 70, 70) },
	Slap_Launch = { emoji = { "🎉", "🎊" }, color = Color3.fromRGB(255, 120, 220) },
}
local SIGN_HIT_COUNT = { Rare = 4, Epic = 5, Legendary = 6, Mythic = 8 }
local SIGN_SWING_COUNT = 3
local SIGN_STUDS = 1.6
local SIGN_SPEED = 9
local SIGN_UP = 10
local SIGN_GRAVITY = 26
local SIGN_SPIN = 240
local SIGN_LIFE = 0.9
local SIGN_DISTANCE = 120
local SIGN_MAX = 48
local SKIN_TRAIL_SECONDS = 0.22
local SKIN_LIGHT_RANGE = 10
local SKIN_LIGHT_BRIGHTNESS = 3
local SKIN_RING_SIZE = 12 -- studs across when it has spread
local SKIN_RING_SECONDS = 0.45
local SWING_SECONDS = 0.4 -- the whole swing, wind-up to rest; the hit lands at SWING_HIT of it
local SWING_HIT = 0.55
-- the arm's key poses: joint -> { pitch (about its X: + lifts a limb forward), yaw (about its Y: + turns
-- toward the character's left) }, eased between; missing joints stay as they are
local SWING_KEYS = {
	{ 0, {} },
	{ 0.35, { RightShoulder = { 1.4, -1.1 }, RightElbow = { 0.8, 0 }, Waist = { 0, -0.35 } } }, -- wind-up, right
	{ 0.6, { RightShoulder = { 1.55, 0.95 }, RightElbow = { 0.1, 0 }, Waist = { 0, 0.4 } } }, -- the sweep, left
	{ 1, {} },
}
local SWING_JOINTS = { "RightShoulder", "RightElbow", "Waist" }
local SWING_ARC = math.rad(150)
local KNOCK_SECONDS = 0.25
local FOSSIL_POP_SIZE = UDim2.fromOffset(160, 64)
local FOSSIL_POP_FROM = Vector3.new(0, 4, 0)
local FOSSIL_POP_RISE = 3
local FOSSIL_POP_SECONDS = 0.9
local FOSSIL_POP_GROW_SECONDS = 0.2
local FOSSIL_POP_COLOR = Color3.fromRGB(255, 215, 90)
local FOSSIL_POP_MANY_COLOR = Color3.fromRGB(255, 140, 60)
local TUMBLE = 4 -- radians per second the thrown body turns over
local FLY_HEARD = 120 -- studs from the camera: a thrown player's whoosh (Net push FlyFx)
local BUCK_LIGHT_PITCH, BUCK_LIGHT_GAIN = 1.8, 0.55 -- a little wild dino's buck (a giant's: the sound as it is)
local FLY_PITCH_SECONDS = 0.9 -- a throw this long whooshes at its usual pitch; longer lower, shorter higher
local POP_SECONDS = 0.6
local STAR_SPIN = 180 -- degrees per second
-- (2026-10-03, "찰싹 맞고 어질어질 이펙트가 화면에 안 맞는데") groggy after a slap: stars circling the head (everyone sees
-- them), and my own "💫 어질어질" line fits any screen (it was 520 px wide whatever the phone)
local DIZZY_STARS = { "⭐", "💫", "⭐" }
local DIZZY_SIZE = UDim2.fromOffset(110, 60) -- the billboard over the head
local DIZZY_UP = 2.2 -- studs over the head
local DIZZY_TURN = 4 -- turns a second... (radians)
local DIZZY_RX, DIZZY_RY = 0.38, 0.16 -- the circle's half width and height, share of the billboard
local DIZZY_TEXT = 22
local DIZZY_CHECK = 0.2 -- seconds between looks at who is groggy
local CENTER_MAX = Vector2.new(520, 40) -- my status line: at most this big, less on a narrow screen
local CENTER_TEXT = 26
local TOAST_SECONDS = 1.6
local CHECK_EVERY = 0.3
-- the announcements (Net push Banner) in the notice stack (Shared/Notices): how long each stays, the plain ones' color
local BANNER_SECONDS = 4 -- (were 2.5 across the middle; at the side they can stay a little longer)
local BANNER_SPECIAL_SECONDS = 5
local BANNER_COLOR = Color3.fromRGB(255, 225, 120)
local RAINBOW_CYCLE_SECONDS = 2
local COLOR_STEP = 0.1 -- seconds between two color steps of the cycle

local gui = Instance.new("ScreenGui")
gui.Name = "Combat"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local function label(parent, text, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextSize = textSize
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextStrokeTransparency = 0.3
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

-- ---------------------------------------------------------------------------
-- Slap button
-- ---------------------------------------------------------------------------

-- "내려놓기": only while carrying keys, just above the slap button
local dropButton = Instance.new("TextButton")
dropButton.AnchorPoint = Vector2.new(1, 0.5)
dropButton.Size = DROP_BUTTON_SIZE
dropButton.Position = UDim2.new(0.5, 0, 1, CARRY_TOP + CARRY_HEIGHT / 2)
dropButton.BackgroundColor3 = COLOR_DROP
dropButton.Font = FONT
dropButton.TextSize = 12
dropButton.TextWrapped = true
dropButton.TextColor3 = Color3.new(1, 1, 1)
dropButton.Text = "🎁⬇️ 내려놓기\n(G)"
dropButton.Visible = false
dropButton.Parent = gui
local dropCorner = Instance.new("UICorner")
dropCorner.CornerRadius = UDim.new(0, 10)
dropCorner.Parent = dropButton
local function dropKeys()
	if (player:GetAttribute("CarriedKeys") or 0) > 0 then
		Net.request("DropKeys")
	end
end
dropButton.Activated:Connect(dropKeys)
local lastCarried = player:GetAttribute("CarriedKeys") or 0
local remindCarry -- defined below: the gold screen edges and "take them home" when keys are picked up
player:GetAttributeChangedSignal("CarriedKeys"):Connect(function() -- picking keys up sounds
	local now = player:GetAttribute("CarriedKeys") or 0
	if now > lastCarried then
		Sfx.play("KeyPickup")
		if lastCarried == 0 and remindCarry then
			remindCarry()
		end
	end
	lastCarried = now
end)
player:GetAttributeChangedSignal("KnockedOutAt"):Connect(function()
	if player:GetAttribute("KnockedOutAt") then
		Sfx.play("KnockOut")
	end
end)
player:GetAttributeChangedSignal("CarriedKeys"):Connect(function()
	dropButton.Visible = (player:GetAttribute("CarriedKeys") or 0) > 0
	if not dropButton.Visible then
	end
end)

local slapButton = Instance.new("TextButton")
slapButton.Name = "SlapButton"
slapButton:SetAttribute("NoClickSound", true) -- (UiSounds: pressed all the time, it has its own swing)
slapButton.AnchorPoint = Vector2.new(1, 1)
slapButton.Size = SLAP_BUTTON_SIZE
slapButton.Position = SLAP_BUTTON_POS
slapButton.BackgroundColor3 = COLOR_SLAP
slapButton.Font = FONT
slapButton.TextSize = 20
slapButton.TextColor3 = Color3.new(1, 1, 1)
slapButton.Text = "👋 찰싹\n(F)"
slapButton.Parent = gui
Coach.mark(slapButton, "Slap")
local round = Instance.new("UICorner")
round.CornerRadius = UDim.new(0.5, 0)
round.Parent = slapButton
-- (2026-10-03) a hide-and-seek hider can't slap: 🕸️ 함정 (StarterPlayerScripts/HideSeek) takes the button's place
local function slapShown()
	slapButton.Visible = player:GetAttribute("HideSeekRole") ~= "Hider"
		and not (player:GetAttribute("HideSeekTrapPractice") and player:GetAttribute("HideSeekRoom") == nil)
end
player:GetAttributeChangedSignal("HideSeekRole"):Connect(slapShown)
player:GetAttributeChangedSignal("HideSeekTrapPractice"):Connect(slapShown)

local lastPress = -math.huge
-- next to my own defense track, where a slap hits the fossils (the server checks again)
local function nearOwnTrack(position)
	local map = Workspace:FindFirstChild("Map")
	local folder = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	local frame = folder and folder:GetAttribute("ArenaFrame")
	if not frame then
		return false
	end
	local p = frame:PointToObjectSpace(position)
	local fromLane = Formulas.laneDistance(Formulas.lanePath(folder:GetAttribute("DefenseMap")), p.X, p.Z)
	local reach = Formulas.slapReach(player:GetAttribute("TrainReal_Slap") or player:GetAttribute("SlapLevel") or 1) + Config.Defense.MonsterRadius + TRACK_SLACK
	return math.abs(p.Y) <= Config.Slap.FossilHeight and fromLane <= reach
end

-- (2026-10-03, "날아가는 도중엔 찰싹이 안 되게") thrown by a slap: no slap while flying or lying groggy
-- (the server checks too)
local function down()
	return player:GetAttribute("StunReason") == "Groggy"
		and (player:GetAttribute("StunnedUntil") or 0) > Workspace:GetServerTimeNow()
end

local function trySlap()
	if os.clock() - lastPress < Config.Slap.Cooldown or down() then
		return
	end
	lastPress = os.clock()
	-- where I am and face on my screen (running, the server has me a little behind; it checks this)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	Net.request("Slap", root and root.Position or Vector3.zero, root and root.CFrame.LookVector or Vector3.zAxis)
end
slapButton.Activated:Connect(trySlap)
UserInputService.InputBegan:Connect(function(input, processed)
	if not processed and (input.KeyCode == Enum.KeyCode.F or input.KeyCode == Enum.KeyCode.ButtonX) then
		trySlap()
	elseif not processed and (input.KeyCode == Enum.KeyCode.G or input.KeyCode == Enum.KeyCode.ButtonY) then
		dropKeys()
	end
end)

-- ---------------------------------------------------------------------------
-- Swings and hits
-- ---------------------------------------------------------------------------


-- the slap toy: the slapper's skin (player attribute SlapSkin, Skins service) or else the level's look,
-- at the level's size
local function handModel(level, slapper)
	local look = Config.Slap.Looks[math.min(#Config.Slap.Looks, (level - 1) // Config.Slap.LevelsPerLook + 1)]
	local skin = slapper and slapper:GetAttribute("SlapSkin")
	local slapModels = ReplicatedStorage:FindFirstChild("SlapModels")
	local skinSource = slapModels and skin and skin ~= "" and slapModels:FindFirstChild(skin)
	local source = skinSource or (slapModels and slapModels:FindFirstChild(look))
	local model = Instance.new("Model")
	if source then
		source:Clone().Parent = model
	else
		local p = Instance.new("Part")
		p.Size = Vector3.new(1.4, 1.8, 0.4)
		p.Color = COLOR_SLAP
		p.Parent = model
	end
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
		end
	end
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position)
	model:ScaleTo(HAND_SIZE * Formulas.slapScale(level) * (skinSource and SKIN_SIZE or 1) / math.max(size.X, size.Y, size.Z, 0.1))
	local onePart = skinSource and model:FindFirstChildWhichIsA("BasePart", true)
	local skinInfo = skinSource and Formulas.skinByModel(skin)
	local fx = skinInfo and SKIN_FX[skinInfo.Grade]
	local gradeColor = fx and DinoPortrait.gradeColor(skinInfo.Grade)
	local sign = skinSource and SKIN_SIGNS[skin]
	if onePart then -- a skin glitters as it swings (in its grade's color)
		local sparkle = Instance.new("ParticleEmitter")
		sparkle.Color = sign and ColorSequence.new(sign.color, gradeColor or SKIN_SPARKLE_COLORS[1])
			or gradeColor and ColorSequence.new(SKIN_SPARKLE_COLORS[1], gradeColor)
			or ColorSequence.new(SKIN_SPARKLE_COLORS[1], SKIN_SPARKLE_COLORS[2])
		sparkle.LightEmission = 1
		sparkle.Size = NumberSequence.new(0.35, 0)
		sparkle.Speed = NumberRange.new(1, 3)
		sparkle.Lifetime = NumberRange.new(0.3, 0.5)
		sparkle.SpreadAngle = Vector2.new(180, 180)
		sparkle.Rate = fx and fx.sparkle or SKIN_SPARKLE_RATE
		sparkle.Parent = onePart
	end
	if onePart and fx and fx.trail then -- a streak behind it, along its longest side (the model is still unturned)
		local center, extent = model:GetBoundingBox()
		local axis = extent.X >= extent.Y and extent.X >= extent.Z and Vector3.xAxis
			or extent.Y >= extent.Z and Vector3.yAxis or Vector3.zAxis
		local half = axis * (math.max(extent.X, extent.Y, extent.Z) * 0.4)
		local a0, a1 = Instance.new("Attachment"), Instance.new("Attachment")
		a0.Parent, a1.Parent = onePart, onePart
		a0.WorldPosition, a1.WorldPosition = center.Position + half, center.Position - half
		local trail = Instance.new("Trail")
		trail.Enabled = false -- (on once it is in the hand: not a streak from where it was made)
		trail.Attachment0, trail.Attachment1 = a0, a1
		trail.Color = ColorSequence.new(sign and sign.color or gradeColor, gradeColor)
		trail.Transparency = NumberSequence.new(0.2, 1)
		trail.Lifetime = SKIN_TRAIL_SECONDS
		trail.LightEmission = 0.8
		trail.FaceCamera = true
		trail.Parent = onePart
	end
	if onePart and fx and fx.light then
		local light = Instance.new("PointLight")
		light.Color = gradeColor
		light.Range = SKIN_LIGHT_RANGE
		light.Brightness = SKIN_LIGHT_BRIGHTNESS
		light.Parent = onePart
	end
	return model, fx, gradeColor, sign and { emoji = sign.emoji, count = SIGN_HIT_COUNT[skinInfo and skinInfo.Grade] or SIGN_HIT_COUNT.Rare }
end

local flying = {}
local function signBurst(sign, at, count)
	local camera = Workspace.CurrentCamera
	if not sign or not camera or (camera.CFrame.Position - at).Magnitude > SIGN_DISTANCE then
		return
	end
	for i = 1, count do
		if #flying >= SIGN_MAX then
			return
		end
		local part = Instance.new("Part")
		part.Anchored, part.CanCollide, part.CanQuery, part.CanTouch, part.CastShadow = true, false, false, false, false
		part.Transparency = 1
		part.Size = Vector3.one * 0.2
		part.CFrame = CFrame.new(at)
		local board = Instance.new("BillboardGui")
		board.Size = UDim2.fromScale(SIGN_STUDS, SIGN_STUDS)
		board.LightInfluence = 0
		board.Adornee = part
		board.Parent = part
		local label = Instance.new("TextLabel")
		label.Size = UDim2.fromScale(1, 1)
		label.BackgroundTransparency = 1
		label.TextScaled = true
		label.Text = sign.emoji[(i - 1) % #sign.emoji + 1]
		label:SetAttribute("KeepText", true)
		label.Parent = board
		part.Parent = Workspace
		local angle = math.random() * 2 * math.pi
		local speed = SIGN_SPEED * (0.5 + math.random() * 0.5)
		table.insert(flying, { part = part, label = label, born = os.clock(), spin = (math.random() * 2 - 1) * SIGN_SPIN,
			v = Vector3.new(math.cos(angle) * speed, SIGN_UP * (0.7 + math.random() * 0.6), math.sin(angle) * speed) })
	end
end

RunService.Heartbeat:Connect(FrameMeter.wrap("CombatFxSign", function(dt)
	if #flying == 0 then
		return
	end
	local now = os.clock()
	for i = #flying, 1, -1 do
		local f = flying[i]
		local age = now - f.born
		if age >= SIGN_LIFE or not f.part.Parent then
			f.part:Destroy()
			table.remove(flying, i)
		else
			f.v -= Vector3.new(0, SIGN_GRAVITY * dt, 0)
			f.part.Position += f.v * dt
			f.label.Rotation += f.spin * dt
			f.label.TextTransparency = math.clamp((age / SIGN_LIFE - 0.6) / 0.4, 0, 1)
		end
	end
end))

-- a skin's own hit at a spot: its grade's sparks and ring (nothing for a plain toy)
local function skinHit(fx, color, at, sign)
	if sign then
		signBurst(sign, at, sign.count)
	end
	if not fx then
		return
	end
	if fx.sparks then
		Fx.burst(at, { color, Color3.new(1, 1, 1) }, fx.sparks, 22, 0.8, 0.6)
	end
	if fx.ring then
		local ring = Instance.new("Part")
		ring.Shape = Enum.PartType.Cylinder
		ring.Anchored, ring.CanCollide, ring.CanQuery, ring.CanTouch, ring.CastShadow = true, false, false, false, false
		ring.Material = Enum.Material.Neon
		ring.Color = color
		ring.Transparency = 0.2
		ring.Size = Vector3.new(0.2, 1, 1)
		ring.CFrame = CFrame.new(at) * CFrame.Angles(0, 0, math.rad(90)) -- (a cylinder's round faces on X: lying flat)
		ring.Parent = Workspace
		TweenService:Create(ring, TweenInfo.new(SKIN_RING_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
			{ Size = Vector3.new(0.2, SKIN_RING_SIZE, SKIN_RING_SIZE), Transparency = 1 }):Play()
		task.delay(SKIN_RING_SECONDS, function()
			ring:Destroy()
		end)
	end
end

-- the pickaxe in the slapper's hand is hidden while the toy swings (only the toy in the fist);
-- [character] = swings going on now, so overlapping slaps show it again only after the last
local pickaxeHidden = {}
local function hidePickaxe(character, hidden)
	local count = (pickaxeHidden[character] or 0) + (hidden and 1 or -1)
	pickaxeHidden[character] = count > 0 and count or nil
	local held = character:FindFirstChild("HeldPickaxe")
	if held then
		for _, d in ipairs(held:GetDescendants()) do
			if d:IsA("BasePart") then
				d.LocalTransparencyModifier = count > 0 and 1 or 0
			end
		end
	end
end

local function pop(character, text, at)
	local head = character and character:FindFirstChild("Head")
	if not head and not at then
		return
	end
	if not head then -- a spot in the world (a slapped fossil)
		head = Instance.new("Part")
		head.Anchored, head.CanCollide, head.CanQuery, head.CanTouch = true, false, false, false
		head.Transparency = 1
		head.Size = Vector3.one * 0.2
		head.CFrame = CFrame.new(at)
		head.Parent = Workspace
		task.delay(POP_SECONDS, function()
			head:Destroy()
		end)
	end
	local b = Instance.new("BillboardGui")
	b.Size = UDim2.fromOffset(120, 40)
	b.StudsOffsetWorldSpace = Vector3.new(0, 2.5, 0)
	b.AlwaysOnTop = true
	label(b, text, UDim2.fromScale(1, 1), UDim2.new(), 30, Color3.fromRGB(255, 230, 90))
	b.Parent = head
	task.delay(POP_SECONDS, function()
		b:Destroy()
	end)
end

local flash = Instance.new("Frame")
flash.Size = UDim2.fromScale(1, 1)
flash.BackgroundColor3 = Color3.new(1, 1, 1)
flash.BackgroundTransparency = 1
flash.ZIndex = 10
flash.Parent = gui

-- the swinging arm: the joints of a character's rig (Motor6D, or AnimationConstraint with Roblox's
-- avatar joint upgrade), nil when it has none of them
local function swingJoints(character)
	local found, any = {}, false
	for _, d in ipairs(character and character:GetDescendants() or {}) do
		if (d:IsA("Motor6D") or d:IsA("AnimationConstraint")) and table.find(SWING_JOINTS, d.Name) then
			found[d.Name] = d
			any = true
		end
	end
	return any and found or nil
end

local function ease(t)
	return t * t * (3 - 2 * t)
end

-- the swing's turn of one joint at t (0-1)
local function swingPose(name, t)
	for i = 1, #SWING_KEYS - 1 do
		local a, b = SWING_KEYS[i], SWING_KEYS[i + 1]
		if t <= b[1] then
			local k = ease((t - a[1]) / (b[1] - a[1]))
			local pa, pb = a[2][name] or { 0, 0 }, b[2][name] or { 0, 0 }
			local pitch = pa[1] + (pb[1] - pa[1]) * k
			local yaw = pa[2] + (pb[2] - pa[2]) * k
			return CFrame.fromAxisAngle(Vector3.yAxis, yaw) * CFrame.fromAxisAngle(Vector3.xAxis, pitch)
		end
	end
	return CFrame.identity
end

-- swinging characters: [character] = { start, joints }; posed after the Animator each frame
local swings = {}
RunService.Stepped:Connect(FrameMeter.wrap("CombatFx", function()
	local now = os.clock()
	for character, sw in pairs(swings) do
		local t = (now - sw.start) / SWING_SECONDS
		if t >= 1 or not character.Parent then
			swings[character] = nil
		else
			for name, joint in pairs(sw.joints) do
				if joint.Parent then
					joint.Transform = joint.Transform * swingPose(name, t)
				end
			end
		end
	end
end))

Net.onPush("SlapFx", function(slapperId, targetId, level, fossilAt) -- targetId / fossilAt: lists (2026-10-01)
	local slapper = Players:GetPlayerByUserId(slapperId)
	local root = slapper and slapper.Character and slapper.Character:FindFirstChild("HumanoidRootPart")
	if not root or (root.Position - Workspace.CurrentCamera.CFrame.Position).Magnitude > 200 then
		return
	end
	local hand, skinFx, skinColor, skinSign = handModel(level, slapper)
	hand.Parent = Workspace
	local _, handSize = hand:GetBoundingBox()
	local grip = math.max(handSize.X, handSize.Y, handSize.Z) / 2 -- held by its end: the toy reaches out of the fist
	task.delay(SWING_SECONDS * 0.3, Sfx.play, "SlapSwing", root.Position)
	local character = slapper.Character
	local joints = swingJoints(character)
	local rightHand = character:FindFirstChild("RightHand") or character:FindFirstChild("Right Arm")
	if joints then
		swings[character] = { start = os.clock(), joints = joints }
	end
	hidePickaxe(character, true)
	local reach = Formulas.slapReach(level) * 0.6
	local start = os.clock()
	local trailsOn = false
	if skinSign then
		task.delay(SWING_SECONDS * SWING_HIT, function()
			if hand.Parent then
				signBurst(skinSign, hand:GetPivot().Position, SIGN_SWING_COUNT)
			end
		end)
	end
	local conn
	conn = RunService.Heartbeat:Connect(FrameMeter.wrap("CombatFx", function() -- after Stepped moved the arm
		local t = math.min(1, (os.clock() - start) / SWING_SECONDS)
		if joints and rightHand and rightHand.Parent then -- in the fist, out along the forearm
			-- the toy's handle (its bottom, -Y) in the fist, its paw (+Y) out past the fingers (the hand's -Y)
			hand:PivotTo(rightHand.CFrame * CFrame.new(0, -grip, 0) * CFrame.Angles(0, math.rad(90), 0)
				* CFrame.Angles(0, 0, math.pi))
		else -- no arm to hold it: the toy sweeps around the body
			local angle = SWING_ARC / 2 - SWING_ARC * t
			local base = root.CFrame * CFrame.Angles(0, angle, 0)
			hand:PivotTo(base * CFrame.new(0, 0.5, -reach) * CFrame.Angles(0, math.rad(90), 0))
		end
		if not trailsOn then -- (a grade's trail, from the hand on)
			trailsOn = true
			for _, d in ipairs(hand:GetDescendants()) do
				if d:IsA("Trail") then
					d.Enabled = true
				end
			end
		end
		if t >= 1 then
			conn:Disconnect()
			hand:Destroy()
			hidePickaxe(character, false)
		end
	end))
	-- (2026-10-01) a slap hits everything in reach: every player (targetIds) and every fossil or zombie (spots)
	local spots = typeof(fossilAt) == "Vector3" and { fossilAt } or (type(fossilAt) == "table" and fossilAt or {})
	for i, at in ipairs(spots) do
		if i > MAX_HIT_FX then
			break
		end
		if typeof(at) == "Vector3" then
			task.delay(SWING_SECONDS * SWING_HIT, function()
				pop(nil, "찰싹!", at)
				Fx.burst(at, BONE_COLORS, 18, 14, 0.6, 0.5)
				skinHit(skinFx, skinColor, at, skinSign)
				if i == 1 then -- one smack for the whole slap
					Sfx.play("SlapHit", at)
					Sfx.play("BoneHit", at, 0.9)
				end
			end)
		end
	end
	local ids = type(targetId) == "table" and targetId or { targetId }
	for i, id in ipairs(ids) do
		local target = type(id) == "number" and id ~= 0 and Players:GetPlayerByUserId(id)
		if target and i <= MAX_HIT_FX then
			task.delay(SWING_SECONDS * SWING_HIT, function()
				pop(target.Character, "찰싹!")
				local head = target.Character and target.Character:FindFirstChild("Head")
				if head then -- the hit: stars fly off the head, and the smack sound
					Fx.burst(head.Position, HIT_COLORS, 24, 18, 0.7, 0.6)
					skinHit(skinFx, skinColor, head.Position, skinSign)
					Sfx.play("SlapHit", head.Position)
					Sfx.play("Oof", head.Position) -- the one hit cries out: Roblox's own character death sound
				end
				if target == player then
					flash.BackgroundTransparency = 0.5
					TweenService:Create(flash, TweenInfo.new(0.3), { BackgroundTransparency = 1 }):Play()
				end
			end)
		end
	end
end)

-- a slap throws this player: up in a high arc, studs away, down after flight seconds, then lying
-- groggy for groggy seconds (the server keeps them still and unslappable meanwhile)
Net.onPush("Knockback", function(dx, dz, studs, flight, groggy)
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not root or not humanoid then
		return
	end
	flight = flight or KNOCK_SECONDS
	groggy = groggy or 0
	humanoid.PlatformStand = true -- no walking or standing up: the throw carries the body
	local up = Workspace.Gravity * flight / 2 -- lands again after flight seconds
	root.AssemblyLinearVelocity = Vector3.new(dx, 0, dz) * (studs / flight) + Vector3.new(0, up, 0)
	root.AssemblyAngularVelocity = Vector3.new(dz, 0, -dx) * TUMBLE -- tumbles over as it flies
	task.delay(flight + groggy, function()
		if humanoid.Parent then
			humanoid.PlatformStand = false
			humanoid:ChangeState(Enum.HumanoidStateType.GettingUp)
		end
	end)
end)

-- (2026-10-03, "야생공룡이 유저를 떨쳐낼때 소리이펙트 넣고 유저날아갈때도 소리이펙트 넣어") someone thrown through the
-- air (a slap, a bomb, a zombie, a storm bolt, a wild dino): a whoosh that flies with them, and when a wild dino
-- bucked them off its back, the buck first
Net.onPush("FlyFx", function(userId, seconds, kind)
	local who = Players:GetPlayerByUserId(userId)
	local root = who and who.Character and who.Character:FindFirstChild("HumanoidRootPart")
	local camera = Workspace.CurrentCamera
	if not root or not camera or (root.Position - camera.CFrame.Position).Magnitude > FLY_HEARD then
		return
	end
	if kind == "BuckBig" then
		Sfx.play("BuckOff", root)
	elseif kind == "Buck" then -- (2026-10-04) a little wild dino: the same buck, higher and softer
		Sfx.play("BuckOff", root, BUCK_LIGHT_PITCH, BUCK_LIGHT_GAIN)
	end
	local pitch = math.clamp(FLY_PITCH_SECONDS / math.max(tonumber(seconds) or FLY_PITCH_SECONDS, 0.1), 0.8, 1.3)
	Sfx.play("FlyWhoosh", root, pitch * (0.95 + math.random() * 0.1))
end)

-- ---------------------------------------------------------------------------
-- Knock-outs, crowns
-- ---------------------------------------------------------------------------

local function starsOver(character)
	local head = character:FindFirstChild("Head")
	if not head or head:FindFirstChild("KnockStars") then
		return
	end
	local b = Instance.new("BillboardGui")
	b.Name = "KnockStars"
	b.Size = UDim2.fromOffset(90, 40)
	b.StudsOffsetWorldSpace = Vector3.new(0, 2, 0)
	local stars = label(b, "★  ★  ★", UDim2.fromScale(1, 1), UDim2.new(), 24, Color3.fromRGB(255, 225, 70))
	b.Parent = head
	task.spawn(function()
		while b.Parent do
			stars.Rotation = (stars.Rotation + STAR_SPIN * task.wait()) % 360
		end
	end)
end

local function crownOver(other)
	local head = other.Character and other.Character:FindFirstChild("Head")
	if not head then
		return
	end
	local crown = head:FindFirstChild("BountyCrown")
	if other:GetAttribute("Bounty") then
		if not crown then
			crown = Instance.new("BillboardGui")
			crown.Name = "BountyCrown"
			crown.Size = UDim2.fromOffset(110, 26)
			-- (2026-10-02, "bounty 자막이 조금 내려가야 될듯": at 4.4 it rose into the screen's top lines up close) at the
			-- head-tag spot, stacked by pixels over the race record and the carried keys (StarterPlayerScripts/Race)
			crown.StudsOffsetWorldSpace = Vector3.new(0, 1.2, 0)
			crown.SizeOffset = Vector2.new(0, 3.5)
			crown.AlwaysOnTop = true
			label(crown, "👑 현상금 1등", UDim2.fromScale(1, 1), UDim2.new(), 18, Color3.fromRGB(255, 215, 60))
			crown.Parent = head
		end
	elseif crown then
		crown:Destroy()
	end
end

local function watchPlayer(other)
	local function onCharacter(character)
		local humanoid = character:WaitForChild("Humanoid", 10)
		if humanoid then
			humanoid.Died:Connect(function()
				starsOver(character)
			end)
		end
		task.defer(crownOver, other)
	end
	other.CharacterAdded:Connect(onCharacter)
	if other.Character then
		task.spawn(onCharacter, other.Character)
	end
	other:GetAttributeChangedSignal("Bounty"):Connect(function()
		crownOver(other)
	end)
end
Players.PlayerAdded:Connect(watchPlayer)
for _, other in ipairs(Players:GetPlayers()) do
	watchPlayer(other)
end

-- ---------------------------------------------------------------------------
-- My status lines: knocked out, carrying keys, battlefield edge
-- ---------------------------------------------------------------------------

local center = label(gui, "", UDim2.new(0.9, 0, 0, CENTER_MAX.Y), UDim2.fromScale(0.5, 0.35), CENTER_TEXT)
center.AnchorPoint = Vector2.new(0.5, 0)
center.TextScaled = true -- (shrinks to fit a narrow phone; never bigger than CENTER_TEXT)
do
	local most = Instance.new("UISizeConstraint")
	most.MaxSize = CENTER_MAX
	most.Parent = center
	local text = Instance.new("UITextSizeConstraint")
	text.MaxTextSize = CENTER_TEXT
	text.Parent = center
end
-- (2026-10-02, "화면 다 가리네") the keys I carry: a short pill over the bag bar, not a long line across the screen
local carryLine = label(gui, "", UDim2.fromOffset(0, CARRY_HEIGHT), UDim2.new(0.5, 0, 1, CARRY_TOP), 15, Color3.fromRGB(255, 205, 60))
carryLine.AnchorPoint = Vector2.new(0.5, 0)
carryLine.AutomaticSize = Enum.AutomaticSize.X
carryLine.BackgroundColor3 = Color3.fromRGB(20, 22, 32)
carryLine.BackgroundTransparency = 1
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 13)
	round.Parent = carryLine
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, 10), UDim.new(0, 10)
	pad.Parent = carryLine
end
-- (2026-10-02, "이런 식 글자도 안 겹치게": was a big 30 line at the screen's upper middle, over the name tags)
-- a pill over the carrying pill, on its own dark background
local toast = label(gui, "", UDim2.fromOffset(0, 30), UDim2.new(0.5, 0, 1, -182), 18)
toast.AnchorPoint = Vector2.new(0.5, 0)
toast.AutomaticSize = Enum.AutomaticSize.X
toast.BackgroundColor3 = Color3.fromRGB(20, 22, 32)
toast.BackgroundTransparency = 0.3
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 15)
	round.Parent = toast
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, 12), UDim.new(0, 12)
	pad.Parent = toast
end
toast.Visible = false

local inside = nil
local toastUntil = 0
local sinceCheck = 0
local lastBoost = nil
player:GetAttributeChangedSignal("SpeedBoostUntil"):Connect(function() -- a speed pad (SpeedPads): new or started over
	local boost = player:GetAttribute("SpeedBoost")
	local again = boost ~= nil and boost == lastBoost -- a weaker pad kept the speed and started the time over
	lastBoost = boost
	if boost then
		Sfx.play("SpeedPad")
		-- (2026-10-01) a key carrier gets only a share of it, a king key's carrier none (MoveGuard)
		local king = (player:GetAttribute("CarriedKing") or 0) > 0
		local carrying = (player:GetAttribute("CarriedKeys") or 0) > 0
		local share = king and Config.Keys.KingCarrierPadShare or carrying and Config.Keys.CarrierPadShare or 1
		local felt = 1 + (boost - 1) * share
		toast.Text = king and string.format("👑 왕 상자를 들어서 발판이 약해요 x%.1f", felt)
			or carrying and string.format("🎁 상자를 들어서 발판이 약해요 x%.1f", felt)
			or again and string.format("⚡ x%.1f 시간 연장!", boost) or string.format("⚡ 속도 x%.1f!", boost)
		toast.TextColor3 = Color3.fromRGB(80, 230, 255)
		toast.Visible = true
		toastUntil = os.clock() + TOAST_SECONDS
	end
end)
RunService.Heartbeat:Connect(FrameMeter.wrap("CombatFx", function(dt)
	local knocked = player:GetAttribute("KnockedOutAt")
	local stunnedUntil = player:GetAttribute("StunnedUntil")
	if knocked then
		local left = knocked + Players.RespawnTime - Workspace:GetServerTimeNow()
		Lang.set(center, string.format("⏱️ %d초 뒤 기지에서 다시 시작해요", math.max(0, math.ceil(left))))
	elseif stunnedUntil then -- groggy after a slap, or hit by a dropping: counting down
		local left = math.max(0, math.ceil(stunnedUntil - Workspace:GetServerTimeNow()))
		local reason = player:GetAttribute("StunReason")
		Lang.set(center, reason == "Poop" and string.format("💩 똥에 맞았어요! %d", left)
			or reason == "HideSeek" and string.format("🙈 눈 감고 기다려요… %d", left) -- (2026-10-03) the seeker's wait
			or reason == "Trap" and string.format("🕸️ 함정에 걸렸어요! %d", left) -- (2026-10-03) a hider's trap
			or string.format("💫 어질어질… %d", left))
	else
		Lang.set(center, "")
	end

	local carrying = player:GetAttribute("CarriedKeys") or 0
	Lang.set(carryLine, carrying > 0 and string.format("🔑 %d개 운반 중 → 🏠 집으로!", carrying) or "")
	carryLine.BackgroundTransparency = carrying > 0 and 0.35 or 1
	if carrying > 0 then
		dropButton.Position = UDim2.new(0.5, -carryLine.AbsoluteSize.X / 2 - DROP_GAP, 1, CARRY_TOP + CARRY_HEIGHT / 2)
	end

	sinceCheck += dt
	if sinceCheck >= CHECK_EVERY then
		sinceCheck = 0
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if root then
			-- danger only inside the battlefield flags (2026-10-04: and not up over it on a flying dino, only looking)
			local now = not SafeZones.isSafe(root.Position) and not SafeZones.inSky(player, root.Position)
			if inside ~= nil and now ~= inside then
				toast.Text = now and "위험 지역!" or "안전 지역"
				toast.TextColor3 = now and Color3.fromRGB(255, 120, 90) or Color3.fromRGB(120, 230, 140)
				toast.Visible = true
				toastUntil = os.clock() + TOAST_SECONDS
			end
			inside = now
			local ready = os.clock() - lastPress >= Config.Slap.Cooldown
			local mining = player:GetAttribute("Mining") == true or down()
			slapButton.BackgroundColor3 = ((now or nearOwnTrack(root.Position)) and ready and not mining) and COLOR_SLAP
				or COLOR_DIM
		end
	end
	if toast.Visible and os.clock() > toastUntil then
		toast.Visible = false
	end
end))

-- ---------------------------------------------------------------------------
-- Banners at the top (Net push Banner: key drops, better keys) and rainbow keys
-- ---------------------------------------------------------------------------

-- (2026-10-02, "자막도 어떻게 좀 해봐 화면 다 가리네 가독성은 잃지말고 … 왼쪽에 편성하든가 다른 알림들처럼")
-- the announcements go in the notice stack at the left middle (Shared/Notices), not across the middle of the
-- screen: their text in their color and a bit bigger, a thin outline in it
local Notices = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Notices"))

-- night and day banners (DayNight service) look like the weather's: big, in their color
local DAY_NIGHT_BANNERS = {
	Night = { Id = "Night", Rgb = { 170, 180, 255 } },
	Day = { Id = "Day", Rgb = { 255, 215, 110 } },
	Boss = { Id = "Boss", Rgb = { 205, 150, 255 } }, -- the night's boss zombie (Zombies service)
	KeySpawn = { Id = "KeySpawn", Rgb = { 255, 210, 70 } }, -- "열쇠가 생성되었습니다!" (Keys): big, like the weather's
}

local function showBanner(text, grade, slot)
	-- (2026-10-01) the weather countdown: one notice, its number changing ("3…", "2…", "1…"), a tick each
	if not slot and grade and (grade == "Clear" or Formulas.weather(grade).Id == grade) then
		Notices.hide("Banner:WeatherCountdown") -- (the weather itself: the countdown before it goes)
	end
	local keyType = Formulas.keyType(grade or "Normal")
	local weather = not keyType and grade and (DAY_NIGHT_BANNERS[grade] or Formulas.weather(grade)) -- a weather banner
		-- (Weather service) or night / day (DayNight service), styled the same
	if weather and weather.Rgb then
		keyType = weather -- styled like a special key: bigger, in the weather's color
	end
	local special = keyType ~= nil and grade ~= "Normal" and grade ~= "Clear"
	if slot then
		Sfx.play("CountTick")
	elseif weather and weather.Id == "RainbowSky" then
		Sfx.play("GachaBig") -- a bright shimmer, not thunder
	elseif weather and weather.Id == "KeySpawn" then
		Sfx.play("KeyDrop")
	elseif weather and weather.Rgb then
		Sfx.play("Weather")
	elseif special then
		Sfx.play("SpecialKey")
	else
		Sfx.play("KeyDrop")
	end
	local color = special and keyType.Rgb and Color3.fromRGB(table.unpack(keyType.Rgb)) or BANNER_COLOR
	Notices.show(nil, tostring(text), { color = color, big = special, key = slot and ("Banner:" .. slot) or nil,
		seconds = special and BANNER_SPECIAL_SECONDS or BANNER_SECONDS })
end
Net.onPush("Banner", showBanner)

-- rainbow keys and their beams cycle through the colors
local rainbowParts = {}
local function watchRainbow(inst)
	if inst:GetAttribute("Rainbow") then
		if inst:IsA("BasePart") then
			rainbowParts[inst] = true
		end
		for _, d in ipairs(inst:GetDescendants()) do
			if d:IsA("BasePart") then
				rainbowParts[d] = true
			end
		end
	end
end
task.spawn(function()
	local keysFolder = Workspace:WaitForChild("Keys")
	keysFolder.DescendantAdded:Connect(function(d)
		task.defer(watchRainbow, d)
	end)
	keysFolder.ChildAdded:Connect(function(key) -- keys falling or scattering: a sparkle where each lands
		task.defer(function()
			local camera = Workspace.CurrentCamera
			local at = key:IsA("BasePart") and key.Position or (key:IsA("Model") and key:GetPivot().Position)
			if at and camera and (at - camera.CFrame.Position).Magnitude < KEY_BURST_DISTANCE then
				Fx.burst(at, KEY_BURST_COLORS, 16, 10, 0.5, 0.7)
			end
		end)
	end)
	for _, d in ipairs(keysFolder:GetDescendants()) do
		watchRainbow(d)
	end
end)
local function watchCarried(character)
	character.ChildAdded:Connect(function(c)
		if c.Name == "CarryStack" then
			task.defer(function()
				for _, m in ipairs(c:GetChildren()) do
					watchRainbow(m)
				end
			end)
		end
	end)
end
local function watchCarrier(other)
	other.CharacterAdded:Connect(watchCarried)
	if other.Character then
		watchCarried(other.Character)
	end
end
Players.PlayerAdded:Connect(watchCarrier)
for _, other in ipairs(Players:GetPlayers()) do
	watchCarrier(other)
end
-- (2026-10-02, "혼자하는데 렉이 좀 있는거 같은데 최적화 해봐": every one recolored every frame) a slow cycle:
-- COLOR_STEP seconds between recolors
local colorSince = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("CombatFx", function(dt)
	colorSince += dt
	if colorSince < COLOR_STEP or not next(rainbowParts) then
		return
	end
	colorSince = 0
	local hue = (os.clock() / RAINBOW_CYCLE_SECONDS) % 1
	for part in pairs(rainbowParts) do
		if part.Parent then
			part.Color = Color3.fromHSV(hue, 0.6, 1)
		else
			rainbowParts[part] = nil
		end
	end
end))

-- ---------------------------------------------------------------------------
-- Carrying keys: the screen's edges glow gold (a flash when picked up, then a slow pulse) and a
-- banner says to take them home
-- ---------------------------------------------------------------------------

local edgeGui = Instance.new("ScreenGui")
edgeGui.Name = "CarryEdges"
edgeGui.ResetOnSpawn = false
edgeGui.IgnoreGuiInset = true
edgeGui.ScreenInsets = Enum.ScreenInsets.None -- to the very edges of the screen, past a phone's notch and rounded corners
edgeGui.DisplayOrder = 3
edgeGui.Parent = player:WaitForChild("PlayerGui")
local edges = {}
for _, side in ipairs({ { 0, 0, 1, 0, 90 }, { 0, 1, 1, 0, -90 }, { 0, 0, 0, 1, 0 }, { 1, 0, 0, 1, 180 } }) do
	local f = Instance.new("Frame")
	f.BorderSizePixel = 0
	f.BackgroundColor3 = EDGE_COLOR
	f.AnchorPoint = Vector2.new(side[1], side[2])
	f.Position = UDim2.fromScale(side[1], side[2])
	f.Size = side[3] == 1 and UDim2.new(1, 0, 0, EDGE_WIDTH) or UDim2.new(0, EDGE_WIDTH, 1, 0)
	local fade = Instance.new("UIGradient")
	fade.Rotation = side[5]
	fade.Transparency = NumberSequence.new(0, 1) -- solid at the screen's edge, fading inward
	fade.Parent = f
	f.BackgroundTransparency = 1
	f.Parent = edgeGui
	table.insert(edges, f)
end

remindCarry = function()
	showBanner("🎁 선물상자를 집으로 가져가요! 🏠", "Gold")
	for _, f in ipairs(edges) do
		f.BackgroundTransparency = 0
		TweenService:Create(f, TweenInfo.new(EDGE_FLASH_SECONDS), { BackgroundTransparency = EDGE_PULSE_MIN }):Play()
	end
end

RunService.Heartbeat:Connect(FrameMeter.wrap("CombatFx", function()
	local carrying = (player:GetAttribute("CarriedKeys") or 0) > 0
	for _, f in ipairs(edges) do
		if not carrying then
			f.BackgroundTransparency = 1
		elseif f.BackgroundTransparency >= EDGE_PULSE_MIN - 0.01 then -- after the flash: a slow pulse
			local wave = (math.sin(os.clock() * EDGE_PULSE_SPEED) + 1) / 2
			f.BackgroundTransparency = EDGE_PULSE_MIN + (EDGE_PULSE_MAX - EDGE_PULSE_MIN) * wave
		end
	end
end))

-- ---------------------------------------------------------------------------
-- Groggy: stars circling the head (2026-10-03)
-- ---------------------------------------------------------------------------

local dizzy = {} -- [player] = { gui, stars = { TextLabel } }

local function groggy(other)
	return other:GetAttribute("StunReason") == "Groggy" and (other:GetAttribute("StunnedUntil") or 0) > Workspace:GetServerTimeNow()
end

local function dizzyOn(other)
	local head = other.Character and other.Character:FindFirstChild("Head")
	if not head then
		return
	end
	local b = Instance.new("BillboardGui")
	b.Name = "DizzyStars"
	b.Size = DIZZY_SIZE
	b.StudsOffsetWorldSpace = Vector3.new(0, DIZZY_UP, 0)
	b.LightInfluence = 0
	local stars = {}
	for _, text in ipairs(DIZZY_STARS) do
		local l = label(b, text, UDim2.fromOffset(DIZZY_TEXT + 6, DIZZY_TEXT + 6), UDim2.new(), DIZZY_TEXT)
		l.AnchorPoint = Vector2.new(0.5, 0.5)
		table.insert(stars, l)
	end
	b.Parent = head
	dizzy[other] = { gui = b, stars = stars }
end

local function dizzyOff(other)
	local d = dizzy[other]
	if d then
		d.gui:Destroy()
		dizzy[other] = nil
	end
end

task.spawn(function()
	while true do
		task.wait(DIZZY_CHECK)
		for _, other in ipairs(Players:GetPlayers()) do
			local d = dizzy[other]
			local now = groggy(other)
			if now and (not d or not d.gui.Parent) then
				dizzyOff(other)
				dizzyOn(other)
			elseif not now and d then
				dizzyOff(other)
			end
		end
		for other in pairs(dizzy) do
			if not other.Parent then
				dizzyOff(other)
			end
		end
	end
end)

RunService.RenderStepped:Connect(FrameMeter.wrap("CombatFx", function()
	if next(dizzy) == nil then
		return
	end
	local a0 = os.clock() * DIZZY_TURN
	for _, d in pairs(dizzy) do
		for i, l in ipairs(d.stars) do
			local a = a0 + (i - 1) * 2 * math.pi / #d.stars
			l.Position = UDim2.fromScale(0.5 + math.cos(a) * DIZZY_RX, 0.5 + math.sin(a) * DIZZY_RY)
			l.ZIndex = math.sin(a) > 0 and 2 or 1 -- (the front half over the back)
		end
	end
end))

local fossilPop = Instance.new("BillboardGui")
fossilPop.Name = "FossilSlapPop"
fossilPop.Size = FOSSIL_POP_SIZE
fossilPop.AlwaysOnTop = true
fossilPop.Enabled = false
fossilPop.Parent = player:WaitForChild("PlayerGui")
local fossilPopText = Instance.new("TextLabel")
fossilPopText.Size = UDim2.fromScale(1, 1)
fossilPopText.BackgroundTransparency = 1
fossilPopText.Font = Enum.Font.GothamBlack
fossilPopText.TextScaled = true
fossilPopText.TextStrokeTransparency = 0.2
fossilPopText.Parent = fossilPop
local fossilPopGrow = Instance.new("UIScale")
fossilPopGrow.Parent = fossilPopText
local fossilPopToken = 0

Net.onPush("FossilSlap", function(n)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	n = tonumber(n) or 0
	if not root or n <= 0 then
		return
	end
	fossilPopToken += 1
	local token = fossilPopToken
	fossilPopText.Text = string.format("👋 ×%d", n)
	fossilPopText.TextColor3 = n > 1 and FOSSIL_POP_MANY_COLOR or FOSSIL_POP_COLOR
	fossilPopText.TextTransparency, fossilPopText.TextStrokeTransparency = 0, 0.2
	fossilPop.Adornee = root
	fossilPop.StudsOffsetWorldSpace = FOSSIL_POP_FROM
	fossilPopGrow.Scale = 0.5 + 0.15 * math.min(n, 5)
	fossilPop.Enabled = true
	TweenService:Create(fossilPopGrow, TweenInfo.new(FOSSIL_POP_GROW_SECONDS, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
		{ Scale = 1 + 0.1 * math.min(n - 1, 4) }):Play()
	TweenService:Create(fossilPop, TweenInfo.new(FOSSIL_POP_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{ StudsOffsetWorldSpace = FOSSIL_POP_FROM + Vector3.new(0, FOSSIL_POP_RISE, 0) }):Play()
	TweenService:Create(fossilPopText, TweenInfo.new(FOSSIL_POP_SECONDS / 2, Enum.EasingStyle.Quad, Enum.EasingDirection.In,
		0, false, FOSSIL_POP_SECONDS / 2), { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
	task.delay(FOSSIL_POP_SECONDS, function()
		if fossilPopToken == token then
			fossilPop.Enabled = false
		end
	end)
end)
