--[[
RebirthFx: the show when a player is reborn (Net push RebirthFx from the Shop service). Their own
screen lifts their character up, spins it round faster and faster and sets it down again (the server
lets the move be, MoveGuard.allow); everyone sees that move. Every screen adds sparkles swirling round
the body in the tier's color and, on landing, a burst and a ring along the ground; the sound "Rebirth"
(Shared/Sfx) follows the same beats: up 1 s, spin 1.6 s, down 0.7 s, landing. Display only.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local ShareMoment = require(Shared:WaitForChild("ShareMoment"))

local player = Players.LocalPlayer

-- display only
local RISE_SECONDS, SPIN_SECONDS, FALL_SECONDS = 1.0, 1.6, 0.7 -- (the sound "Rebirth" is cut to these)
local SHARE_AFTER = 0.6
local RISE_STUDS = 10
local SPIN_TURNS = 3 -- turns while up, faster and faster
local BOB_STUDS = 0.6 -- a little up-and-down while spinning
local SWIRL_RADIUS = 3.2
local SWIRL_SPARKS = 8 -- sparkles going round the body
local LAND_RING_SIZE = 28 -- studs across the ring on the ground at its widest
local LAND_RING_SECONDS = 0.8
local TIER_COLORS = { -- one a tier (RebirthLook's): rebirths 1, 2, ...; the last one repeats
	Color3.fromRGB(80, 220, 110),
	Color3.fromRGB(70, 150, 255),
	Color3.fromRGB(185, 95, 255),
	Color3.fromRGB(255, 150, 40),
	Color3.fromRGB(255, 70, 70),
	Color3.fromRGB(255, 210, 60),
}

local function tierColor(rebirths) -- (as RebirthLook: one color a rebirth, the last one repeats)
	return TIER_COLORS[math.clamp(rebirths, 1, #TIER_COLORS)]
end

local function part(props)
	local p = Instance.new("Part")
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
	p.Material = Enum.Material.Neon
	for k, v in pairs(props) do
		p[k] = v
	end
	p.Parent = Workspace
	return p
end

local function ease(k) -- slow in, slow out
	return k * k * (3 - 2 * k)
end

-- my own character: up, round and down (PlatformStand so the humanoid doesn't fight it)
local busy = false
local function liftAndSpin()
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = humanoid and humanoid.RootPart
	if busy or not root then
		return
	end
	busy = true
	local start = root.CFrame
	local base = CFrame.new(start.Position) * (start - start.Position)
	humanoid.PlatformStand = true
	local t0 = os.clock()
	local total = RISE_SECONDS + SPIN_SECONDS + FALL_SECONDS
	local conn
	conn = RunService.RenderStepped:Connect(FrameMeter.wrap("RebirthFx", function()
		local t = os.clock() - t0
		if not root.Parent then
			conn:Disconnect()
			busy = false
			return
		end
		local height, angle = 0, 0
		if t < RISE_SECONDS then
			height = RISE_STUDS * ease(t / RISE_SECONDS)
			angle = 0.5 * math.pi * (t / RISE_SECONDS) ^ 2 -- starts turning on the way up
		elseif t < RISE_SECONDS + SPIN_SECONDS then
			local k = (t - RISE_SECONDS) / SPIN_SECONDS
			height = RISE_STUDS + BOB_STUDS * math.sin(k * math.pi * 4)
			angle = 0.5 * math.pi + SPIN_TURNS * 2 * math.pi * k * k -- faster and faster
		elseif t < total then
			local k = (t - RISE_SECONDS - SPIN_SECONDS) / FALL_SECONDS
			height = RISE_STUDS * (1 - ease(k))
			angle = (0.5 + SPIN_TURNS * 2) * math.pi + 1.5 * math.pi * ease(k) -- slows to face the front again
		else
			conn:Disconnect()
			root.CFrame = base
			root.AssemblyLinearVelocity = Vector3.zero
			humanoid.PlatformStand = false
			busy = false
			return
		end
		root.CFrame = base * CFrame.new(0, height, 0) * CFrame.Angles(0, angle, 0)
		root.AssemblyLinearVelocity = Vector3.zero
		root.AssemblyAngularVelocity = Vector3.zero
	end))
end

-- every screen: sparkles round the body while it goes up and spins, a burst and a ground ring on landing
local function sparkles(who, color)
	local character = who.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end
	local sparks = {}
	for i = 1, SWIRL_SPARKS do
		sparks[i] = part({ Name = "RebirthSpark", Shape = Enum.PartType.Ball, Size = Vector3.one * 0.6, Color = color,
			Transparency = 0.2 })
	end
	local light = Instance.new("PointLight")
	light.Color, light.Range, light.Brightness = color, 14, 3
	light.Parent = sparks[1]
	local t0 = os.clock()
	local conn
	conn = RunService.RenderStepped:Connect(FrameMeter.wrap("RebirthFx", function()
		local t = os.clock() - t0
		if t > RISE_SECONDS + SPIN_SECONDS or not root.Parent then
			conn:Disconnect()
			for _, s in ipairs(sparks) do
				s:Destroy()
			end
			return
		end
		for i, s in ipairs(sparks) do
			local a = t * (4 + 6 * t / (RISE_SECONDS + SPIN_SECONDS)) + i / #sparks * 2 * math.pi
			local h = math.sin(t * 3 + i) * 2
			s.CFrame = CFrame.new(root.Position + Vector3.new(math.cos(a) * SWIRL_RADIUS, h, math.sin(a) * SWIRL_RADIUS))
		end
	end))
	task.delay(RISE_SECONDS + SPIN_SECONDS + FALL_SECONDS, function()
		if not root.Parent then
			return
		end
		local feet = root.Position - Vector3.new(0, 3, 0)
		local ring = part({ Name = "RebirthRing", Shape = Enum.PartType.Cylinder, Size = Vector3.new(0.2, 2, 2),
			CFrame = CFrame.new(feet) * CFrame.Angles(0, 0, math.pi / 2), Color = color, Transparency = 0.2 })
		TweenService:Create(ring, TweenInfo.new(LAND_RING_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
			{ Size = Vector3.new(0.2, LAND_RING_SIZE, LAND_RING_SIZE), Transparency = 1 }):Play()
		local burst = Instance.new("ParticleEmitter")
		burst.Color = ColorSequence.new(color, Color3.new(1, 1, 1))
		burst.LightEmission = 1
		burst.Size = NumberSequence.new(0.8, 0)
		burst.Speed = NumberRange.new(14, 24)
		burst.Lifetime = NumberRange.new(0.6, 1.1)
		burst.SpreadAngle = Vector2.new(180, 180)
		burst.Rate = 0
		burst.Parent = ring
		burst:Emit(60)
		task.delay(1.5, function()
			ring:Destroy()
		end)
	end)
end

Net.onPush("RebirthFx", function(userId, rebirths)
	local who = Players:GetPlayerByUserId(userId)
	if not who then
		return
	end
	local root = who.Character and who.Character:FindFirstChild("HumanoidRootPart")
	-- my own in my ears; another's from where they are
	Sfx.play("Rebirth", userId ~= player.UserId and root and root.Position or nil)
	sparkles(who, tierColor(rebirths or 1))
	if who == player then
		liftAndSpin()
		task.delay(RISE_SECONDS + SPIN_SECONDS + FALL_SECONDS + SHARE_AFTER, ShareMoment.offer, "Rebirth", "📸 환생 자랑하기")
	end
end)
