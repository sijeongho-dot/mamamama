--[[
TutorialAsk (2026-10-04, "처음에 언어 선택하고 튜토리얼 할지말지 누르는 창도 띄워주자. 네 아니요 하나 누르면 정말요? 라면서
한 번 더 체크해주고. 아니요 누르면 설정에서 나중에 다시 가능하다는등 하면 보상이 있다는 등 붙여주고"): right after the
first join's language pick, while the player attribute TutorialAsk is set (the Tutorial service), a window asks whether to
play the tutorial with Coco: ✅ 네 / ❌ 아니요. (2026-10-04, "D도 해줘") 네 starts it at once; 아니요 asks "정말요?" once
more before it counts (the sureYes page below is no longer reached):
- yes: Coco teaches one thing at a time, it can be skipped on the way; ✅ 네, 시작! sends it, ↩️ 뒤로 goes back.
- no: it can be played any time later from ⚙️ 설정 → 📖 코코에게 배우기, and playing it to the end then still pays the
  tutorial's reward (Config.Tutorial.Field); ✅ 할래요 sends yes after all, ❌ 네, 안 할래요 sends no.
Net request TutorialChoice(yes). Korean words, translated as they show (StarterPlayerScripts/Translate).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local PANEL_SIZE = UDim2.fromOffset(340, 300)
local TITLE_HEIGHT = 40
local LINE_HEIGHT = 34
local LINE_GAP = 6
local BUTTON_HEIGHT = 52
local EDGE = 16
local COLOR_DIM = Color3.fromRGB(0, 0, 0)
local DIM_TRANSPARENCY = 0.35
local COLOR_BG = Color3.fromRGB(30, 34, 50)
local COLOR_TITLE = Color3.fromRGB(255, 225, 120)
local COLOR_LINE = Color3.fromRGB(230, 232, 240)
local COLOR_REWARD = Color3.fromRGB(150, 255, 170)
local COLOR_YES = Color3.fromRGB(70, 180, 100)
local COLOR_NO = Color3.fromRGB(120, 124, 140)
local COLOR_STROKE = Color3.fromRGB(255, 200, 90)

-- the reward line (the welcome-back card's words: Tutorial.client)
local function rewardLine()
	local f = Config.Tutorial.Field
	return string.format("🎁 튜토리얼 완료 보상: %s · 🍀 행운 %d분", Formulas.rewardShortText(f.Reward), f.RewardLuckMinutes)
end

-- each page: title, lines (REWARD: the reward line), left button { words, send (true / false) or a page }, right one
local PAGES = {
	ask = { "🐣 코코랑 튜토리얼 할까요?", { "⛏️ 캐기 · 🦖 공룡 · 🔑 열쇠를 약 5분 만에 배워요", "REWARD" },
		-- (2026-10-04, "D도 해줘": yes starts at once; only no asks "정말요?" again)
		{ "✅ 네, 할래요", true }, { "❌ 아니요", "sureNo" } },
	sureYes = { "정말요? 🐣", { "🐣 코코가 하나씩 알려 줘요", "중간에 ⏩ 건너뛰기도 할 수 있어요" },
		{ "✅ 네, 시작!", true }, { "↩️ 뒤로", "ask" } },
	sureNo = { "정말요? 😢", { "⚙️ 설정 → 📖 코코에게 배우기에서 언제든 다시 할 수 있어요", "🎁 그때 끝까지 하면 보상도 받아요!",
		"REWARD" }, { "✅ 할래요", true }, { "❌ 네, 안 할래요", false } },
}

local gui = Instance.new("ScreenGui")
gui.Name = "TutorialAsk"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.DisplayOrder = 30 -- (over everything, as the language pick before it)
gui.Enabled = false
gui.Parent = player:WaitForChild("PlayerGui")

local dim = Instance.new("Frame")
dim.Size = UDim2.fromScale(1, 1)
dim.BackgroundColor3 = COLOR_DIM
dim.BackgroundTransparency = DIM_TRANSPARENCY
dim.Active = true
dim.Parent = gui

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(0.5, 0.5)
panel.Position = UDim2.fromScale(0.5, 0.5)
panel.Size = UDim2.new(0.9, 0, 0.9, 0)
panel.BackgroundColor3 = COLOR_BG
panel.Parent = dim
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 16)
	round.Parent = panel
	local stroke = Instance.new("UIStroke")
	stroke.Color = COLOR_STROKE
	stroke.Thickness = 3
	stroke.Parent = panel
	local scale = Instance.new("UIAspectRatioConstraint") -- (keeps its shape when a small screen squeezes it)
	scale.AspectRatio = PANEL_SIZE.X.Offset / PANEL_SIZE.Y.Offset
	scale.Parent = panel
	local limit = Instance.new("UISizeConstraint")
	limit.MaxSize = Vector2.new(PANEL_SIZE.X.Offset, PANEL_SIZE.Y.Offset)
	limit.Parent = panel
end

local function label(height, color)
	local t = Instance.new("TextLabel")
	t.BackgroundTransparency = 1
	t.Font = FONT
	t.TextScaled = true
	t.TextWrapped = true
	t.TextColor3 = color
	t.Size = UDim2.new(1, -EDGE * 2, 0, height)
	t.Parent = panel
	return t
end

local title = label(TITLE_HEIGHT, COLOR_TITLE)
title.Position = UDim2.fromOffset(EDGE, 14)
local lines = {}
for i = 1, 3 do
	local t = label(LINE_HEIGHT, COLOR_LINE)
	t.Position = UDim2.fromOffset(EDGE, 14 + TITLE_HEIGHT + 10 + (i - 1) * (LINE_HEIGHT + LINE_GAP))
	lines[i] = t
end

local function button(x, color)
	local b = Instance.new("TextButton")
	b.AnchorPoint = Vector2.new(0, 1)
	b.Size = UDim2.new(0.5, -EDGE - 5, 0, BUTTON_HEIGHT)
	b.Position = UDim2.new(x, x == 0 and EDGE or 5, 1, -EDGE)
	b.BackgroundColor3 = color
	b.Font = FONT
	b.TextScaled = true
	b.TextColor3 = Color3.new(1, 1, 1)
	b.Parent = panel
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 12)
	round.Parent = b
	local pad = Instance.new("UIPadding")
	pad.PaddingTop, pad.PaddingBottom = UDim.new(0, 10), UDim.new(0, 10)
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, 8), UDim.new(0, 8)
	pad.Parent = b
	return b
end
local left = button(0, COLOR_YES)
local right = button(0.5, COLOR_NO)

local page = nil
local function show(name)
	page = PAGES[name]
	title.Text = page[1]
	for i, t in ipairs(lines) do
		local words = page[2][i]
		t.Visible = words ~= nil
		t.Text = words == "REWARD" and rewardLine() or words or ""
		t.TextColor3 = words == "REWARD" and COLOR_REWARD or COLOR_LINE
	end
	left.Text = page[3][1]
	right.Text = page[4][1]
end

local function press(choice)
	if type(choice) == "string" then
		show(choice)
	else
		Net.request("TutorialChoice", choice)
		gui.Enabled = false
	end
end
left.Activated:Connect(function()
	press(page[3][2])
end)
right.Activated:Connect(function()
	press(page[4][2])
end)

local function refresh()
	local asking = player:GetAttribute("TutorialAsk") == true
	if asking and not gui.Enabled then
		show("ask")
	end
	gui.Enabled = asking
end
player:GetAttributeChangedSignal("TutorialAsk"):Connect(refresh)
refresh()
