--[[
AutoMine: the ⛏️ auto mining pass (Config.GamePasses.AutoMine), 2026-10-02: "자동채굴 결제한건 알아서 가장
최적의 동선에 있고 가장 자원 효율이 좋게 뽑히는 자원에 자동으로 달려가서 캐는 메커니즘을 적용하고, 꽉차면 판매까지
알아서 하게 해", "기능 키고 끌수 있게". (It was: standing next to a mineral started the nearest one.)

While the pass is owned (player attribute PassAutoMine) and switched on (setting AutoMineOff, the "⛏️ 자동"
button in the right column; Settings), this player's own character:
- picks the mineral worth the most money a second: what it would put in the bag (its turns left, up to the
  room in the bag) × its worth, over the walk there (straight distance ÷ walk speed × PATH_FACTOR) plus the
  turns it takes (Formulas.mineSeconds with this pickaxe). Minerals skipped are left out;
- walks there (PathfindingService around rocks and trees, straight on when no path is found) and asks to
  mine it (Net Mine, the same request as a tap; the server checks reach, the bag and every turn);
- (2026-10-02, "탈것 상태에서 못쓰게 할까") never while riding: the button reads "🦖 자동 쉼" and it goes on after;
- when the bag is full, walks home to its own deposit bin and empties it (Net AutoDeposit), then goes on.
Zombies (2026-10-02, "자동채굴때 좀비등이랑 만나면 어떻게 할지"): it never fights for the player. Minerals with
a zombie that is up and not dizzy within ZombieAvoid studs (a boss: BossAvoid; Workspace.Zombies) are left
out; when one comes within ZombieFlee (BossFlee) it stops mining and walks away from it (zombies chase more
slowly than a player walks), home to empty the bag if there is anything in it; with no safe mineral left it
waits at home. Thrown or dizzy (Humanoid.PlatformStand: a slap, a zombie's hit) it waits until up again.
Keys in hand (attribute CarriedKeys, picked up at the altar): it stops mining and takes them home first (they
only count inside the base; Keys service), selling the bag there too.
Moving by hand (keys or thumbstick; 2026-10-02, "내가 조작시작하면 자동으로 오토꺼지게 … 움직임조작, 다른 상호작용들
제외": was a 4-second pause) switches it off, with a notice; taps on buttons and windows don't. It waits while the
player rides, is in the tutorial or a hide-and-seek game, or has no base. A mineral the player stopped by hand, or one it could not reach,
is skipped for SkipSeconds. Everything it does is a request the server checks as if the player did it.
(2026-10-02, "오토 광질 광물 앞에서 멈추는 버그 … 다른 광물에 서서 안움직임", "자동이 광물 내려놓기도 빨리 못하네")
Distances are measured as the server measures them: a mineral from its bounding box's middle (was its pivot,
so it stopped "in reach" where the server said too far, skipped it and stood at the next one), the deposit bin
in 3D (Bases.near; was flat, so a tall bin's middle was out of the server's reach and home was skipped for
SkipSeconds with a full bag).
Fruit: in the safe
land and the bases only (no slapping on the battlefield), it walks to a fruit tree it has not shaken for a while,
slaps it (Net Slap, as the slap button) and walks over the fruit that fell (the Trees script picks it up; 2026-10-05:
it is food at once, so it never goes home for it - the trip home with FRUIT_HOME_AT carried fruits is for fruit carried
from before). With both on, it mines and takes fruit on the way: fruit or a ready tree within FRUIT_NEAR studs first.
(2026-10-05, "유료 오토는 광질만 가능하고 과일 채집 오토는 기본으로 가능하게 하자 … 광질은 안 사면 어차피 안 열려있으니까 키면 과일
채집 모드만 뜨는겨", "과일 채집은 공룡타고도 되고 지상공룡만") the pass is for the minerals only: everyone has the button. Fruit goes on while riding a
land dino (minerals wait till getting off; a flying one: all of it waits).
]]

local Players = game:GetService("Players")
local PathfindingService = game:GetService("PathfindingService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Unlock = require(Shared:WaitForChild("Unlock"))
local Net = require(Shared:WaitForChild("Net"))
local Notices = require(Shared:WaitForChild("Notices"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local SideButtons = require(Shared:WaitForChild("SideButtons"))
local WorldWatch = require(Shared:WaitForChild("WorldWatch"))

local player = Players.LocalPlayer
local A = Config.GamePasses.AutoMine

-- display only
local BUTTON_SIZE = UDim2.fromOffset(68, 36)
local BUTTON_POS = UDim2.new(1, -12 - 2 * (68 + 10), 0, 86) -- a third column, left of 인벤토리 (Inventory); its middle
-- (not under 기지로: on short phones 타기 over the jump button rises there, Ride)
local COLOR_ON = Color3.fromRGB(80, 170, 90)
local COLOR_OFF = Color3.fromRGB(110, 110, 120)
local MODES = {
	{ AutoMineOff = true },
	{ AutoMineOff = false, AutoNoMinerals = false, AutoFruit = false },
	{ AutoMineOff = false, AutoNoMinerals = true, AutoFruit = true },
	{ AutoMineOff = false, AutoNoMinerals = false, AutoFruit = true },
}
local MODE_SETTINGS = { "AutoMineOff", "AutoNoMinerals", "AutoFruit" }
local FRUIT_TEXTS = { "🍎 자동 OFF", "🍎 자동 열매" }
local MINE_TEXTS = { "⛏️ 자동 OFF", "⛏️ 자동 광물" }
local TEXT_RIDING = "🦖 자동 쉼"
local MINE_BUTTON_GAP = 4
local COLOR_RESTING = Color3.fromRGB(190, 140, 60)
local FRUIT_NEAR = 45 -- studs: with both on, fruit or a ready tree this close comes before the next mineral
local FRUIT_HOME_AT = 25 -- carried fruits: home with them
local TREE_AGAIN = 6 -- seconds before it slaps the same tree again (the server: Fruit.TreeCooldown)
local FRUIT_FALL_WAIT = 0.9 -- seconds after a slap for the fruit to land
local TREE_RESCAN = 30 -- seconds between looks through the map for the fruit trees
local TREE_EMPTY_RESCAN = 2
local WILD_SPOT_NEAR = 24
local TREE_REACH_GAP = 2 -- studs inside the slap's reach it stops at, from the trunk
local TREE_GIVE_UP = 12 -- seconds of trying to get to a tree before another one
-- (2026-10-03, "자동열매 채취도중 나무위에 올라가서 안 움직이는 버그") fruit can land on a branch's collider up in the
-- tree: measured flat it was "reached" at once, never picked up, and it stood there for good (a stuck hop could
-- also put it up on the tree). Fruit higher than FRUIT_TOO_HIGH over my feet is left alone, fruit still there
-- FRUIT_PICK_WAIT after reaching it is skipped for SkipSeconds, and up on a tree it first walks off it
local FRUIT_TOO_HIGH = 4 -- studs over the ground under me
local FRUIT_PICK_WAIT = 0.6
local WILD_TREE_SEARCH = 60
local OFF_TREE_STUDS = 10 -- studs out past the tree's own half width when getting down from it
local OFF_TREE_SECONDS = 1.5
local HIP_GUESS = 2 -- studs from the root's bottom to the feet (Roblox's usual hip height)
local TREE_NO_HOP = 7 -- studs from a tree's trunk: a stuck walk doesn't hop there (a hop puts it up the tree)
local LOOP_ERROR_EVERY = 60 -- seconds between two reports of an error in the loop (it goes on)
local TREE_KINDS = { Tree = true, Prop_Tree_Round = true, Prop_Tree_Pine = true, Prop_Tree_Palm = true } -- (Fruits service)
local RESEND_SECONDS = 2 -- an on/off not answered by the server yet is asked again this often
local HAND_MOVE_GRACE = 0.6 -- seconds after the auto's last MoveTo before the character's heading counts as the player's
-- (2026-10-05, "자동 열매도 움직이면 멈춰야지": the walk sent its MoveTo again every 0.1 s, so the look below - waiting
-- HAND_MOVE_GRACE / 2 after the last one - never came while walking, and the fruit auto walks nearly all the time) the
-- walk now sends it again only every MOVE_RESEND seconds; the heading is looked at OFF_COURSE_GRACE after each new one,
-- and off the auto's way by more than HAND_OFF_COURSE for OFF_COURSE_FRAMES frames in a row is the player
local HAND_OFF_COURSE = 0.8 -- walking: heading no nearer the auto's way than this (cos, about 37°) is the player's
local OFF_COURSE_GRACE = 0.15 -- seconds after the auto's MoveTo
local OFF_COURSE_FRAMES = 3
local MOVE_RESEND = 5 -- seconds: a MoveTo to the same spot again (Roblox drops one after 8)

-- walking (how the character moves, not a game rule)
local PATH_FACTOR = 1.3 -- a walk is about this much longer than the straight line
-- (2026-10-04, "광질 오토는 제일 효율좋은거를 캐는것도 맞지만 효율에 거리도 포함돼. 거리가 너무 멀어서 가까이 있는걸 캐는게
-- 낫겠다 싶으면 가까이 있는걸 캐야지") the way there counts WALK_WEIGHT times (zombies to go round, bumps, the way back
-- to it after a deposit), plus TRIP_SECONDS a trip; and of the minerals within NEAR_ENOUGH of the best one's money a
-- second, the nearest is taken
local WALK_WEIGHT = 2
local TRIP_SECONDS = 2
local NEAR_ENOUGH = 0.75
local ARRIVE_GAP = 2 -- studs inside Config.Mining.Range (or Config.Deposit.Range) before asking
local WAYPOINT_REACHED = 3 -- studs: close enough to a path point to go to the next
-- (2026-10-03, "돌에 걸리면 꽤 오래 앞에서 머물렀다 움직이네": was 2.5 s, then the same path again until GiveUpSeconds)
local STUCK_SECONDS = 1.2 -- not this much nearer in this long: jump, then find the path again
local STUCK_STUDS = 1.5
local SIDESTEP_STUDS = 6 -- stuck again: a step to the side (each time the other side), then a new path
local SIDESTEP_SECONDS = 0.8
local STUCK_LIMIT = 4 -- stuck this many times with no real way nearer: another target
local PROGRESS_STUDS = 8 -- this much nearer the target counts as getting somewhere (the stuck count starts over)
local TELEPORT_JUMP = 25 -- studs moved in one look: a teleport (기지로), so the old path is dropped
local REPATH_SECONDS = 4 -- the target may move (a full bag goes home): the path is found again this often
local DEPOSIT_WAIT = 3 -- seconds to wait for the bag to empty after asking
-- (2026-10-04, "왜 오토 가방 가득차고 입금소에서 입금을 안 하냐", "개 느리게 하네 입금": a failed walk home left home
-- skipped for SkipSeconds (30 s standing with a full bag), and it walked the whole way) a bag full this far from the
-- bin: the 기지로 teleport first (as the button: Net TeleportHome, not with keys, its cooldown kept here); a walk home
-- that fails is tried again HOME_RETRY seconds later
local TELEPORT_HOME_FAR = 60 -- studs
local HOME_RETRY = 3
local TELEPORT_WAIT = 6 -- seconds at most it waits for the teleport to happen
local AGENT = { AgentRadius = 2.5, AgentHeight = 5, AgentCanJump = true, WaypointSpacing = 6 }

-- ---------------------------------------------------------------------------
-- The on / off button
-- ---------------------------------------------------------------------------

local gui = Instance.new("ScreenGui")
gui.Name = "AutoMine"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local function makeButton(name, position)
	local b = Instance.new("TextButton")
	b.Name = name
	b.AnchorPoint = Vector2.new(1, 0.5)
	b.Size = BUTTON_SIZE
	b.Position = position
	b.Font = Enum.Font.GothamBold
	b.TextSize = 12
	b.TextColor3 = Color3.new(1, 1, 1)
	b.Visible = false
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 10)
	c.Parent = b
	b.Parent = gui
	SideButtons.register(b)
	return b
end

local fruitButton = makeButton("AutoFruitToggle", BUTTON_POS)
local mineButton = makeButton("AutoMineToggle", BUTTON_POS + UDim2.fromOffset(-(BUTTON_SIZE.X.Offset + MINE_BUTTON_GAP), 0))

local function owned()
	return player:GetAttribute("PassAutoMine") == true
end
-- (2026-10-02, "오토를 켰다가 움직이면 꺼지긴 하는데 오토 오프로는 스위치가 안 되네 버튼이": the button waited for
-- the server's answer and was never redrawn when switching off by hand; an answer lost or late left it on
-- "ON" for good) what this screen asked for, shown at once, until the server's attribute says the same;
-- asked again every RESEND_SECONDS meanwhile
local want = nil -- the mode asked for and not answered yet

-- does the server's copy (the attributes) match this mode?
local function matches(mode)
	for _, name in ipairs(MODE_SETTINGS) do
		if mode[name] ~= nil and (player:GetAttribute(name) == true) ~= mode[name] then
			return false
		end
	end
	return true
end

local function setting(name)
	if want and want[name] ~= nil then
		return want[name]
	end
	return player:GetAttribute(name) == true
end

local function fruitOpen()
	return ReplicatedStorage:GetAttribute("TutorialField") ~= nil or player:GetAttribute("OpenArea") == nil
		or player:GetAttribute("WildSpot") ~= nil
end

local function on() -- (without the pass: only the fruit)
	return not setting("AutoMineOff") and (owned() or (setting("AutoFruit") and fruitOpen()))
end

local function minesOn() -- minerals in the mode (the pass's)
	return on() and owned() and not setting("AutoNoMinerals")
end

local function fruitOn() -- fruit in the mode
	return on() and setting("AutoFruit") and fruitOpen()
end

local function modeFor(mines, fruit)
	if mines and fruit then
		return MODES[4]
	elseif mines then
		return MODES[2]
	elseif fruit then
		return MODES[3]
	end
	return MODES[1]
end

-- riding: all of it waits on a flying dino or with no fruit in the mode; on a land dino the fruit goes on (2026-10-05)
local function restingOnMount()
	return player:GetAttribute("Riding") == true and (player:GetAttribute("Flying") == true or not fruitOn())
end

local function paint(b, isOn, resting, texts)
	b.Text = resting and TEXT_RIDING or texts[isOn and 2 or 1]
	b.BackgroundColor3 = resting and COLOR_RESTING or isOn and COLOR_ON or COLOR_OFF
end

local function refreshButton()
	local shown = not player:GetAttribute("TutorialStep")
	local riding = player:GetAttribute("Riding") == true
	fruitButton.Visible = shown and fruitOpen()
	mineButton.Visible = shown and owned()
	paint(fruitButton, fruitOn(), fruitOn() and riding and player:GetAttribute("Flying") == true, FRUIT_TEXTS)
	paint(mineButton, minesOn(), minesOn() and riding, MINE_TEXTS)
end

local function send(mode)
	for _, name in ipairs(MODE_SETTINGS) do
		if mode[name] ~= nil then
			Net.request("SetSetting", name, mode[name]) -- (the server mirrors each back as the attribute)
		end
	end
end

local function setMode(mode)
	want = mode
	refreshButton()
	send(mode)
end

local function switch(off) -- (off: moved by hand)
	setMode(off and MODES[1] or MODES[2])
end

refreshButton()
player:GetAttributeChangedSignal("PassAutoMine"):Connect(refreshButton)
for _, name in ipairs(MODE_SETTINGS) do
	player:GetAttributeChangedSignal(name):Connect(function()
		if want and matches(want) then
			want = nil
		end
		refreshButton()
	end)
end
player:GetAttributeChangedSignal("TutorialStep"):Connect(refreshButton)
player:GetAttributeChangedSignal("OpenArea"):Connect(refreshButton)
player:GetAttributeChangedSignal("WildSpot"):Connect(refreshButton)
player:GetAttributeChangedSignal("Riding"):Connect(function()
	refreshButton()
	if on() and player:GetAttribute("Riding") then
		task.defer(function() -- (Flying is set with it)
			if restingOnMount() then
				Notices.show(nil, "🦖 공룡을 타는 동안은 자동이 쉬어요. 내리면 다시 해요")
			elseif minesOn() then
				Notices.show(nil, "🦖 타는 동안은 🍎 열매만 따요. ⛏️ 광물은 내리면 다시 캐요")
			end
		end)
	end
end)
player:GetAttributeChangedSignal("Flying"):Connect(refreshButton)
fruitButton.Activated:Connect(function()
	setMode(modeFor(minesOn(), not fruitOn()))
end)
mineButton.Activated:Connect(function()
	setMode(modeFor(not minesOn(), fruitOn()))
end)
task.spawn(function()
	while true do
		task.wait(RESEND_SECONDS)
		if want then
			if matches(want) then
				want = nil
				refreshButton()
			else
				send(want)
			end
		end
	end
end)

-- ---------------------------------------------------------------------------
-- Choosing
-- ---------------------------------------------------------------------------

local skipped = setmetatable({}, { __mode = "k" })

local function isSkipped(key)
	local untilAt = skipped[key]
	if untilAt ~= nil and os.clock() >= untilAt then
		skipped[key] = nil
		return false
	end
	return untilAt ~= nil
end

local function flat(v)
	return Vector3.new(v.X, 0, v.Z)
end

local function bagRoom()
	return (player:GetAttribute("BagCapacity") or 0) - (player:GetAttribute("BagCount") or 0)
end

-- zombies up and not dizzy: { pos, avoid, flee } (Workspace.Zombies: one Configuration each, Zombies service)
local function threats()
	local list = {}
	local folder = Workspace:FindFirstChild("Zombies")
	if not folder or player:GetAttribute("InTutorial") then
		return list
	end
	local now = Workspace:GetServerTimeNow()
	for _, z in ipairs(folder:GetChildren()) do
		local state = z:GetAttribute("State")
		local p = z:GetAttribute("P") -- (x, height, z: Zombies service)
		local x, zz = p and p.X, p and p.Z
		local boss = z:GetAttribute("Boss") or z:GetAttribute("Aurora")
		if (state == "Up" or state == "Rising") and x and zz and (z:GetAttribute("StunUntil") or 0) < now
			and not z:GetAttribute("DefeatedAt") then
			table.insert(list, { pos = Vector3.new(x, 0, zz), avoid = boss and A.BossAvoid or A.ZombieAvoid,
				flee = boss and A.BossFlee or A.ZombieFlee })
		end
	end
	return list
end

-- the nearest zombie within its kind's radius ("avoid" or "flee") of a spot, or nil
local function dangerAt(position, kind, list)
	local spot = Vector3.new(position.X, 0, position.Z)
	local nearest, nearestDistance = nil, math.huge
	for _, t in ipairs(list or threats()) do
		local d = (t.pos - spot).Magnitude
		if d <= t[kind] and d < nearestDistance then
			nearest, nearestDistance = t, d
		end
	end
	return nearest
end

-- the mineral worth the most money a second from here, the way there counted (see WALK_WEIGHT), or nil
local function bestMineral(root, humanoid)
	local folder = Workspace:FindFirstChild("Minerals")
	if not folder then
		return nil
	end
	local tier = player:GetAttribute("PickaxeTier") or 1
	local power = player:GetAttribute("TrainReal_Power") or player:GetAttribute("PickaxePower") or 0
	local speed = player:GetAttribute("TrainReal_Speed") or player:GetAttribute("PickaxeSpeed") or 0
	local room = bagRoom() / Config.Minerals.BagSlotsPerMineral
	local walk = math.max(humanoid.WalkSpeed, 1)
	local candidates, bestScore = {}, 0
	local danger = threats()
	for _, model in ipairs(folder:GetChildren()) do
		local gradeId, sizeId = model:GetAttribute("Grade"), model:GetAttribute("Size")
		local grade, left = gradeId and Formulas.grade(gradeId), model:GetAttribute("TurnsLeft") or 1
		local size = sizeId and Formulas.size(sizeId)
		local share = math.ceil(left / (1 + (model:GetAttribute("Miners") or 0)))
		if grade and size and left > 0 and not isSkipped(model) and model:IsA("Model") and Unlock.mineable(model)
			and not Formulas.mineLocked(tier, power, speed, gradeId) -- (2026-10-04: too hard to start, the server says no)
			and not dangerAt(model:GetBoundingBox().Position, "avoid", danger) then
			local perTurn = math.max(Formulas.yieldPerTurn(tier, gradeId, sizeId), 1)
			local special = gradeId == Config.Minerals.Special.Id
			local slots = special and Formulas.treasureSlots() or Formulas.bagSlots(gradeId)
			local amount = special and math.min(math.floor(room / slots), Config.Minerals.Special.MaxUnits) or math.min(share * perTurn, math.floor(room / slots))
			local turnsNeeded = math.ceil(amount / perTurn)
			local distance = flat(model:GetBoundingBox().Position - root.Position).Magnitude
			local seconds = distance / walk * PATH_FACTOR * WALK_WEIGHT + TRIP_SECONDS
				+ turnsNeeded * Formulas.mineSeconds(tier, power, speed, gradeId)
			local score = Formulas.carryValue({ [Formulas.carryKey(gradeId, sizeId)] = amount },
				player:GetAttribute("DefenseLevel") or 1) / math.max(seconds, 0.1)
			table.insert(candidates, { model, score, distance })
			bestScore = math.max(bestScore, score)
		end
	end
	local best, bestDistance = nil, math.huge
	for _, c in ipairs(candidates) do
		if c[2] >= bestScore * NEAR_ENOUGH and c[3] < bestDistance then
			best, bestDistance = c[1], c[3]
		end
	end
	return best
end

local function homeBin()
	local map = Workspace:FindFirstChild("Map")
	local base = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	return base and base:FindFirstChild("Base_DepositBin", true)
end

local function present(target) -- (a spot is always there; a mineral or a bin may go)
	return typeof(target) == "Vector3" or target.Parent ~= nil
end

local function positionOf(instance)
	if typeof(instance) == "Vector3" then
		return instance
	elseif instance:IsA("BasePart") then
		return instance.Position
	elseif instance:IsA("Model") then
		return instance:GetBoundingBox().Position -- (as the server measures: Minerals, Bases.position)
	end
	return instance:GetPivot().Position
end

-- ---------------------------------------------------------------------------
-- Walking
-- ---------------------------------------------------------------------------

local controls = nil -- the PlayerModule's ControlModule: is the player moving by hand?
local walking = false -- (declared here: the take-over below stops what it does)
local asked = nil -- the mineral it asked to mine
local autoMovedAt = -math.huge -- os.clock() of its last MoveTo (autoMove)
local autoTarget = nil -- where its last MoveTo goes
-- every MoveTo of the auto goes through here, so a MoveDirection it did not ask for is the player's (below)
local function autoMove(humanoid, at)
	autoMovedAt = os.clock()
	autoTarget = at
	humanoid:MoveTo(at)
end
-- (2026-10-02, "움직여서오토가 안꺼지네 아예 동작도 오토중이고 계속": the stick was looked at only when a step
-- was due, 0.3 s apart; a short push between two looks was missed and the walk went on) every frame: a push
-- of the stick or the movement keys while it is on is kept until ready() sees it
local handMoved = false
local offCourse = 0 -- frames in a row the character heads off the auto's way
local function moveVector()
	if not controls then
		pcall(function()
			local module = player:FindFirstChild("PlayerScripts") and player.PlayerScripts:FindFirstChild("PlayerModule")
			controls = module and require(module):GetControls()
		end)
	end
	local ok, v = pcall(function()
		return controls and controls:GetMoveVector()
	end)
	return ok and v or nil
end
-- (2026-10-03, "자동 열매랑 자동 두개다는 왜 움직여도 안 멈춤") switched off right here, the moment it is pushed: it
-- was left to the walking loop to see (ready()), so whatever kept the loop from looking (a long wait, an error that
-- stopped it) kept the auto on while the player pushed the stick
local takeOver -- (below: needs switch)
RunService.Heartbeat:Connect(FrameMeter.wrap("AutoMine", function()
	if not handMoved and on() then
		local v = moveVector()
		if v and v.Magnitude > 0.1 then
			handMoved = true
		end
		-- (2026-10-04, "자동채굴은 왜 움직이는데 자동이 안끝나냐 또") and in case the stick's module can't be read (a phone):
		-- the character heading somewhere while the auto has not asked it to walk for a moment is the player
		local humanoid = not handMoved and not walking and os.clock() - autoMovedAt > HAND_MOVE_GRACE
			and player.Character and player.Character:FindFirstChildOfClass("Humanoid")
		if humanoid and humanoid.MoveDirection.Magnitude > 0.1 and not humanoid.PlatformStand then
			handMoved = true
		end
		-- (2026-10-04, "또 움직이는데 오토 취소 안 되네": while it walked, a push of the stick went unseen when the stick's
		-- module can't be read) walking: the character heading well off the way the auto sent it is the player
		local character = not handMoved and walking and autoTarget and os.clock() - autoMovedAt > OFF_COURSE_GRACE
			and player.Character
		local h = character and character:FindFirstChildOfClass("Humanoid")
		local root = character and character:FindFirstChild("HumanoidRootPart")
		if h and root and h.MoveDirection.Magnitude > 0.1 and not h.PlatformStand then
			local toward = Vector3.new(autoTarget.X - root.Position.X, 0, autoTarget.Z - root.Position.Z)
			local going = Vector3.new(h.MoveDirection.X, 0, h.MoveDirection.Z)
			if toward.Magnitude > 1 and going.Magnitude > 0.1 and toward.Unit:Dot(going.Unit) < HAND_OFF_COURSE then
				offCourse += 1
				handMoved = offCourse >= OFF_COURSE_FRAMES
			else
				offCourse = 0
			end
		else
			offCourse = 0
		end
	end
	if handMoved and takeOver then
		takeOver()
	end
end))
-- (the movement keys too, in case the stick's module can't be read)
local MOVE_KEYS = { [Enum.KeyCode.W] = true, [Enum.KeyCode.A] = true, [Enum.KeyCode.S] = true, [Enum.KeyCode.D] = true,
	[Enum.KeyCode.Up] = true, [Enum.KeyCode.Down] = true, [Enum.KeyCode.Left] = true, [Enum.KeyCode.Right] = true }
UserInputService.InputBegan:Connect(function(input, processed)
	if not processed and MOVE_KEYS[input.KeyCode] and on() then
		handMoved = true
	end
end)
local function movedByHand()
	local moved = handMoved
	handMoved = false
	return moved
end

-- the player took over: auto off at once (the button turns it on again), the walk it started stopped
takeOver = function()
	if not movedByHand() or not on() then
		return
	end
	local fruitOnly = not minesOn()
	switch(true)
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	walking = false
	if humanoid and root then
		humanoid:MoveTo(root.Position)
	end
	-- (2026-10-04, "자동채굴은 왜 움직이는데 자동이 안끝나냐 또": the button went OFF, but the mineral the auto had started
	-- went on being mined while the player stayed in reach) the auto's own mining stops too
	if asked and player:GetAttribute("Mining") == true then
		Net.request("Mine", asked) -- (the same request again stops it)
	end
	asked = nil
	Notices.show(nil, fruitOnly and "🍎 직접 움직여서 자동 열매를 껐어요" or "⛏️ 직접 움직여서 자동 채굴을 껐어요")
end

-- may it act now? (owned and on, alive, not riding, not in the tutorial, has a base, not moved by hand)
local function ready()
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	-- (2026-10-03, the 8-player check) and never in a 🙈 hide-and-seek game: it walked home with a full bag, the game
	-- put it back inside the battlefield, again and again
	if not on() or not humanoid or humanoid.Health <= 0 or not root or humanoid.PlatformStand or restingOnMount()
		or player:GetAttribute("TutorialStep") or not player:GetAttribute("Base") or player:GetAttribute("HideSeekRoom") then
		return nil
	end
	return humanoid, root
end

-- every tree's trunk (any kind, anywhere: the battlefield's too), looked up every TREE_RESCAN seconds
local treeModels = {}
task.spawn(function()
	local map = Workspace:WaitForChild("Map")
	WorldWatch.listen({ "Model" }, function(model)
		if TREE_KINDS[model.Name] and model:IsDescendantOf(map) then
			treeModels[model] = true
		end
	end)
end)

local function trunkAt(model)
	local trunk = model:FindFirstChild("TrunkCollider") or model:FindFirstChild("Trunk")
	return trunk and trunk:IsA("BasePart") and trunk.Position or model:GetBoundingBox().Position
end

local trunks, trunksAt = {}, -math.huge
local function allTrees()
	if os.clock() - trunksAt < TREE_RESCAN then
		return trunks
	end
	trunksAt = os.clock()
	trunks = {}
	for model in pairs(treeModels) do
		if model.Parent then
			table.insert(trunks, trunkAt(model))
		else
			treeModels[model] = nil
		end
	end
	return trunks
end

-- the tree model (any kind) this part belongs to, or nil
local function treeOf(part)
	local model = part and part:FindFirstAncestorWhichIsA("Model")
	while model do
		if TREE_KINDS[model.Name] then
			return model
		end
		model = model.Parent and model.Parent:FindFirstAncestorWhichIsA("Model")
	end
	return nil
end

-- (2026-10-03) standing up on a tree (its trunk or branch colliders under my feet): walk out past its side and
-- drop down. True when it was on one
local downRay = RaycastParams.new()
downRay.FilterType = Enum.RaycastFilterType.Exclude
downRay.RespectCanCollide = true
local function offTree(humanoid, root)
	downRay.FilterDescendantsInstances = { player.Character }
	local hit = Workspace:Raycast(root.Position, Vector3.new(0, -(root.Size.Y / 2 + HIP_GUESS + 2), 0), downRay)
	local tree = hit and treeOf(hit.Instance)
	if not tree then
		return false
	end
	local center, size = tree:GetBoundingBox()
	local out = flat(root.Position - center.Position)
	out = out.Magnitude > 0.1 and out.Unit or flat(root.CFrame.LookVector).Unit
	walking = true -- (its own walk: not the player's)
	autoMove(humanoid, root.Position + out * (math.max(size.X, size.Z) / 2 + OFF_TREE_STUDS))
	local waited = 0
	while waited < OFF_TREE_SECONDS and on() do
		waited += task.wait(0.1)
	end
	walking = false
	if on() then
		autoMove(humanoid, root.Position)
	end
	return true
end

-- is a tree's trunk this close (flat)? (a stuck walk doesn't hop there)
local function byTree(position)
	for _, t in ipairs(allTrees()) do
		if flat(t - position).Magnitude <= TREE_NO_HOP then
			return true
		end
	end
	return false
end

local function stopWalking(humanoid)
	if walking and humanoid and humanoid.Parent then
		local root = humanoid.Parent:FindFirstChild("HumanoidRootPart")
		if root then
			autoMove(humanoid, root.Position)
		end
	end
	walking = false
end

-- walk toward target (an instance) until within reach studs of its position (minus extra, its own size),
-- or until stop() says so; false when it gave up (no way there, switched off, moved by hand). full: the
-- distance in 3D (the deposit bin: Bases.near), else flat
local function walkTo(target, reach, stop, full, giveUp)
	local function away(root)
		local d = positionOf(target) - root.Position
		return full and d.Magnitude or flat(d).Magnitude
	end
	local started = os.clock()
	local stucks, side = 0, 1
	local bestAway = math.huge
	while true do
		local humanoid, root = ready()
		if not humanoid or not present(target) then
			stopWalking(humanoid)
			return false
		end
		-- (2026-10-03, "오토 중 가방 꽉 차서 홈 눌러주면 홈에서 광물 팔러 안가고 웬 이상한데로 가네": it walked on along the
		-- path from before the 기지로 teleport) while the teleport counts down it stands; after it, a new path
		if player:GetAttribute("TeleportAt") then
			stopWalking(humanoid)
			if typeof(target) == "Vector3" then
				return false -- (a spot to flee to: no use from the base)
			end
			task.wait(0.2)
			started = os.clock()
			bestAway, stucks = math.huge, 0
			continue
		end
		if away(root) < bestAway - PROGRESS_STUDS then
			bestAway, stucks = away(root), 0
		end
		if stucks >= STUCK_LIMIT then
			stopWalking(humanoid)
			return false
		end
		if stop and stop() then
			stopWalking(humanoid)
			return true
		end
		local goal = positionOf(target)
		if away(root) <= reach then
			stopWalking(humanoid)
			return true
		end
		if os.clock() - started > (giveUp or A.GiveUpSeconds) then
			stopWalking(humanoid)
			return false
		end
		-- a path round rocks and trees; straight on without one
		local points = { goal }
		local path = PathfindingService:CreatePath(AGENT)
		local ok = pcall(function()
			path:ComputeAsync(root.Position, goal)
		end)
		if ok and path.Status == Enum.PathStatus.Success then
			points = {}
			for _, w in ipairs(path:GetWaypoints()) do
				table.insert(points, w)
			end
		end
		walking = true
		local legStart = os.clock()
		local lastPos, lastMoved = root.Position, os.clock()
		local seen = root.Position
		local again = false -- stuck or walked long enough: find the path again
		local stuck = false
		for _, point in ipairs(points) do
			local at = typeof(point) == "Vector3" and point or point.Position
			if typeof(point) ~= "Vector3" and point.Action == Enum.PathWaypointAction.Jump and not byTree(root.Position) then
				humanoid.Jump = true -- (never by a tree: the hop puts it up on the branches)
			end
			autoMove(humanoid, at)
			while flat(at - root.Position).Magnitude > WAYPOINT_REACHED do
				task.wait(0.1)
				if not ready() or not present(target) or (stop and stop()) or away(root) <= reach then
					break
				end
				if (root.Position - seen).Magnitude > TELEPORT_JUMP or player:GetAttribute("TeleportAt") then
					again = true -- teleported (or about to be): the path from before is no use
					if typeof(target) == "Vector3" then
						stopWalking(humanoid)
						return false
					end
					break
				end
				seen = root.Position
				if (root.Position - lastPos).Magnitude > STUCK_STUDS then
					lastPos, lastMoved = root.Position, os.clock()
				elseif os.clock() - lastMoved > STUCK_SECONDS then
					if not byTree(root.Position) then
						humanoid.Jump = true -- a low step or a fence: hop, then a new path
					end
					again, stuck = true, true
					break
				end
				if os.clock() - legStart > REPATH_SECONDS then
					again = true
					break
				end
				if os.clock() - autoMovedAt > MOVE_RESEND then
					autoMove(humanoid, at) -- (MoveTo gives up by itself after 8 seconds)
				end
			end
			if again or not ready() or not present(target) or (stop and stop()) or away(root) <= reach then
				break
			end
		end
		if stuck and ready() and offTree(humanoid, root) then
			stuck = false -- (up on a tree: down first, then a new path)
		end
		if stuck then
			stucks += 1
			if stucks >= 2 and stucks < STUCK_LIMIT and ready() then
				-- a rock or a tree in the way: a step to the side, round it, before the next path
				local toward = flat(positionOf(target) - root.Position)
				toward = toward.Magnitude > 0.1 and toward.Unit or root.CFrame.LookVector
				local sideways = Vector3.new(-toward.Z, 0, toward.X) * side
				side = -side
				autoMove(humanoid, root.Position + (sideways - toward * 0.3) * SIDESTEP_STUDS)
				task.wait(SIDESTEP_SECONDS)
			end
		end
	end
end

-- ---------------------------------------------------------------------------
-- The loop
-- ---------------------------------------------------------------------------

local function mining()
	return player:GetAttribute("Mining") == true
end

local function bagHolds()
	return (player:GetAttribute("BagCount") or 0) > 0 or (player:GetAttribute("FoundKeys") or 0) > 0
end

-- home to the deposit bin; empties the bag there when there is something in it
local teleportedAt = -math.huge -- os.clock() of the last 기지로 teleport (its cooldown: Config.HomeTeleport)
player:GetAttributeChangedSignal("TeleportAt"):Connect(function()
	if player:GetAttribute("TeleportAt") == nil then
		teleportedAt = os.clock()
	end
end)

-- fruitTrip (2026-10-05, "자동 열매를 광물로 인식하는지 집에 돌아와서 광물 판매하는 동작이 들어가네"): the fruit only (no
-- minerals in the mode, or riding): it walks home only till the fruit turns into food inside the base, and sells nothing
local function goHome(fruitTrip)
	local bin = homeBin()
	if not bin or isSkipped("home") then
		return
	end
	-- far off: the 기지로 teleport (not with keys: they must be run home; not on its cooldown)
	local _, root = ready()
	if root and (positionOf(bin) - root.Position).Magnitude > TELEPORT_HOME_FAR
		and (player:GetAttribute("CarriedKeys") or 0) <= 0 and not player:GetAttribute("TeleportAt")
		and os.clock() - teleportedAt > Config.HomeTeleport.Cooldown then
		stopWalking(player.Character and player.Character:FindFirstChildOfClass("Humanoid"))
		Net.request("TeleportHome")
		local waited = 0
		repeat
			waited += task.wait(0.2)
		until not on() or (not player:GetAttribute("TeleportAt") and waited > 0.6) or waited > TELEPORT_WAIT
		if not on() then
			return
		end
	end
	local banked = fruitTrip and (player:GetAttribute("CarriedKeys") or 0) <= 0 and function()
		return (player:GetAttribute("CarriedFruit") or 0) <= 0 -- (inside the base: food now)
	end or nil
	if not walkTo(bin, Config.Deposit.Range - ARRIVE_GAP, banked, true) then
		skipped["home"] = os.clock() + HOME_RETRY
		return
	end
	if fruitTrip or not bagHolds() or not owned() then
		return -- (came home to wait: no safe mineral out there; without the pass the fruit is all it brings)
	end
	local before = player:GetAttribute("BagCount") or 0
	Net.request("AutoDeposit")
	local waited = 0
	while waited < DEPOSIT_WAIT and bagHolds() do
		waited += task.wait(0.2)
	end
	if bagHolds() and (player:GetAttribute("BagCount") or 0) >= before then
		skipped["home"] = os.clock() + HOME_RETRY * 3 -- (the server said no: wait a little; was SkipSeconds, 30 s)
	end
end

-- a zombie close: stop mining, then home with anything in the bag, or FleeStuds straight away from it
local function flee(root, threat)
	if mining() and asked then
		Net.request("Mine", asked) -- (the same request again stops it; the Mining handler skips that mineral)
	end
	if minesOn() and bagHolds() and homeBin() and not isSkipped("home") then -- (fruit only: away, never to sell)
		goHome()
		return
	end
	local away = Vector3.new(root.Position.X - threat.pos.X, 0, root.Position.Z - threat.pos.Z)
	away = away.Magnitude > 0.1 and away.Unit or Vector3.xAxis
	walkTo(root.Position + away * A.FleeStuds, ARRIVE_GAP)
end

local function goMine(humanoid, root)
	local target = bestMineral(root, humanoid)
	if not target then
		goHome() -- nothing safe (or nothing at all): wait at home
		return
	end
	local radius = target:GetAttribute("Radius") or 0
	local reached = walkTo(target, Config.Mining.Range + radius - ARRIVE_GAP, function()
		local here = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		return mining() or (here ~= nil and dangerAt(here.Position, "flee") ~= nil)
	end)
	if not reached then
		skipped[target] = os.clock() + A.SkipSeconds
		return
	end
	if mining() or not present(target) or dangerAt(root.Position, "flee") then
		return -- (another one in reach started on its own, it went, or a zombie came: the loop runs)
	end
	asked = target
	Net.request("Mine", target)
	local waited = 0
	while waited < 1.5 and not mining() do
		waited += task.wait(0.1)
	end
	if not mining() then
		skipped[target] = os.clock() + A.SkipSeconds -- the server said no (someone took it, too far)
		asked = nil
	end
end

-- ---------------------------------------------------------------------------
-- Fruit (the 🍎 modes)
-- ---------------------------------------------------------------------------

local trees, treesAt = {}, -math.huge -- { model, foot } of the fruit trees in safe places
local slappedAt = {} -- [tree model] = os.clock() it was slapped
local function treesChanged()
	treesAt = -math.huge
end
for _, name in ipairs({ "OpenArea", "WildSpot", "FieldOpen", "Base" }) do
	player:GetAttributeChangedSignal(name):Connect(treesChanged)
end

local function fruitTrees()
	local wait = #trees > 0 and TREE_RESCAN or TREE_EMPTY_RESCAN
	if os.clock() - treesAt < wait then
		return trees
	end
	treesAt = os.clock()
	trees = {}
	local wild = player:GetAttribute("WildSpot")
	local map = Workspace:FindFirstChild("Map")
	if typeof(wild) == "Vector3" and map then
		for _, part in ipairs(Workspace:GetPartBoundsInRadius(wild, WILD_TREE_SEARCH)) do
			local model = treeOf(part)
			if model and model:IsDescendantOf(map) then
				treeModels[model] = true
			end
		end
	end
	for model in pairs(treeModels) do
		if not model.Parent then
			treeModels[model] = nil
		elseif model:FindFirstChildWhichIsA("BasePart", true) then
			local foot = trunkAt(model)
			if SafeZones.isSafe(foot) and Unlock.reachable(foot) then -- (never slapping on the battlefield)
				table.insert(trees, { model = model, foot = foot })
			end
		end
	end
	return trees
end

local function carriedFruit()
	return player:GetAttribute("CarriedFruit") or 0
end

-- the nearest fruit on the ground within radius (the Trees script draws each as a Model "Fruit" in Workspace)
local function nearestFruit(root, radius)
	local best, bestDistance = nil, radius
	local feet = root.Position.Y - (root.Size.Y / 2 + HIP_GUESS)
	for _, child in ipairs(Workspace:GetChildren()) do
		if child.Name == "Fruit" and child:IsA("Model") and child.PrimaryPart and not isSkipped(child) then
			local d = flat(child.PrimaryPart.Position - root.Position).Magnitude
			if d < bestDistance and SafeZones.isSafe(child.PrimaryPart.Position) and Unlock.reachable(child.PrimaryPart.Position)
				and child.PrimaryPart.Position.Y - feet <= FRUIT_TOO_HIGH then
				best, bestDistance = child, d
			end
		end
	end
	return best
end

-- the nearest tree within radius not slapped for TREE_AGAIN seconds and with no zombie near
local function nearestTree(root, radius)
	local best, bestDistance = nil, radius
	local danger = threats()
	for _, t in ipairs(fruitTrees()) do
		local d = flat(t.foot - root.Position).Magnitude
		if d < bestDistance and t.model.Parent and os.clock() - (slappedAt[t.model] or -math.huge) >= TREE_AGAIN
			and not dangerAt(t.foot, "avoid", danger) then
			best, bestDistance = t, d
		end
	end
	return best
end

-- is there fruit to take within radius (on the ground, or a tree ready to shake)?
local function fruitNear(root, radius)
	return carriedFruit() < Config.Fruit.MaxCarried and (nearestFruit(root, radius) ~= nil or nearestTree(root, radius) ~= nil)
end

-- one fruit step: home with a full load, else pick up fruit lying near, else shake the nearest ready tree.
-- false when there was nothing to do within radius
local function fruitStep(root, radius, fruitOnly)
	if carriedFruit() >= math.min(FRUIT_HOME_AT, Config.Fruit.MaxCarried) then
		goHome(fruitOnly) -- (inside the base the fruit turns into food; with minerals on, the bag is emptied too)
		return true
	end
	local fruit = nearestFruit(root, radius)
	if fruit then
		-- (in 3D, as it is picked up; riding, flat: the seat is high, Trees and Fruits measure it flat too)
		walkTo(fruit.PrimaryPart, math.max(Config.Fruit.PickRange - 1, 1), nil, not player:GetAttribute("Riding"))
		task.wait(FRUIT_PICK_WAIT) -- (the Trees script asks for it)
		if fruit.Parent then
			skipped[fruit] = os.clock() + A.SkipSeconds -- not picked up from here: another one
		end
		return true
	end
	local tree = nearestTree(root, radius)
	local wild = player:GetAttribute("WildSpot")
	if not tree and fruitOnly and typeof(wild) == "Vector3" and flat(wild - root.Position).Magnitude > WILD_SPOT_NEAR then
		walkTo(wild, WILD_SPOT_NEAR, nil, nil, TREE_GIVE_UP)
		treesChanged()
		return true
	end
	if not tree then
		return false
	end
	slappedAt[tree.model] = os.clock() -- (also when it can't get there: try another one)
	-- (2026-10-02, "나무앞에가서 그냥 서있네 찰싹 못하고": it walked to CloseRadius of the trunk, which a round tree's low
	-- leaves kept it from, and stood pushing until it gave up) as far as the slap reaches, facing the trunk: the
	-- server takes a tree in front within the reach and a little more (Fruits)
	local reach = math.max(Formulas.slapReach(player:GetAttribute("TrainReal_Slap") or player:GetAttribute("SlapLevel") or 1) - TREE_REACH_GAP, Config.Slap.CloseRadius)
	if not walkTo(tree.foot, reach, nil, nil, TREE_GIVE_UP) then
		return true
	end
	local _, here = ready()
	if here then
		local look = flat(tree.foot - here.Position)
		look = look.Magnitude > 0.1 and look.Unit or here.CFrame.LookVector
		here.CFrame = CFrame.lookAt(here.Position, here.Position + look)
		Net.request("Slap", here.Position, look) -- (the same request as the slap button; the server checks it)
		task.wait(FRUIT_FALL_WAIT)
	end
	return true
end

-- mining stopped while the mineral is still there, in reach, with room in the bag: the player stopped it
player:GetAttributeChangedSignal("Mining"):Connect(function()
	if mining() or not asked then
		return
	end
	local target = asked
	asked = nil
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if target.Parent and (target:GetAttribute("TurnsLeft") or 0) > 0 and bagRoom() > 0 and root
		and flat(target:GetBoundingBox().Position - root.Position).Magnitude <= Config.Mining.Range + (target:GetAttribute("Radius") or 0) then
		skipped[target] = os.clock() + A.SkipSeconds
	end
end)

-- one look at what to do next
local function step()
	local humanoid, root = ready()
	if humanoid and offTree(humanoid, root) then
		return -- (up on a tree: down first)
	end
	do
		local threat = humanoid and dangerAt(root.Position, "flee")
		if threat then
			flee(root, threat)
		elseif humanoid and (player:GetAttribute("CarriedKeys") or 0) > 0 then
			-- (2026-10-02, "키를 쥔채로 오토를 키면 어떻게 되는거야") keys in hand: home first, they count only there
			-- (Keys banks them inside the base; anything in the bag is sold on the way)
			if mining() and asked then
				Net.request("Mine", asked)
			end
			goHome(not minesOn() or player:GetAttribute("Riding") == true) -- (the bag sold only with minerals on)
		elseif humanoid and mining() and asked and (not minesOn() or player:GetAttribute("Riding")) then
			-- (2026-10-03, "오토는 왜 과일 선택했는데도 광질을 하나": the mineral it started before 🍎 went on to the end)
			Net.request("Mine", asked) -- (the same request again stops it)
			asked = nil
		elseif humanoid and not mining() then
			local mines, fruit = minesOn() and not player:GetAttribute("Riding"), fruitOn() -- (riding: the fruit only)
			if mines and bagRoom() <= 0 then
				goHome()
			elseif fruit and (not mines or fruitNear(root, FRUIT_NEAR) or carriedFruit() >= FRUIT_HOME_AT)
				and fruitStep(root, mines and FRUIT_NEAR or math.huge, not mines) then
				-- (fruit first: only fruit, or some close by on the way)
			elseif mines then
				goMine(humanoid, root)
			elseif carriedFruit() > 0 then
				goHome(true) -- (no tree ready: the fruit in hand goes home meanwhile)
			end
		end
	end
end

-- (2026-10-03) an error in one look never stops the loop (it stopped it for good, the auto still on): reported
-- to the server's log at most every LOOP_ERROR_EVERY seconds, and it goes on
local lastLoopError = -math.huge
task.spawn(function()
	while true do
		task.wait(A.CheckSeconds)
		local ok, err = pcall(step)
		if not ok then
			walking = false
			if os.clock() - lastLoopError >= LOOP_ERROR_EVERY then
				lastLoopError = os.clock()
				Net.request("ClientError", "[AutoMine] loop error", tostring(err))
			end
		end
	end
end)
