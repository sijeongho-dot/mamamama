local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))

local UPDATE_EVERY = 0.25
local SHOW_DISTANCE = 80
local RING_WIDTH = 0.35
local RING_HEIGHT = 0.08
local RING_UP = 0.12
local RING_TRANSPARENCY = 0.45
local RING_PICKED = 0
local RING_PULSE_SECONDS = 1.5
local RING_PULSE_WIDTH = 0.8
local ICON_SIZE = UDim2.fromScale(4.4, 1.8)
local ICON_PULSE_SCALE = 1.4
local ICON_UP = 3
local ICON_DISTANCE = 70
local ICON_TEXT_COLOR = Color3.new(1, 1, 1)
local ICON_BACK = Color3.fromRGB(30, 30, 45)
local ICON_BACK_TRANSPARENCY = 0.35
local ATTRIBUTE_COLORS = {
	Ice = Color3.fromRGB(150, 220, 255), Fire = Color3.fromRGB(255, 120, 40), Electric = Color3.fromRGB(255, 235, 60),
	Poison = Color3.fromRGB(170, 80, 220), Earth = Color3.fromRGB(160, 110, 60), Water = Color3.fromRGB(60, 140, 255),
	Neutral = Color3.fromRGB(255, 255, 255),
}
local FLAT = CFrame.Angles(math.rad(90), 0, 0)

local player = Players.LocalPlayer
local folder = Instance.new("Folder")
folder.Name = "MyReachRings"
folder.Parent = Workspace

local rings = {}
local outline = nil

local function modeIcon(id)
	for _, t in ipairs(Config.Defense.Targets) do
		if t.Id == id then
			return t.Icon
		end
	end
	return Config.Defense.Targets[1].Icon
end

local function drop(model)
	local r = rings[model]
	if r then
		r.ring:Destroy()
		r.tag:Destroy()
		r.spot:Destroy()
		for _, c in ipairs(r.watch) do
			c:Disconnect()
		end
		rings[model] = nil
	end
end

local function clear()
	for model in pairs(rings) do
		drop(model)
	end
end

local function place(r, model)
	local rest = model:GetAttribute("Rest")
	local reach = model:GetAttribute("Reach") or 0
	if not rest or reach <= 0 then
		return false
	end
	local ground = CFrame.new(rest.Position + Vector3.new(0, RING_UP, 0))
	r.ring.CFrame = ground * FLAT
	r.ring.Radius = reach
	r.spot.WorldPosition = rest.Position + Vector3.new(0, ICON_UP, 0)
	r.label.Text = "🎯" .. modeIcon(model:GetAttribute("Target") or "Auto")
	return true
end

local function pulse(r)
	r.pulseUntil = os.clock() + RING_PULSE_SECONDS
	r.tag.Size = UDim2.fromScale(ICON_SIZE.X.Scale * ICON_PULSE_SCALE, ICON_SIZE.Y.Scale * ICON_PULSE_SCALE)
	task.delay(RING_PULSE_SECONDS, function()
		if r.tag.Parent then
			r.tag.Size = ICON_SIZE
		end
	end)
end

local function add(model)
	local ring = Instance.new("CylinderHandleAdornment")
	ring.Name = "Reach"
	ring.Height = RING_HEIGHT
	ring.InnerRadius = 0
	ring.Color3 = ATTRIBUTE_COLORS[model:GetAttribute("Attribute") or ""] or ATTRIBUTE_COLORS.Neutral
	ring.Transparency = RING_TRANSPARENCY
	ring.AlwaysOnTop = false
	ring.Adornee = Workspace.Terrain
	ring.Parent = folder
	local spot = Instance.new("Attachment")
	spot.Parent = Workspace.Terrain
	local tag = Instance.new("BillboardGui")
	tag.Size = ICON_SIZE
	tag.MaxDistance = ICON_DISTANCE
	tag.AlwaysOnTop = true
	tag.Adornee = spot
	tag.Parent = folder
	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundColor3 = ICON_BACK
	label.BackgroundTransparency = ICON_BACK_TRANSPARENCY
	label.TextColor3 = ICON_TEXT_COLOR
	label.Font = Enum.Font.GothamBold
	label.TextScaled = true
	label.Parent = tag
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0.5, 0)
	corner.Parent = label
	local r = { ring = ring, tag = tag, spot = spot, label = label, watch = {} }
	rings[model] = r
	local function moved()
		if rings[model] == r then
			place(r, model)
		end
	end
	table.insert(r.watch, model:GetAttributeChangedSignal("Rest"):Connect(moved))
	table.insert(r.watch, model:GetAttributeChangedSignal("Reach"):Connect(moved))
	table.insert(r.watch, model:GetAttributeChangedSignal("Target"):Connect(function()
		moved()
		pulse(r)
	end))
	place(r, model)
end

local function myUnits()
	local map = Workspace:FindFirstChild("Map")
	local base = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	return base and base:FindFirstChild("DefenseUnits"), base and base:GetAttribute("ArenaFrame")
end

local function shown(frame)
	if player:GetAttribute("HideReach") or player:GetAttribute("HideMyDinos") or not frame then
		return false
	end
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	return root ~= nil and (root.Position - frame.Position).Magnitude <= SHOW_DISTANCE
end

local function picked()
	if not outline or not outline.Parent then
		outline = player:FindFirstChildOfClass("PlayerGui") and player.PlayerGui:FindFirstChild("NearUnitOutline", true)
	end
	return outline and outline.Enabled and outline.Adornee or nil
end

task.spawn(function()
	while true do
		local units, frame = myUnits()
		if units and shown(frame) then
			local seen = {}
			for _, model in ipairs(units:GetChildren()) do
				if model:IsA("Model") and model:GetAttribute("Rest") then
					seen[model] = true
					if not rings[model] then
						add(model)
					end
				end
			end
			for model in pairs(rings) do
				if not seen[model] then
					drop(model)
				end
			end
			local pick = picked()
			local now = os.clock()
			for model, r in pairs(rings) do
				local hot = model == pick or (r.pulseUntil or 0) > now
				r.ring.Transparency = hot and RING_PICKED or RING_TRANSPARENCY
				r.ring.InnerRadius = math.max(0, r.ring.Radius - (hot and RING_PULSE_WIDTH or RING_WIDTH))
				r.tag.Enabled = true
			end
		elseif next(rings) then
			clear()
		end
		task.wait(UPDATE_EVERY)
	end
end)
