--[[
Npcs: the shopkeeper dinos and the central board, on this screen only (display).

- NPC dinos (server Npcs service: models with attributes Npc, NpcBase, Rest) breathe, look around
  and sway their tails (Shared/DinoMotion) while the camera is near.
- Every time this player uses a place's prompt, that place's NPC does its motion and says a line in a
  speech bubble and a greeting sound: the shop's hops, the key stall's spins, the enhance stall's roars with a stomp, the
  board's waves. Now and then (every GROWL_EVERY seconds or so) a nearby NPC also growls on its own:
  rears up, lunges with its jaw open, a low growl and sometimes a "크르릉…" bubble. (Shop, KeyShop and Enhance only in the player's own base: other bases' prompts are
  hidden anyway.)
- (2026-10-02, "npc 공룡들 찰싹 맞으면 으르렁하게 하자 탈것처럼") Slapped (Net push SlapFx, the NPC in the
  slapper's reach) an NPC rears up and roars like a ridden dino (DinoMotion.roar, its species' big roar)
  with an angry word in its bubble.
- The central board (KeyZone.Zone_Leaderboard): its screen shows the time to the next key drop and the
  server's top 5; its "게시판 보기" prompt (Kind "Board") opens the board window with every player
  in this server ranked by defense level, then saved keys (leaderstats), with rebirths and the #1 crown
  (attribute Bounty). E again or walking away closes it.
]]

local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Lang = require(Shared:WaitForChild("Lang"))
local DinoMotion = require(Shared:WaitForChild("DinoMotion"))
local Lod = require(Shared:WaitForChild("Lod"))
local Windows = require(Shared:WaitForChild("Windows"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local DinoVoices = require(Shared:WaitForChild("DinoVoices"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local SpeechBubble = require(Shared:WaitForChild("SpeechBubble"))
local WorldWatch = require(Shared:WaitForChild("WorldWatch"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local DRAW_DISTANCE = 220 -- NPCs farther from the camera stand still
local REACTION_SECONDS = 1.1
local BUBBLE_SECONDS = 2.6
local BUBBLE_ABOVE = 1.5 -- studs over the NPC's head
local BUBBLE_DISTANCE = 70 -- studs: farther away the bubble is not drawn
local HOP_HEIGHT = 0.35 -- × the NPC's height
local SPIN_HOP = 0.2
local ROAR_TILT = 0.18
local STOMP_SHAKE = 0.06
local WAVE_ROLL = 0.28
local WAVE_TIMES = 3
local GROWL_EVERY = { 9, 22 } -- seconds between an NPC's own growls
local GROWL_SECONDS = 1.0
local GROWL_DISTANCE = 90 -- only NPCs this close to the camera growl (and are heard)
local GROWL_TILT = 0.14
local GROWL_SHAKE = 0.03 -- × height
local GROWL_BUBBLE_CHANCE = 0.5
local NPC_VOICE_PITCH = 1.1
local SLAPPED_LINES = { "크아앙!!", "누가 때렸어?!", "으르렁!!", "아프잖아!" }
local SLAP_BODY = 0.4 -- × an NPC's height: its body round where it stands (added to the slap's reach) ...
local SLAP_COUNTER = 2 -- ... and the counter it stands behind (studs)
local CHIRP_ROAR_PITCH = 1.25
local GROWL_LINES = { "크르릉…", "그르렁!", "크아앙~", "으르렁!" }
local LINES = {
	Shop = { "어서 와요! 곡괭이 보고 가요~", "가방이 꽉 찼나요? 키워 줄게요!", "오늘도 열심히 캐요!" },
	KeyShop = { "반짝반짝 열쇠 있어요!", "열쇠 10개 → 윗등급 1개로 바꿔 줘요!", "좋은 열쇠엔 좋은 공룡이!",
		"남는 열쇠, 여기서 교환해요!", "무지개 열쇠, 탐나죠?" },
	Enhance = { "쾅쾅! 더 세게 만들어 줄게요!", "아무 공룡이나 먹이면 강해져요!", "크게 키울수록 튼튼해요!" },
	BombShop = { "펑! 폭탄 사 가요!", "똥 폭탄은 보스도 묶어요!", "상자 든 녀석한테 던져 봐요!" },
	Board = { "오늘의 1등은 누구일까요?", "선물상자가 곧 떨어져요!", "순위를 확인해 봐요!" },
}
local BOARD_SIZE = UDim2.fromOffset(360, 400)
local BOARD_ROW = 30
local BOARD_HEAD_ROW = 26
local BOARD_WALK_AWAY = 10 -- studs past the prompt's reach
local COLOR_BIG_DROP = Color3.fromRGB(255, 220, 90) -- the next drop is a big one (⚡)
-- the board's own tall panel (made on this screen in front of the board, facing the plaza)
local PANEL_HEIGHT = 9 -- studs
local PANEL_MIN_WIDTH = 10
local PANEL_LIFT = 1 -- studs over the ground under it
local PANEL_FRONT = 0.3 -- studs in front of the board
local PANEL_THICKNESS = 0.4
local PANEL_PIXELS_PER_STUD = 30
local PANEL_BORDER_PX = 10 -- the wooden frame round the screen
local PANEL_FRAME = Color3.fromRGB(110, 80, 55)
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_ROW = Color3.fromRGB(40, 44, 60)
local COLOR_ME = Color3.fromRGB(60, 90, 60)
local COLOR_GOLD = Color3.fromRGB(255, 215, 90)
local COLOR_SCREEN = Color3.fromRGB(30, 30, 36)
local COLOR_HEAD_GLOBAL = Color3.fromRGB(120, 200, 255)
local COLOR_HEAD_SERVER = Color3.fromRGB(150, 230, 150)
local COLOR_BUBBLE_EDGE = Color3.fromRGB(120, 170, 230) -- an NPC's bubble edge

local npcs = {} -- [model] = { rig, rest, kind, base, height, reactStart, bubble (Shared/SpeechBubble), above }

-- The NPC's parts can arrive after the model, or stream out and back in (StreamingEnabled): the
-- bubble and the motion hang on the parts there now. With none, nothing is shown (a bubble without
-- its part showed at the middle of the map, on the ground).
local function attach(npc)
	local model = npc.model
	if model:GetAttribute("Hidden") then
		return false
	end
	local anchor = model:FindFirstChildWhichIsA("BasePart", true)
	if anchor and anchor == npc.anchor then
		return true
	end
	npc.anchor = anchor
	if not anchor then
		return false
	end
	model:PivotTo(npc.rest)
	npc.rig = DinoMotion.new(model)
	npc.height = npc.rig.height
	-- over the top of the whole NPC (the part it hangs on can sit anywhere in it)
	local box, boxSize = model:GetBoundingBox()
	npc.above = box.Position.Y + boxSize.Y / 2 - anchor.Position.Y + BUBBLE_ABOVE
	return true
end

local function addNpc(model)
	if npcs[model] or not model:IsA("Model") or not model:GetAttribute("Npc") then
		return
	end
	local rest = model:GetAttribute("Rest") or model:GetPivot()
	local npc = { model = model, rig = nil, anchor = nil, rest = rest, kind = model:GetAttribute("Npc"),
		base = model:GetAttribute("NpcBase"), height = 0, reactStart = nil, bubble = nil, above = 0,
		growlStart = nil, nextGrowl = os.clock() + math.random(GROWL_EVERY[1], GROWL_EVERY[2]) }
	npcs[model] = npc
	attach(npc)
	model.AncestryChanged:Connect(function()
		if not model:IsDescendantOf(Workspace) and npcs[model] then
			npcs[model] = nil -- (its bubble hangs on its part: gone with it)
		end
	end)
end

-- where the NPC is t seconds into its motion (0-1 of REACTION_SECONDS), on top of where it stands
local function reaction(npc, t)
	local h = npc.height
	if npc.kind == "Shop" then -- two happy hops
		return CFrame.new(0, h * HOP_HEIGHT * math.abs(math.sin(2 * math.pi * t)), 0)
	elseif npc.kind == "KeyShop" then -- a spin with a little hop
		local turn = 2 * math.pi * (t * t * (3 - 2 * t))
		return CFrame.new(0, h * SPIN_HOP * math.sin(math.pi * t), 0) * CFrame.Angles(0, turn, 0)
	elseif npc.kind == "BombShop" then -- ducks down as if something went off, then pops back up
		local duck = math.sin(math.pi * math.min(1, t * 1.6))
		local shake = STOMP_SHAKE * h * math.sin(t * 50) * (1 - t)
		return CFrame.new(shake, -h * HOP_HEIGHT * 0.8 * duck, 0)
	elseif npc.kind == "Enhance" then -- rears back, then stomps (the roar is DinoMotion.attack)
		local tilt = ROAR_TILT * math.sin(math.pi * math.min(1, t * 2))
		local shake = t > 0.5 and STOMP_SHAKE * h * math.sin(t * 60) * (1 - t) or 0
		return CFrame.new(shake, 0, 0) * CFrame.Angles(tilt, 0, 0)
	else -- waves: sways side to side and bobs
		local roll = WAVE_ROLL * math.sin(WAVE_TIMES * 2 * math.pi * t) * (1 - t)
		return CFrame.new(0, h * 0.08 * math.abs(math.sin(WAVE_TIMES * math.pi * t)), 0) * CFrame.Angles(0, 0, roll)
	end
end

-- a growl of its own: rears up, then lunges with the jaw open, trembling a little
local function growlMotion(npc, t)
	local tilt = GROWL_TILT * math.sin(math.pi * math.min(1, t / 0.35)) * (t < 0.35 and 1 or 0)
	local shake = t > 0.35 and GROWL_SHAKE * npc.height * math.sin(t * 70) * (1 - t) or 0
	return CFrame.new(shake, 0, 0) * CFrame.Angles(tilt, 0, 0)
end

-- (2026-10-02, "NPC말풍선 크다": a fixed 190 × 46 box with its text scaled up to fill it) the speech bubble of
-- the wild dinos and zombies: text 15, the bubble fitted to the words (Shared/SpeechBubble)
local function say(npc, text)
	if not attach(npc) then
		return
	end
	SpeechBubble.say(npc, npc.anchor, npc.above, text, { seconds = BUBBLE_SECONDS, distance = BUBBLE_DISTANCE,
		edge = COLOR_BUBBLE_EDGE })
end

local function growl(npc)
	npc.growlStart = os.clock()
	npc.growlLunged = false
	local species = npc.model and npc.model:GetAttribute("Species")
	if species then -- its species' own voice (Shared/DinoVoices), a little higher: they are small
		local name, pitch = DinoVoices.voice(species)
		Sfx.play(name, npc.rest.Position, pitch * NPC_VOICE_PITCH)
	else
		Sfx.play("NpcGrowl", npc.rest.Position)
	end
	if math.random() < GROWL_BUBBLE_CHANCE then
		say(npc, GROWL_LINES[math.random(1, #GROWL_LINES)])
	end
end

-- slapped (see the top): the growl's rear-up with a ridden dino's roar
local function slapped(npc)
	npc.reactStart = nil
	npc.growlStart = os.clock()
	npc.growlLunged = true -- (the roar instead of the lunge)
	DinoMotion.roar(npc.rig)
	Sfx.play("SlapHit", npc.rest.Position + Vector3.new(0, npc.height * 0.6, 0))
	local species = npc.model:GetAttribute("Species")
	if species then
		local name, pitch = DinoVoices.roar(species)
		if name == "MountChirp" then -- (2026-10-02, "열쇠상점 npc는 으르렁 안하는데": the raptor's own voice is a
			name, pitch = "MountRoar", pitch * CHIRP_ROAR_PITCH -- chirp) a real roar, a little higher
		end
		Sfx.play(name, npc.rest.Position, pitch * NPC_VOICE_PITCH)
	else
		Sfx.play("NpcGrowl", npc.rest.Position)
	end
	say(npc, SLAPPED_LINES[math.random(1, #SLAPPED_LINES)])
end

local function react(npc)
	npc.growlStart = nil
	npc.reactStart = os.clock()
	npc.roared = false
	local lines = LINES[npc.kind] or { "안녕!" }
	say(npc, lines[math.random(1, #lines)])
	Sfx.play("NpcHello", npc.rest.Position)
	if npc.rig and (npc.kind == "Enhance" or npc.kind == "Board") then
		DinoMotion.attack(npc.rig) -- the jaw opens: a roar, or a hello
	end
end

task.spawn(function()
	local map = Workspace:WaitForChild("Map")
	WorldWatch.listen({ "Model" }, function(d, existing)
		if d:GetAttribute("Npc") and d:IsDescendantOf(map) then
			if existing then
				addNpc(d)
			else
				task.defer(addNpc, d)
			end
		end
	end)
end)

Net.onPush("SlapFx", function(slapperId, _, level)
	local slapper = Players:GetPlayerByUserId(slapperId)
	local root = slapper and slapper.Character and slapper.Character:FindFirstChild("HumanoidRootPart")
	local camera = Workspace.CurrentCamera
	if not root or not camera or (root.Position - camera.CFrame.Position).Magnitude > GROWL_DISTANCE then
		return
	end
	local reach = Formulas.slapReach(math.clamp(tonumber(level) or 1, 1, #Config.Slap.Scale))
	local look = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z)
	look = look.Magnitude > 0.01 and look.Unit or Vector3.zAxis
	for _, npc in pairs(npcs) do
		if npc.rig and attach(npc) then
			local offset = Vector3.new(npc.rest.Position.X - root.Position.X, 0, npc.rest.Position.Z - root.Position.Z)
			local gap = math.max(0, offset.Magnitude - npc.height * SLAP_BODY - SLAP_COUNTER)
			local away = offset.Magnitude > 0.1 and offset.Unit or look
			if gap <= reach and (gap < Config.Slap.CloseRadius or away:Dot(look) >= Config.Slap.FrontDot) then
				slapped(npc)
			end
		end
	end
end)

Net.onPush("BombBlast", function(_, at, _, _, _, reach)
	local camera = Workspace.CurrentCamera
	if typeof(at) ~= "Vector3" or not camera or (at - camera.CFrame.Position).Magnitude > GROWL_DISTANCE then
		return
	end
	reach = tonumber(reach) or Config.Slap.ReachBase
	for _, npc in pairs(npcs) do
		if npc.rig and attach(npc) then
			local offset = Vector3.new(npc.rest.Position.X - at.X, 0, npc.rest.Position.Z - at.Z)
			if offset.Magnitude - npc.height * SLAP_BODY <= reach then
				slapped(npc)
			end
		end
	end
end)

RunService.Heartbeat:Connect(FrameMeter.wrap("Npcs", function(dt)
	local camera = Workspace.CurrentCamera
	local eye = camera and camera.CFrame.Position or Vector3.zero
	local now = os.clock()
	for model, npc in pairs(npcs) do
		local distance = (npc.rest.Position - eye).Magnitude
		if distance <= DRAW_DISTANCE and attach(npc) then
			local extra = CFrame.identity
			if not npc.reactStart and not npc.growlStart and now >= npc.nextGrowl then
				npc.nextGrowl = now + math.random(GROWL_EVERY[1], GROWL_EVERY[2])
				if distance <= GROWL_DISTANCE then
					growl(npc)
				end
			end
			if npc.growlStart then
				local t = (now - npc.growlStart) / GROWL_SECONDS
				if t >= 1 then
					npc.growlStart = nil
				else
					if t > 0.35 and not npc.growlLunged then
						npc.growlLunged = true
						DinoMotion.attack(npc.rig)
					end
					extra = growlMotion(npc, t)
				end
			end
			if npc.reactStart then
				local t = (now - npc.reactStart) / REACTION_SECONDS
				if t >= 1 then
					npc.reactStart = nil
				else
					if npc.kind == "Enhance" and t > 0.5 and not npc.roared then
						npc.roared = true
						DinoMotion.attack(npc.rig) -- the second roar with the stomp
					end
					extra = reaction(npc, t)
				end
			end
			local due, step = Lod.due(npc, distance, dt) -- far ones less often (Shared/Lod)
			if due or npc.reactStart or npc.growlStart then
				model:PivotTo(npc.rest * extra * DinoMotion.step(npc.rig, due and step or dt, 0))
			end
		end
	end
end))

-- ---------------------------------------------------------------------------
-- The central board: its screen and its window
-- ---------------------------------------------------------------------------

local gui = Instance.new("ScreenGui")
gui.Name = "Board"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local window = Instance.new("Frame")
window.AnchorPoint = Vector2.new(0.5, 0.5)
window.Position = UDim2.fromScale(0.5, 0.5)
window.Size = BOARD_SIZE
window.BackgroundColor3 = COLOR_BG
window.Visible = false
window.Parent = gui
local windowRound = Instance.new("UICorner")
windowRound.CornerRadius = UDim.new(0, 14)
windowRound.Parent = window
Windows.fit(window) -- smaller on small screens, clear of the HUD

local function text(parent, value, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextSize = textSize
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.Text = value
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

text(window, "📋 서버 게시판", UDim2.new(1, -60, 0, 32), UDim2.fromOffset(14, 8), 20)
local nextDropText = text(window, "", UDim2.new(1, -28, 0, 22), UDim2.fromOffset(14, 42), 15, COLOR_GOLD)
text(window, "🌏 전 서버 순위 (디펜스 레벨) · 🏠 이 서버 순위 · 📖 도감 순위", UDim2.new(1, -28, 0, 18), UDim2.fromOffset(14, 66), 12,
	Color3.fromRGB(180, 180, 190))
local list = Instance.new("ScrollingFrame")
list.Position = UDim2.fromOffset(10, 88)
list.Size = UDim2.new(1, -20, 1, -98)
list.BackgroundTransparency = 1
list.ScrollBarThickness = 6
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = window
local listLayout = Instance.new("UIListLayout")
listLayout.Padding = UDim.new(0, 4)
listLayout.SortOrder = Enum.SortOrder.LayoutOrder
listLayout.Parent = list
Windows.register(window)

local function keysOf(p)
	return p:GetAttribute("Keys") or 0
end

-- every player in this server, best first: defense level, then saved keys
local function ranking()
	local all = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if not p:GetAttribute("Developer") then -- (2026-10-04: the developers are never ranked, Config.Developers)
			table.insert(all, p)
		end
	end
	table.sort(all, function(a, b)
		local la, lb = a:GetAttribute("DefenseLevel") or 0, b:GetAttribute("DefenseLevel") or 0
		if la ~= lb then
			return la > lb
		end
		return keysOf(a) > keysOf(b)
	end)
	return all
end

local function nextDropLine()
	local at = ReplicatedStorage:GetAttribute("NextKeyDrop")
	if not at then
		return "🎁 다음 상자: 곧"
	end
	local left = math.max(0, math.floor(at - Workspace:GetServerTimeNow()))
	return string.format("🎁 다음 상자까지 %d:%02d", left // 60, left % 60)
end

-- the all-server top list (server Leaderboards: ReplicatedStorage attribute GlobalRanking, JSON)
local function globalRanking()
	local ok, list = pcall(function()
		return HttpService:JSONDecode(ReplicatedStorage:GetAttribute("GlobalRanking") or "[]")
	end)
	return ok and type(list) == "table" and list or {}
end

-- (2026-10-02, 도감 자랑하기) the collection's all-server top (server Leaderboards: DexTop, JSON { Name, Count })
local function dexRanking()
	local ok, list = pcall(function()
		return HttpService:JSONDecode(ReplicatedStorage:GetAttribute("DexTop") or "[]")
	end)
	return ok and type(list) == "table" and list or {}
end

local function dexRowText(rank, name, count)
	local title = Formulas.collectionTitle(count)
	return string.format("%d위 %s · 📖 %d (%d%%)%s", rank, tostring(name), count, math.floor(count / Formulas.collectionTotal() * 100),
		title and (" · " .. title) or "")
end

local function globalRowText(rank, entry)
	return string.format("%d위 %s · %s", rank, tostring(entry.Name),
		Formulas.levelText(entry.Level or 1, Formulas.tierOfLevel(entry.Level or 1)))
end

local function rowText(rank, p)
	local rebirths = p:GetAttribute("Rebirths") or 0
	return string.format("%d위 %s%s · %s · 🔑 %s", rank, p:GetAttribute("Bounty") and "👑 " or "", p.DisplayName,
		Formulas.levelText(p:GetAttribute("DefenseLevel") or 1, rebirths),
		Formulas.shortNumber(keysOf(p)) .. (rebirths > 0 and (" · 환생 " .. rebirths) or ""))
end

local function refreshWindow()
	nextDropText.Text = nextDropLine()
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
	local order = 0
	local function head(value, color)
		order += 1
		local l = text(list, value, UDim2.new(1, -8, 0, BOARD_HEAD_ROW), UDim2.new(), 15, color)
		l.LayoutOrder = order
	end
	local function row(value, mine, first)
		order += 1
		local r = Instance.new("Frame")
		r.LayoutOrder = order
		r.Size = UDim2.new(1, -8, 0, BOARD_ROW)
		r.BackgroundColor3 = mine and COLOR_ME or COLOR_ROW
		r.Parent = list
		local round = Instance.new("UICorner")
		round.CornerRadius = UDim.new(0, 8)
		round.Parent = r
		local line = text(r, value, UDim2.new(1, -16, 1, 0), UDim2.fromOffset(8, 0), 14, first and COLOR_GOLD or nil)
		line.TextTruncate = Enum.TextTruncate.AtEnd
	end
	head(string.format("🌏 전 서버 TOP %d", Config.Leaderboard.Top), COLOR_HEAD_GLOBAL)
	local global = globalRanking()
	if #global == 0 then
		row("불러오는 중이거나 쓸 수 없어요 (스튜디오는 API 접근 필요)", false, false)
	end
	for i, entry in ipairs(global) do
		row(globalRowText(i, entry), entry.Name == player.DisplayName, i == 1)
	end
	head("🏠 이 서버", COLOR_HEAD_SERVER)
	for i, p in ipairs(ranking()) do
		row(rowText(i, p), p == player, i == 1)
	end
	head(string.format("📖 전 서버 도감 TOP %d", Config.Leaderboard.Top), COLOR_HEAD_GLOBAL)
	local dex = dexRanking()
	if #dex == 0 then
		row("불러오는 중이거나 쓸 수 없어요 (스튜디오는 API 접근 필요)", false, false)
	end
	for i, entry in ipairs(dex) do
		row(dexRowText(i, entry.Name, tonumber(entry.Count) or 0), entry.Name == player.DisplayName, i == 1)
	end
	head("📖 이 서버 도감", COLOR_HEAD_SERVER)
	local collectors = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if not p:GetAttribute("Developer") then -- (2026-10-04: never ranked)
			table.insert(collectors, p)
		end
	end
	table.sort(collectors, function(a, b)
		return (a:GetAttribute("CollectionCount") or 0) > (b:GetAttribute("CollectionCount") or 0)
	end)
	for i, p in ipairs(collectors) do
		row(dexRowText(i, p.DisplayName, p:GetAttribute("CollectionCount") or 0), p == player, i == 1)
	end
end

-- the board's own screen: faces the plaza, drawn on this client
local screenLines = {}
local function makeScreen(board)
	-- (2026-10-01, "nothing on the board; make it taller and carve the text in") a tall panel of its own in front of
	-- the board, facing the plaza, made on this screen (it stays when the board streams out): four big lines (no "서버 게시판" title:
	-- the board says what it is)
	local part = board:FindFirstChildWhichIsA("BasePart", true)
	if not part then
		return false -- (not streamed in yet: tried again)
	end
	local cf, size = board:GetBoundingBox()
	local toMiddle = Vector3.new(-cf.Position.X, 0, -cf.Position.Z)
	toMiddle = toMiddle.Magnitude > 1e-3 and toMiddle.Unit or Vector3.zAxis
	local width = math.max(PANEL_MIN_WIDTH, math.max(size.X, size.Z))
	local ground = cf.Position.Y - size.Y / 2
	local center = Vector3.new(cf.Position.X, ground + PANEL_LIFT + PANEL_HEIGHT / 2, cf.Position.Z)
		+ toMiddle * (math.min(size.X, size.Z) / 2 + PANEL_FRONT)
	local panel = Instance.new("Part")
	panel.Name = "BoardPanel"
	panel.Anchored, panel.CanCollide, panel.CanQuery, panel.CanTouch = true, false, false, false
	panel.Size = Vector3.new(width, PANEL_HEIGHT, PANEL_THICKNESS)
	panel.CFrame = CFrame.lookAt(center, center + toMiddle) -- its front toward the plaza
	panel.Color = PANEL_FRAME
	panel.Material = Enum.Material.WoodPlanks
	panel.Parent = Workspace
	local surface = Instance.new("SurfaceGui")
	surface.Name = "BoardScreen"
	surface.Adornee = panel
	surface.Face = Enum.NormalId.Front
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = PANEL_PIXELS_PER_STUD
	surface.LightInfluence = 0
	surface.ResetOnSpawn = false
	surface.Parent = player.PlayerGui
	local back = Instance.new("Frame")
	back.AnchorPoint = Vector2.new(0.5, 0.5)
	back.Position = UDim2.fromScale(0.5, 0.5)
	back.Size = UDim2.new(1, -PANEL_BORDER_PX * 2, 1, -PANEL_BORDER_PX * 2)
	back.BackgroundColor3 = COLOR_SCREEN
	back.Parent = surface
	local rows = 4
	local function line(y, color)
		local l = Instance.new("TextLabel")
		l.BackgroundTransparency = 1
		l.Font = FONT
		l.TextScaled = true
		l.TextColor3 = color or Color3.new(1, 1, 1)
		l.Position = UDim2.new(0, 10, y / rows, 3)
		l.Size = UDim2.new(1, -20, 1 / rows, -6)
		l.Text = ""
		l.Parent = back
		return l
	end
	screenLines.drop = line(0, COLOR_GOLD)
	screenLines.here = line(1, COLOR_HEAD_SERVER)
	screenLines.world = line(2, COLOR_HEAD_GLOBAL)
	screenLines.me = line(3)
	return true
end

task.spawn(function()
	local map = Workspace:WaitForChild("Map")
	local built = false -- (the board streams in whenever: tried every second until it is there)
	while true do
		if not built then
			local zone = map:FindFirstChild("KeyZone")
			local board = zone and zone:FindFirstChild("Zone_Leaderboard")
			built = board ~= nil and makeScreen(board)
		end
		if screenLines.drop then
			local big = ReplicatedStorage:GetAttribute("NextKeyDropBig") == true
			Lang.set(screenLines.drop, nextDropLine() .. (big and "  ⚡ 대박 드랍!" or ""))
			screenLines.drop.TextColor3 = big and COLOR_BIG_DROP or COLOR_GOLD
			local ranked = ranking()
			local top, first = ranked[1], globalRanking()[1]
			Lang.set(screenLines.here, top and string.format("🏠 이 서버 1등 %s · %s", top.DisplayName,
				Formulas.levelText(top:GetAttribute("DefenseLevel") or 1, top:GetAttribute("Rebirths") or 0)) or "🏠 이 서버 1등 -")
			Lang.set(screenLines.world, first and string.format("🌏 전 서버 1등 %s · %s", tostring(first.Name),
				Formulas.levelText(first.Level or 1, Formulas.tierOfLevel(first.Level or 1))) or "🌏 전 서버 1등 불러오는 중…")
			local mine = table.find(ranked, player)
			Lang.set(screenLines.me, (mine and string.format("🙋 나: 이 서버 %d위 / %d명", mine, #ranked) or "")
				.. "  · 눌러서 자세히")
		end
		if window.Visible then
			Lang.set(nextDropText, nextDropLine())
		end
		task.wait(1)
	end
end)

local boardPrompt = nil
ProximityPromptService.PromptTriggered:Connect(function(prompt)
	local kind = prompt:GetAttribute("Kind")
	local base = prompt:GetAttribute("Base")
	for _, npc in pairs(npcs) do
		if npc.kind == kind and npc.base == base then
			react(npc)
		end
	end
	if kind == "Board" then
		if window.Visible then -- E again closes it
			window.Visible = false
			return
		end
		boardPrompt = prompt
		refreshWindow()
		window.Visible = true
	end
end)

Players.PlayerAdded:Connect(function()
	if window.Visible then
		refreshWindow()
	end
end)
for _, name in ipairs({ "GlobalRanking", "DexTop" }) do
	ReplicatedStorage:GetAttributeChangedSignal(name):Connect(function()
		if window.Visible then
			refreshWindow()
		end
	end)
end
Players.PlayerRemoving:Connect(function()
	if window.Visible then
		task.defer(refreshWindow)
	end
end)

RunService.Heartbeat:Connect(FrameMeter.wrap("Npcs", function() -- walked away from the board: close it
	if window.Visible and boardPrompt then
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		local part = boardPrompt.Parent
		if not root or not part or not part:IsA("BasePart")
			or (root.Position - part.Position).Magnitude > boardPrompt.MaxActivationDistance + BOARD_WALK_AWAY then
			window.Visible = false
		end
	end
end))

-- (2026-10-04, "글을 읽기 싫어하는 애들 어떻게 잡을까" → "제안은 전부 진행") a bouncing ❗ over my own base's shop NPC while
-- something there can be bought, and over the key stall's while a key can (local attributes ShopReady / KeyShopReady,
-- worked out by Hud.client); seen from afar, no reading needed
local READY_KINDS = { Shop = "ShopReady", KeyShop = "KeyShopReady" }
local READY_CHECK_EVERY = 0.5
local READY_SIZE = UDim2.fromOffset(46, 46)
local READY_DISTANCE = 220
local READY_BOUNCE = 0.6 -- studs up and down
local READY_COLOR = Color3.fromRGB(255, 210, 60)
local readyMarks = {} -- [npc] = BillboardGui
task.spawn(function()
	while true do
		task.wait(READY_CHECK_EVERY)
		local base = player:GetAttribute("Base")
		for model, npc in pairs(npcs) do
			local attribute = READY_KINDS[npc.kind]
			local want = attribute ~= nil and npc.base == base and player:GetAttribute(attribute) == true
				and npc.anchor ~= nil and npc.anchor.Parent ~= nil
			local mark = readyMarks[npc]
			if want and not (mark and mark.Parent) then
				mark = Instance.new("BillboardGui")
				mark.Name = "ReadyMark"
				mark.Size = READY_SIZE
				mark.AlwaysOnTop = true
				mark.MaxDistance = READY_DISTANCE
				mark.LightInfluence = 0
				mark.StudsOffsetWorldSpace = Vector3.new(0, npc.above + 2, 0)
				local text = Instance.new("TextLabel")
				text.Size = UDim2.fromScale(1, 1)
				text.BackgroundTransparency = 1
				text.Font = Enum.Font.GothamBlack
				text.TextScaled = true
				text.TextColor3 = READY_COLOR
				text.TextStrokeTransparency = 0
				text.Text = "❗"
				text.Parent = mark
				mark.Adornee = npc.anchor
				mark.Parent = npc.anchor
				readyMarks[npc] = mark
				TweenService:Create(mark, TweenInfo.new(0.45, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
					{ StudsOffsetWorldSpace = Vector3.new(0, npc.above + 2 + READY_BOUNCE, 0) }):Play()
			elseif not want and mark then
				mark:Destroy()
				readyMarks[npc] = nil
			end
		end
		for npc, mark in pairs(readyMarks) do -- (NPCs gone)
			if not npcs[npc.model] then
				mark:Destroy()
				readyMarks[npc] = nil
			end
		end
	end
end)
