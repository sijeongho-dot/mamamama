local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local Sfx = require(Shared:WaitForChild("Sfx"))

local player = Players.LocalPlayer

local WALL = { Out = 1.5, Height = 700, Below = 40, Thick = 1, Color = Color3.new(0, 0, 0) }
local LIFT_SECONDS = 2.5
local LOOK_EVERY = 1
local CAMERA_IN = 1
local CAMERA_STEP = "BaseVoidCamera"
local GROUND_SLACK = 0.5
local HIDE_MAX_SIZE = 400
local MIN_PIECE = 0.05
local EPS = 0.01
local OUTSIDE = { "Decor", "FieldDecor", "TrafficLights" }
local AWAY = { "Racing", "HideSeekRoom", "Cinematic" }

local folder = Instance.new("Folder")
folder.Name = "BaseVoid"
folder.Parent = Workspace

local built = nil

local function away()
	if ReplicatedStorage:GetAttribute("TutorialField") then
		return true
	end
	for _, name in ipairs(AWAY) do
		if player:GetAttribute(name) then
			return true
		end
	end
	return false
end

local function myBase()
	local map = Workspace:FindFirstChild("Map")
	local base = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
	return map, base, base and base:FindFirstChild("SafeZone")
end

local function grown(rects)
	local list = {}
	for _, r in ipairs(rects) do
		table.insert(list, { r[1] - WALL.Out, r[2] + WALL.Out, r[3] - WALL.Out, r[4] + WALL.Out })
	end
	return list
end

local function inside(rects, x, z)
	for _, r in ipairs(rects) do
		if x > r[1] and x < r[2] and z > r[3] and z < r[4] then
			return true
		end
	end
	return false
end

local function subtract(pieces, a, b)
	local out = {}
	for _, p in ipairs(pieces) do
		if b <= p[1] or a >= p[2] then
			table.insert(out, p)
		else
			if a > p[1] then
				table.insert(out, { p[1], a })
			end
			if b < p[2] then
				table.insert(out, { b, p[2] })
			end
		end
	end
	return out
end

local function sides(rects)
	local list = {}
	for _, r in ipairs(rects) do
		for _, side in ipairs({
			{ axis = "Z", at = r[4], from = r[1], to = r[2], out = 1 },
			{ axis = "Z", at = r[3], from = r[1], to = r[2], out = -1 },
			{ axis = "X", at = r[2], from = r[3], to = r[4], out = 1 },
			{ axis = "X", at = r[1], from = r[3], to = r[4], out = -1 },
		}) do
			local pieces = { { side.from, side.to } }
			local beyond = side.at + side.out * EPS
			for _, q in ipairs(rects) do
				if side.axis == "Z" and q[3] < beyond and q[4] > beyond then
					pieces = subtract(pieces, q[1], q[2])
				elseif side.axis == "X" and q[1] < beyond and q[2] > beyond then
					pieces = subtract(pieces, q[3], q[4])
				end
			end
			for _, p in ipairs(pieces) do
				local a, b = p[1], p[2]
				if b - a > MIN_PIECE then
					local function open(along)
						if side.axis == "Z" then
							return inside(rects, along, beyond)
						end
						return inside(rects, beyond, along)
					end
					if not open(a - EPS) then
						a -= WALL.Thick
					end
					if not open(b + EPS) then
						b += WALL.Thick
					end
					table.insert(list, { axis = side.axis, at = side.at + side.out * WALL.Thick / 2, from = a, to = b })
				end
			end
		end
	end
	return list
end

local function wallPart(b, side)
	local h = WALL.Height + WALL.Below
	local y = -b.halfY - WALL.Below + h / 2
	local mid, long = (side.from + side.to) / 2, side.to - side.from
	local p = Instance.new("Part")
	p.Name = "Void"
	p.Anchored = true
	p.CanCollide = true
	p.CanQuery = true
	p.CanTouch = false
	p.CastShadow = false
	p.Material = Enum.Material.Neon
	p.Color = WALL.Color
	p.Transparency = 0
	if side.axis == "Z" then
		p.Size = Vector3.new(long, h, WALL.Thick)
		p.CFrame = b.cf * CFrame.new(mid, y, side.at)
	else
		p.Size = Vector3.new(WALL.Thick, h, long)
		p.CFrame = b.cf * CFrame.new(side.at, y, mid)
	end
	p.Parent = folder
	return p
end

local function straddles(b, part)
	if not part:IsA("BasePart") or (b.base and part:IsDescendantOf(b.base)) then
		return false
	end
	local s = part.Size
	if s.X > HIDE_MAX_SIZE or s.Y > HIDE_MAX_SIZE or s.Z > HIDE_MAX_SIZE then
		return false
	end
	local cf = b.cf:ToObjectSpace(part.CFrame)
	local h = s / 2
	local x, y, z = cf.XVector, cf.YVector, cf.ZVector
	local ex = math.abs(x.X) * h.X + math.abs(y.X) * h.Y + math.abs(z.X) * h.Z
	local ey = math.abs(x.Y) * h.X + math.abs(y.Y) * h.Y + math.abs(z.Y) * h.Z
	local ez = math.abs(x.Z) * h.X + math.abs(y.Z) * h.Y + math.abs(z.Z) * h.Z
	local p = cf.Position
	if p.Y + ey <= -b.halfY + GROUND_SLACK then
		return false
	end
	local x0, x1, z0, z1 = p.X - ex, p.X + ex, p.Z - ez, p.Z + ez
	local touches = false
	for _, r in ipairs(b.rects) do
		if x0 >= r[1] and x1 <= r[2] and z0 >= r[3] and z1 <= r[4] then
			return false
		end
		if x1 > r[1] and x0 < r[2] and z1 > r[3] and z0 < r[4] then
			touches = true
		end
	end
	return touches
end

local function tuck(b, part)
	if b.hidden[part] == nil and straddles(b, part) then
		b.hidden[part] = part.CanCollide
		part.LocalTransparencyModifier = 1
		part.CanCollide = false
	end
end

local function holdCamera()
	local b = built
	local camera = Workspace.CurrentCamera
	if not b or not camera then
		return
	end
	local cf = camera.CFrame
	local p = b.cf:PointToObjectSpace(cf.Position)
	local x, z = p.X, p.Z
	if not Formulas.inRects(b.rects, x, z, CAMERA_IN) then
		x, z = Formulas.intoRects(b.rects, x, z, CAMERA_IN)
	end
	local y = math.min(p.Y, -b.halfY + WALL.Height - CAMERA_IN)
	if x ~= p.X or y ~= p.Y or z ~= p.Z then
		camera.CFrame = CFrame.new(b.cf:PointToWorldSpace(Vector3.new(x, y, z))) * cf.Rotation
	end
end

local function build(map, base, zone, text, rects)
	local b = { cf = zone.CFrame, halfY = zone.Size.Y / 2, base = base, text = text, rects = grown(rects), parts = {},
		hidden = {}, watches = {} }
	for _, side in ipairs(sides(b.rects)) do
		table.insert(b.parts, wallPart(b, side))
	end
	built = b
	for _, name in ipairs(OUTSIDE) do
		local holder = map:FindFirstChild(name)
		if holder then
			for _, d in ipairs(holder:GetDescendants()) do
				tuck(b, d)
			end
			table.insert(b.watches, holder.DescendantAdded:Connect(function(d)
				if built == b then
					tuck(b, d)
				end
			end))
		end
	end
	RunService:BindToRenderStep(CAMERA_STEP, Enum.RenderPriority.Camera.Value + 1, FrameMeter.wrap("BaseVoid", holdCamera))
end

local function release(b)
	RunService:UnbindFromRenderStep(CAMERA_STEP)
	for _, c in ipairs(b.watches) do
		c:Disconnect()
	end
	for part, collide in pairs(b.hidden) do
		if part.Parent then
			part.LocalTransparencyModifier = 0
			part.CanCollide = collide
		end
	end
end

local function fadeOut(parts)
	local began = os.clock()
	local fade
	fade = RunService.RenderStepped:Connect(FrameMeter.wrap("BaseVoid", function()
		local k = math.clamp((os.clock() - began) / LIFT_SECONDS, 0, 1)
		for _, p in ipairs(parts) do
			p.CanCollide = false
			p.Transparency = k
		end
		if k >= 1 then
			fade:Disconnect()
			for _, p in ipairs(parts) do
				p:Destroy()
			end
		end
	end))
end

local function refresh()
	local text = player:GetAttribute("OpenArea")
	local rects = not away() and Formulas.rectsOf(text) or nil
	local map, base, zone = myBase()
	local old = built
	if rects and old and old.text == text and (not zone or zone.CFrame == old.cf) then
		return
	end
	built = nil
	if old then
		release(old)
	end
	if rects and map and zone then
		build(map, base, zone, text, rects)
	end
	if not old then
		return
	end
	if away() then
		for _, p in ipairs(old.parts) do
			p:Destroy()
		end
		return
	end
	Sfx.play("WindGust")
	fadeOut(old.parts)
end

for _, name in ipairs({ "OpenArea", "Base", table.unpack(AWAY) }) do
	player:GetAttributeChangedSignal(name):Connect(refresh)
end
ReplicatedStorage:GetAttributeChangedSignal("TutorialField"):Connect(refresh)
task.spawn(function()
	while true do
		refresh()
		task.wait(LOOK_EVERY)
	end
end)
