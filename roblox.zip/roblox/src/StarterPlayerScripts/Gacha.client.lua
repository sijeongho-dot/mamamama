--[[
Gacha: the draw screen and the odds window (design 4.3-4.6, 14 확률 공개; grey-box UI, the full
effects come with the art and UI stages).

- "뽑기" (top-right row, Shared/TopBar) opens the draw screen: a tab per key grade (Config.Keys.Types, with
  the player's count), "1번 뽑기" / "10번 뽑기" with the chosen grade (Net ask Draw; the server rolls and
  answers the results) and the text button "확률 보기" next to them (the chosen grade's odds).
- Results are revealed one by one as cards with a small picture of the dino (Shared/DinoPortrait); better rarities take longer and flash their color, Legendary
  and up get a big banner and their own show (Shared/GachaFx: from Mythic a wait with a glowing orb
  first, then flash, light rays, emoji, sound; the card pops in big).
- (2026-10-02) The draw screen's top left: this week's limited dino and the time left ("🎖️ 이번 주 한정:
  스피노 · ⏳ 2일 5시간"; ReplicatedStorage LimitedSpecies / LimitedEndsAt, the Limited service). A dino
  from its share shows 🎖️ before its name.
- The odds window lists every possible result with its chance, step by step (limited dino, species,
  rarity, size, mutation), for the player's current defense level and any luck, from the same
  Formulas.gachaOdds the server rolls with.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")
local TweenService = game:GetService("TweenService")
local MarketplaceService = game:GetService("MarketplaceService")
local RunService = game:GetService("RunService")
local ProximityPromptService = game:GetService("ProximityPromptService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local TopBar = require(Shared:WaitForChild("TopBar"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local GachaFx = require(Shared:WaitForChild("GachaFx"))
local Prices = require(Shared:WaitForChild("Prices"))
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local Coach = require(Shared:WaitForChild("Coach"))
local ShareMoment = require(Shared:WaitForChild("ShareMoment"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local PANEL_SIZE = UDim2.fromOffset(500, 476)
local RESULT_SIZE = UDim2.fromOffset(500, 360) -- the results window over the draw screen
local KEY_CARD = UDim2.fromOffset(148, 184)
local KEY_CARD_GAP = 8
local KEY_CARDS_TOP = 46
local KEY_CARD_BUTTON = 26
local KEY_ICON = 36
local CHIP = 13
local CHIP_GAP = 2
local CHIP_SIDE = 5
local CHIPS_TOP = KEY_ICON + 26
local SHINE = {
	BestEdge = 2, BestEdgePulse = 1.5, PulseSpeed = 4, Stroke = Color3.fromRGB(20, 20, 30), Spin = 120, OddsChip = 14,
	CardTint = 0.3, ChipText = 12, LockedText = 0.35,
}
local CAPSULE = { Size = 1.3, Radius = 4.2, Up = 2.5, Bob = 0.5, BobSpeed = 2, Spin = 0.6, Draw = 160, HueSpeed = 0.25 }
local STRIKE_COLOR = Color3.fromRGB(255, 30, 30)
local STRIKE_THICKNESS = 3
local LOCKED_CHIP_SEE_THROUGH = 0.55
local LOCK_LINE_COLOR = Color3.fromRGB(255, 130, 130)
local ODDS_SIZE = UDim2.fromOffset(420, 440)
local CARD_SIZE = UDim2.fromOffset(88, 117)
local CARD_PORTRAIT = 60 -- the dino picture at the top of a card
local CARD_COLUMNS = 5
local REVEAL_BASE, REVEAL_PER_RARITY = 0.12, 0.06 -- seconds before each card shows
local BANNER_FROM = 5 -- rarity number (Legendary) and up get the big banner
local BANNER_SECONDS = 1.4 -- (at least; a unique rarity's show keeps it up longer, GachaFx.life)
local CARD_POP = 1.8 -- a unique card pops in this much bigger
local CARD_POP_SECONDS = 0.45
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_CARD = Color3.fromRGB(40, 44, 60)
local COLOR_LOCKED_SPECIES = Color3.fromRGB(230, 160, 90) -- "🔒 아직 안 나오는 공룡" in the odds
local COLOR_BUTTON = Color3.fromRGB(80, 190, 110)
local COLOR_ODDS = Color3.fromRGB(70, 140, 230)
local COLOR_CLOSE = Color3.fromRGB(235, 70, 80)
local COLOR_DISABLED = Color3.fromRGB(110, 110, 120)
local COLOR_OK = Color3.fromRGB(70, 140, 230)
local COLOR_SHARE = Color3.fromRGB(255, 105, 160)
local OK_SIZE = UDim2.fromOffset(110, 40)
local EXCHANGE_HINT = "🔄 같은 열쇠 10개 → 윗등급 1개! 열쇠 가판대에서 교환"
local COLOR_HINT = Color3.fromRGB(170, 200, 255)
local NEW_BADGE_SIZE = 26 -- "🆕" on the 뽑기 button after an awakening opened or raised something
local NEW_BADGE_COLOR = Color3.fromRGB(235, 60, 70)
local LIMITED_SIZE = UDim2.fromOffset(190, 28) -- the limited dino line at the draw screen's top left
local TABLE_BUTTON_SIZE = UDim2.fromOffset(92, 34) -- "📋 등급표", left of the X
local COLOR_LIMITED = Color3.fromRGB(255, 205, 60)
local COLOR_LIMITED_BG = Color3.fromRGB(70, 55, 30)
local BOX_PANEL_SIZE = UDim2.fromOffset(440, 380)
local BOX_CARD = UDim2.fromOffset(96, 128)
local BOX_CARD_GAP = 6
local BOX_CARD_ICON = 48
local BOX_CARD_BUTTON = 24
local BOX_LIST_TOP = 104
local BOX_OPEN_ALL_SIZE = UDim2.fromOffset(190, 36)
local BOX_TOP_GAP = 4
local COLOR_RUSH = Color3.fromRGB(240, 150, 30)
local COLOR_FREE = Color3.fromRGB(60, 180, 110)
local COLOR_FREE_SHINE = Color3.fromRGB(255, 230, 90)
local BOX_PILL_GAP = 4
local BOX_PILL_HEIGHT = 24
local BOX_PULSE_SPEED = 6
local BOX_TICK = 0.5
local BOX_PULSE_STEP = 0.1
local BOX_SHOW_GAP = 0.08
local BOX_SMALLEST, BOX_BIGGEST = 0.4, 1
local BOX_LID_SHARE = 0.24
local BOX_RIBBON_SHARE = 0.16
local BOX_LID_DARKEN = 0.25
local COLOR_BOX_PILL = Color3.fromRGB(70, 50, 30)
local COLOR_BOX_READY = Color3.fromRGB(235, 170, 40)
local COLOR_RIBBON = Color3.fromRGB(255, 250, 240)
local COLOR_WAIT = Color3.fromRGB(200, 204, 215)
local FAST_REVEAL_FROM = 11
local FAST_REVEAL = 0.03
local MACHINE_BADGE_SIZE = UDim2.fromScale(9, 2)
local MACHINE_BADGE_UP = 7
local MACHINE_BADGE_BOB = 0.6
local MACHINE_BADGE_BOB_SECONDS = 0.9
local MACHINE_BADGE_COLOR = Color3.fromRGB(255, 225, 90)
local MACHINE_BADGE_DISTANCE = 160
local RARITY_COLORS = {
	Common = Color3.fromRGB(170, 170, 170), Uncommon = Color3.fromRGB(90, 200, 90), Rare = Color3.fromRGB(70, 140, 255),
	Epic = Color3.fromRGB(170, 90, 230), Legendary = Color3.fromRGB(255, 150, 40), Mythic = Color3.fromRGB(240, 60, 60),
	Transcendent = Color3.fromRGB(255, 100, 200), Rainbow = Color3.fromRGB(120, 230, 255), Golden = Color3.fromRGB(255, 210, 60),
	Onyx = Color3.fromRGB(120, 60, 170), Celestial = Color3.fromRGB(255, 255, 255), Secret = Color3.fromRGB(255, 240, 150),
	Cosmic = Color3.fromRGB(110, 90, 240), Primeval = Color3.fromRGB(255, 160, 40), Divine = Color3.fromRGB(255, 245, 200),
	Special = Color3.fromRGB(190, 140, 255), -- (2026-10-04) ⭐ 특별, given only
}

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.TextWrapped = true
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 17
	b.TextColor3 = Color3.new(1, 1, 1)
	b.Text = text
	b.BackgroundColor3 = color
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 10)
	return b
end

-- shrink a window to fit small (phone) screens
local function fitToScreen(frame)
	require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Windows")).fit(frame)
end

local function percentText(p)
	if p == 0 then
		return "0%"
	end
	local s = string.format("%.4f", p):gsub("0+$", ""):gsub("%.$", "")
	return s .. "%"
end

local function normalKeys()
	return player:GetAttribute("Keys") or 0
end

local function oddsOptions()
	local server = (ReplicatedStorage:GetAttribute("ServerLuckUntil") or 0) > Workspace:GetServerTimeNow()
		and (ReplicatedStorage:GetAttribute("ServerLuck") or 1) or 1
	return {
		luckCap = Formulas.luckCap(player:GetAttribute("Luck"), server), -- (as the server)
		luck = (player:GetAttribute("Luck") or 1) * (1 + (player:GetAttribute("BonusRareChance") or 0)) -- as the server
			* ((ReplicatedStorage:GetAttribute("ServerLuckUntil") or 0) > Workspace:GetServerTimeNow()
				and (ReplicatedStorage:GetAttribute("ServerLuck") or 1) or 1),
		limitedPotion = player:GetAttribute("LimitedPotion") == true,
		limitedSpecies = ReplicatedStorage:GetAttribute("LimitedSpecies"),
		mutationEvent = ReplicatedStorage:GetAttribute("MutationEvent") == true,
		rebirths = player:GetAttribute("Rebirths") or 0, -- (the awakened variants, as the server)
	}
end

local gui = Instance.new("ScreenGui")
gui.Name = "Gacha"
gui.ResetOnSpawn = false
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling -- the odds window (ZIndex 5) covers the draw screen
gui.Parent = player:WaitForChild("PlayerGui")

local openButton = TopBar.button("🎰 뽑기", 3, Color3.fromRGB(240, 120, 60))
TopBar.pin(openButton)

-- (2026-10-02) "🆕" on the button when an awakening in this session opened a rarity or a key grade in the
-- shop, or made a newly opened rarity commoner (Config.Gacha.NewRarityScale); opening the draw screen clears it
local newBadge = Instance.new("TextLabel")
newBadge.Name = "NewBadge"
newBadge.AnchorPoint = Vector2.new(0.75, 0.25)
newBadge.Position = UDim2.new(1, 0, 0, 0)
newBadge.Size = UDim2.fromOffset(NEW_BADGE_SIZE, NEW_BADGE_SIZE)
newBadge.BackgroundColor3 = NEW_BADGE_COLOR
newBadge.Text = "🆕"
newBadge.TextScaled = true
newBadge.Font = FONT
newBadge.TextColor3 = Color3.new(1, 1, 1)
newBadge.ZIndex = openButton.ZIndex + 1
newBadge.Visible = false
newBadge.Parent = openButton
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = newBadge
end
-- does reaching this many awakenings change what the draw gives or the key shop sells?
local function awakeningNews(rebirths)
	local steps = #Config.Gacha.NewRarityScale
	for _, r in ipairs(Config.Rarities) do
		local at = r.UnlockRebirths or 0
		if at > 0 and rebirths >= at and rebirths <= at + steps then
			return true
		end
	end
	for _, t in ipairs(Config.Keys.Types) do
		if (t.ShopRebirths or 0) == rebirths and rebirths > 0 then
			return true
		end
	end
	return false
end
do
	local seen = player:GetAttribute("Rebirths") -- nil until the profile loads: that first value is no news
	player:GetAttributeChangedSignal("Rebirths"):Connect(function()
		local now = player:GetAttribute("Rebirths") or 0
		if seen ~= nil and now > seen and awakeningNews(now) then
			newBadge.Visible = true
		end
		seen = now
	end)
end

-- ---------------------------------------------------------------------------
-- Draw screen
-- ---------------------------------------------------------------------------

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(0.5, 0.5)
panel.Position = UDim2.fromScale(0.5, 0.5)
panel.Size = PANEL_SIZE
panel.BackgroundColor3 = COLOR_BG
panel.Visible = false
panel.Parent = gui
corner(panel, 14)
fitToScreen(panel)
label(panel, "뽑기", UDim2.new(1, 0, 0, 34), UDim2.fromOffset(0, 6), 24)
local close = button(panel, "X", COLOR_CLOSE, UDim2.fromOffset(34, 34), UDim2.new(1, -42, 0, 8))
-- (2026-10-02) the rarities and when each opens: the odds window, its table first
local tableButton = button(panel, "📋 등급표", COLOR_ODDS, TABLE_BUTTON_SIZE, UDim2.new(1, -50 - TABLE_BUTTON_SIZE.X.Offset, 0, 8))
tableButton.TextSize = 13
-- this week's limited dino and the time left (2026-10-02)
local limitedLine = label(panel, "", LIMITED_SIZE, UDim2.fromOffset(12, 9), 12)
limitedLine.BackgroundTransparency = 0
limitedLine.BackgroundColor3 = COLOR_LIMITED_BG
limitedLine.TextColor3 = COLOR_LIMITED
limitedLine.TextScaled = true
corner(limitedLine, 8)
local function showLimited()
	local species = ReplicatedStorage:GetAttribute("LimitedSpecies")
	local endsAt = ReplicatedStorage:GetAttribute("LimitedEndsAt")
	limitedLine.Visible = species ~= nil
	if species then
		local left = math.max(0, (endsAt or 0) - Workspace:GetServerTimeNow())
		local d, h, m = left // 86400, left % 86400 // 3600, left % 3600 // 60
		limitedLine.Text = string.format("🎖️ 이번 주 한정: %s · ⏳ %s", Formulas.species(species).Name,
			d > 0 and string.format("%d일 %d시간", d, h) or string.format("%d시간 %d분", h, m))
	end
end
showLimited()
task.spawn(function()
	while true do
		task.wait(1)
		if panel.Visible then
			showLimited()
		end
	end
end)
-- one row per key grade (등급별 뽑기): its saved keys, "1번", "N번" (every key up to 10) and its odds.
-- A draw uses that grade's keys and gets its luck and lowest rarity.
local spinning = setmetatable({}, { __mode = "k" })
local selected = "Normal" -- the grade of the last draw or odds window
local rows = {} -- [grade Id] = { keys, one, many, odds }
local function gradeColor(t)
	return t.Rgb and Color3.fromRGB(table.unpack(t.Rgb)) or Color3.fromRGB(255, 205, 60)
end
local function keysOf(grade)
	return grade == "Normal" and normalKeys() or (player:GetAttribute("Keys" .. grade) or 0)
end
local openOdds -- defined below
local doDraw -- defined below
local keyCards = Instance.new("Frame")
keyCards.AnchorPoint = Vector2.new(0.5, 0)
keyCards.Position = UDim2.new(0.5, 0, 0, KEY_CARDS_TOP)
keyCards.Size = UDim2.fromOffset(3 * KEY_CARD.X.Offset + 2 * KEY_CARD_GAP, 2 * KEY_CARD.Y.Offset + KEY_CARD_GAP)
keyCards.BackgroundTransparency = 1
keyCards.Parent = panel
do
	local cardLayout = Instance.new("UIGridLayout")
	cardLayout.CellSize = KEY_CARD
	cardLayout.CellPadding = UDim2.fromOffset(KEY_CARD_GAP, KEY_CARD_GAP)
	cardLayout.SortOrder = Enum.SortOrder.LayoutOrder
	cardLayout.Parent = keyCards
end
for i, t in ipairs(Config.Keys.Types) do
	local row = Instance.new("Frame")
	row.LayoutOrder = i
	row.Size = KEY_CARD
	row.Position = UDim2.fromOffset((i - 1) % 3 * (KEY_CARD.X.Offset + KEY_CARD_GAP),
		(i - 1) // 3 * (KEY_CARD.Y.Offset + KEY_CARD_GAP))
	row.BackgroundColor3 = Color3.fromRGB(40, 44, 60)
	row.Parent = keyCards
	corner(row, 10)
	local edge = Instance.new("UIStroke")
	edge.Color = gradeColor(t)
	edge.Thickness = 2
	edge.Parent = row
	local keyPicture = DinoPortrait.key(t.Id, UDim2.fromOffset(KEY_ICON, KEY_ICON))
	keyPicture.AnchorPoint = Vector2.new(0.5, 0)
	keyPicture.Position = UDim2.new(0.5, 0, 0, 4)
	keyPicture.Parent = row
	local name = label(row, "", UDim2.new(1, -8, 0, 18), UDim2.fromOffset(4, KEY_ICON + 6), 14)
	name.TextColor3 = gradeColor(t)
	name.TextScaled = true
	local chipsRow = Instance.new("Frame")
	chipsRow.BackgroundTransparency = 1
	chipsRow.Size = UDim2.new(1, -2 * CHIP_SIDE, 0, 4 * CHIP + 3 * CHIP_GAP)
	chipsRow.Position = UDim2.fromOffset(CHIP_SIDE, CHIPS_TOP)
	chipsRow.Parent = row
	local chipsLayout = Instance.new("UIGridLayout")
	chipsLayout.CellSize = UDim2.new(0.5, -CHIP_GAP / 2, 0, CHIP)
	chipsLayout.CellPadding = UDim2.fromOffset(CHIP_GAP, CHIP_GAP)
	chipsLayout.SortOrder = Enum.SortOrder.LayoutOrder
	chipsLayout.Parent = chipsRow
	local chips = {}
	local from = t.FloorRarity and table.find(Config.Rarities, Formulas.rarity(t.FloorRarity)) or 1
	local to = t.MaxRarity and table.find(Config.Rarities, Formulas.rarity(t.MaxRarity)) or #Config.Rarities
	for j = from, to do
		local r = Config.Rarities[j]
		if r.ChancePercent and r.ChancePercent > 0 then
			local chip = Instance.new("Frame")
			chip.LayoutOrder = j
			chip.Parent = chipsRow
			corner(chip, 5)
			local paint, rainbow = DinoPortrait.paint(chip, r.Id)
			if rainbow then
				spinning[paint] = true
			end
			local word = label(chip, r.Name, UDim2.new(1, -4, 1, 0), UDim2.fromOffset(2, 0), SHINE.ChipText)
			word.Font = Enum.Font.GothamBlack
			word.TextScaled = true
			word.TextWrapped = false
			word.TextStrokeTransparency = 0
			word.TextStrokeColor3 = SHINE.Stroke
			local most = Instance.new("UITextSizeConstraint")
			most.MaxTextSize = SHINE.ChipText
			most.Parent = word
			local edge = Instance.new("UIStroke")
			edge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			edge.Color = Color3.new(1, 1, 1)
			edge.Thickness = SHINE.BestEdge
			edge.Enabled = false
			edge.Parent = chip
			local strike = Instance.new("Frame")
			strike.AnchorPoint = Vector2.new(0.5, 0.5)
			strike.Position = UDim2.fromScale(0.5, 0.5)
			strike.Size = UDim2.new(1, -4, 0, STRIKE_THICKNESS)
			strike.BackgroundColor3 = STRIKE_COLOR
			strike.BorderSizePixel = 0
			strike.ZIndex = word.ZIndex + 1
			strike.Visible = false
			strike.Parent = chip
			table.insert(chips, { rarity = r, chip = chip, strike = strike, edge = edge, word = word })
		end
	end
	local half = UDim2.new(0.5, -6, 0, KEY_CARD_BUTTON)
	local one = button(row, "🎲 1번", COLOR_BUTTON, half, UDim2.new(0, 4, 1, -2 * KEY_CARD_BUTTON - 8))
	local many = button(row, "🎲 10번", COLOR_BUTTON, half, UDim2.new(0.5, 2, 1, -2 * KEY_CARD_BUTTON - 8))
	local odds = button(row, "📊 확률", COLOR_ODDS, UDim2.new(1, -8, 0, KEY_CARD_BUTTON), UDim2.new(0, 4, 1, -KEY_CARD_BUTTON - 4))
	one.TextSize, many.TextSize, odds.TextSize = 13, 13, 13
	if t.Id == "Normal" then
		Coach.mark(one, "DrawOne")
		Coach.mark(many, "DrawMany")
	end
	one.Activated:Connect(function()
		if keysOf(t.Id) >= 1 then
			selected = t.Id
			doDraw(1)
		end
	end)
	many.Activated:Connect(function()
		local keys = keysOf(t.Id)
		if keys >= 2 then
			selected = t.Id
			doDraw(Formulas.bulkDrawCount(keys))
		end
	end)
	odds.Activated:Connect(function()
		selected = t.Id
		openOdds()
	end)
	rows[t.Id] = { keys = name, one = one, many = many, chips = chips }
end
local lockLine = label(panel, "", UDim2.new(1, -28, 0, 18), UDim2.new(0, 14, 1, -50), 13)
lockLine.TextColor3 = LOCK_LINE_COLOR
lockLine.TextScaled = true
local message = label(panel, "", UDim2.new(1, -28, 0, 20), UDim2.new(0, 14, 1, -28), 14)
message.TextColor3 = Color3.fromRGB(255, 180, 180)
-- (2026-10-01) where no message is, a reminder that keys can be traded up at the key stall
local exchangeHint = label(panel, EXCHANGE_HINT, UDim2.new(1, -28, 0, 20), UDim2.new(0, 14, 1, -28), 13)
exchangeHint.TextColor3 = COLOR_HINT
exchangeHint.TextScaled = true -- (one line on a small phone too)
message:GetPropertyChangedSignal("Text"):Connect(function()
	exchangeHint.Visible = message.Text == ""
end)
-- (2026-10-02, 뽑기 천장) the draws left until a sure Legendary or better leads the hint line (player attribute
-- PityLeft, the Gacha service; Config.Gacha.Pity)
local function refreshPity()
	local left = player:GetAttribute("PityLeft")
	local sure = player:GetAttribute("GuaranteedDraws") or 0 -- (a first key pack's or a mission's sure draw)
	exchangeHint.Text = sure > 0 and string.format("⭐ 확정 뽑기 %d회 남음! 다음 뽑기 첫 공룡", sure)
		or left and string.format("🎯 %s 이상 확정까지 %d번", Formulas.rarity(Config.Gacha.Pity.Rarity).Name,
		left) .. " · " .. EXCHANGE_HINT or EXCHANGE_HINT
end
player:GetAttributeChangedSignal("PityLeft"):Connect(refreshPity)
player:GetAttributeChangedSignal("GuaranteedDraws"):Connect(refreshPity)
refreshPity()

-- the results: a window of its own over the draw screen; "확인" closes it
local results = Instance.new("Frame")
results.AnchorPoint = Vector2.new(0.5, 0.5)
results.Position = UDim2.fromScale(0.5, 0.5)
results.Size = RESULT_SIZE
results.BackgroundColor3 = COLOR_BG
results.ZIndex = 4
results.Visible = false
results.Parent = gui
corner(results, 14)
fitToScreen(results)
local resultStroke = Instance.new("UIStroke")
resultStroke.Color = Color3.fromRGB(255, 205, 60)
resultStroke.Thickness = 2
resultStroke.Parent = results
local resultTitle = label(results, "뽑기 결과", UDim2.new(1, -20, 0, 34), UDim2.fromOffset(10, 6), 20)

local grid = Instance.new("ScrollingFrame")
grid.BackgroundTransparency = 1
grid.BorderSizePixel = 0
grid.ScrollBarThickness = 6
grid.AutomaticCanvasSize = Enum.AutomaticSize.Y
grid.CanvasSize = UDim2.new()
grid.Position = UDim2.fromOffset(14, 44)
grid.Size = UDim2.new(1, -28, 1, -104) -- room for 확인 below
grid.Parent = results
local layout = Instance.new("UIGridLayout")
layout.CellSize = CARD_SIZE
layout.CellPadding = UDim2.fromOffset(8, 8)
layout.FillDirectionMaxCells = CARD_COLUMNS
layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = grid

-- "확인": clears the results of the last draw
local okButton = button(results, "✅ 확인", COLOR_OK, OK_SIZE, UDim2.new(0.5, -OK_SIZE.X.Offset / 2, 1, -OK_SIZE.Y.Offset - 10))
okButton.Visible = false
local boxesButton = button(results, "📦 상자 보기", COLOR_BUTTON, OK_SIZE, UDim2.new(0.5, 6, 1, -OK_SIZE.Y.Offset - 10))
boxesButton.TextSize = 15
boxesButton.Visible = false
Coach.mark(boxesButton, "BoxesButton")
local shareButton = button(results, "📸 자랑하기", COLOR_SHARE, OK_SIZE, UDim2.new(0.5, 6, 1, -OK_SIZE.Y.Offset - 10))
shareButton.TextSize = 15
shareButton.Visible = false
shareButton.Activated:Connect(function()
	ShareMoment.share("Box", { shareButton })
end)

local function clearResults()
	for _, c in ipairs(grid:GetChildren()) do
		if c:IsA("Frame") then
			c:Destroy()
		end
	end
	okButton.Visible = false
	boxesButton.Visible = false
	shareButton.Visible = false
	Coach.mark(okButton, nil)
	okButton.Position = UDim2.new(0.5, -OK_SIZE.X.Offset / 2, 1, -OK_SIZE.Y.Offset - 10)
	results.Visible = false
	results:SetAttribute("Busy", nil)
end

local banner = label(gui, "", UDim2.fromOffset(600, 90), UDim2.fromScale(0.5, 0.3), 54)
banner.AnchorPoint = Vector2.new(0.5, 0.5)
banner.TextStrokeTransparency = 0
banner.Visible = false

local refreshMachineBadge
local function refreshKeys()
	local special = 0
	local level = player:GetAttribute("DefenseLevel") or 1
	local anyLocked = false
	for _, t in ipairs(Config.Keys.Types) do
		local keyLevel = Formulas.keyRarityLevel(level, t.Id)
		local row = rows[t.Id]
		local top = nil
		for _, c in ipairs(row.chips) do
			local locked = not Formulas.rarityOpen(c.rarity, keyLevel)
			anyLocked = anyLocked or locked
			c.strike.Visible = locked
			c.chip.BackgroundTransparency = locked and LOCKED_CHIP_SEE_THROUGH or 0
			c.word.TextTransparency = locked and SHINE.LockedText or 0
			if not locked then
				top = c
			end
		end
		for _, c in ipairs(row.chips) do
			c.edge.Enabled = c == top
			c.edge.Thickness = SHINE.BestEdge
		end
		row.top = top
	end
	local _, nextLocked = Formulas.rarityUnlocks(level)
	lockLine.Visible = anyLocked
	lockLine.Text = nextLocked and string.format("🚫 빨간 줄 등급은 아직 못 얻어요 · 다음: %s %s", nextLocked.Name, nextLocked.Condition)
		or "🚫 빨간 줄 등급은 아직 못 얻어요"
	for _, t in ipairs(Config.Keys.Types) do
		local n = keysOf(t.Id)
		if t.Id ~= "Normal" then
			special += n
		end
		local r = rows[t.Id]
		r.keys.Text = string.format("%s %s개", t.Name, Formulas.shortNumber(n))
		r.one.BackgroundColor3 = n >= 1 and COLOR_BUTTON or COLOR_DISABLED
		r.many.Text = string.format("🎲 %d번", Formulas.bulkDrawCount(n))
		r.many.BackgroundColor3 = n >= 2 and COLOR_BUTTON or COLOR_DISABLED
	end
	openButton.Text = special > 0
			and string.format("🎰 뽑기 · 🔑%s+%s", Formulas.shortNumber(normalKeys()), Formulas.shortNumber(special))
		or string.format("🎰 뽑기 · 🔑%s", Formulas.shortNumber(normalKeys()))
	if refreshMachineBadge then
		refreshMachineBadge(normalKeys() + special)
	end
end

for _, t in ipairs(Config.Keys.Types) do
	if t.Id ~= "Normal" then
		player:GetAttributeChangedSignal("Keys" .. t.Id):Connect(function()
			refreshKeys()
		end)
	end
end
player:GetAttributeChangedSignal("DefenseLevel"):Connect(refreshKeys)

local function card(unit, order)
	local rarity = Formulas.rarity(unit.Rarity)
	local color = RARITY_COLORS[unit.Rarity] or Color3.new(1, 1, 1)
	local c = Instance.new("Frame")
	c.LayoutOrder = order
	c.BackgroundColor3 = color
	c.Parent = grid
	corner(c, 10)
	DinoPortrait.border(c, unit.Rarity, 3) -- its rarity at a glance (the rainbow ones run through every color)
	local picture = DinoPortrait.new(unit.Species, UDim2.fromOffset(CARD_PORTRAIT, CARD_PORTRAIT))
	picture.AnchorPoint = Vector2.new(0.5, 0)
	picture.Position = UDim2.new(0.5, 0, 0, 3)
	picture.Parent = c
	local lines = UDim2.new(1, -6, 0, (CARD_SIZE.Y.Offset - CARD_PORTRAIT - 6) / 3)
	local nameLine = label(c, Formulas.unitName(unit), lines, UDim2.fromOffset(3, CARD_PORTRAIT + 3), 12)
	nameLine.TextScaled = true
	nameLine.TextStrokeTransparency = 0.3
	local rarityLine = label(c, rarity.Name, lines, UDim2.new(0, 3, 0, CARD_PORTRAIT + 3 + lines.Y.Offset), 13)
	rarityLine.Font = Enum.Font.GothamBlack
	rarityLine.TextScaled = true
	rarityLine.TextStrokeTransparency = 0
	rarityLine.TextStrokeColor3 = SHINE.Stroke
	local paint, rainbow = DinoPortrait.paint(rarityLine, unit.Rarity)
	if rainbow then
		spinning[paint] = true
	end
	local sizeLine = label(c, Formulas.dinoSize(unit.Size).Name, lines,
		UDim2.new(0, 3, 0, CARD_PORTRAIT + 3 + 2 * lines.Y.Offset), 11)
	sizeLine.TextScaled = true
	sizeLine.TextStrokeTransparency = 0.3
	TweenService:Create(c, TweenInfo.new(0.35), { BackgroundColor3 = COLOR_CARD:Lerp(color, SHINE.CardTint) }):Play()
	if GachaFx.has(unit.Rarity) then -- a unique one pops in big
		local scale = Instance.new("UIScale")
		scale.Scale = CARD_POP
		scale.Parent = c
		TweenService:Create(scale, TweenInfo.new(CARD_POP_SECONDS, Enum.EasingStyle.Back), { Scale = 1 }):Play()
	end
	return c
end

local busy = false
local reveal = 0 -- which draw's cards are being revealed; closing the results stops the reveal

local function boxIcon(box, px)
	local t = math.clamp((Formulas.dinoSizeRank(box.Size) - 1) / math.max(#Config.Sizes - 1, 1), 0, 1)
	local full = px * (BOX_SMALLEST + (BOX_BIGGEST - BOX_SMALLEST) * t)
	local edge = math.floor(full * Formulas.boxScale(box, Workspace:GetServerTimeNow()) + 0.5)
	local color = RARITY_COLORS[box.Rarity] or Color3.new(1, 1, 1)
	local holder = Instance.new("Frame")
	holder.BackgroundTransparency = 1
	holder.Size = UDim2.fromOffset(px, px)
	local body = Instance.new("Frame")
	body.AnchorPoint = Vector2.new(0.5, 1)
	body.Position = UDim2.fromScale(0.5, 1)
	body.Size = UDim2.fromOffset(edge, edge)
	body.BackgroundColor3 = color
	body.BorderSizePixel = 0
	body.Parent = holder
	corner(body, math.max(2, edge // 8))
	local lid = Instance.new("Frame")
	lid.Size = UDim2.new(1, 0, BOX_LID_SHARE, 0)
	lid.BackgroundColor3 = color:Lerp(Color3.new(), BOX_LID_DARKEN)
	lid.BorderSizePixel = 0
	lid.Parent = body
	corner(lid, math.max(2, edge // 8))
	for _, upright in ipairs({ true, false }) do
		local ribbon = Instance.new("Frame")
		ribbon.AnchorPoint = Vector2.new(0.5, 0.5)
		ribbon.Position = UDim2.fromScale(0.5, 0.5)
		ribbon.Size = upright and UDim2.new(BOX_RIBBON_SHARE, 0, 1, 0) or UDim2.new(1, 0, BOX_RIBBON_SHARE, 0)
		ribbon.BackgroundColor3 = COLOR_RIBBON
		ribbon.BorderSizePixel = 0
		ribbon.ZIndex = 2
		ribbon.Parent = body
	end
	return holder, body, full
end

local function growIcon(body, full, box, now)
	local edge = math.floor(full * Formulas.boxScale(box, now) + 0.5)
	if body.Size.X.Offset ~= edge then
		body.Size = UDim2.fromOffset(edge, edge)
	end
end

local function boxName(box)
	return string.format("%s 상자", Formulas.rarity(box.Rarity).Name)
end

local function boxCard(box, order)
	local c = Instance.new("Frame")
	c.LayoutOrder = order
	c.BackgroundColor3 = COLOR_CARD
	c.Parent = grid
	corner(c, 10)
	DinoPortrait.border(c, box.Rarity, 3)
	local icon = boxIcon(box, CARD_PORTRAIT)
	icon.AnchorPoint = Vector2.new(0.5, 0)
	icon.Position = UDim2.new(0.5, 0, 0, 3)
	icon.Parent = c
	c.BackgroundColor3 = COLOR_CARD:Lerp(RARITY_COLORS[box.Rarity] or COLOR_CARD, SHINE.CardTint)
	local left = box.ReadyAt - Workspace:GetServerTimeNow()
	local lines = UDim2.new(1, -6, 0, (CARD_SIZE.Y.Offset - CARD_PORTRAIT - 6) / 3)
	local nameLine = label(c, boxName(box), lines, UDim2.fromOffset(3, CARD_PORTRAIT + 3), 13)
	nameLine.Font = Enum.Font.GothamBlack
	nameLine.TextScaled = true
	nameLine.TextStrokeTransparency = 0
	nameLine.TextStrokeColor3 = SHINE.Stroke
	local paint, rainbow = DinoPortrait.paint(nameLine, box.Rarity)
	if rainbow then
		spinning[paint] = true
	end
	local text = label(c, string.format("%s\n%s", Formulas.dinoSize(box.Size).Name,
		left > 0 and "⏳ " .. Formulas.clockText(left) or "✅"), UDim2.new(1, -6, 0, 2 * lines.Y.Offset),
		UDim2.new(0, 3, 0, CARD_PORTRAIT + 3 + lines.Y.Offset), 12)
	text.TextStrokeTransparency = 0.3
	return c
end

local function showBoxCards(list, token)
	for i, box in ipairs(list) do
		if reveal ~= token then
			return
		end
		boxCard(box, i)
		Sfx.play((Formulas.rarity(box.Rarity .. "#") or 1) >= BANNER_FROM and "GachaBig" or "GachaCard")
		task.wait(BOX_SHOW_GAP)
	end
end

local function revealCards(results_, token)
	local fast = #results_ >= FAST_REVEAL_FROM
	for i, unit in ipairs(results_) do
		if reveal ~= token then
			return
		end
		local number = Formulas.rarity(unit.Rarity .. "#") or 1
		task.wait((fast and number < BANNER_FROM) and FAST_REVEAL or REVEAL_BASE + number * REVEAL_PER_RARITY)
		if reveal ~= token then
			return
		end
		local color = RARITY_COLORS[unit.Rarity] or Color3.new(1, 1, 1)
		local unique = GachaFx.has(unit.Rarity)
		if unique then
			GachaFx.suspense(unit.Rarity, color) -- (yields: the wait before the card)
			if reveal ~= token then
				return
			end
		end
		card(unit, i)
		if unique then
			GachaFx.burst(unit.Rarity, color, results) -- (its own sound)
		else
			Sfx.play(number >= BANNER_FROM and "GachaBig" or "GachaCard")
		end
		if number >= BANNER_FROM then
			banner.Text = string.format(unit.Pity and "🎯 천장 %s! %s" or "%s! %s", Formulas.rarity(unit.Rarity).Name,
				Formulas.unitName(unit))
			banner.TextColor3 = color
			banner.Visible = true
			task.wait(math.max(BANNER_SECONDS, GachaFx.life(unit.Rarity) * 0.8))
			banner.Visible = false
		end
	end
end

function doDraw(count)
	if busy then
		return
	end
	busy = true
	message.Text = ""
	clearResults()
	reveal += 1
	local token = reveal
	local ok, err = pcall(function()
		local answer = Net.ask("Draw", count, selected)
		if not answer then
			message.Text = "⏳ 잠시 뒤에 다시 해 주세요"
		elseif answer.Error then
			message.Text = answer.Error
		elseif answer.Boxes then
			resultTitle.Text = string.format("📦 상자 %d개가 농장에 쌓였어요!", #answer.Boxes)
			results.Visible = true
			okButton.Position = UDim2.new(0.5, -OK_SIZE.X.Offset - 6, 1, -OK_SIZE.Y.Offset - 10)
			okButton.Visible = true
			boxesButton.Visible = true
			results:SetAttribute("Busy", true)
			showBoxCards(answer.Boxes, token)
			if reveal == token then
				results:SetAttribute("Busy", nil)
				Coach.mark(okButton, "DrawOk")
			end
		end
	end)
	if not ok then
		warn("[Gacha] " .. tostring(err))
	end
	banner.Visible = false
	pcall(refreshKeys)
	busy = false -- always, so the next draw and 확인 keep working
end

local function closeResults()
	reveal += 1 -- stops a reveal still running
	banner.Visible = false
	clearResults()
end

okButton.Activated:Connect(closeResults)

local boxPanel = Instance.new("Frame")
boxPanel.AnchorPoint = Vector2.new(0.5, 0.5)
boxPanel.Position = UDim2.fromScale(0.5, 0.5)
boxPanel.Size = BOX_PANEL_SIZE
boxPanel.BackgroundColor3 = COLOR_BG
boxPanel.ZIndex = 3
boxPanel.Visible = false
boxPanel.Parent = gui
corner(boxPanel, 14)
local boxTitle = label(boxPanel, "📦 내 상자", UDim2.new(1, -60, 0, 34), UDim2.fromOffset(14, 6), 22)
boxTitle.TextXAlignment = Enum.TextXAlignment.Left
local boxClose = button(boxPanel, "X", COLOR_CLOSE, UDim2.fromOffset(34, 34), UDim2.new(1, -42, 0, 8))
local boxNote = label(boxPanel, "", UDim2.new(1, -28, 0, 18), UDim2.fromOffset(14, 42), 13)
boxNote.TextColor3 = COLOR_WAIT
local openAll = button(boxPanel, "📦 모두 열기", COLOR_BUTTON, BOX_OPEN_ALL_SIZE,
	UDim2.new(0.5, -BOX_OPEN_ALL_SIZE.X.Offset / 2, 0, 62))
local boxList = Instance.new("ScrollingFrame")
boxList.Position = UDim2.fromOffset(10, BOX_LIST_TOP)
boxList.Size = UDim2.new(1, -20, 1, -BOX_LIST_TOP - 10)
boxList.BackgroundTransparency = 1
boxList.BorderSizePixel = 0
boxList.ScrollBarThickness = 6
boxList.AutomaticCanvasSize = Enum.AutomaticSize.Y
boxList.CanvasSize = UDim2.new()
boxList.Parent = boxPanel
do
	local boxLayout = Instance.new("UIGridLayout")
	boxLayout.CellSize = BOX_CARD
	boxLayout.CellPadding = UDim2.fromOffset(BOX_CARD_GAP, BOX_CARD_GAP)
	boxLayout.SortOrder = Enum.SortOrder.LayoutOrder
	boxLayout.Parent = boxList
end
local boxEmpty = label(boxPanel, "📦 상자가 없어요! 🎰 뽑기로 상자를 받아요", UDim2.new(1, -28, 0, 40),
	UDim2.fromOffset(14, BOX_LIST_TOP + 10), 15)
boxEmpty.TextColor3 = COLOR_WAIT
boxEmpty.Visible = false

local rushAll = button(boxPanel, "", COLOR_RUSH, BOX_OPEN_ALL_SIZE, UDim2.new(0.5, BOX_TOP_GAP, 0, 62))
rushAll.TextSize = 14
rushAll.TextWrapped = true
rushAll.Visible = false

local boxData = { list = {}, total = 0, rows = {}, rush = {}, icons = {}, free = {} }
local openBoxes
local rush
local freeSkip

local function rushKey(need)
	local tier = Formulas.boxRushTier(need)
	return tier and "BoxRush" .. tier or nil
end

local function rushOn(key)
	return key ~= nil and not player:GetAttribute("PaidRandomItemsRestricted")
		and ((Config.Monetization.ProductIds[key] or 0) > 0 or RunService:IsStudio())
end

local function rushText(need, many)
	local key = rushKey(need)
	if need <= 0 then
		return many and "⚡ 모두 바로 열기" or "⚡ 바로"
	end
	local price = Prices.get(Config.Monetization.ProductIds[key] or 0, false, Config.Products[key].Robux)
	return many and string.format("⚡ 모두 바로 열기 R$%d", price) or string.format("⚡ R$%d", price)
end

local function boxNoteText()
	local credit = player:GetAttribute("BoxRush") or 0
	local skips = player:GetAttribute("FreeSkips") or 0
	if skips > 0 then
		return string.format("🎟️ 무료 바로 열기권 %d장! 오래 걸리는 상자에 눌러요", skips)
	end
	return credit > 0 and string.format("⚡ 남은 빨리 열기 %s", Formulas.clockText(credit))
		or "⏳ 다 되면 열 수 있어요 · 🏡 농장에 쌓여 있어요"
end

local function renderBoxes()
	for _, c in ipairs(boxList:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
	boxData.rows, boxData.rush, boxData.icons, boxData.free = {}, {}, {}, {}
	local now = Workspace:GetServerTimeNow()
	local credit = player:GetAttribute("BoxRush") or 0
	local bottom = UDim2.new(0, 4, 1, -BOX_CARD_BUTTON - 4)
	local wide = UDim2.new(1, -8, 0, BOX_CARD_BUTTON)
	for i, box in ipairs(boxData.list) do
		local c = Instance.new("Frame")
		c.LayoutOrder = i
		c.BackgroundColor3 = COLOR_CARD
		c.Parent = boxList
		corner(c, 10)
		DinoPortrait.border(c, box.Rarity, 2)
		local icon, body, full = boxIcon(box, BOX_CARD_ICON)
		icon.AnchorPoint = Vector2.new(0.5, 0)
		icon.Position = UDim2.new(0.5, 0, 0, 4)
		icon.Parent = c
		boxData.icons[box.Id] = { body = body, full = full, box = box }
		local name = label(c, boxName(box), UDim2.new(1, -6, 0, 16), UDim2.fromOffset(3, BOX_CARD_ICON + 6), 12)
		name.TextColor3 = RARITY_COLORS[box.Rarity] or Color3.new(1, 1, 1)
		name.TextScaled = true
		local sizeName = label(c, Formulas.dinoSize(box.Size).Name, UDim2.new(1, -6, 0, 13),
			UDim2.fromOffset(3, BOX_CARD_ICON + 22), 11)
		sizeName.TextColor3 = COLOR_WAIT
		sizeName.TextScaled = true
		local ready = box.ReadyAt <= now
		local timer = label(c, ready and "✅" or "⏳ " .. Formulas.clockText(box.ReadyAt - now), UDim2.new(1, -6, 0, 14),
			UDim2.fromOffset(3, BOX_CARD_ICON + 35), 12)
		timer.TextColor3 = COLOR_WAIT
		if ready then
			local b = button(c, "✅ 열기", COLOR_BUTTON, wide, bottom)
			Coach.mark(b, "BoxOpen")
			b.TextSize = 13
			b.Activated:Connect(function()
				openBoxes(box.Id)
			end)
		else
			boxData.rows[box.Id] = timer
			local need = box.ReadyAt - now - credit
			if (player:GetAttribute("FreeSkips") or 0) > 0 and box.ReadyAt - now >= Config.Boxes.FreeSkipMinSeconds then
				local f = button(c, "🎟️ 무료로 열기", COLOR_FREE, wide, bottom)
				Coach.mark(f, "BoxFree")
				f.TextSize = 12
				f.TextScaled = true
				local shine = Instance.new("UIStroke")
				shine.Color = COLOR_FREE_SHINE
				shine.Thickness = 2
				shine.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
				shine.Parent = f
				table.insert(boxData.free, shine)
				f.Activated:Connect(function()
					freeSkip(box.Id)
				end)
			elseif need <= 0 or rushOn(rushKey(need)) then
				local r = button(c, rushText(need, false), COLOR_RUSH, wide, bottom)
				r.TextSize = 13
				r.Activated:Connect(function()
					rush(box.Id)
				end)
				boxData.rush[box.Id] = r
			end
		end
	end
	boxEmpty.Visible = #boxData.list == 0
	if boxData.total > #boxData.list then
		local more = label(boxList, string.format("📦 상자 %d개 더 있어요", boxData.total - #boxData.list),
			UDim2.new(), UDim2.new(), 13)
		more.LayoutOrder = #boxData.list + 1
		more.TextColor3 = COLOR_WAIT
	end
	local ready = player:GetAttribute("BoxesReady") or 0
	openAll.Text = ready > 0 and string.format("📦 모두 열기 (%d)", ready) or "📦 모두 열기"
	openAll.BackgroundColor3 = ready > 0 and COLOR_BUTTON or COLOR_DISABLED
	Coach.mark(openAll, ready > 0 and (boxData.fromPill and "PillOpenAll" or "BoxOpenAll") or nil)
	local ids, total, tier = Formulas.boxRushPick(boxData.list, now, "All", credit)
	rushAll.Visible = #ids > 0 and (not tier or rushOn("BoxRush" .. tier))
	if rushAll.Visible then
		rushAll.Text = rushText(total - credit, true)
	end
	openAll.Position = UDim2.new(0.5, rushAll.Visible and -BOX_OPEN_ALL_SIZE.X.Offset - BOX_TOP_GAP or -BOX_OPEN_ALL_SIZE.X.Offset / 2,
		0, 62)
	boxNote.Text = boxNoteText()
end

local function loadBoxes()
	local ok, answer = pcall(Net.ask, "GetBoxes")
	if ok and type(answer) == "table" and answer.Boxes then
		boxData.list, boxData.total = answer.Boxes, answer.Total or #answer.Boxes
		renderBoxes()
	end
end

local function showBoxPanel(fromPill)
	boxData.fromPill = fromPill == true
	boxNote.Text = boxNoteText()
	boxPanel.Visible = true
	task.spawn(loadBoxes)
end

function openBoxes(which)
	if busy then
		return
	end
	busy = true
	clearResults()
	reveal += 1
	local token = reveal
	local ok, err = pcall(function()
		local answer = Net.ask("OpenBoxes", which)
		if not answer then
			boxNote.Text = "⏳ 잠시 뒤에 다시 해 주세요"
		elseif answer.Error then
			boxNote.Text = answer.Error
		elseif answer.Results then
			resultTitle.Text = "🎉 상자 열기!"
			results.Visible = true
			okButton.Visible = true
			task.spawn(loadBoxes)
			results:SetAttribute("Busy", true)
			revealCards(answer.Results, token)
			if reveal == token then
				results:SetAttribute("Busy", nil)
				Coach.mark(okButton, "BoxOk")
				local shareFrom = Formulas.rarity(Config.Share.FromRarity .. "#") or math.huge
				for _, unit in ipairs(answer.Results) do
					if (Formulas.rarity(unit.Rarity .. "#") or 0) >= shareFrom and ShareMoment.allowed() then
						okButton.Position = UDim2.new(0.5, -OK_SIZE.X.Offset - 6, 1, -OK_SIZE.Y.Offset - 10)
						shareButton.Visible = true
						break
					end
				end
			end
			local from = Formulas.rarity(Config.Beta.LikeAsk.BoxFrom .. "#")
			for _, unit in ipairs(answer.Results) do
				if (Formulas.rarity(unit.Rarity .. "#") or 0) >= from then
					player:SetAttribute("BigBox", true)
					break
				end
			end
		end
	end)
	if not ok then
		warn("[Gacha] " .. tostring(err))
	end
	banner.Visible = false
	busy = false
end

function rush(which)
	local ok, answer = pcall(Net.ask, "BoxRush", which)
	if not ok or type(answer) ~= "table" then
		boxNote.Text = "⏳ 잠시 뒤에 다시 해 주세요"
	elseif answer.Error then
		boxNote.Text = answer.Error
	elseif answer.Product then
		local id = Config.Monetization.ProductIds[answer.Product] or 0
		if id > 0 then
			MarketplaceService:PromptProductPurchase(player, id)
		elseif RunService:IsStudio() then
			Net.request("StudioBuy", answer.Product)
		end
	end
	task.spawn(loadBoxes)
end

function freeSkip(id)
	if busy then
		return
	end
	local ok, answer = pcall(Net.ask, "BoxFreeSkip", id)
	if not ok or type(answer) ~= "table" then
		boxNote.Text = "⏳ 잠시 뒤에 다시 해 주세요"
	elseif answer.Error then
		boxNote.Text = answer.Error
	elseif answer.Done then
		openBoxes(id)
		return
	end
	task.spawn(loadBoxes)
end

openAll.Activated:Connect(function()
	openBoxes("All")
end)
rushAll.Activated:Connect(function()
	rush("All")
end)
boxClose.Activated:Connect(function()
	boxPanel.Visible = false
end)
boxesButton.Activated:Connect(function()
	closeResults()
	showBoxPanel()
end)
player:GetAttributeChangedSignal("OpenBoxes"):Connect(function()
	if player:GetAttribute("OpenBoxes") then
		player:SetAttribute("OpenBoxes", nil)
		showBoxPanel()
	end
end)
for _, name in ipairs({ "BoxesReady", "BoxesWaiting", "BoxRush", "FreeSkips" }) do
	player:GetAttributeChangedSignal(name):Connect(function()
		if boxPanel.Visible and not busy then
			task.spawn(loadBoxes)
		end
	end)
end
task.spawn(function()
	while true do
		task.wait(BOX_TICK)
		if boxPanel.Visible then
			local now = Workspace:GetServerTimeNow()
			local changed = false
			for _, shine in ipairs(boxData.free) do
				shine.Transparency = 0.5 - 0.5 * math.sin(os.clock() * BOX_PULSE_SPEED)
			end
			for _, box in ipairs(boxData.list) do
				local timer = boxData.rows[box.Id]
				local icon = boxData.icons[box.Id]
				if icon then
					growIcon(icon.body, icon.full, box, now)
				end
				if timer then
					local left = box.ReadyAt - now
					if left <= 0 then
						changed = true
					else
						timer.Text = "⏳ " .. Formulas.clockText(left)
						local r = boxData.rush[box.Id]
						if r then
							r.Text = rushText(left - (player:GetAttribute("BoxRush") or 0), false)
						end
					end
				end
			end
			if changed then
				renderBoxes()
			end
		end
	end
end)

local boxPill = Instance.new("TextButton")
boxPill.Name = "BoxPill"
boxPill.Position = UDim2.new(0, 0, 1, BOX_PILL_GAP)
boxPill.Size = UDim2.new(1, 0, 0, BOX_PILL_HEIGHT)
boxPill.BackgroundColor3 = COLOR_BOX_PILL
boxPill.Font = FONT
boxPill.TextScaled = true
boxPill.TextColor3 = Color3.new(1, 1, 1)
boxPill.Text = ""
boxPill.Visible = false
boxPill.ZIndex = openButton.ZIndex + 1
boxPill.Parent = openButton
corner(boxPill, 8)
local pillStroke = Instance.new("UIStroke")
pillStroke.Color = COLOR_BOX_READY
pillStroke.Thickness = 2
pillStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
pillStroke.Transparency = 1
pillStroke.Parent = boxPill
Coach.mark(boxPill, "BoxPill")
boxPill.Activated:Connect(function()
	showBoxPanel(true)
end)
task.spawn(function()
	while true do
		task.wait(BOX_PULSE_STEP)
		local ready = player:GetAttribute("BoxesReady") or 0
		local waiting = player:GetAttribute("BoxesWaiting") or 0
		boxPill.Visible = ready + waiting > 0
		if ready > 0 then
			boxPill.Text = string.format("📦 ✅%d", ready)
			boxPill.BackgroundColor3 = COLOR_BOX_READY
			pillStroke.Color = Color3.new(1, 1, 1)
			pillStroke.Transparency = 0.5 - 0.5 * math.sin(os.clock() * BOX_PULSE_SPEED)
		elseif waiting > 0 then
			local nextAt = player:GetAttribute("BoxNextAt")
			local free = player:GetAttribute("FreeSkipFor")
			boxPill.Text = (free and "📦🎟️ " or "📦 ") .. (nextAt and Formulas.clockText(nextAt - Workspace:GetServerTimeNow()) or "")
			boxPill.BackgroundColor3 = free and COLOR_FREE or COLOR_BOX_PILL
			pillStroke.Color = COLOR_FREE_SHINE
			pillStroke.Transparency = free and 0.5 - 0.5 * math.sin(os.clock() * BOX_PULSE_SPEED) or 1
		end
	end
end)

-- Studio's ;gachafx (TestCommands): the reveal of a rarity (or every unique one in turn) with a
-- made-up dino, nothing given
Net.onPush("GachaPreview", function(rarityId)
	local list = {}
	for i, r in ipairs(Config.Rarities) do
		if (rarityId == "" and i >= BANNER_FROM) or r.Id == rarityId then
			table.insert(list, { Species = Config.Species[1].Id, Rarity = r.Id, Size = Config.Sizes[1].Id })
		end
	end
	clearResults()
	reveal += 1
	results.Visible = true
	okButton.Visible = true
	revealCards(list, reveal)
	banner.Visible = false
end)
panel:GetPropertyChangedSignal("Visible"):Connect(function() -- closing the draw screen closes its results
	if not panel.Visible then
		closeResults()
	end
end)


-- ---------------------------------------------------------------------------
-- Odds window
-- ---------------------------------------------------------------------------

local odds = Instance.new("Frame")
odds.AnchorPoint = Vector2.new(0.5, 0.5)
odds.Position = UDim2.fromScale(0.5, 0.5)
odds.Size = ODDS_SIZE
odds.BackgroundColor3 = COLOR_BG
odds.Visible = false
odds.ZIndex = 5
odds.Parent = gui
corner(odds, 14)
fitToScreen(odds)
local oddsTitle = label(odds, "확률 보기", UDim2.new(1, -60, 0, 34), UDim2.fromOffset(14, 6), 20)
oddsTitle.TextXAlignment = Enum.TextXAlignment.Left
local oddsClose = button(odds, "X", COLOR_CLOSE, UDim2.fromOffset(34, 34), UDim2.new(1, -42, 0, 8))
local list = Instance.new("ScrollingFrame")
list.Position = UDim2.fromOffset(10, 46)
list.Size = UDim2.new(1, -20, 1, -56)
list.BackgroundTransparency = 1
list.ScrollBarThickness = 6
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = odds
local listLayout = Instance.new("UIListLayout")
listLayout.SortOrder = Enum.SortOrder.LayoutOrder
listLayout.Padding = UDim.new(0, 2)
listLayout.Parent = list

local function oddsRow(order, left, right, header, color, chipId)
	local row = Instance.new("Frame")
	row.LayoutOrder = order
	row.Size = UDim2.new(1, -10, 0, header and 30 or 22)
	row.BackgroundTransparency = header and 0.2 or 1
	row.BackgroundColor3 = COLOR_CARD
	row.Parent = list
	local indent = chipId and SHINE.OddsChip + 6 or 0
	local l = label(row, left, UDim2.new(0.7, -8 - indent, 1, 0), UDim2.fromOffset(8 + indent, 0), header and 16 or 14)
	l.TextXAlignment = Enum.TextXAlignment.Left
	if color then
		l.TextColor3 = color
	end
	if chipId then
		local chip = Instance.new("Frame")
		chip.AnchorPoint = Vector2.new(0, 0.5)
		chip.Position = UDim2.new(0, 6, 0.5, 0)
		chip.Size = UDim2.fromOffset(SHINE.OddsChip, SHINE.OddsChip)
		chip.Parent = row
		corner(chip, 3)
		local paint, rainbow = DinoPortrait.paint(chip, chipId)
		if rainbow then
			spinning[paint] = true
		end
	end
	if (right == nil or right == "") and not header then -- (a line of its own: the whole width, smaller if long)
		l.Size = UDim2.new(1, -16 - indent, 1, 0)
		l.TextScaled = true
		local most = Instance.new("UITextSizeConstraint")
		most.MaxTextSize = 14
		most.Parent = l
		return
	end
	local r = label(row, right or "", UDim2.new(0.3, -8, 1, 0), UDim2.fromScale(0.7, 0), header and 16 or 14)
	r.TextXAlignment = Enum.TextXAlignment.Right
end

local function showOdds()
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("Frame") then
			c:Destroy()
		end
	end
	local level = player:GetAttribute("DefenseLevel") or 1
	local options = oddsOptions()
	options.keyType = selected
	local o = Formulas.gachaOdds(level, options)
	oddsTitle.Text = string.format("확률 보기 · %s · %s", Formulas.keyType(selected).Name,
		Formulas.levelText(level, player:GetAttribute("Rebirths")))
	local n = 0
	local function row(...)
		n += 1
		oddsRow(n, ...)
	end
	-- (2026-10-02, "이 표를 명시해놔야지 나도 햇갈리네 뽑기할 때 명시되게") every rarity and when it opens, first
	row("📋 등급이 열리는 때 (환생)", nil, true)
	for _, u in ipairs(Formulas.rarityUnlocks(level)) do
		row(Formulas.rarityUnlockLine(u), nil, false, u.Open and RARITY_COLORS[u.Id] or COLOR_LOCKED_SPECIES, u.Id)
	end
	row(Formulas.newRarityRuleText(), nil, false, Color3.fromRGB(255, 220, 120))
	-- (2026-10-02) a better key draws its own awakening's rarities even before it (Formulas.keyRarityLevel)
	do
		local parts = {}
		for _, t in ipairs(Config.Keys.Types) do
			if (t.ShopRebirths or 0) > 0 then
				table.insert(parts, string.format("%s %s", t.Name, Formulas.keyShopCondition(t.Id)))
			end
		end
		row(string.format("💎 좋은 열쇠는 환생 전에도 그 열쇠 등급까지 나와요: %s", table.concat(parts, " · ")), nil, false,
			Color3.fromRGB(255, 220, 120))
	end
	-- (2026-10-02) 뽑기 천장
	row(string.format("🎯 %s보다 낮은 게 %d번 나오면 다음엔 %s 이상 꼭! (%d번 남음)",
		Formulas.rarity(Config.Gacha.Pity.Rarity).Name, Config.Gacha.Pity.Draws - 1, Formulas.rarity(Config.Gacha.Pity.Rarity).Name,
		player:GetAttribute("PityLeft") or Config.Gacha.Pity.Draws), nil, false, Color3.fromRGB(255, 220, 120))
	row(string.format("🔄 환생할 때마다 전설 이상이 +%d%% 더 잘 나와요 (행운은 모두 합쳐 최대 ×%d · 🍀 물약·서버 행운 땐 ×%d)",
		math.floor(Config.Rebirth.RareChancePerRebirth * 100 + 0.5), Config.Gacha.LuckMaxMultiplier, Config.Gacha.PaidLuckMax), nil, false,
		Color3.fromRGB(255, 220, 120))
	row("🎰 뽑기 한 번은 아래 단계를 차례로 따로 뽑아요", nil, true)
	local keyType = Formulas.keyType(selected)
	local luck = math.min(options.luck or 1, options.luckCap or Config.Gacha.LuckMaxMultiplier)
	if luck > 1 then
		row(string.format("🍀 행운 ×%g 켜짐 (전설 이상 ×%g, 맨 위 %d등급은 ×%g)", luck, luck, Config.Gacha.TopLuck.Rarities,
			Formulas.topLuck(luck)), nil, false, Color3.fromRGB(255, 220, 120))
	end
	if Formulas.keyPicks(keyType.Id) > 1 then
		row(string.format("%s: %s 뽑아 등급이 가장 좋은 것, 크기도 %d개 중 가장 큰 것", keyType.Name,
			Formulas.keyDrawText(keyType.Id), Formulas.keySizePicks(keyType.Id, level)), nil, false, gradeColor(keyType))
	end
	row(string.format("1. 종 (%d종)", #o.Species), "", true)
	for _, s in ipairs(o.Species) do
		-- (2026-10-02, "이것들은 왜 한글임": a name glued to a Korean tail is translated only in its name) whole
		-- templates, so the translation finds them
		row(s.Limited and string.format("🎖️ %s (이번 주 한정, 🎖️ 표시)", Formulas.species(s.Id).Name)
			or Formulas.species(s.Id).Name, percentText(s.Percent))
	end
	-- (2026-10-01) the species no key gives yet at my level: how many, and when the next open
	local open, all, nextLevel, nextCount, nextRebirths = Formulas.speciesOutlook(level)
	if nextRebirths then
		row(string.format("🔒 아직 안 나오는 공룡 %d종 · 다음 환생 %d번에 %d종 (📖 도감)", all - open, nextRebirths, nextCount), "",
			false, COLOR_LOCKED_SPECIES)
	elseif nextLevel then
		row(string.format("🔒 아직 안 나오는 공룡 %d종 · 다음 %s에 %d종 (📖 도감)", all - open, Formulas.levelText(nextLevel),
			nextCount), "", false, COLOR_LOCKED_SPECIES)
	end
	-- the variants this key can't give: each only from its own key and better (2026-10-02, "금열쇠 + 루비열쇠+ 종류들도 구분해줘")
	for _, t in ipairs(Formulas.variantTiers()) do
		if not Formulas.variantOpen({ Theme = "Variant", MinKey = t.Key }, selected) then
			row(string.format("✨ 변종 %d종은 %s 이상에서만", t.Count, Formulas.keyType(t.Key).Name), "", false,
				COLOR_LOCKED_SPECIES)
		end
	end
	-- (2026-10-02) the awakened variants this player can't draw with this key yet: what each needs
	for _, s in ipairs(Formulas.awakenedVariants()) do
		if not Formulas.variantOpen(s, selected, options.rebirths) then
			row(string.format("🌟 %s: 환생 %d + %s 이상", s.Name, s.MinRebirths, Formulas.keyType(s.MinKey).Name), "", false,
				COLOR_LOCKED_SPECIES)
		end
	end
	row("2. 등급", "", true)
	for _, r in ipairs(o.Rarities) do
		row(r.Locked and string.format("%s (%s에 열림)", Formulas.rarity(r.Id).Name, Formulas.rarityCondition(r))
			or Formulas.rarity(r.Id).Name,
			percentText(r.Percent), false, RARITY_COLORS[r.Id], r.Id)
	end
	row("3. 크기", "", true)
	for _, s in ipairs(o.Sizes) do
		local size = Formulas.dinoSize(s.Id)
		row(string.format("%s (×%g)", size.Name, size.Look or size.Scale), percentText(s.Percent))
	end
	row("4. 변이", percentText(o.MutationPercent), true)
	if #o.Mutations == 0 then
		row("✨ 변이 이벤트 중에만 붙어요 (지금은 0%)", "")
	end
	for _, m in ipairs(o.Mutations) do
		row(Formulas.mutation(m.Id).Name, percentText(m.Percent))
	end
	odds.Visible = true
end

openOdds = showOdds
tableButton.Activated:Connect(function()
	showOdds()
	list.CanvasPosition = Vector2.zero -- (the table is at the top)
end)
oddsClose.Activated:Connect(function()
	odds.Visible = false
end)

local function togglePanel()
	panel.Visible = not panel.Visible
	newBadge.Visible = false
	odds.Visible = false
	refreshKeys()
end
openButton.Activated:Connect(togglePanel)
ProximityPromptService.PromptTriggered:Connect(function(prompt)
	if prompt:GetAttribute("Kind") == "Gacha" then
		togglePanel()
	end
end)

do
	local badge = Instance.new("BillboardGui")
	badge.Name = "GachaKeys"
	badge.Size = MACHINE_BADGE_SIZE
	badge.MaxDistance = MACHINE_BADGE_DISTANCE
	badge.LightInfluence = 0
	badge.Enabled = false
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBlack
	text.TextScaled = true
	text.TextColor3 = MACHINE_BADGE_COLOR
	text.TextStrokeTransparency = 0.2
	text.Parent = badge
	badge.Parent = player:WaitForChild("PlayerGui")
	local keys, bob = 0, nil
	local ring = { folder = Instance.new("Folder"), list = {}, center = nil, count = -1 }
	ring.folder.Name = "GachaCapsules"
	local function buildCapsules()
		local level = player:GetAttribute("DefenseLevel") or 1
		local open = {}
		for _, r in ipairs(Config.Rarities) do
			if (r.ChancePercent or 0) > 0 and Formulas.rarityOpen(r, level) then
				table.insert(open, r)
			end
		end
		if #open == ring.count then
			return
		end
		ring.count = #open
		for _, c in ipairs(ring.list) do
			c.part:Destroy()
		end
		table.clear(ring.list)
		for _, r in ipairs(open) do
			local ball = Instance.new("Part")
			ball.Name = "Capsule_" .. r.Id
			ball.Shape = Enum.PartType.Ball
			ball.Size = Vector3.one * CAPSULE.Size
			ball.Material = Enum.Material.Neon
			ball.Color = DinoPortrait.gradeColor(r.Id)
			ball.Anchored, ball.CanCollide, ball.CanQuery, ball.CanTouch, ball.CastShadow = true, false, false, false, false
			ball.Parent = ring.folder
			table.insert(ring.list, { part = ball, cycle = r.Id == "Rainbow" or r.Id == "Secret" or r.Id == "Divine" })
		end
	end
	buildCapsules()
	player:GetAttributeChangedSignal("DefenseLevel"):Connect(buildCapsules)
	RunService.Heartbeat:Connect(FrameMeter.wrap("GachaCapsules", function()
		local camera = Workspace.CurrentCamera
		local center, list = ring.center, ring.list
		if not center or #list == 0 or not camera or (camera.CFrame.Position - center).Magnitude > CAPSULE.Draw then
			return
		end
		local t = os.clock()
		local parts, frames = {}, {}
		for i, c in ipairs(list) do
			local a = t * CAPSULE.Spin + (i - 1) / #list * 2 * math.pi
			table.insert(parts, c.part)
			table.insert(frames, CFrame.new(center + Vector3.new(math.cos(a) * CAPSULE.Radius,
				math.sin(t * CAPSULE.BobSpeed + i) * CAPSULE.Bob, math.sin(a) * CAPSULE.Radius)))
			if c.cycle then
				c.part.Color = Color3.fromHSV((t * CAPSULE.HueSpeed + i / #list) % 1, 0.65, 1)
			end
		end
		Workspace:BulkMoveTo(parts, frames, Enum.BulkMoveMode.FireCFrameChanged)
	end))
	local function place(machine)
		local part = machine and machine:FindFirstChildWhichIsA("BasePart", true)
		if not part then
			badge.Adornee = nil
			ring.center = nil
			ring.folder.Parent = nil
			return
		end
		local cf, size = machine:GetBoundingBox()
		ring.center = cf.Position + Vector3.new(0, size.Y / 2 + CAPSULE.Up, 0)
		ring.folder.Parent = Workspace
		local up = cf.Position - part.Position + Vector3.new(0, size.Y / 2 + MACHINE_BADGE_UP, 0)
		badge.Adornee = part
		badge.StudsOffsetWorldSpace = up
		if bob then
			bob:Cancel()
		end
		bob = TweenService:Create(badge, TweenInfo.new(MACHINE_BADGE_BOB_SECONDS, Enum.EasingStyle.Sine,
			Enum.EasingDirection.InOut, -1, true), { StudsOffsetWorldSpace = up + Vector3.new(0, MACHINE_BADGE_BOB, 0) })
		bob:Play()
	end
	local function show()
		badge.Enabled = keys > 0 and badge.Adornee ~= nil and badge.Adornee.Parent ~= nil
		text.Text = string.format("🔑 ×%s 뽑기 가능!", Formulas.shortNumber(keys))
	end
	refreshMachineBadge = function(n)
		keys = n
		show()
	end
	task.spawn(function()
		while true do
			local map = Workspace:FindFirstChild("Map")
			local index = player:GetAttribute("Base")
			local folder = map and index and map:FindFirstChild("Base" .. index)
			local machine = folder and folder:FindFirstChild("GachaMachine")
			local hidden = machine ~= nil and machine:GetAttribute("Hidden") == true
			TopBar.setHidden(openButton, hidden)
			if hidden then
				machine = nil
			end
			if machine ~= (badge.Adornee and badge.Adornee:FindFirstAncestor("GachaMachine")) then
				place(machine)
				show()
			end
			task.wait(machine and 10 or 1)
		end
	end)
end
close.Activated:Connect(function()
	panel.Visible = false
	odds.Visible = false
end)
-- (2026-10-04) another screen script opens it (the first free draw's card, FirstDraw): a local player attribute
player:GetAttributeChangedSignal("OpenGacha"):Connect(function()
	if player:GetAttribute("OpenGacha") then
		player:SetAttribute("OpenGacha", nil)
		panel.Visible = true
		newBadge.Visible = false
		odds.Visible = false
		refreshKeys()
	end
end)

task.spawn(function()
	while player:GetAttribute("Keys") == nil do
		player:GetAttributeChangedSignal("Keys"):Wait()
	end
	player:GetAttributeChangedSignal("Keys"):Connect(refreshKeys)
	player:GetAttributeChangedSignal("DefenseLevel"):Connect(function()
		refreshKeys()
		if odds.Visible then
			showOdds()
		end
	end)
	refreshKeys()
end)

RunService.Heartbeat:Connect(FrameMeter.wrap("GachaShine", function()
	if not panel.Visible and not odds.Visible and not results.Visible then
		return
	end
	local t = os.clock()
	local spin = (t * SHINE.Spin) % 360
	for gradient in pairs(spinning) do
		gradient.Rotation = spin
	end
	local glow = SHINE.BestEdge + SHINE.BestEdgePulse * math.abs(math.sin(t * SHINE.PulseSpeed))
	for _, row in pairs(rows) do
		if row.top then
			row.top.edge.Thickness = glow
		end
	end
end))

-- Esc / Backspace / gamepad B closes the last opened window (Shared/Windows)
local Windows = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Windows"))
Windows.fit(panel) -- in the screen's free part, smaller on phones
Windows.fit(odds)
Windows.fit(results)
Windows.fit(boxPanel)
Windows.register(panel)
Windows.register(boxPanel)
Windows.register(odds)
Windows.register(results, closeResults)
