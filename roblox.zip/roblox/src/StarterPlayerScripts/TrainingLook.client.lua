--[[
TrainingLook (2026-10-04, "훈련도에 따라서 해당 부위에 이펙트 달아주자. 늘어지는 줄같이 달리는 이펙트나 반짝이는 이펙트라던지...",
"등급별로 색도 다르고 이펙트가"): every player's training shows on their body, drawn on every screen from their level
attributes (MoveSpeedLevel, SlapLevel: Shop; BagLevel, PickaxeTier + PickaxePower, PickaxeSpeed: Minerals). Each track's
grade (Formulas.trainLookGrade: Config.Training.LookShares of its top, marked 🟢 🔵 🟣 🟠 🌈 in the training panel) picks
the color and how much:
  👟 MoveSpeed   the feet: a streaming line behind each foot while running (a Trail, longer and wider each grade),
                 sparkles off the feet from 🟣
  👋 Slap        the hands: sparkles round each hand (more and bigger each grade), a soft glow round them from 🟣
  🎒 Bag         the back: motes drifting up off the back (more each grade), big glowing ones from 🟣
  ⛏️ Power/Speed the pickaxe in hand (HeldPickaxe): sparks off it, the better of the two tracks' grades
  🌈 (a track at its top): every color at once.
Built-in Trails and ParticleEmitters, made once per character and again only when a grade changes (no per-frame work);
a character farther than DISTANCE from the camera has them off (looked at every CHECK_SECONDS), and the view setting
✨ 오라 (HideAuras) turns them all off (weak phones).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))

local player = Players.LocalPlayer

-- display only
local GRADE_COLORS = { -- 🟢 🔵 🟣 🟠 (Config.Training.LookMarks); the top grade, 🌈, is RAINBOW
	Color3.fromRGB(90, 235, 120),
	Color3.fromRGB(80, 175, 255),
	Color3.fromRGB(195, 110, 255),
	Color3.fromRGB(255, 185, 50),
}
local RAINBOW = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 80, 80)),
	ColorSequenceKeypoint.new(0.2, Color3.fromRGB(255, 170, 50)),
	ColorSequenceKeypoint.new(0.4, Color3.fromRGB(255, 240, 80)),
	ColorSequenceKeypoint.new(0.6, Color3.fromRGB(90, 235, 120)),
	ColorSequenceKeypoint.new(0.8, Color3.fromRGB(80, 175, 255)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(195, 110, 255)),
})
local SPARKLE = "rbxasset://textures/particles/sparkles_main.dds"
local DISTANCE = 120 -- studs from the camera: a character farther off shows none
local CHECK_SECONDS = 0.5
local PARTS_WAIT = 10 -- seconds a new character's parts are waited for
-- by grade (1 to 5): 👟 the feet
local TRAIL_SECONDS = { 0.22, 0.32, 0.42, 0.52, 0.65 } -- how long the line behind a foot is
local TRAIL_WIDTH = { 0.25, 0.35, 0.45, 0.55, 0.65 } -- studs
local FEET_RATE = { 0, 0, 3, 5, 8 } -- sparkles a second off each foot
local FEET_START_SECONDS = 0.14
local FEET_START_WIDTH = 0.18
local FEET_START_COLOR = ColorSequence.new(Color3.fromRGB(235, 245, 255))
-- 👋 the hands
local HAND_RATE = { 2, 4, 6, 8, 11 }
local HAND_SIZE = { 0.2, 0.25, 0.3, 0.34, 0.4 }
local HAND_GLOW_RATE = { 0, 0, 1.2, 1.8, 2.5 }
local HAND_GLOW_SIZE = 0.9
-- 🎒 the back
local BACK_RATE = { 1.5, 2.5, 3.5, 5, 7 }
local BACK_SIZE = { 0.22, 0.26, 0.3, 0.34, 0.38 }
local BACK_GLOW_RATE = { 0, 0, 0.8, 1.2, 1.8 }
local BACK_GLOW_SIZE = 0.8
local BACK_OUT = 0.6 -- studs behind the torso's middle
-- ⛏️ the pickaxe
local PICK_RATE = { 2, 4, 6, 8, 11 }
local PICK_SIZE = { 0.2, 0.24, 0.28, 0.32, 0.36 }
local GLOW_FROM = 3 -- the grade (🟣) the glows and the feet's sparkles start at

local looks = {} -- [other player] = { character, grades, effects = { Trail/ParticleEmitter, ... } }

local function colorOf(grade)
	return grade >= #Config.Training.LookShares and RAINBOW or ColorSequence.new(GRADE_COLORS[math.clamp(grade, 1, #GRADE_COLORS)])
end

-- each look's grade from the player's level attributes
local function gradesOf(other)
	local function a(name, default)
		return other:GetAttribute(name) or default
	end
	local power = (a("PickaxeTier", 1) - 1) * Config.Pickaxe.PowerSteps + a("PickaxePower", 0)
	return {
		Feet = Formulas.trainLookGrade("MoveSpeed", a("MoveSpeedLevel", 0)),
		FeetStart = a("MoveSpeedLevel", 0) >= 1,
		Hands = Formulas.trainLookGrade("Slap", a("SlapLevel", 1)),
		Back = Formulas.trainLookGrade("Bag", a("BagLevel", 1)),
		Pickaxe = math.max(Formulas.trainLookGrade("Power", power), Formulas.trainLookGrade("Speed", a("PickaxeSpeed", 0))),
	}
end

local function same(a, b)
	return a and b and a.Feet == b.Feet and a.FeetStart == b.FeetStart and a.Hands == b.Hands and a.Back == b.Back and a.Pickaxe == b.Pickaxe
end

local function attachment(part, offset)
	local at = Instance.new("Attachment")
	at.Name = "TrainLook"
	at.Position = offset
	at.Parent = part
	return at
end

-- sparkles (or, glow, a few big soft ones held round the spot)
local function sparkles(parent, color, rate, size, glow)
	local e = Instance.new("ParticleEmitter")
	e.Name = "TrainLook"
	e.Texture = SPARKLE
	e.Color = color
	e.LightEmission = 1
	e.Rate = rate
	e.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, size), NumberSequenceKeypoint.new(1, glow and size * 0.6 or 0) })
	e.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, glow and 0.55 or 0.1), NumberSequenceKeypoint.new(1, 1) })
	e.Lifetime = glow and NumberRange.new(0.5, 0.8) or NumberRange.new(0.4, 0.8)
	e.Speed = glow and NumberRange.new(0, 0.3) or NumberRange.new(0.6, 1.6)
	e.SpreadAngle = Vector2.new(180, 180)
	e.LockedToPart = glow == true
	e.Parent = parent
	return e
end

local function clear(look)
	for _, effect in ipairs(look.effects) do
		effect:Destroy()
	end
	for _, at in ipairs(look.attachments) do
		at:Destroy()
	end
	look.effects, look.attachments = {}, {}
end

local function hidden()
	return player:GetAttribute("HideAuras") == true
end

local function shownFor(look)
	if hidden() then
		return false
	end
	local root = look.character and look.character:FindFirstChild("HumanoidRootPart")
	local camera = Workspace.CurrentCamera
	return root ~= nil and camera ~= nil and (root.Position - camera.CFrame.Position).Magnitude <= DISTANCE
end

local function setShown(look, shown)
	if look.shown == shown then
		return
	end
	look.shown = shown
	for _, effect in ipairs(look.effects) do
		effect.Enabled = shown
	end
end

-- (re)makes the character's looks for its grades
local function build(other)
	local look = looks[other]
	local character = other.Character
	if not look or not character then
		return
	end
	clear(look)
	look.character = character
	local g = look.grades
	local r6 = character:FindFirstChild("UpperTorso") == nil
	local function add(effect)
		table.insert(look.effects, effect)
		return effect
	end
	local function at(part, offset)
		local a = attachment(part, offset)
		table.insert(look.attachments, a)
		return a
	end
	-- 👟 the feet: a line behind each foot, sparkles from 🟣
	if g.Feet > 0 or g.FeetStart then
		local color = g.Feet > 0 and colorOf(g.Feet) or FEET_START_COLOR
		for _, name in ipairs(r6 and { "Left Leg", "Right Leg" } or { "LeftFoot", "RightFoot" }) do
			local part = character:FindFirstChild(name)
			if part then
				local y, half = r6 and -0.9 or -0.1, (TRAIL_WIDTH[g.Feet] or FEET_START_WIDTH) / 2
				local a0, a1 = at(part, Vector3.new(0, y - half, 0)), at(part, Vector3.new(0, y + half, 0))
				local trail = Instance.new("Trail")
				trail.Name = "TrainLook"
				trail.Attachment0, trail.Attachment1 = a0, a1
				trail.Color = color
				trail.Lifetime = TRAIL_SECONDS[g.Feet] or FEET_START_SECONDS
				trail.LightEmission = 0.7
				trail.FaceCamera = true
				trail.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(1, 1) })
				trail.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.3) })
				trail.Parent = part
				add(trail)
				if (FEET_RATE[g.Feet] or 0) > 0 then
					add(sparkles(a0, color, FEET_RATE[g.Feet], HAND_SIZE[g.Feet], false))
				end
			end
		end
	end
	-- 👋 the hands: sparkles, a glow from 🟣
	if g.Hands > 0 then
		local color = colorOf(g.Hands)
		for _, name in ipairs(r6 and { "Left Arm", "Right Arm" } or { "LeftHand", "RightHand" }) do
			local part = character:FindFirstChild(name)
			if part then
				local spot = at(part, Vector3.new(0, r6 and -0.9 or 0, 0))
				add(sparkles(spot, color, HAND_RATE[g.Hands], HAND_SIZE[g.Hands], false))
				if g.Hands >= GLOW_FROM then
					add(sparkles(spot, color, HAND_GLOW_RATE[g.Hands], HAND_GLOW_SIZE, true))
				end
			end
		end
	end
	-- 🎒 the back: motes drifting up, big glowing ones from 🟣
	local torso = character:FindFirstChild("UpperTorso") or character:FindFirstChild("Torso")
	if g.Back > 0 and torso then
		local color = colorOf(g.Back)
		local spot = at(torso, Vector3.new(0, r6 and 0.2 or 0.1, BACK_OUT))
		local motes = add(sparkles(spot, color, BACK_RATE[g.Back], BACK_SIZE[g.Back], false))
		motes.EmissionDirection = Enum.NormalId.Top
		motes.SpreadAngle = Vector2.new(35, 35)
		motes.Lifetime = NumberRange.new(0.8, 1.3)
		if g.Back >= GLOW_FROM then
			add(sparkles(spot, color, BACK_GLOW_RATE[g.Back], BACK_GLOW_SIZE, true))
		end
	end
	-- ⛏️ the pickaxe in hand: sparks off its biggest part
	local pickaxe = character:FindFirstChild("HeldPickaxe")
	if g.Pickaxe > 0 and pickaxe then
		local biggest, volume = nil, 0
		for _, part in ipairs(pickaxe:GetDescendants()) do
			if part:IsA("BasePart") and part.Size.X * part.Size.Y * part.Size.Z > volume then
				biggest, volume = part, part.Size.X * part.Size.Y * part.Size.Z
			end
		end
		if biggest then
			add(sparkles(biggest, colorOf(g.Pickaxe), PICK_RATE[g.Pickaxe], PICK_SIZE[g.Pickaxe], false))
		end
	end
	look.shown = nil
	setShown(look, shownFor(look))
end

-- a level changed: made again only when a grade did
local function regrade(other)
	local look = looks[other]
	if not look then
		return
	end
	local grades = gradesOf(other)
	if not same(grades, look.grades) or look.character ~= other.Character then
		look.grades = grades
		build(other)
	end
end

local LEVELS = { "MoveSpeedLevel", "SlapLevel", "BagLevel", "PickaxeTier", "PickaxePower", "PickaxeSpeed" }

local function watch(other)
	local look = { character = nil, grades = nil, effects = {}, attachments = {}, shown = nil }
	looks[other] = look
	local function onCharacter(character)
		local root = character:WaitForChild("HumanoidRootPart", PARTS_WAIT)
		if not root or other.Character ~= character then
			return
		end
		character:WaitForChild("Humanoid", PARTS_WAIT)
		task.wait() -- (the limbs come with the humanoid's description)
		look.grades = gradesOf(other)
		build(other)
		character.ChildAdded:Connect(function(child) -- the pickaxe is made again with a new tier (Minerals)
			if child.Name == "HeldPickaxe" and other.Character == character then
				build(other)
			end
		end)
	end
	other.CharacterAdded:Connect(onCharacter)
	if other.Character then
		task.spawn(onCharacter, other.Character)
	end
	for _, name in ipairs(LEVELS) do
		other:GetAttributeChangedSignal(name):Connect(function()
			regrade(other)
		end)
	end
end

for _, other in ipairs(Players:GetPlayers()) do
	watch(other)
end
Players.PlayerAdded:Connect(watch)
Players.PlayerRemoving:Connect(function(other)
	looks[other] = nil
end)

-- far away or ✨ 오라 off: off (looked at every CHECK_SECONDS, never every frame)
task.spawn(function()
	while true do
		task.wait(CHECK_SECONDS)
		for _, look in pairs(looks) do
			if #look.effects > 0 then
				setShown(look, shownFor(look))
			end
		end
	end
end)
player:GetAttributeChangedSignal("HideAuras"):Connect(function()
	for _, look in pairs(looks) do
		setShown(look, shownFor(look))
	end
end)
