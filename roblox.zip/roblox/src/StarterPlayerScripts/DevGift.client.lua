local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(Shared:WaitForChild("Windows"))
local Sfx = require(Shared:WaitForChild("Sfx"))

local player = Players.LocalPlayer

local FONT = Enum.Font.GothamBold
local SIZE = Vector2.new(460, 300)
local COLOR_BG = Color3.fromRGB(34, 30, 56)
local COLOR_TITLE = Color3.fromRGB(255, 215, 90)
local COLOR_OK = Color3.fromRGB(70, 180, 90)
local COLOR_STROKE = Color3.fromRGB(255, 215, 90)
local WAIT_STEP = 1

local function label(parent, text, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextSize = textSize
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextWrapped = true
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function show()
	while player:GetAttribute("CocoIntro") or player:GetAttribute("FirstFight") or player:GetAttribute("LanguagePick") do
		task.wait(WAIT_STEP)
	end
	if not player:GetAttribute("DevGift") then
		return
	end
	local gui = Instance.new("ScreenGui")
	gui.Name = "DevGift"
	gui.ResetOnSpawn = false
	gui.Parent = player:WaitForChild("PlayerGui")
	local frame = Instance.new("Frame")
	frame.AnchorPoint = Vector2.new(0.5, 0.5)
	frame.Position = UDim2.fromScale(0.5, 0.5)
	frame.Size = UDim2.fromOffset(SIZE.X, SIZE.Y)
	frame.BackgroundColor3 = COLOR_BG
	frame.Parent = gui
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 16)
	round.Parent = frame
	local stroke = Instance.new("UIStroke")
	stroke.Color = COLOR_STROKE
	stroke.Thickness = 3
	stroke.Parent = frame
	label(frame, "🎁", UDim2.new(1, 0, 0, 64), UDim2.fromOffset(0, 12), 52)
	label(frame, "개발자가 보내는 특별한 선물이에요!", UDim2.new(1, -24, 0, 34), UDim2.fromOffset(12, 80), 26, COLOR_TITLE)
	label(frame, "버그를 알려 줘서 정말 고마워요! ⭐ VIP를 선물로 드려요", UDim2.new(1, -40, 0, 60), UDim2.fromOffset(20, 118), 18)
	local ok = Instance.new("TextButton")
	ok.AnchorPoint = Vector2.new(0.5, 1)
	ok.Position = UDim2.new(0.5, 0, 1, -18)
	ok.Size = UDim2.fromOffset(280, 54)
	ok.BackgroundColor3 = COLOR_OK
	ok.Font = FONT
	ok.TextSize = 20
	ok.TextColor3 = Color3.new(1, 1, 1)
	ok.Text = "✅ 확인, 감사합니다!"
	ok.Parent = frame
	local okRound = Instance.new("UICorner")
	okRound.CornerRadius = UDim.new(0, 12)
	okRound.Parent = ok
	local function close()
		Net.request("DevGiftSeen")
		gui:Destroy()
	end
	ok.Activated:Connect(close)
	Windows.register(frame, close, { Keep = true })
	Windows.fit(frame, { Cover = "Big" })
	Sfx.play("GachaBig")
end

player:GetAttributeChangedSignal("DevGift"):Connect(function()
	if player:GetAttribute("DevGift") then
		task.spawn(show)
	end
end)
if player:GetAttribute("DevGift") then
	task.spawn(show)
end
