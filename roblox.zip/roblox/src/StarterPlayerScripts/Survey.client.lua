local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

local FONT = Enum.Font.GothamBold
local PANEL_SIZE = UDim2.fromOffset(340, 250)
local EDGE = 14
local TITLE_HEIGHT = 34
local NOTE_HEIGHT = 22
local VOTE_HEIGHT = 64
local REASON_HEIGHT = 40
local REASON_GAP = 6
local THANKS_SECONDS = 1.5
local WAIT_LOOK = 2
local WAIT_MAX = 600
local COLOR_BG = Color3.fromRGB(30, 34, 50)
local COLOR_TITLE = Color3.fromRGB(255, 225, 120)
local COLOR_NOTE = Color3.fromRGB(200, 204, 215)
local COLOR_UP = Color3.fromRGB(70, 180, 100)
local COLOR_DOWN = Color3.fromRGB(215, 80, 90)
local COLOR_REASON = Color3.fromRGB(70, 76, 100)
local COLOR_STROKE = Color3.fromRGB(255, 200, 90)

local gui = Instance.new("ScreenGui")
gui.Name = "Survey"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(0.5, 0.5)
panel.Position = UDim2.fromScale(0.5, 0.5)
panel.Size = PANEL_SIZE
panel.BackgroundColor3 = COLOR_BG
panel.Visible = false
panel.Parent = gui
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 14)
	round.Parent = panel
	local edge = Instance.new("UIStroke")
	edge.Color = COLOR_STROKE
	edge.Thickness = 2
	edge.Parent = panel
end
Windows.fit(panel)

local function label(parent, text, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.TextWrapped = true
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos, textSize)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = textSize
	b.TextColor3 = Color3.new(1, 1, 1)
	b.TextWrapped = true
	b.Text = text
	b.BackgroundColor3 = color
	b.Size = size
	b.Position = pos
	b.Parent = parent
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 10)
	round.Parent = b
	return b
end

local title = label(panel, "", UDim2.new(1, -EDGE * 2 - 40, 0, TITLE_HEIGHT), UDim2.fromOffset(EDGE, 8), 20, COLOR_TITLE)
title.TextXAlignment = Enum.TextXAlignment.Left
local note = label(panel, "", UDim2.new(1, -EDGE * 2, 0, NOTE_HEIGHT), UDim2.fromOffset(EDGE, 8 + TITLE_HEIGHT), 13, COLOR_NOTE)
note.TextXAlignment = Enum.TextXAlignment.Left
local body = Instance.new("Frame")
body.BackgroundTransparency = 1
body.Position = UDim2.fromOffset(EDGE, 8 + TITLE_HEIGHT + NOTE_HEIGHT + 10)
body.Size = UDim2.new(1, -EDGE * 2, 1, -(8 + TITLE_HEIGHT + NOTE_HEIGHT + 10) - EDGE)
body.Parent = panel

local function clear()
	for _, c in ipairs(body:GetChildren()) do
		c:Destroy()
	end
end

local function thanks()
	clear()
	title.Text = "🙏 고마워요!"
	note.Text = "🐣 더 재밌게 만들게요"
	task.delay(THANKS_SECONDS, function()
		panel.Visible = false
	end)
end

local function reasons(up)
	clear()
	title.Text = up and "👍 뭐가 제일 재밌어요?" or "👎 뭐가 제일 별로예요?"
	note.Text = "하나만 골라 주세요"
	local list = up and Config.Beta.Survey.Up or Config.Beta.Survey.Down
	for i, r in ipairs(list) do
		local col, row = (i - 1) % 2, (i - 1) // 2
		local b = button(body, r.Text, COLOR_REASON, UDim2.new(0.5, -REASON_GAP / 2, 0, REASON_HEIGHT),
			UDim2.new(col * 0.5, col * REASON_GAP / 2, 0, row * (REASON_HEIGHT + REASON_GAP)), 14)
		b.Activated:Connect(function()
			Net.request("SurveyAnswer", up, r.Id)
			thanks()
		end)
	end
end

local function ask()
	clear()
	title.Text = "🐣 이 게임 어때요?"
	note.Text = "솔직하게 알려 주면 더 재밌게 만들게요!"
	local yes = button(body, "👍 재밌어요", COLOR_UP, UDim2.new(0.5, -REASON_GAP / 2, 0, VOTE_HEIGHT), UDim2.new(), 18)
	local no = button(body, "👎 별로예요", COLOR_DOWN, UDim2.new(0.5, -REASON_GAP / 2, 0, VOTE_HEIGHT),
		UDim2.new(0.5, REASON_GAP / 2, 0, 0), 18)
	yes.Activated:Connect(function()
		reasons(true)
	end)
	no.Activated:Connect(function()
		reasons(false)
	end)
end

local function busy()
	return Windows.anyOpen() or player:GetAttribute("CocoIntro") or player:GetAttribute("FirstFight")
		or player:GetAttribute("PromoLevel") or player:GetAttribute("TutorialStep") or player:GetAttribute("Cinematic")
		or player:GetAttribute("TopView") or player:GetAttribute("PlacingUnit")
end

Net.onPush("Survey", function()
	local started = os.clock()
	while busy() and os.clock() - started < WAIT_MAX do
		task.wait(WAIT_LOOK)
	end
	if busy() then
		return
	end
	ask()
	panel.Visible = true
end)

Windows.register(panel)
