--[[
SpeedPadLabels: the "⚡ 속도 x1.8" label over each speed pad near the camera (display only).

(2026-10-04, "게임 최적화") the server's pads (Workspace.SpeedPads, ServerScriptService/Services/SpeedPads) are one
part each with their multiplier as the attribute Multiplier; the label used to come from the server with every pad
(about 850 out). Now every CHECK_EVERY seconds the pads within NEAR studs of the camera get a label made here, and
the ones farther lose it, so only a few dozen labels exist at a time.
]]

local Workspace = game:GetService("Workspace")

-- display only
-- (2026-10-04, "화면이 느려요" + a screenshot: dozens of small labels far over the field, each drawn on top) 150 → 60
local NEAR = 60 -- studs from the camera
local TOO_NEAR = 16
local CHECK_EVERY = 0.3
-- the label: just over the pad, lower than a player, sized in studs (a pixel-sized label grows in the
-- world far away and sinks into the ground)
local LABEL_HEIGHT = 2.2 -- studs from the pad to the label's middle (its top stays below a player's head)
local LABEL_STUDS = Vector2.new(4.5, 1.3)
local LABEL_BACK = Color3.fromRGB(15, 30, 45)

local labels = {} -- [pad part] = its BillboardGui

local function makeLabel(pad, multiplier)
	local gui = Instance.new("BillboardGui")
	gui.Name = "PadLabel"
	gui.Size = UDim2.fromScale(LABEL_STUDS.X, LABEL_STUDS.Y)
	gui.StudsOffsetWorldSpace = Vector3.new(0, LABEL_HEIGHT, 0)
	gui.MaxDistance = NEAR
	gui.AlwaysOnTop = true -- never hidden by the glowing pad or the ground under it
	gui.LightInfluence = 0
	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundColor3 = LABEL_BACK -- a dark pill, so the text does not drown in the pad's glow
	label.BackgroundTransparency = 0.35
	label.Font = Enum.Font.GothamBold
	label.TextScaled = true
	label.TextColor3 = Color3.new(1, 1, 1)
	label.TextStrokeColor3 = Color3.new(0, 0, 0)
	label.TextStrokeTransparency = 0
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = label
	local padding = Instance.new("UIPadding")
	padding.PaddingLeft, padding.PaddingRight = UDim.new(0.06, 0), UDim.new(0.06, 0)
	padding.Parent = label
	label.Text = string.format("⚡ 속도 x%.1f", multiplier)
	label.Parent = gui
	gui.Adornee = pad
	gui.Parent = pad
	return gui
end

local cells = {}

local function cellOf(position)
	return math.floor(position.X / NEAR) * 65536 + math.floor(position.Z / NEAR)
end

local function added(pad)
	if not pad:IsA("BasePart") then
		return
	end
	local key = cellOf(pad.Position)
	cells[key] = cells[key] or {}
	cells[key][pad] = true
end

local function removed(pad)
	if pad:IsA("BasePart") then
		local cell = cells[cellOf(pad.Position)]
		if cell then
			cell[pad] = nil
		end
	end
	local gui = labels[pad]
	if gui then
		gui:Destroy()
		labels[pad] = nil
	end
end

task.spawn(function()
	local folder = Workspace:WaitForChild("SpeedPads")
	folder.ChildAdded:Connect(added)
	folder.ChildRemoved:Connect(removed)
	for _, pad in ipairs(folder:GetChildren()) do
		added(pad)
	end
	while true do
		local camera = Workspace.CurrentCamera
		if camera then
			local eye = camera.CFrame.Position
			local near2 = NEAR * NEAR
			local cx, cz = math.floor(eye.X / NEAR), math.floor(eye.Z / NEAR)
			for dx = -1, 1 do
				for dz = -1, 1 do
					for pad in pairs(cells[(cx + dx) * 65536 + cz + dz] or {}) do
						local multiplier = pad:GetAttribute("Multiplier")
						local p = pad.Position
						local x, y, z = p.X - eye.X, p.Y - eye.Y, p.Z - eye.Z
						if multiplier and x * x + y * y + z * z <= near2 and not (labels[pad] and labels[pad].Parent) then
							labels[pad] = makeLabel(pad, multiplier)
						end
					end
				end
			end
			for pad, gui in pairs(labels) do
				local p = pad.Position
				local x, y, z = p.X - eye.X, p.Y - eye.Y, p.Z - eye.Z
				local d2 = x * x + y * y + z * z
				if not pad.Parent or d2 > near2 then
					gui:Destroy()
					labels[pad] = nil
				else
					gui.Enabled = d2 >= TOO_NEAR * TOO_NEAR
				end
			end
		end
		task.wait(CHECK_EVERY)
	end
end)
