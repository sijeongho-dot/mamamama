local ContentProvider = game:GetService("ContentProvider")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local player = Players.LocalPlayer
player:SetAttribute("Loading", true)

local FrameMeter = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("FrameMeter"))
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))

local DISPLAY_ORDER = 200
local COLOR_BG = Color3.fromRGB(28, 34, 52)
local COLOR_BAR_BACK = Color3.fromRGB(55, 62, 86)
local COLOR_BAR = Color3.fromRGB(120, 220, 120)
local COLOR_BAR_TIP = Color3.fromRGB(200, 255, 200)
local COLOR_TEXT = Color3.fromRGB(255, 255, 255)
local COLOR_WAIT = Color3.fromRGB(255, 220, 120)
local DINO_SIZE = UDim2.fromOffset(110, 110)
local STATUS_SIZE = UDim2.fromOffset(420, 56)
local BAR_SIZE = UDim2.fromOffset(340, 22)
local PERCENT_SIZE = UDim2.fromOffset(80, 22)
local BOB = 10
local BOB_SPEED = 3
local SHINE_SPEED = 0.8
local MAX_SECONDS = 50
local GAME_SECONDS = 30
local MAP_SECONDS = 20
local WORLD_SECONDS = 30
local WORLD_MIN = 1.5
local CHARACTER_SECONDS = 15
local STREAM_SECONDS = 8
local DATA_SECONDS = 40
local QUIET_WINDOW = 1
local QUIET_PARTS = 30
local QUIET_HOLD = 2
local NEAR_SHARE = 0.97
local SMOOTH_FRAME = 0.1
local SETTLE_SECONDS = 1.5
local SETTLE_MAX = 10
local CREEP_SECONDS = 2.5
local CREEP_MOST = 0.92
local SMOOTH = 5
local TEXT_EVERY = 0.25
local FULL_AT = 0.995
local FILL_SECONDS = 3
local DONE_SECONDS = 0.6
local FADE_SECONDS = 0.5
local PHASE_ENDS = { Game = 0.08, World = 0.7, Ready = 0.85, Settle = 0.995, Done = 1 }
local GAME_TEXT = "📦 게임 받는 중..."
local WORLD_TEXT = "🗺️ 맵 받는 중... %d / %d"
local WORLD_TEXT_PLAIN = "🗺️ 맵 받는 중... %d"
local CHARACTER_TEXT = "🦖 캐릭터 준비 중..."
local DATA_TEXT = "💾 내 데이터 불러오는 중..."
local DATA_WAIT_TEXT = "💾 내 데이터 불러오는 중...\n잠깐만 기다려 주세요"
local SETTLE_TEXT = "✨ 화면 맞추는 중..."
local DONE_TEXT = "✅ 준비 끝!"

local gui = Instance.new("ScreenGui")
gui.Name = "LoadingScreen"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.ScreenInsets = Enum.ScreenInsets.None
gui.DisplayOrder = DISPLAY_ORDER

local back = Instance.new("Frame")
back.Size = UDim2.fromScale(1, 1)
back.BackgroundColor3 = COLOR_BG
back.BorderSizePixel = 0
back.Active = true
back.Parent = gui

local dino = Instance.new("TextLabel")
dino.AnchorPoint = Vector2.new(0.5, 1)
dino.Position = UDim2.new(0.5, 0, 0.5, -20)
dino.Size = DINO_SIZE
dino.BackgroundTransparency = 1
dino.TextScaled = true
dino.Text = "🦖"
dino:SetAttribute("KeepText", true)
dino.Parent = back

local status = Instance.new("TextLabel")
status.AnchorPoint = Vector2.new(0.5, 0)
status.Position = UDim2.new(0.5, 0, 0.5, 0)
status.Size = STATUS_SIZE
status.BackgroundTransparency = 1
status.Font = Enum.Font.GothamBlack
status.TextScaled = true
status.TextColor3 = COLOR_TEXT
status.Text = GAME_TEXT
status.Parent = back
local most = Instance.new("UITextSizeConstraint")
most.MaxTextSize = 26
most.Parent = status

local barBack = Instance.new("Frame")
barBack.AnchorPoint = Vector2.new(0.5, 0)
barBack.Position = UDim2.new(0.5, 0, 0.5, STATUS_SIZE.Y.Offset + 12)
barBack.Size = BAR_SIZE
barBack.BackgroundColor3 = COLOR_BAR_BACK
barBack.BorderSizePixel = 0
barBack.ClipsDescendants = true
barBack.Parent = back
local bar = Instance.new("Frame")
bar.Size = UDim2.fromScale(0, 1)
bar.BackgroundColor3 = COLOR_BAR
bar.BorderSizePixel = 0
bar.Parent = barBack
local shine = Instance.new("UIGradient")
shine.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, COLOR_BAR), ColorSequenceKeypoint.new(0.45, COLOR_BAR),
	ColorSequenceKeypoint.new(0.5, COLOR_BAR_TIP), ColorSequenceKeypoint.new(0.55, COLOR_BAR), ColorSequenceKeypoint.new(1, COLOR_BAR) })
shine.Parent = bar
for _, f in ipairs({ barBack, bar }) do
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0.5, 0)
	c.Parent = f
end
local percent = Instance.new("TextLabel")
percent.AnchorPoint = Vector2.new(0.5, 0.5)
percent.Position = UDim2.fromScale(0.5, 0.5)
percent.Size = PERCENT_SIZE
percent.BackgroundTransparency = 1
percent.Font = Enum.Font.GothamBlack
percent.TextScaled = true
percent.TextColor3 = COLOR_TEXT
percent.TextStrokeTransparency = 0.4
percent.Text = "0%"
percent.ZIndex = 3
percent.Parent = barBack

gui.Parent = player:WaitForChild("PlayerGui")

local started = os.clock()
local function left()
	return math.max(0, MAX_SECONDS - (os.clock() - started))
end

local floorAt, capAt, phaseStart, phaseName = 0, PHASE_ENDS.Game, os.clock(), "Game"
local queueMost = 0
local shown = 0
local shownPercent = -1
local parts, partsConn, childConn = 0, nil, nil
local skipped = {}
local nearParts, nearCenter, nearRadius = 0, nil, nil
local samples, nearSamples = {}, {}
local quietFor, nearQuietFor, settled = 0, 0, 0
local textAt = 0
local marks = { start = os.clock() }

local function nextPhase(name, text)
	floorAt = capAt
	capAt = PHASE_ENDS[name]
	phaseStart = os.clock()
	phaseName = name
	if text then
		status.Text = text
		status.TextColor3 = COLOR_TEXT
	end
end

local function expected()
	local base = player:GetAttribute("Base")
	local n = base and ReplicatedStorage:GetAttribute("StreamParts" .. base)
	return n or ReplicatedStorage:GetAttribute("StreamPartsMost")
end

local function nearExpected()
	local base = player:GetAttribute("Base")
	return base and ReplicatedStorage:GetAttribute("StreamNear" .. base) or nil
end

local function isNear(part)
	local dx, dz = part.Position.X - nearCenter.X, part.Position.Z - nearCenter.Z
	return dx * dx + dz * dz <= nearRadius * nearRadius
end

local function counted(d)
	if not d:IsA("BasePart") then
		return false
	end
	for folder in pairs(skipped) do
		if d:IsDescendantOf(folder) then
			return false
		end
	end
	return true
end

local function skipBuilt(child)
	if child:GetAttribute("Built") == true then
		skipped[child] = true
	end
end

local function recent(list, now, count)
	while #list > 1 and list[2][1] <= now - QUIET_WINDOW do
		table.remove(list, 1)
	end
	return list[1] and count - list[1][2] or 0
end

local function startNear(map)
	if nearCenter or not map then
		return
	end
	local center = player:GetAttribute("BaseCenter")
	local radius = ReplicatedStorage:GetAttribute("StreamNearRadius")
	if typeof(center) ~= "Vector3" or type(radius) ~= "number" then
		return
	end
	nearCenter, nearRadius = center, radius
	local n = 0
	for _, d in ipairs(map:GetDescendants()) do
		if counted(d) and isNear(d) then
			n += 1
		end
	end
	nearParts = n
	table.clear(nearSamples)
	nearQuietFor = 0
end

local function countMap(map)
	for _, c in ipairs(map:GetChildren()) do
		skipBuilt(c)
	end
	childConn = map.ChildAdded:Connect(skipBuilt)
	local n = 0
	for _, d in ipairs(map:GetDescendants()) do
		if counted(d) then
			n += 1
		end
	end
	parts = n
	partsConn = map.DescendantAdded:Connect(function(d)
		if counted(d) then
			parts += 1
			if nearCenter and isNear(d) then
				nearParts += 1
			end
		end
	end)
end

local frame = RunService.Heartbeat:Connect(FrameMeter.wrap("LoadingScreen", function(dt)
	local now = os.clock()
	dino.Position = UDim2.new(0.5, 0, 0.5, -20 - math.abs(math.sin(now * BOB_SPEED)) * BOB)
	table.insert(samples, { now, parts })
	table.insert(nearSamples, { now, nearParts })
	local quiet = recent(samples, now, parts) < QUIET_PARTS
	local nearQuiet = recent(nearSamples, now, nearParts) < QUIET_PARTS
	quietFor = quiet and quietFor + dt or 0
	nearQuietFor = nearQuiet and nearQuietFor + dt or 0
	settled = (nearQuiet and dt <= SMOOTH_FRAME) and settled + dt or 0
	local share = math.min(CREEP_MOST, 1 - math.exp(-(now - phaseStart) / CREEP_SECONDS))
	if phaseName == "Game" then
		local queue = ContentProvider.RequestQueueSize
		queueMost = math.max(queueMost, queue)
		if queueMost > 0 then
			share = math.max(share * 0.5, math.min(CREEP_MOST, 1 - queue / queueMost))
		end
	elseif phaseName == "World" then
		local want = nearCenter and nearExpected()
		local n = expected()
		if want and want > 0 then
			share = math.min(1, nearParts / (want * NEAR_SHARE))
			if now - textAt >= TEXT_EVERY then
				textAt = now
				status.Text = string.format(WORLD_TEXT, math.min(nearParts, want), want)
			end
		elseif n and n > 0 then
			share = math.min(1, parts / n)
			if now - textAt >= TEXT_EVERY then
				textAt = now
				status.Text = string.format(WORLD_TEXT, math.min(parts, n), n)
			end
		elseif now - textAt >= TEXT_EVERY then
			textAt = now
			status.Text = string.format(WORLD_TEXT_PLAIN, parts)
		end
	elseif phaseName == "Settle" then
		share = math.min(1, settled / SETTLE_SECONDS)
	elseif phaseName == "Done" then
		share = 1
	end
	local target = floorAt + (capAt - floorAt) * share
	shown = math.min(1, shown + math.max(0, target - shown) * math.min(1, dt * SMOOTH))
	bar.Size = UDim2.fromScale(shown, 1)
	shine.Offset = Vector2.new(((now * SHINE_SPEED) % 2) - 1, 0)
	local whole = math.min(phaseName == "Done" and 100 or 99, math.floor(shown * 100 + 0.5))
	if whole ~= shownPercent then
		shownPercent = whole
		percent.Text = string.format("%d%%", whole)
	end
end))

local function waitFor(seconds, ready)
	local until_ = os.clock() + math.min(seconds, left())
	while not ready() and os.clock() < until_ do
		task.wait(0.1)
	end
end

local function run()
	waitFor(GAME_SECONDS, function()
		return game:IsLoaded()
	end)
	marks.game = os.clock()
	nextPhase("World", nil)
	local map = Workspace:FindFirstChild("Map") or Workspace:WaitForChild("Map", math.max(0.1, math.min(MAP_SECONDS, left())))
	if map then
		countMap(map)
	end
	waitFor(WORLD_SECONDS, function()
		startNear(map)
		local long = os.clock() - phaseStart >= WORLD_MIN
		local want = nearCenter and nearExpected()
		if want and want > 0 then
			return nearParts >= want * NEAR_SHARE or (long and nearQuietFor >= QUIET_HOLD)
		elseif nearCenter then
			return long and nearQuietFor >= QUIET_HOLD
		end
		local n = expected()
		if n and n > 0 and parts >= n then
			return true
		end
		return long and quietFor >= QUIET_HOLD
	end)
	marks.world = os.clock()
	nextPhase("Ready", CHARACTER_TEXT)
	waitFor(CHARACTER_SECONDS, function()
		return player.Character ~= nil and player.Character:FindFirstChild("HumanoidRootPart") ~= nil
	end)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if root and left() > 0 then
		pcall(function()
			player:RequestStreamAroundAsync(root.Position, math.min(STREAM_SECONDS, left()))
		end)
	end
	status.Text = DATA_TEXT
	waitFor(DATA_SECONDS, function()
		if player:GetAttribute("DataWait") == true then
			status.Text = DATA_WAIT_TEXT
			status.TextColor3 = COLOR_WAIT
		end
		return player:GetAttribute("DefenseLevel") ~= nil and player:GetAttribute("Base") ~= nil
	end)
	marks.ready = os.clock()
	nextPhase("Settle", SETTLE_TEXT)
	settled = 0
	waitFor(SETTLE_MAX, function()
		startNear(map)
		return settled >= SETTLE_SECONDS
	end)
	marks.settle = os.clock()
	nextPhase("Done", DONE_TEXT)
	waitFor(FILL_SECONDS, function()
		return shown >= FULL_AT
	end)
	task.wait(DONE_SECONDS)
end
pcall(run)

if partsConn then
	partsConn:Disconnect()
end
if childConn then
	childConn:Disconnect()
end
local function span(from, to)
	return math.max(0, (marks[to] or os.clock()) - (marks[from] or marks.start))
end
local total = os.clock() - marks.start
print(string.format("[Loading] %.1f초: 게임 %.1f · 맵 %.1f (기지 둘레 %d/%s, 전체 %d) · 캐릭터·저장 %.1f · 화면 %.1f",
	total, span("start", "game"), span("game", "world"), nearParts, tostring(nearExpected() or "?"), parts,
	span("world", "ready"), span("ready", "settle")))
pcall(Net.request, "LoadReport", total, span("start", "game"), span("game", "world"), span("world", "ready"),
	span("ready", "settle"))
local fade = TweenInfo.new(FADE_SECONDS)
TweenService:Create(back, fade, { BackgroundTransparency = 1 }):Play()
for _, label in ipairs({ dino, status, percent }) do
	TweenService:Create(label, fade, { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
end
for _, f in ipairs({ barBack, bar }) do
	TweenService:Create(f, fade, { BackgroundTransparency = 1 }):Play()
end
back.Active = false
task.wait(FADE_SECONDS)
frame:Disconnect()
gui:Destroy()
player:SetAttribute("Loading", nil)
