--[[
MiningFx: what mining looks like (display only; the server decides every turn in Minerals).

- Whole-body mining swing: while a player's attribute Mining is true (it replicates), every client
  moves that character's R15 joints itself, so everyone sees it without uploading an animation:
  wind-up (both arms lift the pickaxe overhead, the body leans back, the head looks up), a fast
  two-handed strike (the body bends forward, the knees crouch, the head follows the pickaxe), then
  recovery. It blends over whatever the character's own animation does, in and out smoothly.
  The joints are set in RunService.Stepped: the Animator writes the joints' Transform before that
  every frame, so anything set earlier (RenderStepped) is overwritten and never shows.
  A joint is a Motor6D, or an AnimationConstraint of the same name in places with Roblox's avatar
  joint upgrade (Workspace.AvatarJointUpgrade); both have Transform.
- Underneath, the player's own character also plays Roblox's tool slash animation (it replicates),
  so an arm swing still shows if a rig's joints cannot be found (R6, custom rigs).
- A loading bar above the bag bar fills over the current turn, from the server's MineStart (server
  time) and MineDuration attributes, with the time left.
- The mineral in reach gets an outline and a small "⛏ 캐기!" button beside it; the button, tapping the
  mineral, or the E key starts (and stops) mining it. The names over the minerals are off until the
  player switches them on (보기 설정 "광물 이름", setting HideMineralNames).
- (2026-10-04, "본게임에서 광질 조금 하다 가던데") one too hard for my pickaxe (Formulas.mineLocked) has a grey "🔒 n티어"
  button, and one I can mine in reach wins over it; pressing it (or tapping it: the server's Net push MineLocked) says
  which pickaxe it needs and points an arrow over my head at the nearest one I can mine (Shared/PointerArrow).
- (2026-10-04, same) every finished turn (Net push Mined): "+1 💧" in the stone's color and "💰 +32" (what it will pay)
  pop up beside me and fade, with a light ding.
- Starlight (색순환): the parts the server marked Crystal on a starlight node, and its name label,
  cycle through the rainbow.
- 대박 광물 (Net push Jackpot): a golden burst and confetti on the mineral, the big draw fanfare and
  "🌟 대박! +money" rising over it, on every screen nearby.
]]

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Fx = require(Shared:WaitForChild("Fx"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Lang = require(Shared:WaitForChild("Lang")) -- (Lang.set: a text set every frame, only when it changes)
local Formulas = require(Shared:WaitForChild("Formulas"))
local Unlock = require(Shared:WaitForChild("Unlock"))
local Notices = require(Shared:WaitForChild("Notices"))
local PointerArrow = require(Shared:WaitForChild("PointerArrow"))
local TweenService = game:GetService("TweenService")

local player = Players.LocalPlayer

-- display only
local SLASH = { -- Roblox's default "toolslash" animations
	[Enum.HumanoidRigType.R15] = "rbxassetid://522635514",
	[Enum.HumanoidRigType.R6] = "rbxassetid://129967390",
}
local SWING_SPEED = 1.2 -- R6 animation playback speed
local SWING_SECONDS = 0.95 -- one whole-body swing
local BLEND_SECONDS = 0.15 -- fading in and out of the swing
local SWING_DISTANCE = 150 -- characters farther than this from the camera are not animated
local BAR_SIZE = UDim2.fromOffset(260, 22)
local BAR_POS = UDim2.new(0.5, 0, 1, -92)
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_FILL = Color3.fromRGB(255, 200, 60)
local STARLIGHT_CYCLE_SECONDS = 4 -- one trip around the rainbow
local COLOR_STEP = 0.1 -- seconds between two color steps of the cycle
local NEAR_CHECK = 0.15 -- seconds between looks for the mineral in reach
-- (2026-10-03, "배틀필드 내에서 렉이 좀 걸리는거 같다": 880 minerals, about 410 of them with a light, 670 with sparkles
-- and 100 with a shimmering shell, nearly all streamed in on the battlefield) a mineral's aura only near the camera
local AURA_LIGHT_NEAR = 70 -- studs: its glow (a PointLight, the dearest on a phone)
local AURA_SPARKLE_NEAR = 120 -- its sparkles
local AURA_SHELL_NEAR = 220 -- its shimmering shell
local AURA_LOD_EVERY = 0.5 -- seconds between looks
local MINE_BUTTON = UDim2.fromOffset(70, 22)
local MINE_BUTTON_UP = 2.5 -- studs over my character's middle (the button stands at the mineral's side toward me)
local MINE_KEY = Enum.KeyCode.E
local COLOR_MINE = Color3.fromRGB(80, 190, 110)
local COLOR_STOP = Color3.fromRGB(235, 90, 80)
local COLOR_STROKE = Color3.fromRGB(255, 255, 255)
local STRIKE_AT = 0.6 -- the moment in the swing (0-1) the pickaxe hits: a clink and flying chips
local CHIP_COLORS = { Color3.fromRGB(170, 160, 150), Color3.fromRGB(255, 240, 200) }
local CHIP_REACH = 3 -- studs in front of the character
local JACKPOT_COLORS = { Color3.fromRGB(255, 215, 60), Color3.fromRGB(255, 255, 255), Color3.fromRGB(255, 160, 40) }
local JACKPOT_RISE = 8 -- studs the "대박!" text rises
local JACKPOT_SECONDS = 2.5
local JACKPOT_DISTANCE = 250 -- farther screens see nothing
local JACKPOT_TEXT_SIZE = UDim2.fromOffset(220, 50)
-- (2026-10-04, "본게임에서 광질 조금 하다 가던데") a mineral too hard for my pickaxe: a grey button, and the arrow over my head
-- to the nearest one I can mine
local COLOR_LOCKED = Color3.fromRGB(110, 110, 125)
local GUIDE_SECONDS = 10 -- the arrow stays this long, or until that mineral is in reach (or gone)
local GUIDE_RANGE = 300 -- studs: the nearest one I can mine within this
local GUIDE_UP = 4.5 -- studs over my middle (the carried keys' arrow has this spot while I carry keys: no guide then)
local GUIDE_SIZES = { 15, 250, 1.7, 0.6 } -- PointerArrow.point: big at 15 studs or nearer, small at 250 or farther
local GUIDE_COLOR = Color3.fromRGB(80, 200, 255)
local OPENED_GUIDE_RANGE = 700
local OPENED_GUIDE_SECONDS = 25
-- (2026-10-04, same) what a finished turn put in my bag, beside me: "+1 💧" in the stone's color over "💰 +32"
local GRADE_ICONS = { Droplet = "💧", Sprout = "🌱", Grape = "🍇", Strawberry = "🍓", Sunlight = "☀️", Starlight = "✨", Treasure = "💰" }
local POP_SIZE = UDim2.fromOffset(130, 52)
local POP_FROM = Vector3.new(2, 2.4, 0) -- studs from my middle, on the screen (right, up)
local POP_JITTER = 0.6 -- studs either way across
local POP_RISE = 3
local POP_SECONDS = 0.9
local POP_GROW_SECONDS = 0.2
local POP_POOL = 4 -- at most this many at once (a fast pickaxe reuses the oldest)
local POP_SOUND_GAP = 0.12 -- seconds at least between two dings
local POP_PITCH = { 0.95, 1.1 }
local POP_MONEY_COLOR = Color3.fromRGB(255, 220, 90)

-- key poses of the swing: joint -> { pitch (about the joint's X: + = forward for limbs, backward for
-- the upper body), yaw (about Y), drop (studs down, Root only) }. Characters face -Z.
local POSES = {
	rest = {},
	windup = { -- the pickaxe held high overhead
		RightShoulder = { 2.75, 0.25 }, LeftShoulder = { 2.75, -0.25 },
		RightElbow = { 0.5 }, LeftElbow = { 0.5 },
		Waist = { 0.2 }, Neck = { 0.2 },
		RightHip = { 0.05 }, LeftHip = { 0.05 },
	},
	strike = { -- brought down in front, bent over, knees bent
		RightShoulder = { 0.85, 0.35 }, LeftShoulder = { 0.85, -0.35 },
		RightElbow = { 0.1 }, LeftElbow = { 0.1 },
		Waist = { -0.55 }, Neck = { -0.35 },
		Root = { -0.12, 0, 0.35 },
		RightHip = { 0.55 }, LeftHip = { 0.55 },
		RightKnee = { -0.9 }, LeftKnee = { -0.9 },
		RightAnkle = { 0.35 }, LeftAnkle = { 0.35 },
	},
}
-- the swing: { time (0-1 of SWING_SECONDS), pose }, eased between
local KEYS = { { 0, "rest" }, { 0.45, "windup" }, { 0.6, "strike" }, { 0.75, "strike" }, { 1, "rest" } }
local JOINTS = { "RightShoulder", "LeftShoulder", "RightElbow", "LeftElbow", "Waist", "Neck", "Root",
	"RightHip", "LeftHip", "RightKnee", "LeftKnee", "RightAnkle", "LeftAnkle" }

-- ---------------------------------------------------------------------------
-- Whole-body swing for every mining character (R15)
-- ---------------------------------------------------------------------------

local rigs = setmetatable({}, { __mode = "k" }) -- [character] = { joints, weight, clock }
local warned = setmetatable({}, { __mode = "k" }) -- [character] = true once a partial rig was reported
-- (2026-10-04, "게임 최적화") a rig still missing joints was searched again every frame (all of the character's
-- parts and accessories, for every such player in sight): once every RIG_RETRY seconds at most
local RIG_RETRY = 1
local triedAt = setmetatable({}, { __mode = "k" }) -- [character] = os.clock() of the last search that found too few

local function rigOf(character)
	local r = rigs[character]
	if r then
		return r
	end
	if triedAt[character] and os.clock() - triedAt[character] < RIG_RETRY then
		return nil
	end
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not humanoid or humanoid.RigType ~= Enum.HumanoidRigType.R15 then
		return nil
	end
	local joints = {}
	for _, d in ipairs(character:GetDescendants()) do
		if (d:IsA("Motor6D") or d:IsA("AnimationConstraint")) and table.find(JOINTS, d.Name) then
			joints[d.Name] = d
		end
	end
	local count = 0
	for _ in pairs(joints) do
		count += 1
	end
	if count < #JOINTS then -- still loading: look again next frame
		if character == player.Character and not warned[character] and humanoid.Health > 0
			and character:FindFirstChild("UpperTorso") and character:FindFirstChild("LeftFoot") then
			warned[character] = true
			local kinds = {} -- what the rig's joints are, to tell why
			for _, d in ipairs(character:GetDescendants()) do
				if d:IsA("JointInstance") or d:IsA("AnimationConstraint") then
					kinds[d.ClassName] = (kinds[d.ClassName] or 0) + 1
				end
			end
			local seen = {}
			for className, n in pairs(kinds) do
				table.insert(seen, className .. " " .. n)
			end
			warn(string.format("[MiningFx] 캐릭터 관절을 %d/%d개만 찾았습니다 (캐릭터 안: %s). 찾은 관절만 움직입니다", count,
				#JOINTS, #seen > 0 and table.concat(seen, ", ") or "없음"))
		elseif not warned[character] then
			triedAt[character] = os.clock()
			return nil
		end
	end
	r = { joints = joints, weight = 0, clock = 0 }
	rigs[character] = r
	return r
end

local function smooth(t)
	return t * t * (3 - 2 * t)
end

local function poseAt(phase)
	for i = 1, #KEYS - 1 do
		local a, b = KEYS[i], KEYS[i + 1]
		if phase <= b[1] then
			local t = (phase - a[1]) / (b[1] - a[1])
			-- the strike is fast at the end (ease in), the rest is smooth
			t = (a[2] == "windup" and b[2] == "strike") and t * t or smooth(t)
			return POSES[a[2]], POSES[b[2]], t
		end
	end
	return POSES.rest, POSES.rest, 0
end

local function jointTarget(name, from, to, t)
	local a, b = from[name] or {}, to[name] or {}
	local pitch = (a[1] or 0) + ((b[1] or 0) - (a[1] or 0)) * t
	local yaw = (a[2] or 0) + ((b[2] or 0) - (a[2] or 0)) * t
	local drop = (a[3] or 0) + ((b[3] or 0) - (a[3] or 0)) * t
	return CFrame.new(0, -drop, 0) * CFrame.Angles(pitch, yaw, 0)
end

RunService.Stepped:Connect(FrameMeter.wrap("MiningFx", function(_, dt)
	local camera = Workspace.CurrentCamera
	local eye = camera and camera.CFrame.Position
	for _, other in ipairs(Players:GetPlayers()) do
		local character = other.Character
		local root = character and character:FindFirstChild("HumanoidRootPart")
		-- (2026-10-04) a rig is looked for only once they mine (or it was found before)
		if root and eye and (rigs[character] or other:GetAttribute("Mining") == true)
			and (root.Position - eye).Magnitude <= SWING_DISTANCE then
			local r = rigOf(character)
			if r then
				local mining = other:GetAttribute("Mining") == true
				local was = r.weight
				r.weight = math.clamp(r.weight + (mining and dt or -dt) / BLEND_SECONDS, 0, 1)
				if r.weight <= 0 and was > 0 then
					-- joints no animation moves would keep the last swing pose: put them back
					for _, joint in pairs(r.joints) do
						joint.Transform = CFrame.identity
					end
				end
				if r.weight > 0 then
					local before = r.clock
					r.clock = mining and (r.clock + dt / SWING_SECONDS) % 1 or r.clock
					if mining and before < STRIKE_AT and (r.clock >= STRIKE_AT or r.clock < before) then
						local root = character:FindFirstChild("HumanoidRootPart")
						if root then
							local at = root.Position + root.CFrame.LookVector * CHIP_REACH - Vector3.new(0, 1.5, 0)
							Sfx.play("MineHit", at)
							Fx.burst(at, CHIP_COLORS, 8, 12, 0.35, 0.5)
						end
					end
					local from, to, t = poseAt(r.clock)
					for name, joint in pairs(r.joints) do
						-- on top of what the character's animation set this frame
						joint.Transform = joint.Transform:Lerp(jointTarget(name, from, to, t), r.weight)
					end
				else
					r.clock = 0
				end
			end
		end
	end
end))

-- ---------------------------------------------------------------------------
-- Roblox's tool slash on this player's own character (under the whole-body swing)
-- ---------------------------------------------------------------------------

local track = nil

local function stopSwing()
	if track then
		track:Stop()
		track = nil
	end
end

local function startSwing()
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local animator = humanoid and humanoid:FindFirstChildOfClass("Animator")
	if not animator then
		return
	end
	local animation = Instance.new("Animation")
	animation.AnimationId = SLASH[humanoid.RigType] or SLASH[Enum.HumanoidRigType.R15]
	local ok, loaded = pcall(animator.LoadAnimation, animator, animation)
	if not ok then
		warn("[MiningFx] 휘두르기 애니메이션을 불러오지 못했습니다: " .. tostring(loaded))
		return
	end
	track = loaded
	track.Priority = Enum.AnimationPriority.Action
	track.Looped = true
	track:Play(0.1, 1, SWING_SPEED)
end

local function onMiningChanged()
	if player:GetAttribute("Mining") then
		if not track then
			startSwing()
		end
	else
		stopSwing()
	end
end

player:GetAttributeChangedSignal("Mining"):Connect(onMiningChanged)
player.CharacterAdded:Connect(function()
	track = nil -- the old character's track went with it
	task.defer(onMiningChanged)
end)

-- ---------------------------------------------------------------------------
-- Loading bar for this player
-- ---------------------------------------------------------------------------

local gui = Instance.new("ScreenGui")
gui.Name = "MiningBar"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local bar = Instance.new("Frame")
bar.AnchorPoint = Vector2.new(0.5, 1)
bar.Size = BAR_SIZE
bar.Position = BAR_POS
bar.BackgroundColor3 = COLOR_BG
bar.BackgroundTransparency = 0.2
bar.Visible = false
bar.Parent = gui
Instance.new("UICorner").Parent = bar

local fill = Instance.new("Frame")
fill.Size = UDim2.fromScale(0, 1)
fill.BackgroundColor3 = COLOR_FILL
fill.Parent = bar
Instance.new("UICorner").Parent = fill

local text = Instance.new("TextLabel")
text.Size = UDim2.fromScale(1, 1)
text.BackgroundTransparency = 1
text.Font = Enum.Font.GothamBold
text.TextSize = 15
text.TextColor3 = Color3.new(1, 1, 1)
text.TextStrokeTransparency = 0.5
text.ZIndex = 2
text.Parent = bar

RunService.RenderStepped:Connect(FrameMeter.wrap("MiningFx", function()
	local miningNow = player:GetAttribute("Mining")
	bar.Visible = miningNow == true
	if not miningNow then
		return
	end
	local start = player:GetAttribute("MineStart") or 0
	local duration = player:GetAttribute("MineDuration") or 1
	local elapsed = Workspace:GetServerTimeNow() - start
	fill.Size = UDim2.fromScale(math.clamp(elapsed / duration, 0, 1), 1)
	local left = math.max(0, duration - elapsed)
	if left >= 60 then
		Lang.set(text, string.format("캐는 중… %d분 %d초", left // 60, math.floor(left % 60)))
	else
		Lang.set(text, string.format("캐는 중… %.1f초", left))
	end
end))

-- ---------------------------------------------------------------------------
-- Starlight crystals change color
-- ---------------------------------------------------------------------------

local starlight = {} -- [part or name label] = true

-- every mineral's aura (Minerals service addAura: a Part "Aura" with sparkles, maybe a light, maybe a visible shell)
local auras = {} -- [Aura part] = { light, sparkles, shell = bool, near = { light, sparkles, shell } }
local function watchAura(model)
	local function add(aura)
		if aura.Name ~= "Aura" or not aura:IsA("BasePart") or auras[aura] then
			return
		end
		auras[aura] = { light = aura:FindFirstChildOfClass("PointLight"), sparkles = aura:FindFirstChildOfClass("ParticleEmitter"),
			shell = aura.Transparency < 1, near = {} }
	end
	local aura = model:FindFirstChild("Aura")
	if aura then
		add(aura)
	end
	model.ChildAdded:Connect(function(child)
		task.defer(add, child) -- (its light and sparkles come with it)
	end)
end
local sinceAura = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("MiningFx", function(dt)
	sinceAura += dt
	if sinceAura < AURA_LOD_EVERY then
		return
	end
	sinceAura = 0
	local camera = Workspace.CurrentCamera
	if not camera then
		return
	end
	local eye = camera.CFrame.Position
	for aura, a in pairs(auras) do
		if not aura.Parent then
			auras[aura] = nil
		else
			local d = (aura.Position - eye).Magnitude
			local light, sparkles, shell = d <= AURA_LIGHT_NEAR, d <= AURA_SPARKLE_NEAR, d <= AURA_SHELL_NEAR
			if a.near.light ~= light and a.light then
				a.light.Enabled = light
			end
			if a.near.sparkles ~= sparkles and a.sparkles then
				a.sparkles.Enabled = sparkles
			end
			if a.near.shell ~= shell and a.shell then
				aura.LocalTransparencyModifier = shell and 0 or 1
			end
			a.near.light, a.near.sparkles, a.near.shell = light, sparkles, shell
		end
	end
end))

local function watchNode(model)
	watchAura(model)
	if model:GetAttribute("Grade") ~= "Starlight" then
		return
	end
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") and d:GetAttribute("Crystal") then
			starlight[d] = true
		end
	end
	local info = model:FindFirstChild("Info")
	local label = info and info:FindFirstChildOfClass("TextLabel")
	if label then
		starlight[label] = true -- its name too
	end
end

-- the view setting HideMineralNames (player attribute, Settings) turns the names over minerals off
local function labelsShown()
	return player:GetAttribute("HideMineralNames") == false -- off until the player switches them on
end
local function applyLabel(model)
	local info = model:FindFirstChild("Info")
	if info and info:IsA("BillboardGui") then
		info.Enabled = labelsShown()
	end
end
-- (2026-10-02, "광물 이름 숨겼는데 몇 개 뜨는 버그") a name that comes after its mineral (streaming in from
-- far, or made again by the server) is hidden too
local function watchLabel(model)
	applyLabel(model)
	model.ChildAdded:Connect(function(child)
		if child.Name == "Info" then
			task.defer(applyLabel, model)
		end
	end)
end

task.spawn(function()
	local folder = Workspace:WaitForChild("Minerals")
	folder.ChildAdded:Connect(function(model)
		task.defer(watchNode, model) -- attributes and parts arrive with it
		task.defer(watchLabel, model)
	end)
	player:GetAttributeChangedSignal("HideMineralNames"):Connect(function()
		for _, model in ipairs(folder:GetChildren()) do
			applyLabel(model)
		end
	end)
	for _, model in ipairs(folder:GetChildren()) do
		watchLabel(model)
	end
	for _, model in ipairs(folder:GetChildren()) do
		watchNode(model)
	end
end)

-- (2026-10-02, "혼자하는데 렉이 좀 있는거 같은데 최적화 해봐": every one recolored every frame) a slow cycle:
-- COLOR_STEP seconds between recolors
local colorSince = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("MiningFx", function(dt)
	colorSince += dt
	if colorSince < COLOR_STEP or not next(starlight) then
		return
	end
	colorSince = 0
	local hue = (os.clock() / STARLIGHT_CYCLE_SECONDS) % 1
	for part in pairs(starlight) do
		if part.Parent and part:IsA("TextLabel") then
			part.TextColor3 = Color3.fromHSV(hue, 0.55, 1)
		elseif part.Parent then
			part.Color = Color3.fromHSV(hue, 0.55, 1)
		else
			starlight[part] = nil
		end
	end
end))

-- ---------------------------------------------------------------------------
-- The mineral in reach: an outline around it and a small "캐기!" button beside it (tapping the
-- mineral works too). The server checks the reach again (Net request Mine).
-- ---------------------------------------------------------------------------

local outline = Instance.new("Highlight")
outline.Name = "MineableOutline"
outline.FillTransparency = 1
outline.OutlineColor = COLOR_STROKE
outline.OutlineTransparency = 0
outline.DepthMode = Enum.HighlightDepthMode.Occluded
outline.Enabled = false
outline.Parent = gui -- (kept when the character respawns)

local mineGui = Instance.new("BillboardGui")
mineGui.Name = "MineButton"
mineGui.Size = MINE_BUTTON
mineGui.AlwaysOnTop = true
mineGui.Active = true
mineGui.Enabled = false
mineGui.ResetOnSpawn = false -- made once by this script: respawning must not delete it
mineGui.Parent = player.PlayerGui
local mineButton = Instance.new("TextButton")
mineButton.Size = UDim2.fromScale(1, 1)
mineButton.Font = Enum.Font.GothamBold
mineButton.TextScaled = true
mineButton.TextColor3 = Color3.new(1, 1, 1)
mineButton.BackgroundColor3 = COLOR_MINE
mineButton.Parent = mineGui
local mineRound = Instance.new("UICorner")
mineRound.CornerRadius = UDim.new(0, 10)
mineRound.Parent = mineButton
local mineStroke = Instance.new("UIStroke")
mineStroke.Color = Color3.new(1, 1, 1)
mineStroke.Thickness = 2
mineStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
mineStroke.Parent = mineButton

local target, targetLocked = nil, false

-- (2026-10-04) too hard for my pickaxe to start (Formulas.mineLocked: the server says no too)
local function lockedFor(model)
	local grade = model:GetAttribute("Grade")
	return grade ~= nil and Formulas.grade(grade) ~= nil and Formulas.mineLocked(player:GetAttribute("PickaxeTier") or 1,
		player:GetAttribute("TrainReal_Power") or player:GetAttribute("PickaxePower") or 0,
		player:GetAttribute("TrainReal_Speed") or player:GetAttribute("PickaxeSpeed") or 0, grade)
end

-- the nearest mineral I can mine (not locked), within GUIDE_RANGE, or nil
local function nearestMinable(root)
	local folder = Workspace:FindFirstChild("Minerals")
	local best, bestD = nil, GUIDE_RANGE
	for _, model in ipairs(folder and folder:GetChildren() or {}) do
		if model:GetAttribute("Radius") and (model:GetAttribute("TurnsLeft") or 1) > 0 and not lockedFor(model)
			and Unlock.mineable(model) then
			local d = model:GetPivot().Position - root.Position
			local dist = Vector3.new(d.X, 0, d.Z).Magnitude
			if dist < bestD then
				best, bestD = model, dist
			end
		end
	end
	return best
end

-- a locked one pressed (or tapped: the server's MineLocked): which pickaxe it needs, and the arrow to one I can mine
local guide = nil -- { model = the mineral the arrow points at, untilAt = os.clock() }
local function lockedHelp(gradeId)
	local grade = type(gradeId) == "string" and Formulas.grade(gradeId)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not grade or not root then
		return
	end
	local spot = nearestMinable(root)
	local tier = player:GetAttribute("PickaxeTier") or 1
	local need = tier < Formulas.minTier(gradeId) and Formulas.minTier(gradeId) or tier + 1
	Notices.show("🔒 너무 단단해요!", string.format(spot and "⛏️ %d티어 곡괭이부터 · ➡️ 화살표의 광물을 캐요"
		or "⛏️ %d티어 곡괭이부터 · 💪 훈련장에서 곡괭이를 키워요", need))
	guide = spot and { model = spot, untilAt = os.clock() + GUIDE_SECONDS } or nil
end
Net.onPush("MineLocked", lockedHelp)

Net.onPush("GradeOpened", function(gradeId)
	Sfx.play("Victory")
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local folder = Workspace:FindFirstChild("Minerals")
	if not root or not folder then
		return
	end
	local best, bestD = nil, OPENED_GUIDE_RANGE
	for _, model in ipairs(folder:GetChildren()) do
		if model:GetAttribute("Grade") == gradeId and model:GetAttribute("Radius") and (model:GetAttribute("TurnsLeft") or 1) > 0 then
			local d = model:GetPivot().Position - root.Position
			local dist = Vector3.new(d.X, 0, d.Z).Magnitude
			if dist < bestD then
				best, bestD = model, dist
			end
		end
	end
	guide = best and { model = best, untilAt = os.clock() + OPENED_GUIDE_SECONDS } or guide
end)

local function mineTarget()
	if target and target.Parent then
		if targetLocked and player:GetAttribute("Mining") ~= true then
			lockedHelp(target:GetAttribute("Grade"))
			return
		end
		Net.request("Mine", target)
	end
end
mineButton.Activated:Connect(mineTarget)
-- the E key does the same (like the other places' prompts); a prompt in reach keeps E for itself
UserInputService.InputBegan:Connect(function(input, processed)
	if not processed and input.KeyCode == MINE_KEY and target then
		mineTarget()
	end
end)

local sinceNear = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("MiningFx", function(dt)
	sinceNear += dt
	if sinceNear < NEAR_CHECK then
		return
	end
	sinceNear = 0
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local folder = Workspace:FindFirstChild("Minerals")
	local best, bestGap, bestLocked = nil, math.huge, true
	-- (2026-10-04) none on a flying dino: over the battlefield it is only to look (the server says no too)
	if root and folder and not player:GetAttribute("Flying") then
		for _, model in ipairs(folder:GetChildren()) do
			local radius = model:GetAttribute("Radius")
			if radius then
				local d = model:GetPivot().Position - root.Position
				local gap = Vector3.new(d.X, 0, d.Z).Magnitude - radius
				if gap <= Config.Mining.Range then
					-- (2026-10-04) one I can mine wins over a locked one nearer
					local locked = lockedFor(model)
					if (bestLocked and not locked) or (locked == bestLocked and gap < bestGap) then
						best, bestGap, bestLocked = model, gap, locked
					end
				end
			end
		end
	end
	target, targetLocked = best, best ~= nil and bestLocked
	outline.Enabled = best ~= nil
	mineGui.Enabled = best ~= nil
	if best then
		outline.Adornee = best
		-- (2026-10-02, "큰 미네랄은 캐기 버튼이 너무 위에 있다. 캐릭터와 미네랄 주변 적당히") on the mineral's
		-- side facing me, at about my head's height (was over the mineral's top: far up on the big ones)
		local part = best:FindFirstChildWhichIsA("BasePart", true)
		mineGui.Adornee = part
		mineGui.Enabled = part ~= nil -- no part yet (streaming): not at the map's middle
		if part then
			local center = best:GetPivot().Position
			local toMe = Vector3.new(root.Position.X - center.X, 0, root.Position.Z - center.Z)
			local side = toMe.Magnitude > 0.1 and toMe.Unit * math.min(best:GetAttribute("Radius"), toMe.Magnitude) or Vector3.zero
			local spot = Vector3.new(center.X + side.X, root.Position.Y + MINE_BUTTON_UP, center.Z + side.Z)
			mineGui.StudsOffsetWorldSpace = spot - part.Position
		end
		local mining = player:GetAttribute("Mining") == true
		local key = UserInputService.KeyboardEnabled and " [E]" or ""
		if targetLocked and not mining then
			local grade = best:GetAttribute("Grade") -- (the tier that opens it: the grade's, or the recommended when that is the turn time)
			local need = player:GetAttribute("PickaxeTier") or 1
			need = need < Formulas.minTier(grade) and Formulas.minTier(grade) or math.max(need + 1, Formulas.minTier(grade))
			Lang.set(mineButton, string.format("🔒 %d티어", need) .. key)
			mineButton.BackgroundColor3 = COLOR_LOCKED
		else
			Lang.set(mineButton, (mining and "⛏ 그만" or "⛏ 캐기!") .. key)
			mineButton.BackgroundColor3 = mining and COLOR_STOP or COLOR_MINE
		end
	end
end))

-- the arrow over my head to the mineral lockedHelp chose, while it lasts
local guideArrow = nil
RunService.RenderStepped:Connect(FrameMeter.wrap("MiningFx", function()
	if not guide then
		return
	end
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local m = guide.model
	local over = not root or not m.Parent or os.clock() > guide.untilAt or (player:GetAttribute("CarriedKeys") or 0) > 0
	if not over then
		local d = m:GetPivot().Position - root.Position
		over = Vector3.new(d.X, 0, d.Z).Magnitude - (m:GetAttribute("Radius") or 0) <= Config.Mining.Range -- (there)
	end
	if over then
		guide = nil
		if guideArrow then
			guideArrow:Destroy()
			guideArrow = nil
		end
		return
	end
	if not guideArrow then
		guideArrow = PointerArrow.make(GUIDE_COLOR)
		guideArrow.Name = "MineGuideArrow"
	end
	local at = root.Position + Vector3.new(0, GUIDE_UP, 0)
	local spot = m:GetPivot().Position
	PointerArrow.point(guideArrow, at, Vector3.new(spot.X, at.Y, spot.Z), GUIDE_SIZES)
end))

-- (2026-10-04) what a finished turn put in my bag (Net push Mined): a few billboards beside me, used in turn
local pops, popNext, popDingAt = {}, 1, 0
local function popLabel(parent, size, pos)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = Enum.Font.GothamBlack
	l.TextScaled = true
	l.Size = size
	l.Position = pos
	l:SetAttribute("KeepText", true) -- (numbers and pictures: nothing to translate)
	l.Parent = parent
	return l
end
for i = 1, POP_POOL do
	local g = Instance.new("BillboardGui")
	g.Name = "MinedPop"
	g.Size = POP_SIZE
	g.AlwaysOnTop = true
	g.Enabled = false
	g.ResetOnSpawn = false
	g.Parent = player.PlayerGui
	local box = Instance.new("Frame") -- (the UIScale's: it grows what is in it)
	box.BackgroundTransparency = 1
	box.Size = UDim2.fromScale(1, 1)
	box.Parent = g
	local count = popLabel(box, UDim2.fromScale(1, 0.6), UDim2.new())
	local money = popLabel(box, UDim2.fromScale(1, 0.4), UDim2.fromScale(0, 0.6))
	money.TextColor3 = POP_MONEY_COLOR
	local grow = Instance.new("UIScale")
	grow.Parent = box
	pops[i] = { gui = g, count = count, money = money, grow = grow, token = 0 }
end
Net.onPush("Mined", function(n, gradeId, money)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local grade = type(gradeId) == "string" and Formulas.grade(gradeId)
	if not root or not grade then
		return
	end
	local p = pops[popNext]
	popNext = popNext % POP_POOL + 1
	p.token += 1
	local token = p.token
	p.count.Text = string.format("+%d %s", tonumber(n) or 1, GRADE_ICONS[gradeId] or "💎")
	p.count.TextColor3 = Color3.fromRGB(grade.Rgb[1], grade.Rgb[2], grade.Rgb[3])
	p.money.Text = string.format("💰 +%s", Formulas.shortNumber(tonumber(money) or 0))
	for _, l in ipairs({ p.count, p.money }) do
		l.TextTransparency, l.TextStrokeTransparency = 0, 0.2
	end
	local from = POP_FROM + Vector3.new((math.random() * 2 - 1) * POP_JITTER, 0, 0)
	p.gui.Adornee = root
	p.gui.StudsOffsetWorldSpace = from
	p.grow.Scale = 0.5
	p.gui.Enabled = true
	TweenService:Create(p.grow, TweenInfo.new(POP_GROW_SECONDS, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
		{ Scale = 1 }):Play()
	TweenService:Create(p.gui, TweenInfo.new(POP_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{ StudsOffsetWorldSpace = from + Vector3.new(0, POP_RISE, 0) }):Play()
	local fade = TweenInfo.new(POP_SECONDS / 2, Enum.EasingStyle.Quad, Enum.EasingDirection.In, 0, false, POP_SECONDS / 2)
	for _, l in ipairs({ p.count, p.money }) do
		TweenService:Create(l, fade, { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
	end
	task.delay(POP_SECONDS, function()
		if p.token == token then
			p.gui.Enabled = false
		end
	end)
	if os.clock() - popDingAt >= POP_SOUND_GAP then
		popDingAt = os.clock()
		Sfx.play("MinePop", nil, POP_PITCH[1] + math.random() * (POP_PITCH[2] - POP_PITCH[1]))
	end
end)

-- 대박 광물: a burst, a fanfare and the money rising over the mineral
Net.onPush("Jackpot", function(userId, position, money)
	local camera = Workspace.CurrentCamera
	if typeof(position) ~= "Vector3" or not camera or (camera.CFrame.Position - position).Magnitude > JACKPOT_DISTANCE then
		return
	end
	Fx.burst(position + Vector3.new(0, 2, 0), JACKPOT_COLORS, 90, 30, 0.8, 1.8)
	Fx.confetti(position + Vector3.new(0, 3, 0))
	Sfx.play("GachaBig", position)
	local anchor = Instance.new("Part")
	anchor.Anchored, anchor.CanCollide, anchor.CanQuery, anchor.CanTouch = true, false, false, false
	anchor.Transparency = 1
	anchor.Size = Vector3.one * 0.2
	anchor.CFrame = CFrame.new(position + Vector3.new(0, 4, 0))
	anchor.Parent = Workspace
	local gui = Instance.new("BillboardGui")
	gui.Size = JACKPOT_TEXT_SIZE
	gui.AlwaysOnTop = true
	gui.Parent = anchor
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBlack
	text.TextScaled = true
	text.TextColor3 = JACKPOT_COLORS[1]
	text.TextStrokeTransparency = 0.2
	local who = Players:GetPlayerByUserId(userId)
	text.Text = string.format("🌟 대박!%s +%s", who and who ~= player and (" " .. who.DisplayName) or "",
		Formulas.shortNumber(tonumber(money) or 0))
	text.Parent = gui
	local info = TweenInfo.new(JACKPOT_SECONDS, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	TweenService:Create(anchor, info, { CFrame = anchor.CFrame + Vector3.new(0, JACKPOT_RISE, 0) }):Play()
	TweenService:Create(text, info, { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
	task.delay(JACKPOT_SECONDS, function()
		anchor:Destroy()
	end)
end)
