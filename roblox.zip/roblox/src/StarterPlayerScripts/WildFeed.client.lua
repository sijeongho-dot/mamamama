local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Lang = require(Shared:WaitForChild("Lang"))
local Net = require(Shared:WaitForChild("Net"))

local player = Players.LocalPlayer

local FONT = Enum.Font.GothamBold
local PANEL = UDim2.fromOffset(190, 64)
local PANEL_POS = UDim2.new(0.5, 0, 1, -96)
local BAR_H = 10
local BUTTON_H = 40
local COLOR_BG = Color3.fromRGB(30, 30, 40)
local COLOR_BAR = Color3.fromRGB(120, 220, 120)
local COLOR_BAR_LOW = Color3.fromRGB(240, 110, 90)
local COLOR_FEED = Color3.fromRGB(215, 70, 80)
local COLOR_OFF = Color3.fromRGB(90, 95, 110)
local LOW_SHARE = 0.3

local gui = Instance.new("ScreenGui")
gui.Name = "WildFeed"
gui.ResetOnSpawn = false
gui.Enabled = false
gui.Parent = player:WaitForChild("PlayerGui")

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(0.5, 1)
panel.Position = PANEL_POS
panel.Size = PANEL
panel.BackgroundTransparency = 1
panel.Parent = gui

local barBack = Instance.new("Frame")
barBack.Size = UDim2.new(1, 0, 0, BAR_H)
barBack.BackgroundColor3 = COLOR_BG
barBack.BackgroundTransparency = 0.3
barBack.BorderSizePixel = 0
barBack.Parent = panel
local fill = Instance.new("Frame")
fill.Size = UDim2.fromScale(1, 1)
fill.BackgroundColor3 = COLOR_BAR
fill.BorderSizePixel = 0
fill.Parent = barBack
for _, f in ipairs({ barBack, fill }) do
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0.5, 0)
	c.Parent = f
end

local button = Instance.new("TextButton")
button.AnchorPoint = Vector2.new(0, 1)
button.Position = UDim2.fromScale(0, 1)
button.Size = UDim2.new(1, 0, 0, BUTTON_H)
button.Font = FONT
button.TextSize = 16
button.TextColor3 = Color3.new(1, 1, 1)
button.BackgroundColor3 = COLOR_FEED
button.Parent = panel
do
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 10)
	c.Parent = button
end

local w = Config.Wildlife
local endsAt, total, feedsLeft = 0, 1, 0

local function refresh()
	local food = player:GetAttribute("Fruit") or 0
	local keys = (player:GetAttribute("CarriedKeys") or 0) > 0
	button.Visible = feedsLeft > 0 and not keys
	local can = food >= w.FeedFood
	button.BackgroundColor3 = can and COLOR_FEED or COLOR_OFF
	button.AutoButtonColor = can
	Lang.set(button, can and string.format("🍎 먹이 주기 +%d초", w.FeedSeconds) or "🍎 먹이가 없어요")
end

player:GetAttributeChangedSignal("WildRiding"):Connect(function()
	local seconds = player:GetAttribute("WildRiding")
	if seconds then
		endsAt, total, feedsLeft = os.clock() + seconds, seconds, w.FeedMax
		refresh()
		gui.Enabled = true
	else
		gui.Enabled = false
	end
end)
player:GetAttributeChangedSignal("Fruit"):Connect(refresh)
player:GetAttributeChangedSignal("CarriedKeys"):Connect(refresh)

button.Activated:Connect(function()
	if (player:GetAttribute("Fruit") or 0) >= w.FeedFood then
		Net.request("WildFeed")
	end
end)

Net.onPush("WildFed", function(left, remaining)
	endsAt = os.clock() + left
	total = math.max(total, left)
	feedsLeft = remaining
	refresh()
end)

RunService.RenderStepped:Connect(function()
	if not gui.Enabled then
		return
	end
	local share = math.clamp((endsAt - os.clock()) / total, 0, 1)
	fill.Size = UDim2.fromScale(share, 1)
	fill.BackgroundColor3 = share < LOW_SHARE and COLOR_BAR_LOW or COLOR_BAR
end)
