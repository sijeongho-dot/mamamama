--[[
Lessons (2026-10-03, "30이나 걸려 튜토가??" → "그렇게 바꿔"): the tutorial's first run is short (about 5 minutes); the
rest are lessons (Config.Tutorial.Parts with Lesson), learned on the tutorial field like a part's replay. Coco asks
about each one once, when it is needed and its reward is still to come (player attribute LessonsDue; LessonsOffered:
already asked, Net request LessonOffered(part) marks it). A lesson's Offer comes true on: Level (the defense level
reached, player attribute DefenseLevel), PromoFail (a promotion lost: PromoRetryAt), Battlefield (standing on the
battlefield, outside SafeZones), Night (ReplicatedStorage Night).

A small card in the middle: Coco's question (the part's Ask), the lesson's name, its 🎁 and two buttons: "📖 배우러
가기" (Net request TutorialReplay(part): to the field and back, the Tutorial service pays it there) and "나중에" (the
lesson stays in ⚙️ 설정 → 📖 코코에게 배우기). Not during the tutorial, on the field, in a race or hide-and-seek, with a
window open or with the language still to pick; one at a time, a while apart.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local CARD_SIZE = UDim2.fromOffset(320, 176)
local CARD_SCREEN_SHARE = 0.6
local COLOR_BG = Color3.fromRGB(30, 34, 50)
local COLOR_TITLE = Color3.fromRGB(150, 255, 220)
local COLOR_SOFT = Color3.fromRGB(200, 200, 210)
local COLOR_GIFT = Color3.fromRGB(255, 220, 110)
local COLOR_GO = Color3.fromRGB(70, 180, 90)
local COLOR_LATER = Color3.fromRGB(90, 100, 130)
local STROKE_COLOR = Color3.fromRGB(150, 255, 220)
local CHECK_EVERY = 2 -- seconds between looks for a lesson to offer
local SHOW_SECONDS = 30 -- the card goes by itself after this
local GAP_SECONDS = 90 -- at least this long between two offers
local FIRST_WAIT = 20 -- seconds after joining before the first (the welcome-back card and the news come first)

local gui = Instance.new("ScreenGui")
gui.Name = "Lessons"
gui.ResetOnSpawn = false
gui.DisplayOrder = 5
gui.Parent = player:WaitForChild("PlayerGui")

local card = Instance.new("Frame")
card.Name = "LessonOffer"
card.Size = CARD_SIZE
card.BackgroundColor3 = COLOR_BG
card.BackgroundTransparency = 0.1
card.Visible = false
card.Active = true
card.Parent = gui
do
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 14)
	c.Parent = card
	local stroke = Instance.new("UIStroke")
	stroke.Color = STROKE_COLOR
	stroke.Thickness = 2
	stroke.Parent = card
end
Windows.fit(card, { Share = CARD_SCREEN_SHARE })

local function label(text, y, height, size, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextSize = size
	l.TextWrapped = true
	l.TextColor3 = color
	l.Text = text
	l.Position = UDim2.fromOffset(14, y)
	l.Size = UDim2.new(1, -28, 0, height)
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.Parent = card
	return l
end
label("🐣 코코: 배워 볼래?", 10, 24, 18, COLOR_TITLE)
local ask = label("", 36, 38, 14, Color3.new(1, 1, 1))
local lessonLine = label("", 76, 20, 14, COLOR_SOFT)
local giftLine = label("", 98, 20, 14, COLOR_GIFT)

local function button(text, color, x, width)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 15
	b.TextColor3 = Color3.new(1, 1, 1)
	b.BackgroundColor3 = color
	b.Text = text
	b.AnchorPoint = Vector2.new(0, 1)
	b.Position = UDim2.new(0, x, 1, -12)
	b.Size = UDim2.fromOffset(width, 38)
	b.Parent = card
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, 10)
	c.Parent = b
	return b
end
local go = button("📖 배우러 가기", COLOR_GO, 14, 180)
local later = button("나중에", COLOR_LATER, 204, 102)

local shown = nil -- the part on the card
local shownAt = 0
local lastOffer = os.clock() - GAP_SECONDS + FIRST_WAIT

local function hide()
	card.Visible = false
	shown = nil
end
go.Activated:Connect(function()
	local part = shown
	hide()
	if part and player:GetAttribute("TutorialStep") == nil and not player:GetAttribute("TutorialTravel") then
		Net.request("TutorialReplay", part.Id)
	end
end)
later.Activated:Connect(hide)

local function list(name)
	local set = {}
	for id in string.gmatch(player:GetAttribute(name) or "", "[^,]+") do
		set[id] = true
	end
	return set
end

-- is this lesson needed now?
local function wanted(offer)
	if offer.Level and not player:GetAttribute("FreshStart") and (player:GetAttribute("DefenseLevel") or 1) >= offer.Level then
		return true
	end
	if offer.PromoFail and player:GetAttribute("PromoRetryAt") ~= nil then
		return true
	end
	if offer.Battlefield then
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if root and not SafeZones.isSafe(root.Position) and not SafeZones.inSky(player, root.Position) then -- (not flying over it)
			return true
		end
	end
	if offer.Night and ReplicatedStorage:GetAttribute("Night") == true then
		return true
	end
	return false
end

-- can a card show now?
local function free()
	return player:GetAttribute("LessonsDue") ~= nil and ReplicatedStorage:GetAttribute("TutorialField") ~= true
		and player:GetAttribute("TutorialStep") == nil and not player:GetAttribute("TutorialTravel")
		and not player:GetAttribute("LanguagePick") and not player:GetAttribute("CocoIntro") and not player:GetAttribute("FirstFight")
		and player:GetAttribute("Racing") == nil
		and player:GetAttribute("HideSeekRoom") == nil and not Windows.anyOpen()
end

local function offer(part)
	shown, shownAt, lastOffer = part, os.clock(), os.clock()
	ask.Text = part.Ask or ""
	lessonLine.Text = part.Name
	giftLine.Text = string.format("🎁 처음 배우면 %s", Formulas.rewardShortText(part.Reward or {}))
	card.Visible = true
	Sfx.play("NpcHello")
	Net.request("LessonOffered", part.Id) -- (asked once, whatever the answer)
end

task.spawn(function()
	while true do
		task.wait(CHECK_EVERY)
		if shown and (os.clock() - shownAt > SHOW_SECONDS or not free()) then
			hide()
		end
		if not shown and os.clock() - lastOffer >= GAP_SECONDS and free() then
			local due, offered = list("LessonsDue"), list("LessonsOffered")
			for _, part in ipairs(Config.Tutorial.Parts) do
				if part.Lesson and part.Offer and due[part.Id] and not offered[part.Id] and wanted(part.Offer) then
					offer(part)
					break
				end
			end
		end
	end
end)
