--[[
NoAutoTranslate: Roblox's automatic translation stays off for this game's own text (2026-10-01). With
the experience's automatic translation on, Roblox collects the text on players' screens; this game
changes a lot of text every second (timers, distances, rankings, the boards' clocks), and on a phone the
connection to the server stalled until nothing came in ("서버 응답이 늦어요", "받기 0 KB/s", then error 277)
near the boards full of text. Every screen, sign and label made by the game (PlayerGui, and the
SurfaceGuis and BillboardGuis in Workspace) gets AutoLocalize = false, now and whenever one is added.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local WorldWatch = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("WorldWatch"))

local player = Players.LocalPlayer

local function off(inst)
	if inst:IsA("GuiBase2d") then
		pcall(function()
			inst.AutoLocalize = false
		end)
	end
end

local function watch(root)
	for _, d in ipairs(root:GetDescendants()) do
		off(d)
	end
	root.DescendantAdded:Connect(off)
end

watch(player:WaitForChild("PlayerGui"))
WorldWatch.listen({ "GuiBase2d" }, off)
