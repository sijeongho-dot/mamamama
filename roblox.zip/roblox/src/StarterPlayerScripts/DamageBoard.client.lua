local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local Lang = require(Shared:WaitForChild("Lang"))
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

local VIEW_DISTANCE = 170
local CHECK_EVERY = 0.5
local PIXELS_PER_STUD = 40
local ROWS_TOP, ROWS_IDLE = 6, 3
local FRESH_SECONDS = 900
local FONT = Enum.Font.GothamBlack
local COLOR_BG = Color3.fromRGB(26, 30, 52)
local COLOR_STROKE = Color3.fromRGB(255, 205, 90)
local COLOR_TITLE = Color3.fromRGB(255, 215, 100)
local COLOR_SUB = Color3.fromRGB(160, 210, 255)
local COLOR_ROW = Color3.fromRGB(44, 52, 82)
local COLOR_ROW_IDLE = Color3.fromRGB(100, 40, 54)
local COLOR_TRACK = Color3.fromRGB(18, 20, 34)
local COLOR_TEXT = Color3.new(1, 1, 1)
local COLOR_IDLE = Color3.fromRGB(255, 125, 125)
local COLOR_REST = Color3.fromRGB(185, 190, 205)
local COLOR_WIN = Color3.fromRGB(140, 240, 140)
local COLOR_LOSE = Color3.fromRGB(255, 150, 160)
local COLOR_MOVE = Color3.fromRGB(70, 140, 230)
local COLOR_HINT = Color3.fromRGB(255, 235, 160)
local ATTR_COLORS = {
	Fire = Color3.fromRGB(240, 110, 60), Ice = Color3.fromRGB(110, 200, 255), Electric = Color3.fromRGB(250, 220, 70),
	Water = Color3.fromRGB(70, 140, 250), Earth = Color3.fromRGB(190, 140, 80), Poison = Color3.fromRGB(150, 220, 90),
	Neutral = Color3.fromRGB(200, 200, 215),
}
local STROKE_PIXELS = 12
local BORDER_PIXELS = 4
local PULSE_SPEED = 3
local BOARD_LAYOUT = { rank = { 0, 0.06 }, picture = { 0.065, 0.1 }, name = { 0.175, 0.3 }, bar = { 0.485, 0.31 },
	value = { 0.805, 0.185 } }
local WINDOW_LAYOUT = { rank = { 0, 0.05 }, picture = { 0.055, 0.09 }, name = { 0.15, 0.27 }, bar = { 0.43, 0.22 },
	value = { 0.655, 0.135 }, button = { 0.8, 0.195 } }
local WINDOW_SIZE = UDim2.fromOffset(480, 340)
local WINDOW_PAD = 8
local WINDOW_TITLE = 34
local WINDOW_SUB = 22
local WINDOW_ROW = 46

local TITLE = "📊 이번 판 공룡 피해"
local EMPTY = "🦖 공룡을 배치하면 피해가 표시돼요"
local NORMAL = "⚔️ 일반전 누적"
local LIVE_BOSS = "👑 보스전 진행 중"
local LIVE_CHALLENGE = "♾️ 도전 진행 중"
local SYNERGIES = { Predator = "🍖 포식자", Guardian = "🛡️ 수호자", Sky = "🦅 하늘의 지배자" }
local BOSS = "👑 %s 보스"
local WON = "🎉 이겼어요"
local LOST = "💔 졌어요"
local TOTAL = "💥 합계 %s"
local FAR = "💤 공격 못 함"
local REST = "💤 쉬는 중"
local MISSED = "😶 못 맞힘"
local MORE = "➕ 외 %d마리 · 👆 눌러서 전체 보기"
local HINT_MINE = "👆 가까이 가서 눌러요 · 공룡을 골라 옮겨요"
local HINT_FAR = "📍 💤 공룡은 길 가까이 옮겨요 · 👆 가까이 가서 눌러요"
local HINT_OTHER = "👀 %s님의 지난 보스 웨이브"
local NAME = "%s · %s · Lv %d"
local MOVE = "🗺️ 옮기기"
local GONE = "지금 없음"
local NEW_MARK = "🆕 "

local gui = Instance.new("ScreenGui")
gui.Name = "DamageBoard"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local function baseFolder(index)
	local map = Workspace:FindFirstChild("Map")
	return map and index and map:FindFirstChild("Base" .. index) or nil
end

local function decode(raw)
	if type(raw) ~= "string" then
		return nil
	end
	local ok, report = pcall(HttpService.JSONDecode, HttpService, raw)
	if not ok or type(report) ~= "table" or type(report.U) ~= "table" then
		return nil
	end
	return report
end

local function rawReport(index)
	local folder = baseFolder(index)
	return folder and (folder:GetAttribute("LiveDamageReport") or folder:GetAttribute("DamageReport"))
end

local function reportOf(index)
	local folder = baseFolder(index)
	return decode(rawReport(index))
end

local function modeText(report)
	if report.Live then
		return report.M == "Boss" and LIVE_BOSS or report.M == "Challenge" and LIVE_CHALLENGE or NORMAL
	end
	return report.W and WON or LOST
end

local function fresh(report)
	return report ~= nil and not report.Live and type(report.T) == "number" and Workspace:GetServerTimeNow() - report.T < FRESH_SECONDS
end

local function text(parent, words, x, y, w, h, color, align)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextScaled = true
	l.TextWrapped = true
	l.TextColor3 = color or COLOR_TEXT
	l.TextXAlignment = align or Enum.TextXAlignment.Center
	l.Position = UDim2.fromScale(x, y)
	l.Size = UDim2.fromScale(w, h)
	Lang.set(l, words)
	l.Parent = parent
	return l
end

local function corner(parent, scale)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(scale, 0)
	c.Parent = parent
end

local function nameOf(u)
	local species = Formulas.species(u.S)
	local rarity = Formulas.rarity(u.R)
	return string.format(NAME, species and species.Name or tostring(u.S), rarity and rarity.Name or tostring(u.R), u.E or 1)
end

local function statusOf(u, total)
	if u.H and not u.F and not u.Q then
		return "🛡️ 지원 역할", COLOR_SUB
	end
	if (u.D or 0) > 0 then
		return string.format("%d%%", math.floor((u.D / math.max(total, 1)) * 100 + 0.5)), COLOR_TEXT
	elseif u.F then
		return FAR, COLOR_IDLE
	elseif u.Q then
		return REST, COLOR_REST
	end
	return MISSED, COLOR_REST
end

local function fillRow(row, rank, u, most, total, layout, border)
	row.BackgroundColor3 = u.F and COLOR_ROW_IDLE or COLOR_ROW
	corner(row, 0.18)
	DinoPortrait.border(row, u.R, border)
	local rankLabel = text(row, tostring(rank), layout.rank[1], 0.1, layout.rank[2], 0.8, COLOR_SUB)
	local picture = DinoPortrait.new(u.S, UDim2.fromScale(layout.picture[2], 0.92))
	picture.Position = UDim2.fromScale(layout.picture[1], 0.04)
	local square = Instance.new("UIAspectRatioConstraint")
	square.AspectRatio = 1
	square.Parent = picture
	picture.Parent = row
	text(row, nameOf(u), layout.name[1], 0.08, layout.name[2], 0.84, COLOR_TEXT, Enum.TextXAlignment.Left)
	local track = Instance.new("Frame")
	track.BackgroundColor3 = COLOR_TRACK
	track.BorderSizePixel = 0
	track.Position = UDim2.fromScale(layout.bar[1], 0.2)
	track.Size = UDim2.fromScale(layout.bar[2], 0.6)
	track.Parent = row
	corner(track, 0.3)
	local share = math.clamp((u.D or 0) / math.max(most, 1), 0, 1)
	local fill = Instance.new("Frame")
	do
		fill.BackgroundColor3 = ATTR_COLORS[u.A or ""] or ATTR_COLORS.Neutral
		fill.BorderSizePixel = 0
		fill.Size = UDim2.fromScale(share, 1)
		fill.Parent = track
		corner(fill, 0.3)
	end
	local amount = text(track, (u.D or 0) > 0 and Formulas.shortNumber(u.D) or "0", 0.04, 0.05, 0.92, 0.9, COLOR_TEXT,
		Enum.TextXAlignment.Left)
	amount.ZIndex = 3
	local stroke = Instance.new("UIStroke")
	stroke.Thickness = 1.5
	stroke.Parent = amount
	local status, color = statusOf(u, total)
	local statusLabel = text(row, status, layout.value[1], 0.1, layout.value[2], 0.8, color)
	return { row = row, rank = rankLabel, fill = fill, amount = amount, status = statusLabel }
end

local function refreshRow(view, rank, u, most, total)
	view.rank.Text = tostring(rank)
	view.fill.Size = UDim2.fromScale(math.clamp((u.D or 0) / math.max(most, 1), 0, 1), 1)
	view.amount.Text = Formulas.shortNumber(u.D or 0)
	local status, color = statusOf(u, total)
	Lang.set(view.status, status)
	view.status.TextColor3 = color
	view.row.BackgroundColor3 = u.F and COLOR_ROW_IDLE or COLOR_ROW
end

local boards = {}

local function drawBoard(entry, report, index)
	local surface = entry.gui
	surface:ClearAllChildren()
	local back = Instance.new("Frame")
	back.Size = UDim2.fromScale(1, 1)
	back.BackgroundColor3 = COLOR_BG
	back.BorderSizePixel = 0
	back.Parent = surface
	corner(back, 0.03)
	local stroke = Instance.new("UIStroke")
	stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	stroke.Color = COLOR_STROKE
	stroke.Thickness = STROKE_PIXELS
	stroke.Parent = back
	entry.stroke = stroke
	entry.fresh = fresh(report)
	text(back, (entry.fresh and NEW_MARK or "") .. TITLE, 0.03, 0.015, 0.94, 0.1, COLOR_TITLE)
	if not report then
		text(back, EMPTY, 0.06, 0.32, 0.88, 0.3, COLOR_SUB)
		return
	end
	text(back, report.Live and modeText(report) or string.format(BOSS, Formulas.levelText(report.L or 1)), 0.03, 0.12, 0.34, 0.06, COLOR_SUB, Enum.TextXAlignment.Left)
	text(back, report.Live and "" or modeText(report), 0.38, 0.12, 0.26, 0.06, report.W and COLOR_WIN or COLOR_LOSE)
	text(back, string.format(TOTAL, Formulas.shortNumber(report.N or 0)), 0.65, 0.12, 0.32, 0.06, COLOR_SUB,
		Enum.TextXAlignment.Right)
	local rows, more = Formulas.damageRows(report.U, ROWS_TOP, ROWS_IDLE)
	local most, idle = 1, false
	for _, u in ipairs(rows) do
		most = math.max(most, u.D or 0)
		idle = idle or u.F ~= nil
	end
	local top, bottom, gap = 0.195, 0.905, 0.008
	local h = (bottom - top - gap * (ROWS_TOP + ROWS_IDLE - 1)) / (ROWS_TOP + ROWS_IDLE)
	for i, u in ipairs(rows) do
		local row = Instance.new("Frame")
		row.Position = UDim2.fromScale(0.025, top + (i - 1) * (h + gap))
		row.Size = UDim2.fromScale(0.95, h)
		row.Parent = back
		fillRow(row, i, u, most, report.N or 0, BOARD_LAYOUT, BORDER_PIXELS)
	end
	local folder = baseFolder(index)
	local ownerId = folder and folder:GetAttribute("OwnerUserId")
	local hint
	if ownerId ~= player.UserId then
		local owner = ownerId and Players:GetPlayerByUserId(ownerId)
		hint = string.format(HINT_OTHER, owner and owner.DisplayName or "?")
	elseif more > 0 then
		hint = string.format(MORE, more)
	else
		hint = idle and HINT_FAR or HINT_MINE
	end
	text(back, hint, 0.03, 0.92, 0.94, 0.065, COLOR_HINT)
end

local window = Instance.new("Frame")
window.Name = "DamageWindow"
window.AnchorPoint = Vector2.new(0.5, 0.5)
window.Position = UDim2.fromScale(0.5, 0.5)
window.Size = WINDOW_SIZE
window.BackgroundColor3 = COLOR_BG
window.Visible = false
window.Parent = gui
corner(window, 0.04)
do
	local stroke = Instance.new("UIStroke")
	stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	stroke.Color = COLOR_STROKE
	stroke.Thickness = 3
	stroke.Parent = window
end
local windowTitle = Instance.new("TextLabel")
windowTitle.BackgroundTransparency = 1
windowTitle.Font = FONT
windowTitle.TextScaled = true
windowTitle.TextColor3 = COLOR_TITLE
windowTitle.Position = UDim2.fromOffset(WINDOW_PAD, 4)
windowTitle.Size = UDim2.new(1, -WINDOW_PAD * 2 - 44, 0, WINDOW_TITLE - 6)
windowTitle.Parent = window
local windowSub = Instance.new("TextLabel")
windowSub.BackgroundTransparency = 1
windowSub.Font = FONT
windowSub.TextScaled = true
windowSub.TextColor3 = COLOR_SUB
windowSub.Position = UDim2.fromOffset(WINDOW_PAD, WINDOW_TITLE)
windowSub.Size = UDim2.new(1, -WINDOW_PAD * 2, 0, WINDOW_SUB - 4)
windowSub.Parent = window
local list = Instance.new("ScrollingFrame")
list.BackgroundTransparency = 1
list.BorderSizePixel = 0
list.Position = UDim2.fromOffset(WINDOW_PAD, WINDOW_TITLE + WINDOW_SUB)
list.Size = UDim2.new(1, -WINDOW_PAD * 2, 1, -WINDOW_TITLE - WINDOW_SUB - WINDOW_PAD)
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.ScrollBarThickness = 6
list.Parent = window
local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 4)
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = list
Windows.fit(window)
Windows.register(window)

local shownIndex = nil
local windowRows = {}
local windowRaw

local function placedNow(index, id)
	local folder = baseFolder(index)
	local units = folder and folder:FindFirstChild("DefenseUnits")
	return units ~= nil and units:FindFirstChild(id) ~= nil
end

local function openWindow(index)
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
	shownIndex = index
	windowRows = {}
	windowRaw = rawReport(index)
	local report = reportOf(index)
	local folder = baseFolder(index)
	local mine = folder ~= nil and folder:GetAttribute("OwnerUserId") == player.UserId
	Lang.set(windowTitle, TITLE)
	if not report then
		Lang.set(windowSub, EMPTY)
		window.Visible = true
		return
	end
	Lang.set(windowSub, string.format(BOSS, Formulas.levelText(report.L or 1)) .. " · " .. modeText(report) .. " · "
		.. string.format(TOTAL, Formulas.shortNumber(report.N or 0)))
	local rows = Formulas.damageRows(report.U, #report.U, #report.U)
	local most = 1
	for _, u in ipairs(rows) do
		most = math.max(most, u.D or 0)
	end
	for i, u in ipairs(rows) do
		local row = Instance.new("Frame")
		row.LayoutOrder = i
		row.Size = UDim2.new(1, -8, 0, WINDOW_ROW)
		row.Parent = list
		windowRows[u.I] = fillRow(row, i, u, most, report.N or 0, WINDOW_LAYOUT, 2)
		if mine then
			local b = Instance.new("TextButton")
			b.Name = "MoveButton"
			b.Font = FONT
			b.TextScaled = true
			b.TextColor3 = COLOR_TEXT
			b.Position = UDim2.fromScale(WINDOW_LAYOUT.button[1], 0.12)
			b.Size = UDim2.fromScale(WINDOW_LAYOUT.button[2], 0.76)
			b.Parent = row
			corner(b, 0.25)
			local here = placedNow(index, u.I)
			b.BackgroundColor3 = here and COLOR_MOVE or COLOR_TRACK
			b.AutoButtonColor = here
			Lang.set(b, here and MOVE or GONE)
			if here then
				b.Activated:Connect(function()
					window.Visible = false
					player:SetAttribute("TopViewPick", u.I)
				end)
			end
		end
	end
	list.CanvasPosition = Vector2.zero
	window.Visible = true
	if mine then
		Net.request("DamageLook")
	end
end

ProximityPromptService.PromptTriggered:Connect(function(prompt)
	if prompt:GetAttribute("Kind") ~= "DamageBoard" then
		return
	end
	local index = prompt.Parent and prompt.Parent:GetAttribute("BaseIndex")
	if window.Visible and shownIndex == index then
		window.Visible = false
		return
	end
	openWindow(index)
end)

local function boardParts()
	local map = Workspace:FindFirstChild("Map")
	local holder = map and map:FindFirstChild("DefenseGuides")
	local found = {}
	for _, model in ipairs(holder and holder:GetChildren() or {}) do
		local part = model:FindFirstChild("DamageBoard")
		if part and part:IsA("BasePart") then
			table.insert(found, part)
		end
	end
	return found
end

local function refreshWindow()
	if not window.Visible or not shownIndex then
		return
	end
	local raw = rawReport(shownIndex)
	if raw == windowRaw then
		return
	end
	local report = decode(raw)
	if not report then
		return
	end
	windowRaw = raw
	local n = 0
	for _ in pairs(windowRows) do n += 1 end
	local rebuild = n ~= #report.U
	for _, u in ipairs(report.U) do
		rebuild = rebuild or not windowRows[u.I]
	end
	if rebuild then
		local position = list.CanvasPosition
		openWindow(shownIndex)
		list.CanvasPosition = position
		return
	end
	Lang.set(windowSub, modeText(report) .. " · " .. string.format(TOTAL, Formulas.shortNumber(report.N or 0)))
	local rows = Formulas.damageRows(report.U, #report.U, #report.U)
	local most = 1
	for _, u in ipairs(rows) do most = math.max(most, u.D or 0) end
	for i, u in ipairs(rows) do
		local view = windowRows[u.I]
		view.row.LayoutOrder = i
		refreshRow(view, i, u, most, report.N or 0)
	end
end

local hudGui = Instance.new("ScreenGui")
hudGui.Name = "LiveDamageHUD"
hudGui.ResetOnSpawn = false
hudGui.IgnoreGuiInset = true
hudGui.DisplayOrder = 2
hudGui.Parent = gui.Parent
local compact = Instance.new("Frame")
compact.Name = "LiveDamage"
compact.AnchorPoint = Vector2.new(1, 0)
compact.Position = UDim2.new(1, -10, 0.28, 0)
compact.Size = UDim2.fromOffset(226, 140)
compact.BackgroundColor3 = COLOR_BG
compact.BackgroundTransparency = 0.15
compact.BorderSizePixel = 0
compact.Parent = hudGui
corner(compact, 0.07)
local compactTitle = Instance.new("TextButton")
compactTitle.BackgroundTransparency = 1
compactTitle.Position = UDim2.fromOffset(8, 3)
compactTitle.Size = UDim2.new(1, -40, 0, 24)
compactTitle.Font = FONT
compactTitle.TextSize = 12
compactTitle.TextColor3 = COLOR_TITLE
compactTitle.TextXAlignment = Enum.TextXAlignment.Left
Lang.set(compactTitle, TITLE)
compactTitle.Parent = compact
local fold = Instance.new("TextButton")
fold.Position = UDim2.new(1, -30, 0, 1)
fold.Size = UDim2.fromOffset(28, 28)
fold.BackgroundTransparency = 1
fold.TextColor3 = COLOR_TEXT
fold.TextSize = 20
fold.Text = "−"
fold.Parent = compact
local compactBody = Instance.new("Frame")
compactBody.Position = UDim2.fromOffset(8, 29)
compactBody.Size = UDim2.new(1, -16, 0, 105)
compactBody.BackgroundTransparency = 1
compactBody.Parent = compact
local compactSub = text(compactBody, "", 0, 0, 1, 0.18, COLOR_SUB, Enum.TextXAlignment.Left)
local compactRows = {}
for i = 1, 3 do
	compactRows[i] = text(compactBody, "", 0, 0.20 + (i - 1) * 0.19, 1, 0.18, COLOR_TEXT, Enum.TextXAlignment.Left)
end
local compactSynergy = text(compactBody, "", 0, 0.81, 1, 0.18, COLOR_HINT, Enum.TextXAlignment.Left)
local folded = false
local compactPhone = false
fold.Activated:Connect(function()
	if compactPhone then
		openWindow(player:GetAttribute("TopViewBase") or player:GetAttribute("Base"))
		return
	end
	folded = not folded
	compactBody.Visible = not folded
	fold.Text = folded and "+" or "−"
end)
compactTitle.Activated:Connect(function()
	openWindow(player:GetAttribute("TopViewBase") or player:GetAttribute("Base"))
end)
local compactRaw
local function updateCompact()
	local index = player:GetAttribute("TopViewBase") or player:GetAttribute("Base")
	local raw = rawReport(index)
	compact.Visible = index ~= nil and not Windows.anyOpen()
	local camera = Workspace.CurrentCamera
	local viewport = hudGui.AbsoluteSize
	if not viewport or viewport.X <= 0 then
		viewport = camera and camera.ViewportSize or Vector2.new(667, 375)
	end
	compactPhone = viewport.Y < 500 or viewport.X < 800
	compact.AnchorPoint = compactPhone and Vector2.new(0.5, 0) or Vector2.new(1, 0)
	compact.Position = compactPhone and UDim2.new(0.5, 0, 0, 42) or UDim2.new(1, -190, 0, 90)
	compact.Size = UDim2.fromOffset(math.min(226, viewport.X * 0.36), compactPhone and 32 or folded and 29 or 140)
	compactTitle.Size = UDim2.new(1, -40, 0, compactPhone and 28 or 24)
	compactTitle.TextSize = compactPhone and 10 or 12
	compactTitle.TextWrapped = true
	compactBody.Visible = not compactPhone and not folded
	fold.Text = compactPhone and "+" or folded and "+" or "−"
	local current = decode(raw)
	local first = current and current.U[1]
	local species = first and Formulas.species(first.S)
	Lang.set(compactTitle, compactPhone and TITLE .. " " .. Formulas.shortNumber(current and current.N or 0)
		.. "\n" .. (species and species.Name or "") .. " " .. (first and Formulas.shortNumber(first.D or 0) or "") or TITLE)
	if compactRaw == raw then
		return
	end
	compactRaw = raw
	local report = decode(raw)
	Lang.set(compactSub, report and modeText(report) .. " · " .. Formulas.shortNumber(report.N or 0) or EMPTY)
	for i, label in ipairs(compactRows) do
		local u = report and report.U[i]
		local species = u and Formulas.species(u.S)
		Lang.set(label, u and tostring(i) .. ". " .. (species and species.Name or u.S) .. "  " .. Formulas.shortNumber(u.D or 0) or "")
	end
	local names = {}
	for _, id in ipairs({ "Predator", "Guardian", "Sky" }) do
		if report and report.Y and report.Y[id] then
			table.insert(names, SYNERGIES[id])
		end
	end
	Lang.set(compactSynergy, table.concat(names, " · "))
end

local since = CHECK_EVERY
RunService.Heartbeat:Connect(FrameMeter.wrap("DamageBoard", function(dt)
	since += dt
	if since >= CHECK_EVERY then
		since = 0
		updateCompact()
		refreshWindow()
		local camera = Workspace.CurrentCamera
		local eye = camera and camera.CFrame.Position
		local seen = {}
		for _, part in ipairs(boardParts()) do
			seen[part] = true
			local entry = boards[part]
			local near = eye ~= nil and (part.Position - eye).Magnitude <= VIEW_DISTANCE
				and not (part.Parent and part.Parent:GetAttribute("Hidden") == true)
			if near then
				local index = part:GetAttribute("BaseIndex")
				local folder = baseFolder(index)
				local raw = folder and folder:GetAttribute("DamageReport")
				if not entry then
					local surface = Instance.new("SurfaceGui")
					surface.Name = "DamageBoardGui"
					surface.Adornee = part
					surface.Face = Enum.NormalId.Front
					surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
					surface.PixelsPerStud = PIXELS_PER_STUD
					surface.LightInfluence = 0
					surface.ResetOnSpawn = false
					surface.Parent = gui.Parent
					entry = { gui = surface }
					boards[part] = entry
				end
				if entry.raw ~= raw then
					entry.raw, entry.report = raw, decode(raw)
				end
				local key = tostring(raw) .. "|" .. tostring(folder and folder:GetAttribute("OwnerUserId")) .. "|"
					.. tostring(fresh(entry.report))
				if entry.key ~= key then
					entry.key = key
					drawBoard(entry, entry.report, index)
				end
			elseif entry then
				entry.gui:Destroy()
				boards[part] = nil
			end
		end
		for part, entry in pairs(boards) do
			if not seen[part] then
				entry.gui:Destroy()
				boards[part] = nil
			end
		end
	end
	local wave = 0.5 + 0.5 * math.sin(os.clock() * PULSE_SPEED)
	for _, entry in pairs(boards) do
		if entry.fresh and entry.stroke then
			entry.stroke.Transparency = 0.5 * wave
		end
	end
end))
