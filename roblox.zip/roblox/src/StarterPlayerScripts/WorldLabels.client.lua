local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TextService = game:GetService("TextService")

local WorldWatch = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("WorldWatch"))

local STUDS_PER_PIXEL = 1 / 14
local TEXT_MAX = 100
local TALL = 100000

local texts = setmetatable({}, { __mode = "k" })
local watched = setmetatable({}, { __mode = "k" })
local pinned = setmetatable({}, { __mode = "k" })

local function hasOffset(u)
	return u.X.Offset ~= 0 or u.Y.Offset ~= 0
end

local function isText(d)
	return d:IsA("TextLabel") or d:IsA("TextButton") or d:IsA("TextBox")
end

local function boardOf(d)
	return d:IsA("BillboardGui") and d or d:FindFirstAncestorWhichIsA("BillboardGui")
end

local inner

local function pixels(g)
	if g:IsA("BillboardGui") then
		local s = g.Size
		return Vector2.new(s.X.Scale / STUDS_PER_PIXEL + s.X.Offset, s.Y.Scale / STUDS_PER_PIXEL + s.Y.Offset)
	end
	if not g:IsA("GuiObject") or not g.Parent then
		return nil
	end
	local box = inner(g.Parent)
	if not box then
		return nil
	end
	local s = g.Size
	return Vector2.new(s.X.Scale * box.X + s.X.Offset, s.Y.Scale * box.Y + s.Y.Offset)
end

function inner(g)
	if not g:IsA("BillboardGui") and not g:IsA("GuiObject") then
		return nil
	end
	local px = pixels(g)
	local pad = px and g:FindFirstChildOfClass("UIPadding")
	if not pad then
		return px
	end
	local l, r, t, b = pad.PaddingLeft, pad.PaddingRight, pad.PaddingTop, pad.PaddingBottom
	return Vector2.new(px.X * (1 - l.Scale - r.Scale) - l.Offset - r.Offset, px.Y * (1 - t.Scale - b.Scale) - t.Offset - b.Offset)
end

local function managed(d)
	return isText(d) and (texts[d] ~= nil or not d.TextScaled or d:FindFirstChildOfClass("UITextSizeConstraint") ~= nil)
end

local function fitBoard(board)
	if hasOffset(board.Size) then
		local px = pixels(board)
		board.Size = UDim2.fromScale(px.X * STUDS_PER_PIXEL, px.Y * STUDS_PER_PIXEL)
	end
end

local function pin(board)
	local rec = pinned[board]
	if not rec then
		rec = { base = board.StudsOffsetWorldSpace, cam = Vector3.zero, frac = 0, set = nil }
		pinned[board] = rec
	elseif board.StudsOffsetWorldSpace ~= rec.set then
		rec.base = board.StudsOffsetWorldSpace
	end
	if board.StudsOffset ~= Vector3.zero then
		rec.cam = board.StudsOffset
		board.StudsOffset = Vector3.zero
	end
	if board.SizeOffset ~= Vector2.zero then
		rec.frac = board.SizeOffset.Y
		board.SizeOffset = Vector2.zero
	end
	if board.ExtentsOffset ~= Vector3.zero then
		board.ExtentsOffsetWorldSpace += board.ExtentsOffset
		board.ExtentsOffset = Vector3.zero
	end
	local tall = board.Size.Y.Scale + board.Size.Y.Offset * STUDS_PER_PIXEL
	local want = rec.base + rec.cam + Vector3.new(0, rec.frac * tall, 0)
	rec.set = want
	if board.StudsOffsetWorldSpace ~= want then
		board.StudsOffsetWorldSpace = want
	end
end

local function fitBox(g)
	local s, p = g.Size, g.Position
	if not hasOffset(s) and not hasOffset(p) then
		return
	end
	local box = g.Parent and inner(g.Parent)
	if not box or box.X <= 0 or box.Y <= 0 then
		return
	end
	if hasOffset(s) then
		g.Size = UDim2.fromScale(s.X.Scale + s.X.Offset / box.X, s.Y.Scale + s.Y.Offset / box.Y)
	end
	if hasOffset(p) then
		g.Position = UDim2.fromScale(p.X.Scale + p.X.Offset / box.X, p.Y.Scale + p.Y.Offset / box.Y)
	end
end

local function fitText(t)
	local fit = texts[t]
	local box = pixels(t)
	if not box or box.X <= 0 or box.Y <= 0 then
		return
	end
	if not fit then
		if not managed(t) then
			return
		end
		local most = t:FindFirstChildOfClass("UITextSizeConstraint")
		local pad = t:FindFirstChildOfClass("UIPadding")
		local base = { 0, 0, 0, 0 }
		if pad then
			local l, r, top, b = pad.PaddingLeft, pad.PaddingRight, pad.PaddingTop, pad.PaddingBottom
			base = { l.Scale + l.Offset / box.X, r.Scale + r.Offset / box.X, top.Scale + top.Offset / box.Y,
				b.Scale + b.Offset / box.Y }
		else
			pad = Instance.new("UIPadding")
			pad.Parent = t
		end
		fit = { pad = pad, base = base, cap = t.TextScaled and most and most.MaxTextSize or nil }
		if most then
			most.MinTextSize = 1
			most.MaxTextSize = TEXT_MAX
		end
		texts[t] = fit
		t.TextScaled = true
	end
	local size = fit.cap or t.TextSize
	local b = fit.base
	local width, height = box.X * (1 - b[1] - b[2]), box.Y * (1 - b[3] - b[4])
	local need = size
	if t.TextWrapped then
		local ok, bounds = pcall(TextService.GetTextSize, TextService, t.Text, size, t.Font, Vector2.new(math.max(width, 1), TALL))
		need = ok and bounds.Y or size
	else
		local _, breaks = string.gsub(t.Text, "\n", "")
		need = size * (breaks + 1)
	end
	local spare = math.max(0, height - need) / box.Y
	local align = t.TextYAlignment
	local top = align == Enum.TextYAlignment.Top and 0 or align == Enum.TextYAlignment.Bottom and spare or spare / 2
	fit.pad.PaddingLeft = UDim.new(b[1], 0)
	fit.pad.PaddingRight = UDim.new(b[2], 0)
	fit.pad.PaddingTop = UDim.new(b[3] + top, 0)
	fit.pad.PaddingBottom = UDim.new(b[4] + spare - top, 0)
end

local function fitModifier(m)
	local host = m.Parent
	local px = host and (host:IsA("GuiObject") or host:IsA("BillboardGui")) and pixels(host)
	if not px or px.X <= 0 or px.Y <= 0 then
		return
	end
	if m:IsA("UIPadding") then
		if managed(host) then
			return
		end
		local l, r, t, b = m.PaddingLeft, m.PaddingRight, m.PaddingTop, m.PaddingBottom
		if l.Offset ~= 0 or r.Offset ~= 0 or t.Offset ~= 0 or b.Offset ~= 0 then
			m.PaddingLeft = UDim.new(l.Scale + l.Offset / px.X, 0)
			m.PaddingRight = UDim.new(r.Scale + r.Offset / px.X, 0)
			m.PaddingTop = UDim.new(t.Scale + t.Offset / px.Y, 0)
			m.PaddingBottom = UDim.new(b.Scale + b.Offset / px.Y, 0)
		end
	elseif m:IsA("UIListLayout") then
		local box = inner(host)
		local along = m.FillDirection == Enum.FillDirection.Horizontal and box.X or box.Y
		if m.Padding.Offset ~= 0 and along > 0 then
			m.Padding = UDim.new(m.Padding.Scale + m.Padding.Offset / along, 0)
		end
	elseif m:IsA("UIGridLayout") then
		local box = inner(host)
		if box.X > 0 and box.Y > 0 then
			for _, key in ipairs({ "CellSize", "CellPadding" }) do
				local u = m[key]
				if hasOffset(u) then
					m[key] = UDim2.fromScale(u.X.Scale + u.X.Offset / box.X, u.Y.Scale + u.Y.Offset / box.Y)
				end
			end
		end
	elseif m:IsA("UICorner") then
		local r = m.CornerRadius
		if r.Offset ~= 0 then
			m.CornerRadius = UDim.new(r.Scale + r.Offset / math.min(px.X, px.Y), 0)
		end
	elseif m:IsA("UITextSizeConstraint") and isText(host) then
		fitText(host)
	end
end

local function refitTexts(root)
	if texts[root] then
		fitText(root)
	end
	for _, d in ipairs(root:GetDescendants()) do
		if texts[d] then
			fitText(d)
		end
	end
end

local function watch(g)
	if watched[g] then
		return
	end
	watched[g] = true
	if g:IsA("BillboardGui") then
		g:GetPropertyChangedSignal("Size"):Connect(function()
			if boardOf(g) then
				fitBoard(g)
				refitTexts(g)
				pin(g)
			end
		end)
		for _, key in ipairs({ "StudsOffset", "SizeOffset", "ExtentsOffset", "StudsOffsetWorldSpace" }) do
			g:GetPropertyChangedSignal(key):Connect(function()
				pin(g)
			end)
		end
		return
	end
	g:GetPropertyChangedSignal("Size"):Connect(function()
		if boardOf(g) then
			fitBox(g)
			refitTexts(g)
		end
	end)
	g:GetPropertyChangedSignal("Position"):Connect(function()
		if boardOf(g) then
			fitBox(g)
		end
	end)
	if isText(g) then
		local function again()
			if texts[g] and boardOf(g) then
				fitText(g)
			end
		end
		g:GetPropertyChangedSignal("Text"):Connect(again)
		g:GetPropertyChangedSignal("TextSize"):Connect(again)
		g:GetPropertyChangedSignal("TextWrapped"):Connect(again)
	end
end

local function take(d)
	local board = d.Parent and boardOf(d)
	if not board or board:GetAttribute("KeepSize") or d:FindFirstAncestor("ProximityPrompts") then
		return
	end
	if d:IsA("BillboardGui") then
		fitBoard(d)
		pin(d)
		watch(d)
	elseif d:IsA("GuiObject") then
		fitBox(d)
		watch(d)
		if isText(d) then
			fitText(d)
		end
	elseif d:IsA("UIComponent") then
		fitModifier(d)
	end
end

local function interesting(d)
	return d:IsA("BillboardGui") or d:IsA("GuiObject") or d:IsA("UIComponent")
end

local function takeTree(d)
	if not d.Parent then
		return
	end
	take(d)
	if d:IsA("BillboardGui") or d:IsA("GuiObject") then
		for _, inside in ipairs(d:GetDescendants()) do
			if interesting(inside) then
				take(inside)
			end
		end
	end
end

local function scan(root)
	for _, d in ipairs(root:GetDescendants()) do
		if interesting(d) then
			take(d)
		end
	end
	root.DescendantAdded:Connect(function(d)
		if interesting(d) then
			task.defer(takeTree, d)
		end
	end)
end

WorldWatch.listen({ "BillboardGui", "GuiObject", "UIComponent" }, function(d, existing)
	if existing then
		take(d)
	else
		task.defer(takeTree, d)
	end
end)
scan(Players.LocalPlayer:WaitForChild("PlayerGui"))
