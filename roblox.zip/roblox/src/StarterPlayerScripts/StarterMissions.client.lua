--[[
StarterMissions (client): the beginner mission board at the top left (design 10 초보 미션), one mission
at a time: its words and progress, and the reward. When it is reached the board turns green and a tap
takes the reward (Net request ClaimStarter); an optional mission has a small "넘기기" held down
(StarterPass). Under it, while a luck boost lasts, "🍀 행운 ×2 12:34" (2026-10-04: and a new player's 🐣 rookie mining
buff, "🐣 캐기 ×3 14:12": player attribute RookieEndsAt).

On its bottom row, "🧭 길잡이 켬 / 끔" switches the guide line (MissionGuide) on and off (2026-10-04).

Reads the player attributes the server's StarterMissions sets: StarterStep (nil: no board), StarterCount,
StarterReady, Luck, LuckEndsAt. Hidden while a window is open (Shared/Windows).

(2026-10-03, "튜토리얼 미션도 추가해서 거기에 보상 넣고 그걸 클리어하게 유도하면서 배우게 하자") a mission with Learn
lines (Config.StarterMissions) shows Coco's card in the middle when it comes up (once a session, when nothing else is
on: no tutorial, no window, no language to pick) and again when the board is tapped before it is reached; the
board's title ends with 📖 then. "✅ 알겠어!" closes it.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TextService = game:GetService("TextService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Lang = require(Shared:WaitForChild("Lang")) -- (Lang.set: the timer line, written only when it changes)
local HoldButton = require(Shared:WaitForChild("HoldButton"))
local Windows = require(Shared:WaitForChild("Windows"))
local CocoVoice = require(Shared:WaitForChild("CocoVoice"))
local Unlock = require(Shared:WaitForChild("Unlock"))
local Pictures = require(Shared:WaitForChild("Pictures"))
local Notices = require(Shared:WaitForChild("Notices"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local CARD_POS = UDim2.new(0, 12, 0, 8) -- the top left, above the move stick's area (the tutorial's skip
-- button there hides on its last step, the one that points here)
local CARD_SIZE = UDim2.fromOffset(236, 104)
local CARD_MIN_WIDTH = 160
local CARD_COLOR = Color3.fromRGB(34, 46, 92)
local CARD_EDGE = { Color = Color3.fromRGB(255, 215, 90), Glow = Color3.fromRGB(255, 255, 255), Thickness = 2.5, Pulse = 1.5,
	Speed = 3 }
local CARD_TEXT = { Title = 16, Mission = 15, Reward = 13, Rows = { 0, 24, 48, 70 }, Heights = { 22, 22, 19 } }
local READY_COLOR = Color3.fromRGB(46, 160, 80)
local TITLE_COLOR = Color3.fromRGB(150, 255, 220)
local TEXT_COLOR = Color3.fromRGB(255, 255, 255)
local REWARD_COLOR = Color3.fromRGB(255, 220, 90)
local PASS_SIZE = UDim2.fromOffset(110, 26)
local PASS_COLOR = Color3.fromRGB(80, 84, 100)
local LUCK_SIZE = UDim2.fromOffset(236, 22)
local HINT_ROW = 18
local HINT_COLOR = Color3.fromRGB(150, 230, 255)
local HINT_TEXT = 12
-- (2026-10-04, "초보 미션 on off 기능을 왼쪽위에 있는 거 말하는거야. 거기다가 넣어줘야지 줄 on off 하는거") the 🧭 guide
-- line's switch (MissionGuide; player attribute HideMissionGuide, saved like 보기 설정's) on its own row at the board's
-- bottom right, saying what it is (2026-10-04, "켬 끔을 설명을 해줘야지 길잡이 켬 끔 이런식으로": was a bare "🧭 켬"
-- in the corner)
local GUIDE_SIZE = UDim2.fromOffset(120, 22)
local GUIDE_ON_COLOR = Color3.fromRGB(60, 150, 200)
local GUIDE_OFF_COLOR = Color3.fromRGB(80, 84, 100)
local GUIDE_SHINE_COLOR = Color3.fromRGB(255, 200, 60)
local GUIDE_SHINE_SPEED = 5
local GUIDE_STROKE = 2
local LUCK_COLOR = Color3.fromRGB(120, 230, 120)
local PULSE_SPEED = 4
local PULSE_GROW = 0.04
local LUCK_EVERY = 0.25
local LEARN_WIDTH = 340 -- Coco's card for a mission's Learn lines
local LEARN_PAD = 14
local LEARN_TITLE_TEXT = 19
local LEARN_TEXT = 15
local LEARN_BUTTON_HEIGHT = 38
local LEARN_BG = Color3.fromRGB(30, 34, 50)
local LEARN_STROKE = Color3.fromRGB(150, 255, 220)
local LEARN_OK = Color3.fromRGB(70, 180, 90)
local LEARN_GAP = 6
local LEARN_CHECK_EVERY = 1 -- seconds between looks for a moment to show it
local LEARN_JOIN_WAIT = 20
local LEARN_AFTER_POPUP = 5
local LEARN_PICTURE_TEXT = 56
local LEARN_PICTURE_HEIGHT = 64
local NUDGE_SECONDS = 9
local GUIDE_PICTURES = {
	Base_Arena = { "Fossil", "Boss" }, PlaceBoard = { "Dino", "Dino_TRex" }, MyDino = { "Dino", "Dino_TRex" },
	EnhanceStall = { "Dino", "Dino_TRex" }, MountPedestal = { "Dino", "Dino_Raptor" }, Zombie = { "Dino", Config.Zombies.Model },
	Boss = { "Dino", Config.Zombies.Boss.Kinds[1].Model }, AltarBox = { "Dino", Config.Zombies.Guardians.Model },
	Wild = { "Dino", Config.Wildlife.RaptorModel }, KeyStall = { "Key", "Key_Normal" }, Mineral = { "Item", Config.Minerals.Sizes[1].Model },
	BombStall = { "Item", Config.Bombs.Kinds[1].Model }, Base_DepositBin = { "Item", Config.Bag.Looks[1] },
	Base_Shop = { "Item", "Pickaxe_T2" },
}
for _, station in ipairs(Config.Training.Stations) do
	GUIDE_PICTURES["Train" .. station.Id] = { "Item", station.Model }
end
local LEARN_SHOWN_LINES = 2
local LEARN_MORE_HEIGHT = 26
local LEARN_MORE = Color3.fromRGB(70, 80, 110)
local LEARN_SCREEN_SHARE = 0.6
local NEXT_SIZE = UDim2.fromOffset(236, 20)
local NEXT_COLOR = Color3.fromRGB(255, 210, 100)
local NEXT_TEXT = 12
local LEARNING_COLOR = Color3.fromRGB(70, 60, 130)
local UNLOCK_COLOR = Color3.fromRGB(150, 110, 30)

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, size, position, textSize, color)
	local l = Instance.new("TextLabel")
	l.Text = ""
	l.BackgroundTransparency = 1
	l.Size = size
	l.Position = position
	l.Font = FONT
	l.TextSize = textSize
	l.TextColor3 = color
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.TextTruncate = Enum.TextTruncate.AtEnd
	l.Parent = parent
	return l
end

local gui = Instance.new("ScreenGui")
gui.Name = "StarterMissions"
gui.ResetOnSpawn = false
gui.DisplayOrder = 3 -- under the tutorial (4) and any open window (5)
gui.Parent = player:WaitForChild("PlayerGui")

local card = Instance.new("TextButton")
card.Size = CARD_SIZE
card.Position = CARD_POS
card.BackgroundColor3 = CARD_COLOR
card.BackgroundTransparency = 0.15
card.AutoButtonColor = false
card.Font = FONT
card.TextSize = 13
card.TextTransparency = 1 -- (its words are the title label's; kept on the button for the tutorial's finger)
card.Visible = false
card.Parent = gui
corner(card, 12)
local cardEdge = Instance.new("UIStroke")
cardEdge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
cardEdge.Color = CARD_EDGE.Color
cardEdge.Thickness = CARD_EDGE.Thickness
cardEdge.Parent = card
local pad = Instance.new("UIPadding")
pad.PaddingLeft, pad.PaddingTop = UDim.new(0, 8), UDim.new(0, 5)
pad.Parent = card
local scale = Instance.new("UIScale")
scale.Parent = card

local title = label(card, UDim2.new(1, -8, 0, CARD_TEXT.Heights[1]), UDim2.fromOffset(0, CARD_TEXT.Rows[1]), CARD_TEXT.Title,
	TITLE_COLOR)
title.Font = Enum.Font.GothamBlack
local mission = label(card, UDim2.new(1, -8, 0, CARD_TEXT.Heights[2]), UDim2.fromOffset(0, CARD_TEXT.Rows[2]), CARD_TEXT.Mission,
	TEXT_COLOR)
local reward = label(card, UDim2.new(1, -8, 0, CARD_TEXT.Heights[3]), UDim2.fromOffset(0, CARD_TEXT.Rows[3]), CARD_TEXT.Reward,
	REWARD_COLOR)
for _, l in ipairs({ title, mission, reward }) do
	l.TextStrokeTransparency = 0.5
end
local hint = label(card, UDim2.new(1, -8, 0, HINT_ROW), UDim2.fromOffset(0, CARD_TEXT.Rows[4]), HINT_TEXT, HINT_COLOR)
hint.TextScaled = true
hint.Visible = false
do
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = HINT_TEXT
	most.Parent = hint
end

local passButton = Instance.new("TextButton")
passButton.Size = PASS_SIZE
local function cardHeight()
	return card.Size.Y.Offset
end
passButton.Position = CARD_POS + UDim2.fromOffset(0, CARD_SIZE.Y.Offset + 4)
passButton.BackgroundColor3 = PASS_COLOR
passButton.BackgroundTransparency = 0.15
passButton.Font = FONT
passButton.TextSize = 13
passButton.TextColor3 = TEXT_COLOR
passButton.Text = "⏩ 넘기기 (꾹)"
passButton.Visible = false
passButton.Parent = gui
corner(passButton, 8)
HoldButton.connect(passButton, function()
	Net.request("StarterPass")
end)

local guideButton = Instance.new("TextButton")
guideButton.Name = "GuideSwitch"
guideButton.Size = GUIDE_SIZE
guideButton.AnchorPoint = Vector2.new(1, 1)
guideButton.Position = UDim2.new(1, -4, 1, -4) -- (inside the board's padding: its bottom right corner)
guideButton.BackgroundTransparency = 0.15
guideButton.Font = FONT
guideButton.TextSize = 12
guideButton.TextColor3 = TEXT_COLOR
guideButton.Visible = true -- (on the board: shown with it)
guideButton.Parent = card
corner(guideButton, 6)
local guideStroke = Instance.new("UIStroke")
guideStroke.Color = GUIDE_SHINE_COLOR
guideStroke.Thickness = GUIDE_STROKE
guideStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
guideStroke.Transparency = 1
guideStroke.Parent = guideButton
local function showGuideSwitch()
	local on = player:GetAttribute("HideMissionGuide") ~= true
	guideButton.Text = on and "🧭 길잡이 켬" or "🧭 길잡이 끔"
	guideButton.BackgroundColor3 = on and GUIDE_ON_COLOR or GUIDE_OFF_COLOR
end
guideButton.Activated:Connect(function()
	Net.request("SetSetting", "HideMissionGuide", player:GetAttribute("HideMissionGuide") ~= true)
end)
player:GetAttributeChangedSignal("HideMissionGuide"):Connect(showGuideSwitch)
showGuideSwitch()
local function guideForced()
	guideButton.Visible = Unlock.nextOne() == nil
end
guideForced()
local cardWidth = CARD_SIZE.X.Offset
local function cardSize(extra)
	local height = CARD_SIZE.Y.Offset - (guideButton.Visible and 0 or GUIDE_SIZE.Y.Offset + 4)
	return UDim2.fromOffset(cardWidth, height + extra)
end

local nextPill = label(gui, NEXT_SIZE, CARD_POS, NEXT_TEXT, NEXT_COLOR)
nextPill.BackgroundColor3 = CARD_COLOR
nextPill.BackgroundTransparency = 0.25
nextPill.TextXAlignment = Enum.TextXAlignment.Center
nextPill.TextScaled = true
nextPill.Visible = false
corner(nextPill, 8)
do
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = NEXT_TEXT
	most.Parent = nextPill
end

local function belowBoard()
	return card.Visible and (cardHeight() + 4 + (passButton.Visible and PASS_SIZE.Y.Offset + 4 or 0)) or 0
end

local function showNextUnlock()
	local u = Unlock.nextOne()
	nextPill.Visible = u ~= nil and card.Visible and not player:GetAttribute("StarterLocked")
		and player:GetAttribute("TutorialStep") == nil
	if u then
		nextPill.Text = string.format("🔜 %s · %s", u.Name, Unlock.whyText(u))
	end
	nextPill.Position = CARD_POS + UDim2.fromOffset(0, belowBoard())
end

local luck = label(gui, LUCK_SIZE, CARD_POS, 12, LUCK_COLOR)
luck.TextStrokeTransparency = 0.4
luck.TextScaled = true -- (both lucks on one line: shrinks to fit)
local luckMax = Instance.new("UITextSizeConstraint")
luckMax.MaxTextSize = 12
luckMax.Parent = luck
luck.Visible = false

-- Coco's card: the mission's Learn lines
local learnGui = Instance.new("ScreenGui")
learnGui.Name = "StarterLearn"
learnGui.ResetOnSpawn = false
learnGui.DisplayOrder = 5
learnGui.Parent = player:WaitForChild("PlayerGui")
local learn = Instance.new("Frame")
learn.Name = "StarterLearnCard"
learn.AnchorPoint = Vector2.new(0.5, 0.5)
learn.Position = UDim2.fromScale(0.5, 0.5)
learn.Size = UDim2.fromOffset(LEARN_WIDTH, 0)
learn.BackgroundColor3 = LEARN_BG
learn.BackgroundTransparency = 0.08
learn.Active = true
learn.Visible = false
learn.Parent = learnGui
corner(learn, 14)
do
	local stroke = Instance.new("UIStroke")
	stroke.Color = LEARN_STROKE
	stroke.Thickness = 2
	stroke.Parent = learn
	local p = Instance.new("UIPadding")
	p.PaddingLeft, p.PaddingRight = UDim.new(0, LEARN_PAD), UDim.new(0, LEARN_PAD)
	p.PaddingTop, p.PaddingBottom = UDim.new(0, LEARN_PAD), UDim.new(0, LEARN_PAD)
	p.Parent = learn
	local list = Instance.new("UIListLayout")
	list.SortOrder = Enum.SortOrder.LayoutOrder
	list.Padding = UDim.new(0, LEARN_GAP)
	list.HorizontalAlignment = Enum.HorizontalAlignment.Center
	list.Parent = learn
end
Windows.fit(learn, { Share = LEARN_SCREEN_SHARE })
Windows.register(learn, nil, { Keep = true }) -- (a window: the HUD steps aside; its ✅ closes it, no X in the list)
local learnLines = {}
local learnOk = Instance.new("TextButton")
learnOk.Font = FONT
learnOk.TextSize = 16
learnOk.TextColor3 = TEXT_COLOR
learnOk.BackgroundColor3 = LEARN_OK
learnOk.Text = "✅ 알겠어!"
learnOk.Size = UDim2.new(0.6, 0, 0, LEARN_BUTTON_HEIGHT)
learnOk.LayoutOrder = 1000
learnOk.Parent = learn
corner(learnOk, 10)
learnOk.Activated:Connect(function()
	learn.Visible = false
end)

local function learnOf(step)
	local m = step and Config.StarterMissions.Missions[step]
	return m and m.Learn
end

local function questStep()
	local id = player:GetAttribute("UnlockQuest")
	local step = player:GetAttribute("UnlockQuestStep")
	local u = id and Formulas.unlockOf(id)
	local m = u and step and u.Steps[step]
	if not m then
		return nil
	end
	return u, step, m
end

local function lineHeight(text, size)
	local inner = Vector2.new(LEARN_WIDTH - LEARN_PAD * 2, math.huge)
	return math.ceil(TextService:GetTextSize(Lang.t(text), size, FONT, inner).Y)
end

local function fitLearn()
	local tall, count = LEARN_PAD * 2, 0
	for _, c in ipairs(learn:GetChildren()) do
		if c:IsA("GuiObject") and c.Visible then
			tall += c.Size.Y.Offset
			count += 1
		end
	end
	learn.Size = UDim2.fromOffset(LEARN_WIDTH, tall + LEARN_GAP * math.max(0, count - 1))
end

local function showLines(lines, missionText, guide)
	if not lines then
		return
	end
	for _, l in ipairs(learnLines) do
		l:Destroy()
	end
	learnLines = {}
	local spec = guide and (GUIDE_PICTURES[guide] or (string.match(guide, "^Mineral") and GUIDE_PICTURES.Mineral))
	local picture = spec and Pictures.of(spec, UDim2.new(1, 0, 0, LEARN_PICTURE_HEIGHT))
	if not picture then
		picture = Instance.new("TextLabel")
		picture.BackgroundTransparency = 1
		picture.Font = FONT
		picture.TextSize = LEARN_PICTURE_TEXT
		picture.Text = string.match(missionText or "", "^(%S+)%s") or "🐣"
		picture.Size = UDim2.new(1, 0, 0, LEARN_PICTURE_HEIGHT)
		picture:SetAttribute("KeepText", true)
	end
	picture.LayoutOrder = 0
	picture.Parent = learn
	table.insert(learnLines, picture)
	local hidden = {}
	for i, text in ipairs(lines) do
		local l = Instance.new("TextLabel")
		l.BackgroundTransparency = 1
		l.Font = FONT
		l.TextSize = i == 1 and LEARN_TITLE_TEXT or LEARN_TEXT
		l.TextColor3 = i == 1 and TITLE_COLOR or TEXT_COLOR
		l.TextWrapped = true
		l.TextXAlignment = Enum.TextXAlignment.Left
		l.Text = i == 1 and ("🐣 " .. text) or text
		l.Size = UDim2.new(1, 0, 0, lineHeight(l.Text, l.TextSize))
		l.LayoutOrder = i
		l.Visible = i <= LEARN_SHOWN_LINES
		l.Parent = learn
		table.insert(learnLines, l)
		if not l.Visible then
			table.insert(hidden, l)
		end
	end
	if #hidden > 0 then
		local more = Instance.new("TextButton")
		more.Font = FONT
		more.TextSize = 14
		more.TextColor3 = TEXT_COLOR
		more.BackgroundColor3 = LEARN_MORE
		more.Text = "▼ 더 보기"
		more.Size = UDim2.new(0.5, 0, 0, LEARN_MORE_HEIGHT)
		more.LayoutOrder = 999
		more.Parent = learn
		corner(more, 8)
		table.insert(learnLines, more)
		more.Activated:Connect(function()
			for _, l in ipairs(hidden) do
				l.Visible = true
			end
			more.Visible = false
			fitLearn()
		end)
	end
	fitLearn()
	learn.Visible = true
	CocoVoice.babble(table.concat({ Lang.t(lines[1]), Lang.t(lines[2] or "") }, " "))
end

local function showLearn(step)
	local m = step and Config.StarterMissions.Missions[step]
	if m then
		showLines(m.Learn, m.Text, m.Guide)
	end
end

local function showQuestLearn()
	local _, _, m = questStep()
	if m then
		showLines(m.Learn, m.Text, m.Guide)
	end
end

local function nudge(lines, guide)
	if not lines or not lines[1] then
		return
	end
	local spec = guide and (GUIDE_PICTURES[guide] or (string.match(guide, "^Mineral") and GUIDE_PICTURES.Mineral))
	Notices.show(lines[2] and lines[1] or nil, lines[2] or lines[1],
		{ picture = spec and Pictures.of(spec, UDim2.fromScale(1, 1)) or nil, seconds = NUDGE_SECONDS })
end

-- a moment to show it: no tutorial, no trip, no language to pick, no other window
local function free()
	return player:GetAttribute("TutorialStep") == nil and not player:GetAttribute("TutorialTravel")
		and not player:GetAttribute("LanguagePick") and not player:GetAttribute("CocoIntro") and not player:GetAttribute("FirstFight")
		and not player:GetAttribute("Cinematic")
		and not Windows.anyOpen(learn) and not Windows.coverBusy(LEARN_AFTER_POPUP)
		and ((player:GetAttribute("DefenseLevel") or 1) < 2 or player:GetAttribute("FreshStart") or time() >= LEARN_JOIN_WAIT)
end

local learnShown = {} -- [mission index] = true: its card came up this session
local cocoCards = {}
Net.onPush("CocoCard", function(lines, picture)
	if type(lines) == "table" and type(lines[1]) == "string" then
		table.insert(cocoCards, { lines, picture })
	end
end)
task.spawn(function()
	while true do
		task.wait(LEARN_CHECK_EVERY)
		if cocoCards[1] and not learn.Visible and free() then
			local c = table.remove(cocoCards, 1)
			showLines(c[1], c[1][1], c[2])
			continue
		end
		local u, qStep, qm = questStep()
		local step = player:GetAttribute("StarterStep")
		if u then
			local key = u.Id .. "#" .. qStep
			if not learnShown[key] and qm.Learn and free() then
				learnShown[key] = true
				nudge(qm.Learn, qm.Guide)
			end
		elseif player:GetAttribute("UnlockNext") then
			continue
		elseif step and not learnShown[step] and learnOf(step) and not player:GetAttribute("StarterReady")
			and not player:GetAttribute("StarterLocked") and free() then
			learnShown[step] = true
			local _, at = Formulas.starterChapter(step, #Config.StarterMissions.Missions)
			local m = Config.StarterMissions.Missions[step]
			if at == 1 then
				showLearn(step)
			elseif m then
				nudge(m.Learn, m.Guide)
			end
		end
	end
end)

card.Activated:Connect(function()
	if questStep() then
		showQuestLearn()
	elseif player:GetAttribute("UnlockNext") then
		return
	elseif player:GetAttribute("StarterReady") then
		Net.request("ClaimStarter")
	elseif player:GetAttribute("StarterLocked") then
		return
	elseif learnOf(player:GetAttribute("StarterStep")) then
		showLearn(player:GetAttribute("StarterStep")) -- (again, any time: what to do and how)
	end
end)

local function showUnlockOnBoard()
	local u, qStep, qm = questStep()
	local readyId = not u and player:GetAttribute("UnlockNext")
	local r = readyId and Formulas.unlockOf(readyId)
	if not u and not r then
		return false
	end
	card.Visible = true
	passButton.Visible = false
	hint.Visible = false
	card.Size = cardSize(0)
	passButton.Position = CARD_POS + UDim2.fromOffset(0, cardHeight() + 4)
	if u then
		card.BackgroundColor3 = LEARNING_COLOR
		card.Text = string.format(qm.Learn and "🔓 %s %d/%d · 📖" or "🔓 %s %d/%d", u.Name, qStep, #u.Steps)
		mission.Text = string.format("%s (%d/%d)", qm.Text, player:GetAttribute("UnlockQuestCount") or 0, qm.Target)
		reward.Text = "🎁 다 하면: " .. Formulas.starterRewardText(u.Reward)
	else
		card.BackgroundColor3 = UNLOCK_COLOR
		card.Text = string.format("🔓 %s 열 수 있어요!", r.Name)
		mission.Text = (r.Where or r.Zone) and "👉 빛나는 줄을 따라 가면 바로 열려요!" or "⏳ 곧 열려요!"
		reward.Text = "🎁 다 배우면: " .. Formulas.starterRewardText(r.Reward)
	end
	title.Text = card.Text
	return true
end

local function refresh()
	if showUnlockOnBoard() then
		return
	end
	local step = player:GetAttribute("StarterStep")
	local m = step and Config.StarterMissions.Missions[step]
	card.Visible = m ~= nil
	local top = (player:GetAttribute("DefenseLevel") or 1) >= Formulas.maxDefenseLevel(player:GetAttribute("Rebirths") or 0)
	passButton.Visible = m ~= nil and (m.Optional == true or (m.Fight == true and top))
		and not player:GetAttribute("StarterReady") and not player:GetAttribute("StarterLocked")
	if not m then
		return
	end
	local ready = player:GetAttribute("StarterReady") == true
	local chapter, at, size = Formulas.starterChapter(step, #Config.StarterMissions.Missions)
	local info = Formulas.starterChapterInfo(chapter)
	local chapterName = info.Name
	local locked = player:GetAttribute("StarterLocked")
	local lock = locked and Formulas.unlockOf(locked)
	local tutorial = player:GetAttribute("InTutorial") and chapter >= 1 and chapter <= Config.StarterMissions.TutorialChapters
	card.Text = ready and "✅ 미션 완료! 🎁"
		or lock and string.format("🔒 %d장 %s", chapter, chapterName)
		or info.TopGoal and string.format("🎯 최우선: 디펜스 %s / %s → 🔄 첫 환생",
			Formulas.levelText(player:GetAttribute("DefenseLevel") or 1),
			Formulas.levelText(Formulas.maxDefenseLevel(player:GetAttribute("Rebirths") or 0)))
		or chapter == 0 and string.format(m.Learn and "%s %d/%d · 📖" or "%s %d/%d", chapterName, at, size)
		or tutorial and string.format(m.Learn and "🎓 %d/%d장 %s %d/%d · 📖" or "🎓 %d/%d장 %s %d/%d", chapter,
			Config.StarterMissions.TutorialChapters, chapterName, at, size)
		or m.Learn and string.format("%d장 %s %d/%d · 📖", chapter, chapterName, at, size) -- (a tap shows Coco's card)
		or string.format("%d장 %s %d/%d", chapter, chapterName, at, size)
	title.Text = card.Text
	if lock then
		card.BackgroundColor3 = CARD_COLOR
		hint.Visible = false
		card.Size = cardSize(0)
		passButton.Visible = false
		passButton.Position = CARD_POS + UDim2.fromOffset(0, cardHeight() + 4)
		local why = player:GetAttribute("FacilityWhy" .. lock.Id)
		if why == "Level" then
			mission.Text = lock.Line
			reward.Text = string.format("⚔️ 디펜스 %s부터 · 지금 %s", Formulas.levelText(lock.Level),
				Formulas.levelText(player:GetAttribute("DefenseLevel") or 1))
		else
			mission.Text = string.format("🔒 %s: %s", lock.Name, Unlock.whyText(lock))
			reward.Text = "🔓 열면 이 장이 시작돼요"
		end
		return
	end
	card.BackgroundColor3 = ready and READY_COLOR or CARD_COLOR
	hint.Visible = m.Hint ~= nil and not ready
	hint.Text = m.Hint or ""
	card.Size = cardSize(hint.Visible and HINT_ROW or 0)
	passButton.Position = CARD_POS + UDim2.fromOffset(0, cardHeight() + 4)
	mission.Text = string.format("%s (%d/%d)", m.Text, player:GetAttribute("StarterCount") or 0, m.Target)
	local parts = {}
	if (m.Reward.Keys or 0) > 0 then
		table.insert(parts, string.format("🔑 열쇠 %d개", m.Reward.Keys))
	end
	for _, t in ipairs(Config.Keys.Types) do -- (2026-10-03: the learning missions' silver keys)
		local n = m.Reward.SpecialKeys and m.Reward.SpecialKeys[t.Id] or 0
		if n > 0 then
			table.insert(parts, string.format("🔑 %s %d개", t.Name, n))
		end
	end
	if (m.Reward.LuckMinutes or 0) > 0 then
		table.insert(parts, string.format("🍀 행운 ×%g %d분", Config.StarterMissions.LuckMultiplier, m.Reward.LuckMinutes))
	end
	if (m.Reward.SlapLevels or 0) > 0 then
		table.insert(parts, string.format("🖐️ 손바닥 +%d단계", m.Reward.SlapLevels))
	end
	if m.Reward.GuaranteedRarity then
		local name = m.Reward.GuaranteedRarity
		for _, r in ipairs(Config.Rarities) do
			if r.Id == name then
				name = r.Name
			end
		end
		table.insert(parts, string.format("✨ %s 이상 확정 뽑기", name))
	end
	reward.Text = "🎁 " .. table.concat(parts, " · ")
end

local function refreshAll()
	guideForced()
	refresh()
	showNextUnlock()
end
for _, name in ipairs({ "StarterStep", "StarterCount", "StarterReady", "StarterLocked", "DefenseLevel", "TutorialStep",
	"UnlockQuest", "UnlockQuestStep", "UnlockQuestCount", "UnlockNext" }) do
	player:GetAttributeChangedSignal(name):Connect(refreshAll)
end
Unlock.watch(refreshAll)
refreshAll()

local function roomForCard()
	local training = gui.Parent and gui.Parent:FindFirstChild("Training")
	local panel = training and training:IsA("ScreenGui") and training.Enabled and training:FindFirstChildOfClass("Frame")
	if not panel or not panel.Visible then
		return CARD_SIZE.X.Offset
	end
	return math.clamp(math.floor(panel.AbsolutePosition.X - card.AbsolutePosition.X), CARD_MIN_WIDTH, CARD_SIZE.X.Offset)
end

local luckIn = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("StarterMissions", function(dt)
	gui.Enabled = not Windows.anyOpen() -- (an open window covers the top left: out of its way)
	local room = roomForCard()
	if room ~= cardWidth then
		cardWidth = room
		card.Size = UDim2.fromOffset(room, card.Size.Y.Offset)
		nextPill.Size = UDim2.fromOffset(room, NEXT_SIZE.Y.Offset)
		luck.Size = UDim2.fromOffset(room, LUCK_SIZE.Y.Offset)
	end
	-- the green board breathes so it is seen
	if card.Visible and player:GetAttribute("StarterReady") then
		scale.Scale = 1 + PULSE_GROW * math.sin(os.clock() * PULSE_SPEED)
	else
		scale.Scale = 1
	end
	if card.Visible then
		local glow = 0.5 + 0.5 * math.sin(os.clock() * CARD_EDGE.Speed)
		cardEdge.Thickness = CARD_EDGE.Thickness + CARD_EDGE.Pulse * glow
		cardEdge.Color = CARD_EDGE.Color:Lerp(CARD_EDGE.Glow, glow * 0.5)
	end
	if card.Visible and guideButton.Visible then
		local wave = 0.5 + 0.5 * math.sin(os.clock() * GUIDE_SHINE_SPEED)
		guideStroke.Transparency = 1 - wave
		local base = player:GetAttribute("HideMissionGuide") == true and GUIDE_OFF_COLOR or GUIDE_ON_COLOR
		guideButton.BackgroundColor3 = base:Lerp(GUIDE_SHINE_COLOR, wave * 0.6)
	elseif guideStroke.Transparency < 1 then
		guideStroke.Transparency = 1
		showGuideSwitch()
	end
	-- the luck boost's time left, under the board (or in its place)
	-- (2026-10-01) and the server luck boost someone bought for everyone (Monetization), after it
	luckIn -= dt
	if luckIn > 0 then
		return
	end
	luckIn = LUCK_EVERY
	local now = Workspace:GetServerTimeNow()
	local ends = player:GetAttribute("LuckEndsAt")
	local left = ends and ends - now or 0
	local serverLeft = (ReplicatedStorage:GetAttribute("ServerLuckUntil") or 0) - now
	-- (2026-10-04) 🐣 the rookie mining buff (Rewards: RookieEndsAt), not on the tutorial's screen (its skip button is here)
	local rookieLeft = player:GetAttribute("TutorialStep") == nil and (player:GetAttribute("RookieEndsAt") or 0) - now or 0
	luck.Visible = left > 0 or serverLeft > 0 or (player:GetAttribute("MoneyBoostUntil") or 0) > now or rookieLeft > 0
	if luck.Visible then
		local below = belowBoard() + (nextPill.Visible and NEXT_SIZE.Y.Offset + 4 or 0)
		luck.Position = CARD_POS + UDim2.fromOffset(0, below)
		local parts = {}
		if rookieLeft > 0 then
			table.insert(parts, string.format("🐣 캐기 ×%d %d:%02d", Config.Mining.Rookie.Speed, rookieLeft // 60,
				math.floor(rookieLeft % 60)))
		end
		if left > 0 then
			table.insert(parts, string.format("🍀 행운 ×%g %d:%02d", player:GetAttribute("Luck") or 1, left // 60, math.floor(left % 60)))
		end
		local moneyLeft = (player:GetAttribute("MoneyBoostUntil") or 0) - now
		if moneyLeft > 0 then
			table.insert(parts, string.format("💰 돈 ×2 %d:%02d", moneyLeft // 60, math.floor(moneyLeft % 60)))
		end
		if serverLeft > 0 then
			table.insert(parts, string.format("🌍 서버 ×%g %d:%02d", ReplicatedStorage:GetAttribute("ServerLuck") or 1,
				serverLeft // 60, math.floor(serverLeft % 60)))
		end
		Lang.set(luck, table.concat(parts, " · ")) -- (was set every frame: Korean over the English, translated again)
	end
end))
