local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local Lang = require(Shared:WaitForChild("Lang"))
local Net = require(Shared:WaitForChild("Net"))
local Notices = require(Shared:WaitForChild("Notices"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

local FONT = Enum.Font.GothamBold
local SIZE = Vector2.new(420, 426)
local COLOR_BG = Color3.fromRGB(34, 26, 40)
local COLOR_STROKE = Color3.fromRGB(255, 120, 140)
local COLOR_STEP = Color3.fromRGB(70, 140, 230)
local COLOR_FIRST = Color3.fromRGB(70, 180, 90)
local COLOR_RETRY = Color3.fromRGB(235, 120, 60)
local COLOR_WAIT = Color3.fromRGB(90, 95, 110)
local COLOR_WHY = Color3.fromRGB(255, 220, 140)
local COLOR_WHO = Color3.fromRGB(255, 150, 150)
local BUTTON_H = 44
local BUTTON_GAP = 8
local STEPS_TOP = 204
local FRESH = 6
local BEAM_COLOR = Color3.fromRGB(255, 150, 150)
local BEAM_WIDTH = 0.6
local ARRIVE = 14
local GUIDE_SECONDS = 120
local MARK_SIZE = UDim2.fromScale(6, 6)
local MARK_UP = 4
local MARK_BOUNCE, MARK_SPEED = 1.2, 4
local TICK = 0.25

local PLANS = {
	Placement = { "Damage", "AutoPlace", "Analysis" },
	Twist = { "AutoPlace", "Damage", "Analysis" },
	Slots = { "AutoPlace", "Slots", "Damage" },
	Hidden = { "AutoPlace", "Draw", "Damage" },
	Immune = { "AutoPlace", "Draw", "Damage" },
	Few = { "Slots", "AutoPlace", "Damage" },
	Area = { "Draw", "AutoPlace", "Damage" },
	Matchup = { "Draw", "AutoPlace", "Damage" },
	Power = { "Enhance", "Damage", "Draw" },
}
local ACTIONS = {
	AutoPlace = { Text = "✨ 자동 배치로 다시 놓기" },
	DeckPlan = { Text = "🦖 추천 교체·이동 적용" },
	Enhance = { Text = "⬆️ 공룡 강화하러 가기", Place = "EnhanceStall" },
	Draw = { Text = "🎰 공룡 더 뽑으러 가기", Place = "GachaMachine" },
	Slots = { Text = "➕ 공룡 자리 늘리러 가기", Place = "DefenseSign" },
	Analysis = { Text = "🩺 보스 분석 판 보러 가기", Board = "AdviceBoard" },
	Damage = { Text = "📊 공룡 피해 간판 보러 가기", Board = "DamageBoard" },
}

local gui = Instance.new("ScreenGui")
gui.Name = "LossCard"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.DisplayOrder = 9
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Name = "LossCard"
frame.AnchorPoint = Vector2.new(0.5, 0.5)
frame.Position = UDim2.fromScale(0.5, 0.5)
frame.Size = UDim2.fromOffset(SIZE.X, SIZE.Y)
frame.BackgroundColor3 = COLOR_BG
frame.Visible = false
frame.Parent = gui
do
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 16)
	corner.Parent = frame
	local stroke = Instance.new("UIStroke")
	stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	stroke.Color = COLOR_STROKE
	stroke.Thickness = 3
	stroke.Parent = frame
end

local function label(text, size, y, h, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextSize = size
	l.TextWrapped = true
	l.Size = UDim2.new(1, -60, 0, h)
	l.Position = UDim2.fromOffset(16, y)
	l.TextXAlignment = Enum.TextXAlignment.Left
	Lang.set(l, text)
	l.Parent = frame
	return l
end

label("🦖 준비해서 다시 도전해요", 22, 12, 30)
local why = label("", 16, 46, 24, COLOR_WHY)
local who = label("", 13, 70, 20, COLOR_WHO)
local deckPlan = label("", 13, 94, 72, COLOR_WHY)
label("👇 이렇게 하고 다시 도전해요", 15, 174, 24)

local function button(color, y)
	local b = Instance.new("TextButton")
	b.Size = UDim2.new(1, -32, 0, BUTTON_H)
	b.Position = UDim2.fromOffset(16, y)
	b.BackgroundColor3 = color
	b.Font = FONT
	b.TextSize = 17
	b.TextColor3 = Color3.new(1, 1, 1)
	b.AutoButtonColor = true
	b.Parent = frame
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 12)
	corner.Parent = b
	return b
end

local steps = {}
for i = 1, 3 do
	steps[i] = button(i == 1 and COLOR_FIRST or COLOR_STEP, STEPS_TOP + (i - 1) * (BUTTON_H + BUTTON_GAP))
	steps[i].Visible = false
end
local retry = button(COLOR_RETRY, STEPS_TOP + 3 * (BUTTON_H + BUTTON_GAP) + 4)

local close = Instance.new("TextButton")
close.Name = "CloseX"
close.AnchorPoint = Vector2.new(1, 0)
close.Position = UDim2.new(1, -10, 0, 10)
close.Size = UDim2.fromOffset(34, 34)
close.BackgroundColor3 = Color3.fromRGB(235, 70, 80)
close.Font = FONT
close.TextSize = 16
close.TextColor3 = Color3.new(1, 1, 1)
close.Text = "X"
close.Parent = frame
do
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 8)
	corner.Parent = close
end

Windows.fit(frame)
Windows.register(frame)
frame:SetAttribute("NoCloseHint", true)
close.Activated:Connect(function()
	frame.Visible = false
end)

local guide = nil
local function stopGuide()
	if guide then
		for _, x in ipairs({ guide.beam, guide.from, guide.to, guide.mark }) do
			x:Destroy()
		end
		guide = nil
	end
end

local function partOf(inst)
	if not inst then
		return nil
	end
	if inst:IsA("BasePart") then
		return inst
	end
	if inst:IsA("Model") then
		return inst.PrimaryPart or inst:FindFirstChildWhichIsA("BasePart", true)
	end
	return inst:FindFirstChildWhichIsA("BasePart", true)
end

local function targetOf(action)
	local index = player:GetAttribute("Base")
	local map = Workspace:FindFirstChild("Map")
	if action.Board then
		local holder = map and map:FindFirstChild("DefenseGuides")
		local model = holder and index and holder:FindFirstChild("DefenseGuideBase" .. index)
		return partOf(model and model:FindFirstChild(action.Board))
	end
	local folder = map and index and map:FindFirstChild("Base" .. index)
	return partOf(folder and folder:FindFirstChild(action.Place, true))
end

local function startGuide(target)
	stopGuide()
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not target or not root then
		return false
	end
	local from = Instance.new("Attachment")
	from.Parent = root
	local to = Instance.new("Attachment")
	to.Parent = target
	local beam = Instance.new("Beam")
	beam.Attachment0, beam.Attachment1 = from, to
	beam.Color = ColorSequence.new(BEAM_COLOR)
	beam.Width0, beam.Width1 = BEAM_WIDTH, BEAM_WIDTH
	beam.FaceCamera = true
	beam.LightEmission = 1
	beam.Transparency = NumberSequence.new(0.2)
	beam.Parent = target
	local mark = Instance.new("BillboardGui")
	mark.Size = MARK_SIZE
	mark.AlwaysOnTop = true
	mark.Adornee = target
	local arrow = Instance.new("TextLabel")
	arrow.BackgroundTransparency = 1
	arrow.Size = UDim2.fromScale(1, 1)
	arrow.TextScaled = true
	arrow.Text = "⬇️"
	arrow:SetAttribute("KeepText", true)
	arrow.Parent = mark
	mark.Parent = gui
	guide = { beam = beam, from = from, to = to, mark = mark, target = target, untilAt = os.clock() + GUIDE_SECONDS }
	return true
end

local plan = {}
local function act(i)
	local action = ACTIONS[plan[i]]
	if not action then
		return
	end
	if plan[i] == "DeckPlan" then
		Net.request("ApplyDeckAdvice")
		return
	end
	frame.Visible = false
	if plan[i] == "AutoPlace" then
		Net.request("AutoArrange")
		return
	end
	if startGuide(targetOf(action)) then
		Notices.show(nil, "🧭 빛줄기를 따라가요")
	end
end
for i, b in ipairs(steps) do
	b.Activated:Connect(function()
		act(i)
	end)
end

local function retryLeft()
	local at = player:GetAttribute("PromoRetryAt")
	return type(at) == "number" and math.max(0, math.ceil(at - Workspace:GetServerTimeNow())) or 0
end

local function paintRetry()
	local left = retryLeft()
	retry.BackgroundColor3 = left > 0 and COLOR_WAIT or COLOR_RETRY
	Lang.set(retry, left > 0 and string.format("⏳ %d초 뒤에 ⚔️ 다시 도전", left) or "⚔️ 보스 웨이브 다시 도전!")
end

retry.Activated:Connect(function()
	if retryLeft() > 0 then
		return
	end
	frame.Visible = false
	Net.request("StartPromotion")
end)

local function show()
	local kind = player:GetAttribute("PromoLossKind")
	plan = table.clone(PLANS[kind or ""] or PLANS.Power)
	local action = player:GetAttribute("PromoDeckAction")
	if action and action ~= "Enhance" and action ~= "Review" then
		plan = { "DeckPlan", "Damage", "Analysis" }
	elseif action == "Enhance" then
		plan = { "Enhance", "Damage", "Analysis" }
	elseif action == "Review" then
		plan = { "Analysis", "Damage", "AutoPlace" }
	end
	Lang.set(deckPlan, player:GetAttribute("PromoDeckPlan") or "")
	for i, b in ipairs(steps) do
		local action = ACTIONS[plan[i] or ""]
		b.Visible = action ~= nil
		if action then
			Lang.set(b, string.format("%d. %s", i, action.Text))
		end
	end
	local head = player:GetAttribute("PromoLossHead")
	Lang.set(why, type(head) == "string" and ("🩺 " .. head) or "🩺 공격력이 모자라요")
	local names = player:GetAttribute("PromoLossWho")
	who.Visible = type(names) == "string" and names ~= ""
	Lang.set(who, who.Visible and string.format("💤 공격 못 한 공룡: %s", names) or "")
	paintRetry()
	frame.Visible = true
end

player:GetAttributeChangedSignal("PromoDeckPlan"):Connect(function()
	if frame.Visible then show() end
end)
player:GetAttributeChangedSignal("PromoDeckAction"):Connect(function()
	if frame.Visible then show() end
end)

player:GetAttributeChangedSignal("PromoLostAt"):Connect(function()
	local at = player:GetAttribute("PromoLostAt")
	if type(at) == "number" and Workspace:GetServerTimeNow() - at < FRESH and player:GetAttribute("TutorialStep") == nil then
		show()
	end
end)
player:GetAttributeChangedSignal("PromoLevel"):Connect(function()
	if player:GetAttribute("PromoLevel") then
		frame.Visible = false
		stopGuide()
	end
end)

local since = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("LossCard", function(dt)
	since += dt
	if since >= TICK then
		since = 0
		if frame.Visible then
			paintRetry()
		end
	end
	if not guide then
		return
	end
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if root and guide.from.Parent ~= root then
		guide.from.Parent = root
	end
	local gap = root and (root.Position - guide.target.Position) * Vector3.new(1, 0, 1)
	if not guide.target.Parent or os.clock() >= guide.untilAt or (gap and gap.Magnitude <= ARRIVE) then
		stopGuide()
		return
	end
	guide.mark.StudsOffsetWorldSpace = Vector3.new(0, guide.target.Size.Y / 2 + MARK_UP
		+ math.abs(math.sin(os.clock() * MARK_SPEED)) * MARK_BOUNCE, 0)
end))
