--[[
Community: the community reward on this client (the server's Community service decides).

Net push CommunityJoin(groupId): I used my base's "👍 커뮤니티 보상" sign without being in the game's group,
so Roblox's own join prompt shows (GroupService:PromptJoinAsync); once I join, the reward is asked for
again at once (Net request ClaimCommunity).
]]

local GroupService = game:GetService("GroupService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))

Net.onPush("CommunityJoin", function(groupId)
	if type(groupId) ~= "number" or groupId <= 0 then
		return
	end
	local ok, result = pcall(GroupService.PromptJoinAsync, GroupService, groupId)
	if ok and result == Enum.GroupMembershipStatus.Joined then
		Net.request("ClaimCommunity")
	end
end)
