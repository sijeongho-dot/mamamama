--[[
Robux: the 💎 shop on this client (the server's Monetization service grants every purchase).

- "💎 상점" in the right side's column, between 📆 출석 and 🏆 시즌: a window with tabs
  ⭐ 추천 (the starter pack while not bought, the server luck boosts), 🍀 행운 (luck and speed potions),
  🔑 열쇠 (key packs, ruby keys), 💰 돈 (money packs), 🎫 패스 (game passes). Each row: what it gives at my
  level (keys and money in hours of my own income, Formulas), its price and "사기" (a pass I own: "보유 중").
  (2026-10-01, the Creator Hub's description box takes no Korean, so Roblox's own prompt can't explain) tapping
  a row opens its plain explanation under it (what you get, how long, what to know; one row at a time).
  Before my first key or money purchase a gold line says it gives Config.Monetization.FirstPurchaseMultiplier
  times as much (player attribute FirstPurchaseDone).
- Buying: MarketplaceService prompts with the id from Config.Monetization; an id still 0 is "준비 중" in a live
  game and granted at once in Studio (Net request StudioBuy). Paid random items are hidden where they are
  restricted (player attribute PaidRandomItemsRestricted, Policy service).
- Net push Offer("StarterPack"): the starter pack pops up once in the middle (사기 / 나중에).
- Net push PurchaseDone: confetti and a chime. Over every player whose LuckCrownUntil (server time) is ahead:
  "👑🍀 행운 선물" (they bought luck for the whole server; 2026-10-02: now a panel high over the key altar instead). VIP players get "[⭐VIP]" before their chat name.
]]

local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local TextChatService = game:GetService("TextChatService")
local TextService = game:GetService("TextService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(Shared:WaitForChild("Windows"))
local Lang = require(Shared:WaitForChild("Lang")) -- (Lang.set: a text set every frame, only when it changes)
local Sfx = require(Shared:WaitForChild("Sfx"))
local Fx = require(Shared:WaitForChild("Fx"))
local Notices = require(Shared:WaitForChild("Notices"))
local Prices = require(Shared:WaitForChild("Prices"))

local player = Players.LocalPlayer
local M = Config.Monetization

-- display only
local FONT = Enum.Font.GothamBold
local OPEN_SIZE = UDim2.fromOffset(68, 36)
local OPEN_POS = UDim2.new(1, -12 - 2 * (68 + 10), 0, 178)
local COLOR_OPEN = Color3.fromRGB(70, 150, 255)
local WINDOW_SIZE = UDim2.fromOffset(470, 400)
local ROW_HEIGHT = 64
local DETAIL_TEXT_SIZE = 12 -- the opened explanation
local DETAIL_LINE_HEIGHT = 1.05
local DETAIL_PAD = 8
local DETAIL_INSET = 14 -- its left edge in the row (and as much room on the right)
local COLOR_DETAIL = Color3.fromRGB(225, 230, 245)
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_ROW = Color3.fromRGB(45, 50, 68)
local COLOR_TAB_ON = Color3.fromRGB(70, 150, 255)
local COLOR_TAB_OFF = Color3.fromRGB(60, 64, 80)
local COLOR_BUY = Color3.fromRGB(80, 170, 90)
local COLOR_OWNED = Color3.fromRGB(90, 90, 100)
local COLOR_CLOSE = Color3.fromRGB(235, 70, 80)
local COLOR_SOFT = Color3.fromRGB(190, 190, 200)
local COLOR_GOLD = Color3.fromRGB(255, 215, 90)
local OFFER_SIZE = UDim2.fromOffset(320, 200)
-- the starter pack pop-up's lively background (2026-10-02, "여기 안 배경 좀더 화려하고 역동적이게")
local OFFER_COLORS = { Color3.fromRGB(70, 30, 140), Color3.fromRGB(170, 40, 150), Color3.fromRGB(240, 120, 40) }
local OFFER_SHADE = 0.35 -- a dark veil over it so the words stay easy to read
local OFFER_RAYS = 14 -- light rays turning behind everything
local OFFER_RAY_TURN = 12 -- degrees a second
local OFFER_RAY_COLOR = Color3.fromRGB(255, 235, 150)
local OFFER_RAY_TRANSPARENCY = 0.82
local OFFER_SPARKLES = 16
local OFFER_SPARKLE_COLORS = { Color3.fromRGB(255, 240, 150), Color3.fromRGB(255, 255, 255), Color3.fromRGB(150, 230, 255) }
local OFFER_SHINE_EVERY = 2.6 -- seconds between the white shine sweeping across
local OFFER_GRADIENT_TURN = 25 -- degrees a second the colors slide round
local OFFER_EDGE_COLORS = { Color3.fromRGB(255, 215, 90), Color3.fromRGB(255, 120, 200), Color3.fromRGB(120, 220, 255) }
local VIP_TAG = "<font color=\"#FFD75A\">[⭐VIP]</font> "

local gui = Instance.new("ScreenGui")
gui.Name = "Robux"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.TextWrapped = true
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 13
	b.TextColor3 = Color3.new(1, 1, 1)
	b.BackgroundColor3 = color
	b.Text = text
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 8)
	return b
end

-- ---------------------------------------------------------------------------
-- What is on sale
-- ---------------------------------------------------------------------------

local function level()
	return player:GetAttribute("DefenseLevel") or 1
end

-- a pack's time: "4시간", or under an hour "45분" (2026-10-02: the money packs give 0.75, 4, 11, 37 hours)
local function packTime(hours)
	if hours < 1 then
		return string.format("%d분", math.floor(hours * 60 + 0.5))
	end
	return string.format("%g시간", hours)
end

local function restricted()
	return player:GetAttribute("PaidRandomItemsRestricted") == true
end

local function packMoney(hours)
	return Formulas.moneyPackMoney(level(), player:GetAttribute("HourlyIncome"), hours)
end

-- key and money packs bought today (Monetization mirrors Today_<key> and PacksDay; the day turns as Config.Rewards)
local function boughtToday(key)
	local day = math.floor((os.time() + Config.Rewards.ResetOffsetHours * 3600) / 86400)
	return player:GetAttribute("PacksDay") == day and (player:GetAttribute("Today_" .. key) or 0) or 0
end
local function packLimit(id)
	return Config.Monetization.PackDailyLimit[id] or math.huge
end

-- (2026-10-02, "문제 해결해봐") a luck potion's worth with my saved normal keys now: how many keys, and the
-- Legendary+ dinos they would give without and with it (the same odds the server rolls)
local function luckForecast(multiplier)
	local keys = player:GetAttribute("Keys") or 0
	local base = (player:GetAttribute("Luck") or 1) * (1 + (player:GetAttribute("BonusRareChance") or 0))
	local function legendaries(luck)
		local share = 0
		for _, r in ipairs(Formulas.gachaOdds(level(), { luck = luck }).Rarities) do
			if Formulas.rarityRank(r.Id) >= Formulas.rarityRank(Config.Gacha.LuckFromRarity) then
				share += r.Percent / 100
			end
		end
		return keys * share
	end
	return keys, legendaries(base), legendaries(base * multiplier)
end
-- the best rarity a ruby key can bring me now (its own awakening's rarities at least, Formulas.keyRarityLevel)
local function rubyTop()
	local top = Config.Rarities[1]
	for _, r in ipairs(Formulas.gachaOdds(level(), { keyType = "Ruby" }).Rarities) do
		if r.Percent > 0 then
			top = Formulas.rarity(r.Id)
		end
	end
	return top
end
local LUCK_WORTH_MIN = 0.5 -- extra Legendary+ dinos below this: the card itself warns (few read the details)

local function rareShare(keyType, luck)
	local share = 0
	for _, r in ipairs(Formulas.gachaOdds(level(), { keyType = keyType, luck = luck }).Rarities) do
		if Formulas.rarityRank(r.Id) >= Formulas.rarityRank(Config.Gacha.LuckFromRarity) then
			share += r.Percent / 100
		end
	end
	return share
end
local function packForecast(keys, special, luck)
	local n = keys * rareShare(nil, luck)
	for id, count in pairs(special or {}) do
		n += count * rareShare(id, luck)
	end
	return n
end
local function myLuck()
	return (player:GetAttribute("Luck") or 1) * (1 + (player:GetAttribute("BonusRareChance") or 0))
end

-- { key, kind ("product" | "pass"), icon, name, text(), robux, soldOut, locked }
local function catalog(tab)
	local P, list = Config.Products, {}
	local function add(key, kind, icon, name, text, robux)
		table.insert(list, { key = key, kind = kind, icon = icon, name = name, text = text, robux = robux })
	end
	if tab == "Featured" then
		if not player:GetAttribute("StarterBought") then
			add("StarterPack", "product", "🎁", "스타터 팩 (한 번만!)", function()
				return string.format("⭐ %s 확정 + 🔑 열쇠 %d개 + ✨ 황금 %d + 💎 루비 %d + 🍀 %d분",
					Formulas.rarity(Formulas.starterSureRarity(level())).Name, Formulas.keyPackKeys(level(), P.StarterPack.KeyHours),
					P.StarterPack.SpecialKeys.Gold, P.StarterPack.SpecialKeys.Ruby or 0, P.StarterPack.LuckMinutes)
			end, P.StarterPack.Robux)
		end
		add("ServerLuckBoost", "product", "🌍", "서버 행운 선물", function()
			return string.format("🌍 모두 뽑기 행운 ×%d %d분 + 👑 제단 하늘에 내 이름", P.ServerLuckBoost.LuckMultiplier, P.ServerLuckBoost.Minutes)
		end, P.ServerLuckBoost.Robux)
		add("ServerLuckBoostBig", "product", "🌈", "서버 행운 대선물", function()
			return string.format("🌍 모두 뽑기 행운 ×%d %d분 + 👑 제단 하늘에 내 이름", P.ServerLuckBoostBig.LuckMultiplier, P.ServerLuckBoostBig.Minutes)
		end, P.ServerLuckBoostBig.Robux)
		-- (2026-10-02) this week's limited dino, sure, once a limited week (Limited service)
		local limited = ReplicatedStorage:GetAttribute("LimitedSpecies")
		if limited and player:GetAttribute("LimitedBoughtWeek") ~= Formulas.limitedWeek(Workspace:GetServerTimeNow()) then
			add("LimitedDino", "product", "🎖️", "이번 주 한정 공룡", function()
				return string.format("🎖️ %s 확정 (%s · %s, 주 1회)", Formulas.species(limited).Name,
					Formulas.rarity(Formulas.limitedDinoRarity(level())).Name, Formulas.dinoSize(P.LimitedDino.Size).Name)
			end, P.LimitedDino.Robux)
		end
		local records = 0
		for _, name in ipairs({ "RaceWins", "RaceLosses", "SkyWins", "SkyLosses", "HideWins", "HideLosses" }) do
			records += player:GetAttribute(name) or 0
		end
		-- (2026-10-01; 2026-10-03: the 🙈 hide-and-seek record too)
		if records > 0 then
			add("RaceRecordReset", "product", "🏁", "기록 초기화권", function()
				return string.format("🔁 머리 위 기록 🏁%d승 %d패 · 🦅%d승 %d패 · 🙈%d승 %d패 → 0승 0패",
					player:GetAttribute("RaceWins") or 0, player:GetAttribute("RaceLosses") or 0, player:GetAttribute("SkyWins") or 0,
					player:GetAttribute("SkyLosses") or 0, player:GetAttribute("HideWins") or 0, player:GetAttribute("HideLosses") or 0)
			end, P.RaceRecordReset.Robux)
		end
	elseif tab == "Luck" then
		-- (2026-10-02) with too few keys the card itself says so, in place of the usual line
		local function potionLine(data, usual)
			local keys, without, with = luckForecast(data.LuckMultiplier)
			if with - without < LUCK_WORTH_MIN then
				return string.format("⚠ 지금 열쇠 %s개로는 효과가 작아요. 열쇠를 모은 뒤에!", Formulas.shortNumber(keys))
			end
			return usual
		end
		add("LuckPotion", "product", "🍀", "행운 포션", function()
			return potionLine(P.LuckPotion, string.format("🍀 내 뽑기 행운 ×%d %d분 (맨 위 %d등급엔 절반)",
				P.LuckPotion.LuckMultiplier, P.LuckPotion.Minutes, Config.Gacha.TopLuck.Rarities))
		end, P.LuckPotion.Robux)
		add("LuckPotionBig", "product", "🍀", "행운 포션 대", function()
			return potionLine(P.LuckPotionBig, string.format("🍀 내 뽑기 행운 ×%d %d분 (맨 위 %d등급엔 절반)", P.LuckPotionBig.LuckMultiplier,
				P.LuckPotionBig.Minutes, Config.Gacha.TopLuck.Rarities))
		end, P.LuckPotionBig.Robux)
		if ReplicatedStorage:GetAttribute("LimitedSpecies") then -- (2026-10-02)
			add("LimitedLuckPotion", "product", "🎖️", "한정 행운 포션", function()
				return string.format("🎖️ 이번 주 한정 공룡 ×%d %d분", P.LimitedLuckPotion.LimitedMultiplier, P.LimitedLuckPotion.Minutes)
			end, P.LimitedLuckPotion.Robux)
		end
		add("SpeedPotion", "product", "👟", "스피드 포션", function()
			return string.format("👟 이동속도 +%d%% %d분 (레이스 빼고 · 더 마시면 시간 UP)", math.floor(P.SpeedPotion.SpeedBonus * 100 + 0.5), P.SpeedPotion.Minutes)
		end, P.SpeedPotion.Robux)
		add("SpeedPotionBig", "product", "👟", "스피드 포션 대", function()
			return string.format("👟 이동속도 +%d%% %d분 (레이스 빼고)", math.floor(P.SpeedPotionBig.SpeedBonus * 100 + 0.5), P.SpeedPotionBig.Minutes)
		end, P.SpeedPotionBig.Robux)
	elseif tab == "Keys" then
		for _, pack in ipairs(Config.KeyPacks) do
			local key = "KeyPack_" .. pack.Id
			add(key, "product", "🔑", string.format("열쇠 %g시간치", pack.Hours), function()
				local normal, gold = Formulas.keyPackSplit(level(), pack.Hours, player:GetAttribute("HourlyIncome"))
				return string.format("🔑 열쇠 %s개 + ✨ 황금 열쇠 %d개 (%g시간치) · 오늘 %d/%d", Formulas.shortNumber(normal), gold,
					pack.Hours, boughtToday(key), packLimit(pack.Id))
			end, pack.Robux)
			list[#list].soldOut = boughtToday(key) >= packLimit(pack.Id)
		end
		-- (2026-10-02, "루비열쇠로 열 수 있는 상품을 가질 수 있게 해줘. 돈 쓴거잖아") a ruby key draws its own awakening's
		-- rarities even before it (Formulas.keyRarityLevel), so it is worth its price at any level: the card says
		-- what it can bring right on its line
		add("RubyKeys", "product", "💎", string.format("루비 열쇠 %d개", P.RubyKeys.SpecialKeys.Ruby), function()
			local before = not Formulas.keyShopOpen("Ruby", player:GetAttribute("Rebirths") or 0)
			return before and string.format("💎 환생 전에도 %s까지 나와요! %d번 뽑은 것 중 최고", rubyTop().Name, Formulas.keyPicks("Ruby"))
				or string.format("💎 하나로 %d번 뽑은 것 중 제일 좋은 공룡 (최고 %s)", Formulas.keyPicks("Ruby"), rubyTop().Name)
		end, P.RubyKeys.Robux)
	elseif tab == "Money" then
		if not player:GetAttribute("PassDoubleMoney") then -- (with the pass it would add nothing)
			add("MoneyBoost", "product", "⏱️", "돈 2배 1시간", function()
				return string.format("💰 1시간 동안 버는 돈 ×%d (지금 열심히 할 때!)", P.MoneyBoost.MoneyMultiplier)
			end, P.MoneyBoost.Robux)
		end
		for _, pack in ipairs(Config.MoneyPacks) do
			local key = "MoneyPack_" .. pack.Id
			add(key, "product", "💰", string.format("게임머니 %s치", packTime(pack.Hours)), function()
				return string.format("💰 내가 버는 돈 %s치 (지금 %s원) · 오늘 %d/%d", packTime(pack.Hours),
					Formulas.shortNumber(packMoney(pack.Hours)), boughtToday(key), packLimit(pack.Id))
			end, pack.Robux)
			list[#list].soldOut = boughtToday(key) >= packLimit(pack.Id)
		end
	else
		local G = Config.GamePasses
		add("DoubleMoney", "pass", "💰", "게임머니 2배", function()
			return "💰 버는 돈이 영원히 ×2"
		end, G.DoubleMoney.Robux)
		add("DoubleBag", "pass", "🎒", "가방 2배 + 빠른 채굴", function()
			return string.format("🎒 광물 2배 담기 + ⛏️ 채굴 속도 +%d%% (영원히)", math.floor(G.DoubleBag.MiningSpeedBonus * 100 + 0.5))
		end, G.DoubleBag.Robux)
		add("AutoMine", "pass", "⛏️", "자동 채굴", function()
			return "⛏️ 광물을 알아서 캐고 팔아요 (🍎 자동 열매는 누구나 무료)"
		end, G.AutoMine.Robux)
		add("PlacementSlot", "pass", "🦖", "공룡 자리 +1", function()
			local slots = player:GetAttribute("DefenseSlots")
			if slots and slots > 0 and not player:GetAttribute("PassPlacementSlot") then
				return string.format("🦖 아레나 공룡 %d → %d마리 (+%d%%)", slots, slots + G.PlacementSlot.Slots,
					math.floor(G.PlacementSlot.Slots / slots * 100 + 0.5))
			end
			return "🦖 아레나에 공룡을 한 마리 더"
		end, G.PlacementSlot.Robux)
		add("FarmSlots", "pass", "🌾", "농장 칸 +10", function()
			-- (2026-10-02) said on the card when some farm bonuses are already at their cap (Farm: FarmCapped)
			-- (2026-10-02, "현질엔 확실히 이득") the pass raises every farm cap too, so even a maxed farm gains
			local capped = player:GetAttribute("FarmCapped") or 0
			return string.format(capped > 0 and "🌾 농장 +10칸 · 🔝 효과 끝 ×%g (끝에 닿은 효과도 더 올라요!)"
				or "🌾 농장 +10칸 · 🔝 효과 끝도 ×%g", Config.Farm.PassCapMultiplier)
		end, G.FarmSlots.Robux)
		add("VIP", "pass", "⭐", "VIP", function()
			if restricted() then -- (2026-10-02: no keys there, design 14)
				local alt = G.VIP.RestrictedDaily
				return string.format("채팅 [⭐VIP] 표시 + 매일 이동속도 %d분 + 폭탄 %d개씩", alt.SpeedMinutes, alt.Bombs.Egg)
			end
			return string.format("채팅 [⭐VIP] 표시 + 매일 열쇠 %s개 + 은 %d개 + 황금 %d개",
				Formulas.shortNumber(Formulas.keyPackKeys(level(), G.VIP.DailyKeyHours)),
				G.VIP.DailySpecialKeys.Silver or 0, G.VIP.DailySpecialKeys.Gold or 0)
		end, G.VIP.Robux)
	end
	return list
end

-- the Roblox id to sell it by, and whether it is a game pass (a pass may be made as a developer product instead:
-- PassProductIds, 2026-10-02)
local function assetId(item)
	if item.kind == "pass" then
		local passId = M.GamePassIds[item.key] or 0
		if passId > 0 then
			return passId, true
		end
		return (M.PassProductIds or {})[item.key] or 0, false
	end
	return M.ProductIds[item.key] or 0, false
end

local function price(item)
	local id, isPass = assetId(item)
	return Prices.get(id, isPass, item.robux)
end

-- the plain explanation under a tapped row: lines of what it gives, for how long, what to know
local function keyName(id)
	local t = Formulas.keyType(id)
	return t and t.Name or id
end
local function details(item)
	local P, G, key = Config.Products, Config.GamePasses, item.key
	local first = not player:GetAttribute("FirstPurchaseDone")
	-- the first pack's extra (Formulas.firstPurchaseBonusHours: ×2, at most 5 hours more)
	local function firstLine(hours)
		return first and string.format("🎉 첫 구매 보너스: %s치 더 줘요", packTime(Formulas.firstPurchaseBonusHours(hours))) or nil
	end
	local lines
	local packKind, packId = string.match(key, "^(%a+Pack)_(%a+)$")
	if key == "StarterPack" then
		local s = P.StarterPack
		local sure = Formulas.rarity(Formulas.starterSureRarity(level())).Name
		local keys = Formulas.keyPackKeys(level(), s.KeyHours)
		local expect = 1 + packForecast(keys, s.SpecialKeys, myLuck() * Config.StarterMissions.LuckMultiplier)
		lines = { string.format("⭐ %s 확정 뽑기 1회 (다음 뽑기 첫 공룡)", sure),
			string.format("🔑 열쇠 %s개 (내가 %g시간 모으는 만큼)", Formulas.shortNumber(keys), s.KeyHours),
			string.format("✨ %s %d개: 하나로 열쇠 %d번 뽑은 것 중 제일 좋은 공룡", keyName("Gold"), s.SpecialKeys.Gold, Formulas.keyPicks("Gold")),
			string.format("💎 %s %d개: 하나로 열쇠 %s번 뽑은 것 중 제일 좋은 공룡", keyName("Ruby"), s.SpecialKeys.Ruby or 0, Formulas.shortNumber(Formulas.keyPicks("Ruby"))),
			string.format("🍀 뽑기 행운 ×%d · %d분", Config.StarterMissions.LuckMultiplier, s.LuckMinutes),
			string.format("📊 행운 켜고 다 뽑으면 %s 이상 약 %d마리!", Formulas.rarity(Config.Gacha.LuckFromRarity).Name,
				math.floor(expect + 0.5)),
			"⚠️ 계정마다 한 번만 살 수 있어요" }
	elseif key == "ServerLuckBoost" or key == "ServerLuckBoostBig" then
		local s = P[key]
		lines = { string.format("🌍 이 서버 모두의 뽑기 행운 ×%d · %d분", s.LuckMultiplier, s.Minutes),
			string.format("👑 제단 하늘에 내 사진·이름 %d분 + 서버 알림", s.Minutes),
			"⏱️ 같은 선물이 켜져 있으면 시간이 더해져요" }
	elseif key == "RaceRecordReset" then
		lines = { "🔁 머리 위 기록을 모두 0승 0패로 (🏁 지상 · 🦅 하늘 · 🙈 숨바꼭질)",
			string.format("📊 지금: 🏁 지상 %d승 %d패 · 🦅 하늘 %d승 %d패", player:GetAttribute("RaceWins") or 0,
				player:GetAttribute("RaceLosses") or 0, player:GetAttribute("SkyWins") or 0, player:GetAttribute("SkyLosses") or 0),
			string.format("📊 🙈 숨바꼭질 %d승 %d패", player:GetAttribute("HideWins") or 0, player:GetAttribute("HideLosses") or 0),
			"⚠️ 탈 공룡·레이스 실력은 그대로예요" }
	elseif key == "LuckPotion" or key == "LuckPotionBig" then
		local s = P[key]
		lines = { string.format("🍀 내 뽑기에서 전설 이상 ×%d · %d분", s.LuckMultiplier, s.Minutes),
			"💡 열쇠를 모아 뒀다가 마시고 한꺼번에 뽑아요",
			"⏱️ 더 마시면 시간이 늘어나요 (×는 그대로)",
			string.format("🔝 마시면 행운 한도 ×%d → ×%d", Config.Gacha.LuckMaxMultiplier, Config.Gacha.PaidLuckMax),
			string.format("⚠️ 맨 위 %d등급엔 행운이 절반만", Config.Gacha.TopLuck.Rarities) }
		local keys, without, with = luckForecast(s.LuckMultiplier)
		table.insert(lines, string.format("📊 지금 열쇠 %s개를 다 뽑으면 전설 이상 약 %.1f마리 → 마시면 약 %.1f마리",
			Formulas.shortNumber(keys), without, with))
		if with - without < LUCK_WORTH_MIN then
			table.insert(lines, "⚠ 열쇠가 적어요! 열쇠를 더 모은 뒤 마셔요")
		end
	elseif key == "SpeedPotion" or key == "SpeedPotionBig" then
		local s = P[key]
		lines = { string.format("👟 걷는 속도 +%d%% · %d분", math.floor(s.SpeedBonus * 100 + 0.5), s.Minutes),
			"⚠️ 열쇠를 들면 느려지는 건 그대로예요",
			"⚠️ 🏁 레이스에선 안 빨라져요 (모두 같은 속도)",
			"⏱️ 더 마시면 시간이 늘어나요 (속도는 그대로)" }
	elseif key == "LimitedLuckPotion" then -- (2026-10-02)
		local s = P.LimitedLuckPotion
		lines = { string.format("🎖️ 이번 주 한정 공룡 %g%% → %g%% · %d분", Config.Gacha.LimitedChancePercent,
				Config.Gacha.LimitedPotionChancePercent, s.Minutes),
			"🏅 그렇게 나온 공룡엔 🎖️ 표시가 영원히 붙어요",
			"⏱️ 더 마시면 시간이 늘어나요" }
	elseif key == "LimitedDino" then
		local limited = ReplicatedStorage:GetAttribute("LimitedSpecies")
		lines = { string.format("🎖️ %s 1마리 · ⭐ %s 등급 · 📏 %s 크기", limited and Formulas.species(limited).Name or "?",
				Formulas.rarity(Formulas.limitedDinoRarity(level())).Name, Formulas.dinoSize(P.LimitedDino.Size).Name),
			"⭐ 등급은 내 레벨에 맞춘 좋은 등급 (전설 이상)",
			"📅 이번 주에만, 한 번만 (토요일에 바뀌어요)",
			"🏅 타고 다니면 머리 위에 \"🎖️ 한정\" 뱃지" }
	elseif key == "RubyKeys" then
		local top = rubyTop()
		lines = { string.format("💎 %s %d개 · 바로 저장돼요", keyName("Ruby"), P.RubyKeys.SpecialKeys.Ruby),
			string.format("✨ 하나로 열쇠 %s번 뽑은 것 중 제일 좋은 공룡", Formulas.shortNumber(Formulas.keyPicks("Ruby"))),
			string.format("🔝 지금 최고 %s까지 (환생 전에도 %s 등급까지)", top.Name,
				Formulas.keyShopCondition("Ruby")) }
	elseif key == "MoneyBoost" then
		lines = { string.format("💰 1시간 동안 버는 돈 ×%d (⛏️ 광물 · 🌟 대박 · 🦖 디펜스 · 📦 상자)", P.MoneyBoost.MoneyMultiplier),
			"⏱️ 더 사면 시간이 늘어나요",
			"⚠️ 게임머니 2배 패스가 있으면 필요 없어요 (겹치지 않아요)" }
	elseif packKind == "KeyPack" then
		for _, pack in ipairs(Config.KeyPacks) do
			if pack.Id == packId then
				local normal, gold = Formulas.keyPackSplit(level(), pack.Hours, player:GetAttribute("HourlyIncome"))
				local expect = packForecast(normal, { Gold = gold }, myLuck())
				lines = { string.format("🔑 열쇠 %s개 + ✨ 황금 열쇠 %d개 (내가 %g시간 모으는 만큼)", Formulas.shortNumber(normal), gold, pack.Hours),
					string.format("📊 다 뽑으면 %s 이상 약 %d마리", Formulas.rarity(Config.Gacha.LuckFromRarity).Name, math.floor(expect + 0.5)),
					"⛏️ 많이 캐고 사냥할수록 1시간치가 커져요",
					string.format("✨ 황금 열쇠 하나 = 열쇠 %d번 뽑은 것 중 제일 좋은 것 · %s 이상 · 환생하면 신화 이상도", Formulas.keyPicks("Gold"),
						Formulas.rarity(Formulas.keyType("Gold").FloorRarity).Name),
					"💾 바로 저장돼요 (맞아도 안 흩어져요)",
					string.format("📅 하루 %d개까지 (오늘 %d개 샀어요)", packLimit(pack.Id), boughtToday(key)) }
				if not player:GetAttribute("FirstKeyPackDone") then -- (2026-10-02) the first key pack's sure draw
					table.insert(lines, string.format("⭐ 첫 열쇠 팩: %s 확정 뽑기 1회 더",
						Formulas.rarity(Config.Monetization.FirstKeyPackGuaranteed).Name))
				end
				table.insert(lines, firstLine(pack.Hours))
			end
		end
	elseif packKind == "MoneyPack" then
		for _, pack in ipairs(Config.MoneyPacks) do
			if pack.Id == packId then
				lines = { string.format("💰 내가 1시간에 버는 돈의 %s치 (지금 %s원)", packTime(pack.Hours), Formulas.shortNumber(packMoney(pack.Hours))),
					"⛏️ 많이 캐고 사냥할수록 1시간치가 커져요",
					string.format("📅 하루 %d개까지 (오늘 %d개 샀어요)", packLimit(pack.Id), boughtToday(key)), firstLine(pack.Hours) }
			end
		end
	elseif key == "DoubleMoney" then
		lines = { "💰 버는 돈이 영원히 ×2 (⛏️ 광물 · 🌟 대박 · 🦖 디펜스 · 📦 상자)",
			"🔄 환생해도 그대로예요", "⚠️ 돈 2배 1시간과는 겹치지 않아요" }
	elseif key == "DoubleBag" then
		local bag = player:GetAttribute("TrainReal_Bag") or player:GetAttribute("BagLevel") or 1
		lines = { string.format("🎒 가방 ×%d (지금 %d개 → %d개)", G.DoubleBag.CapacityMultiplier, Formulas.bagCapacity(bag, false),
				Formulas.bagCapacity(bag, true)),
			string.format("⛏️ 채굴 속도 +%d%%", math.floor(G.DoubleBag.MiningSpeedBonus * 100 + 0.5)),
			"🔄 가방을 키워도, 환생해도 그대로예요" }
	elseif key == "AutoMine" then
		lines = { "⛏️ 돈이 가장 빨리 모이는 광물로 달려가서 캐요", "💰 가방이 차면 기지 입금통에 넣고 다시 와요",
			"🍎 자동 열매는 패스 없이도 돼요. 패스가 있으면 ⛏️ 광물·🍎 열매 둘 다도!",
			"👆 ⛏️ 자동 버튼: 켜기·끄기 · 🔄 광물 → 열매 → 둘 다 · 움직이면 꺼져요" }
	elseif key == "PlacementSlot" then
		local slots = player:GetAttribute("DefenseSlots")
		lines = { slots and string.format("🦖 아레나에 공룡 한 마리 더 (지금 %d칸 → %d칸)", slots, slots + G.PlacementSlot.Slots)
				or "🦖 아레나에 공룡 한 마리 더",
			"🔄 영원히, 환생해도 그대로예요" }
	elseif key == "FarmSlots" then
		local slots = player:GetAttribute("FarmSlots")
		lines = { slots and string.format("🌾 농장 칸 +%d (지금 %d칸 → %d칸)", G.FarmSlots.Slots, slots, slots + G.FarmSlots.Slots)
				or string.format("🌾 농장 칸 +%d", G.FarmSlots.Slots),
			"💪 농장 공룡이 많을수록 파워·돈·행운이 커져요",
			string.format("🔝 농장 효과 끝 ×%g: 💪 +%d%% → +%d%% · 💰⛏️ +%d%% → +%d%%",
				Config.Farm.PassCapMultiplier, math.floor(Config.Farm.UnitPowerCap * 100 + 0.5),
				math.floor(Config.Farm.UnitPowerCap * Config.Farm.PassCapMultiplier * 100 + 0.5),
				math.floor(Config.Farm.MoneyCap * 100 + 0.5),
				math.floor(Config.Farm.MoneyCap * Config.Farm.PassCapMultiplier * 100 + 0.5)),
			string.format("🔝 🍀 +%d%% → +%d%% · 🐢 %d%% → %d%%",
				math.floor(Config.Farm.RareChanceCap * 100 + 0.5),
				math.floor(Config.Farm.RareChanceCap * Config.Farm.PassCapMultiplier * 100 + 0.5),
				math.floor(Config.Farm.MonsterSlowCap * 100 + 0.5), math.floor(Config.Farm.PassSlowCapMax * 100 + 0.5)),
			"🔄 영원히, 환생해도 그대로예요" }
	elseif key == "VIP" and restricted() then
		local alt = G.VIP.RestrictedDaily
		lines = { "⭐ 채팅 이름 앞에 [⭐VIP]",
			string.format("👟 매일 처음 들어오면 이동속도 +%d%% %d분", math.floor(Config.Products.SpeedPotion.SpeedBonus * 100 + 0.5),
				alt.SpeedMinutes),
			string.format("💥 알 폭탄 %d개 + 💩 똥 폭탄 %d개 (최대 %d개까지)", alt.Bombs.Egg, alt.Bombs.Poop, Config.Bombs.MaxHeld),
			"🔄 영원히 그대로예요" }
	elseif key == "VIP" then
		lines = { "⭐ 채팅 이름 앞에 [⭐VIP]",
			string.format("🔑 매일 처음 들어오면 열쇠 %s개 (내가 %g시간 모으는 만큼)",
				Formulas.shortNumber(Formulas.keyPackKeys(level(), G.VIP.DailyKeyHours)), G.VIP.DailyKeyHours),
			string.format("✨ 매일 은 열쇠 %d개 + 황금 열쇠 %d개", G.VIP.DailySpecialKeys.Silver or 0, G.VIP.DailySpecialKeys.Gold or 0),
			"🔄 영원히 그대로예요" }
	end
	local out = {}
	for _, line in ipairs(lines or {}) do -- (a nil firstLine at the end just stops the list)
		table.insert(out, line)
	end
	return out
end

local function buy(item)
	if ReplicatedStorage:GetAttribute("TutorialField") then -- (2026-10-03: the practice field keeps nothing)
		Notices.show("💎 상점", "🏠 튜토리얼 필드에선 못 사요. 내 기지로 가면 살 수 있어요")
		return
	end
	if item.key == "MoneyBoost" and player:GetAttribute("PassDoubleMoney") then
		return -- (2026-10-01, "with the forever pass, the 1-hour one can't be bought": Roblox charges before the
		-- server could say no, so it is never offered)
	end
	local id, isPass = assetId(item)
	if id > 0 then
		if isPass then
			MarketplaceService:PromptGamePassPurchase(player, id)
		else
			MarketplaceService:PromptProductPurchase(player, id)
		end
	elseif RunService:IsStudio() then
		Net.request("StudioBuy", item.key) -- (no id yet: Studio grants it to test)
	end
end

local function randomItem(item)
	local group = string.match(item.key, "^KeyPack_") and "KeyPacks" or string.match(item.key, "^MoneyPack_") and "MoneyPacks"
		or item.key
	return table.find(Config.RestrictedProducts, group) ~= nil
end

-- ---------------------------------------------------------------------------
-- The window
-- ---------------------------------------------------------------------------

local open = button(gui, "💎 상점", COLOR_OPEN, OPEN_SIZE, OPEN_POS)
require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("SideButtons")).register(open)
open.AnchorPoint = Vector2.new(1, 0.5)
open.TextSize = 13

local window = Instance.new("Frame")
window.AnchorPoint = Vector2.new(0.5, 0.5)
window.Position = UDim2.fromScale(0.5, 0.5)
window.Size = WINDOW_SIZE
window.BackgroundColor3 = COLOR_BG
window.Visible = false
window.Parent = gui
require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("DinoPortrait")).backdrop(window, "Spino")
corner(window, 14)
Windows.fit(window)
label(window, "💎 상점", UDim2.fromOffset(90, 34), UDim2.fromOffset(12, 6), 18).TextXAlignment = Enum.TextXAlignment.Left
local close = button(window, "X", COLOR_CLOSE, UDim2.fromOffset(34, 34), UDim2.new(1, -42, 0, 8))
close.TextSize = 16
local firstLine = label(window, "", UDim2.new(1, -24, 0, 18), UDim2.fromOffset(12, 84), 12)
firstLine.TextColor3 = COLOR_GOLD
firstLine.TextXAlignment = Enum.TextXAlignment.Left

local TABS = { { "Featured", "⭐ 추천" }, { "Luck", "🍀 행운" }, { "Keys", "🔑 열쇠" }, { "Money", "💰 돈" }, { "Passes", "🎫 패스" } }
local tabButtons = {}
local current = "Featured"
local opened = nil -- the item key whose explanation is open
for i, t in ipairs(TABS) do
	tabButtons[t[1]] = button(window, t[2], COLOR_TAB_OFF, UDim2.fromOffset(84, 30), UDim2.fromOffset(12 + (i - 1) * 90, 46))
end

local list = Instance.new("ScrollingFrame")
list.Position = UDim2.fromOffset(10, 106)
list.Size = UDim2.new(1, -20, 1, -116)
list.BackgroundTransparency = 1
list.ScrollBarThickness = 6
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = window
local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 6)
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = list

local function rebuild()
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
	for name, b in pairs(tabButtons) do
		b.BackgroundColor3 = name == current and COLOR_TAB_ON or COLOR_TAB_OFF
	end
	firstLine.Text = player:GetAttribute("FirstPurchaseDone") and "ℹ️ 상품을 누르면 자세한 설명이 나와요"
		or string.format("🎉 첫 구매 보너스: 열쇠·게임머니 팩 처음 사면 ×%d (최대 +%d시간치)", M.FirstPurchaseMultiplier,
			M.FirstPurchaseMaxBonusHours)
	local shown = 0
	for i, item in ipairs(catalog(current)) do
		if not (restricted() and randomItem(item)) then
			shown += 1
			local lines = opened == item.key and details(item) or {}
			local detailText = table.concat(lines, "\n")
			local detailWidth = math.max(list.AbsoluteSize.X - 8 - DETAIL_INSET * 2, 100)
			local extra = #lines > 0 and math.ceil(TextService:GetTextSize(detailText, DETAIL_TEXT_SIZE, FONT,
				Vector2.new(detailWidth, 10000)).Y * DETAIL_LINE_HEIGHT) + DETAIL_PAD or 0
			local row = Instance.new("Frame")
			row.LayoutOrder = i
			row.Size = UDim2.new(1, -8, 0, ROW_HEIGHT + extra)
			row.BackgroundColor3 = COLOR_ROW
			row.Parent = list
			corner(row, 10)
			-- tapping the row (not its buy button) opens or closes its explanation
			local tap = Instance.new("TextButton")
			tap.Text = ""
			tap.BackgroundTransparency = 1
			tap.Size = UDim2.new(1, -116, 1, 0)
			tap.Parent = row
			tap.Activated:Connect(function()
				opened = opened ~= item.key and item.key or nil
				rebuild()
			end)
			if extra > 0 then
				local d = label(row, detailText, UDim2.new(1, -DETAIL_INSET * 2, 0, extra - DETAIL_PAD),
					UDim2.fromOffset(DETAIL_INSET, ROW_HEIGHT - 2), DETAIL_TEXT_SIZE)
				d.TextXAlignment = Enum.TextXAlignment.Left
				d.TextYAlignment = Enum.TextYAlignment.Top
				d.TextColor3 = COLOR_DETAIL
				d.LineHeight = DETAIL_LINE_HEIGHT
			end
			label(row, item.icon, UDim2.fromOffset(44, 44), UDim2.fromOffset(6, ROW_HEIGHT / 2 - 22), 28)
			local name = label(row, item.name .. (opened == item.key and "  ▲" or "  ℹ️"), UDim2.new(1, -170, 0, 22), UDim2.fromOffset(56, 6), 14)
			name.TextXAlignment = Enum.TextXAlignment.Left
			local text = label(row, item.text(), UDim2.new(1, -170, 0, 32), UDim2.fromOffset(56, 28), 11)
			text.TextXAlignment = Enum.TextXAlignment.Left
			text.TextYAlignment = Enum.TextYAlignment.Top
			text.TextColor3 = COLOR_SOFT
			local owned = item.kind == "pass" and player:GetAttribute("Pass" .. item.key)
			local ready = assetId(item) > 0 or RunService:IsStudio()
			local b = button(row, owned and "✅ 보유 중" or item.locked or item.soldOut and "내일 또!"
				or ready and string.format("💎 %d", price(item))
				or "준비 중", (owned or item.locked or item.soldOut or not ready) and COLOR_OWNED or COLOR_BUY, UDim2.fromOffset(100, 40),
				UDim2.new(1, -108, 0, ROW_HEIGHT / 2 - 20)) -- (stays by the name when the row opens)
			b.TextSize = 15
			if item.key == "KeyPack_" .. Config.KeyPacks[#Config.KeyPacks].Id
				or item.key == "MoneyPack_" .. Config.MoneyPacks[#Config.MoneyPacks].Id then
				local best = label(row, "⭐ 가장 이득", UDim2.fromOffset(100, 12), UDim2.new(1, -108, 0, ROW_HEIGHT / 2 + 21), 10)
				best.TextColor3 = COLOR_GOLD
			end
			if not owned and not item.locked and not item.soldOut and ready then
				b.Activated:Connect(function()
					buy(item)
				end)
			end
		end
	end
	if shown == 0 then
		label(list, "🚫 이 지역에서는 살 수 없는 상품이에요", UDim2.new(1, -8, 0, 40), UDim2.new(), 13).TextColor3 = COLOR_SOFT
	end
end

for name, b in pairs(tabButtons) do
	b.Activated:Connect(function()
		current, opened = name, nil
		rebuild()
	end)
end
open.Activated:Connect(function()
	window.Visible = not window.Visible
	if window.Visible then
		rebuild()
	end
end)
close.Activated:Connect(function()
	window.Visible = false
end)
local WATCHED = {}
for _, name in ipairs({ "FirstPurchaseDone", "FirstKeyPackDone", "Rebirths", "FarmCapped", "StarterBought", "PassDoubleMoney", "PassDoubleBag", "PassPlacementSlot",
	"PassFarmSlots", "PassVIP", "PassAutoMine", "DefenseLevel", "PacksDay", "RaceWins", "RaceLosses",
	"SkyWins", "SkyLosses", "HideWins", "HideLosses", "LimitedBoughtWeek" }) do
	WATCHED[name] = true
end
-- (2026-10-01) Today_<pack> too, so a pack's "오늘 n/한도" and "내일 또!" follow each purchase at once
player.AttributeChanged:Connect(function(name)
	if window.Visible and (WATCHED[name] or string.sub(name, 1, 6) == "Today_") then
		rebuild()
	end
end)
Windows.register(window)
RunService.Heartbeat:Connect(FrameMeter.wrap("Robux", function() -- out of the way of another open window (it sits on the top row)
	open.Visible = window.Visible or not Windows.anyOpen()
end))

-- ---------------------------------------------------------------------------
-- The starter pack's pop-up, thanks, the crown over a luck giver, VIP in chat
-- ---------------------------------------------------------------------------

local offerCard = Instance.new("Frame")
offerCard.AnchorPoint = Vector2.new(0.5, 0.5)
offerCard.Position = UDim2.fromScale(0.5, 0.5)
offerCard.Size = OFFER_SIZE
offerCard.BackgroundColor3 = COLOR_BG
offerCard.Visible = false
offerCard.Parent = gui
corner(offerCard, 14)

-- the lively background: sliding colors, turning light rays, twinkling sparkles rising, a shine sweeping
-- across, a shimmering edge; all under the words (ZIndex 0) and only moving while the pop-up is up
local glow = Instance.new("CanvasGroup") -- (clips the rays to the rounded card)
glow.Name = "Glow"
glow.Size = UDim2.fromScale(1, 1)
glow.BackgroundColor3 = Color3.new(1, 1, 1)
glow.ZIndex = 0
glow.Active = false
glow.ClipsDescendants = true
glow.Parent = offerCard
corner(glow, 14)
local colors = Instance.new("UIGradient")
colors.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, OFFER_COLORS[1]),
	ColorSequenceKeypoint.new(0.55, OFFER_COLORS[2]), ColorSequenceKeypoint.new(1, OFFER_COLORS[3]) })
colors.Parent = glow
local rays = Instance.new("Frame")
rays.AnchorPoint = Vector2.new(0.5, 0.5)
rays.Position = UDim2.fromScale(0.5, 0.45)
rays.Size = UDim2.fromOffset(700, 700)
rays.BackgroundTransparency = 1
rays.Parent = glow
for k = 1, OFFER_RAYS do
	local ray = Instance.new("Frame")
	ray.AnchorPoint = Vector2.new(0.5, 0.5)
	ray.Position = UDim2.fromScale(0.5, 0.5)
	ray.Size = UDim2.new(0, 26, 1, 0)
	ray.Rotation = k * 180 / OFFER_RAYS
	ray.BackgroundColor3 = OFFER_RAY_COLOR
	ray.BackgroundTransparency = OFFER_RAY_TRANSPARENCY
	ray.BorderSizePixel = 0
	local fade = Instance.new("UIGradient") -- bright in the middle, gone at the ends
	fade.Rotation = 90
	fade.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0),
		NumberSequenceKeypoint.new(1, 1) })
	fade.Parent = ray
	ray.Parent = rays
end
local veil = Instance.new("Frame")
veil.Size = UDim2.fromScale(1, 1)
veil.BackgroundColor3 = Color3.new(0, 0, 0)
veil.BackgroundTransparency = 1 - OFFER_SHADE
veil.BorderSizePixel = 0
veil.Parent = glow
local shine = Instance.new("Frame")
shine.AnchorPoint = Vector2.new(0.5, 0.5)
shine.Size = UDim2.new(0, 60, 2, 0)
shine.Rotation = 20
shine.BackgroundColor3 = Color3.new(1, 1, 1)
shine.BackgroundTransparency = 0.75
shine.BorderSizePixel = 0
shine.Position = UDim2.fromScale(-0.3, 0.5)
shine.Parent = glow
local sparkles = {}
local lastSparkle = nil
for k = 1, OFFER_SPARKLES do
	local star = Instance.new("TextLabel")
	star.BackgroundTransparency = 1
	star.Text = k % 3 == 0 and "★" or "✦"
	star.TextColor3 = OFFER_SPARKLE_COLORS[k % #OFFER_SPARKLE_COLORS + 1]
	star.Font = Enum.Font.GothamBold
	star.TextSize = math.random(10, 20)
	star.Size = UDim2.fromOffset(20, 20)
	star.AnchorPoint = Vector2.new(0.5, 0.5)
	star.Parent = glow
	table.insert(sparkles, { label = star, x = math.random(), y = math.random(), speed = 0.04 + math.random() * 0.08,
		phase = math.random() * math.pi * 2 })
end
require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("DinoPortrait")).backdrop(offerCard, "TRex", 0.55)
Windows.fit(offerCard, { Cover = "Big" })
local stroke = Instance.new("UIStroke")
stroke.Color = Color3.new(1, 1, 1)
stroke.Thickness = 3
stroke.Parent = offerCard
local edge = Instance.new("UIGradient") -- the edge shimmers round in gold, pink and blue
edge.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, OFFER_EDGE_COLORS[1]),
	ColorSequenceKeypoint.new(0.33, OFFER_EDGE_COLORS[2]), ColorSequenceKeypoint.new(0.66, OFFER_EDGE_COLORS[3]),
	ColorSequenceKeypoint.new(1, OFFER_EDGE_COLORS[1]) })
edge.Parent = stroke
RunService.RenderStepped:Connect(FrameMeter.wrap("Robux", function()
	if not offerCard.Visible then
		return
	end
	local t = os.clock()
	rays.Rotation = (t * OFFER_RAY_TURN) % 360
	colors.Rotation = (t * OFFER_GRADIENT_TURN) % 360
	edge.Rotation = (t * OFFER_GRADIENT_TURN * 3) % 360
	local sweep = (t % OFFER_SHINE_EVERY) / OFFER_SHINE_EVERY -- across in the first 40%, then a rest
	shine.Position = UDim2.fromScale(-0.3 + math.min(sweep / 0.4, 1) * 1.6, 0.5)
	local dt = t - (lastSparkle or t)
	lastSparkle = t
	for _, sp in ipairs(sparkles) do
		sp.y -= sp.speed * dt
		if sp.y < -0.05 then
			sp.y, sp.x = 1.05, math.random()
		end
		sp.label.Position = UDim2.fromScale(sp.x + math.sin(t * 1.3 + sp.phase) * 0.02, sp.y)
		sp.label.TextTransparency = 0.25 + 0.6 * (0.5 + 0.5 * math.sin(t * 4 + sp.phase))
		sp.label.Rotation = (t * 60 + sp.phase * 50) % 360
	end
end))
local offerTitle = label(offerCard, "🎁 스타터 팩! (한 번만)", UDim2.new(1, -20, 0, 30), UDim2.fromOffset(10, 10), 20)
offerTitle.TextColor3 = COLOR_GOLD
offerTitle.TextStrokeTransparency = 0.3 -- (readable over the colors)
local titlePulse = Instance.new("UIScale") -- the title beats gently
titlePulse.Parent = offerTitle
RunService.RenderStepped:Connect(FrameMeter.wrap("Robux", function()
	if offerCard.Visible then
		titlePulse.Scale = 1 + 0.05 * math.sin(os.clock() * 5)
	end
end))
local offerText = label(offerCard, "", UDim2.new(1, -24, 0, 80), UDim2.fromOffset(12, 46), 14)
offerText.TextStrokeTransparency = 0.4
local offerBuy = button(offerCard, "", COLOR_BUY, UDim2.fromOffset(124, 40), UDim2.new(0.5, -152, 1, -52))
offerBuy.TextSize = 16
-- (2026-10-04, "첫구매도 오늘 하루 안 보기 넣어줘도 되겠다") not again today (saved: Net request HideAdToday)
local offerToday = button(offerCard, "🙈 오늘 하루 안 보기", COLOR_OWNED, UDim2.fromOffset(104, 40), UDim2.new(0.5, -22, 1, -52))
offerToday.TextSize = 11
offerToday.TextWrapped = true
local offerLater = button(offerCard, "나중에", COLOR_OWNED, UDim2.fromOffset(62, 40), UDim2.new(0.5, 90, 1, -52))
offerLater.TextSize = 14
Windows.register(offerCard)

local offered = nil -- the item the pop-up offers
Prices.onChanged(function()
	if window.Visible then
		rebuild()
	end
	if offerCard.Visible and offered then
		offerBuy.Text = string.format("💎 %d로 사기", price(offered))
	end
end)
local OFFER_WAIT = 180 -- (2026-10-04) seconds the joining offer waits for the join's own windows (attendance, news) to close
Net.onPush("Offer", function(key)
	if key ~= "StarterPack" or player:GetAttribute("StarterBought") or restricted() then
		return
	end
	-- (2026-10-04: it comes on joining now) after the windows the join opens, not over them
	-- (2026-10-04) and after the 🎉 event's pop-up (EventAd: local attribute EventAdUp while it waits or shows)
	while player:GetAttribute("CocoIntro") or player:GetAttribute("FirstFight") or (player:GetAttribute("DefenseLevel") or 1) < 2
		or player:GetAttribute("FreshStart") do
		task.wait(0.5)
	end
	local waited = os.clock()
	while (Windows.anyOpen() or player:GetAttribute("EventAdUp")) and os.clock() - waited < OFFER_WAIT do
		task.wait(0.5)
	end
	task.wait(1) -- (a breath between the two pop-ups)
	if Windows.anyOpen() or player:GetAttribute("EventAdUp") or player:GetAttribute("StarterBought")
		or player:GetAttribute("TutorialStep") then
		return
	end
	local item = catalog("Featured")[1]
	if not item or item.key ~= "StarterPack" then
		return
	end
	offerText.Text = item.text() .. "\n\n💪 지금 사면 훨씬 빨리 강해져요!"
	offerBuy.Text = string.format("💎 %d로 사기", price(item))
	offered = item
	offerCard.Visible = true
	Net.request("OfferSeen") -- (2026-10-04: marked seen; every join until bought, unless "🙈 오늘 하루 안 보기")
end)
offerBuy.Activated:Connect(function()
	offerCard.Visible = false
	if offered then
		buy(offered)
	end
end)
offerLater.Activated:Connect(function()
	offerCard.Visible = false
end)
offerToday.Activated:Connect(function()
	offerCard.Visible = false
	Net.request("HideAdToday", "Offer")
end)

Net.onPush("PurchaseDone", function()
	Sfx.play("GachaBig")
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if root then
		Fx.confetti(root.Position + Vector3.new(0, 3, 0))
	end
	if window.Visible then
		rebuild()
	end
end)

-- (2026-10-02, "서버 행운 사도 왕관도 어딨는지 모르겠고, 열쇠제단 중앙 공중에 프로필이랑 닉네임, 버프 내용 합해서 왕관
-- 씌워서 띄워주든가 … 어디서든 보이게, 감사합니다 이런 것도") while a server luck boost runs (ReplicatedStorage ServerLuck,
-- ServerLuckUntil, ServerLuckBy, ServerLuckByUserId: Monetization), a panel high over the key altar's middle: a crown,
-- the buyer's avatar and name, the boost and its time left, and a thank-you. Grows nearer, never too small far off.
-- (It was a small "👑🍀 행운 선물" over the buyer's head, lost up close and on top of the other head tags.)
local SKY_HEIGHT = 48 -- studs over the altar
local SKY_SIZE = UDim2.fromScale(32, 17)
local SKY_DISTANCE = 2000
local COLOR_SKY_BG = Color3.fromRGB(25, 28, 40)
local COLOR_LUCK = Color3.fromRGB(110, 230, 120)
local SKY_THANKS = { "고마워요! 🙏", "모두 행운 받아요! 🍀", "최고예요! 💖" }
local skyPanel, skyFor = nil, nil
local function skyPart()
	local map = Workspace:FindFirstChild("Map")
	local zone = map and map:FindFirstChild("KeyZone")
	local altar = zone and zone:FindFirstChild("Zone_KeyAltar", true)
	local center = altar and (altar:IsA("Model") and altar:GetPivot().Position or altar.Position) or Vector3.zero
	local anchor = Instance.new("Part")
	anchor.Name = "ServerLuckSky"
	anchor.Anchored, anchor.CanCollide, anchor.CanQuery, anchor.CanTouch = true, false, false, false
	anchor.Transparency = 1
	anchor.Size = Vector3.one
	anchor.Position = center + Vector3.new(0, SKY_HEIGHT, 0)
	anchor.Parent = Workspace
	return anchor
end
local function buildSky(userId, name)
	local anchor = skyPart()
	local gui = Instance.new("BillboardGui")
	gui.Size = SKY_SIZE
	gui.MaxDistance = SKY_DISTANCE
	gui.LightInfluence = 0
	gui.Adornee = anchor
	gui.Parent = anchor
	local panel = Instance.new("Frame")
	panel.Size = UDim2.fromScale(1, 0.78)
	panel.Position = UDim2.fromScale(0, 0.22)
	panel.BackgroundColor3 = COLOR_SKY_BG
	panel.BackgroundTransparency = 0.15
	panel.Parent = gui
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.12, 0)
	round.Parent = panel
	local edge = Instance.new("UIStroke")
	edge.Color = COLOR_GOLD
	edge.Thickness = 3
	edge.Parent = panel
	local crown = label(gui, "👑", UDim2.fromScale(0.3, 0.32), UDim2.fromScale(0.03, 0), 30)
	crown.TextScaled = true
	local face = Instance.new("ImageLabel")
	face.BackgroundColor3 = COLOR_GOLD
	face.Size = UDim2.fromScale(0.3, 0.6)
	face.Position = UDim2.fromScale(0.03, 0.3)
	face.Parent = gui
	local faceRound = Instance.new("UICorner")
	faceRound.CornerRadius = UDim.new(0.5, 0)
	faceRound.Parent = face
	local square = Instance.new("UIAspectRatioConstraint")
	square.Parent = face
	task.spawn(function()
		local ok, image = pcall(Players.GetUserThumbnailAsync, Players, userId, Enum.ThumbnailType.HeadShot,
			Enum.ThumbnailSize.Size150x150)
		if ok and face.Parent then
			face.Image = image
		end
	end)
	local function line(text, y, h, color)
		local l = label(panel, text, UDim2.new(0.62, 0, h, 0), UDim2.new(0.35, 0, y, 0), 20)
		l.TextScaled = true
		l.TextXAlignment = Enum.TextXAlignment.Left
		l.TextColor3 = color
		l.TextStrokeTransparency = 0.3
		return l
	end
	local nameLine = line(name, 0.06, 0.3, COLOR_GOLD)
	local luckLine = line("", 0.38, 0.26, COLOR_LUCK)
	local thanksLine = line(SKY_THANKS[1], 0.68, 0.24, Color3.new(1, 1, 1))
	return { anchor = anchor, luck = luckLine, thanks = thanksLine, name = nameLine, since = os.clock() }
end
RunService.Heartbeat:Connect(FrameMeter.wrap("Robux", function()
	local now = Workspace:GetServerTimeNow()
	local untilAt = ReplicatedStorage:GetAttribute("ServerLuckUntil") or 0
	local userId = ReplicatedStorage:GetAttribute("ServerLuckByUserId")
	local on = untilAt > now and userId ~= nil
	if on and skyFor ~= userId then
		if skyPanel then
			skyPanel.anchor:Destroy()
		end
		skyPanel = buildSky(userId, ReplicatedStorage:GetAttribute("ServerLuckBy") or "?")
		skyFor = userId
	elseif not on and skyPanel then
		skyPanel.anchor:Destroy()
		skyPanel, skyFor = nil, nil
	end
	if skyPanel then
		local left = math.max(0, math.floor(untilAt - now))
		Lang.set(skyPanel.luck, string.format("🍀 서버 모두 뽑기 행운 ×%g · %d:%02d", ReplicatedStorage:GetAttribute("ServerLuck") or 1,
			left // 60, left % 60))
		Lang.set(skyPanel.thanks, SKY_THANKS[math.floor((os.clock() - skyPanel.since) / 4) % #SKY_THANKS + 1])
	end
end))


-- [⭐VIP] before a VIP's name in the chat (TextChatService)
pcall(function()
	TextChatService.OnIncomingMessage = function(message)
		local props = Instance.new("TextChatMessageProperties")
		local source = message.TextSource and Players:GetPlayerByUserId(message.TextSource.UserId)
		if source and source:GetAttribute("VIP") then
			props.PrefixText = VIP_TAG .. message.PrefixText
		end
		return props
	end
end)
