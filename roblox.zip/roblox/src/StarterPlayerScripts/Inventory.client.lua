--[[
Inventory: everything the player owns in one window (display only; Net ask GetInventory).

- "🎒 인벤토리" button on the right edge, under 기지로 (Hud).
- Tab "🦖 공룡": every dino, strongest first, each with its picture (drawn only for the rows in view).
  Tapping one shows its details on the right: a big picture, species, rarity, size, mutation, theme,
  attribute, level and experience, attack, attack speed and reach, its farm effect (what it gives on the
  farm, Formulas.farmBuff) and where it is (placed, on the farm, the dino I ride). Every row also shows
  its farm effect at its right (2026-10-01, "in the inventory too, which farm effect each dino has").
- Tab "🎒 아이템": a tile with a picture for each thing: money, every key grade (DinoPortrait.key),
  the minerals in the bag by grade and size (the mineral model in the grade's color), the pickaxe,
  the bag, the slap toy, move speed, defense level, rebirths and the collection.
- Tab "👋 스킨": the slap skins (Config.Slap.Skins): the plain one (the slap level's own look) first, then
  every skin with its picture; owned ones are tapped to wear (Net request EquipSkin, Skins service),
  the one worn says so, the others are grey with how to get them (theme completed, collection count,
  shop).
  Pictures come from ReplicatedStorage (DinoModels, KeyModels, SlapModels, ItemModels); an emoji
  stands in without the model.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBold
local BUTTON_SIZE = UDim2.fromOffset(68, 36)
local BUTTON_POS = UDim2.new(1, -12 - 68 - 10, 0, 86) -- left of 보기 설정 (ViewSettings; was under 기지로); its middle
local COLOR_BUTTON = Color3.fromRGB(150, 110, 60)
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_PANEL = Color3.fromRGB(35, 39, 54)
local COLOR_ROW = Color3.fromRGB(45, 50, 68)
local COLOR_PICKED = Color3.fromRGB(70, 90, 130)
local COLOR_TAB_ON = Color3.fromRGB(90, 110, 170)
local COLOR_TAB_OFF = Color3.fromRGB(60, 64, 80)
local COLOR_EXP = Color3.fromRGB(120, 200, 255)
local COLOR_CLOSE = Color3.fromRGB(235, 70, 80)
local COLOR_SOFT = Color3.fromRGB(190, 190, 200)
local RARITY_COLORS = {
	Common = Color3.fromRGB(170, 170, 170), Uncommon = Color3.fromRGB(90, 200, 90), Rare = Color3.fromRGB(70, 140, 255),
	Epic = Color3.fromRGB(170, 90, 230), Legendary = Color3.fromRGB(255, 150, 40), Mythic = Color3.fromRGB(240, 60, 60),
	Transcendent = Color3.fromRGB(255, 100, 200), Rainbow = Color3.fromRGB(120, 230, 255), Golden = Color3.fromRGB(255, 210, 60),
	Onyx = Color3.fromRGB(120, 60, 170), Celestial = Color3.fromRGB(255, 255, 255), Secret = Color3.fromRGB(255, 240, 150),
	Cosmic = Color3.fromRGB(110, 90, 240), Primeval = Color3.fromRGB(255, 160, 40), Divine = Color3.fromRGB(255, 245, 200),
	Special = Color3.fromRGB(190, 140, 255), -- (2026-10-04) ⭐ 특별, given only
}
local WINDOW_SIZE = UDim2.fromOffset(600, 430)
local LIST_WIDTH = 300
local CARD = UDim2.fromOffset(90, 120)
local CARD_GAP = 6
local CARD_PORTRAIT = 64
local CARD_TEXT = 12
local CARD_LINE = 14
local DETAIL_PORTRAIT = 120
local TILE = UDim2.fromOffset(105, 140)
local TILE_PICTURE = 64
local COLOR_WORN = Color3.fromRGB(120, 230, 140) -- the skin I wear
local COLOR_LOCKED = Color3.fromRGB(120, 120, 130) -- a skin I don't have: its picture in grey
local COLOR_LOCKED_TILE = Color3.fromRGB(42, 42, 48)
local COLOR_LOCKED_TEXT = Color3.fromRGB(140, 140, 148)
local LOCKED_FADE = 0.4
local LOCK_BADGE = 22
local BUFF_LOOKS = { -- [farm buff] = { emoji, color } (as over the farm dinos, Farm service)
	UnitPower = { "💪", Color3.fromRGB(255, 120, 100) },
	Money = { "💰", Color3.fromRGB(255, 215, 80) },
	MonsterSlow = { "🐢", Color3.fromRGB(120, 200, 255) },
	RareChance = { "🍀", Color3.fromRGB(130, 235, 130) },
	Mining = { "⛏️", Color3.fromRGB(220, 180, 120) },
}

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.Text = text
	l.Size = size
	l.Position = pos
	l.TextWrapped = true
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 14
	b.TextColor3 = Color3.new(1, 1, 1)
	b.TextWrapped = true
	b.Text = text
	b.BackgroundColor3 = color
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 10)
	return b
end

-- a picture of a model from a ReplicatedStorage folder, or the emoji without it
local function picture(folderName, modelName, size, emoji, recolor)
	local folder = ReplicatedStorage:FindFirstChild(folderName)
	local source = folder and folder:FindFirstChild(modelName)
	if not source then
		local l = Instance.new("TextLabel")
		l.Size = size
		l.BackgroundTransparency = 1
		l.TextScaled = true
		l.Font = FONT
		l.Text = emoji
		return l
	end
	if recolor then
		source = source:Clone()
		recolor(source)
	end
	return DinoPortrait.ofModel(source, size)
end

local gui = Instance.new("ScreenGui")
gui.Name = "Inventory"
gui.ResetOnSpawn = false
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.Parent = player:WaitForChild("PlayerGui")

local open = button(gui, "🎒 인벤토리", COLOR_BUTTON, BUTTON_SIZE, BUTTON_POS)
require(Shared:WaitForChild("SideButtons")).register(open) -- folds with the right column
open.AnchorPoint = Vector2.new(1, 0.5)
open.TextSize = 13

local window = Instance.new("Frame")
window.AnchorPoint = Vector2.new(0.5, 0.5)
window.Position = UDim2.fromScale(0.5, 0.5)
window.Size = WINDOW_SIZE
window.BackgroundColor3 = COLOR_BG
window.Visible = false
window.Parent = gui
corner(window, 14)
Windows.fit(window)
local title = label(window, "🎒 인벤토리", UDim2.new(0, 200, 0, 34), UDim2.fromOffset(14, 6), 20)
title.TextXAlignment = Enum.TextXAlignment.Left
local close = button(window, "X", COLOR_CLOSE, UDim2.fromOffset(34, 34), UDim2.new(1, -42, 0, 8))
local dinoTab = button(window, "🦖 공룡", COLOR_TAB_ON, UDim2.fromOffset(120, 32), UDim2.fromOffset(200, 8))
local itemTab = button(window, "🎒 아이템", COLOR_TAB_OFF, UDim2.fromOffset(120, 32), UDim2.fromOffset(326, 8))
local skinTab = button(window, "👋 스킨", COLOR_TAB_OFF, UDim2.fromOffset(100, 32), UDim2.fromOffset(452, 8))

-- ---------------------------------------------------------------------------
-- Dinos: the list on the left, the chosen one's details on the right
-- ---------------------------------------------------------------------------

local dinoPage = Instance.new("Frame")
dinoPage.BackgroundTransparency = 1
dinoPage.Position = UDim2.fromOffset(10, 48)
dinoPage.Size = UDim2.new(1, -20, 1, -58)
dinoPage.Parent = window

local list = Instance.new("ScrollingFrame")
list.Size = UDim2.new(0, LIST_WIDTH, 1, 0)
list.BackgroundTransparency = 1
list.ScrollBarThickness = 6
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = dinoPage
local cards = Instance.new("UIGridLayout")
cards.CellSize = CARD
cards.CellPadding = UDim2.fromOffset(CARD_GAP, CARD_GAP)
cards.SortOrder = Enum.SortOrder.LayoutOrder
cards.Parent = list
local empty = label(dinoPage, "🦖 아직 공룡이 없어요. 뽑기로 모아 보세요!", UDim2.new(0, LIST_WIDTH, 0, 60), UDim2.new(), 14)
empty.Visible = false

local detail = Instance.new("Frame")
detail.Position = UDim2.fromOffset(LIST_WIDTH + 10, 0)
detail.Size = UDim2.new(1, -LIST_WIDTH - 10, 1, 0)
detail.BackgroundColor3 = COLOR_PANEL
detail.Parent = dinoPage
corner(detail, 10)

local itemPage = Instance.new("ScrollingFrame")
itemPage.Position = UDim2.fromOffset(10, 48)
itemPage.Size = UDim2.new(1, -20, 1, -58)
itemPage.BackgroundTransparency = 1
itemPage.ScrollBarThickness = 6
itemPage.AutomaticCanvasSize = Enum.AutomaticSize.Y
itemPage.CanvasSize = UDim2.new()
itemPage.Visible = false
itemPage.Parent = window
local grid = Instance.new("UIGridLayout")
grid.CellSize = TILE
grid.CellPadding = UDim2.fromOffset(8, 8)
grid.SortOrder = Enum.SortOrder.LayoutOrder
grid.Parent = itemPage

local skinPage = itemPage:Clone() -- the same grid of tiles
skinPage.Parent = window

local data = nil -- the last GetInventory answer
local pickedId = nil

local function clear(frame)
	for _, c in ipairs(frame:GetChildren()) do
		if c:IsA("GuiObject") then
			c:Destroy()
		end
	end
end

-- a dino's farm effect: its emoji, "돈 획득량 +0.40%" and its color
local function farmEffect(unit)
	local kind, amount = Formulas.farmBuff(unit)
	local look = BUFF_LOOKS[kind] or { "🌾", COLOR_SOFT }
	local percent = amount * 100
	local text = string.format(percent < 1 and "+%.2f%%" or percent < 10 and "+%.1f%%" or "+%.0f%%", percent)
	return look[1], (Config.Farm.BuffNames[kind] or kind) .. " " .. text, look[2], text
end

local function whereIs(unit)
	local places = {}
	if data.Placed[unit.Id] then
		table.insert(places, "🛡️ 디펜스에 배치됨")
	end
	if data.Farm[unit.Id] then
		table.insert(places, "🌾 농장에 등록됨")
	end
	if data.Mount == unit.Species then
		table.insert(places, "🦖 타는 공룡 (이 종)")
	end
	return #places > 0 and table.concat(places, " · ") or "📦 보관 중"
end

local function showDetail(unit)
	clear(detail)
	if not unit then
		label(detail, "👈 왼쪽에서 공룡을 눌러 자세히 보세요", UDim2.new(1, -20, 1, 0), UDim2.fromOffset(10, 0), 14).TextColor3 =
			COLOR_SOFT
		return
	end
	local species = Formulas.species(unit.Species)
	local stats = Formulas.unitStats(unit)
	local level = Formulas.unitLevel(unit)
	local need = Formulas.enhanceNeed(unit)
	local mutation = unit.Mutation and Formulas.mutation(unit.Mutation)
	local big = DinoPortrait.new(unit.Species, UDim2.fromOffset(DETAIL_PORTRAIT, DETAIL_PORTRAIT))
	DinoPortrait.border(big, unit.Rarity, 3)
	big.Position = UDim2.new(0.5, -DETAIL_PORTRAIT / 2, 0, 6)
	big.Parent = detail
	local name = label(detail, string.format("%s  Lv%d", species.Name, level), UDim2.new(1, -20, 0, 26),
		UDim2.fromOffset(10, DETAIL_PORTRAIT + 8), 18)
	name.TextColor3 = RARITY_COLORS[unit.Rarity] or Color3.new(1, 1, 1)
	local lines = {
		string.format("등급 %s · 크기 %s%s", Formulas.rarity(unit.Rarity).Name, Formulas.dinoSize(unit.Size).Name,
			mutation and (" · 변이 " .. mutation.Name) or ""),
		string.format("%s%s · %s%s", Formulas.theme(stats.Theme).Icon or "", Formulas.theme(stats.Theme).Name,
			Config.Attributes[stats.Attribute].Icon, Config.Attributes[stats.Attribute].Name),
		string.format("⚔️ %s · %.1f초마다 · 사거리 %.0f", Formulas.shortNumber(stats.Damage + 0.5), stats.Interval, stats.Reach),
		whereIs(unit),
	}
	if stats.Sniper then
		table.insert(lines, 3, "🎯 저격: 멀리 있는 한 마리만 세게")
	end
	local emojiText, buffText, buffColor = farmEffect(unit)
	local buff = label(detail, string.format("🌾 농장 효과: %s %s%s", emojiText, buffText,
		data.Farm[unit.Id] and "" or " (농장에 등록하면)"), UDim2.new(1, -20, 0, 34), UDim2.new(0, 10, 1, -68), 13)
	buff.TextWrapped = true
	buff.TextColor3 = buffColor
	local info = label(detail, table.concat(lines, "\n"), UDim2.new(1, -20, 0, 90), UDim2.fromOffset(10, DETAIL_PORTRAIT + 36), 13)
	info.TextYAlignment = Enum.TextYAlignment.Top
	info.TextColor3 = COLOR_SOFT
	local expBack = Instance.new("Frame")
	expBack.Position = UDim2.new(0, 10, 1, -30)
	expBack.Size = UDim2.new(1, -20, 0, 18)
	expBack.BackgroundColor3 = COLOR_ROW
	expBack.Parent = detail
	corner(expBack, 8)
	local fill = Instance.new("Frame")
	fill.BackgroundColor3 = COLOR_EXP
	fill.Size = UDim2.fromScale(need and math.clamp((unit.Exp or 0) / need, 0, 1) or 1, 1)
	fill.Parent = expBack
	corner(fill, 8)
	label(expBack, need and string.format("경험치 %s / %s", Formulas.shortNumber(unit.Exp or 0), Formulas.shortNumber(need)) or "최고 레벨", UDim2.fromScale(1, 1),
		UDim2.new(), 12).ZIndex = 2
end

-- dino pictures only for the rows in view (a player can have hundreds of dinos)
local function fillPortraits()
	local top = list.AbsolutePosition.Y - CARD.Y.Offset
	local bottom = list.AbsolutePosition.Y + list.AbsoluteSize.Y + CARD.Y.Offset
	for _, card in ipairs(list:GetChildren()) do
		local species = card:IsA("GuiObject") and card:GetAttribute("Species")
		if species and not card:FindFirstChild("Portrait") and card.AbsolutePosition.Y < bottom
			and card.AbsolutePosition.Y + card.AbsoluteSize.Y > top then
			local p = DinoPortrait.new(species, UDim2.fromOffset(CARD_PORTRAIT, CARD_PORTRAIT))
			p.Name = "Portrait"
			p.Position = UDim2.new(0.5, -CARD_PORTRAIT / 2, 0, 6)
			p.Parent = card
		end
	end
end
list:GetPropertyChangedSignal("CanvasPosition"):Connect(fillPortraits)

local function buildDinos()
	clear(list)
	local units = table.clone(data.Units)
	table.sort(units, function(a, b)
		return Formulas.unitStrength(a) > Formulas.unitStrength(b)
	end)
	dinoTab.Text = string.format("🦖 공룡 %d", #units)
	local chosen = nil
	for i, u in ipairs(units) do
		local card = Instance.new("TextButton")
		card.LayoutOrder = i
		card.BackgroundColor3 = u.Id == pickedId and COLOR_PICKED or COLOR_ROW
		card.Text = ""
		card:SetAttribute("Species", u.Species)
		DinoPortrait.border(card, u.Rarity)
		card.Parent = list
		corner(card, 8)
		local textTop = CARD_PORTRAIT + 8
		local name = label(card, string.format("%s Lv%d", Formulas.unitName(u), Formulas.unitLevel(u)),
			UDim2.new(1, -6, 0, CARD_LINE), UDim2.fromOffset(3, textTop), CARD_TEXT)
		name.TextWrapped = false
		name.TextScaled = true
		name.TextColor3 = RARITY_COLORS[u.Rarity] or Color3.new(1, 1, 1)
		local kind = label(card, string.format("%s · %s", Formulas.rarity(u.Rarity).Name, Formulas.dinoSize(u.Size).Name),
			UDim2.new(1, -6, 0, CARD_LINE), UDim2.fromOffset(3, textTop + CARD_LINE), CARD_TEXT - 1)
		kind.TextWrapped = false
		kind.TextScaled = true
		kind.TextColor3 = COLOR_SOFT
		local emojiText, _, buffColor, percentText = farmEffect(u)
		local buff = label(card, "🌾 " .. emojiText .. " " .. percentText, UDim2.new(1, -6, 0, CARD_LINE),
			UDim2.fromOffset(3, textTop + CARD_LINE * 2), CARD_TEXT - 1)
		buff.TextWrapped = false
		buff.TextScaled = true
		buff.TextColor3 = buffColor
		local marks = (data.Placed[u.Id] and "🛡️" or "") .. (data.Farm[u.Id] and "🌾" or "")
		if marks ~= "" then
			local mark = label(card, marks, UDim2.fromOffset(CARD_LINE * 2 + 4, CARD_LINE + 4), UDim2.fromOffset(3, 3), CARD_TEXT)
			mark.TextXAlignment = Enum.TextXAlignment.Left
			mark.ZIndex = 3
		end
		card.Activated:Connect(function()
			pickedId = u.Id
			for _, other in ipairs(list:GetChildren()) do
				if other:IsA("TextButton") then
					other.BackgroundColor3 = COLOR_ROW
				end
			end
			card.BackgroundColor3 = COLOR_PICKED
			showDetail(u)
		end)
		if u.Id == pickedId then
			chosen = u
		end
	end
	empty.Visible = #units == 0
	showDetail(chosen or units[1])
	if not chosen and units[1] then
		pickedId = units[1].Id
		local first = list:FindFirstChildWhichIsA("TextButton")
		if first then
			first.BackgroundColor3 = COLOR_PICKED
		end
	end
	task.defer(fillPortraits)
end

-- ---------------------------------------------------------------------------
-- Items: one tile each
-- ---------------------------------------------------------------------------

local tileOrder = 0
local tileParent = itemPage -- the page the tiles go on (the items or the skins)
-- grade: a key grade or "Money" for its border (DinoPortrait.border); otherwise the border takes color
local function tile(pic, name, value, color, grade)
	tileOrder += 1
	local t = Instance.new("Frame")
	t.LayoutOrder = tileOrder
	t.BackgroundColor3 = COLOR_ROW
	t.Parent = tileParent
	corner(t, 10)
	if grade then
		DinoPortrait.border(t, grade)
	else
		local stroke = Instance.new("UIStroke")
		stroke.Name = "GradeBorder"
		stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		stroke.Thickness = 2
		stroke.Color = color or COLOR_SOFT
		stroke.Parent = t
	end
	pic.Size = UDim2.fromOffset(TILE_PICTURE, TILE_PICTURE)
	pic.Position = UDim2.new(0.5, -TILE_PICTURE / 2, 0, 4)
	pic.Parent = t
	local n = label(t, name, UDim2.new(1, -8, 0, 18), UDim2.new(0, 4, 0, TILE_PICTURE + 6), 13)
	n.TextScaled = true
	n.TextColor3 = color or Color3.new(1, 1, 1)
	local v = label(t, value, UDim2.new(1, -8, 0, 44), UDim2.new(0, 4, 0, TILE_PICTURE + 24), 12)
	v.TextYAlignment = Enum.TextYAlignment.Top
	v.TextColor3 = COLOR_SOFT
	return t, n, v
end

local function emoji(text)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.TextScaled = true
	l.Font = FONT
	l.Text = text
	return l
end

local function oreColor(grade)
	return function(model)
		local color = Color3.fromRGB(table.unpack(grade.Rgb))
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") and string.find(d.Name, "Crystal") then
				d.Color = color
			end
		end
	end
end

local liveTiles = {}

local function trainedNow(track, level)
	return player:GetAttribute("TrainReal_" .. track) or level
end

local function refreshLive()
	for _, update in ipairs(liveTiles) do
		update()
	end
end

local function buildItems()
	clear(itemPage)
	table.clear(liveTiles)
	tileParent, tileOrder = itemPage, 0
	local up = data.Upgrades
	tile(emoji("💰"), "돈", Formulas.shortNumber(data.Money) .. "원", Color3.fromRGB(255, 215, 90), "Money")
	for _, t in ipairs(Config.Keys.Types) do
		local count = t.Id == "Normal" and data.Keys or (data.SpecialKeys[t.Id] or 0)
		tile(DinoPortrait.key(t.Id, UDim2.new()), t.Name, count .. "개",
			t.Rgb and Color3.fromRGB(table.unpack(t.Rgb)) or Color3.fromRGB(255, 205, 60), t.Id)
	end
	-- minerals in the bag, the best grades first
	local bagCount = 0
	local special = Config.Minerals.Special
	local specialCount = 0
	for key, n in pairs(data.Carry) do
		local gradeId, sizeId = Formulas.splitCarryKey(key)
		if gradeId == special.Id and n > 0 then
			specialCount += n
			bagCount += n * Formulas.bagSlots(gradeId, sizeId)
		end
	end
	if specialCount > 0 then
		tile(picture("ItemModels", Formulas.size(special.Size).Model, UDim2.new(), "💰", oreColor(special)),
			special.Name, specialCount .. "개", Color3.fromRGB(table.unpack(special.Rgb)))
	end
	for gi = #Config.Minerals.Grades, 1, -1 do
		local grade = Config.Minerals.Grades[gi]
		for _, size in ipairs(Config.Minerals.Sizes) do
			local n = data.Carry[Formulas.carryKey(grade.Id, size.Id)] or 0
			if n > 0 then
				bagCount += n * Formulas.bagSlots(grade.Id)
				tile(picture("ItemModels", size.Model, UDim2.new(), "💎", oreColor(grade)),
					grade.Name .. " " .. size.Name, n .. "개", Color3.fromRGB(table.unpack(grade.Rgb)))
			end
		end
	end
	local tier = Config.Pickaxe.Tiers[up.PickaxeTier]
	local _, _, pickValue = tile(picture("ItemModels", "Pickaxe_T" .. up.PickaxeTier, UDim2.new(), "⛏️"), "⛏️ " .. tier.Name .. " 곡괭이", "")
	local bag0 = math.floor(trainedNow("Bag", up.Bag))
	local bagLook = Config.Bag.Looks[math.min(#Config.Bag.Looks, (bag0 - 1) // Config.Bag.LevelsPerLook + 1)]
	local _, bagName, bagValue = tile(picture("ItemModels", bagLook, UDim2.new(), "🎒"), "", "")
	local slap0 = math.floor(trainedNow("Slap", up.Slap))
	local slapLook = Config.Slap.Looks[math.min(#Config.Slap.Looks, (slap0 - 1) // Config.Slap.LevelsPerLook + 1)]
	local _, slapName, slapValue = tile(picture("SlapModels", slapLook, UDim2.new(), "👋"), "", "")
	local _, moveName, moveValue = tile(emoji("👟"), "", "")
	local function update()
		local power, speed = trainedNow("Power", up.PickaxePower), trainedNow("Speed", up.PickaxeSpeed)
		local bag, slap, move = trainedNow("Bag", up.Bag), trainedNow("Slap", up.Slap), trainedNow("MoveSpeed", up.MoveSpeed)
		pickValue.Text = string.format("파워 %.1f · 속도 %.2f", Formulas.pickaxePower(up.PickaxeTier, power),
			Formulas.pickaxeSpeed(up.PickaxeTier, speed))
		bagName.Text = string.format("🎒 가방 Lv %d", Formulas.trainShownOf("Bag", bag))
		bagValue.Text = string.format("광물 %d / %d개", bagCount, Formulas.bagCapacity(bag, false))
		slapName.Text = string.format("👋 손바닥 Lv %d", Formulas.trainShownOf("Slap", slap))
		slapValue.Text = string.format("날리기 %g", Formulas.slapKnockback(slap))
		moveName.Text = string.format("👟 이동속도 Lv %d", Formulas.trainShownOf("MoveSpeed", move))
		moveValue.Text = Formulas.trainValueText("MoveSpeed", move)
	end
	update()
	table.insert(liveTiles, update)
	tile(emoji("🛡️"), "디펜스", string.format("%s · 공룡 자리 %d", Formulas.levelText(data.DefenseLevel, data.Rebirths),
		player:GetAttribute("DefenseSlots") or 0))
	tile(emoji("🔄"), "환생", data.Rebirths .. "번")
	tile(emoji("📖"), "도감", data.Collected .. "종류 모음")
	itemTab.Text = "🎒 아이템"
end

-- ---------------------------------------------------------------------------
-- Skins: tap one I own to wear it
-- ---------------------------------------------------------------------------

local function grey(model)
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Color = COLOR_LOCKED
			d.Material = Enum.Material.SmoothPlastic
			if d:IsA("MeshPart") then
				pcall(function()
					d.TextureID = ""
				end)
			end
		elseif d:IsA("SurfaceAppearance") or d:IsA("Decal") then
			d:Destroy()
		end
	end
end

local function lockLook(t, pic)
	t.BackgroundColor3 = COLOR_LOCKED_TILE
	if pic:IsA("ViewportFrame") then
		pic.ImageTransparency = LOCKED_FADE
	elseif pic:IsA("TextLabel") then
		pic.TextTransparency = LOCKED_FADE
	end
	local lock = Instance.new("TextLabel")
	lock.BackgroundTransparency = 1
	lock.Size = UDim2.fromOffset(LOCK_BADGE, LOCK_BADGE)
	lock.Position = UDim2.new(1, -LOCK_BADGE - 4, 0, 4)
	lock.TextScaled = true
	lock.Font = FONT
	lock.Text = "🔒"
	lock.ZIndex = 4
	lock.Parent = t
end

local function tapToWear(t, id)
	local b = Instance.new("TextButton")
	b.BackgroundTransparency = 1
	b.Text = ""
	b.Size = UDim2.fromScale(1, 1)
	b.ZIndex = 5
	b.Parent = t
	b.Activated:Connect(function()
		Net.request("EquipSkin", id)
	end)
end

local function buildSkins()
	clear(skinPage)
	tileParent, tileOrder = skinPage, 0
	local worn = data.SlapSkin or ""
	local slapLook = Config.Slap.Looks[math.min(#Config.Slap.Looks, (data.Upgrades.Slap - 1) // Config.Slap.LevelsPerLook + 1)]
	local plain = tile(picture("SlapModels", slapLook, UDim2.new(), "👋"), "기본 손바닥",
		worn == "" and "✅ 끼는 중" or "눌러서 끼기", worn == "" and COLOR_WORN or nil)
	tapToWear(plain, "")
	for _, skin in ipairs(Config.Slap.Skins) do
		local owned = data.Skins[skin.Id] == true
		-- (2026-10-02) its grade: the border and the name's tag (its effects in CombatFx)
		local pic = picture("SlapModels", skin.Model, UDim2.new(), "👋", not owned and grey or nil)
		local t = tile(pic,
			skin.Grade and string.format("%s (%s)", skin.Name, Formulas.rarity(skin.Grade).Name) or skin.Name,
			not owned and ("🔒 " .. Formulas.skinHowTo(skin)) or worn == skin.Id and "✅ 끼는 중" or "눌러서 끼기",
			worn == skin.Id and COLOR_WORN or owned and Color3.new(1, 1, 1) or COLOR_LOCKED_TEXT, owned and skin.Grade or nil)
		if owned then
			tapToWear(t, skin.Id)
		else
			lockLook(t, pic)
		end
	end
end

-- ---------------------------------------------------------------------------
-- Opening, tabs
-- ---------------------------------------------------------------------------

local function showTab(which) -- "dinos" | "items" | "skins"
	dinoPage.Visible = which == "dinos"
	itemPage.Visible = which == "items"
	skinPage.Visible = which == "skins"
	dinoTab.BackgroundColor3 = which == "dinos" and COLOR_TAB_ON or COLOR_TAB_OFF
	itemTab.BackgroundColor3 = which == "items" and COLOR_TAB_ON or COLOR_TAB_OFF
	skinTab.BackgroundColor3 = which == "skins" and COLOR_TAB_ON or COLOR_TAB_OFF
end

local function reload()
	local answer = Net.ask("GetInventory")
	if not answer then
		return
	end
	data = answer
	buildDinos()
	buildItems()
	buildSkins()
end

open.Activated:Connect(function()
	window.Visible = not window.Visible
	if window.Visible then
		reload()
	end
end)
close.Activated:Connect(function()
	window.Visible = false
end)
dinoTab.Activated:Connect(function()
	showTab("dinos")
	task.defer(fillPortraits)
end)
itemTab.Activated:Connect(function()
	showTab("items")
end)
skinTab.Activated:Connect(function()
	showTab("skins")
end)
player:GetAttributeChangedSignal("OpenInventory"):Connect(function()
	local which = player:GetAttribute("OpenInventory")
	if not which then
		return
	end
	player:SetAttribute("OpenInventory", nil)
	window.Visible = true
	reload()
	showTab(which)
	if which == "dinos" then
		task.defer(fillPortraits)
	end
end)
player:GetAttributeChangedSignal("SlapSkin"):Connect(function() -- a skin put on (Skins service)
	if window.Visible then
		reload()
	end
end)
for _, track in ipairs({ "Power", "Speed", "Bag", "Slap", "MoveSpeed" }) do
	player:GetAttributeChangedSignal("TrainReal_" .. track):Connect(function()
		if window.Visible then
			refreshLive()
		end
	end)
end
player:GetAttributeChangedSignal("UnitsVersion"):Connect(function() -- my dinos changed (Defense service)
	if window.Visible then
		reload()
	end
end)
Windows.register(window)
