--[[
TrafficLights: the race track's traffic lights (Workspace.Map.TrafficLights, roblox/MapBuilder.lua;
2026-10-02, "신호등 모델링해서 … 길가에 등이 트랙 진행방향과 마주보도록"), lit on this screen only.

- Every light runs the same cycle by server time (all screens alike): green, yellow, red (CYCLE).
- The one facing the start boxes (attribute Start) follows my own road race on my screen: red, then
  yellow for the last second of the countdown, green on GO and for GO_GREEN seconds after.
- A lit lamp is Neon in its color; an unlit one dark. Only lamps that change are touched.
]]

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local Workspace = game:GetService("Workspace")

local player = Players.LocalPlayer

-- display only
local CYCLE = { { "Green", 8 }, { "Yellow", 2 }, { "Red", 6 } } -- seconds each
local LIT = { Red = Color3.fromRGB(255, 60, 50), Yellow = Color3.fromRGB(255, 200, 40), Green = Color3.fromRGB(60, 230, 90) }
local DARK = { Red = Color3.fromRGB(70, 25, 25), Yellow = Color3.fromRGB(70, 60, 20), Green = Color3.fromRGB(20, 60, 30) }
local YELLOW_LAST = 1 -- seconds of the countdown left when the start light turns yellow
local GO_GREEN = 4 -- seconds the start light stays green after GO (then back to the cycle)
local CHECK_EVERY = 0.2

local cycleLength = 0
for _, step in ipairs(CYCLE) do
	cycleLength += step[2]
end

local function cycleColor(t)
	local at = t % cycleLength
	for _, step in ipairs(CYCLE) do
		if at < step[2] then
			return step[1]
		end
		at -= step[2]
	end
	return CYCLE[1][1]
end

local goAt = nil -- os.clock() when my road race went GO (the start light's green)
player:GetAttributeChangedSignal("Racing"):Connect(function()
	if player:GetAttribute("Racing") == "Go" then
		goAt = os.clock()
	end
end)

-- my road race's color for the start light, or nil (none of mine on)
local function startColor()
	if player:GetAttribute("RaceKind") == "Sky" then
		return nil
	end
	local state = player:GetAttribute("Racing")
	if state == "Countdown" then
		local left = (player:GetAttribute("RaceUntil") or 0) - Workspace:GetServerTimeNow()
		return left > YELLOW_LAST and "Red" or "Yellow"
	elseif state == "Go" and goAt and os.clock() - goAt < GO_GREEN then
		return "Green"
	end
	return nil
end

local shown = setmetatable({}, { __mode = "k" }) -- [model] = the color lit now

local function light(model, color)
	if shown[model] == color then
		return
	end
	shown[model] = color
	for name, lit in pairs(LIT) do
		local lamp = model:FindFirstChild("Lamp" .. name)
		if lamp then
			local on = name == color
			lamp.Color = on and lit or DARK[name]
			lamp.Material = on and Enum.Material.Neon or Enum.Material.SmoothPlastic
		end
	end
end

local since = 0
RunService.Heartbeat:Connect(FrameMeter.wrap("TrafficLights", function(dt)
	since += dt
	if since < CHECK_EVERY then
		return
	end
	since = 0
	local map = Workspace:FindFirstChild("Map")
	local folder = map and map:FindFirstChild("TrafficLights")
	if not folder then
		return
	end
	local normal = cycleColor(Workspace:GetServerTimeNow())
	local mine = startColor()
	for _, model in ipairs(folder:GetChildren()) do
		light(model, model:GetAttribute("Start") and mine or normal)
	end
end))
