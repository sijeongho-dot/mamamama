--[[
LampLights (2026-10-04, "렉이 특히 밤에 더 걸리는거 같군"): the street lamps and arena spotlights (StreetLamps service,
lights named LampLight, attribute Lit) and the crystal fence glows (FenceLook, CrystalGlow) shine on this screen only
within NEAR studs of the camera. A full server lit over a hundred lights at night and a phone drew every one it could
see; one farther than this barely shows (a lamp reaches 32 studs). Display only: the server says which are lit.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local FrameMeter = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("FrameMeter"))
local WorldWatch = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("WorldWatch"))

-- display only
local NEAR = 160 -- studs from the camera
local CHECK_EVERY = 0.5 -- seconds for one look at every light (a slice of them each frame)
local NAMES = { LampLight = true, CrystalGlow = true }

local lights = {} -- the lights watched, a slice looked at each frame
local cursor = 0

local function watch(d)
	if d:IsA("Light") and NAMES[d.Name] then
		table.insert(lights, d)
	end
end

local function where(light)
	local p = light.Parent
	return p and p:IsA("BasePart") and p.Position or nil
end

task.spawn(function()
	local map = Workspace:WaitForChild("Map")
	WorldWatch.listen({ "Light" }, function(d)
		if d:IsDescendantOf(map) then
			watch(d)
		end
	end)
end)

RunService.Heartbeat:Connect(FrameMeter.wrap("LampLights", function(dt)
	local n = #lights
	local camera = Workspace.CurrentCamera
	if n == 0 or not camera then
		return
	end
	local eye = camera.CFrame.Position
	for _ = 1, math.min(n, math.ceil(n * math.min(dt, CHECK_EVERY) / CHECK_EVERY)) do
		cursor += 1
		if cursor > #lights then
			cursor = 1
		end
		local light = lights[cursor]
		local at = light and light.Parent and where(light)
		if not at then -- (gone, or streamed out: dropped; it is watched again when it comes back)
			lights[cursor] = lights[#lights]
			lights[#lights] = nil
			cursor -= 1
		else
			local want = light:GetAttribute("Lit") ~= false and (at - eye).Magnitude <= NEAR and light.Parent.Transparency < 1
			if light.Name == "LampLight" then
				want = want and light:GetAttribute("Lit") == true
			end
			if light.Enabled ~= want then
				light.Enabled = want
			end
		end
	end
end))
