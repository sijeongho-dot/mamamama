--[[
GuideBoards (client): the "📖 자세히 보기" window of the boards beside every base's defense sign (DefenseGuide service:
prompts with the attribute Kind "DefenseGuide" / "AttributeGuide"). (2026-10-04, "공룡 속성도 표나 그림으로 그려서 알기
편하게 바꿔 글로 짜라락 써놓지 말고. 디펜스 레벨 간판도", "자세하게 알았으면 좋겠다 싶은건 그냥 가까이 가서 눌러서 보게
하면 되잖아") the boards show pictures; the whole story is here, a row a thing, an emoji in front of each:
- DefenseGuide: what a won promotion pays (keys, the milestone keys), the levels new species open, what
  rebirths open, what grows with the level, the rebirth at the top;
- AttributeGuide: each attribute and what it does (Formulas.attributeText), that rarity and size make it stronger,
  the bosses' weaknesses.
Display only (from Config and Formulas). The prompt again closes it.
]]

local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Windows = require(Shared:WaitForChild("Windows"))
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))

local player = Players.LocalPlayer

-- display only
local WINDOW_SIZE = UDim2.fromOffset(420, 300)
local FONT = Enum.Font.GothamBold
local COLOR_BG = Color3.fromRGB(30, 36, 52)
local COLOR_ROW = Color3.fromRGB(46, 56, 78)
local COLOR_TITLE = Color3.fromRGB(255, 220, 90)
local COLOR_HEAD = Color3.fromRGB(150, 210, 255)
local COLOR_TEXT = Color3.new(1, 1, 1)
local TITLE_HEIGHT = 34
local ROW_TEXT = 14
local HEAD_TEXT = 15
local PAD = 8
local KEY_ICON = 30 -- px: a key's picture in front of its row

local gui = Instance.new("ScreenGui")
gui.Name = "GuideBoards"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local window = Instance.new("Frame")
window.AnchorPoint = Vector2.new(0.5, 0.5)
window.Position = UDim2.fromScale(0.5, 0.5)
window.Size = WINDOW_SIZE
window.BackgroundColor3 = COLOR_BG
window.Visible = false
window.Parent = gui
local round = Instance.new("UICorner")
round.CornerRadius = UDim.new(0, 14)
round.Parent = window

local title = Instance.new("TextLabel")
title.BackgroundTransparency = 1
title.Font = Enum.Font.GothamBlack
title.TextScaled = true
title.TextColor3 = COLOR_TITLE
title.Position = UDim2.fromOffset(PAD, 4)
title.Size = UDim2.new(1, -PAD * 2 - 40, 0, TITLE_HEIGHT - 6)
title.Parent = window

local list = Instance.new("ScrollingFrame")
list.BackgroundTransparency = 1
list.BorderSizePixel = 0
list.Position = UDim2.fromOffset(PAD, TITLE_HEIGHT)
list.Size = UDim2.new(1, -PAD * 2, 1, -TITLE_HEIGHT - PAD)
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.ScrollBarThickness = 6
list.Parent = window
local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 4)
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = list

Windows.fit(window)
Windows.register(window)

-- a row: text on a rounded strip (a head: no strip, its own color)
local function row(order, text, head, keyGrade)
	local l = Instance.new("TextLabel")
	l.LayoutOrder = order
	l.BackgroundColor3 = COLOR_ROW
	l.BackgroundTransparency = head and 1 or 0
	l.Font = head and Enum.Font.GothamBlack or FONT
	l.TextSize = head and HEAD_TEXT or ROW_TEXT
	l.TextColor3 = head and COLOR_HEAD or COLOR_TEXT
	l.TextWrapped = true
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.Size = UDim2.new(1, -8, 0, 0)
	l.AutomaticSize = Enum.AutomaticSize.Y
	l.Text = text
	local p = Instance.new("UIPadding")
	p.PaddingLeft, p.PaddingRight = UDim.new(0, 8), UDim.new(0, 8)
	p.PaddingTop, p.PaddingBottom = UDim.new(0, 4), UDim.new(0, 4)
	p.Parent = l
	if keyGrade then -- (2026-10-04, "은열쇠를 박아두라고. 열쇠도 열쇠 모델링을 넣고") the key's own picture in front
		p.PaddingLeft = UDim.new(0, KEY_ICON + 12)
		local key = DinoPortrait.key(keyGrade, UDim2.fromOffset(KEY_ICON, KEY_ICON))
		key.Position = UDim2.new(0, -KEY_ICON - 6, 0.5, -KEY_ICON / 2)
		key.Parent = l
		local tall = Instance.new("UISizeConstraint")
		tall.MinSize = Vector2.new(0, KEY_ICON + 8)
		tall.Parent = l
	end
	if not head then
		local c = Instance.new("UICorner")
		c.CornerRadius = UDim.new(0, 8)
		c.Parent = l
	end
	l.Parent = list
end

local function defenseRows()
	local promo = Config.Defense.Promotion
	local rows = {}
	local function add(text, head, keyGrade)
		table.insert(rows, { text, head, keyGrade })
	end
	add("👑 보스 웨이브 깨면", true)
	add(string.format("열쇠 %d개! 레벨이 높을수록 더 많이", promo.KeysBase), nil, "Normal")
	for _, m in ipairs(promo.Milestones) do
		for _, t in ipairs(Config.Keys.Types) do
			if t.Id == m.Grade then
				add(string.format("🎁 %d레벨마다 %s", m.Every, t.Name), nil, t.Id)
			end
		end
	end
	add("🦖 새 공룡이 나와요", true)
	local levels, byAwakening, lastAwakening = {}, {}, 0
	for _, s in ipairs(Config.Species) do
		if s.UnlockRebirths then
			byAwakening[s.UnlockRebirths] = (byAwakening[s.UnlockRebirths] or 0) + 1
			lastAwakening = math.max(lastAwakening, s.UnlockRebirths)
		elseif s.UnlockLevel > 1 and not table.find(levels, s.UnlockLevel) then
			table.insert(levels, s.UnlockLevel)
		end
	end
	table.sort(levels)
	local words = {}
	for _, level in ipairs(levels) do
		table.insert(words, tostring(level))
	end
	add(string.format("🔓 LV %s%s에서 새 공룡!", table.concat(words, " · "), ""))
	local from = 1
	for n = 1, lastAwakening do
		if n == lastAwakening or (byAwakening[n + 1] or 0) ~= (byAwakening[n] or 0) then
			add(string.format("환생 %d~%d번마다 %d종", from, n, byAwakening[n] or 0))
			from = n + 1
		end
	end
	add("✨ 환생하면 더 좋은 등급이 나와요", true)
	for n = 1, 2 do
		local names = Formulas.raritiesOpenedBy(n)
		if #names > 0 then
			add(string.format("%s: %s", Formulas.rarityCondition({ UnlockRebirths = n }), table.concat(names, "·")))
		end
	end
	add("📈 레벨이 오를수록 더 많이 받아요", true)
	add("💰 화석 잡은 돈 · 🔑 열쇠 값 · 🎁 보물상자")
	add(string.format("🔄 LV %d가 되면 환생! → 더 센 단계 + 환생 선물", Config.Rebirth.FirstTierLevels), true)
	return rows
end

local function attributeRows()
	local rows = {}
	local B = Config.Defense.Boss
	for _, id in ipairs(B.AttributeOrder) do
		local a = Config.Attributes[id]
		table.insert(rows, { string.format("%s %s: %s", a.Icon, a.Name, Formulas.attributeText(id)) })
	end
	table.insert(rows, { "✨ 등급이 높고 덩치가 클수록 효과가 더 세요", true })
	table.insert(rows, { string.format("👑 보스는 약점 속성에 크게 아파요! 같은 속성엔 거의 안 아파요 · %d레벨마다 바뀌어요",
		B.AttributeChangeEveryLevels) })
	local pairsText = {}
	for _, id in ipairs(B.AttributeOrder) do
		table.insert(pairsText, Config.Attributes[id].Icon .. "←" .. Config.Attributes[B.Weakness[id]].Icon)
	end
	table.insert(rows, { string.format("🎯 보스 ← 이 공룡이 세요: %s", table.concat(pairsText, "  ")) })
	return rows
end

local shownKind = nil
local function open(kind)
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("TextLabel") then
			c:Destroy()
		end
	end
	local rows
	if kind == "DefenseGuide" then
		title.Text = "🛡️ 디펜스 레벨 보상"
		rows = defenseRows()
	else
		title.Text = "🧪 공룡 속성"
		rows = attributeRows()
	end
	for i, r in ipairs(rows) do
		row(i, r[1], r[2], r[3])
	end
	list.CanvasPosition = Vector2.zero
	shownKind = kind
	window.Visible = true
end

ProximityPromptService.PromptTriggered:Connect(function(prompt)
	local kind = prompt:GetAttribute("Kind")
	if kind ~= "DefenseGuide" and kind ~= "AttributeGuide" then
		return
	end
	if window.Visible and shownKind == kind then -- (E again closes it)
		window.Visible = false
		return
	end
	open(kind)
end)
