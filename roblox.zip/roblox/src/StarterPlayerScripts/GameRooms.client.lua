--[[
GameRooms: the 🎮 놀이방 window (2026-10-04, "레이스도 방 열수 있게 하자 술래잡기처럼. 지금 술래잡기 방여는 버튼에 다 합쳐
넣고 탭 나눠 안에서. 버튼 라벨 바꾸고"): the 🙈 hide-and-seek rooms and the 🏁 race rooms in one window, a tab each (the
hide-and-seek window was in StarterPlayerScripts/HideSeek). The servers decide everything (HideSeek, Race).

- Opened by the 🎮 놀이방 button in the bottom left corner (over the 🔔 bell, Bell.client): while a room waits for players it
  says so and glows ("🙈 방 열림! 2/8", "🏁 방 열림! 2/6"), in a room "🙈 내 방 2/8"; hidden in a game, a race, the tutorial.
  Or by the hide-and-seek board's prompt by the key altar (Kind "HideSeek": its tab; walking away closes it when not in
  a room). It opens on my room's tab, else a waiting room's, else the last one shown.
- A tab, not in a room: every room (its number, 🏆 랭킹전 or 🎈 일반전, a race's 🦖 길 or 🦅 하늘, the host, how many,
  waiting or playing) with 참가 (Net request HideSeekJoin(id) / RaceRoomJoin(id)), and ➕ 방 만들기: the choice of 🏆 랭킹전
  (the records kept, this week's ranking: keys next week) or 🎈 일반전 (nothing kept), for a race 🦖 길 or 🦅 하늘 too
  (Net request HideSeekCreate(ranked) / RaceRoomCreate(kind, ranked)). In a room: its members (👑 the host; ✅ ready,
  ⏳ not yet; 😈 the seeker, 🙈 hiding, 🏁 racing), ✅ 준비 / 준비 취소 and 🚪 나가기 (playing: 🏳️ 기권; Net requests
  HideSeekReady, HideSeekLeave / RaceRoomReady, RaceRoomLeave). My record and this week's ranked wins at the bottom.
- 🏆 순위: this week's 🏆 랭킹전 of all servers (ReplicatedStorage HideWeekTop / RaceWeekTop, Leaderboards) with the time left
  and the rewards (Config.Ranked), then all-time: the hide-and-seek wins (HideSeekTop) or the best race times (RaceTopRoad
  / RaceTopSky), and the players here.
- Net ask GetHideSeek / GetRaceRooms when it opens; Net push HideSeekRooms / RaceRooms keep it current, the result
  pushes (HideSeekResult, RaceResult) this week's ranked wins.
- (2026-10-04, the night boss's ①②③, "밤보스는 123 다 되나") a third tab, 🧟 보스: what slapping the night's boss down
  gives (Config.Zombies.Boss), my 🦴 bones toward each zombie dino (a picture and a bar each), my hunts and the hunt
  titles (Net ask GetBossHunt; again when my BossHunts attribute changes). Its 🏆 순위: this week's hunts of all
  servers (BossWeekTop) with the same rewards, and the players here (their BossHunts).
]]

local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local FrameMeter = require(Shared:WaitForChild("FrameMeter")) -- (the screen's per-frame time, PerfCheck)
local Formulas = require(Shared:WaitForChild("Formulas"))
local Unlock = require(Shared:WaitForChild("Unlock"))
local Lang = require(Shared:WaitForChild("Lang")) -- (Lang.set: a text set every frame, only when it changes)
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(Shared:WaitForChild("Windows"))
local Coach = require(Shared:WaitForChild("Coach"))

local player = Players.LocalPlayer
local MAX_PLAYERS = { Hide = Config.HideSeek.MaxPlayers, Race = Config.Race.Rooms.MaxPlayers }
local MIN_PLAYERS = { Hide = Config.HideSeek.MinPlayers, Race = Config.Race.Rooms.MinPlayers }

-- display only
local FONT = Enum.Font.GothamBold
local WINDOW_SIZE = UDim2.fromOffset(340, 300)
local TAB_SIZE = UDim2.fromOffset(92, 30) -- (2026-10-04: three tabs now, was 112; the window's X is at its right)
local TAB_TEXT = 14 -- (at most: a longer word shrinks)
local TAB_GAP = 6
local ROW_HEIGHT = 40
local RANK_ROW = 30
local CHOICE_HEIGHT = 46 -- a ➕ 방 만들기 choice's row
local CHOICE_LABEL = 84 -- the race's 🦖 / 🦅 at the start of its choice row
local TRIAL_ROW = 56
local TRIAL_KINDS = { { "Road", "🦖 길 · 탈 공룡" }, { "Sky", "🦅 하늘 · 나는 공룡" } }
local TRIAL_BEST = { Road = "RaceTrialRoad" }
local MEDALS = { "🥇", "🥈", "🥉" }
local COLOR_SOLO = Color3.fromRGB(125, 95, 215)
local COLOR_SOLO_ROW = Color3.fromRGB(55, 46, 84)
local COLOR_SOLO_TEXT = Color3.fromRGB(205, 185, 255)
local SOLO_GAP = 12
local SOLO_BUTTON = UDim2.fromOffset(96, 36)
local SOLO_BUTTON_TEXT = 13
local SOLO_STROKE = 2
local COLOR_BG = Color3.fromRGB(25, 28, 40)
local COLOR_ROW = Color3.fromRGB(45, 50, 68)
local COLOR_GO = Color3.fromRGB(80, 170, 90)
local COLOR_BLUE = Color3.fromRGB(70, 130, 200)
local COLOR_QUIT = Color3.fromRGB(200, 80, 80)
local COLOR_SOFT = Color3.fromRGB(190, 190, 200)
local COLOR_KEYS = Color3.fromRGB(255, 215, 110)
local COLOR_RANK = Color3.fromRGB(200, 150, 40)
local COLOR_ME = Color3.fromRGB(255, 225, 120) -- my own line in a ranking
local COLOR_RANKED = Color3.fromRGB(215, 150, 40) -- 🏆 랭킹전's buttons
local COLOR_NORMAL = Color3.fromRGB(80, 140, 200) -- 🎈 일반전's
local COLOR_SEEKER = Color3.fromRGB(255, 120, 110)
local COLOR_HIDER = Color3.fromRGB(130, 220, 140)
local TAB_COLORS = { Hide = Color3.fromRGB(80, 160, 105), Race = Color3.fromRGB(215, 115, 55), Boss = Color3.fromRGB(125, 95, 175) }
local TAB_NAMES = { Hide = "🙈 숨바꼭질", Race = "🏁 레이스", Boss = "🧟 보스" }
local BONE_ROW = 46 -- a 🦴 row: the zombie dino's picture, its name, the bones and a bar
local BONE_BAR = 8
local COLOR_BONE = Color3.fromRGB(235, 225, 200)
local COLOR_BAR_BACK = Color3.fromRGB(30, 33, 46)
local TAB_OFF = Color3.fromRGB(55, 60, 80)
local SIDE_AT = UDim2.new(0, 140, 1, -62) -- 나가기 beside 준비 (playing: in its place)
local CORNER_SIZE = UDim2.fromOffset(72, 58) -- (2026-10-05, "놀이방 버튼 가로 줄이고 세로 늘리고 더 눈에 띄게 해": was 112 × 30)
local CORNER_POS = UDim2.new(0, 68, 1, -30)
local CORNER_COLOR = Color3.fromRGB(150, 70, 230) -- (2026-10-05: was a dull 70, 75, 100)
local CORNER_TEXT_MAX = 17
local CORNER_EDGE = Color3.fromRGB(255, 255, 255)
local CORNER_GLOW_EDGE = Color3.fromRGB(255, 240, 150)
local CORNER_EDGE_IDLE = 0.35 -- the white edge's transparency when nothing glows
local CORNER_OPEN_COLOR = Color3.fromRGB(80, 170, 90)
local CORNER_BLINK = 0.6 -- seconds a glow goes up (and as long down)
-- (2026-10-04, "알림만으로 어느 버튼을 눌러야 할지 모르는 사람을 위해 버튼을 좀더 화려하게 반짝이게") a room opened or a 📣 모집
-- came (Net push RoomCallFx): for CALL_SECONDS the button flashes gold fast, pulses bigger, and "👈 여기!" bobs beside it
local CALL_SECONDS = 8
local CALL_BLINK = 0.22 -- seconds a flash goes up
local CALL_COLORS = { Color3.fromRGB(255, 150, 40), Color3.fromRGB(255, 225, 80) }
local CALL_POP = 0.22 -- the button's size goes up to 1 + this
local CALL_STROKE = { 2, 5 } -- the border's thickness, low and high
local POINTER_SIZE = UDim2.fromOffset(80, 30)
local POINTER_GAP = 8 -- pixels right of the button
local POINTER_BOB = 6 -- pixels it swings toward the button
local POINTER_COLOR = Color3.fromRGB(255, 225, 80)
local CLOSE_SLACK = 8 -- studs past the board prompt's reach that close the window (when not in a room)
local COLOR_RECRUIT = Color3.fromRGB(230, 140, 50) -- 📣 모집
local RECRUIT_HEIGHT = 34

local gui = Instance.new("ScreenGui")
gui.Name = "GameRooms"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextSize = textSize
	l.TextWrapped = true
	l.Text = text
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 13
	b.TextColor3 = Color3.new(1, 1, 1)
	b.BackgroundColor3 = color
	b.Text = text
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 8)
	return b
end

local function nameOf(userId)
	local p = Players:GetPlayerByUserId(userId)
	return p and p.DisplayName or "?"
end

local function decode(name)
	local ok, value = pcall(HttpService.JSONDecode, HttpService, ReplicatedStorage:GetAttribute(name) or "[]")
	return ok and type(value) == "table" and value or {}
end

local function stakeText(grade)
	for _, g in ipairs(Config.Ranked.Stake.Grades) do
		if g.Id == grade then
			return string.format("%s %d개", Formulas.keyType(g.Id).Name, g.Keys)
		end
	end
	return ""
end

local function modeText(ranked, stake)
	return ranked and "🏆 랭킹전 · 🔑 " .. stakeText(stake) or "🎈 일반전"
end

local function keysHeld(grade)
	if grade ~= "Normal" then
		return player:GetAttribute("Keys" .. grade) or 0
	end
	return player:GetAttribute("Keys") or 0
end

local function kindText(kind)
	return kind == "Sky" and "🦅 하늘" or "🦖 길"
end

-- ---------------------------------------------------------------------------
-- The window
-- ---------------------------------------------------------------------------

local tab = "Hide" -- the tab shown: "Hide", "Race" or "Boss"
local rooms = { Hide = {}, Race = {} } -- the servers' lists (Net push HideSeekRooms / RaceRooms)
local weekWins = { Hide = 0, Race = 0 } -- my counted ranked wins this week
local ranking = false -- 🏆 순위 shown in place of the rooms
local choosing = false -- ➕ 방 만들기: the choice of the room's mode (and a race's kind)
local stakePick = Config.Ranked.Stake.Grades[1].Id
local hunt = { Hunts = 0, Week = 0, Bones = {} } -- (2026-10-04) my night boss hunts (Net ask GetBossHunt)

local window = Instance.new("Frame")
window.AnchorPoint = Vector2.new(0.5, 0.5)
window.Position = UDim2.fromScale(0.5, 0.5)
window.Size = WINDOW_SIZE
window.BackgroundColor3 = COLOR_BG
window.Visible = false
window.Parent = gui
corner(window, 14)
Windows.fit(window)
local hint = label(window, "", UDim2.new(1, -28, 0, 18), UDim2.fromOffset(14, 40), 12)
hint.TextXAlignment = Enum.TextXAlignment.Left
hint.TextColor3 = COLOR_SOFT
hint.TextTruncate = Enum.TextTruncate.AtEnd
local list = Instance.new("ScrollingFrame")
list.Size = UDim2.new(1, -20, 1, -128)
list.Position = UDim2.fromOffset(10, 62)
list.BackgroundTransparency = 1
list.BorderSizePixel = 0
list.ScrollBarThickness = 4
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.CanvasSize = UDim2.new()
list.Parent = window
local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 6)
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = list
local empty = label(window, "🚪 아직 열린 방이 없어요. 방을 만들어 친구를 불러요!", UDim2.new(1, -40, 0, 40),
	UDim2.fromOffset(20, 84), 13)
empty.TextColor3 = COLOR_SOFT
local mainButton = button(window, "", COLOR_GO, UDim2.fromOffset(124, 36), UDim2.new(0, 10, 1, -62))
mainButton.TextSize = 14
local sideButton = button(window, "🚪 나가기", COLOR_QUIT, UDim2.fromOffset(100, 36), SIDE_AT)
sideButton.TextSize = 14
local rankButton = button(window, "🏆 순위", COLOR_RANK, UDim2.fromOffset(88, 36), UDim2.new(1, -98, 1, -62))
rankButton.TextSize = 14
local recordLine = label(window, "", UDim2.new(1, -28, 0, 18), UDim2.new(0, 14, 1, -22), 12)
recordLine.TextXAlignment = Enum.TextXAlignment.Left
recordLine.TextColor3 = COLOR_SOFT
recordLine.TextTruncate = Enum.TextTruncate.AtEnd

local redraw -- (below)

local fetchHunt -- (below)

local tabs = {}
for i, id in ipairs({ "Hide", "Race", "Boss" }) do
	local b = button(window, TAB_NAMES[id], TAB_OFF, TAB_SIZE, UDim2.fromOffset(10 + (i - 1) * (TAB_SIZE.X.Offset + TAB_GAP), 6))
	b.Name = "Tab" .. id
	b.TextScaled = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = TAB_TEXT
	most.Parent = b
	b.Activated:Connect(function()
		if tab ~= id then
			tab, ranking, choosing = id, false, false
			if id == "Boss" then
				task.spawn(function()
					fetchHunt()
					if window.Visible and tab == "Boss" then
						redraw()
					end
				end)
			end
			redraw()
		end
	end)
	tabs[id] = b
	Coach.mark(b, id == "Race" and "RaceTab" or nil)
end

local function myRoom(id)
	for _, room in ipairs(rooms[id] or {}) do
		if table.find(room.Members, player.UserId) then
			return room
		end
	end
	return nil
end

-- a room waiting for players with room for me (and its game), the hide-and-seek ones first
local function waitingRoom()
	for _, id in ipairs({ "Hide", "Race" }) do
		for _, room in ipairs(rooms[id]) do
			if room.Phase == "Waiting" and #room.Members < MAX_PLAYERS[id] then
				return room, id
			end
		end
	end
	return nil, nil
end

local order = 0 -- the next row's LayoutOrder in the list

local function clearList()
	for _, child in ipairs(list:GetChildren()) do
		if child:IsA("Frame") then
			child:Destroy()
		end
	end
	order = 0
end

local function row(height)
	order += 1
	local r = Instance.new("Frame")
	r.Size = UDim2.new(1, -6, 0, height or ROW_HEIGHT)
	r.BackgroundColor3 = COLOR_ROW
	r.LayoutOrder = order
	r.Parent = list
	corner(r, 8)
	return r
end

-- a line of text in the list (held by a Frame: clearList takes Frames)
local function textRow(text, color, height, textSize)
	order += 1
	local holder = Instance.new("Frame")
	holder.Size = UDim2.new(1, -6, 0, height or 22)
	holder.BackgroundTransparency = 1
	holder.LayoutOrder = order
	holder.Parent = list
	local l = label(holder, text, UDim2.fromScale(1, 1), UDim2.new(), textSize or 13)
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.TextColor3 = color or Color3.new(1, 1, 1)
	return l
end

local function recordText()
	if tab == "Boss" then
		return string.format("🧟 보스 사냥 모두 %d마리 · 이번 주 %d마리", hunt.Hunts, hunt.Week)
	end
	if tab == "Hide" then
		return string.format("🙈 내 기록 %d승 %d패 · 이번 주 🏆 %d승", player:GetAttribute("HideWins") or 0,
			player:GetAttribute("HideLosses") or 0, weekWins.Hide)
	end
	return string.format("🏁 %d승 · 🦅 %d승 · 이번 주 🏆 %d승", player:GetAttribute("RaceWins") or 0,
		player:GetAttribute("SkyWins") or 0, weekWins.Race)
end

-- 🏆 순위: this week's ranked wins of all servers and the rewards, then all-time, then the players here
local function drawRanking()
	hint.Text = tab == "Hide" and "🏆 숨바꼭질 순위" or tab == "Boss" and "🏆 보스 사냥 순위" or "🏆 레이스 순위"
	local function heading(text)
		textRow(text, COLOR_RANK, 24, 14)
	end
	local function line(rank, name, value, me)
		local r = row(RANK_ROW)
		local who = label(r, string.format("%s %s", MEDALS[rank] or (rank .. "."), name), UDim2.new(1, -90, 1, 0),
			UDim2.fromOffset(10, 0), 14)
		who.TextXAlignment = Enum.TextXAlignment.Left
		who.TextTruncate = Enum.TextTruncate.AtEnd
		local v = label(r, value, UDim2.fromOffset(76, RANK_ROW), UDim2.new(1, -82, 0, 0), 14)
		v.TextXAlignment = Enum.TextXAlignment.Right
		if me then
			who.TextColor3, v.TextColor3 = COLOR_ME, COLOR_ME
		end
	end
	local function isMe(name)
		return name == player.DisplayName or name == player.Name
	end
	local ends = ReplicatedStorage:GetAttribute("ChallengeWeekEnds") -- (the same week as ♾️ 무한 도전's)
	local left = ends and math.max(0, ends - Workspace:GetServerTimeNow()) or 0
	local boss = tab == "Boss"
	heading(string.format(boss and "📅 이번 주 보스 사냥 · ⏳ %d일 %d시간" or "📅 이번 주 랭킹전 · ⏳ %d일 %d시간", left // 86400,
		(left % 86400) // 3600))
	local week = decode(tab .. "WeekTop")
	if #week == 0 then
		textRow("아직 기록이 없어요", COLOR_SOFT)
	end
	for i, entry in ipairs(week) do
		line(i, tostring(entry.Name), string.format(boss and "%d마리" or "%d승", entry.Wins or 0), isMe(entry.Name))
	end
	heading("🎁 다음 주에 순위대로 선물")
	local from = 1
	for _, r in ipairs(Config.Ranked.RankRewards) do
		local place = from == r.Top and string.format("%d위", r.Top) or string.format("%d~%d위", from, r.Top)
		textRow(string.format("%s: %s", place, Formulas.rewardShortText(r.Reward)), nil, 20)
		from = r.Top + 1
	end
	textRow(string.format(boss and "🙌 그 밖에 1마리 이상: %s" or "🙌 그 밖에 1승 이상: %s",
		Formulas.rewardShortText(Config.Ranked.PlayReward)), nil, 20)
	if not boss then
		textRow(string.format("⚖️ 같은 상대에게는 한 주에 %d승까지만 순위에 들어가요", Config.Ranked.SameRivalWins), COLOR_SOFT, 34, 12)
		local st = Config.Ranked.Stake
		local grades = {}
		for _, g in ipairs(st.Grades) do
			table.insert(grades, stakeText(g.Id))
		end
		textRow(string.format("🔑 방장이 고른 열쇠를 걸어요 (%s) · 1등이 가장 많이, 꼴찌는 0",
			table.concat(grades, " · ")), COLOR_RANKED, 34, 12)
		textRow(string.format("🎉 하루 %d판까지 받은 열쇠 +%d%%", st.BonusGamesPerDay, math.floor(st.WinBonus * 100 + 0.5)),
			COLOR_RANKED, 20, 12)
	end
	if boss then
		-- (no all-time list: the titles say it, over the heads)
	elseif tab == "Hide" then
		heading("🌍 전체 서버")
		local top = decode("HideSeekTop")
		if #top == 0 then
			textRow("아직 기록이 없어요", COLOR_SOFT)
		end
		for i, entry in ipairs(top) do
			line(i, tostring(entry.Name), string.format("%d승", entry.Wins or 0), isMe(entry.Name))
		end
	else
		for _, kind in ipairs({ "Road", "Sky" }) do
			heading(kind == "Sky" and "🦅 하늘 레이스 최고 기록" or "🏁 길 레이스 최고 기록")
			local top = decode("RaceTop" .. kind)
			if #top == 0 then
				textRow("아직 기록이 없어요", COLOR_SOFT)
			end
			for i, entry in ipairs(top) do
				line(i, tostring(entry.Name), string.format("%.1f초", entry.Seconds or 0), isMe(entry.Name))
			end
		end
	end
	heading("🏠 이 서버")
	local here = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p:GetAttribute("Developer") then -- (2026-10-04: the developers are never ranked)
			continue
		end
		local wins = boss and (p:GetAttribute("BossHunts") or 0) or tab == "Hide" and (p:GetAttribute("HideWins") or 0)
			or (p:GetAttribute("RaceWins") or 0) + (p:GetAttribute("SkyWins") or 0)
		table.insert(here, { p = p, wins = wins })
	end
	table.sort(here, function(a, b)
		return a.wins > b.wins
	end)
	for i, h in ipairs(here) do
		line(i, h.p.DisplayName, string.format(boss and "%d마리" or "%d승", h.wins), h.p == player)
	end
end

-- 🧟 보스 (2026-10-04): what slapping the night's boss down gives, my 🦴 bones toward each zombie dino, my hunts and titles
local function drawBoss()
	local bc = Config.Zombies.Boss
	hint.Text = "🌙 밤마다 배틀필드에 보스가 나와요 · 같이 때려요!"
	local function heading(text)
		textRow(text, COLOR_RANK, 24, 14)
	end
	heading("🎁 쓰러뜨리면 때린 사람 모두")
	textRow(Formulas.rewardShortText(bc.HitterReward, player:GetAttribute("DefenseLevel") or 1), nil, 20)
	textRow(string.format("🦴 그 보스의 뼈 %d개 · %d개 모으면 좀비 공룡!", bc.Bones, bc.BonesForDino), nil, 20)
	textRow(string.format("🏆 가장 많이 때린 사람: %s · 🦴 %d개 더", Formulas.rewardShortText(bc.MvpReward), bc.BonesMvp),
		nil, 34)
	heading("🦴 내 뼈 조각")
	for _, kind in ipairs(bc.Kinds) do
		local dino = Formulas.boneDino(kind.Id)
		if dino then
			local n = math.clamp(tonumber(hunt.Bones[kind.Id]) or 0, 0, bc.BonesForDino)
			local r = row(BONE_ROW)
			local picture = DinoPortrait.new(dino.Id, UDim2.fromOffset(BONE_ROW - 6, BONE_ROW - 6))
			picture.Position = UDim2.fromOffset(4, 3)
			picture.Parent = r
			local name = label(r, string.format("%s %s", kind.Icon, dino.Name), UDim2.new(1, -(BONE_ROW + 78), 0, 22),
				UDim2.fromOffset(BONE_ROW + 4, 3), 14)
			name.TextXAlignment = Enum.TextXAlignment.Left
			name.TextTruncate = Enum.TextTruncate.AtEnd
			local count = label(r, string.format("🦴 %d/%d", n, bc.BonesForDino), UDim2.fromOffset(70, 22),
				UDim2.new(1, -76, 0, 3), 14)
			count.TextXAlignment = Enum.TextXAlignment.Right
			count.TextColor3 = COLOR_BONE
			local bar = Instance.new("Frame")
			bar.BackgroundColor3 = COLOR_BAR_BACK
			bar.BorderSizePixel = 0
			bar.Size = UDim2.new(1, -(BONE_ROW + 12), 0, BONE_BAR)
			bar.Position = UDim2.new(0, BONE_ROW + 4, 1, -(BONE_BAR + 8))
			bar.Parent = r
			corner(bar, BONE_BAR // 2)
			local fill = Instance.new("Frame")
			fill.BackgroundColor3 = COLOR_BONE
			fill.BorderSizePixel = 0
			fill.Size = UDim2.fromScale(n / bc.BonesForDino, 1)
			fill.Parent = bar
			corner(fill, BONE_BAR // 2)
		end
	end
	heading("🧟 내 사냥")
	textRow(string.format("🧟 모두 %d마리 · 이번 주 %d마리", hunt.Hunts, hunt.Week), nil, 20)
	local title = Formulas.huntTitle(hunt.Hunts)
	textRow(title and string.format("🏅 내 칭호: %s (머리 위에 보여요)", title.Name) or "🏅 칭호: 아직 없어요", nil, 20)
	for _, t in ipairs(bc.HuntTitles) do
		local got = hunt.Hunts >= t.Hunts
		textRow(string.format("%s %s · %d마리", got and "✅" or "🔒", t.Name, t.Hunts), got and COLOR_HIDER or COLOR_SOFT, 20, 12)
	end
	textRow("🏆 순위: 이번 주 사냥 수대로 다음 주에 🔑 선물", COLOR_SOFT, 20, 12)
end

-- ➕ 방 만들기: 🏆 랭킹전 or 🎈 일반전 (a race: on 🦖 walking dinos or 🦅 flying ones too)
local function drawChoice()
	hint.Text = "👥 여럿이 같이 하는 멀티플레이 방 · 어떤 방?"
	textRow("🏆 랭킹전: 고른 열쇠를 모두 걸고 등수대로 나눠 가져요 (꼴찌는 0) · 기록·이번 주 순위", COLOR_RANKED, 34, 12)
	textRow("🎈 일반전: 열쇠 없이 여럿이 그냥 놀아요 · 기록 없음", COLOR_SOFT, 20, 12)
	textRow("🔑 랭킹전에 걸 열쇠 (그 열쇠가 있는 사람만 들어와요)", COLOR_SOFT, 20, 12)
	order += 1
	local stakes = Instance.new("Frame")
	stakes.Size = UDim2.new(1, -6, 0, CHOICE_HEIGHT)
	stakes.BackgroundTransparency = 1
	stakes.LayoutOrder = order
	stakes.Parent = list
	local grades = Config.Ranked.Stake.Grades
	for i, g in ipairs(grades) do
		local held = keysHeld(g.Id)
		local b = button(stakes, string.format("%s\n내 %s개", stakeText(g.Id), Formulas.shortNumber(held)),
			g.Id == stakePick and COLOR_RANKED or TAB_OFF, UDim2.new(1 / #grades, -4, 1, -4),
			UDim2.new((i - 1) / #grades, 2, 0, 0))
		b.TextSize = 12
		b.TextColor3 = held >= g.Keys and Color3.new(1, 1, 1) or COLOR_SOFT
		b.Activated:Connect(function()
			stakePick = g.Id
			redraw()
		end)
	end
	local function pick(ranked, kind)
		choosing = false
		if tab == "Hide" then
			Net.request("HideSeekCreate", ranked, stakePick)
		else
			Net.request("RaceRoomCreate", kind, ranked, stakePick)
		end
		redraw()
	end
	local function choiceRow(kind)
		order += 1
		local holder = Instance.new("Frame")
		holder.Size = UDim2.new(1, -6, 0, CHOICE_HEIGHT)
		holder.BackgroundTransparency = 1
		holder.LayoutOrder = order
		holder.Parent = list
		local left = 0
		if kind then
			local what = label(holder, kind == "Sky" and "🦅 하늘\n나는 공룡" or "🦖 길\n걷는 공룡",
				UDim2.new(0, CHOICE_LABEL, 1, 0), UDim2.new(), 13)
			what.TextXAlignment = Enum.TextXAlignment.Left
			left = CHOICE_LABEL + 4
		end
		local ranked = button(holder, "🏆 랭킹전", COLOR_RANKED, UDim2.new(0.5, -left / 2 - 4, 1, -4), UDim2.fromOffset(left, 0))
		ranked.TextSize = 15
		ranked.Activated:Connect(function()
			pick(true, kind)
		end)
		local normal = button(holder, "🎈 일반전", COLOR_NORMAL, UDim2.new(0.5, -left / 2 - 4, 1, -4),
			UDim2.new(0.5, left / 2 + 4, 0, 0))
		normal.TextSize = 15
		normal.Activated:Connect(function()
			pick(false, kind)
		end)
	end
	if tab == "Hide" then
		choiceRow(nil)
	else
		choiceRow("Road")
		choiceRow("Sky")
	end
	mainButton.Visible = true
	mainButton.Text = "↩️ 뒤로"
	mainButton.BackgroundColor3 = COLOR_BLUE
end

local function drawTrials()
	order += 1
	local gap = Instance.new("Frame")
	gap.Size = UDim2.new(1, -6, 0, SOLO_GAP)
	gap.BackgroundTransparency = 1
	gap.LayoutOrder = order
	gap.Parent = list
	textRow("⏱️ 혼자 기록전 · 방 없이 나 혼자 달려요", COLOR_SOLO_TEXT, 22, 13)
	textRow("🏅 시간 안에 들어오면 메달과 보상!", COLOR_SOFT, 18, 12)
	for _, entry in ipairs(TRIAL_KINDS) do
		local kind = entry[1]
		local medals = Config.Race.Medals[kind]
		local got = player:GetAttribute("RaceMedal" .. kind) or 0
		local best = TRIAL_BEST[kind] and player:GetAttribute(TRIAL_BEST[kind])
		local r = row(TRIAL_ROW)
		r.BackgroundColor3 = COLOR_SOLO_ROW
		local edge = Instance.new("UIStroke")
		edge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		edge.Color = COLOR_SOLO
		edge.Thickness = SOLO_STROKE
		edge.Parent = r
		local title = entry[2] .. (got > 0 and medals[got] and (" " .. medals[got].Icon) or "")
			.. (best and string.format(" · 내 최고 %.1f초", best) or "")
		local top = label(r, title, UDim2.new(1, -SOLO_BUTTON.X.Offset - 20, 0, 22), UDim2.fromOffset(10, 4), 14)
		top.TextXAlignment = Enum.TextXAlignment.Left
		top.TextTruncate = Enum.TextTruncate.AtEnd
		local parts = {}
		for i, m in ipairs(medals) do
			local mark = i <= got and "✅" or ""
			table.insert(parts, m.Seconds and string.format("%s%s %d초", mark, m.Icon, m.Seconds) or (mark .. m.Icon))
		end
		local line = table.concat(parts, " ") .. (kind == "Sky" and " · 목표는 코스마다" or "")
		local targets = label(r, line, UDim2.new(1, -SOLO_BUTTON.X.Offset - 20, 0, 22), UDim2.fromOffset(10, 28), 12)
		targets.TextXAlignment = Enum.TextXAlignment.Left
		targets.TextColor3 = COLOR_SOFT
		targets.TextTruncate = Enum.TextTruncate.AtEnd
		local go = button(r, "🏃 혼자 달리기", COLOR_SOLO, SOLO_BUTTON, UDim2.new(1, -SOLO_BUTTON.X.Offset - 6, 0, 10))
		Coach.mark(go, kind == "Road" and "RaceSolo" or kind == "Sky" and "RaceSoloSky" or nil)
		go.TextScaled = true
		go.TextWrapped = true
		local most = Instance.new("UITextSizeConstraint")
		most.MaxTextSize = SOLO_BUTTON_TEXT
		most.Parent = go
		go.Activated:Connect(function()
			Net.request("RacePractice", kind)
		end)
	end
end

-- the rooms, not being in one
local function drawRooms()
	hint.Text = tab == "Hide" and string.format("👥 %d명 이상 모여 모두 준비하면 시작 · 술래는 랜덤", MIN_PLAYERS.Hide)
		or string.format("👥 %d명 이상 모여 모두 준비하면 출발!", MIN_PLAYERS.Race)
	local left = player:GetAttribute("MiniKeysLeft") or Config.Ranked.PlayKeys.DailyGames
	textRow(left > 0 and string.format("🔑 같이 한 판마다 열쇠 · 🏆 이기면 더! (오늘 %d판 남음)", left)
		or "🎮 오늘 열쇠 판은 다 받았어요 · 내일 또!", COLOR_KEYS, 22, 12)
	empty.Visible = #rooms[tab] == 0
	for _, room in ipairs(rooms[tab]) do
		local r = row()
		local top = tab == "Hide" and string.format("%d번 방 · %s", room.Id, modeText(room.Ranked, room.Stake))
			or string.format("%d번 방 · %s · %s", room.Id, kindText(room.Kind), modeText(room.Ranked, room.Stake))
		local a = label(r, top, UDim2.new(1, -96, 0, 20), UDim2.fromOffset(10, 2), 13)
		a.TextXAlignment = Enum.TextXAlignment.Left
		a.TextTruncate = Enum.TextTruncate.AtEnd
		local b = label(r, string.format("👑 %s · 👥 %d/%d", nameOf(room.Host), #room.Members, MAX_PLAYERS[tab]),
			UDim2.new(1, -96, 0, 16), UDim2.fromOffset(10, 22), 11)
		b.TextXAlignment = Enum.TextXAlignment.Left
		b.TextColor3 = COLOR_SOFT
		b.TextTruncate = Enum.TextTruncate.AtEnd
		if room.Phase ~= "Waiting" then
			local state = label(r, tab == "Hide" and "🎮 게임 중" or "🏁 달리는 중", UDim2.fromOffset(80, ROW_HEIGHT),
				UDim2.new(1, -84, 0, 0), 12)
			state.TextColor3 = COLOR_SOFT
		else
			local join = button(r, "참가", COLOR_GO, UDim2.fromOffset(76, 30), UDim2.new(1, -82, 0, 5))
			local id = room.Id
			join.Activated:Connect(function()
				Net.request(tab == "Hide" and "HideSeekJoin" or "RaceRoomJoin", id)
			end)
		end
	end
	if tab == "Race" then
		if #rooms.Race == 0 then
			empty.Visible = false
			textRow("🚪 아직 열린 방이 없어요. 방을 만들어 친구를 불러요!", COLOR_SOFT, 22, 12)
		end
		drawTrials()
	end
	mainButton.Visible = true
	mainButton.Text = "👥 멀티플레이\n➕ 방 만들기"
	mainButton.BackgroundColor3 = COLOR_GO
end

-- my room: its members, 준비 and 나가기
local function drawMyRoom(mine)
	local playing = mine.Phase ~= "Waiting"
	hint.Text = tab == "Hide"
		and string.format("🙈 %d번 방 · %s · %d/%d명", mine.Id, modeText(mine.Ranked, mine.Stake), #mine.Members, MAX_PLAYERS.Hide)
		or string.format("🏁 %d번 방 · %s · %s · %d/%d명", mine.Id, kindText(mine.Kind), modeText(mine.Ranked, mine.Stake), #mine.Members,
			MAX_PLAYERS.Race)
	for _, userId in ipairs(mine.Members) do
		local r = row()
		local mark, color = nil, COLOR_SOFT
		if playing and tab == "Hide" then
			mark = userId == mine.Seeker and "😈 술래" or "🙈 숨는 중"
			color = userId == mine.Seeker and COLOR_SEEKER or COLOR_HIDER
		elseif playing then
			mark, color = "🏁 달리는 중", COLOR_HIDER
		else
			mark = table.find(mine.Ready, userId) and "✅ 준비" or "⏳ 대기"
		end
		local who = label(r, (userId == mine.Host and "👑 " or "") .. nameOf(userId), UDim2.new(1, -110, 1, 0),
			UDim2.fromOffset(10, 0), 14)
		who.TextXAlignment = Enum.TextXAlignment.Left
		who.TextTruncate = Enum.TextTruncate.AtEnd
		local state = label(r, mark, UDim2.fromOffset(96, ROW_HEIGHT), UDim2.new(1, -100, 0, 0), 13)
		state.TextColor3 = color
	end
	local ready = table.find(mine.Ready, player.UserId) ~= nil
	mainButton.Visible = not playing
	mainButton.Text = ready and "준비 취소" or "✅ 준비"
	mainButton.BackgroundColor3 = ready and COLOR_BLUE or COLOR_GO
	-- (2026-10-04, "놀이방에서 내가 놀이방에서 기다리고 있다는 것 같은 모집을 위한 알림을 날릴 수 있게 해줘 서버 안 사람들에게.
	-- 10초에 한 번씩", "방 만든 이후에 가능하게") 📣 under the members while the room waits: everyone else in the server
	-- hears of it (Net request HideSeekRecruit / RaceRoomRecruit; the server keeps the 10 seconds and says when). Only
	-- the host's (2026-10-04, "방장만 하는게 낫지"; the next member is the host when they leave)
	if not playing and mine.Host == player.UserId then
		order += 1
		local holder = Instance.new("Frame")
		holder.Size = UDim2.new(1, -6, 0, RECRUIT_HEIGHT)
		holder.BackgroundTransparency = 1
		holder.LayoutOrder = order
		holder.Parent = list
		local recruit = button(holder, "📣 모집 알림 보내기 (서버 모두에게)", COLOR_RECRUIT, UDim2.fromScale(1, 1), UDim2.new())
		recruit.Activated:Connect(function()
			Net.request(tab == "Hide" and "HideSeekRecruit" or "RaceRoomRecruit")
		end)
	end
	sideButton.Visible = true
	sideButton.Text = playing and "🏳️ 기권" or "🚪 나가기"
	sideButton.Position = playing and UDim2.new(0, 10, 1, -62) or SIDE_AT
end

redraw = function()
	clearList()
	for id, b in pairs(tabs) do
		b.BackgroundColor3 = id == tab and TAB_COLORS[id] or TAB_OFF
		b.TextColor3 = id == tab and Color3.new(1, 1, 1) or COLOR_SOFT
	end
	recordLine.Text = recordText()
	rankButton.Text = ranking and "📋 방 목록" or "🏆 순위"
	empty.Visible = false
	mainButton.Visible, sideButton.Visible = false, false
	local mine = myRoom(tab)
	if mine then
		choosing = false
	end
	rankButton.Visible = not choosing
	if ranking then
		drawRanking()
	elseif tab == "Boss" then
		drawBoss()
	elseif mine then
		drawMyRoom(mine)
	elseif choosing then
		drawChoice()
	else
		drawRooms()
	end
end

mainButton.Activated:Connect(function()
	if tab == "Boss" then
		return
	end
	local mine = myRoom(tab)
	if mine then
		Net.request(tab == "Hide" and "HideSeekReady" or "RaceRoomReady", not table.find(mine.Ready, player.UserId))
		return
	end
	choosing = not choosing
	redraw()
end)
sideButton.Activated:Connect(function()
	if tab ~= "Boss" then
		Net.request(tab == "Hide" and "HideSeekLeave" or "RaceRoomLeave")
	end
end)
rankButton.Activated:Connect(function()
	ranking, choosing = not ranking, false
	redraw()
end)
for _, name in ipairs({ "HideSeekTop", "HideWeekTop", "RaceWeekTop", "RaceTopRoad", "RaceTopSky", "BossWeekTop" }) do
	ReplicatedStorage:GetAttributeChangedSignal(name):Connect(function()
		if window.Visible and ranking then
			redraw()
		end
	end)
end
player:GetAttributeChangedSignal("MiniKeysLeft"):Connect(function()
	if window.Visible and not ranking then
		redraw()
	end
end)
for _, name in ipairs({ "HideWins", "HideLosses", "RaceWins", "RaceLosses", "SkyWins", "SkyLosses" }) do
	player:GetAttributeChangedSignal(name):Connect(function()
		if window.Visible then
			recordLine.Text = recordText()
		end
	end)
end

Net.onPush("HideSeekRooms", function(list_)
	rooms.Hide = type(list_) == "table" and list_ or {}
	if window.Visible then
		redraw()
	end
end)
Net.onPush("RaceRooms", function(list_)
	rooms.Race = type(list_) == "table" and list_ or {}
	if window.Visible then
		redraw()
	end
end)
-- this week's counted ranked wins come with a ranked game's result
Net.onPush("HideSeekResult", function(_, _, ranked, _, wins)
	if ranked and tonumber(wins) then
		weekWins.Hide = tonumber(wins)
	end
end)
Net.onPush("RaceResult", function(r)
	if type(r) == "table" and r.Ranked and tonumber(r.WeekWins) then
		weekWins.Race = tonumber(r.WeekWins)
	end
end)

-- (2026-10-04) my night boss hunts from the server
fetchHunt = function()
	local h = Net.ask("GetBossHunt")
	if type(h) == "table" then
		hunt.Hunts = tonumber(h.Hunts) or hunt.Hunts
		hunt.Week = tonumber(h.Week) or hunt.Week
		hunt.Bones = type(h.Bones) == "table" and h.Bones or hunt.Bones
	end
end
player:GetAttributeChangedSignal("BossHunts"):Connect(function() -- (a hunt: the 🧟 tab shows it)
	if window.Visible and tab == "Boss" then
		task.spawn(function()
			fetchHunt()
			if window.Visible and tab == "Boss" then
				redraw()
			end
		end)
	end
end)

-- the rooms (and my week's wins) from the servers
local fetching = 0
local function fetch()
	fetching += 1
	local mine = fetching
	local left = 3
	local function done()
		left -= 1
		if left == 0 and mine == fetching and window.Visible then
			redraw()
		end
	end
	task.spawn(function()
		local hide = Net.ask("GetHideSeek")
		if type(hide) == "table" then
			rooms.Hide = type(hide.Rooms) == "table" and hide.Rooms or rooms.Hide
			weekWins.Hide = tonumber(hide.WeekWins) or weekWins.Hide
		end
		done()
	end)
	task.spawn(function()
		local race = Net.ask("GetRaceRooms", true)
		if type(race) == "table" then
			rooms.Race = type(race.Rooms) == "table" and race.Rooms or rooms.Race
			weekWins.Race = tonumber(race.WeekWins) or weekWins.Race
		end
		done()
	end)
	task.spawn(function()
		fetchHunt()
		done()
	end)
end

local openedBy = nil
local function open(prompt, which)
	openedBy = prompt
	ranking, choosing = false, false
	local _, waitingId = waitingRoom()
	tab = which or (myRoom("Hide") and "Hide") or (myRoom("Race") and "Race") or waitingId or tab
	redraw()
	window.Visible = true
	fetch()
end

ProximityPromptService.PromptTriggered:Connect(function(prompt)
	if prompt:GetAttribute("Kind") == "HideSeek" then
		if window.Visible then -- E again closes it
			window.Visible = false
			return
		end
		open(prompt, "Hide")
	end
end)

-- the 🎮 놀이방 corner button (2026-10-03 the 🙈 one, "숨바꼭질 방 열리면 화면 구석쯤에 작게 반짝거리게.. 그 버튼으로도 열 수
-- 있게 해 방"; 2026-10-04 both games): the window from anywhere; says so and glows while a room waits or I'm in one
local cornerGui = Instance.new("ScreenGui")
cornerGui.Name = "GameRoomsCorner"
cornerGui.ResetOnSpawn = false
cornerGui.Parent = player:WaitForChild("PlayerGui")
local cornerButton = button(cornerGui, "🎮 놀이방", CORNER_COLOR, CORNER_SIZE, CORNER_POS)
cornerButton.Name = "GameRoomsCorner"
cornerButton.AnchorPoint = Vector2.new(0, 1)
cornerButton.TextScaled = true
cornerButton.TextWrapped = true
do
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = CORNER_TEXT_MAX
	most.Parent = cornerButton
end
local cornerStroke = Instance.new("UIStroke")
cornerStroke.Color = CORNER_GLOW_EDGE
cornerStroke.Thickness = 2
cornerStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
cornerStroke.Transparency = 1
cornerStroke.Parent = cornerButton
local cornerScale = Instance.new("UIScale")
cornerScale.Parent = cornerButton
local pointer = label(cornerGui, "👈 여기!", POINTER_SIZE, UDim2.new(), 16)
pointer.AnchorPoint = Vector2.new(0, 1)
pointer.TextColor3 = POINTER_COLOR
pointer.TextStrokeTransparency = 0.2
pointer.TextXAlignment = Enum.TextXAlignment.Left
pointer.Visible = false
local callUntil = 0
Net.onPush("RoomCallFx", function()
	callUntil = os.clock() + CALL_SECONDS
end)
cornerButton.Activated:Connect(function()
	if Unlock.ready("GameRooms") then
		Unlock.ask("GameRooms")
		return
	end
	callUntil = 0 -- (found it)
	if window.Visible then
		window.Visible = false
	else
		open(nil, nil)
	end
end)
task.spawn(function() -- (the rooms already open when I come in)
	local hide = Net.ask("GetHideSeek")
	if type(hide) == "table" and type(hide.Rooms) == "table" then
		rooms.Hide = hide.Rooms
	end
	local race = Net.ask("GetRaceRooms")
	if type(race) == "table" and type(race.Rooms) == "table" then
		rooms.Race = race.Rooms
	end
end)
local roomsOpen = Unlock.usable("GameRooms") or Unlock.ready("GameRooms")
Unlock.watch(function()
	roomsOpen = Unlock.usable("GameRooms") or Unlock.ready("GameRooms")
end)
RunService.Heartbeat:Connect(FrameMeter.wrap("GameRooms", function()
	local show = roomsOpen and player:GetAttribute("HideSeekRoom") == nil and not player:GetAttribute("TutorialStep")
		and not player:GetAttribute("Racing") and not player:GetAttribute("RacePractice")
	cornerButton.Visible = show
	local calling = show and os.clock() < callUntil and not window.Visible
	pointer.Visible = calling
	if not show then
		return
	end
	local mineId = (myRoom("Hide") and "Hide") or (myRoom("Race") and "Race") or nil
	local mine = mineId and myRoom(mineId)
	local waiting, waitingId = nil, nil
	if not mine then
		waiting, waitingId = waitingRoom()
	end
	if mine then
		Lang.set(cornerButton, string.format(mineId == "Hide" and "🙈 내 방 %d/%d" or "🏁 내 방 %d/%d", #mine.Members,
			MAX_PLAYERS[mineId]))
	elseif waiting then
		Lang.set(cornerButton, string.format(waitingId == "Hide" and "🙈 방 열림! %d/%d" or "🏁 방 열림! %d/%d",
			#waiting.Members, MAX_PLAYERS[waitingId]))
	elseif Unlock.ready("GameRooms") then
		Lang.set(cornerButton, "🔓 🎮 놀이방")
	else
		Lang.set(cornerButton, "🎮 놀이방")
	end
	local glow = (mine or waiting) and (0.5 + 0.5 * math.sin(os.clock() * math.pi / CORNER_BLINK)) or 0
	cornerButton.BackgroundColor3 = (mine or waiting) and CORNER_COLOR:Lerp(CORNER_OPEN_COLOR, glow) or CORNER_COLOR
	cornerStroke.Transparency = (mine or waiting) and 1 - glow or CORNER_EDGE_IDLE
	cornerStroke.Color = (mine or waiting) and CORNER_GLOW_EDGE or CORNER_EDGE
	cornerStroke.Thickness = CALL_STROKE[1]
	cornerScale.Scale = 1
	if calling then -- (over the quiet glow above)
		local flash = 0.5 + 0.5 * math.sin(os.clock() * math.pi / CALL_BLINK)
		cornerButton.BackgroundColor3 = CALL_COLORS[1]:Lerp(CALL_COLORS[2], flash)
		cornerStroke.Transparency = 0
		cornerStroke.Thickness = CALL_STROKE[1] + (CALL_STROKE[2] - CALL_STROKE[1]) * flash
		cornerScale.Scale = 1 + CALL_POP * flash
		pointer.Position = CORNER_POS + UDim2.fromOffset(CORNER_SIZE.X.Offset * (1 + CALL_POP) + POINTER_GAP
			- POINTER_BOB * flash, 0)
	end
end))

RunService.Heartbeat:Connect(FrameMeter.wrap("GameRooms", function() -- walked away from the board (not in a room): close it
	if window.Visible and openedBy and not myRoom("Hide") and not myRoom("Race") then
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		local holder = openedBy.Parent
		local at = holder and (holder:IsA("Attachment") and holder.WorldPosition or holder:IsA("BasePart") and holder.Position)
		if not root or not at or (root.Position - at).Magnitude > openedBy.MaxActivationDistance + CLOSE_SLACK then
			window.Visible = false
		end
	end
end))
Windows.register(window)
