--[[
RebirthLook: everyone who has reborn shows it (design 12, 환생 표식). Over the head a small badge in the
tier's color with its mark ("🟢 환생 1", the marks of Config.Rebirth.TierMarks), and round the body a
soft aura of rising sparkles in the same color, thicker with more rebirths. Drawn on every screen for
every player from their Rebirths attribute. The aura goes with the view setting "오라" (HideAuras);
the badge always shows. (2026-10-05, "한정 뽑았다고 한정 캐릭터에 달아주지 말고, 한정 공룡을 탈것으로 타면 한정이 달리게")
Riding a limited dino (player attributes Riding and MountLimited, the Ride service) puts "🎖️ 한정" on the same
badge, in gold without rebirths.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))

local player = Players.LocalPlayer

-- display only
local TIER_COLORS = { -- one a tier, rebirths 1, 2, ...; the last one repeats (matches TierMarks' 🟢 🔵 🟣 🟠 🔴 ⭐)
	Color3.fromRGB(80, 220, 110),
	Color3.fromRGB(70, 150, 255),
	Color3.fromRGB(185, 95, 255),
	Color3.fromRGB(255, 150, 40),
	Color3.fromRGB(255, 70, 70),
	Color3.fromRGB(255, 210, 60),
}
local BADGE_SIZE = UDim2.fromOffset(130, 26)
local BADGE_HEIGHT = 1.2 -- (2026-10-02: was 4, then the tags overlapped up close) the head-tag spot (StarterPlayerScripts/Race)
local BADGE_DISTANCE = 150
local BADGE_TEXT = 18
local LIMITED_COLOR = Color3.fromRGB(255, 205, 60) -- the badge with only the limited mark
local AURA_RATE_BASE = 4 -- sparkles a second at one rebirth ...
local AURA_RATE_PER_REBIRTH = 2 -- ... and this many more a rebirth
local AURA_RATE_MAX = 20
local AURA_SIZE = 0.35
local AURA_LIFETIME = NumberRange.new(1, 1.6)
local AURA_SPEED = NumberRange.new(1.5, 3)

local function tierColor(rebirths)
	return TIER_COLORS[math.clamp(rebirths, 1, #TIER_COLORS)]
end

local function auraHidden()
	return player:GetAttribute("HideAuras") == true
end

local function refresh(other)
	local character = other.Character
	local head = character and character:FindFirstChild("Head")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not head or not root then
		return
	end
	local rebirths = other:GetAttribute("Rebirths") or 0
	local limited = other:GetAttribute("Riding") == true and other:GetAttribute("MountLimited") == true
	local badge = head:FindFirstChild("RebirthBadge")
	local aura = root:FindFirstChild("RebirthAura")
	if rebirths <= 0 and aura then
		aura:Destroy()
		aura = nil
	end
	if rebirths <= 0 and not limited then
		if badge then
			badge:Destroy()
		end
		return
	end
	local color = rebirths > 0 and tierColor(rebirths) or LIMITED_COLOR
	if not badge then
		badge = Instance.new("BillboardGui")
		badge.Name = "RebirthBadge"
		badge.Size = BADGE_SIZE
		badge.StudsOffsetWorldSpace = Vector3.new(0, BADGE_HEIGHT, 0)
		badge.SizeOffset = Vector2.new(0, 4.75)
		badge.MaxDistance = BADGE_DISTANCE
		local text = Instance.new("TextLabel")
		text.Name = "Text"
		text.Size = UDim2.fromScale(1, 1)
		text.BackgroundTransparency = 1
		text.Font = Enum.Font.GothamBlack
		text.TextSize = BADGE_TEXT
		text.TextStrokeTransparency = 0.2
		text.Parent = badge
		badge.Parent = head
	end
	local marks = Config.Rebirth.TierMarks
	local parts = {}
	if rebirths > 0 then
		table.insert(parts, string.format("%s 환생 %d", marks[math.min(#marks, rebirths + 1)], rebirths))
	end
	if limited then
		table.insert(parts, "🎖️ 한정")
	end
	badge.Text.Text = table.concat(parts, " · ")
	badge.Text.TextColor3 = color
	if rebirths <= 0 then
		return -- (no aura without rebirths)
	end
	if not aura then
		aura = Instance.new("ParticleEmitter")
		aura.Name = "RebirthAura"
		aura.Texture = "rbxasset://textures/particles/sparkles_main.dds"
		aura.LightEmission = 1
		aura.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, AURA_SIZE), NumberSequenceKeypoint.new(1, 0) })
		aura.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
		aura.Lifetime = AURA_LIFETIME
		aura.Speed = AURA_SPEED
		aura.EmissionDirection = Enum.NormalId.Top
		aura.SpreadAngle = Vector2.new(25, 25)
		aura.Parent = root
	end
	aura.Color = ColorSequence.new(color)
	aura.Rate = math.min(AURA_RATE_MAX, AURA_RATE_BASE + AURA_RATE_PER_REBIRTH * (rebirths - 1))
	aura.Enabled = not auraHidden()
end

local function watch(other)
	other.CharacterAdded:Connect(function(character)
		character:WaitForChild("Head", 10)
		character:WaitForChild("HumanoidRootPart", 10)
		refresh(other)
	end)
	other:GetAttributeChangedSignal("Rebirths"):Connect(function()
		refresh(other)
	end)
	for _, name in ipairs({ "Riding", "MountLimited" }) do
		other:GetAttributeChangedSignal(name):Connect(function()
			refresh(other)
		end)
	end
	task.spawn(refresh, other)
end

for _, other in ipairs(Players:GetPlayers()) do
	watch(other)
end
Players.PlayerAdded:Connect(watch)

player:GetAttributeChangedSignal("HideAuras"):Connect(function()
	for _, other in ipairs(Players:GetPlayers()) do
		refresh(other)
	end
end)
