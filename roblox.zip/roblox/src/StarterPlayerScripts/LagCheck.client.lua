--[[
LagCheck: tells the player when the server stops answering (Watchdog service). Every
Config.Watchdog.PingEvery seconds it asks Ping; while an answer is late by more than SlowAfter seconds a
small banner at the top says "⏳ 서버 응답이 늦어요 (n초)" (walking still works then: it is the phone's
own, the buttons wait on the server). Also sends this screen's script errors to the server's log
(ClientError), so a bug on a phone can be found in the developer console. While the player's save
is still held by another server (player attribute DataWait, PlayerData) it says "loading my data".
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local ScriptContext = game:GetService("ScriptContext")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))

local player = Players.LocalPlayer
local developer = RunService:IsStudio() or Formulas.isDeveloper(player.Name)

-- display only
local BANNER_SIZE = UDim2.fromOffset(420, 112) -- (the slow-server banner tells what the server reports)
local BANNER_SIZE_PLAYER = UDim2.fromOffset(300, 46)
local BANNER_POS = UDim2.new(0.5, 0, 0, 44)
local STALL_KBPS = 1
local SIGNAL_FRESH = 2
local COLOR_BG = Color3.fromRGB(60, 40, 20)
local COLOR_TEXT = Color3.fromRGB(255, 220, 120)
local PAUSE_GAP = 2 -- seconds between two frames: the game was stopped (the phone's screen off, the app away)
local RESUMED_SECONDS = 60 -- this long after that, a late server is told as the phone reconnecting

local gui = Instance.new("ScreenGui")
gui.Name = "LagCheck"
gui.ResetOnSpawn = false
gui.DisplayOrder = 7
gui.Parent = player:WaitForChild("PlayerGui")
local banner = Instance.new("TextLabel")
banner.AnchorPoint = Vector2.new(0.5, 0)
banner.Size = BANNER_SIZE
banner.Position = BANNER_POS
banner.BackgroundColor3 = COLOR_BG
banner.BackgroundTransparency = 0.15
banner.TextColor3 = COLOR_TEXT
banner.Font = Enum.Font.GothamBold
banner.TextScaled = true
banner.Visible = false
banner.Parent = gui
local round = Instance.new("UICorner")
round.CornerRadius = UDim.new(0, 8)
round.Parent = banner

local ERRORS_PER_MINUTE = 5 -- script errors this screen reports a minute at most (2026-10-01: no limit
-- here; an error every frame would have sent 60 reports a second), the same one only once
local joinedAt = os.clock()
local lastArrive = nil
ReplicatedStorage:GetAttributeChangedSignal("ServerClock"):Connect(function()
	lastArrive = os.clock()
end)
local waitingSince = nil -- os.clock() since when a Ping has been waiting with none answered
local newestAsk = nil -- os.clock() of the newest Ping still waiting

-- (2026-10-02, "스마트폰 화면이 꺼졌다 켜지니 버튼이 안 먹네" / "이 서버 지연이 뜨는데"): a Ping lost while the phone
-- slept would have kept the banner up for good (a new one was sent only after it came back): another is
-- sent when one waits longer than Config.Watchdog.RetrySeconds, and any answer clears the wait
task.spawn(function()
	while true do
		if not newestAsk or os.clock() - newestAsk > Config.Watchdog.RetrySeconds then
			local at = os.clock()
			newestAsk = at
			waitingSince = waitingSince or at
			task.spawn(function()
				Net.ask("Ping")
				waitingSince = nil
				if newestAsk == at then
					newestAsk = nil
				end
			end)
		end
		task.wait(Config.Watchdog.PingEvery)
	end
end)

-- the phone's screen went off (the game stopped for a while): its connection takes a moment to catch up after
local resumedAt = nil
local lastBeat = os.clock()
RunService.Heartbeat:Connect(FrameMeter.wrap("LagCheck", function()
	local now = os.clock()
	if now - lastBeat > PAUSE_GAP then
		resumedAt = now
	end
	lastBeat = now
end))
UserInputService.WindowFocused:Connect(function()
	if UserInputService.TouchEnabled then -- (a phone's app back in front; on a computer clicking back in is no pause)
		resumedAt = os.clock()
	end
end)

task.spawn(function()
	while true do
		local late = waitingSince and os.clock() - waitingSince or 0
		-- my save is still held by the server I was on before (PlayerData waits for it to let go)
		local dataWait = player:GetAttribute("DataWait") == true
		-- (not while the map is still coming in after joining: that always takes a moment)
		banner.Visible = dataWait or (late > Config.Watchdog.SlowAfter and os.clock() - joinedAt > Config.Watchdog.JoinGraceSeconds)
		banner.Size = (developer or dataWait) and BANNER_SIZE or BANNER_SIZE_PLAYER
		if dataWait then
			banner.Text = "💾 내 데이터 불러오는 중...\n잠깐만 기다려 주세요"
		elseif banner.Visible and resumedAt and os.clock() - resumedAt < RESUMED_SECONDS then
			-- (the server is fine: this phone is catching up; the buttons wait on the server till then)
			banner.Text = string.format("📶 화면이 꺼졌다 켜져서 서버와 다시 연결하는 중 (%d초)\n잠시 뒤 버튼이 다시 돼요", math.floor(late))
		elseif banner.Visible and not developer then
			banner.Text = "📶 인터넷이 잠깐 느려요\n잠시만 기다려 주세요"
		elseif banner.Visible then
			local clock = ReplicatedStorage:GetAttribute("ServerClock")
			local okRecv, recv = pcall(function()
				return game:GetService("Stats").DataReceiveKbps
			end)
			local okSend, send = pcall(function()
				return game:GetService("Stats").DataSendKbps
			end)
			-- this screen's side too (2026-10-01): how much it sends, how high it is, flying or riding
			local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
			local mine = string.format("내 화면: 보내기 %s KB/s · 높이 %s%s%s", okSend and tostring(math.floor(send / 8 + 0.5)) or "?",
				root and tostring(math.floor(root.Position.Y)) or "?", player:GetAttribute("Riding") and " · 탐" or "",
				player:GetAttribute("Flying") and " · 비행" or "")
			local arrived = lastArrive and os.clock() - lastArrive or math.huge
			local stalled = okRecv and recv / 8 < STALL_KBPS and arrived > SIGNAL_FRESH
			local serverFine = clock and Workspace:GetServerTimeNow() - clock <= SIGNAL_FRESH
			local delayed = not serverFine and clock ~= nil and arrived <= SIGNAL_FRESH
			banner.Text = string.format(stalled and "📶 이 기기가 받는 신호 없음 (%d초) · 서버 신호 %s · 받기 %s KB/s\n%s\n%s"
				or delayed and "📶 신호가 이 기기에 늦게 와요 (%d초) · 서버 신호 %s · 받기 %s KB/s\n%s\n%s"
				or serverFine and "📶 서버는 정상 · 이 기기가 보내는 신호가 늦어요 (%d초) · 서버 신호 %s · 받기 %s KB/s\n%s\n%s"
				or "⏳ 서버 응답이 늦어요 (%d초) · 서버 신호 %s · 받기 %s KB/s\n%s\n%s", math.floor(late),
				clock and string.format("%d초 전", math.floor(Workspace:GetServerTimeNow() - clock)) or "없음",
				okRecv and tostring(math.floor(recv / 8 + 0.5)) or "?", mine, ReplicatedStorage:GetAttribute("ServerStats") or "")
		end
		task.wait(0.5)
	end
end)

local errorSignal = ScriptContext and ScriptContext.Error -- (missing in the build tool's mock)
if errorSignal then
	local sent, since = {}, os.clock()
	local count = 0
	errorSignal:Connect(function(message, trace)
		if os.clock() - since > 60 then
			sent, since, count = {}, os.clock(), 0
		end
		local key = tostring(message)
		if sent[key] or count >= ERRORS_PER_MINUTE then
			return
		end
		sent[key] = true
		count += 1
		local most = Config.Net.MaxStringLength -- (longer is turned away by the server)
		Net.request("ClientError", key:sub(1, most), tostring(trace):sub(1, most))
	end)
end
