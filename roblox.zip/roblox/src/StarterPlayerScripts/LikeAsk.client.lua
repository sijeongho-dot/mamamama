local AvatarEditorService = game:GetService("AvatarEditorService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Windows = require(Shared:WaitForChild("Windows"))
local CocoVoice = require(Shared:WaitForChild("CocoVoice"))

local player = Players.LocalPlayer

local FONT = Enum.Font.GothamBold
local PANEL_SIZE = UDim2.fromOffset(340, 236)
local EDGE = 14
local BUTTON_HEIGHT = 46
local BUTTON_GAP = 8
local LOOK_EVERY = 2
local THANKS_SECONDS = 2
local COLOR_BG = Color3.fromRGB(30, 34, 50)
local COLOR_TITLE = Color3.fromRGB(255, 225, 120)
local COLOR_TEXT = Color3.fromRGB(235, 238, 245)
local COLOR_NOTE = Color3.fromRGB(190, 196, 210)
local COLOR_FAV = Color3.fromRGB(240, 175, 40)
local COLOR_OK = Color3.fromRGB(70, 140, 230)
local COLOR_STROKE = Color3.fromRGB(255, 200, 90)

local L = Config.Beta.LikeAsk
local started = os.clock()
local pending = nil
local favTried = false

local gui = Instance.new("ScreenGui")
gui.Name = "LikeAsk"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(0.5, 0.5)
panel.Position = UDim2.fromScale(0.5, 0.5)
panel.Size = PANEL_SIZE
panel.BackgroundColor3 = COLOR_BG
panel.Visible = false
panel.Parent = gui
do
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 14)
	round.Parent = panel
	local edge = Instance.new("UIStroke")
	edge.Color = COLOR_STROKE
	edge.Thickness = 2
	edge.Parent = panel
end

local function label(text, height, y, size, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.TextWrapped = true
	l.TextSize = size
	l.TextColor3 = color
	l.Text = text
	l.Size = UDim2.new(1, -EDGE * 2, 0, height)
	l.Position = UDim2.fromOffset(EDGE, y)
	l.Parent = panel
	return l
end

local function button(text, color, column)
	local b = Instance.new("TextButton")
	b.Font = FONT
	b.TextSize = 17
	b.TextWrapped = true
	b.TextColor3 = Color3.new(1, 1, 1)
	b.Text = text
	b.BackgroundColor3 = color
	b.AnchorPoint = Vector2.new(0, 1)
	b.Size = UDim2.new(0.5, -EDGE - BUTTON_GAP / 2, 0, BUTTON_HEIGHT)
	b.Position = UDim2.new(column * 0.5, column == 0 and EDGE or BUTTON_GAP / 2, 1, -EDGE)
	b.Parent = panel
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0, 10)
	round.Parent = b
	return b
end

label("🐣 코코의 부탁", 30, 10, 21, COLOR_TITLE)
local body = label("", 78, 42, 16, COLOR_TEXT)
local note = label("", 22, 124, 13, COLOR_NOTE)
local fav = button("⭐ 즐겨찾기", COLOR_FAV, 0)
local ok = button("😊 알겠어요", COLOR_OK, 1)

local function close()
	panel.Visible = false
end

local function show()
	body.Text = "재밌었어요? 👍 좋아요와 ⭐ 즐겨찾기를 눌러 주면 더 빠르고 큰 업데이트로 보답할게요!"
	note.Text = "👍 좋아요는 게임 페이지에서 눌러요"
	fav.Visible = not player:GetAttribute("LikeFav")
	panel.Visible = true
	Net.request("LikeAsk", "Shown")
	CocoVoice.babble(body.Text)
end

fav.Activated:Connect(function()
	favTried = true
	local done = pcall(function()
		AvatarEditorService:PromptSetFavorite(game.PlaceId, Enum.AvatarItemType.Asset, true)
	end)
	if not done then
		note.Text = "⭐ 게임 페이지의 ⭐ 즐겨찾기를 눌러 줘요"
	end
end)
AvatarEditorService.PromptSetFavoriteCompleted:Connect(function(result)
	if not favTried then
		return
	end
	favTried = false
	if result == Enum.AvatarPromptResult.Success then
		Net.request("LikeAsk", "Fav")
		fav.Visible = false
		body.Text = "🙏 고마워요! 더 재밌게 만들게요 🐣"
		task.delay(THANKS_SECONDS, close)
	end
end)
ok.Activated:Connect(close)

local function busy()
	return Windows.anyOpen() or player:GetAttribute("CocoIntro") or player:GetAttribute("FirstFight")
		or player:GetAttribute("PromoLevel") or player:GetAttribute("TutorialStep") or player:GetAttribute("Cinematic")
		or player:GetAttribute("TopView") or player:GetAttribute("PlacingUnit")
end

local function allowed()
	return (player:GetAttribute("LikeAsks") or L.Times) < L.Times and not player:GetAttribute("LikeFav")
		and Workspace:GetServerTimeNow() - (player:GetAttribute("LikeAskAt") or 0) >= L.GapMinutes * 60
end

do
	local last = player:GetAttribute("DefenseLevel")
	player:GetAttributeChangedSignal("DefenseLevel"):Connect(function()
		local now = player:GetAttribute("DefenseLevel")
		if last and now and now > last and table.find(L.Levels, now) then
			pending = true
		end
		last = now
	end)
end
player:GetAttributeChangedSignal("BigBox"):Connect(function()
	if player:GetAttribute("BigBox") then
		player:SetAttribute("BigBox", nil)
		pending = true
	end
end)

task.spawn(function()
	while true do
		task.wait(LOOK_EVERY)
		if os.clock() - started >= L.PlayMinutes * 60 then
			pending = true
		end
		if pending and not panel.Visible and allowed() and not busy() then
			pending = nil
			show()
		end
	end
end)

Windows.fit(panel)
Windows.register(panel)
