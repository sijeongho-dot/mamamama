--[[
EventAd (client): 🎉 the launch event's pop-up on every join (Net push EventAd from the Rewards service: once the player
is free - the tutorial done or skipped - while the event runs and its all-done reward is not taken).
(2026-10-04, "런칭 기념 미션 광고 띄워줘야지 접속할 때마다. 이건 튜토 넘긴사람한테도 보여줘도 돼. 보상도 쫙 멋지게,
첫구매 광고마냥 삐까하게", "보상 칸에서 확인가능하다고 하고")

After the join's own windows (the news, the attendance) are closed (however long that takes): a party card like the starter pack's (sliding
colors, turning light rays, rising sparkles, a sweeping shine, a shimmering edge, the title beating), the prizes in a
row of bouncing tiles (the event's slap skin turning in its picture, the ruby, gold and silver keys it gives in all,
keys and money), the title over the head it gives, how many missions are done (a bar), "🎁 보상 창 → 🎉 이벤트에서
확인할 수 있어요", and "🎁 보러 가기" (the 🎁 window on its 🎉 tab: Rewards client, local attribute OpenRewardsTab) /
"나중에". While it waits or shows, the local attribute EventAdUp keeps the starter pack's offer behind it (Robux).
Display only.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local DinoPortrait = require(Shared:WaitForChild("DinoPortrait"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local FrameMeter = require(Shared:WaitForChild("FrameMeter"))
local Net = require(Shared:WaitForChild("Net"))
local Sfx = require(Shared:WaitForChild("Sfx"))
local Windows = require(Shared:WaitForChild("Windows"))

local player = Players.LocalPlayer

-- display only
local FONT = Enum.Font.GothamBlack
local STARTER_WAIT = 60
local CARD_SIZE = UDim2.fromOffset(372, 300)
local COLORS = { Color3.fromRGB(255, 80, 130), Color3.fromRGB(140, 60, 230), Color3.fromRGB(40, 170, 255) }
local SHADE = 0.4 -- a dark veil over the colors so the words stay easy to read
local RAYS, RAY_TURN, RAY_COLOR, RAY_TRANSPARENCY = 16, 14, Color3.fromRGB(255, 240, 170), 0.8
local SPARKLES = 18
local SPARKLE_COLORS = { Color3.fromRGB(255, 240, 150), Color3.fromRGB(255, 255, 255), Color3.fromRGB(255, 170, 220) }
local SHINE_EVERY = 2.4 -- seconds between the white shine sweeping across
local GRADIENT_TURN = 30 -- degrees a second the colors slide round
local EDGE_COLORS = { Color3.fromRGB(255, 215, 90), Color3.fromRGB(255, 120, 200), Color3.fromRGB(120, 220, 255) }
local GOLD = Color3.fromRGB(255, 215, 90)
local COLOR_BG = Color3.fromRGB(25, 22, 45)
local COLOR_GO = Color3.fromRGB(80, 190, 95)
local COLOR_LATER = Color3.fromRGB(90, 90, 105)
local COLOR_BAR_BACK = Color3.fromRGB(40, 36, 60)
local COLOR_BAR = Color3.fromRGB(110, 230, 120)
local COLOR_TILE = Color3.fromRGB(255, 255, 255)
local TILE, TILE_GAP, TILE_TOP = 54, 10, 70
local TILE_BOUNCE, TILE_BOUNCE_SPEED = 4, 3.2 -- pixels up and down, radians a second (each tile a little later)
local SKIN_SPIN = 1.2 -- radians a second the skin turns in its picture
local FREE_FOR = 0.6 -- seconds the screen stays free of windows before it pops up
local WAIT_RETRY = 4 -- seconds before asking again when the rewards could not be read (GetRewards: 3 asks in 10 s)
local ASK_TRIES = 8
local WINDOWS_WAIT = 25 -- seconds at most it waits for the join's other windows; then it shows over them
local ON_TOP = 12 -- its ScreenGui's DisplayOrder when it shows (windows are 5)

local gui = Instance.new("ScreenGui")
gui.Name = "EventAd"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function label(parent, text, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = FONT
	l.Text = text
	l.TextColor3 = color or Color3.new(1, 1, 1)
	l.TextStrokeTransparency = 0.35
	l.TextScaled = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = textSize
	most.Parent = l
	l.Size = size
	l.Position = pos
	l.Parent = parent
	return l
end

local function button(parent, text, color, size, pos)
	local b = Instance.new("TextButton")
	b.BackgroundColor3 = color
	b.Font = FONT
	b.Text = text
	b.TextColor3 = Color3.new(1, 1, 1)
	b.TextScaled = true
	local most = Instance.new("UITextSizeConstraint")
	most.MaxTextSize = 17
	most.Parent = b
	b.Size = size
	b.Position = pos
	b.Parent = parent
	corner(b, 10)
	local edge = Instance.new("UIStroke")
	edge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	edge.Color = Color3.new(1, 1, 1)
	edge.Thickness = 2
	edge.Parent = b
	return b
end

local card = Instance.new("Frame")
card.AnchorPoint = Vector2.new(0.5, 0.5)
card.Position = UDim2.fromScale(0.5, 0.5)
card.Size = CARD_SIZE
card.BackgroundColor3 = COLOR_BG
card.Visible = false
card.Parent = gui
corner(card, 16)

-- the lively background (as the starter pack's, Robux client): under the words and only moving while it is up
local glow = Instance.new("CanvasGroup") -- (clips the rays to the rounded card)
glow.Size = UDim2.fromScale(1, 1)
glow.BackgroundColor3 = Color3.new(1, 1, 1)
glow.ZIndex = 0
glow.Active = false
glow.ClipsDescendants = true
glow.Name = "Glow"
glow.Parent = card
corner(glow, 16)
local colors = Instance.new("UIGradient")
colors.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, COLORS[1]), ColorSequenceKeypoint.new(0.5, COLORS[2]),
	ColorSequenceKeypoint.new(1, COLORS[3]) })
colors.Parent = glow
local rays = Instance.new("Frame")
rays.AnchorPoint = Vector2.new(0.5, 0.5)
rays.Position = UDim2.fromScale(0.5, 0.4)
rays.Size = UDim2.fromOffset(760, 760)
rays.BackgroundTransparency = 1
rays.Parent = glow
for k = 1, RAYS do
	local ray = Instance.new("Frame")
	ray.AnchorPoint = Vector2.new(0.5, 0.5)
	ray.Position = UDim2.fromScale(0.5, 0.5)
	ray.Size = UDim2.new(0, 28, 1, 0)
	ray.Rotation = k * 180 / RAYS
	ray.BackgroundColor3 = RAY_COLOR
	ray.BackgroundTransparency = RAY_TRANSPARENCY
	ray.BorderSizePixel = 0
	local fade = Instance.new("UIGradient") -- bright in the middle, gone at the ends
	fade.Rotation = 90
	fade.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0),
		NumberSequenceKeypoint.new(1, 1) })
	fade.Parent = ray
	ray.Parent = rays
end
local veil = Instance.new("Frame")
veil.Size = UDim2.fromScale(1, 1)
veil.BackgroundColor3 = Color3.new(0, 0, 0)
veil.BackgroundTransparency = 1 - SHADE
veil.BorderSizePixel = 0
veil.Parent = glow
local shine = Instance.new("Frame")
shine.AnchorPoint = Vector2.new(0.5, 0.5)
shine.Size = UDim2.new(0, 60, 2, 0)
shine.Rotation = 20
shine.BackgroundColor3 = Color3.new(1, 1, 1)
shine.BackgroundTransparency = 0.75
shine.BorderSizePixel = 0
shine.Position = UDim2.fromScale(-0.3, 0.5)
shine.Parent = glow
local sparkles = {}
for k = 1, SPARKLES do
	local star = Instance.new("TextLabel")
	star.BackgroundTransparency = 1
	star.Text = k % 3 == 0 and "★" or "✦"
	star.TextColor3 = SPARKLE_COLORS[k % #SPARKLE_COLORS + 1]
	star.Font = Enum.Font.GothamBold
	star.TextSize = math.random(10, 20)
	star.Size = UDim2.fromOffset(20, 20)
	star.AnchorPoint = Vector2.new(0.5, 0.5)
	star:SetAttribute("KeepText", true)
	star.Parent = glow
	table.insert(sparkles, { label = star, x = math.random(), y = math.random(), speed = 0.04 + math.random() * 0.08,
		phase = math.random() * math.pi * 2 })
end
local stroke = Instance.new("UIStroke")
stroke.Color = Color3.new(1, 1, 1)
stroke.Thickness = 3
stroke.Parent = card
local edge = Instance.new("UIGradient") -- the edge shimmers round in gold, pink and blue
edge.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, EDGE_COLORS[1]), ColorSequenceKeypoint.new(0.33, EDGE_COLORS[2]),
	ColorSequenceKeypoint.new(0.66, EDGE_COLORS[3]), ColorSequenceKeypoint.new(1, EDGE_COLORS[1]) })
edge.Parent = stroke

local e = Config.LaunchEvent
local title = label(card, "🎉 런칭 기념 이벤트!", UDim2.new(1, -40, 0, 32), UDim2.fromOffset(20, 10), 24, GOLD)
title.TextStrokeTransparency = 0.2
local beat = Instance.new("UIScale") -- the title beats gently
beat.Parent = title
label(card, string.format("임무 %d개를 깨면 선물이 쏟아져요!", #e.Missions), UDim2.new(1, -30, 0, 22), UDim2.fromOffset(15, 44), 16)

-- the prizes in all: the skin, the special keys every mission and the all-done reward give, then keys and money
local totals = {}
local function addKeys(reward)
	for id, n in pairs(reward.SpecialKeys or {}) do
		totals[id] = (totals[id] or 0) + n
	end
end
for _, m in ipairs(e.Missions) do
	addKeys(m.Reward)
end
addKeys(e.AllReward)
local tiles = {} -- { frame, base y }
local skinPicture = nil
local function tile(index, count, makePicture, text)
	local width = count * TILE + (count - 1) * TILE_GAP
	local holder = Instance.new("Frame")
	holder.BackgroundColor3 = COLOR_TILE
	holder.BackgroundTransparency = 0.82
	holder.Size = UDim2.fromOffset(TILE, TILE)
	holder.Position = UDim2.new(0.5, -width / 2 + (index - 1) * (TILE + TILE_GAP), 0, TILE_TOP)
	holder.Parent = card
	corner(holder, 12)
	local ring = Instance.new("UIStroke")
	ring.Color = GOLD
	ring.Thickness = 2
	ring.Parent = holder
	local picture = makePicture(UDim2.fromOffset(TILE - 8, TILE - 8))
	picture.AnchorPoint = Vector2.new(0.5, 0.5)
	picture.Position = UDim2.fromScale(0.5, 0.5)
	picture.Parent = holder
	local name = label(holder, text, UDim2.new(1, 16, 0, 18), UDim2.new(0, -8, 1, 3), 13, GOLD)
	name.TextStrokeTransparency = 0.2
	table.insert(tiles, holder)
	return picture
end
local prizes = {}
local skin = e.AllReward.Skin and Formulas.skin(e.AllReward.Skin)
table.insert(prizes, { function(size)
	local models = ReplicatedStorage:FindFirstChild("SlapModels")
	local model = skin and models and models:FindFirstChild(skin.Model)
	if model then
		skinPicture = DinoPortrait.ofModel(model, size)
		return skinPicture
	end
	local hand = label(nil, "👋", size, UDim2.new(), 40)
	return hand
end, "전용 장갑" })
for _, t in ipairs({ { "Ruby", "루비 ×%d" }, { "Gold", "황금 ×%d" }, { "Silver", "은 ×%d" } }) do
	if (totals[t[1]] or 0) > 0 then
		table.insert(prizes, { function(size)
			return DinoPortrait.key(t[1], size)
		end, string.format(t[2], totals[t[1]]) })
	end
end
table.insert(prizes, { function(size)
	return label(nil, "🔑💰", size, UDim2.new(), 30)
end, "열쇠·돈 듬뿍" })
for i, p in ipairs(prizes) do
	tile(i, #prizes, p[1], p[2])
end

label(card, string.format("🏷️ 머리 위 칭호 %s", e.Title), UDim2.new(1, -30, 0, 22), UDim2.fromOffset(15, TILE_TOP + TILE + 24), 15)
-- the missions done (filled in when it shows)
local barBack = Instance.new("Frame")
barBack.BackgroundColor3 = COLOR_BAR_BACK
barBack.Size = UDim2.new(1, -60, 0, 22)
barBack.Position = UDim2.fromOffset(30, TILE_TOP + TILE + 48)
barBack.Parent = card
corner(barBack, 11)
local bar = Instance.new("Frame")
bar.BackgroundColor3 = COLOR_BAR
bar.Size = UDim2.fromScale(0, 1)
bar.Parent = barBack
corner(bar, 11)
local barText = label(barBack, "", UDim2.fromScale(1, 1), UDim2.new(), 15)
barText.ZIndex = 2
label(card, "🎁 보상 창 → 🎉 이벤트에서 확인할 수 있어요", UDim2.new(1, -30, 0, 20), UDim2.fromOffset(15, TILE_TOP + TILE + 74), 14)
local go = button(card, "🎁 보러 가기", COLOR_GO, UDim2.fromOffset(128, 40), UDim2.new(0.5, -177, 1, -50))
-- (2026-10-04, "오늘 하루 안 보기 넣어줘도 되고") not again today (saved: Net request HideAdToday)
local today = button(card, "🙈 오늘 하루 안 보기", COLOR_LATER, UDim2.fromOffset(118, 40), UDim2.new(0.5, -41, 1, -50))
local later = button(card, "나중에", COLOR_LATER, UDim2.fromOffset(92, 40), UDim2.new(0.5, 85, 1, -50))
Windows.fit(card, { Cover = "Big" })
Windows.register(card)

local function close()
	card.Visible = false
	player:SetAttribute("EventAdUp", nil)
end
card:GetPropertyChangedSignal("Visible"):Connect(function()
	if not card.Visible then
		player:SetAttribute("EventAdUp", nil) -- (closed by its X too)
	end
end)
go.Activated:Connect(function()
	close()
	player:SetAttribute("OpenRewardsTab", "Event")
end)
later.Activated:Connect(close)
today.Activated:Connect(function()
	close()
	Net.request("HideAdToday", "Event")
end)

local lastSparkle = nil
RunService.RenderStepped:Connect(FrameMeter.wrap("EventAd", function()
	if not card.Visible then
		return
	end
	local t = os.clock()
	rays.Rotation = (t * RAY_TURN) % 360
	colors.Rotation = (t * GRADIENT_TURN) % 360
	edge.Rotation = (t * GRADIENT_TURN * 3) % 360
	local sweep = (t % SHINE_EVERY) / SHINE_EVERY -- across in the first 40%, then a rest
	shine.Position = UDim2.fromScale(-0.3 + math.min(sweep / 0.4, 1) * 1.6, 0.5)
	beat.Scale = 1 + 0.06 * math.sin(t * 5)
	local dt = t - (lastSparkle or t)
	lastSparkle = t
	for _, sp in ipairs(sparkles) do
		sp.y -= sp.speed * dt
		if sp.y < -0.05 then
			sp.y, sp.x = 1.05, math.random()
		end
		sp.label.Position = UDim2.fromScale(sp.x + math.sin(t * 1.3 + sp.phase) * 0.02, sp.y)
		sp.label.TextTransparency = 0.25 + 0.6 * (0.5 + 0.5 * math.sin(t * 4 + sp.phase))
		sp.label.Rotation = (t * 60 + sp.phase * 50) % 360
	end
	for i, holder in ipairs(tiles) do
		local base = holder.Position
		holder.Position = UDim2.new(base.X.Scale, base.X.Offset, 0, TILE_TOP - math.abs(math.sin(t * TILE_BOUNCE_SPEED - i * 0.5)) * TILE_BOUNCE)
	end
	local camera = skinPicture and skinPicture.CurrentCamera
	local model = skinPicture and skinPicture:FindFirstChildOfClass("Model")
	if camera and model then -- the skin turns slowly in its picture
		model:PivotTo(CFrame.new(model:GetPivot().Position) * CFrame.Angles(0, t * SKIN_SPIN, 0))
	end
end))

-- (2026-10-04, "왜 이벤트 미션 광고창 안 뜨냐고 … 몇 번을 말했냐") this screen starts it after joining (it waited for a
-- push from the server, and asked GetRewards once: on joining the 🎁 window's own asks used up GetRewards' limit (3 in 10 s),
-- the answer came back empty and it quietly gave up). Now: once free of the join's steps (language, the tutorial),
-- AdSeconds on, it waits for the other windows (news, attendance, the first draw) at most WINDOWS_WAIT seconds, then
-- asks - again every WAIT_RETRY seconds until it gets an answer - and shows on top of anything (the server's Event.Ad;
-- why not, if not, in the output). Net push EventAd (Studio ;eventad) shows it whatever the server says.
local function busy()
	return Windows.anyOpen() or player:GetAttribute("TutorialStep")
		or player:GetAttribute("LaunchGiftUp") or player:GetAttribute("CocoIntro") or player:GetAttribute("FirstFight") or (player:GetAttribute("DefenseLevel") or 1) < 2
		or player:GetAttribute("FreshStart")
end
local function joining()
	return player:GetAttribute("TutorialStep") or player:GetAttribute("LanguagePick") or player:GetAttribute("TutorialAsk")
		or player:GetAttribute("TutorialTravel") or not player.Character
end
local showing = false
local function show(force)
	if showing then
		return
	end
	showing = true
	player:SetAttribute("EventAdUp", true) -- (the starter pack's offer waits behind it)
	local waited = os.clock()
	while player.Parent and (busy() or os.clock() - waited < FREE_FOR) and os.clock() - waited < WINDOWS_WAIT do
		task.wait(0.5)
	end
	local ev = nil
	for _ = 1, ASK_TRIES do
		local ok, data = pcall(Net.ask, "GetRewards")
		if ok and type(data) == "table" and type(data.Event) == "table" then
			ev = data.Event
			break
		end
		task.wait(WAIT_RETRY)
	end
	if not ev or not (force or ev.Ad) or not player.Parent then
		print("[EventAd] 이벤트 광고 안 띄움: " .. tostring(ev and ev.AdWhy or "보상 정보를 못 받음"))
		player:SetAttribute("EventAdUp", nil)
		showing = false
		return
	end
	local done = 0
	for _, m in ipairs(ev.Missions) do
		if m.Progress >= m.Target then
			done += 1
		end
	end
	barText.Text = string.format("✅ 완료 %d / %d", done, #ev.Missions)
	bar.Size = UDim2.fromScale(done / math.max(1, #ev.Missions), 1)
	lastSparkle = nil
	gui.DisplayOrder = ON_TOP -- (over a window still open)
	card.Visible = true
	Sfx.play("GachaBig")
	showing = false
end

Net.onPush("EventAd", function()
	show(true)
end)
task.spawn(function()
	if ReplicatedStorage:GetAttribute("TutorialField") then
		return -- (a tutorial field: never)
	end
	while player.Parent and joining() do
		task.wait(1)
	end
	task.wait(Config.LaunchEvent.AdSeconds)
	local waited = os.clock()
	while player.Parent and player:GetAttribute("StarterDone") == nil and player:GetAttribute("StarterStep") == nil
		and os.clock() - waited < STARTER_WAIT do
		task.wait(1)
	end
	if not player:GetAttribute("StarterDone") then
		return
	end
	show(false)
end)
