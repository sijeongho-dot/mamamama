--[[
AntiFling (2026-10-02, "빠른속도로 물체에 부딪히면 높게 점프되는 버그가 보임", and MoveGuard's "moved 41.7 studs in
0.52s, moved back" while jumping on a fence): running fast (speed pads, weather, potions) into a part's edge
can make Roblox's physics throw the character far up and away. That was never meant, and the server then
pulled the player back. Every frame after the physics this player's own character is held to what walking
and jumping can do: up no faster than its jump, sideways no faster than MAX_SIDE_FACTOR × its walk speed.

Left alone: a slap's (or a lightning bolt's, a wild dino's) throw and its groggy time (CombatFx's Knockback
sets Humanoid.PlatformStand), riding (flying mounts push the body themselves) and racing (Race service
bounces). Display side only: the server's MoveGuard still checks every move.
]]

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local FrameMeter = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("FrameMeter")) -- (2026-10-04: the screen's per-frame time, PerfCheck)
local Workspace = game:GetService("Workspace")

local player = Players.LocalPlayer

-- how the body moves (not a game rule)
local JUMP_SLACK = 1.15 -- up to this times the character's own jump speed (a jump's start is a little over)
local MAX_SIDE_FACTOR = 1.6 -- sideways up to this times the walk speed (a slope, a step)
local MIN_SIDE_SPEED = 24 -- studs a second always allowed sideways (a slow character falling off a ledge)

local function jumpSpeed(humanoid)
	if humanoid.UseJumpPower then
		return humanoid.JumpPower
	end
	return math.sqrt(2 * Workspace.Gravity * humanoid.JumpHeight)
end

RunService.Heartbeat:Connect(FrameMeter.wrap("AntiFling", function()
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not humanoid or not root or humanoid.PlatformStand or humanoid.Sit or humanoid.Health <= 0
		or player:GetAttribute("Riding") or player:GetAttribute("Racing") then
		return
	end
	local v = root.AssemblyLinearVelocity
	local maxUp = jumpSpeed(humanoid) * JUMP_SLACK
	local side = Vector3.new(v.X, 0, v.Z)
	local maxSide = math.max(humanoid.WalkSpeed * MAX_SIDE_FACTOR, MIN_SIDE_SPEED)
	local y = v.Y
	local changed = false
	if y > maxUp then
		y = maxUp
		changed = true
	end
	if side.Magnitude > maxSide then
		side = side.Unit * maxSide
		changed = true
	end
	if changed then
		root.AssemblyLinearVelocity = Vector3.new(side.X, y, side.Z)
		root.AssemblyAngularVelocity = Vector3.zero -- (a throw also spins the body)
	end
end))
