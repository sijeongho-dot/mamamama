--[[
Main: starts every server service, in order. Each service lives in ServerScriptService.Services.
Rules (CLAUDE.md): the server decides everything that involves money, keys, draws, mining, hits and
placement; clients only send requests through Shared.Net.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))
local Services = script.Parent:WaitForChild("Services")

Net.init() -- create every remote before any client looks for one

-- (2026-10-02, "왼쪽 스틱 조작하면서 스마트폰 화면 돌리면 시점이 돌아가야하는데 왜 시점이 커졌다 작아졌다"):
-- Roblox's camera pulled in close whenever a tree, fence, stall or sign came between it and the character
-- and went back out once past it, so turning the view while walking zoomed in and out. Now what is in the
-- way turns see-through instead (Invisicam) and the camera keeps its distance. (Copied to each player as
-- they join: set before anyone is in.)
game:GetService("StarterPlayer").DevCameraOcclusionMode = Enum.DevCameraOcclusionMode.Invisicam

-- one service failing to start (e.g. a missing model) is reported but never stops the ones after it
local function start(name)
	local ok, err = xpcall(function()
		require(Services:WaitForChild(name)).init()
	end, debug.traceback)
	if not ok then
		warn(string.format("[Main] %s 시작 중 오류: %s", name, tostring(err)))
	end
end

start("Watchdog") -- first: watches for server stalls and writes client errors to the log
start("AssetSwap") -- before anything reads ServerStorage.Assets: remodeled Dino_<Species>1 replace the old ones
start("Grass")
start("Policy")
start("PlayerData")
start("Rewards") -- before the services that report mission progress
start("Story")
start("BetaLog") -- (2026-10-02) the update news, bug reports, script errors kept by the day
start("LaunchGift") -- (2026-10-04) the launch gift dino, once a player
start("Season") -- (2026-10-02) the season pass: XP from play and from the rewards taken (after Rewards)
start("Friends")
start("Analytics") -- after PlayerData and Rewards (their events); sends nothing the game needs
start("Bases")
start("TreeClimb") -- (2026-10-04) climbable trees: the part trees' leaves let climbers through, palm tops (MoveGuard asks it)
start("MoveGuard")
start("Minerals")
start("Deposit")
start("Shop")
start("Training")
start("Weather")
start("Defense")
start("MoneyPile")
start("Farm")
start("Enhance")
start("OwnerSigns")
start("Leaderboards") -- the all-server ranking for the central board
start("MineralGuide")
start("DefenseGuide") -- the defense rewards board beside the defense sign
start("PlaceBoards") -- (2026-10-04) the arena's and the farm's places as pictures, beside their slot signs; after Defense and Farm
start("StreetLamps")
start("Bombs") -- after Shop (its stall beside the shop), before Npcs (its keeper); its blasts use Combat and Zombies later
start("Npcs") -- after Shop and Enhance: it stands in their stalls (and Bombs')
start("Ride")
start("Unlocks")
start("Race") -- after MoveGuard and Ride
start("Wildlife")
start("Limited") -- this week's limited dino (its attributes, before Gacha draws)
start("Gacha")
start("Boxes")
start("Settings")
start("Keys")
start("SpeedPads")
start("Treasure")
start("Poop")
start("Combat")
start("Fruits") -- (2026-10-02) 공룡 사육's fruit: after Combat (its slap hooks), before Tutorial (its tree step)
start("Skins")
start("Bell")
start("DayNight")
start("Zombies") -- after Combat and DayNight
start("HideSeek") -- (2026-10-03) 🙈 hide-and-seek; after Combat (its tag hook), Keys, Minerals and MoveGuard
start("Lightning") -- storm bolts; after Zombies (it throws them) and MoveGuard
start("Practice")
start("Monetization") -- after PlayerData, Rewards (its events), Policy and MoveGuard; owns MarketplaceService.ProcessReceipt
start("FenceLook") -- a reborn owner's base fence in the tier's crystal; after Bases
start("Community") -- the community (group) reward sign in every base; after Bases and Rewards
start("HomeTeleport")
start("Tutorial") -- after the services whose events and hooks it follows (Rewards, Gacha, Combat, Keys)
start("StarterMissions") -- after Rewards (its events) and Friends
start("Notify")
start("TestCommands") -- does nothing outside Studio

print("[Main] 서버 준비 완료")
