--[[
Bell: a player rings their bell to show everyone where they are (the 🔔 button, StarterPlayerScripts/
Bell). Net request RingBell: checked here, at most once every Config.Bell.Cooldown seconds (kept by
UserId, so leaving and rejoining does not reset it); then Net push BellPing(userId, position) to
everyone, who hear the bell and see a mark standing there for Config.Bell.MarkSeconds. The player
attribute BellReadyAt (server time) lets the button count down. Each player in the server gets a bell
slot of their own (player attribute BellSlot: the lowest one nobody here has), so no two bells look alike
(the client turns the slot into a color).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))

local Bell = {}

local lastRing = {} -- [UserId] = server time of the last ring

local function ring(player)
	local now = Workspace:GetServerTimeNow()
	if now - (lastRing[player.UserId] or -math.huge) < Config.Bell.Cooldown then
		return
	end
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end
	lastRing[player.UserId] = now
	player:SetAttribute("BellReadyAt", now + Config.Bell.Cooldown)
	Net.pushAll("BellPing", player.UserId, root.Position, player:GetAttribute("BellSlot"))
	Rewards.add(player, "Bell", 1) -- daily missions
end

local function giveSlot(player)
	local taken = {}
	for _, other in ipairs(Players:GetPlayers()) do
		local slot = other ~= player and other:GetAttribute("BellSlot")
		if slot then
			taken[slot] = true
		end
	end
	local slot = 1
	while taken[slot] do
		slot += 1
	end
	player:SetAttribute("BellSlot", slot)
end

-- (2026-10-03, "일정시간마다 종울리기가 숨는자들에게 강제된다든지") the HideSeek service rings a hider's bell for them:
-- the same ping everyone sees and hears, no cooldown and no mission count
-- (to: a list of players to show it to, everyone when left out)
function Bell.force(player, to, at, area)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end
	local where = at or root.Position
	if to then
		for _, p in ipairs(to) do
			Net.push(p, "BellPing", player.UserId, where, player:GetAttribute("BellSlot"), area)
		end
	else
		Net.pushAll("BellPing", player.UserId, where, player:GetAttribute("BellSlot"), area)
	end
end

function Bell.init()
	Net.onRequest("RingBell", {}, ring)
	for _, player in ipairs(Players:GetPlayers()) do
		giveSlot(player)
	end
	Players.PlayerAdded:Connect(function(player)
		giveSlot(player)
		local last = lastRing[player.UserId]
		if last then
			player:SetAttribute("BellReadyAt", last + Config.Bell.Cooldown)
		end
	end)
end

return Bell
