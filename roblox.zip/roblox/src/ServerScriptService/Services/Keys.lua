local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local RarityFx = require(Shared:WaitForChild("RarityFx"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local Boxes = require(script.Parent:WaitForChild("Boxes"))
local Story = require(script.Parent:WaitForChild("Story"))

local Keys = {}

local KEY_HEIGHT = 2
local KEY_MATERIALS = {
	Silver = Enum.Material.SmoothPlastic, Ruby = Enum.Material.Glass, Diamond = Enum.Material.Glass,
	Rainbow = Enum.Material.Neon,
}
local KEY_HEIGHT_PER_GRADE = 0.25
local GREY_KEY = Vector3.new(0.6, 1.8, 0.3)
local NORMAL_COLOR = Color3.fromRGB(255, 205, 60)
local BOX_EDGE_SMALLEST = 1.2
local BOX_EDGE_BIGGEST = 5.2
local BOX_BODY_HEIGHT = 0.8
local LID_HEIGHT = 0.22
local LID_WIDER = 1.08
local RIBBON_SHARE = 0.16
local RIBBON_OVER = 0.05
local RIBBON_COLOR = Color3.fromRGB(255, 250, 240)
local LID_DARKEN = 0.25
local KING_EDGE = 3.2
local SHINY_FROM = "Legendary"
local BEAM_FROM = "Epic"
local HOVER = 0.15
local CARRY_SCALE = 0.45
local CARRY_EDGE_MIN = 0.9
local CARRY_EDGE_MAX = 2.2
local CARRY_ABOVE = 1.6
local CARRY_GAP = 0.1
local CARRY_LABEL_HEIGHT = 1.2
local KING_MARK_SIZE = UDim2.fromOffset(56, 56)
local KING_MARK_HEIGHT = 6.5
local KING_MARK_DISTANCE = 5000
local MARKER_HEIGHT = 1.4
local MARKER_DISTANCE = 400
local MARKER_SIZE = UDim2.fromOffset(150, 26)
local BEAM_HEIGHT, BEAM_WIDTH = 300, 2
local ALTAR_TITLE_COLOR = Color3.fromRGB(255, 215, 90)
local ALTAR_CLEARANCE = 2
local ALTAR_RAY_FROM = 300
local ALTAR_PUSH_TRIES = 12
local ALTAR_PUSH_STEP = 2
local ALTAR_TITLE_HEIGHT = 28
local AURA_COLOR = Color3.fromRGB(255, 205, 60)
local SCATTER_FROM = 4
local SCATTER_TRIES = 6
local OPEN_SKY = 1
local PICKUP_MIN = 3
local BOX_COLORS = {
	Common = Color3.fromRGB(170, 170, 170), Uncommon = Color3.fromRGB(90, 200, 90), Rare = Color3.fromRGB(70, 140, 255),
	Epic = Color3.fromRGB(170, 90, 230), Legendary = Color3.fromRGB(255, 150, 40), Mythic = Color3.fromRGB(240, 60, 60),
	Transcendent = Color3.fromRGB(255, 100, 200), Rainbow = Color3.fromRGB(120, 230, 255), Golden = Color3.fromRGB(255, 210, 60),
	Onyx = Color3.fromRGB(60, 40, 90), Celestial = Color3.fromRGB(245, 245, 255), Secret = Color3.fromRGB(255, 240, 150),
	Cosmic = Color3.fromRGB(110, 90, 240), Primeval = Color3.fromRGB(255, 160, 40), Divine = Color3.fromRGB(255, 245, 200),
}
local RAINBOW_RARITIES = { Rainbow = true, Secret = true, Divine = true }

local TYPES = Config.Keys.Types
local A = Config.AltarBoxes
local folder = nil
local announcedFirst = false
local sinceDrop = 0
local ground = {}
local carried = {}
local lastSaid = {}
local rng = Random.new()

local function random()
	return rng:NextNumber()
end

local function say(player, text)
	Net.push(player, "Notice", "🎁 선물상자", text)
end

local function sayOnce(player, key, gap, text)
	local said = lastSaid[player] or {}
	lastSaid[player] = said
	if os.clock() - (said[key] or -math.huge) >= gap then
		said[key] = os.clock()
		say(player, text)
	end
end

local function keyColor(kind)
	local t = Formulas.keyType(kind)
	return t.Rgb and Color3.fromRGB(table.unpack(t.Rgb)) or NORMAL_COLOR
end

local function gradeNumber(kind)
	return Formulas.keyType(kind .. "#")
end

local function rank(rarityId)
	return Formulas.rarityRank(rarityId)
end

local function boxColor(box)
	if box.King then
		return Color3.fromRGB(table.unpack(A.KingRgb))
	end
	return BOX_COLORS[box.Rarity] or RarityFx.color(box.Rarity) or BOX_COLORS.Common
end

local function boxName(box)
	if box.King then
		return Config.Keys.King.Name
	end
	local r = Formulas.rarity(box.Rarity)
	local s = Formulas.dinoSize(box.Size)
	return string.format("🎁 %s · %s%s", r and r.Name or box.Rarity, s and s.Name or box.Size, box.Mutation and " ✨" or "")
end

local function rare(box)
	return not box.King and rank(box.Rarity) >= rank(A.RareFrom)
end

local function groundAt(x, z, fromY)
	local params = RaycastParams.new()
	local ignore = { folder }
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	params.FilterDescendantsInstances = ignore
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true
	local top = fromY or 300
	local hit = Workspace:Raycast(Vector3.new(x, top, z), Vector3.new(0, -top - 300, 0), params)
	return hit and hit.Position.Y or 0, hit ~= nil
end

local function boxEdge(box)
	if box.King then
		return KING_EDGE
	end
	local r = Formulas.dinoSizeRank(box.Size)
	r = r > 0 and r or Formulas.dinoSizeRank("Young")
	return BOX_EDGE_SMALLEST + (BOX_EDGE_BIGGEST - BOX_EDGE_SMALLEST) * (r - 1) / math.max(#Config.Sizes - 1, 1)
end

local function newPart(parent, name, color, material)
	local p = Instance.new("Part")
	p.Name = name
	p.Color = color
	p.Material = material or Enum.Material.SmoothPlastic
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Parent = parent
	return p
end

local function boxModel(box, edge)
	local color = boxColor(box)
	local shiny = box.King or rank(box.Rarity) >= rank(SHINY_FROM)
	local model = Instance.new("Model")
	model.Name = "GiftBox"
	local bodyH, lidH = edge * BOX_BODY_HEIGHT, edge * LID_HEIGHT
	local h = bodyH + lidH
	local w, across = edge * RIBBON_SHARE, edge * LID_WIDER + RIBBON_OVER
	local body = newPart(model, "Body", color)
	body.Size = Vector3.new(edge, bodyH, edge)
	body.CFrame = CFrame.new(0, bodyH / 2, 0)
	local lid = newPart(model, "Lid", color:Lerp(Color3.new(), LID_DARKEN), shiny and Enum.Material.Neon or nil)
	lid.Size = Vector3.new(edge * LID_WIDER, lidH, edge * LID_WIDER)
	lid.CFrame = CFrame.new(0, bodyH + lidH / 2, 0)
	local ribbonX = newPart(model, "RibbonX", RIBBON_COLOR)
	ribbonX.Size = Vector3.new(across, h + RIBBON_OVER, w)
	ribbonX.CFrame = CFrame.new(0, h / 2, 0)
	local ribbonZ = newPart(model, "RibbonZ", RIBBON_COLOR)
	ribbonZ.Size = Vector3.new(w, h + RIBBON_OVER, across)
	ribbonZ.CFrame = CFrame.new(0, h / 2, 0)
	if not box.King and RAINBOW_RARITIES[box.Rarity] then
		model:SetAttribute("Rainbow", true)
	end
	model.PrimaryPart = body
	model.WorldPivot = CFrame.new()
	return model, h
end

local function total(list)
	return list and #list or 0
end

function Keys.carried(player)
	return total(carried[player])
end

function Keys.carriedFor(player)
	local n = 0
	for _, b in ipairs(carried[player] or {}) do
		if b.onlyFor == player then
			n += 1
		end
	end
	return n
end

local function chaseBox(list)
	local bestR, bestS, best = nil, nil, -1
	for _, b in ipairs(list or {}) do
		local r, s = Formulas.boxChase(b)
		local v = Formulas.guardianSpeed(r, s)
		if v > best then
			bestR, bestS, best = r, s, v
		end
	end
	return bestR, bestS
end

function Keys.chaseOf(player)
	return chaseBox(carried[player])
end

function Keys.escapeText(player)
	local r, s = chaseBox(carried[player])
	local profile = PlayerData.get(player)
	if not r or not profile then
		return nil
	end
	local need = Formulas.guardianEscapeLevel(r, s, player:GetAttribute("CarrySlow"))
	local mine = Formulas.trainShownOf("MoveSpeed", Formulas.trained(profile.Upgrades, profile.Training).MoveSpeed)
	if need == nil then
		return "🛡️ 이 상자 지킴이는 너무 빨라요! 👋 찰싹으로 막으며 가요"
	elseif need > mine then
		return string.format("🛡️ 지킴이가 더 빨라요! 👟 이동속도 Lv %d부터 도망쳐요 (지금 Lv %d)", need, mine)
	end
	return nil
end

local function carryText(list)
	if #list == 0 then
		return ""
	end
	local best = list[1]
	for _, b in ipairs(list) do
		if b.King or (not best.King and rank(b.Rarity) > rank(best.Rarity)) then
			best = b
		end
	end
	local name = boxName(best)
	return #list > 1 and string.format("%s +%d", name, #list - 1) or name
end

local function carryAura(player, on)
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end
	local outline = character:FindFirstChild("CarryAura")
	local glow = root:FindFirstChild("CarryGlow")
	if not on then
		if outline then
			outline:Destroy()
		end
		if glow then
			glow:Destroy()
		end
		return
	end
	if not outline then
		outline = Instance.new("Highlight")
		outline.Name = "CarryAura"
		outline.FillColor = AURA_COLOR
		outline.FillTransparency = 0.8
		outline.OutlineColor = AURA_COLOR
		outline.OutlineTransparency = 0
		outline.DepthMode = Enum.HighlightDepthMode.Occluded
		outline.Parent = character
	end
	if not glow then
		glow = Instance.new("Attachment")
		glow.Name = "CarryGlow"
		local light = Instance.new("PointLight")
		light.Color = AURA_COLOR
		light.Range = 14
		light.Brightness = 2
		light.Parent = glow
		local sparkles = Instance.new("ParticleEmitter")
		sparkles.Color = ColorSequence.new(AURA_COLOR, Color3.fromRGB(255, 250, 210))
		sparkles.Rate = 25
		sparkles.Lifetime = NumberRange.new(0.8, 1.3)
		sparkles.Speed = NumberRange.new(3, 6)
		sparkles.SpreadAngle = Vector2.new(35, 35)
		sparkles.EmissionDirection = Enum.NormalId.Top
		sparkles.Size = NumberSequence.new(0.5, 0)
		sparkles.LightEmission = 1
		sparkles.Parent = glow
		glow.Parent = root
	end
end

local function carryStack(player, list)
	local character = player.Character
	local head = character and character:FindFirstChild("Head")
	local old = character and character:FindFirstChild("CarryStack")
	if old then
		old:Destroy()
	end
	if not head or #list == 0 then
		return
	end
	local stack = Instance.new("Model")
	stack.Name = "CarryStack"
	local y = head.Size.Y / 2 + CARRY_ABOVE
	for i, b in ipairs(list) do
		local edge = math.clamp(boxEdge(b) * CARRY_SCALE, CARRY_EDGE_MIN, CARRY_EDGE_MAX)
		local model, h = boxModel(b, edge)
		local turn = CFrame.Angles(0, math.rad((i * 37) % 30 - 15), 0)
		model:PivotTo(head.CFrame * CFrame.new(0, y, 0) * turn)
		for _, part in ipairs(model:GetDescendants()) do
			if part:IsA("BasePart") then
				part.Anchored = false
				part.Massless = true
				local weld = Instance.new("WeldConstraint")
				weld.Part0, weld.Part1 = head, part
				weld.Parent = part
			end
		end
		model.Parent = stack
		y += h + CARRY_GAP
	end
	stack.Parent = character
end

local function setCarried(player, list)
	carried[player] = list
	local sizes, kings = {}, 0
	for _, b in ipairs(list) do
		if b.King then
			kings += 1
		end
		local _, s = Formulas.boxChase(b)
		table.insert(sizes, s)
	end
	player:SetAttribute("CarrySlow", #list > 0 and Formulas.boxCarrySpeed(sizes) or nil)
	player:SetAttribute("CarriedKing", kings)
	player:SetAttribute("CarriedKeys", #list)
	player:SetAttribute("CarriedBoxes", #list > 0 and carryText(list) or nil)
	carryAura(player, #list > 0)
	carryStack(player, list)
	local head = player.Character and player.Character:FindFirstChild("Head")
	local crown = head and head:FindFirstChild("KingMark")
	if head and kings > 0 and not crown then
		crown = Instance.new("BillboardGui")
		crown.Name = "KingMark"
		crown.Size = KING_MARK_SIZE
		crown.StudsOffsetWorldSpace = Vector3.new(0, KING_MARK_HEIGHT, 0)
		crown.AlwaysOnTop = true
		crown.MaxDistance = KING_MARK_DISTANCE
		local text = Instance.new("TextLabel")
		text.Size = UDim2.fromScale(1, 1)
		text.BackgroundTransparency = 1
		text.TextScaled = true
		text.Text = "👑"
		text.Parent = crown
		crown.Parent = head
	elseif crown and kings <= 0 then
		crown:Destroy()
	end
	local label = head and head:FindFirstChild("CarryLabel")
	if #list > 0 and head then
		if not label then
			label = Instance.new("BillboardGui")
			label.Name = "CarryLabel"
			label.Size = UDim2.fromOffset(160, 30)
			label.StudsOffsetWorldSpace = Vector3.new(0, CARRY_LABEL_HEIGHT, 0)
			label.SizeOffset = Vector2.new(0, 2)
			label.AlwaysOnTop = true
			label.PlayerToHideFrom = player
			local text = Instance.new("TextLabel")
			text.Size = UDim2.fromScale(1, 1)
			text.BackgroundTransparency = 1
			text.Font = Enum.Font.GothamBold
			text.TextScaled = true
			text.TextStrokeTransparency = 0
			text.Parent = label
			label.Parent = head
		end
		label.TextLabel.Text = carryText(list)
		label.TextLabel.TextColor3 = boxColor(list[#list])
	elseif label then
		label:Destroy()
	end
end

local publishRare

local function onGroundCount()
	local n = 0
	for _ in pairs(ground) do
		n += 1
	end
	return n
end

local function keyModel(kind)
	local t = Formulas.keyType(kind)
	local assets = ServerStorage:FindFirstChild("Assets")
	local source = assets and assets:FindFirstChild(t.Model, true)
	local model = Instance.new("Model")
	if source then
		source:Clone().Parent = model
		if t.Rgb and t.Id ~= "Gold" then
			for _, d in ipairs(model:GetDescendants()) do
				if d:IsA("BasePart") then
					d.Color = keyColor(kind)
					d.Material = KEY_MATERIALS[t.Id] or d.Material
					if d:IsA("MeshPart") then
						pcall(function()
							d.TextureID = ""
						end)
					end
				elseif d:IsA("SurfaceAppearance") or d:IsA("Decal") or d:IsA("Texture") then
					d:Destroy()
				end
			end
		end
	else
		local p = Instance.new("Part")
		p.Size = GREY_KEY
		p.Color = keyColor(kind)
		p.Material = Enum.Material.Neon
		p.Parent = model
	end
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position)
	model:ScaleTo((KEY_HEIGHT + KEY_HEIGHT_PER_GRADE * (gradeNumber(kind) - 1)) / math.max(size.Y, 0.1))
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
		end
	end
	return model
end

local pickUp

local function placeBox(x, z, box, dropped, blockedPlayer, groundY, taken, onlyFor, fall)
	if not dropped and not onlyFor and onGroundCount() >= Config.Keys.MaxOnGround then
		return nil
	end
	local edge = boxEdge(box)
	local model, h = boxModel(box, edge)
	local y = (groundY or groundAt(x, z)) + HOVER
	local part = Instance.new("Part")
	part.Name = "AltarBox"
	part.Anchored, part.CanCollide, part.CanQuery = true, false, false
	part.Transparency = 1
	part.Size = Vector3.new(math.max(edge, PICKUP_MIN), math.max(h, PICKUP_MIN), math.max(edge, PICKUP_MIN))
	part.CFrame = CFrame.new(x, y + h / 2, z)
	part:SetAttribute("Rarity", box.Rarity)
	part:SetAttribute("Size", box.Size)
	part:SetAttribute("Grade", box.Grade)
	part:SetAttribute("King", box.King or nil)
	part:SetAttribute("Mutation", box.Mutation)
	part:SetAttribute("FallAt", fall and Workspace:GetServerTimeNow() or nil)
	model:PivotTo(CFrame.new(x, y, z) * CFrame.Angles(0, rng:NextNumber(0, 2 * math.pi), 0))
	model.Parent = part
	local color = boxColor(box)
	local light = Instance.new("PointLight")
	light.Color = color
	light.Range = 8 + (box.King and 6 or math.min(rank(box.Rarity), 10))
	light.Parent = part
	if box.King or rank(box.Rarity) >= rank(SHINY_FROM) then
		local sparkle = Instance.new("Sparkles")
		sparkle.SparkleColor = color
		sparkle.Parent = part
	end
	local marker = Instance.new("BillboardGui")
	marker.Name = "BoxLabel"
	marker.Size = MARKER_SIZE
	marker.StudsOffsetWorldSpace = Vector3.new(0, h / 2 + MARKER_HEIGHT, 0)
	marker.MaxDistance = MARKER_DISTANCE
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBold
	text.TextScaled = true
	text.TextColor3 = color
	text.TextStrokeTransparency = 0
	text.Text = boxName(box)
	text.Parent = marker
	marker.Parent = part
	if box.King or rank(box.Rarity) >= rank(BEAM_FROM) then
		local beam = Instance.new("Part")
		beam.Name = "Beam"
		beam.Anchored, beam.CanCollide, beam.CanQuery, beam.CanTouch, beam.CastShadow = true, false, false, false, false
		beam.Material = Enum.Material.Neon
		beam.Transparency = 0.5
		beam.Color = color
		beam.Size = Vector3.new(BEAM_WIDTH, BEAM_HEIGHT, BEAM_WIDTH)
		beam.CFrame = CFrame.new(x, y + BEAM_HEIGHT / 2, z)
		beam.Parent = part
		if not box.King and RAINBOW_RARITIES[box.Rarity] then
			beam:SetAttribute("Rainbow", true)
		end
	end
	local now = os.clock()
	ground[part] = { box = box, dropped = dropped and now or nil, blocked = blockedPlayer, taken = taken, onlyFor = onlyFor,
		blockedUntil = blockedPlayer and now + Config.Keys.DropperPickupDelay or 0 }
	if onlyFor then
		part:SetAttribute("OnlyFor", onlyFor.UserId)
	end
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "TakeBox"
	prompt.ActionText = "🎁 꾹 눌러 가져가기"
	prompt.HoldDuration = A.HoldSeconds
	prompt.MaxActivationDistance = Config.Keys.PickupReach + part.Size.X / 2
	prompt.RequiresLineOfSight = false
	prompt.Parent = part
	prompt.Triggered:Connect(function(player)
		pickUp(player, part)
	end)
	part.Parent = folder
	if rare(box) then
		publishRare()
	end
	return part
end

local function levelOf(player)
	local profile = PlayerData.get(player)
	return profile and profile.DefenseLevel or 1
end

pickUp = function(player, part)
	local info = ground[part]
	local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	if not info or not humanoid or humanoid.Health <= 0 or not PlayerData.isLoaded(player) then
		return
	end
	if (info.blocked == player and os.clock() < info.blockedUntil) or (info.onlyFor and info.onlyFor ~= player)
		or (not info.onlyFor and player:GetAttribute("InTutorial")) then
		return
	end
	local root = player.Character:FindFirstChild("HumanoidRootPart")
	if not root or (root.Position - part.Position).Magnitude > Config.Keys.PickupReach + part.Size.X / 2 then
		return
	end
	if SafeZones.inSky(player, root.Position) then
		return
	end
	local box = info.box
	if not Formulas.boxPickable(box, levelOf(player)) then
		local n = Formulas.boxLockRebirths(box)
		sayOnce(player, "Lock", A.LockNoticeGap, string.format("🔒 %s 상자는 환생 %d번부터 가져갈 수 있어요!",
			Formulas.rarity(box.Rarity).Name, n))
		return
	end
	local list = table.clone(carried[player] or {})
	if #list >= A.MaxCarry then
		sayOnce(player, "Full", A.FullNoticeGap, A.MaxCarry == 1 and "🎁 상자는 하나씩만 들 수 있어요! 🏠 기지에 먼저 가져가요"
			or string.format("🎁 상자는 한 번에 %d개까지! 🏠 기지에 먼저 가져가요", A.MaxCarry))
		return
	end
	ground[part] = nil
	part:Destroy()
	box.onlyFor = info.onlyFor
	table.insert(list, box)
	setCarried(player, list)
	local hint = not box.onlyFor and Keys.escapeText(player)
	if hint then
		sayOnce(player, "Escape", A.EscapeNoticeGap, hint)
	end
	if info.taken or (info.blocked and info.blocked ~= player) then
		Rewards.add(player, "StealKeys", 1)
	end
	if box.King then
		Net.pushAll("Banner", string.format("👑 %s님이 왕 상자를 들었어요! 왕관을 쫓아가 찰싹!", player.DisplayName), "Gold")
	elseif rare(box) then
		Net.pushAll("Notice", "🎁 선물상자", string.format("%s님이 %s 상자를 들었어요!", player.DisplayName,
			Formulas.rarity(box.Rarity).Name))
	end
	publishRare()
end

local altarRim = 0
local altarX, altarZ = 0, 0
local altarParams = nil
local function offAltar(x, z)
	if not altarParams then
		return x, z
	end
	for _ = 1, ALTAR_PUSH_TRIES do
		if not Workspace:Raycast(Vector3.new(x, ALTAR_RAY_FROM, z), Vector3.new(0, -ALTAR_RAY_FROM * 2, 0), altarParams) then
			return x, z
		end
		local dx, dz = x - altarX, z - altarZ
		local d = math.sqrt(dx * dx + dz * dz)
		if d < 1e-3 then
			local angle = rng:NextNumber(0, 2 * math.pi)
			dx, dz, d = math.cos(angle), math.sin(angle), 1
		end
		x, z = altarX + dx / d * (d + ALTAR_PUSH_STEP), altarZ + dz / d * (d + ALTAR_PUSH_STEP)
	end
	return x, z
end
local function outsideAltar(x, z)
	local dx, dz = x - altarX, z - altarZ
	local d = math.sqrt(dx * dx + dz * dz)
	local least = altarRim > 0 and altarRim + ALTAR_CLEARANCE or 0
	if d >= least then
		return offAltar(x, z)
	end
	local angle = d > 1e-3 and math.atan2(dz, dx) or rng:NextNumber(0, 2 * math.pi)
	return offAltar(altarX + math.cos(angle) * least, altarZ + math.sin(angle) * least)
end

local function scatterPoint(position, radius)
	local angle = rng:NextNumber(0, 2 * math.pi)
	local r = rng:NextNumber(1, radius)
	return position.X + math.cos(angle) * r, position.Z + math.sin(angle) * r
end

local function keyZonePoint()
	local angle = rng:NextNumber(0, 2 * math.pi)
	local inner = math.min(altarRim > 0 and altarRim + ALTAR_CLEARANCE or 0, Config.Map.KeyZoneRadius - 1)
	local outer = Config.Map.KeyZoneRadius
	local r = math.sqrt(rng:NextNumber(inner * inner / (outer * outer), 1)) * outer
	return outsideAltar(altarX + math.cos(angle) * r, altarZ + math.sin(angle) * r)
end

function Keys.scatter(position, list, blocked, taken, onlyFor)
	for _, box in ipairs(list) do
		local x, z, y
		for _ = 1, SCATTER_TRIES do
			x, z = outsideAltar(scatterPoint(position, Config.Keys.ScatterRadius))
			local found
			y, found = groundAt(x, z, position.Y + SCATTER_FROM)
			local sky = groundAt(x, z)
			if not found then
				y = sky
			end
			if math.abs(sky - y) <= OPEN_SKY then
				break
			end
		end
		box.onlyFor = nil
		placeBox(x, z, box, true, blocked, y, taken, onlyFor)
	end
end

local function serverLuck()
	local on = (ReplicatedStorage:GetAttribute("ServerLuckUntil") or 0) > Workspace:GetServerTimeNow()
	local luck = on and (ReplicatedStorage:GetAttribute("ServerLuck") or 1) or 1
	return luck, Formulas.luckCap(nil, luck)
end

local function rollFor(level, grade)
	local luck, cap = serverLuck()
	return Formulas.altarBoxRoll(level, grade or "Normal", random, luck, cap)
end

local function patronLevel()
	local list = {}
	for _, p in ipairs(Players:GetPlayers()) do
		local profile = PlayerData.get(p)
		if profile then
			table.insert(list, profile.DefenseLevel)
		end
	end
	return #list > 0 and list[rng:NextInteger(1, #list)] or 1
end

local function altarBox(grade)
	if grade == "King" then
		return { King = true, Grade = "Normal", Size = Config.AltarBoxes.KingChase.Size }
	end
	return rollFor(patronLevel(), grade)
end

function Keys.rollBoxes(n)
	local list = {}
	for _ = 1, n do
		table.insert(list, altarBox("Normal"))
	end
	return list
end

function Keys.dropFor(player, position, count)
	local list = {}
	for _ = 1, count do
		table.insert(list, rollFor(levelOf(player), "Normal"))
	end
	Keys.scatter(position, list, nil, true, player)
end

function Keys.groundFor(player)
	local n = 0
	for _, info in pairs(ground) do
		if info.onlyFor == player then
			n += 1
		end
	end
	return n
end

function Keys.dropAll(player, position)
	local list = carried[player]
	local n = total(list)
	if n <= 0 then
		return 0
	end
	setCarried(player, {})
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	position = position or (root and root.Position)
	local mine, shared = {}, {}
	for _, b in ipairs(list) do
		table.insert(b.onlyFor and mine or shared, b)
	end
	if position then
		Keys.scatter(position, shared, player)
		if #mine > 0 then
			Keys.scatter(position, mine, nil, true, player)
		end
	end
	publishRare()
	return n
end

local function toAltar(box)
	local x, z = keyZonePoint()
	box.onlyFor = nil
	return placeBox(x, z, box, false, nil)
end

function Keys.returnBoxes(player, at)
	local list = carried[player]
	local n = total(list)
	if n <= 0 then
		return 0
	end
	setCarried(player, {})
	for _, b in ipairs(list) do
		if b.onlyFor and at then
			Keys.scatter(at, { b }, nil, true, b.onlyFor)
		elseif not b.onlyFor then
			toAltar(b)
		end
	end
	publishRare()
	return n
end

function Keys.groundKeys()
	local list = {}
	for part, info in pairs(ground) do
		if not info.onlyFor then
			local p = part.Position
			table.insert(list, { id = part, x = p.X, z = p.Z })
		end
	end
	return list
end

function Keys.grab(part)
	local info = ground[part]
	if not info then
		return nil
	end
	ground[part] = nil
	part:Destroy()
	publishRare()
	return info.box
end

local function clearRound()
	for part, info in pairs(ground) do
		if not info.onlyFor then
			ground[part] = nil
			part:Destroy()
		end
	end
	publishRare()
end

local function secondsToDrop()
	return math.max(0, Formulas.keySpawnInterval(#Players:GetPlayers()) - sinceDrop)
end

local function publishNextDrop()
	local at = Workspace:GetServerTimeNow() + secondsToDrop()
	local old = ReplicatedStorage:GetAttribute("NextKeyDrop")
	if not old or math.abs(old - at) > 1.5 then
		ReplicatedStorage:SetAttribute("NextKeyDrop", at)
	end
end

publishRare = function()
	local best, bestCarrier, bestValue = nil, nil, -1
	local function consider(box, carrier)
		if rare(box) then
			local value = rank(box.Rarity) * 100 + Formulas.dinoSizeRank(box.Size)
			if value > bestValue then
				best, bestCarrier, bestValue = box, carrier, value
			end
		end
	end
	for _, info in pairs(ground) do
		if not info.onlyFor then
			consider(info.box, nil)
		end
	end
	for player, list in pairs(carried) do
		for _, b in ipairs(list) do
			if not b.onlyFor then
				consider(b, player)
			end
		end
	end
	local text = best and string.format("%s|%s|%s|%d", best.Rarity, best.Size or "", best.Grade or "Normal",
		bestCarrier and bestCarrier.UserId or 0) or nil
	if ReplicatedStorage:GetAttribute("AltarRare") ~= text then
		ReplicatedStorage:SetAttribute("AltarRare", text)
	end
end

local function announceRare(list)
	local best = nil
	for _, b in ipairs(list) do
		if rare(b) and (not best or rank(b.Rarity) > rank(best.Rarity)) then
			best = b
		end
	end
	if best then
		Net.pushAll("Banner", string.format("✨ %s 상자가 제단에 떨어졌어요! ✨", Formulas.rarity(best.Rarity).Name), "Gold")
	end
end

local drops = 0
local function centralDrop(forceCount, big)
	drops += 1
	clearRound()
	local count, special = Formulas.centralDrop(rng:NextNumber(), rng:NextNumber())
	count = forceCount or (big and Config.Keys.BigDrop.Keys) or count
	local grades = {}
	for i = 1, count do
		grades[i] = (i == 1 and special) or "Normal"
	end
	if big then
		table.insert(grades, "Silver")
	end
	if count >= 2 then
		grades[count] = grades[count] == "Normal" and "King" or grades[count]
	end
	local placed, first, list = 0, nil, {}
	for _, grade in ipairs(grades) do
		local box = altarBox(grade)
		local x, z = keyZonePoint()
		local part = placeBox(x, z, box, false, nil, nil, nil, nil, true)
		if part then
			placed += 1
			first = first or part
			table.insert(list, box)
		end
	end
	if placed > 0 then
		local kings = 0
		for _, b in ipairs(list) do
			if b.King then
				kings += 1
			end
		end
		if big and kings > 0 then
			Story.showAll("BigDrop", Story.explain("BigDrop", placed - kings))
		else
			Story.showAll(big and "BigDrop" or "Drop", Story.explain(kings > 0 and "DropKing" or "Drop", placed - kings))
		end
		announceRare(list)
	end
	return placed, first
end

local function insideOwnBase(player, position)
	local base = Bases.folderOf(player)
	local zone = base and base:FindFirstChild("SafeZone")
	if not zone then
		return false
	end
	local p = zone.CFrame:PointToObjectSpace(position)
	return math.abs(p.X) <= zone.Size.X / 2 and math.abs(p.Z) <= zone.Size.Z / 2 and math.abs(p.Y) <= zone.Size.Y / 2
end
Keys.insideOwnBase = insideOwnBase

local lastPushNotice = {}
local function keepOutOfOtherBases(player, root)
	local index = SafeZones.baseAt(root.Position)
	if not index or index == Bases.of(player) then
		return
	end
	local base = Bases.folder(index)
	local zone = base and base:FindFirstChild("SafeZone")
	if not zone then
		return
	end
	local p = zone.CFrame:PointToObjectSpace(root.Position)
	local hx, hz, out = zone.Size.X / 2, zone.Size.Z / 2, Config.Keys.OtherBasePushOut
	local sides = {
		{ hx - p.X, Vector3.new(hx + out, p.Y, p.Z) }, { hx + p.X, Vector3.new(-hx - out, p.Y, p.Z) },
		{ hz - p.Z, Vector3.new(p.X, p.Y, hz + out) }, { hz + p.Z, Vector3.new(p.X, p.Y, -hz - out) },
	}
	table.sort(sides, function(a, b)
		return a[1] < b[1]
	end)
	MoveGuard.allow(player, Config.MoveGuard.CheckInterval * 2)
	root.CFrame = CFrame.new(zone.CFrame * sides[1][2]) * root.CFrame.Rotation
	root.AssemblyLinearVelocity = Vector3.zero
	if not lastPushNotice[player] or os.clock() - lastPushNotice[player] > 2 then
		lastPushNotice[player] = os.clock()
		say(player, "🎁 상자를 들고는 남의 기지에 못 들어가요!")
	end
end

local function speciesFor(profile, box)
	local odds = Formulas.gachaOdds(profile.DefenseLevel, { keyType = box.Grade or "Normal", rebirths = profile.Rebirths or 0,
		limitedSpecies = ReplicatedStorage:GetAttribute("LimitedSpecies") })
	local pick = Formulas.pickWeighted(odds.Species, "Percent", rng:NextNumber())
	return pick.Id, pick.Limited
end

local function bringHome(player, list)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	local units = {}
	for _, b in ipairs(list) do
		if b.King then
			for _ = 1, Config.Keys.King.Value do
				table.insert(units, rollFor(profile.DefenseLevel, "Normal"))
			end
		else
			table.insert(units, b)
		end
	end
	local room = Config.Gacha.MaxOwnedUnits - #profile.Units - Boxes.count(profile)
	if room < #units then
		setCarried(player, {})
		for _, b in ipairs(list) do
			if not b.onlyFor then
				toAltar(b)
			end
		end
		say(player, string.format("🦖 공룡이 너무 많아요 (최대 %d마리)! 상자는 제단으로 돌아갔어요", Config.Gacha.MaxOwnedUnits))
		publishRare()
		return
	end
	setCarried(player, {})
	local now = os.time()
	local made = {}
	PlayerData.update(player, function(p)
		for _, b in ipairs(units) do
			local species, limited = speciesFor(p, b)
			local unit = { Species = species, Rarity = b.Rarity, Size = b.Size, Mutation = b.Mutation, Limited = limited }
			Boxes.add(p, unit, nil, Boxes.seconds(player, unit, false), now)
			table.insert(made, unit)
		end
	end)
	Boxes.changed(player)
	Rewards.keysHome(player, #list)
	Net.pushAll("KeysHome", player.UserId)
	local best = made[1]
	for _, u in ipairs(made) do
		if rank(u.Rarity) > rank(best.Rarity) then
			best = u
		end
		if Formulas.chatFind(u.Rarity) then
			Net.pushAll("BigFind", player.DisplayName, "Box", u.Rarity)
		end
	end
	say(player, string.format("🏠 선물상자 %d개가 내 상자 더미에! 📦 %s %s · 농장에서 기다려요", #made,
		Formulas.rarity(best.Rarity).Name, Formulas.dinoSize(best.Size).Name))
	publishRare()
end

local function meteorBox(grade)
	local box
	if grade then
		box = altarBox(grade)
	else
		local _, rolled = Formulas.centralDrop(0, rng:NextNumber() / Config.Keys.MeteorShower.SpecialShare)
		box = altarBox(rolled or "Normal")
	end
	local x, z = keyZonePoint()
	local part = placeBox(x, z, box, false, nil, nil, nil, nil, true)
	if part then
		announceRare({ box })
	end
end

local showering = false
local function meteorShower()
	if showering then
		return
	end
	showering = true
	local shower = Config.Keys.MeteorShower
	if secondsToDrop() < shower.DropGap then
		sinceDrop = Formulas.keySpawnInterval(#Players:GetPlayers()) - shower.DropGap
		publishNextDrop()
	end
	local grades = table.create(shower.Keys, false)
	for _ = 1, math.min(shower.Gold, shower.Keys) do
		local i = rng:NextInteger(1, shower.Keys)
		while grades[i] do
			i = i % shower.Keys + 1
		end
		grades[i] = "Gold"
	end
	Story.showAll("Meteor", Story.explain("Meteor", shower.Duration, shower.Keys))
	for i = 1, shower.Keys do
		meteorBox(grades[i] or nil)
		task.wait(shower.Duration / shower.Keys)
	end
	showering = false
end

local function mirrorSaved(player, profile)
	for _, t in ipairs(TYPES) do
		if t.Id ~= "Normal" then
			player:SetAttribute("Keys" .. t.Id, Formulas.savedKeys(profile, t.Id))
		end
	end
end

function Keys.init()
	local map = Workspace:FindFirstChild("Map")
	local zone = map and map:FindFirstChild("KeyZone")
	local altar = zone and zone:FindFirstChild("Zone_KeyAltar")
	if altar then
		Bases.title(altar, "🎁 선물 제단", ALTAR_TITLE_COLOR, true, ALTAR_TITLE_HEIGHT)
		local cf, size = altar:GetBoundingBox()
		if math.sqrt(cf.Position.X ^ 2 + cf.Position.Z ^ 2) < Config.Map.KeyZoneRadius then
			altarX, altarZ = cf.Position.X, cf.Position.Z
			altarRim = math.max(size.X, size.Z) / 2
		end
		altarParams = RaycastParams.new()
		altarParams.FilterType = Enum.RaycastFilterType.Include
		altarParams.FilterDescendantsInstances = { altar }
	end
	folder = Workspace:FindFirstChild("Keys") or Instance.new("Folder")
	folder.Name = "Keys"
	folder:ClearAllChildren()
	folder.Parent = Workspace

	local shared = Instance.new("Folder")
	shared.Name = "KeyModels"
	for _, t in ipairs(Config.Keys.Types) do
		local model = keyModel(t.Id)
		model.Name = "Key_" .. t.Id
		model.Parent = shared
	end
	local oldShared = ReplicatedStorage:FindFirstChild("KeyModels")
	if oldShared then
		oldShared:Destroy()
	end
	shared.Parent = ReplicatedStorage

	Players.PlayerAdded:Connect(function(player)
		player.CharacterAdded:Connect(function()
			local list = carried[player] or {}
			setCarried(player, {})
			for _, b in ipairs(list) do
				if not b.onlyFor then
					toAltar(b)
				end
			end
			publishRare()
		end)
	end)
	Players.PlayerRemoving:Connect(function(player)
		lastPushNotice[player] = nil
		lastSaid[player] = nil
		Keys.dropAll(player)
		carried[player] = nil
		publishRare()
	end)
	PlayerData.onLoaded(mirrorSaved)
	PlayerData.onChanged(mirrorSaved)
	Net.onRequest("DropKeys", { "any", "any" }, function(player)
		local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
		if humanoid and humanoid.Health > 0 then
			Keys.dropAll(player)
		end
	end)

	task.spawn(function()
		sinceDrop = math.huge
		local dropNumber = 0
		local bigDrop = Config.Keys.BigDrop
		local function nextIsBig()
			return (dropNumber + 1) % bigDrop.Every == 0
		end
		ReplicatedStorage:SetAttribute("NextKeyDropBig", nextIsBig())
		while true do
			task.wait(1)
			sinceDrop += 1
			if nextIsBig() and secondsToDrop() == bigDrop.WarnSeconds then
				Story.showAll("BigDropSoon", Story.explain("BigDropSoon", bigDrop.WarnSeconds))
			end
			if secondsToDrop() <= 0 then
				sinceDrop = 0
				local big = nextIsBig()
				dropNumber += 1
				ReplicatedStorage:SetAttribute("NextKeyDropBig", nextIsBig())
				local placed, part = centralDrop(nil, big)
				if part and not announcedFirst then
					announcedFirst = true
					print(string.format("[Keys] 중앙에 선물상자 %d개가 생겼습니다 (%.0f, %.0f, %.0f). 이후 %d초마다",
						placed, part.Position.X, part.Position.Y, part.Position.Z, Config.Keys.SpawnInterval))
				end
			end
			publishNextDrop()
		end
	end)

	task.spawn(function()
		local shower = Config.Keys.MeteorShower
		local started, warned = nil, nil
		while true do
			task.wait(1)
			local since = os.time() - shower.AtMinute * 60
			local hour, into = since // 3600, since % 3600
			if 3600 - into <= shower.WarnSeconds and warned ~= hour + 1 then
				warned = hour + 1
				Story.showAll("MeteorSoon", Story.explain("MeteorSoon", 3600 - into))
			end
			if into < shower.Duration and started ~= hour then
				started = hour
				meteorShower()
			end
		end
	end)

	task.spawn(function()
		while true do
			task.wait(Config.Keys.HomeCheckInterval)
			local home = {}
			for player, list in pairs(carried) do
				local root = #list > 0 and player.Character and player.Character:FindFirstChild("HumanoidRootPart")
				if root and not insideOwnBase(player, root.Position) then
					keepOutOfOtherBases(player, root)
				end
				if root and PlayerData.get(player) and insideOwnBase(player, root.Position) then
					table.insert(home, { player, list })
				end
			end
			for _, h in ipairs(home) do
				bringHome(h[1], h[2])
			end
			local now = os.clock()
			local back = {}
			for part, info in pairs(ground) do
				if info.dropped and now - info.dropped > Config.Keys.DroppedLifetime then
					table.insert(back, part)
				end
			end
			for _, part in ipairs(back) do
				local info = ground[part]
				ground[part] = nil
				part:Destroy()
				if info and not info.onlyFor then
					toAltar(info.box)
				end
			end
		end
	end)
end

function Keys.dropNow(big)
	sinceDrop = 0
	publishNextDrop()
	return (centralDrop(nil, big))
end

function Keys.meteorNow()
	task.spawn(meteorShower)
end

function Keys.rain(count, kind)
	local placed, list = 0, {}
	for i = 1, count do
		local box = altarBox((i == 1 and kind) or "Normal")
		local x, z = keyZonePoint()
		if placeBox(x, z, box, false, nil) then
			placed += 1
			table.insert(list, box)
		end
	end
	if placed > 0 then
		Story.showAll("Drop", Story.explain("Drop", placed))
		announceRare(list)
	end
	return placed
end

function Keys.rainBox(rarity, size, count)
	local placed = 0
	for _ = 1, count or 1 do
		local x, z = keyZonePoint()
		if placeBox(x, z, { Rarity = rarity, Size = size, Grade = "Normal" }, false, nil) then
			placed += 1
		end
	end
	announceRare({ { Rarity = rarity, Size = size } })
	return placed
end

function Keys.give(player, count, kind)
	local list = table.clone(carried[player] or {})
	for _ = 1, count do
		if #list >= A.MaxCarry then
			break
		end
		table.insert(list, kind == "King" and altarBox("King") or rollFor(levelOf(player), kind or "Normal"))
	end
	setCarried(player, list)
	publishRare()
	return #list
end

return Keys
