--[[
TutorialLogic: the tutorial's steps as plain data and rules (no Roblox), so they can be tested
(tools/tests/tutorial_test.lua). The Tutorial service keeps a player's state in the profile
(profile.Tutorial) and calls these.

State: { Step = index in Config.Tutorial.Steps, Count = progress in the step, Done = bool, Replay = bool,
	Did = { [step Id] = true } (the steps finished, kept across replays), Skip = nil | "did" | "cant",
	Until = nil | step index (a part's replay ends after it; Config.Tutorial.Parts),
	PartsDone = { [part Id] = true } (the parts played to their end, kept across runs) }

(2026-10-03, "완전 처음 시작하는 사람들은 튜토리얼 건너뛰기를 없애줘" → "튜토리얼 건너뛰기는 이미 그파트 완료한 사람만
가능하게") a run can be skipped only when it is a replay of what the player finished before (canSkip): one part done,
or the whole with every part done.
(2026-10-04, "튜토리얼 스킵도 가능하게 하자. 그리고 보상은 나중에 튜토리얼 다시하기로 다시 얻을 수 있게") the first run
can be skipped too; it then pays nothing, and the real save keeps Unpaid = true (coreDue). 설정's "처음부터 전부" then
plays the first run again (the short core, joinData Again; the real save's ReplayCore), and finishing it pays the first
run's reward once (applyField "Core").
(2026-10-07, "튜토리얼 나가기 버튼 어디감") every run can be left, a lesson not finished before too; a left run is
Skipped and never Finished, so it pays nothing (the lesson's reward waits for a run played to its end).

(2026-10-03, "30이나 걸려 튜토가??" → "그렇게 바꿔") the first run leaves out the Lesson parts (Config.Tutorial.Parts):
those are learned later, one at a time, like a replay of that part, and the first finish of each pays its Reward
(applyField). The real save keeps Lessons = { [part Id] = true } (paid; nil for a save that finished the whole
tutorial before this, which was paid for all of it) and Offered = { [part Id] = true } (Coco asked once).

(2026-10-02, "처음인 사람은 직접 하나하나 해 주게 도와주고 체험, 다시하기 한 사람은 직접 하는 부분은 이미 돼 있으면
넘어가게") A replay's hands-on steps (an Event, or a Reach without Info) that were finished before (Did) only show
Coco's card: Skip "did", and reading it (clientDone) moves on. The service may also mark a step it can't be done now
(markCant: Skip "cant", e.g. a combo with no team for it), the same way.
]]

local Config = if game
	then require(game:GetService("ReplicatedStorage"):WaitForChild("Config"))
	else CONFIG

local TutorialLogic = {}

local function steps()
	return Config.Tutorial.Steps
end

local OLD_STEPS = {
	[1] = {
		"Hatch", "Welcome", "Mine", "Deposit", "Shop", "Draw1", "Open1", "Place1", "Draw2", "Place2", "Promotion",
		"GachaMore", "Attributes", "BossPath", "TopView", "Combo", "Fossils", "Challenge", "Slots", "Maps", "Enhance",
		"Dummy", "Fruit", "FruitHome", "Feed", "Merge", "Farm", "Ride", "KeyStall", "KeyTrade", "CenterKey", "CarryHome",
		"Battlefield", "SpeedPad", "Chest", "Home", "Weather", "Night", "BombEgg", "BombPoop", "BossKill", "BombShop",
		"Rebirth", "Grow", "Dex", "Bag", "RewardsBtn", "Bell", "More", "Finish" },
}

-- a new player's state: from the first step
function TutorialLogic.new()
	return { Step = 1, Count = 0, Done = false, Replay = false, Did = {}, StepsVersion = Config.Tutorial.StepsVersion }
end

-- a step the player does with their own hands (not a card to read)
function TutorialLogic.handsOn(s)
	return s.Event ~= nil or (s.Reach ~= nil and s.Info == nil)
end

-- the step now (its table and index), nil when done
function TutorialLogic.current(state)
	if state.Done then
		return nil
	end
	local s = steps()[state.Step]
	return s, state.Step
end

-- the index of a step by its Id
function TutorialLogic.index(id)
	for i, s in ipairs(steps()) do
		if s.Id == id then
			return i
		end
	end
	return nil
end

-- the Lesson part a step index is in, or nil
function TutorialLogic.lessonAt(index)
	for _, p in ipairs(Config.Tutorial.Parts) do
		if p.Lesson then
			local from, to = TutorialLogic.index(p.From), TutorialLogic.index(p.To)
			if from and to and index >= from and index <= to then
				return p
			end
		end
	end
	return nil
end

-- past steps a replay leaves out (and the first run the lessons); done after the last
local function settle(state)
	while not state.Done do
		local s = steps()[state.Step]
		if not s or (state.Until and state.Step > state.Until) then
			state.Done = true
			state.Until = nil
		elseif (s.FirstRunOnly and state.Replay) or (not state.Replay and TutorialLogic.lessonAt(state.Step)) then
			state.Step += 1
			state.Count = 0
		else
			if state.Replay and TutorialLogic.handsOn(s) and state.Did and state.Did[s.Id] then
				state.Skip = "did" -- (done before: Coco's card, then on)
			end
			break
		end
	end
end

-- (a run picked up again: a save from before the lessons may stand on one)
TutorialLogic.settle = settle

function TutorialLogic.upgrade(state)
	local version = Config.Tutorial.StepsVersion
	if not state or (state.StepsVersion or 1) >= version then
		return false
	end
	local old = OLD_STEPS[state.StepsVersion or 1]
	state.StepsVersion = version
	if not old then
		return true
	end
	local function moved(i, way)
		while old[i] do
			local now = TutorialLogic.index(old[i])
			if now then
				return now
			end
			i += way
		end
		return nil
	end
	if state.Step and old[state.Step] then
		state.Step = moved(state.Step, 1) or #steps() + 1
	elseif state.Step and state.Step > #old then
		state.Step = #steps() + 1
	end
	if state.Until and old[state.Until] then
		state.Until = moved(state.Until, -1)
	end
	return true
end

-- on to the next step (returns the new step or nil when done)
function TutorialLogic.advance(state)
	local s = steps()[state.Step]
	if s and not state.Skip then
		state.Did = state.Did or {}
		state.Did[s.Id] = true
	end
	if s then -- (a part's last step over: that part was played to its end)
		for _, p in ipairs(Config.Tutorial.Parts) do
			if p.To == s.Id then
				state.PartsDone = state.PartsDone or {}
				state.PartsDone[p.Id] = true
			end
		end
	end
	state.Skip = nil
	state.Step += 1
	state.Count = 0
	settle(state)
	return TutorialLogic.current(state)
end

-- something happened (an Event kind, amount): true when it finished the step
function TutorialLogic.event(state, kind, amount)
	local s = TutorialLogic.current(state)
	if not s or s.Event ~= kind or not amount or amount <= 0 then
		return false
	end
	state.Count += amount
	if state.Count >= (s.Count or 1) then
		TutorialLogic.advance(state)
		return true
	end
	return false
end

-- the player got to a Reach spot: true when that finished the step. (2026-10-02, "공룡 먹이·합성·업그레이드 … 튜토가
-- 제대로 설명 안 하고") a step with Info lines only counts the arrival (Count 1): Coco's card explains it there and
-- the step ends when the player has read it (clientDone)
function TutorialLogic.reached(state, spot)
	local s = TutorialLogic.current(state)
	if s and s.Reach == spot then
		if s.Info then
			if (state.Count or 0) < 1 then
				state.Count = 1
			end
			return false
		end
		TutorialLogic.advance(state)
		return true
	end
	return false
end

-- the client says a Client step is done (the step's Id, so a late message can't skip another step)
function TutorialLogic.clientDone(state, id)
	local s = TutorialLogic.current(state)
	if s and s.Id == id and (s.Client or state.Skip or (s.Info and (state.Count or 0) >= 1)) then
		TutorialLogic.advance(state)
		return true
	end
	return false
end

-- (2026-10-03) the step's thing already happened (fruit picked inside the base is food at once): its card, then on
function TutorialLogic.markDone(state)
	if TutorialLogic.current(state) then
		state.Skip = "done"
	end
end

-- the step now can't be done (the service's check): Coco's card, then on
function TutorialLogic.markCant(state)
	if TutorialLogic.current(state) then
		state.Skip = "cant"
	end
end

function TutorialLogic.skip(state)
	state.Done = true
	state.Count = 0
	state.Until = nil
end

-- a part of the tutorial (Config.Tutorial.Parts) by its Id
function TutorialLogic.part(id)
	for _, p in ipairs(Config.Tutorial.Parts) do
		if p.Id == id then
			return p
		end
	end
	return nil
end

-- was this part (a Config.Tutorial.Parts entry) finished before? played to its end, or (a save from before PartsDone)
-- every step of it done
function TutorialLogic.partDone(state, part)
	if state.PartsDone and state.PartsDone[part.Id] then
		return true
	end
	local from, to = TutorialLogic.index(part.From), TutorialLogic.index(part.To)
	if not from or not to then
		return false
	end
	for i = from, to do
		local s = steps()[i]
		if not s.FirstRunOnly and not (state.Did and state.Did[s.Id]) then
			return false
		end
	end
	return true
end

-- may this run be skipped? only a replay of what was finished before (the part replayed, or every part for the whole)
function TutorialLogic.canSkip(state)
	return not state.Done
end

-- the parts the real save knows finished (sent to the field: TutorialField joinData Done): the first run's when it
-- was played to the end (Paid), each lesson once learned (a save paid the whole tutorial before the lessons: all)
-- (2026-10-04: and each part a field run played to its end, kept on the real save as PartsDone: applyField)
function TutorialLogic.mainPartsDone(mainT)
	local list = {}
	for _, p in ipairs(Config.Tutorial.Parts) do
		if (mainT.PartsDone and mainT.PartsDone[p.Id])
			or (mainT.Paid and (not p.Lesson or mainT.Lessons == nil or (mainT.Lessons and mainT.Lessons[p.Id]))) then
			table.insert(list, p.Id)
		end
	end
	return list
end

-- the field's state takes in the parts the real save knows finished (a list of part Ids)
function TutorialLogic.know(state, list)
	for _, id in ipairs(list or {}) do
		if TutorialLogic.part(id) then
			state.PartsDone = state.PartsDone or {}
			state.PartsDone[id] = true
		end
	end
end

-- again from the start (or only one part: partId), only showing the way (no gifts, no shield, no fixed draws);
-- only once done
function TutorialLogic.replay(state, partId)
	if not state.Done then
		return false
	end
	local part = partId and TutorialLogic.part(partId)
	if partId and not part then
		return false
	end
	state.Step, state.Count, state.Done, state.Replay, state.Skip = 1, 0, false, true, nil
	state.Until = nil
	if part then
		state.Step, state.Until = TutorialLogic.index(part.From), TutorialLogic.index(part.To)
	end
	settle(state)
	return true
end

-- ---------------------------------------------------------------------------
-- (2026-10-03) The tutorial field (TutorialField): the steps run on a server of the player's own, on a save
-- apart; the real save only keeps Done, Paid (the reward was given), ReplayAt / ReplayPart (a replay asked).
-- The field's state adds StartedAt (os.time() the run began), Finished (all done, not skipped).
-- ---------------------------------------------------------------------------

-- has the field run that started at or after the real save's last ask ended?
local function fieldOver(mainT, fieldT)
	return fieldT ~= nil and fieldT.Done == true and (fieldT.StartedAt or 0) > 0
		and (fieldT.StartedAt or 0) >= (mainT.ReplayAt or 0)
end

-- the main server, a player's real save loaded (mainT) beside their field save (fieldT, nil if none):
-- "apply" (a field run ended: TutorialLogic.applyField), "field" (send them to the field) or nil
function TutorialLogic.mainAction(mainT, fieldT)
	local over = fieldOver(mainT, fieldT)
	if not mainT.Done then
		return over and "apply" or "field"
	end
	if (mainT.ReplayAt or 0) > 0 then
		-- (a replay asked and not yet played: only Studio comes back here first; played: a lesson may pay)
		return over and "apply" or "field"
	end
	return nil
end

-- is this lesson's reward still due for the real save? (not for a save that was paid the whole tutorial before)
function TutorialLogic.lessonDue(mainT, partId)
	local part = partId and TutorialLogic.part(partId)
	if not part or not part.Lesson or not part.Reward then
		return false
	end
	if mainT.Paid and mainT.Lessons == nil then
		return false -- (the whole tutorial, finished before the lessons: all paid)
	end
	return not (mainT.Lessons and mainT.Lessons[partId])
end

-- (2026-10-04) the first run's reward is still to come: the first run was skipped (or never reached the field)
function TutorialLogic.coreDue(mainT)
	return mainT.Done == true and mainT.Unpaid == true and not mainT.Paid
end

-- the field's result into the real save: done; returns "Core" when the first run's reward is due, a part Id when
-- that lesson's is (its first finish), else nil
function TutorialLogic.applyField(mainT, fieldT)
	local first = not mainT.Done
	local asked = mainT.ReplayPart
	local again = mainT.ReplayCore == true and TutorialLogic.coreDue(mainT) -- (2026-10-04: the first run again)
	-- (2026-10-04, "클리어한 튜토리얼 파트는 회색버튼으로") the parts the field run played to their end, kept
	for id in pairs(fieldT and fieldT.PartsDone or {}) do
		if TutorialLogic.part(id) then
			mainT.PartsDone = mainT.PartsDone or {}
			mainT.PartsDone[id] = true
		end
	end
	mainT.Done = true
	mainT.ReplayAt, mainT.ReplayPart, mainT.ReplayCore = 0, nil, nil
	if first or again then
		if fieldT and fieldT.Finished and not fieldT.Replay and not mainT.Paid then
			mainT.Paid = true
			mainT.Unpaid = nil
			mainT.Lessons = mainT.Lessons or {} -- (the lessons are to come: each pays once)
			return "Core"
		end
		if first and not mainT.Paid then
			mainT.Unpaid = true -- (skipped: the reward waits for 설정's "처음부터 전부")
		end
		return nil
	end
	local part = fieldT and fieldT.Finished and fieldT.Replay and fieldT.ReplayPart
	if part and part == asked and TutorialLogic.lessonDue(mainT, part) then
		mainT.Lessons = mainT.Lessons or {}
		mainT.Lessons[part] = true
		return part
	end
	return nil
end

-- the field server, the player arrived: go on with an unfinished first run, else a fresh run
-- (2026-10-03: a replay too, when it is the same one asked, of the same part, left halfway; Asked = the real
-- save's ReplayAt, so a new ask starts over)
function TutorialLogic.fieldArrive(fieldT, joinData)
	local unfinished = fieldT ~= nil and not fieldT.Done and (fieldT.StartedAt or 0) > 0
	if joinData and joinData.Replay then
		if unfinished and fieldT.Replay and joinData.Asked and fieldT.StartedAt >= joinData.Asked
			and fieldT.ReplayPart == joinData.Part then
			return "resume"
		end
		return "fresh"
	end
	-- (2026-10-03: a first run left halfway goes on, unless the tutorial was asked again since: Asked = ReplayAt,
	-- the ;tutorial test command)
	if unfinished and not fieldT.Replay and fieldT.StartedAt >= (joinData and joinData.Asked or 0) then
		return "resume"
	end
	return "fresh"
end

-- a fresh run's state (the steps done before kept): the whole, or a replay of all or one part
function TutorialLogic.freshRun(oldT, joinData, now)
	local t = TutorialLogic.new()
	t.Did = oldT and oldT.Did or {}
	t.PartsDone = oldT and oldT.PartsDone or nil
	TutorialLogic.know(t, joinData and joinData.Done)
	t.StartedAt = now
	t.Again = joinData and not joinData.Replay and joinData.Again == true or nil -- (2026-10-04: the first run again)
	if joinData and joinData.Replay then
		t.Done = true -- (a replay starts from a finished state)
		if TutorialLogic.replay(t, joinData.Part) then
			t.ReplayPart = joinData.Part -- (a replay left halfway goes on only for the same part: fieldArrive)
		else
			TutorialLogic.replay(t)
		end
	end
	return t
end

-- the first run's help (gifts, fixed draws, the shield, the easier promotion) is on
function TutorialLogic.firstRun(state)
	return not state.Done and not state.Replay
end

return TutorialLogic
