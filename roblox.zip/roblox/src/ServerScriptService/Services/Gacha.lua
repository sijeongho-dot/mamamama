--[[
Gacha: draws (design 4.3-4.6 뽑기). One saved key = one draw, 1 to Config.Gacha.MaxDrawCount at a time,
from anywhere. The key's grade (Config.Keys.Types) sets the draw: its luck and lowest rarity.
Keys are bought in the shop (Shop.lua) or brought home from the center (Keys.lua).

- Net ask Draw(count, grade): the server checks the keys and the dino limit (Config.Gacha.MaxOwnedUnits),
  rolls each draw with Formulas.gachaOdds / rollDraw (the same numbers the odds window shows),
  takes the keys and puts each dino in a box (Boxes service) in one PlayerData.update, and answers the boxes.
- What changes the odds: the defense level (unlocked species and rarities), ReplicatedStorage
  attributes LimitedSpecies (this week's limited dino, the Limited service; a dino from its share is
  marked Limited) and, when those features arrive,
  MutationEvent, and player attributes Luck and LimitedPotion. A draw's first dino comes at least
  the rarity of a guaranteed draw the player holds (profile.GuaranteedDraws, the beginner missions). Every dino
  counts toward the pity (뽑기 천장, Formulas.applyPity, profile PityCount; player attribute PityLeft; a raised
  one carries Pity = true for the reveal). Clients read the same attributes
  for the odds window (StarterPlayerScripts/Gacha).
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local Boxes = require(script.Parent:WaitForChild("Boxes"))

local Gacha = {}

local rng = Random.new()
local override = nil -- Gacha.setOverride

-- fn(player) -> { Rarity = Id?, Species = Id? } or nil: the next draw's first dino is made so (the
-- tutorial's fixed first draws); asked once per draw, before anything is counted
function Gacha.setOverride(fn)
	override = fn
end

local function oddsOptions(player)
	local server = (ReplicatedStorage:GetAttribute("ServerLuckUntil") or 0) > Workspace:GetServerTimeNow()
		and (ReplicatedStorage:GetAttribute("ServerLuck") or 1) or 1
	return {
		luckCap = Formulas.luckCap(player:GetAttribute("Luck"), server), -- (paid luck goes past the usual cap)
		-- potions and boosts (Luck) × the farm and collection's rare chance (Farm: BonusRareChance)
		-- (2026-10-01) × the server luck boost someone bought for everyone (Monetization: ServerLuck while
		-- ServerLuckUntil, server time); Formulas caps all of it at LuckMaxMultiplier (PaidLuckMax with paid luck on)
		luck = (player:GetAttribute("Luck") or 1) * (1 + (player:GetAttribute("BonusRareChance") or 0))
			* ((ReplicatedStorage:GetAttribute("ServerLuckUntil") or 0) > Workspace:GetServerTimeNow()
				and (ReplicatedStorage:GetAttribute("ServerLuck") or 1) or 1),
		limitedPotion = player:GetAttribute("LimitedPotion") == true,
		limitedSpecies = ReplicatedStorage:GetAttribute("LimitedSpecies"),
		mutationEvent = ReplicatedStorage:GetAttribute("MutationEvent") == true,
		rebirths = (PlayerData.get(player) or {}).Rebirths or 0, -- (the awakened variants, 2026-10-02)
	}
end

local function draw(player, count, grade)
	local keyType = Formulas.keyType(grade)
	if not keyType or count ~= math.floor(count) or count < 1 or count > Config.Gacha.MaxDrawCount then
		return { Error = "잘못된 요청이에요" }
	end
	local profile = PlayerData.get(player)
	local have = Formulas.savedKeys(profile, grade)
	if have < count then
		return { Error = string.format("%s가 모자라요 (%d개 필요 · 지금 %d개)! 🔑 열쇠 상점에서 사거나 가운데에서 주워요",
			keyType.Name, count, have) }
	end
	if #profile.Units + Boxes.count(profile) + count > Config.Gacha.MaxOwnedUnits then
		return { Error = string.format("🦖 공룡이 너무 많아요 (최대 %d마리)", Config.Gacha.MaxOwnedUnits) }
	end
	local options = oddsOptions(player)
	options.keyType = grade
	local odds = Formulas.gachaOdds(profile.DefenseLevel, options)
	local results = {}
	local forced = override and override(player)
	local drawnBefore = profile.Stats.Draws or 0
	local now = os.time()
	PlayerData.update(player, function(p)
		Formulas.addSavedKeys(p, grade, -count)
		p.Stats.Draws = (p.Stats.Draws or 0) + count
		Rewards.add(player, "Draws", count) -- daily missions
		for i = 1, count do
			local unit = Formulas.rollDraw(odds, rng:NextNumber(), rng:NextNumber(), rng:NextNumber(), rng:NextNumber(),
				rng:NextNumber())
			if forced and #results == 0 then
				unit.Rarity = forced.Rarity or unit.Rarity
				unit.Species = forced.Species or unit.Species
				unit.Limited = not forced.Species and unit.Limited or nil
			elseif #results == 0 then -- a guaranteed draw (the beginner missions): at least that rarity
				local floor = Formulas.takeGuaranteedDraw(p)
				if floor and Formulas.rarity(unit.Rarity .. "#") < Formulas.rarity(floor .. "#") then
					unit.Rarity = floor
				end
			end
			local pity = Formulas.applyPity(p, unit, odds, rng:NextNumber()) -- (뽑기 천장)
			local box = Boxes.add(p, unit, pity, Boxes.seconds(player, unit, drawnBefore + i <= Config.Boxes.FirstDraws), now)
			table.insert(results, Boxes.public(box))
		end
	end)
	Boxes.changed(player)
	for _, box in ipairs(results) do
		if Formulas.chatFind(box.Rarity) then
			Net.pushAll("BigFind", player.DisplayName, "Box", box.Rarity)
		end
	end
	local after = PlayerData.get(player)
	player:SetAttribute("PityLeft", Formulas.pityLeft(after))
	local sure = 0 -- (2026-10-02: the sure draws left; it kept showing one already used)
	for _, n in pairs(after.GuaranteedDraws or {}) do
		sure += n
	end
	player:SetAttribute("GuaranteedDraws", sure > 0 and sure or nil)
	return { Boxes = results, Now = now, Keys = Formulas.savedKeys(PlayerData.get(player), grade) }
end

function Gacha.giveBox(player, grade)
	local profile = PlayerData.get(player)
	if not profile or #profile.Units + Boxes.count(profile) + 1 > Config.Gacha.MaxOwnedUnits then
		return nil
	end
	local options = oddsOptions(player)
	options.keyType = grade
	local odds = Formulas.gachaOdds(profile.DefenseLevel, options)
	local unit = Formulas.rollDraw(odds, rng:NextNumber(), rng:NextNumber(), rng:NextNumber(), rng:NextNumber(), rng:NextNumber())
	PlayerData.update(player, function(p)
		Boxes.add(p, unit, nil, Boxes.seconds(player, unit, false), os.time())
	end)
	Boxes.changed(player)
	if Formulas.chatFind(unit.Rarity) then
		Net.pushAll("BigFind", player.DisplayName, "Box", unit.Rarity)
	end
	return unit
end

function Gacha.init()
	Net.onAsk("Draw", { "number", "string" }, draw)
	PlayerData.onLoaded(function(player, profile)
		player:SetAttribute("PityLeft", Formulas.pityLeft(profile)) -- (the gacha window: "🎯 전설 확정까지 n번")
	end)
end

return Gacha
