--[[
Rewards: playtime gifts, offline earnings, daily missions and the weekly key challenge (design 2.13;
the rules are RewardLogic's, the numbers Config.Rewards).

- Playtime gifts: once a day each. Today's play time is kept in the profile (every session of the
  day adds up, counted here every second); Net request ClaimReward("Playtime", i) once gift i's
  minutes of play today have passed (checked here). A new day (Korean midnight) starts over.
- Offline earnings: when the profile loads, the time since Stats.LastSeen (kept up to date every
  minute) pays a share of the arena's idle money, capped; a notice says so.
- Daily missions and the weekly key challenge: other services report progress with
  Rewards.add(player, kind, amount) (Mine, NightMine, Chests, Fossils, Draws, Slaps, Pads, Boss) and
  Rewards.keysHome(player, n); it is collected and written once a second. Finished missions and
  reached milestones are claimed with ClaimReward("Daily", i) / ("DailyAll") / ("Weekly", i).
- Attendance (2026-10-02, design 2.9; RewardLogic.checkIn): the day is checked in on joining and when it
  turns; ClaimReward("Streak") takes today's streak reward, ("Monthly", i) a monthly milestone. Joining
  with something waiting there opens the window on 출석 (Net push OpenRewards, after
  Config.Attendance.PopupDelay; not during the tutorial; after the update news when that is up: BetaLog
  calls Rewards.popupAttendance).
- 🎉 The launch event (2026-10-04, Config.LaunchEvent; RewardLogic): the same progress counts its missions while it runs
  (a notice when one is done); ClaimReward("Event", i) takes a done one's reward, ("EventAll") the all-done reward once
  every one is taken: the event's slap skin and title for good (player attribute EventTitle, over the head: Race
  client), with a notice to everyone. Badge RewardsReadyEvent (the 🎉 tab's).
- 🎉 Its pop-up on every join (2026-10-04): Net push EventAd once the player is free (the tutorial done or skipped),
  while the event runs and its all-done reward is not taken (StarterPlayerScripts/EventAd).
- Net ask GetRewards: everything the 🎁 window shows. Player attributes RewardsReady (how many are
  waiting in the 🎁 window, for its button's badge), RewardsReadyGifts / Daily / Weekly (each tab's, for
  its badge in the window), RewardsReadyAttendance (the 📆 출석 button's badge) and RewardsVersion (changes when something did).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))
local StarterLogic = require(script.Parent:WaitForChild("StarterLogic"))
local TutorialField = require(script.Parent:WaitForChild("TutorialField")) -- (2026-10-04: was used without this - an error)
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))

local Rewards = {}

local FLUSH_EVERY = 1 -- seconds between writing collected progress
-- (2026-10-04) 🎉 the launch event's all-done reward: its notice's line, the big banner, everyone's notice
local EVENT_ALL_LINE = "👋 %s 스킨 (🎒 인벤토리 → 스킨) · 칭호 %s!"
local EVENT_ALL_BANNER = "🎉 이벤트 임무를 모두 끝냈어요! 칭호 %s!"
local EVENT_ALL_EVERYONE = "🎉 %s님이 런칭 이벤트 임무를 모두 끝냈어요! 칭호 %s"
local COMEBACK_TITLE = "🌱 다시 와서 반가워요!"
local SEEN_EVERY = 60 -- seconds between LastSeen updates
local OFFLINE_NOTICE_DELAY = 4 -- seconds after joining, so the screen is ready
local CLAIM_ALL_ROUNDS = 10

local sessions = {} -- [player] = { counted = os.clock() }: play time counted into the profile up to then
local pending = {} -- [player] = { [kind] = amount }
local pendingKeys = {} -- [player] = carried keys brought home

local function say(player, title, text)
	Net.push(player, "Notice", title, text)
end

local function seed(player)
	return player.UserId % 100000
end

local function refresh(player)
	local profile = PlayerData.get(player)
	if profile and sessions[player] then
		local gifts, daily, weekly, attendance, event = RewardLogic.readyByTab(profile)
		player:SetAttribute("RewardsReady", gifts + daily + weekly + event) -- (the 🎁 button; 📆 출석 has its own)
		player:SetAttribute("RewardsReadyEvent", event) -- (2026-10-04: the 🎉 tab's)
		player:SetAttribute("RewardsReadyAttendance", attendance)
		player:SetAttribute("RewardsReadyGifts", gifts) -- (each tab's own count in the window)
		player:SetAttribute("RewardsReadyDaily", daily)
		player:SetAttribute("RewardsReadyWeekly", weekly)
		player:SetAttribute("RewardsVersion", (player:GetAttribute("RewardsVersion") or 0) + 1)
	end
end

-- today's missions and this week's challenge, started over when the day or week turned
local giveAttendance

local function ensure(player)
	local now = os.time()
	local checkedIn, missed = false, {}
	PlayerData.update(player, function(p)
		RewardLogic.ensureDay(p, RewardLogic.dayNumber(now), seed(player))
		RewardLogic.ensureWeek(p, RewardLogic.weekNumber(now))
		RewardLogic.ensureEvent(p) -- (2026-10-04: a new event starts its missions over)
		checkedIn, missed = RewardLogic.checkIn(p, RewardLogic.dayNumber(now))
	end)
	for _, m in ipairs(missed or {}) do
		giveAttendance(player, m.Reward, "📆 지난 출석 보상", m.Month)
	end
	if checkedIn and sessions[player] then
		refresh(player) -- (a new day while playing: today's attendance waits)
	end
end

-- an attendance reward (Config.Attendance kinds)
function giveAttendance(player, reward, title, fromMonth)
	local profile = PlayerData.get(player)
	local level = profile.DefenseLevel
	local month = fromMonth or profile.Attendance.Month
	local dino = nil
	PlayerData.update(player, function(p)
		RewardLogic.apply(p, { Keys = reward.Keys, SpecialKeys = reward.SpecialKeys })
		if reward.LuckMinutes then
			p.LuckUntil = math.max(p.LuckUntil or 0, os.time()) + reward.LuckMinutes * 60
		end
		if reward.GuaranteedRarity then
			p.GuaranteedDraws = p.GuaranteedDraws or {}
			p.GuaranteedDraws[reward.GuaranteedRarity] = (p.GuaranteedDraws[reward.GuaranteedRarity] or 0) + 1
		end
		if reward.MonthDino then
			local c = Config.Attendance
			dino = { Id = "U" .. p.NextUnitId, Species = RewardLogic.monthDino(month), Rarity = c.MonthDinoRarity,
				Size = c.MonthDinoSize, Attend = true } -- (marked 🗓️: only from attendance)
			p.NextUnitId += 1
			table.insert(p.Units, dino)
			Formulas.recordCollection(p, dino)
		end
	end)
	local after = PlayerData.get(player)
	if reward.LuckMinutes then -- (the screens' luck line; StarterMissions keeps it after)
		player:SetAttribute("Luck", Config.StarterMissions.LuckMultiplier)
		player:SetAttribute("LuckEndsAt", after.LuckUntil)
	end
	if reward.GuaranteedRarity then
		local n = 0
		for _, k in pairs(after.GuaranteedDraws or {}) do
			n += k
		end
		player:SetAttribute("GuaranteedDraws", n)
	end
	if reward.KeyPriceTimes then
		PlayerData.addMoney(player, math.floor(Formulas.keyPrice(level) * reward.KeyPriceTimes), "reward")
	end
	if reward.ServerLuckMinutes then
		local c = Config.Attendance
		require(script.Parent:WaitForChild("Monetization")).serverLuck(player, { Minutes = reward.ServerLuckMinutes,
			LuckMultiplier = c.ServerLuckMultiplier, CrownMinutes = c.ServerLuckCrownMinutes })
	end
	local name = dino and Formulas.species(dino.Species).Name
	say(player, title, RewardLogic.attendanceText(reward, Formulas.keyPrice(level), name) .. " 받았어요!")
end

local batching = {}

local function give(player, reward, title, more)
	local profile = PlayerData.get(player)
	local money = 0
	PlayerData.update(player, function(p)
		money = RewardLogic.apply(p, reward)
	end)
	if money > 0 then
		PlayerData.addMoney(player, money, "reward")
	end
	local batch = batching[player]
	if batch then
		batch.total = RewardLogic.mergeRewards(batch.total, reward)
		return
	end
	local text = RewardLogic.text(reward, profile.DefenseLevel) .. " 받았어요!"
	say(player, title, (more and more ~= "") and (text .. "\n" .. more) or text)
end

-- the play time since it was last counted goes into today's total
local function countPlayed(player)
	local s = sessions[player]
	if not s or not PlayerData.isLoaded(player) then
		return
	end
	local now = os.clock()
	local seconds = now - s.counted
	s.counted = now
	ensure(player)
	PlayerData.update(player, function(p)
		RewardLogic.addPlayed(p, seconds)
	end)
end

local function miniGamesLeft(profile)
	local m = profile.MiniKeys
	local used = type(m) == "table" and m.Day == RewardLogic.dayNumber(os.time()) and m.Count or 0
	return math.max(0, Config.Ranked.PlayKeys.DailyGames - used)
end

function Rewards.miniGame(player, won)
	local profile = PlayerData.get(player)
	if not profile or miniGamesLeft(profile) <= 0 then
		return
	end
	local day = RewardLogic.dayNumber(os.time())
	PlayerData.update(player, function(p)
		if type(p.MiniKeys) ~= "table" or p.MiniKeys.Day ~= day then
			p.MiniKeys = { Day = day, Count = 0 }
		end
		p.MiniKeys.Count += 1
	end)
	profile = PlayerData.get(player)
	local left = miniGamesLeft(profile)
	player:SetAttribute("MiniKeysLeft", left)
	give(player, { Keys = Formulas.miniGameKeys(profile.DefenseLevel, won) }, won and "🏆 이겨서 열쇠!" or "🎮 한 판 열쇠!",
		left > 0 and string.format("🎮 오늘 %d판 더 받을 수 있어요", left) or "🎮 오늘 열쇠 판은 다 받았어요 · 내일 또!")
end

-- other services: give a reward now (keys into the profile, money at the player's own level) with a notice; more:
-- lines after the reward's in it (2026-10-04, the night boss: the hunt's)
function Rewards.grant(player, reward, title, more)
	if PlayerData.isLoaded(player) then
		give(player, reward, title, more)
	end
end

local function stakeText(grade, count, plain)
	local parts = {}
	if count > 0 then
		table.insert(parts, string.format("%s %d개", Formulas.keyType(grade).Name, count))
	end
	if plain > 0 then
		table.insert(parts, string.format("%s %d개", Formulas.keyType("Normal").Name, plain))
	end
	return table.concat(parts, " · ")
end

function Rewards.stakeText(gradeId)
	local g = RewardLogic.stakeGrade(gradeId) or Config.Ranked.Stake.Grades[1]
	return stakeText(g.Id, g.Keys, 0)
end

function Rewards.hasStake(player, gradeId)
	local g = RewardLogic.stakeGrade(gradeId)
	local profile = PlayerData.get(player)
	return g ~= nil and profile ~= nil and Formulas.savedKeys(profile, g.Id) >= g.Keys
end

function Rewards.takeStake(player, gradeId)
	local g = RewardLogic.stakeGrade(gradeId)
	if not g then
		return false
	end
	local paid = false
	PlayerData.update(player, function(p)
		if Formulas.savedKeys(p, g.Id) >= g.Keys then
			Formulas.addSavedKeys(p, g.Id, -g.Keys)
			paid = true
		end
	end)
	if paid then
		Net.push(player, "Notice", "🏆 랭킹전", string.format("🔑 %s를 걸었어요! 등수가 높을수록 많이 돌려받아요",
			stakeText(g.Id, g.Keys, 0)))
	end
	return paid
end

function Rewards.refundStake(player, gradeId)
	local g = RewardLogic.stakeGrade(gradeId)
	if g and player.Parent and PlayerData.isLoaded(player) then
		PlayerData.update(player, function(p)
			Formulas.addSavedKeys(p, g.Id, g.Keys)
		end)
		Net.push(player, "Notice", "🏆 랭킹전", string.format("🔑 걸었던 %s를 돌려받았어요", stakeText(g.Id, g.Keys, 0)))
	end
end

function Rewards.payStakes(order, gradeId)
	local ids = {}
	for i, group in ipairs(order) do
		ids[i] = {}
		for _, player in ipairs(group) do
			table.insert(ids[i], player.UserId)
		end
	end
	local pay = RewardLogic.stakePayouts(ids, gradeId)
	local day = RewardLogic.dayNumber(os.time())
	local place = 1
	for _, group in ipairs(order) do
		for _, player in ipairs(group) do
			local worth = pay[player.UserId] or 0
			if player.Parent and PlayerData.isLoaded(player) then
				local bonus = 0
				local grade, count, plain = RewardLogic.stakeSplit(worth, gradeId)
				PlayerData.update(player, function(p)
					if RewardLogic.stakeBonus(p, day) and worth > 0 then
						bonus = math.floor(worth * Config.Ranked.Stake.WinBonus + 0.5)
					end
					grade, count, plain = RewardLogic.stakeSplit(worth + bonus, gradeId)
					Formulas.addSavedKeys(p, grade, count)
					Formulas.addSavedKeys(p, "Normal", plain)
				end)
				Net.push(player, "Notice", "🏆 랭킹전", worth > 0 and string.format("%d등! 🔑 %s%s", place,
					stakeText(grade, count, plain), bonus > 0 and " (🎉 보너스)" or "")
					or string.format("%d등! 이번엔 🔑 열쇠를 못 받았어요", place))
			end
		end
		place += #group
	end
end

local addListeners = {} -- Rewards.onAdd
local claimListeners = {} -- Rewards.onClaim

-- fn(player, kind) after a reward of that kind was taken in the 🎁 / 📆 windows ("Playtime", "Daily",
-- "DailyAll", "Weekly", "WeeklyChallenge", "Streak", "Monthly"; the Season service gives XP for it)
function Rewards.onClaim(fn)
	table.insert(claimListeners, fn)
end

-- fn(player, kind, amount) on every Rewards.add (the Tutorial service follows the same events)
function Rewards.onAdd(fn)
	table.insert(addListeners, fn)
end

-- other services: progress of a daily mission kind
function Rewards.add(player, kind, amount)
	for _, fn in ipairs(addListeners) do
		task.defer(fn, player, kind, amount) -- (after the caller's own PlayerData.update, which often holds this call)
	end
	if amount and amount > 0 then
		pending[player] = pending[player] or {}
		pending[player][kind] = (pending[player][kind] or 0) + amount
	end
end

-- the Keys service: carried keys brought home (the KeysHome mission and the weekly challenge)
function Rewards.keysHome(player, n)
	Rewards.add(player, "KeysHome", n)
	pendingKeys[player] = (pendingKeys[player] or 0) + n
end

local function flush(player)
	local kinds, keys = pending[player], pendingKeys[player]
	pending[player], pendingKeys[player] = nil, nil
	if not PlayerData.isLoaded(player) or (not kinds and not keys) then
		return
	end
	ensure(player)
	local finished, reached, weeklyReady, eventDone = {}, {}, {}, {}
	local day = RewardLogic.dayNumber(os.time())
	PlayerData.update(player, function(p)
		for kind, amount in pairs(kinds or {}) do
			for _, i in ipairs(RewardLogic.progress(p, kind, amount)) do
				table.insert(finished, i)
			end
			if RewardLogic.progressWeekly(p, kind, amount) then
				table.insert(weeklyReady, kind)
			end
			for _, i in ipairs(RewardLogic.progressEvent(p, kind, amount, day)) do -- (2026-10-04) 🎉 the launch event
				table.insert(eventDone, i)
			end
		end
		if keys then
			reached = RewardLogic.addWeeklyKeys(p, keys)
		end
	end)
	if #finished > 0 then
		say(player, "✅ 오늘의 임무", "임무 완료! 🎁 보상 창에서 받아요")
	end
	for _, i in ipairs(reached) do
		say(player, "🎁 주간 선물상자 도전", string.format("상자 %d개 달성! 🎁 보상 창에서 받아요",
			Config.Rewards.Weekly.Milestones[i].Keys))
	end
	if #weeklyReady > 0 then
		say(player, "📅 주간 도전", "단계 달성! 🎁 보상 창 → 주간에서 받아요")
	end
	if #eventDone > 0 then
		say(player, Config.LaunchEvent.Name, "이벤트 임무 완료! 🎁 보상 창 → 🎉 이벤트에서 받아요")
	end
	refresh(player)
end

-- time away pays a share of the arena's idle money: not straight away, it waits as a pile of money in
-- in front of the spawn pad, until the player touches it (profile.OfflinePending, MoneyPile service)
function Rewards.payOffline(player, away)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	local rate = profile.Stats.IdleMoneyRate or 0 -- (what the arena really made a second, Defense)
	local money, seconds = RewardLogic.offlineMoney(away, rate, next(profile.Placed) ~= nil)
	if money > 0 then
		PlayerData.update(player, function(p)
			-- (what waits uncollected never grows past one full day's worth)
			p.OfflinePending = math.min((p.OfflinePending or 0) + money,
				math.max(p.OfflinePending or 0, RewardLogic.offlineMax(rate)))
		end)
		local h, m = math.floor(seconds / 3600), math.floor(seconds % 3600 / 60)
		say(player, "🏠 어서 와요!", string.format("없는 동안(%s) 공룡들이 💰 %s원을 벌었어요! 스폰 앞 돈더미를 만져요",
			h > 0 and string.format("%d시간 %d분", h, m) or string.format("%d분", m), Formulas.shortNumber(money)))
	end
end

local function claim(player, kind, index)
	local profile = PlayerData.get(player)
	local s = sessions[player]
	if not profile or not s then
		return
	end
	if kind == "All" then
		if batching[player] then
			return
		end
		countPlayed(player)
		batching[player] = {}
		for _ = 1, CLAIM_ALL_ROUNDS do
			local now = PlayerData.get(player)
			local list = now and RewardLogic.readyClaims(now) or {}
			if #list == 0 then
				break
			end
			for _, c in ipairs(list) do
				claim(player, c[1], c[2])
			end
		end
		local batch = batching[player]
		batching[player] = nil
		local after = PlayerData.get(player)
		if batch and batch.total and after then
			say(player, "🎁 모두 받기", RewardLogic.text(batch.total, after.DefenseLevel) .. " 받았어요!")
		end
		if after and RewardLogic.eventAllReady(after) then
			claim(player, "EventAll", 0)
		end
		refresh(player)
		return
	end
	countPlayed(player)
	local claimed = nil -- the kind of reward taken (Rewards.onClaim)
	local times = 1
	if kind == "Playtime" or kind == "PlaytimeAll" then
		local reward
		PlayerData.update(player, function(p)
			if kind == "PlaytimeAll" then
				reward, times = RewardLogic.claimPlaytimeAll(p)
			else
				reward = type(index) == "number" and RewardLogic.claimPlaytime(p, index) or nil
			end
		end)
		if reward then
			give(player, reward, "🎁 플레이 선물")
			claimed = "Playtime"
		end
	elseif kind == "Streak" or kind == "Monthly" then
		local reward
		PlayerData.update(player, function(p)
			if kind == "Streak" then
				reward = RewardLogic.claimStreak(p)
			else
				reward = type(index) == "number" and RewardLogic.claimMonthly(p, index) or nil
			end
		end)
		if reward then
			giveAttendance(player, reward, kind == "Streak" and "📆 출석" or "📆 이달의 출석")
			claimed = kind
		end
	elseif kind == "WeeklyChallenge" then
		local reward
		PlayerData.update(player, function(p)
			reward = type(index) == "string" and RewardLogic.claimWeeklyChallenge(p, index) or nil
		end)
		if reward then
			give(player, reward, "📅 주간 도전")
			claimed = kind
		end
	elseif kind == "Event" or kind == "EventAll" then -- (2026-10-04) 🎉 the launch event
		local reward
		PlayerData.update(player, function(p)
			if kind == "Event" then
				reward = type(index) == "number" and RewardLogic.claimEvent(p, index) or nil
			else
				reward = RewardLogic.claimEventAll(p)
			end
		end)
		if reward and kind == "Event" then
			give(player, reward, Config.LaunchEvent.Name)
			claimed = kind
		elseif reward then
			local e = Config.LaunchEvent
			local skin = reward.Skin and Formulas.skin(reward.Skin)
			give(player, reward, e.Name, string.format(EVENT_ALL_LINE, skin and skin.Name or "", e.Title))
			player:SetAttribute("EventTitle", e.Title)
			Net.push(player, "Banner", string.format(EVENT_ALL_BANNER, e.Title), "Rainbow")
			Net.pushAll("Notice", e.Name, string.format(EVENT_ALL_EVERYONE, player.DisplayName, e.Title))
			claimed = kind
		end
	elseif kind == "Daily" or kind == "DailyAll" or kind == "Weekly" then
		local reward
		PlayerData.update(player, function(p)
			if kind == "Daily" then
				reward = RewardLogic.claimDaily(p, index)
			elseif kind == "DailyAll" then
				reward = RewardLogic.claimDailyAll(p)
			else
				reward = RewardLogic.claimWeekly(p, index)
			end
		end)
		if reward then
			give(player, reward, kind == "Weekly" and "🎁 주간 선물상자 도전" or "✅ 오늘의 임무")
			claimed = kind
		end
	end
	if not batching[player] then
		refresh(player)
	end
	if claimed then
		Rewards.add(player, "RewardClaim", times) -- (2026-10-03: the beginner mission "🎁 보상 1번 받기")
		for _ = 1, times do
			for _, fn in ipairs(claimListeners) do
				task.defer(fn, player, claimed)
			end
		end
	end
end

local function snapshot(player)
	local profile = PlayerData.get(player)
	if not profile or not sessions[player] then
		return nil
	end
	countPlayed(player)
	local level = profile.DefenseLevel
	local now = os.time()
	local gifts = {}
	for i, g in ipairs(Config.Rewards.Playtime) do
		table.insert(gifts, { Minutes = g.Minutes, Text = RewardLogic.text(g.Reward, level, true), Icon = RewardLogic.icon(g.Reward),
			Taken = profile.Daily.Gifts[tostring(i)] == true, Ready = RewardLogic.playtimeReady(profile, i) })
	end
	local missions = {}
	for _, m in ipairs(profile.Daily.Missions) do
		local name = m.Kind
		for _, e in ipairs(Config.Rewards.Daily.Pool) do
			if e.Kind == m.Kind then
				name = string.format(e.Name, m.Target)
			end
		end
		table.insert(missions, { Name = name, Target = m.Target, Progress = m.Progress, Claimed = m.Claimed })
	end
	local milestones = {}
	for i, m in ipairs(Config.Rewards.Weekly.Milestones) do
		table.insert(milestones, { Keys = m.Keys, Text = RewardLogic.text(m.Reward, level, true), Icon = RewardLogic.icon(m.Reward),
			Claimed = profile.Weekly.Claimed[tostring(i)] == true })
	end
	local challenges = {}
	for _, c in ipairs(Config.Rewards.Weekly.Challenges) do
		local step, stage, ready = RewardLogic.weeklyStep(profile, c.Kind)
		local last = c.Steps[#c.Steps]
		if c.Unlock and not Unlocks.has(player, c.Unlock) then
			continue
		end
		table.insert(challenges, {
			Kind = c.Kind,
			Name = string.format(c.Name, (step or last).Target),
			Stage = math.min(stage, #c.Steps),
			Stages = #c.Steps,
			Target = (step or last).Target,
			Progress = (profile.Weekly.Progress or {})[c.Kind] or 0,
			Text = step and RewardLogic.text(step.Reward, level, true) or "모두 받음",
			Icon = RewardLogic.icon((step or last).Reward),
			Ready = ready,
			Done = step == nil,
		})
	end
	local offset = Config.Rewards.ResetOffsetHours * 3600
	-- the attendance tab: the 7 streak days and the monthly milestones
	local a = profile.Attendance
	local keyPrice = Formulas.keyPrice(level)
	local monthDino = Formulas.species(RewardLogic.monthDino(a.Month)).Name
	local streak = {}
	for i, r in ipairs(Config.Attendance.Streak) do
		table.insert(streak, { Text = RewardLogic.attendanceText(r, keyPrice, monthDino),
			Icon = r.LuckMinutes and "Luck" or RewardLogic.icon(r), Rarity = r.GuaranteedRarity })
	end
	local monthly = {}
	for i, m in ipairs(Config.Attendance.Monthly) do
		table.insert(monthly, { Days = m.Days, Text = RewardLogic.attendanceText(m, keyPrice, monthDino),
			Icon = m.MonthDino and "Dino" or m.ServerLuckMinutes and "Luck" or RewardLogic.icon(m),
			Claimed = a.MonthClaimed[tostring(i)] == true })
	end
	-- (2026-10-04) 🎉 the launch event's tab: each mission, what it gives, the all-done reward
	local e = Config.LaunchEvent
	local ev = profile.Event.Id == e.Id and profile.Event or { Progress = {}, Claimed = {}, AllClaimed = false }
	local eventMissions = {}
	for i, m in ipairs(e.Missions) do
		table.insert(eventMissions, { Name = string.format(m.Name, m.Target), Target = m.Target,
			Progress = ev.Progress[tostring(i)] or 0, Claimed = ev.Claimed[tostring(i)] == true,
			Text = RewardLogic.text(m.Reward, level, true), Icon = RewardLogic.icon(m.Reward) })
	end
	local eventSkin = e.AllReward.Skin and Formulas.skin(e.AllReward.Skin)
	-- (2026-10-04, "왜 이벤트 미션 광고창 안 뜨냐") whether the join pop-up is due (StarterPlayerScripts/EventAd asks), and
	-- if not, why (written to the screen's output)
	local open = RewardLogic.eventOpen(RewardLogic.dayNumber(now))
	local adWhy = not open and "이벤트 기간 아님" or ev.AllClaimed and "마지막 보상까지 받음"
		or (profile.Purchases.Offers or {}).EventHiddenDay == RewardLogic.dayNumber(now) and "오늘 하루 안 보기"
		or not profile.Tutorial.Done and "튜토리얼을 아직 안 끝냄" or TutorialField.isField() and "튜토리얼 필드"
		or (profile.Stats.Joins or 0) <= 1 and "첫 접속" or nil
	local event = { Open = open, Ad = adWhy == nil, AdWhy = adWhy, Missions = eventMissions,
		AllText = RewardLogic.text(e.AllReward, level, true), AllClaimed = ev.AllClaimed == true,
		AllReady = RewardLogic.eventAllReady(profile), SkinModel = eventSkin and eventSkin.Model,
		SkinName = eventSkin and eventSkin.Name, Title = e.Title }
	return {
		Event = event,
		Attendance = { Streak = a.Streak, StreakClaimed = a.StreakClaimed, Days = streak, MonthDays = a.MonthDays,
			Monthly = monthly, MonthDino = RewardLogic.monthDino(a.Month),
			-- (2026-10-02) the calendar: this month, and the dates checked in
			Calendar = RewardLogic.calendar(RewardLogic.dayNumber(now)), Log = a.MonthLog or {},
			-- (the friend bonus line under it: friends played with today)
			FriendsToday = profile.FriendBonus.Day == RewardLogic.dayNumber(now)
				and RewardLogic.friendsToday(profile, profile.FriendBonus.Day) or 0 }, -- (the same day: nothing changes)
		Challenges = challenges,
		Played = profile.Daily.Played,
		Gifts = gifts,
		Missions = missions,
		MissionText = RewardLogic.text(Config.Rewards.Daily.Reward, level, true),
		MissionIcon = RewardLogic.icon(Config.Rewards.Daily.Reward),
		AllText = RewardLogic.text(Config.Rewards.Daily.AllReward, level, true),
		AllIcon = RewardLogic.icon(Config.Rewards.Daily.AllReward),
		AllClaimed = profile.Daily.AllClaimed,
		DayEndsIn = 86400 - (now + offset) % 86400,
		WeeklyKeys = profile.Weekly.Keys,
		Milestones = milestones,
		WeekEndsIn = 7 * 86400 - (now + offset + 3 * 86400) % (7 * 86400),
	}
end

-- the attendance window, when something waits there (on joining, or after the update news is closed: BetaLog)
function Rewards.popupAttendance(player)
	local p = PlayerData.get(player)
	if player.Parent and p and RewardLogic.attendanceReady(p) > 0 and not player:GetAttribute("TutorialStep")
		and (p.Stats.Joins or 0) > 1 then
		Net.push(player, "OpenRewards", "Attendance")
	end
end

-- (2026-10-04, "런칭 기념 미션 광고 띄워줘야지 접속할 때마다. 이건 튜토 넘긴사람한테도 보여줘도 돼") the 🎉 event's pop-up
-- (Net push EventAd, StarterPlayerScripts/EventAd) on every join: once the player is free (the tutorial done or skipped,
-- nothing asked of them), Config.LaunchEvent.AdSeconds later, while the event runs and its all-done reward is not taken
local AD_WAIT_CHECK = 2 -- seconds between looks while a joining player is not free yet
local AD_WAIT_MAX = 900 -- seconds a session waits for that at most
-- waits until the joining player is free in the main game (the tutorial done or skipped, nothing asked of them):
-- true, or false when they left or it took too long (or on a tutorial field)
local function waitFree(player)
	if TutorialField.isField() then
		return false
	end
	local started = os.clock()
	while player.Parent and os.clock() - started < AD_WAIT_MAX do
		local profile = PlayerData.get(player)
		local busy = not profile or not profile.Tutorial.Done or player:GetAttribute("TutorialStep")
			or player:GetAttribute("LanguagePick") or player:GetAttribute("TutorialAsk") or player:GetAttribute("TutorialTravel")
		if not busy then
			return true
		end
		task.wait(AD_WAIT_CHECK)
	end
	return false
end

-- (2026-10-04, "시작하자마자 무료 뽑기를 한 번 주고" → "추천 다 적용해봐") an account that never drew gets its first free draw
-- once, as soon as it is free (Config.StarterMissions.FirstDraw: plain keys and the first draw's rarity at least ...).
-- One that drew (the tutorial's draws) is marked done.
local function firstDraw(player)
	local profile = PlayerData.get(player)
	if not profile or profile.FreeDraw or not waitFree(player) then
		return
	end
	while player.Parent and PlayerData.get(player) and not StarterLogic.reached(PlayerData.get(player).Starter, "Draws") do
		task.wait(AD_WAIT_CHECK)
	end
	profile = PlayerData.get(player)
	if not profile or profile.FreeDraw then
		return
	end
	local gift = Config.StarterMissions.FirstDraw
	local give = (profile.Stats.Draws or 0) == 0
	PlayerData.update(player, function(p)
		p.FreeDraw = true
		if give then
			RewardLogic.apply(p, { Keys = gift.Keys })
			p.GuaranteedDraws = p.GuaranteedDraws or {}
			p.GuaranteedDraws[gift.GuaranteedRarity] = (p.GuaranteedDraws[gift.GuaranteedRarity] or 0) + 1
		end
	end)
	if not give then
		return
	end
	local n = 0
	for _, k in pairs((PlayerData.get(player) or profile).GuaranteedDraws or {}) do
		n += k
	end
	player:SetAttribute("GuaranteedDraws", n)
end

-- Studio tests (TestCommands ;event): every 🎉 launch event mission done (their rewards still to take in the window)
function Rewards.testEvent(player)
	if sessions[player] and PlayerData.isLoaded(player) then
		PlayerData.update(player, function(p)
			RewardLogic.ensureEvent(p)
			for i, m in ipairs(Config.LaunchEvent.Missions) do
				p.Event.Progress[tostring(i)] = m.Target
			end
		end)
		refresh(player)
	end
end

-- (2026-10-04) 🐣 the rookie mining buff's end in server time, while the player stays (player attribute RookieEndsAt,
-- the board's line under the beginner missions; the server goes by profile.PlaySeconds: Formulas.rookieSpeed)
local function publishRookie(player)
	local profile = PlayerData.get(player)
	local _, left = Formulas.rookieSpeed(profile and profile.PlaySeconds)
	player:SetAttribute("RookieEndsAt", left > 0 and Workspace:GetServerTimeNow() + left or nil)
end

local function publishComeback(player)
	local profile = PlayerData.get(player)
	local tier = profile and RewardLogic.comebackTier(profile.Comeback.Days)
	player:SetAttribute("ComebackGift", tier and RewardLogic.text(tier.Reward, profile.DefenseLevel, true) or nil)
	player:SetAttribute("ComebackKey", tier and RewardLogic.icon(tier.Reward) or nil)
	player:SetAttribute("ComebackDays", tier and profile.Comeback.Days or nil)
end

local function claimComeback(player)
	if not PlayerData.isLoaded(player) or PlayerData.isPractice(player) then
		return
	end
	local reward = nil
	PlayerData.update(player, function(p)
		reward = RewardLogic.claimComeback(p, os.time())
	end)
	publishComeback(player)
	if reward then
		give(player, reward, COMEBACK_TITLE)
		Rewards.add(player, "Comeback", 1)
	end
end

function Rewards.setComeback(player, days)
	if PlayerData.isLoaded(player) and not PlayerData.isPractice(player) then
		PlayerData.update(player, function(p)
			p.Comeback.Days = 0
			RewardLogic.comeback(p, days * 86400)
		end)
		publishComeback(player)
	end
end

-- Studio tests (TestCommands): more minutes of play today (and in all: the rookie buff ends sooner)
function Rewards.addPlaytime(player, minutes)
	if sessions[player] and PlayerData.isLoaded(player) then
		ensure(player)
		PlayerData.update(player, function(p)
			RewardLogic.addPlayed(p, minutes * 60)
		end)
		refresh(player)
		publishRookie(player)
	end
end

function Rewards.init()
	-- (2026-10-04, "오늘 하루 안 보기") a join pop-up not again today: the 🎉 event's ("Event") or the starter pack's
	-- ("Offer", Monetization) - saved with the account's offers
	Net.onRequest("HideAdToday", { "string" }, function(player, kind)
		if (kind == "Event" or kind == "Offer") and PlayerData.isLoaded(player) then
			PlayerData.update(player, function(p)
				p.Purchases.Offers = p.Purchases.Offers or {}
				p.Purchases.Offers[kind .. "HiddenDay"] = RewardLogic.dayNumber(os.time())
			end)
		end
	end)
	Net.onRequest("ClaimReward", { "string", "any" }, claim)
	Net.onRequest("ClaimComeback", {}, claimComeback)
	Net.onAsk("GetRewards", {}, snapshot)
	PlayerData.onLoaded(function(player, profile)
		sessions[player] = { counted = os.clock() }
		player:SetAttribute("MiniKeysLeft", miniGamesLeft(profile))
		local lastSeen = profile.Stats.LastSeen or 0
		local away = lastSeen > 0 and os.time() - lastSeen or 0
		PlayerData.update(player, function(p)
			p.Stats.LastSeen = os.time()
		end)
		ensure(player)
		if away > 0 and not PlayerData.isPractice(player) and not TutorialField.isField() then
			PlayerData.update(player, function(p)
				RewardLogic.comeback(p, away)
			end)
		end
		publishComeback(player)
		refresh(player)
		publishRookie(player)
		player:SetAttribute("EventTitle", RewardLogic.eventTitle(PlayerData.get(player) or profile)) -- (2026-10-04, over the head)
		task.delay(OFFLINE_NOTICE_DELAY, function()
			if player.Parent then
				Rewards.payOffline(player, away)
			end
		end)
		task.spawn(firstDraw, player)
		-- (2026-10-04) the 🎉 event's pop-up: the screen asks when it is free (StarterPlayerScripts/EventAd); the push
		-- here was missed when its GetRewards ask hit the rate limit on joining
		task.delay(Config.Attendance.PopupDelay, function() -- (design 2.9: the attendance shows on joining)
			if not player:GetAttribute("NewsPending") then -- (the update news first: BetaLog opens it after)
				Rewards.popupAttendance(player)
			end
		end)
	end)
	Players.PlayerRemoving:Connect(function(player)
		batching[player] = nil
		countPlayed(player)
		if PlayerData.isLoaded(player) then
			PlayerData.update(player, function(p)
				p.Stats.LastSeen = os.time()
			end)
		end
		sessions[player], pending[player], pendingKeys[player] = nil, nil, nil
	end)
	task.spawn(function()
		local sinceSeen, sinceBadge = 0, 0
		while true do
			task.wait(FLUSH_EVERY)
			sinceSeen += FLUSH_EVERY
			sinceBadge += FLUSH_EVERY
			for _, player in ipairs(Players:GetPlayers()) do
				countPlayed(player)
				flush(player)
			end
			if sinceSeen >= SEEN_EVERY then
				sinceSeen = 0
				for player in pairs(sessions) do
					if PlayerData.isLoaded(player) then
						PlayerData.update(player, function(p)
							p.Stats.LastSeen = os.time()
						end)
					end
				end
			end
			if sinceBadge >= 15 then -- playtime gifts come ready as time passes
				sinceBadge = 0
				for player in pairs(sessions) do
					refresh(player)
				end
			end
		end
	end)
end

return Rewards
