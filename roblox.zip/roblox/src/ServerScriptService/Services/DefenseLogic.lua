--[[
DefenseLogic: one base's defense field as plain data, with no Roblox services, so the rules can be
tested (tools/tests/defense_logic_test.lua). The Defense service runs one field per online owner.

The field works in the arena's own flat coordinates: the arena center is (0, 0), monsters walk the map's road
(Formulas.lanePath, Config.Defense.Maps) from its start gate, and a monster's place is its distance s walked along
it, plus its own offset across the road (up to LaneSpread either side). (2026-10-06) One reaching the end gate goes
("L" event): in a promotion fight or the challenge it costs lives (Promotion.Lives; the boss all of them).

Each step (Config.Defense.TickSeconds):
1. spawning: idle = Defense.Idle.SpawnPerSecond up to MaxOnTrack (pauses when full); during a
   promotion fight (DefenseLogic.startPromotion) Promotion.SpawnPerSecond with no cap, and the boss
   at BossAppearsAt (health × Formulas.bossHealthMultiplier, BossSpeed, an attribute by level: its own
   attribute does half damage, ice slows it half as much and never freezes it)
2. speed: frozen = 0, else MonsterSpeed × (1 − ice slow) × (1 − armored slow aura)
3. burn damage, then every unit whose attack is ready attacks (theme attack + attribute effect)
4. dead monsters pay Formulas.killReward(level)

Everything clients need to draw it goes into field.events (small arrays, sent by the service):
	{ "S", id, s, v, hpFraction, model, level, offset, boss, attribute, kind, group, leader, groupId }  spawned (the
	                                               last ones only when one is set; false for the unset ones before it)
	{ "P", "success" | "fail", reason }           a promotion fight ended (reason: "leak" | "time" | "cancel")
	{ "L", id }                                    went out through the end gate
	{ "G", groupId }                               a whole 🚩 group was beaten (none got through)
	{ "C" }                                        the track was cleared (a promotion starts or ends)
	{ "M", id, s, v }                              speed changed (clients move it on from s at v)
	{ "H", id, hpFraction, id, hpFraction, ... }   health changed (a step's together)
	{ "D", id }                                    died
	{ "T", unitId, reach }                         a pond's sea dino sent a 🌊 wave (fossils in reach pushed back)
	{ "A", unitId, { hit ids }, { chain ids }, combo }  a unit attacked (for effects; combo "Shock" | "Freeze"
	                                               when a combo worked, for its label)
Positions and speeds in events belong to the time the events are sent (the end of the step).

Attributes (2026-10-03: every effect on every hit, paid for with the hit's damage, Attributes.*.DamageMultiplier):
ice (slows and freezes, with a cooldown after a thaw), fire (burn), electric (chain), poison (a pool on the track that
hurts every fossil in it), earth (pushes back along the track, once a cooldown), water (wet), neutral (no effect, +15%,
more on a boss). Fire, ice and water blast round their target (Burst): every fossil in it gets the effect ("R" event:
{ "R", s, offset, radius, attribute }); a poison pool is { "W", s, offset, radius, seconds }. Combos: wet monsters take electric damage × Combo.WetElectricDamage and stay frozen
Combo.WetFreezeMultiplier times as long. field.slow (the owner's farm buff, 0-0.4) slows every monster.

(2026-10-02, "디펜스 전략의 재미") Fossil kinds (Config.Defense.Kinds) in promotion fights and the challenge:
fast, armored (one attribute it takes half from) and swarms; a fossil with an attribute (the boss, an armored
one, or every one under the week's challenge rule Resist) takes half from that attribute's attacks and burns.
]]

local Config = if game then require(game:GetService("ReplicatedStorage"):WaitForChild("Config")) else CONFIG
local Formulas = if game
	then require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Formulas"))
	else LOAD("ReplicatedStorage/Shared/Formulas")

local DefenseLogic = {}

local SWARM_STAGGER = 1.2 -- studs between a swarm's two rows along the track (looks)
local HEALTH_EVENT_EVERY = 0.5 -- seconds between health events of a monster that is only burning (display)
local HIT_HEALTH_EVERY = 0.15

local D = Config.Defense
local A = Config.Attributes

local function setPath(field, mapId)
	field.path = Formulas.lanePath(mapId)
	field.mapId = field.path.Id
	field.healthScale = field.path.map.HealthScale or 1
end

function DefenseLogic.newField(mapId)
	local field = {
		time = 0,
		monsters = {}, -- list
		nextId = 1,
		spawnDebt = 0,
		idleDealt = {},
		units = {}, -- list of { Id, X, Z, Stats, cooldown }
		events = {},
		kills = 0,
		reward = 0,
		promotion = nil, -- { time, boss } during a promotion fight
		slow = 0, -- the owner's farm buff: every monster this much slower
		pools = {}, -- poison pools on the track: { unit, x, z, r, untilTime, dps }
		nextGroupId = 1,
		groupsCleared = 0,
	}
	setPath(field, mapId)
	return field
end

function DefenseLogic.setMap(field, mapId)
	setPath(field, mapId)
	field.monsters = {}
	field.pools = {}
	field.spawnDebt = 0
	table.insert(field.events, { "C" })
end

-- a promotion fight: the track is cleared and the wave starts (the result comes out of step)
function DefenseLogic.startPromotion(field, idle)
	field.pools = {}
	if not idle then
		field.monsters = {}
		field.spawnDebt = 0
		table.insert(field.events, { "C" })
	end
	field.paused = nil
	field.promotion = { time = 0, boss = nil, lives = D.Promotion.Lives, lost = 0, nextGroup = 1, idle = idle == true }
	field.dealt = {}
end

local function dropIdleBoss(field, promo)
	for i = #field.monsters, 1, -1 do
		local m = field.monsters[i]
		if m == promo.boss or m.crowd == promo then
			table.remove(field.monsters, i)
			table.insert(field.events, { "L", m.id, 0 })
		end
	end
end

local function markCrowd(field, promo, from, level)
	local c = D.Promotion.Gauge.Crowd
	local speed = 1 + (c.Speed - 1) * math.clamp((level - 2) / c.SpeedRampLevels, 0, 1)
	for i = from, #field.monsters do
		local m = field.monsters[i]
		if not m.isBoss and not m.crowd then
			m.crowd = promo
			if not (m.kind and m.kind.Id == "Sprinter" and not c.SprinterRamp) then
				m.speed *= speed
			end
			promo.crowdAlive += 1
		end
	end
end

-- (2026-10-02) ♾️ 무한 도전 (Config.Defense.Challenge): the track is cleared and waves start at 1; the end comes
-- out of step (result "challenge" and the waves cleared). Not during a promotion fight.
-- rule: this week's (Formulas.challengeRule), or nil
function DefenseLogic.startChallenge(field, rule)
	field.pools = {}
	field.monsters = {}
	field.spawnDebt = 0
	field.challengeDealt = {}
	field.challenge = { time = 0, wave = 1, waveTime = 0, rule = rule, lives = D.Challenge.Lives }
	table.insert(field.events, { "C" })
end

-- giving up the challenge: it ends now with the waves cleared so far (nil when there is none)
function DefenseLogic.cancelChallenge(field)
	local ch = field.challenge
	if not ch then
		return nil
	end
	field.challenge = nil
	field.monsters = {}
	field.spawnDebt = 0
	table.insert(field.events, { "C" })
	return ch.wave - 1
end

-- during the challenge: the wave, seconds left in it, monsters on the track (nil when there is none)
function DefenseLogic.challengeStatus(field)
	local ch = field.challenge
	if not ch then
		return nil
	end
	return ch.wave, D.Challenge.WaveSeconds - ch.waveTime, #field.monsters, math.max(0, ch.lives)
end

-- giving up a promotion fight: the track is cleared and the fight ends as a failure ("cancel");
-- false when there is no fight
function DefenseLogic.cancelPromotion(field)
	local promo = field.promotion
	if not promo then
		return false
	end
	field.promotion = nil
	field.paused = nil
	field.lastDealt, field.dealt = field.dealt or {}, nil
	if promo.idle then
		dropIdleBoss(field, promo)
	else
		field.monsters = {}
		field.spawnDebt = 0
		table.insert(field.events, { "C" })
	end
	table.insert(field.events, { "P", "fail", "cancel" })
	return true
end

-- where a monster at distance s (and offset across the track) stands, in flat arena coordinates
function DefenseLogic.position(field, s, offset)
	local x, z = Formulas.lanePoint(field.path, s, offset)
	return x, z
end

-- units: list of { Id, X, Z, Stats = Formulas.unitStats(...) }; attack cooldowns carry over by Id
function DefenseLogic.setUnits(field, units)
	local cooldowns = {}
	for _, u in ipairs(field.units) do
		cooldowns[u.Id] = u.cooldown
	end
	field.units = {}
	for _, u in ipairs(units) do
		local near = Formulas.laneDistance(field.path, u.X, u.Z) <= u.Stats.Reach + D.MonsterRadius
		table.insert(field.units, { Id = u.Id, Species = u.Species, X = u.X, Z = u.Z, Stats = u.Stats, cooldown = cooldowns[u.Id] or 0, Target = u.Target,
			active = near and not u.Rest, Rest = u.Rest })
	end
	field.synergies = Formulas.teamSynergies(field.units)
end

function DefenseLogic.clear(field)
	field.monsters = {}
	field.pools = {}
	field.events = {}
	field.spawnDebt = 0
end

-- every monster now, for a player who joins: list of { id, s, v, hpFraction, model, level, offset }
function DefenseLogic.snapshot(field)
	local list = {}
	for _, m in ipairs(field.monsters) do
		local g = m.group
		table.insert(list, { m.id, m.s, m.vSent, m.hp / m.maxHp, m.model, m.level, m.offset, m.isBoss or false,
			m.attribute or false, m.kind and m.kind.Id or false, g and g.kind.Id or false, m.leader or false,
			g and g.id or false })
	end
	return list
end

local function emit(field, event)
	table.insert(field.events, event)
end

-- where across the track a new monster walks: the rows (D.Lanes) in turn, a little jitter in each
local function lanedOffset(field, rng)
	field.spawnCount = (field.spawnCount or 0) + 1
	local lane = field.spawnCount % D.Lanes
	local across = (lane + 0.5) / D.Lanes * 2 - 1 -- the middle of each of Lanes equal strips (like random spread)
	return math.clamp(across * D.LaneSpread + (rng() - 0.5) * 2 * D.LaneJitter, -D.LaneSpread, D.LaneSpread)
end

-- a promotion fight's or the challenge's new fossil: one of Config.Defense.Kinds, or nil (plain)
local function rollKind(field, level, rng)
	local ch = field.challenge
	if not ch and not field.promotion then
		return nil
	end
	local open = {} -- (no roll while none can come: the early fights stay as they were)
	for _, k in ipairs(D.Kinds) do
		local times = ch and ch.rule and ch.rule.KindChance and ch.rule.KindChance[k.Id] or 1
		local from = ch and (times > 1 and math.ceil(k.FromWave / 3) or k.FromWave) or k.FromLevel
		if (ch and ch.wave or level) >= from then
			table.insert(open, { k, k.ChancePercent * times })
		end
	end
	if #open == 0 then
		return nil
	end
	local roll = rng() * 100
	for _, o in ipairs(open) do
		if roll < o[2] then
			return o[1]
		end
		roll -= o[2]
	end
	return nil
end

-- kind: one of Config.Defense.Kinds (nil: plain); s, offset: where (nil: the portal, a lane)
local function spawn(field, level, rng, boss, kind, s, offset, group, leader)
	local ch = field.challenge
	local fight = field.promotion and (boss or not field.promotion.idle or field.crowdSpawn)
	local up = (kind and (kind.Speed or 1) > 1) and 1 or Formulas.speedUp(level)
	local m = {
		id = field.nextId,
		s = 0,
		level = ch and ch.wave or level, -- (the challenge's fossils show their wave)
		-- idle fossils are a share as tough (they are to watch and earn); a promotion fight's are whole
		-- (field.promoHealthScale: the tutorial's easier first promotion)
		maxHp = (ch and Formulas.challengeHealth(ch.wave)
			or Formulas.monsterHealth(level) * (fight and (field.promoHealthScale or 1) * (boss and 1 or D.Promotion.FossilHealth)
				or D.Idle.HealthShare))
			* (kind and kind.Health or 1) * (boss and 1 or field.healthScale) / up,
		model = 1 + math.floor(rng() * #Config.Monsters.Models),
		-- idle hunting walks in rows (looks); a promotion fight keeps its random spread (its balance)
		offset = offset or (fight or ch) and (rng() * 2 - 1) * D.LaneSpread or lanedOffset(field, rng),
		iceUntil = -1,
		freezeUntil = -1,
		thawedAt = -math.huge, -- (ice: when its last freeze ended; it can't freeze again for Ice.FreezeCooldown)
		burnUntil = -1,
		burnDps = 0,
		wetUntil = -1,
		aura = 0,
		vSent = D.MonsterSpeed * up * (kind and kind.Speed or 1),
		speed = D.MonsterSpeed * up * (kind and kind.Speed or 1),
		hpSentAt = field.time,
		kind = kind,
		rewardScale = kind and kind.Health or 1, -- (the kill pays by how tough it was)
		leakCost = kind and kind.LeakLives or D.Promotion.LeakLives,
		attribute = ch and ch.rule and ch.rule.Resist or nil,
	}
	if kind and kind.Resists then
		m.attribute = kind.Resists[1 + math.floor(rng() * #kind.Resists)]
	end
	if s then
		m.s = s
	end
	if group then
		local gk = group.kind
		local scale = (gk.Health or 1) * (leader and (gk.LeaderHealth or D.Groups.LeaderHealth) or 1)
		m.maxHp *= scale
		m.rewardScale *= scale
		m.speed *= gk.Speed or 1
		m.vSent = m.speed
		m.attribute = group.element or m.attribute
		m.group, m.leader = group, leader or nil
		group.alive += 1
	end
	if boss then
		m.isBoss = true
		m.maxHp *= Formulas.bossHealthMultiplier(level) * (field.path.map.BossHealth or 1) * up
		local speed = Formulas.bossSpeed(level)
		m.speed, m.vSent, m.offset = speed, speed, 0
		m.attribute = Formulas.bossAttribute(level)
		m.weakness = Formulas.bossWeakness(m.attribute) -- (2026-10-03) its weak attribute: ×1.5, full effects
	end
	m.hp = m.maxHp
	field.nextId += 1
	m.x, m.z = DefenseLogic.position(field, m.s, m.offset)
	table.insert(field.monsters, m)
	local e = { "S", m.id, m.s, m.vSent, 1, m.model, m.level, m.offset }
	if m.isBoss or m.attribute or kind or group then -- (no holes: a remote's array stops at the first nil)
		e[9], e[10], e[11] = m.isBoss or false, m.attribute or false, kind and kind.Id or false
	end
	if group then
		e[12], e[13], e[14] = group.kind.Id, leader or false, group.id
	end
	emit(field, e)
	return m
end

-- a new fossil of a promotion fight or the challenge (or idle): maybe a special kind; a swarm comes Count at once,
-- side by side across the track
local function spawnWave(field, level, rng)
	local kind = rollKind(field, level, rng)
	if kind and kind.Count then
		for i = 1, kind.Count do
			local across = ((i - 0.5) / kind.Count * 2 - 1) * D.LaneSpread
			spawn(field, level, rng, false, kind, (i % 2) * SWARM_STAGGER, across)
		end
	else
		spawn(field, level, rng, false, kind)
	end
end

local function spawnGroup(field, level, rng, g)
	local group = { id = field.nextGroupId, kind = Formulas.groupKind(g.Kind), element = g.Element, alive = 0 }
	field.nextGroupId += 1
	local spacing = D.Groups.Spacing
	group.leader = spawn(field, level, rng, false, nil, 0, 0, group, true)
	for i = 1, g.Count do
		local row = (i + 1) // 2
		spawn(field, level, rng, false, nil, -row * spacing, (i % 2 == 1 and -0.5 or 0.5) * D.LaneSpread, group, false)
	end
	return group
end

local function distance(ax, az, bx, bz)
	local dx, dz = ax - bx, az - bz
	return math.sqrt(dx * dx + dz * dz)
end

local function inReach(u, m)
	local dx, dz = u.X - m.x, u.Z - m.z
	local r = u.Stats.Reach + D.MonsterRadius
	return dx * dx + dz * dz <= r * r
end

local function immuneTo(m, attack, attribute)
	local k = m.kind
	return k ~= nil and ((attack ~= nil and k.ImmuneAttack == attack) or (attribute ~= nil and k.ImmuneAttribute == attribute))
end

local function seen(u, m)
	local sight = m.group and m.group.kind.Sight
	if sight then
		local dx, dz = u.X - m.x, u.Z - m.z
		local r = sight + D.MonsterRadius
		if dx * dx + dz * dz > r * r then
			return false
		end
	end
	return true
		and not immuneTo(m, u.Stats.Attack, u.Stats.Attribute)
		and (m.revealed or not (m.kind and m.kind.Hidden))
end

local function pickBy(field, u, mode)
	local best, bestScore = nil, -math.huge
	for _, m in ipairs(field.monsters) do
		if m.hp > 0 and inReach(u, m) and seen(u, m) then
			local score = mode == "First" and m.s or mode == "Last" and -m.s or mode == "Strong" and m.hp
				or -distance(u.X, u.Z, m.x, m.z)
			if score > bestScore then
				best, bestScore = m, score
			end
		end
	end
	return best
end

local function waveFirst(field, u, promo)
	local best = nil
	for _, m in ipairs(field.monsters) do
		if m.hp > 0 and (m.crowd == promo or m == promo.boss) and inReach(u, m) and seen(u, m) and (not best or m.s > best.s) then
			best = m
		end
	end
	return best
end

local function nearestInReach(field, u)
	local best, bestD = nil, math.huge
	for _, m in ipairs(field.monsters) do
		if m.hp > 0 and inReach(u, m) and seen(u, m) then
			local d = distance(u.X, u.Z, m.x, m.z)
			if d < bestD then
				best, bestD = m, d
			end
		end
	end
	return best
end

local function around(field, cx, cz, radius, list)
	list = list or {}
	local r = radius + D.MonsterRadius
	local limit = r * r
	for _, m in ipairs(field.monsters) do
		if m.hp > 0 then
			local dx, dz = cx - m.x, cz - m.z
			if dx * dx + dz * dz <= limit then
				table.insert(list, m)
			end
		end
	end
	return list
end

local function countAround(field, cx, cz, radius)
	local n, limit = 0, (radius + D.MonsterRadius) ^ 2
	for _, m in ipairs(field.monsters) do
		local dx, dz = cx - m.x, cz - m.z
		if m.hp > 0 and dx * dx + dz * dz <= limit then
			n += 1
		end
	end
	return n
end

local SPLASH_TRIES = 12

-- the monsters a unit's attack hits (the first one is the main target), or nil when none is in reach
local function targets(field, u)
	local st = u.Stats
	if u.Target and u.Target ~= "Auto" then
		local main = pickBy(field, u, u.Target)
		if not main then
			return nil
		end
		if st.Attack == "AreaAround" or st.Attack == "Splash" then
			local hit = { main }
			for _, m in ipairs(around(field, main.x, main.z, st.AreaRadius)) do
				if m ~= main then
					table.insert(hit, m)
				end
			end
			return hit
		elseif st.Attack ~= "PiercingLine" then
			return { main }
		end
	end
	if st.Attack == "SingleTarget" then -- carnivores: the toughest monster in reach (bosses first)
		local promo = field.promotion
		local first = promo and promo.idle and waveFirst(field, u, promo)
		if first then
			return { first }
		end
		local best = nil
		for _, m in ipairs(field.monsters) do
			if m.hp > 0 and inReach(u, m) and seen(u, m) and (not best or m.hp > best.hp) then
				best = m
			end
		end
		return best and { best }
	elseif st.Attack == "AreaAround" then -- herbivores, armored: a stomp around the nearest monster
		local target = nearestInReach(field, u)
		if not target then
			return nil
		end
		local hit = { target }
		for _, m in ipairs(around(field, target.x, target.z, st.AreaRadius)) do
			if m ~= target then
				table.insert(hit, m)
			end
		end
		return hit
	elseif st.Attack == "PiercingLine" then -- sky: a straight line toward the nearest, through up to PierceMax
		local target = (u.Target and u.Target ~= "Auto") and pickBy(field, u, u.Target) or nearestInReach(field, u)
		if not target then
			return nil
		end
		local len = distance(u.X, u.Z, target.x, target.z)
		local dx, dz = (target.x - u.X) / len, (target.z - u.Z) / len
		local along = {}
		for _, m in ipairs(field.monsters) do
			if m.hp > 0 and seen(u, m) then
				local rx, rz = m.x - u.X, m.z - u.Z
				local t = rx * dx + rz * dz
				local side = math.abs(rx * dz - rz * dx)
				if t >= 0 and t <= st.Reach + D.MonsterRadius and side <= st.PierceWidth / 2 + D.MonsterRadius then
					table.insert(along, { m = m, t = t })
				end
			end
		end
		table.sort(along, function(a, b)
			return a.t < b.t
		end)
		local hit = {}
		for i = 1, math.min(st.PierceMax, #along) do
			hit[i] = along[i].m
		end
		return #hit > 0 and hit or { target }
	elseif st.Attack == "Splash" then -- sea: lands where the most monsters are bunched up
		local inRange = {}
		for _, m in ipairs(field.monsters) do
			if m.hp > 0 and inReach(u, m) and seen(u, m) then
				table.insert(inRange, m)
			end
		end
		local best, bestCount = nil, -1
		local stride = math.max(1, math.ceil(#inRange / SPLASH_TRIES))
		for i = 1, #inRange, stride do
			local m = inRange[i]
			local count = countAround(field, m.x, m.z, st.AreaRadius)
			if count > bestCount then
				best, bestCount = m, count
			end
		end
		if not best then
			return nil
		end
		local hit = { best }
		for _, m in ipairs(around(field, best.x, best.z, st.AreaRadius)) do
			if m ~= best then
				table.insert(hit, m)
			end
		end
		return hit
	end
	return nil
end

-- attribute: the attacker's; a fossil with an attribute (the boss, an armored one, the week's rule) takes half from it
-- and a boss its weakness's at WeaknessDamageMultiplier
local function credit(field, id, m, amount)
	local promo = field.promotion
	local bossFight = promo and (not promo.idle or m.isBoss or m.crowd == promo)
	local dealt = bossFight and field.dealt or field.challenge and field.challengeDealt or field.idleDealt
	if dealt and id and amount > 0 and m.hp > 0 then
		dealt[id] = (dealt[id] or 0) + math.min(amount, m.hp)
	end
end

local function damage(field, m, amount, attribute, by)
	if attribute == m.attribute then
		amount *= D.Boss.SameAttributeDamageMultiplier
	elseif m.weakness and attribute == m.weakness then
		amount *= D.Boss.WeaknessDamageMultiplier
	end
	local g = m.group
	if g and g.kind.Guard and not m.leader and g.leader.hp > 0 and not g.leader.gone then
		amount *= g.kind.Guard
	end
	credit(field, by, m, amount)
	m.hp -= amount
	m.hitNow = true
end

local function wet(field, m)
	return m.wetUntil > field.time
end

-- (2026-10-03) a unit's effect strength (Formulas.effectStrength: rarity and size; 1 without it) and its areas
local function strengthOf(u)
	return u.Stats.Effect or 1
end
local function areaOf(u)
	return Formulas.effectArea(strengthOf(u))
end

-- earth: back along the track (bosses half as far); clients get the new place at once
local function pushBack(field, m, area)
	local distance = A.Earth.PushDistance * area * (m.isBoss and m.weakness ~= "Earth" and A.Earth.BossPushMultiplier or 1)
	m.s = math.max(math.min(m.s, 0), m.s - distance)
	m.x, m.z = DefenseLogic.position(field, m.s, m.offset)
	emit(field, { "M", m.id, m.s, m.vSent })
end

-- one hit with the unit's attribute effect; returns "Shock" or "Freeze" when a combo worked
local function hit(field, u, m, amount, rng)
	local synergy = field.synergies or {}
	local theme = u.Stats.Theme
	if synergy.Predator and theme == "Carnivore" then
		amount *= 1 + D.Synergies.Predator
	end
	if synergy.Sky and theme == "Sky" and m.kind then
		amount *= 1 + D.Synergies.Sky
	end
	local attribute = u.Stats.Attribute
	if immuneTo(m, u.Stats.Attack, attribute) then
		return nil
	end
	local combo = nil
	-- (the price of an effect that always comes on; 2026-10-03: a weaker effect, a common's or a small one's, costs
	-- less of the hit: the price × its strength, up to a legendary's full price)
	amount *= Formulas.effectPrice(A[attribute] and A[attribute].DamageMultiplier or 1, strengthOf(u))
	-- (2026-10-03, "보스의 경우나 저항력이 발생해서 100퍼로 발현이 안되거나 면역되는거지") resistance: a fossil of the
	-- attacker's own attribute (the boss's, an armored one's, the week's) takes none of its effect (and half its damage,
	-- in damage); a boss takes the others at Boss.EffectShare (slow, push, burn, poison, wet) and never freezes
	local immune = attribute == m.attribute
	local share = m.isBoss and attribute ~= m.weakness and D.Boss.EffectShare or 1 -- (its weakness: in full)
	local strength = strengthOf(u) -- (2026-10-03) the effect's seconds grow with the dino's rarity and size
	if attribute == "Neutral" then
		amount *= (1 + A.Neutral.DamageBonus) * (m.isBoss and A.Neutral.BossDamageMultiplier or 1)
	elseif attribute == "Electric" and wet(field, m) then
		amount *= A.Combo.WetElectricDamage
		combo = "Shock"
		m.comboDone = true
	elseif immune then -- (no effect)
	elseif attribute == "Water" then
		-- (the tutorial's combo step: a fossil stays wet until it gets its combo, wherever the ice dino stands — with
		-- the ice before the water on the track, the 3 s ran out long before it came round to the ice again)
		m.wetUntil = field.time + (field.sureCombo and not m.comboDone and math.huge or A.Water.WetDuration * strength * share)
	elseif attribute == "Earth" then
		if field.time >= (m.pushedAt or -math.huge) + A.Earth.PushCooldown then -- (every hit, once a cooldown)
			m.pushedAt = field.time
			pushBack(field, m, areaOf(u))
		end
	elseif attribute == "Ice" then
		m.iceUntil = field.time + A.Ice.SlowDuration * strength -- (every hit: sure)
		local wetNow = wet(field, m)
		local ready = field.time >= m.thawedAt + A.Ice.FreezeCooldown
			or (wetNow and field.sureCombo) -- (the tutorial's combo step: Defense)
		if ready and m.freezeUntil <= field.time and not (m.isBoss and A.Ice.BossFreezeImmune) then
			m.freezeUntil = field.time + A.Ice.FreezeDuration * strength * (wetNow and A.Combo.WetFreezeMultiplier or 1)
			m.thawedAt = m.freezeUntil
			combo = wetNow and "Freeze" or nil
			m.comboDone = m.comboDone or wetNow
		end
	elseif attribute == "Fire" then
		local burn = u.Stats.Damage * A.Fire.DamagePerSecond * share
		m.burnUntil = field.time + A.Fire.Duration * strength
		if burn >= m.burnDps then
			m.burnBy = u.Id
		end
		m.burnDps = math.max(m.burnDps, burn)
	end
	damage(field, m, amount, attribute, u.Id)
	return combo
end

local function attack(field, u, rng)
	local hitList = targets(field, u)
	if not hitList then
		return false
	end
	local ids, chainIds = {}, {}
	local combo = nil
	for _, m in ipairs(hitList) do
		combo = hit(field, u, m, u.Stats.Damage, rng) or combo
		table.insert(ids, m.id)
	end
	local attribute = u.Stats.Attribute
	local own = A[attribute]
	local main = hitList[1]
	if own and own.Burst then -- (fire, ice, water) a blast round the main target: its effect on every fossil in it
		local hitSet = {}
		for _, m in ipairs(hitList) do
			hitSet[m] = true
		end
		local radius = own.Burst * areaOf(u)
		for _, m in ipairs(around(field, main.x, main.z, radius)) do
			if not hitSet[m] then
				combo = hit(field, u, m, u.Stats.Damage * own.BurstDamage, rng) or combo
				table.insert(chainIds, m.id) -- (drawn from the main target outward, like a chain)
			end
		end
		emit(field, { "R", main.s, main.offset, radius, attribute })
	elseif attribute == "Poison" then -- a pool where the main target stood; the dino's oldest goes past PoolsPerUnit
		local mine = 0
		for i = #field.pools, 1, -1 do
			if field.pools[i].unit == u.Id then
				mine += 1
				if mine >= A.Poison.PoolsPerUnit then
					table.remove(field.pools, i)
				end
			end
		end
		local radius, seconds = A.Poison.PoolRadius * areaOf(u), A.Poison.PoolSeconds * strengthOf(u)
		table.insert(field.pools, { unit = u.Id, x = main.x, z = main.z, r = radius,
			untilTime = field.time + seconds, dps = u.Stats.Damage * A.Poison.DamagePerSecond })
		emit(field, { "W", main.s, main.offset, radius, seconds })
	end
	if attribute == "Electric" then -- chains from the main target to the nearest others
		local main = hitList[1]
		local hitSet = {}
		for _, m in ipairs(hitList) do
			hitSet[m] = true
		end
		local near = {}
		for _, m in ipairs(around(field, main.x, main.z, A.Electric.ChainRadius)) do
			if not hitSet[m] and not immuneTo(m, nil, "Electric") then
				table.insert(near, { m = m, d = distance(main.x, main.z, m.x, m.z) })
			end
		end
		table.sort(near, function(a, b)
			return a.d < b.d
		end)
		for i = 1, math.min(Formulas.chainTargets(strengthOf(u)), #near) do
			local chained = near[i].m
			local shock = wet(field, chained)
			combo = shock and "Shock" or combo
			chained.comboDone = chained.comboDone or shock
			damage(field, chained, u.Stats.Damage * A.Electric.ChainDamage * (shock and A.Combo.WetElectricDamage or 1),
				"Electric", u.Id)
			table.insert(chainIds, near[i].m.id)
		end
	end
	emit(field, { "A", u.Id, ids, chainIds, combo })
	return true
end

local function pauseField(field)
	field.paused = true
	for _, m in ipairs(field.monsters) do
		m.vSent = 0
		emit(field, { "M", m.id, m.s, 0 })
	end
end

function DefenseLogic.resume(field)
	field.paused = nil
end

-- rng() -> a number in [0, 1)
function DefenseLogic.step(field, dt, level, rng)
	if field.paused then
		return 0, 0, nil, nil
	end
	field.time += dt
	local now = field.time

	-- 1. spawning
	local promo = field.promotion
	if promo then
		promo.time += dt
		if not promo.boss and promo.time >= (promo.idle and 0 or D.Promotion.BossAppearsAt) then
			promo.boss = spawn(field, level, rng, true)
			if promo.idle then
				promo.crowdTotal, promo.crowdSpawned, promo.crowdAlive, promo.crowdDebt = Formulas.bossCrowdCount(level), 0, 0, 0
				local g = D.Promotion.Gauge
				for i = 1, Formulas.bossAirships(level) do
					local from = #field.monsters + 1
					field.crowdSpawn = true
					promo.airships = promo.airships or {}
					local ship = spawn(field, level, rng, false, Formulas.fossilKind("Airship"), 0,
						i * g.AirshipOffset * (i % 2 == 0 and -1 or 1))
					ship.maxHp *= Formulas.bossAirshipHealth(level)
					ship.hp = ship.maxHp
					ship.split = g.AirshipSplit
					promo.airships[i] = ship
					field.crowdSpawn = nil
					markCrowd(field, promo, from, level)
				end
			end
		end
		promo.airships = promo.airships or {}
		for i, row in ipairs(D.Airships.Times) do
			if not promo.idle and level >= row.Level and promo.time >= row.At and not promo.airships[i] then
				promo.airships[i] = spawn(field, level, rng, false, Formulas.fossilKind("Airship"), 0, 0)
			end
		end
		promo.groups = promo.groups or Formulas.fightGroups(level)
		while promo.groups[promo.nextGroup] and (promo.idle or promo.time >= promo.groups[promo.nextGroup].Time) do
			local from = #field.monsters + 1
			field.crowdSpawn = promo.idle
			spawnGroup(field, level, rng, promo.groups[promo.nextGroup])
			field.crowdSpawn = nil
			if promo.idle then
				markCrowd(field, promo, from, level)
			end
			promo.nextGroup += 1
		end
		if promo.idle and promo.crowdTotal then
			promo.crowdDebt += D.Promotion.Gauge.Crowd.PerSecond * dt
			while promo.crowdDebt >= 1 and promo.crowdSpawned < promo.crowdTotal do
				promo.crowdDebt -= 1
				promo.crowdSpawned += 1
				local from = #field.monsters + 1
				local c = D.Promotion.Gauge.Crowd
				field.crowdSpawn = true
				if level >= c.SprinterFrom and promo.crowdSpawned % c.SprinterEvery == 0 then
					spawn(field, level, rng, false, Formulas.fossilKind("Sprinter"))
				else
					spawnWave(field, level, rng)
				end
				field.crowdSpawn = nil
				markCrowd(field, promo, from, level)
			end
		end
	end
	local ch = field.challenge
	if ch then
		ch.time += dt
		ch.waveTime += dt
		while ch.waveTime >= D.Challenge.WaveSeconds do
			ch.waveTime -= D.Challenge.WaveSeconds
			ch.wave += 1
			local g = Formulas.challengeGroup(ch.wave)
			if g then
				spawnGroup(field, level, rng, g)
			end
			local A2 = D.Airships
			if ch.wave >= A2.ChallengeFromWave and (ch.wave - A2.ChallengeFromWave) % A2.ChallengeEvery == 0 then
				spawn(field, level, rng, false, Formulas.fossilKind("Airship"), 0, 0)
			end
		end
	end
	local fighting = promo and not promo.idle
	field.spawnDebt += (ch and D.Challenge.SpawnPerSecond or fighting and Formulas.promotionSpawnRate(level) or D.Idle.SpawnPerSecond) * dt
	if promo and promo.idle then
		field.spawnDebt = 0
	end
	while field.spawnDebt >= 1 do
		if not fighting and not ch and #field.monsters >= D.Idle.MaxOnTrack then
			field.spawnDebt = 1 -- paused while full, the next one comes as soon as there is room
			break
		end
		field.spawnDebt -= 1
		spawnWave(field, level, rng)
	end

	-- 2. slow auras, speed and movement
	local hidden = false
	for _, m in ipairs(field.monsters) do
		m.aura = 0
		m.hitNow = false
		if not m.revealed and m.kind and m.kind.Hidden then
			hidden = true
		end
	end
	for _, u in ipairs(field.units) do
		local st = u.Stats
		local reveal = hidden and u.active and st.Theme == "Sea"
		local slow = u.active and st.SlowAura
		if slow and field.synergies and field.synergies.Guardian and st.Theme == "Armored" then
			slow *= 1 + D.Synergies.Guardian
		end
		if reveal or slow then
			local r = st.Reach + D.MonsterRadius
			local limit, ux, uz = r * r, u.X, u.Z
			for _, m in ipairs(field.monsters) do
				local dx, dz = ux - m.x, uz - m.z
				if dx * dx + dz * dz <= limit then
					if reveal and not m.revealed and m.kind and m.kind.Hidden then
						m.revealed = true
					end
					if slow and slow > m.aura then
						m.aura = slow
					end
				end
			end
		end
	end
	for _, m in ipairs(field.monsters) do
		local v = m.speed
		if m.freezeUntil > now - dt then
			v = 0
		else
			if m.iceUntil > now - dt then
				v *= 1 - A.Ice.Slow * (m.isBoss and m.weakness ~= "Ice" and A.Ice.BossSlowMultiplier or 1)
			end
			v *= (1 - m.aura) * (1 - field.slow)
		end
		m.s += v * dt
		local wrapped = field.sureCombo and m.s >= field.path.length
		if wrapped then
			m.s -= field.path.length
		end
		m.x, m.z, m.seg = Formulas.lanePointNear(field.path, m.s, m.offset, m.seg)
		if wrapped or math.abs(v - m.vSent) > 1e-6 then
			m.vSent = v
			emit(field, { "M", m.id, m.s, v })
		end
	end

	-- 3. burning, then attacks
	for _, m in ipairs(field.monsters) do
		if m.burnUntil > now - dt then
			local burnt = m.burnDps * math.min(dt, m.burnUntil - (now - dt))
			credit(field, m.burnBy, m, burnt)
			m.hp -= burnt
		elseif m.burnDps > 0 then
			m.burnDps = 0
		end
	end
	for _, leader in ipairs(field.monsters) do
		local g = leader.group
		if leader.leader and leader.hp > 0 and g.kind.HealPerSecond then
			for _, m in ipairs(around(field, leader.x, leader.z, g.kind.HealRadius)) do
				if m.group == g and m ~= leader and m.hp < m.maxHp then
					m.hp = math.min(m.maxHp, m.hp + m.maxHp * g.kind.HealPerSecond * dt)
					m.healedAt = now
				end
			end
		end
	end
	-- poison pools: every fossil in one takes its damage (a poison fossil none; a boss Boss.EffectShare)
	for i = #field.pools, 1, -1 do
		local pool = field.pools[i]
		local seconds = math.max(0, math.min(dt, pool.untilTime - (now - dt)))
		if seconds > 0 then
			for _, m in ipairs(around(field, pool.x, pool.z, pool.r)) do
				if m.attribute ~= "Poison" then
					local amount = pool.dps * seconds * (m.isBoss and m.weakness ~= "Poison" and D.Boss.EffectShare or 1)
					credit(field, pool.unit, m, amount)
					m.hp -= amount
					m.pooledAt = now
				end
			end
		end
		if pool.untilTime <= now then
			table.remove(field.pools, i)
		end
	end
	for _, u in ipairs(field.units) do
		u.cooldown = math.max(0, u.cooldown - dt)
		if u.active and u.cooldown <= 0 and attack(field, u, rng) then
			u.cooldown = u.Stats.Interval
		end
		if u.active and u.Stats.Theme == "Sea" then
			u.waveAt = u.waveAt or field.time + D.Pond.WaveEvery
			if field.time >= u.waveAt then
				local hit = around(field, u.X, u.Z, u.Stats.Reach)
				if #hit > 0 then
					u.waveAt = field.time + D.Pond.WaveEvery
					for _, m in ipairs(hit) do
						m.s = math.max(math.min(m.s, 0), m.s - D.Pond.WavePush * (m.isBoss and D.Pond.WaveBossShare or 1))
						m.x, m.z = DefenseLogic.position(field, m.s, m.offset)
						emit(field, { "M", m.id, m.s, m.vSent })
					end
					emit(field, { "T", u.Id, u.Stats.Reach })
				end
			end
		end
	end

	-- 4. deaths and health
	-- (2026-10-03, "튜토리얼 여기서 안 넘어가는 버그": at LV 1 the water dino's hit killed every fossil, so none lived
	-- wet long enough for the ice dino) while the tutorial waits for a combo, a fossil can't die before it got one
	if field.sureCombo then
		for _, m in ipairs(field.monsters) do
			if m.hp <= 0 and not m.comboDone then
				m.hp = m.maxHp * 0.05
			end
		end
	end
	local kills, reward = 0, 0
	local alive = {}
	local health = { "H" }
	local splits = {}
	local length = field.path.length
	local function groupOut(m, leaked)
		local g = m.group
		if not g then
			return
		end
		g.alive -= 1
		g.leaked = g.leaked or leaked
		if m.leader then
			m.gone = true
		end
		if g.alive <= 0 and not g.leaked then
			field.groupsCleared += 1
			emit(field, { "G", g.id })
		end
	end
	for _, m in ipairs(field.monsters) do
		if m.hp > 0 and m.s >= length then
			local counts = promo and (not promo.idle or m == promo.boss or m.crowd == promo)
			local cost = 0
			if counts and m.isBoss then
				cost = math.max(0, promo.lives)
			elseif counts or ch then
				cost = math.max(1, math.ceil(m.leakCost * m.hp / m.maxHp - 1e-9))
			end
			if counts then
				if m.kind then
					promo.leakedKinds = promo.leakedKinds or {}
					promo.leakedKinds[m.kind.Id] = true
				end
				promo.lives -= cost
				promo.lost += cost
				promo.leakedBoss = promo.leakedBoss or m.isBoss
				if m.crowd == promo then
					promo.crowdAlive -= 1
				end
			elseif ch then
				ch.lives -= cost
			end
			field.leaks = (field.leaks or 0) + 1
			groupOut(m, true)
			emit(field, { "L", m.id, cost })
		elseif m.hp <= 0 then
			groupOut(m, false)
			if m.kind and m.kind.Split then
				table.insert(splits, m)
				field.popped = (field.popped or 0) + 1
				if m.kind.Id == "Airship" then
					field.airshipsDown = (field.airshipsDown or 0) + 1
				end
			end
			kills += 1
			if promo and m.crowd == promo then
				promo.crowdAlive -= 1
			end
			if not ch then -- (the challenge pays no kill money)
				reward += Formulas.killReward(m.level) * (m.isBoss and Formulas.bossHealthMultiplier(m.level) or 1)
					* m.rewardScale
			end
			emit(field, { "D", m.id })
		else
			table.insert(alive, m)
			local healed = (m.healedAt or -1) >= now
			local dotted = m.burnDps > 0 or (m.pooledAt or -1) >= now or healed
			m.hpDirty = m.hpDirty or m.hitNow
			local since = now - m.hpSentAt
			if (m.hp < m.maxHp or healed)
				and ((m.hpDirty and since >= HIT_HEALTH_EVERY) or (dotted and since >= HEALTH_EVENT_EVERY)) then
				m.hpSentAt = now
				m.hpDirty = false
				table.insert(health, m.id)
				table.insert(health, m.hp / m.maxHp)
			end
		end
	end
	if #health > 1 then
		emit(field, health)
	end
	field.monsters = alive
	for _, m in ipairs(splits) do
		local split = m.split or m.kind.Split
		local childKind = split.Kind and Formulas.fossilKind(split.Kind) or nil
		local from = #field.monsters + 1
		field.crowdSpawn = promo and m.crowd == promo or nil
		for i = 1, split.Count do
			local across = ((i - 0.5) / split.Count * 2 - 1) * D.LaneSpread
			spawn(field, level, rng, false, childKind, math.max(0, m.s - (i - 1) * SWARM_STAGGER), across)
		end
		field.crowdSpawn = nil
		if promo and m.crowd == promo then
			markCrowd(field, promo, from, level)
		end
	end
	field.kills += kills
	field.reward += reward

	-- 5. the end of a promotion fight: the boss died (success), too many monsters or out of time (fail)
	local result, reason = nil, nil
	if ch and ch.lives <= 0 then
		-- the challenge ends: the waves cleared (the one it fell in does not count)
		field.challenge = nil
		field.monsters = {}
		field.spawnDebt = 0
		emit(field, { "C" })
		return kills, reward, "challenge", ch.wave - 1
	end
	if promo then
		if promo.leakedBoss then
			result, reason = "fail", "leak"
		elseif promo.lives <= 0 then
			if field.reviveOffer == "can" then
				field.reviveOffer = "asking"
				result = "revive"
				pauseField(field)
			elseif field.reviveOffer ~= "asking" then
				result, reason = "fail", "leak"
			end
		elseif promo.idle and promo.boss and promo.boss.hp <= 0 and promo.crowdTotal
			and promo.crowdSpawned >= promo.crowdTotal and promo.crowdAlive <= 0 then
			result = "success"
		elseif not promo.idle and promo.boss and promo.boss.hp <= 0 then
			result = "success"
		elseif not promo.idle and promo.time >= D.Promotion.Duration then
			result, reason = "fail", "time"
		end
		if result and result ~= "revive" then
			-- the boss's health left (0-1; nil when it never came), for the advice after a lost fight
			field.lastBossLeft = promo.boss and math.max(0, promo.boss.hp) / promo.boss.maxHp or nil
			field.lastPromoTime = promo.time
			field.lastLeakBoss = promo.leakedBoss == true
			field.lastLeakKinds = promo.leakedKinds or {}
			field.lastCrowdLeft = promo.crowdTotal and (promo.crowdTotal - promo.crowdSpawned + math.max(0, promo.crowdAlive)) or nil
			field.lastPromoLost = promo.lost
			field.lastDealt, field.dealt = field.dealt or {}, nil
			field.promotion = nil
			if promo.idle then
				dropIdleBoss(field, promo)
			else
				field.monsters = {}
				field.spawnDebt = 0
				emit(field, { "C" })
			end
			emit(field, { "P", result, reason })
		end
	end
	return kills, reward, result, reason
end

-- during a promotion fight: seconds left, monsters on the track, the boss's health (0-1, nil before it comes), lives left
function DefenseLogic.promotionStatus(field)
	local promo = field.promotion
	if not promo then
		return nil
	end
	local boss = promo.boss
	if promo.idle then
		local crowdLeft = promo.crowdTotal and (promo.crowdTotal - promo.crowdSpawned + promo.crowdAlive) or 0
		return promo.time, crowdLeft, boss and math.max(0, boss.hp / boss.maxHp), math.max(0, promo.lives)
	end
	return D.Promotion.Duration - promo.time, #field.monsters, boss and math.max(0, boss.hp / boss.maxHp),
		math.max(0, promo.lives)
end

-- the events since the last call
function DefenseLogic.takeEvents(field)
	local events = field.events
	field.events = {}
	return events
end

function DefenseLogic.inReach(field, x, z, reach)
	for _, m in ipairs(field.monsters) do
		if m.hp > 0 and distance(x, z, m.x, m.z) - D.MonsterRadius <= reach then
			return true
		end
	end
	return false
end

-- the owner slaps the fossils: every one within reach of (x, z) (flat arena coordinates; 2026-10-01,
-- was only the nearest) loses damage health (its bar updates now; the next step counts the kill and its
-- reward); fossils out of reach but within splashRadius of one hit
-- take splashShare of it (once). Returns the ones hit, nearest first (empty when none is in reach).
-- maxTargets (optional): only the nearest this many are hit; bossShare (optional): the boss takes this share
function DefenseLogic.slapMonster(field, x, z, reach, damage, splashRadius, splashShare, maxTargets, bossShare, push, bossPush)
	local hit, gaps = {}, {}
	for _, m in ipairs(field.monsters) do
		if m.hp > 0 then
			local gap = distance(x, z, m.x, m.z) - D.MonsterRadius
			if gap <= reach then
				table.insert(hit, m)
				gaps[m] = gap
			end
		end
	end
	table.sort(hit, function(a, b)
		return gaps[a] < gaps[b]
	end)
	if maxTargets then
		for i = #hit, maxTargets + 1, -1 do
			gaps[hit[i]] = nil
			table.remove(hit, i)
		end
	end
	local function share(m)
		return m.isBoss and bossShare or 1
	end
	-- the fossils right next to the ones hit take a share too
	if #hit > 0 and splashRadius and splashShare and splashShare > 0 then
		for _, m in ipairs(field.monsters) do
			if m.hp > 0 and not gaps[m] then
				for _, h in ipairs(hit) do
					if distance(h.x, h.z, m.x, m.z) <= splashRadius then
						m.hp -= damage * splashShare * share(m)
						emit(field, { "H", m.id, math.max(0, m.hp) / m.maxHp })
						break
					end
				end
			end
		end
	end
	for _, m in ipairs(hit) do
		m.hp -= damage * share(m)
		emit(field, { "H", m.id, math.max(0, m.hp) / m.maxHp })
		if push and push > 0 and m.hp > 0 then
			m.s = math.max(math.min(m.s, 0), m.s - push * (m.isBoss and (bossPush or 0) or 1))
			m.x, m.z = DefenseLogic.position(field, m.s, m.offset)
			emit(field, { "M", m.id, m.s, m.vSent })
		end
	end
	return hit
end

function DefenseLogic.holdMonsters(field, x, z, reach, seconds, bossSeconds)
	local held = {}
	for _, m in ipairs(field.monsters) do
		local hold = m.isBoss and bossSeconds or seconds
		if m.hp > 0 and hold > 0 and distance(x, z, m.x, m.z) - D.MonsterRadius <= reach then
			m.freezeUntil = math.max(m.freezeUntil, field.time + hold)
			table.insert(held, m)
		end
	end
	return held
end

return DefenseLogic
