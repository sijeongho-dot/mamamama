--[[
Community: the community reward (2026-10-01, Config.Community).

Every base has a sign at its front, between the deposit bin and the spawn pad, facing the way in:
"👍 커뮤니티 보상", what it gives and how. Its prompt ("받기", the owner's own base only): a player who is in
the game's Roblox group (GroupService.GetGroupsAsync, asked fresh) takes Config.Community.Reward once per
account (profile CommunityClaimed; keys and money through Rewards.grant, LuckMinutes of luck ×2 as the
starter missions' luck). Not in the group: Net push CommunityJoin(groupId) asks the client to show Roblox's
join prompt, and it asks again (Net request ClaimCommunity) once joined. GroupId 0 (2026-10-01, no group made
yet): no sign at all, so nothing looks unfinished; it appears once Config.Community.GroupId is set.
]]

local GroupService = game:GetService("GroupService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))

local Community = {}

-- display only
local SIGN_U, SIGN_V = 22, 27 -- plot coordinates (StreetLamps): across from the middle, in from the front
local BOARD_SIZE = Vector3.new(7, 4.5, 0.4)
local BOARD_HEIGHT = 4.2 -- the board's middle over the ground
local POST_SIZE = Vector3.new(0.5, 6.4, 0.5)
local COLOR_BOARD = Color3.fromRGB(70, 130, 230)
local COLOR_POST = Color3.fromRGB(110, 80, 55)
local TITLE_COLOR = Color3.fromRGB(150, 200, 255)
local PIXELS_PER_STUD = 50

local signs = {} -- [base number] = the board part
local busy = {} -- [player] = true while asking Roblox

local function say(player, text)
	Net.push(player, "Notice", "👍 커뮤니티 보상", text)
end

local function inGroup(player, groupId)
	local ok, groups = pcall(GroupService.GetGroupsAsync, GroupService, player.UserId)
	if not ok then
		return nil -- (Roblox didn't answer: try again later)
	end
	for _, g in ipairs(groups) do
		if g.Id == groupId then
			return true
		end
	end
	return false
end

local function claim(player)
	local c = Config.Community
	local profile = PlayerData.get(player)
	if not profile or busy[player] then
		return
	end
	if profile.CommunityClaimed then
		return say(player, "이미 받았어요. 고마워요! 👍")
	end
	if c.GroupId == 0 then
		return say(player, "👍 커뮤니티를 준비 중이에요. 곧 열려요!")
	end
	busy[player] = true
	local member = inGroup(player, c.GroupId)
	busy[player] = nil
	if member == nil then
		return say(player, "⏳ 잠시 뒤에 다시 눌러 주세요")
	elseif not member then
		Net.push(player, "CommunityJoin", c.GroupId) -- the client shows Roblox's join prompt
		return say(player, "👍 그룹에 가입하면 바로 선물을 받아요!")
	end
	PlayerData.update(player, function(p)
		p.CommunityClaimed = true
		p.LuckUntil = math.max(p.LuckUntil or 0, os.time()) + c.LuckMinutes * 60
	end)
	local after = PlayerData.get(player)
	player:SetAttribute("Luck", Config.StarterMissions.LuckMultiplier)
	player:SetAttribute("LuckEndsAt", after.LuckUntil)
	Rewards.grant(player, c.Reward, "👍 커뮤니티 보상")
	say(player, string.format("가입 고마워요! 🍀 행운 ×%d %d분도 같이 받았어요", Config.StarterMissions.LuckMultiplier, c.LuckMinutes))
end

local function makeSign(index, folder)
	local zone = folder:FindFirstChild("SafeZone")
	if not zone then
		return nil
	end
	local flat = Vector3.new(zone.Position.X, 0, zone.Position.Z)
	if flat.Magnitude < 1e-3 then
		return nil
	end
	local out = flat.Unit
	local right = out:Cross(Vector3.yAxis).Unit
	local front = flat - out * Config.Map.PlotDepth / 2
	local spot = front + right * SIGN_U + out * SIGN_V
	local ground = Bases.groundBelow(Vector3.new(spot.X, zone.Position.Y, spot.Z), { zone })
	local at = Vector3.new(spot.X, ground, spot.Z)
	local facing = CFrame.lookAt(at, at - out) -- toward the way in
	local model = Instance.new("Model")
	model.Name = "CommunitySign"
	local function part(name, size, cf, color)
		local p = Instance.new("Part")
		p.Name = name
		p.Anchored = true
		p.Size = size
		p.CFrame = cf
		p.Color = color
		p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
		p.Parent = model
		return p
	end
	local board = part("Board", BOARD_SIZE, facing * CFrame.new(0, BOARD_HEIGHT, 0), COLOR_BOARD)
	for _, x in ipairs({ -BOARD_SIZE.X / 2 + 0.6, BOARD_SIZE.X / 2 - 0.6 }) do
		part("Post", POST_SIZE, facing * CFrame.new(x, POST_SIZE.Y / 2, 0.3), COLOR_POST)
	end
	local gui = Instance.new("SurfaceGui")
	gui.Face = Enum.NormalId.Front
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud = PIXELS_PER_STUD
	gui.Parent = board
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBold
	text.TextScaled = true
	text.TextColor3 = Color3.new(1, 1, 1)
	text.TextStrokeTransparency = 0.3
	text.Text = string.format("👍 커뮤니티 보상\n그룹에 가입하면 한 번!\n%s\n🍀 행운 ×%d %d분",
		RewardLogic.text(Config.Community.Reward, 1), Config.StarterMissions.LuckMultiplier, Config.Community.LuckMinutes)
	text.Parent = gui
	model.PrimaryPart = board
	model.Parent = folder
	Bases.title(model, "👍 커뮤니티 보상", TITLE_COLOR)
	local prompt = Bases.prompt(board, "Community", index, "커뮤니티 보상 받기", Config.Community.SignRange)
	if prompt then
		prompt.Triggered:Connect(function(player)
			if Bases.of(player) == index then
				claim(player)
			end
		end)
	end
	return board
end

function Community.init()
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			local old = folder:FindFirstChild("CommunitySign")
			if old then
				old:Destroy()
			end
			if Config.Community.GroupId ~= 0 then
				signs[index] = makeSign(index, folder)
			end
		end
	end
	Net.onRequest("ClaimCommunity", {}, function(player)
		local board = signs[Bases.of(player)]
		if board and Bases.near(player, board, Config.Community.SignRange + 4) then
			claim(player)
		end
	end)
end

return Community
