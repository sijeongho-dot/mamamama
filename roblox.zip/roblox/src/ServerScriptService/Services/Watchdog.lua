--[[
Watchdog: finding stalls (2026-10-01: on a phone, everything but walking stopped for a long while, and
respawning too; walking is the phone's own, everything else waits on the server, so the server was
probably stuck). A server frame longer than Config.Watchdog.LagWarnSeconds is written to the log with
what was going on (players, night, the time); the clients ask Ping now and then and show "server is
slow" while no answer comes (StarterPlayerScripts/LagCheck); script errors on players' screens are
sent here and written to the server's log (ClientError), at most ErrorsPerMinute a player, and kept by the
day in a DataStore (BetaLog, 2026-10-02). The server
log shows in the developer console (F9, or "/console" in the chat on a phone) under Server.

Measuring (2026-10-01): every second the server tells everyone (ReplicatedStorage attributes
ServerStats, ServerClock) its frame rate, its longest frame, how much it sends, which parts took the
most time (the Defense and Zombies loops, each request handler, each PlayerData.onChanged listener)
and which messages it sent most. The "server is slow" banner shows it, so a stall names its cause.
]]

local AnalyticsService = game:GetService("AnalyticsService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))

local Watchdog = {}

local MAX_TEXT = 400 -- characters of a client error kept
local LOAD_MOST = 600
-- (2026-10-04, "3- 4명 있으니까 서버 지연 한 번 걸리는데") a server frame longer than SPIKE_SECONDS is written down with what
-- took its time (the timed parts of that frame) and whether someone came or went just before: the log, and a third line
-- of ServerStats ("최근 멈춤 …", the "server is slow" banner and ;perf show it) for SPIKE_SHOWN seconds
local SPIKE_SECONDS = 0.15
local SPIKE_SHOWN = 120
local JOIN_NEAR = 5 -- seconds: a join or leave this recent is named with a stall
-- (2026-10-04, error 279 on joining from a phone on Wi-Fi and on data alike, fine again later: the server likely stalled)
-- a stall this long is also kept in the saved error log (BetaLog, Studio ;errors: side "stall"), with the server's memory
local STALL_KEEP_SECONDS = 0.5

local errorCounts = {} -- [player] = { count, since }
local times = {} -- [label] = { seconds, count } this second
local frameTimes = {} -- [label] = seconds this frame
local lastSpike, lastSpikeAt = nil, -math.huge
local lastJoin, lastJoinAt = nil, -math.huge
local lastLeftAlone = -math.huge
local closing = false
local sends = {} -- [message] = receivers this second

local function meter(kind, name, seconds, receivers)
	if kind == "send" then
		sends[name] = (sends[name] or 0) + (receivers or 1)
		return
	end
	local label = (kind == "changed" and "변경:" or kind == "handle" and "요청:" or kind == "loaded" and "입장:" or "")
		.. tostring(name):match("[^%.]*$")
	frameTimes[label] = (frameTimes[label] or 0) + seconds
	local t = times[label]
	if not t then
		t = { 0, 0 }
		times[label] = t
	end
	t[1] += seconds
	t[2] += 1
end

local function top(map, n, value)
	local list = {}
	for k, v in pairs(map) do
		table.insert(list, { k, value(v) })
	end
	table.sort(list, function(a, b)
		return a[2] > b[2]
	end)
	local out = {}
	for i = 1, math.min(n, #list) do
		table.insert(out, list[i])
	end
	return out
end

function Watchdog.init()
	Net.setMeter(meter)
	local Services = script.Parent
	require(Services:WaitForChild("ServerMeter")).sink = meter -- (2026-10-04: DayNight, MoneyPile, Race, Ride)
	Players.PlayerAdded:Connect(function(player)
		lastJoin, lastJoinAt = player.Name .. " 입장", os.clock()
	end)
	Players.PlayerRemoving:Connect(function(player)
		lastJoin, lastJoinAt = player.Name .. " 퇴장", os.clock()
		if #Players:GetPlayers() <= 1 then
			lastLeftAlone = os.clock()
		end
	end)
	game:BindToClose(function()
		closing = true
	end)
	for _, name in ipairs({ "PlayerData", "Defense", "Zombies", "Training" }) do -- (2026-10-04: Training too)
		local ok, module = pcall(require, Services:WaitForChild(name))
		if ok then
			module.meter = meter
		end
	end
	local Stats = game:GetService("Stats")
	local last = os.clock()
	local frames, longest, since = 0, 0, os.clock()
	RunService.Heartbeat:Connect(function()
		local now = os.clock()
		local frame = now - last
		last = now
		frames += 1
		longest = math.max(longest, frame)
		if now - since >= 1 then
			local parts = {}
			for _, t in ipairs(top(times, 3, function(v)
				return v[1]
			end)) do
				table.insert(parts, string.format("%s %dms(%d회)", t[1], math.floor(t[2] * 1000 + 0.5), times[t[1]][2]))
			end
			local msgs = {}
			for _, m in ipairs(top(sends, 3, function(v)
				return v
			end)) do
				table.insert(msgs, string.format("%s %d", m[1], m[2]))
			end
			local okSend, sendKbps = pcall(function()
				return Stats.DataSendKbps
			end)
			local okMem, mem = pcall(function()
				return Stats:GetTotalMemoryUsageMb()
			end)
			ReplicatedStorage:SetAttribute("ServerStats", string.format("서버 FPS %d · 최대 프레임 %dms · 보내기 %s KB/s · 메모리 %s MB\n시간: %s\n보낸 메시지: %s",
				frames, math.floor(longest * 1000 + 0.5), okSend and tostring(math.floor(sendKbps / 8 + 0.5)) or "?",
				okMem and tostring(math.floor(mem)) or "?",
				#parts > 0 and table.concat(parts, ", ") or "-", #msgs > 0 and table.concat(msgs, ", ") or "-")
				.. (lastSpike and now - lastSpikeAt <= SPIKE_SHOWN and "\n" .. lastSpike or ""))
			ReplicatedStorage:SetAttribute("ServerClock", workspace:GetServerTimeNow())
			frames, longest, since = 0, 0, now
			times, sends = {}, {}
		end
		-- (2026-10-04) a stalled frame: what took its time (the frame before this Heartbeat ran the timed parts)
		local shuttingDown = closing or (RunService:IsStudio() and now - lastLeftAlone <= JOIN_NEAR)
		if frame > SPIKE_SECONDS and shuttingDown then
			frameTimes = {}
			return
		end
		if frame > SPIKE_SECONDS then
			local parts = {}
			for _, t in ipairs(top(frameTimes, 3, function(v)
				return v
			end)) do
				table.insert(parts, string.format("%s %dms", t[1], math.floor(t[2] * 1000 + 0.5)))
			end
			local join = now - lastJoinAt <= JOIN_NEAR and string.format(" · %d초 전 %s", math.floor(now - lastJoinAt), lastJoin) or ""
			lastSpike = string.format("최근 멈춤 %dms: %s%s", math.floor(frame * 1000 + 0.5),
				#parts > 0 and table.concat(parts, ", ") or "잰 부분 아님(물리·복제·로블록스)", join)
			lastSpikeAt = now
			warn("[Lag] " .. lastSpike)
			if frame >= STALL_KEEP_SECONDS then
				local okMem, mem = pcall(function()
					return Stats:GetTotalMemoryUsageMb()
				end)
				local cause = #parts > 0 and string.match(parts[1], "^(.-) %d+ms$") or "잰 부분 아님"
				require(script.Parent:WaitForChild("BetaLog")).serverStall("서버 멈춤: " .. tostring(cause),
					string.format("%s · %d명 · 메모리 %s MB", lastSpike, #Players:GetPlayers(),
						okMem and tostring(math.floor(mem)) or "?"))
			end
		end
		frameTimes = {}
		if frame > Config.Watchdog.LagWarnSeconds then
			warn(string.format("[Lag] 서버 프레임 %.1f초 (플레이어 %d명, 밤 %s, 날씨 %s)", frame, #Players:GetPlayers(),
				tostring(ReplicatedStorage:GetAttribute("Night")), tostring(ReplicatedStorage:GetAttribute("Weather"))))
		end
	end)
	Net.onAsk("Ping", {}, function()
		return true
	end)
	Net.onRequest("ClientError", { "string", "string" }, function(player, message, trace)
		local c = errorCounts[player]
		local now = os.clock()
		if not c or now - c.since > 60 then
			c = { count = 0, since = now }
			errorCounts[player] = c
		end
		c.count += 1
		if c.count > Config.Watchdog.ErrorsPerMinute then
			return
		end
		warn(string.format("[ClientError] %s: %s | %s", player.Name, message:sub(1, MAX_TEXT), trace:sub(1, MAX_TEXT)))
		require(script.Parent:WaitForChild("BetaLog")).clientError(player, message, trace) -- (kept by the day, 2026-10-02)
	end)
	local perfAt = {}
	Net.onRequest("PerfReport", { "string" }, function(player, line)
		local now = os.clock()
		if perfAt[player] and now - perfAt[player] < Config.Watchdog.PerfReportGap then
			return
		end
		perfAt[player] = now
		warn(string.format("[Perf] %s: %s", player.Name, line:sub(1, MAX_TEXT)))
	end)
	local loadSent = {}
	Net.onRequest("LoadReport", { "number", "number", "number", "number", "number" }, function(player, total, gameAt, map, ready, settle)
		if loadSent[player] then
			return
		end
		loadSent[player] = true
		local function clamp(x)
			return math.clamp(x, 0, LOAD_MOST)
		end
		total, gameAt, map, ready, settle = clamp(total), clamp(gameAt), clamp(map), clamp(ready), clamp(settle)
		print(string.format("[Load] %s: %.1f초 (게임 %.1f · 맵 %.1f · 캐릭터·저장 %.1f · 화면 %.1f)", player.Name, total, gameAt, map,
			ready, settle))
		for name, value in pairs({ LoadSeconds = total, LoadMapSeconds = map, LoadSettleSeconds = settle }) do
			pcall(AnalyticsService.LogCustomEvent, AnalyticsService, player, name, math.floor(value + 0.5))
		end
	end)
	Players.PlayerRemoving:Connect(function(player)
		errorCounts[player] = nil
		perfAt[player] = nil
		loadSent[player] = nil
	end)
end

return Watchdog
