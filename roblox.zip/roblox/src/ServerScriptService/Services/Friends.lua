--[[
Friends: playing on the same server as Roblox friends gives a money buff (design 2.14 친구 버프).

- For every player, the number of their Roblox friends on this server (Player:IsFriendsWith, asked
  once per pair and remembered) is the player attribute Friends; the buff is
  Formulas.friendBoost(Friends): +Config.Friends.BoostPerFriend a friend, at most MaxFriends friends.
  PlayerData.addMoney applies it to the money earned by playing (mining deposits, arena kills,
  treasure chests).
- When a friend joins, both get a notice ("👥 친구 ○○님이 들어왔어요! 돈 +10%").
- Friend bonus (2026-10-02, design 13 "친구와 같이 들어오면 둘 다 열쇠"): two friends still on the server
  together Config.FriendInvite.MinutesTogether after one joined both get Keys normal keys, once a day for
  each pair, with at most PerDay friends a day each (RewardLogic.friendBonus; both must have room, so
  it is always both or neither).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))

local Friends = {}

local known = {} -- ["small id:big id"] = true / false: are these two friends (asked once)

local function pairKey(a, b)
	local x, y = math.min(a.UserId, b.UserId), math.max(a.UserId, b.UserId)
	return x .. ":" .. y
end

local function areFriends(a, b)
	local key = pairKey(a, b)
	if known[key] == nil then
		local ok, result = pcall(a.IsFriendsWith, a, b.UserId)
		if not ok then
			return false -- not remembered: asked again next time
		end
		known[key] = result == true
	end
	return known[key]
end

-- (2026-10-04) whether two players are known friends, without asking Roblox (never waits; Training's friend bonus)
function Friends.known(a, b)
	return known[pairKey(a, b)] == true
end

local function recount()
	local list = Players:GetPlayers()
	for _, player in ipairs(list) do
		local n = 0
		for _, other in ipairs(list) do
			if other ~= player and areFriends(player, other) then
				n += 1
			end
		end
		player:SetAttribute("Friends", n)
	end
end

-- the friend bonus for a and b, if both are still here and both may get it today
local function together(a, b)
	if a.Parent ~= Players or b.Parent ~= Players or not PlayerData.isLoaded(a) or not PlayerData.isLoaded(b)
		or not areFriends(a, b) then
		return
	end
	local day = RewardLogic.dayNumber(os.time())
	if not RewardLogic.friendBonusOpen(PlayerData.get(a), day, b.UserId)
		or not RewardLogic.friendBonusOpen(PlayerData.get(b), day, a.UserId) then
		return
	end
	local keys = Config.FriendInvite.Keys
	for _, pair in ipairs({ { a, b }, { b, a } }) do
		local me, friend = pair[1], pair[2]
		PlayerData.update(me, function(p)
			RewardLogic.friendBonus(p, day, friend.UserId)
			RewardLogic.apply(p, { Keys = keys })
		end)
		Net.push(me, "Notice", "👥 친구와 함께",
			string.format("%s님과 같이 놀아서 둘 다 🔑 열쇠 %d개 받았어요!", friend.DisplayName, keys))
	end
end

local function joined(player)
	for _, other in ipairs(Players:GetPlayers()) do
		if other ~= player and areFriends(player, other) then
			local boost = math.floor((Formulas.friendBoost(math.min(Config.Friends.MaxFriends, 1)) - 1) * 100 + 0.5)
			Net.push(other, "Notice", "👥 친구", string.format("친구 %s님이 들어왔어요! 친구마다 돈 +%d%%", player.DisplayName, boost))
			Net.push(player, "Notice", "👥 친구", string.format("친구 %s님이 같은 서버에 있어요! 친구마다 돈 +%d%%", other.DisplayName, boost))
			task.delay(Config.FriendInvite.MinutesTogether * 60, together, player, other)
		end
	end
	recount()
end

function Friends.init()
	Players.PlayerAdded:Connect(function(player)
		task.spawn(joined, player)
	end)
	Players.PlayerRemoving:Connect(function(player)
		task.defer(recount)
		for key in pairs(known) do -- forget pairs with the leaver (a friendship may change)
			if string.find(":" .. key .. ":", ":" .. player.UserId .. ":", 1, true) then
				known[key] = nil
			end
		end
	end)
	for _, player in ipairs(Players:GetPlayers()) do
		task.spawn(joined, player)
	end
end

return Friends
