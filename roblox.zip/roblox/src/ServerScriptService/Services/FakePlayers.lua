--[[
FakePlayers: 촬영 도우미 (2026-10-05, "3~4명이 없는걸..." → "어디에 3~4명이 들어가야 되고 어떻게 사용해야할지 가짜 플레이어,
구상해봐" → "아바타를 랜덤 기본으로"): stand-in players for filming the store video alone. Roblox Studio only: TestCommands
(;fake) is the only way in, and every entry here checks RunService:IsStudio() again; Main never starts it.

They are not players: server-run avatar models (random default avatars: Roblox's blocky body in random colors,
a made-up name over the head) in Workspace.FakePlayers, moved by their Humanoid (so every screen draws them
smoothly). The one who gave the command is their owner (what they follow, flee, race beside).

;fake N         N of them round me (1-6; again: new ones)        ;fake clear   all gone
;fake keys      each carries 3-5 keys over its head and runs from a player who comes near; a slap throws it and the
                keys fall out (real keys on the ground, Keys.scatter)
;fake altar     they wait round the key altar; keys on the ground: they run for them and grab them (Keys.grab),
                then carry them off as in "keys"
;fake race      riding dinos, lined up beside me (in a road race practice's start box: beside me; else at the start
                line); they set off with my "Go" (or after a 3-second count of their own), at about the race speed,
                now and then a pad's boost or a bump back. Only on screen: never in the race's result or records
;fake hide      each up in a tree near me (in its leaves, as a climber hides); my slap reaching one: it tumbles out
;fake follow    behind me (riding dinos while I ride)       ;fake wander   strolling round where they are
;fake ride      on / off dinos                               ;fake stop     standing still
;fake fly       on flying dinos, in a flock round the sky over the battlefield
A slap (anywhere: Combat.onSlap on the battlefield, onSafeSlap elsewhere) in reach throws one as a player is thrown,
drops what it carries, and puts it down for a moment. Display only; nothing here is saved.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))

local FakePlayers = {}

-- display only (a filming aid, no game rule)
local MAX = 6
local TICK = 0.15 -- seconds between their looks round
local SPAWN_RING = { 8, 14 } -- studs from me they appear
local NAMES = { "DinoKid_77", "RexRunner", "SlapMaster9", "KeyHunter_X", "TrikeFan22", "PteroPal", "MossyRaptor",
	"LuckyEgg_5", "StegoSteve", "BoneBuster3", "FossilFinn", "ZapZoey" }
local SKINS = { Color3.fromRGB(255, 204, 153), Color3.fromRGB(234, 184, 146), Color3.fromRGB(204, 142, 105),
	Color3.fromRGB(160, 95, 53), Color3.fromRGB(124, 92, 70), Color3.fromRGB(245, 205, 48) }
local SHIRTS = { Color3.fromRGB(13, 105, 172), Color3.fromRGB(196, 40, 28), Color3.fromRGB(75, 151, 75),
	Color3.fromRGB(245, 205, 48), Color3.fromRGB(107, 50, 124), Color3.fromRGB(218, 133, 65), Color3.fromRGB(4, 175, 236) }
local PANTS = { Color3.fromRGB(27, 42, 53), Color3.fromRGB(39, 70, 45), Color3.fromRGB(99, 95, 98),
	Color3.fromRGB(33, 84, 185), Color3.fromRGB(91, 93, 105) }
local ANIMS = { -- Roblox's default R15 animations
	Idle = "rbxassetid://507766388", Run = "rbxassetid://507767714", Fall = "rbxassetid://507767968",
	Sit = "rbxassetid://2506281703",
}
local WALK = 16 -- studs a second on foot (Roblox's usual walk)
local RUN_ANIM_SPEED = 16 -- walk speed the run animation plays at 1×
local MOVING = 1 -- studs a second: faster than this it runs
local BODY = 2 -- studs: how wide one counts for a slap
local DIZZY_MARK = "💫"
local MARK_SIZE = UDim2.fromScale(4.3, 4.3)
local KEYS_HELD = { 3, 5 }
local CARRY_COLOR = Color3.fromRGB(255, 205, 60)
local CARRY_LABEL = UDim2.fromScale(7.9, 2)
local CARRY_LABEL_UP = 3.9
local FLEE_RANGE = 30 -- studs: a player this near makes a key carrier run
local FLEE_STEP = 24
local WANDER_RADIUS = 25
local WANDER_EVERY = { 2, 5 } -- seconds
local ALTAR_RING = { 18, 28 } -- studs from the altar's middle where they wait
local ALTAR_SEEK = 140 -- studs from the altar: keys on the ground this near are run for
local GRAB_REACH = 3.5
local ALTAR_FULL = 4 -- keys: then they carry them off
local FOLLOW_GAP = 6 -- studs behind me, and between them
local RACE_SPOTS = { { -5, 0 }, { 5, 0 }, { 0, -9 }, { -6, -9 }, { 6, -9 }, { 0, -18 } } -- (beside, behind) studs from me
local RACE_STEP = math.rad(6) -- each aims this far ahead round the track
local RACE_SPEEDS = { 0.9, 1.05 } -- × the race speed, each its own
local RACE_COUNT = 3 -- seconds of their own count when I'm not in a race
local BOOST_EVERY = { 4, 9 } -- seconds between their "pads"
local BOOST = { Multiplier = 1.6, Seconds = 1.2 }
local BUMP_CHANCE = 0.3 -- of a "pad" moment that is a bump back instead
local BUMP = { Back = 22, Up = 28 } -- studs a second
local HIDE_RANGE = 120 -- studs from me: trees they hide in
local HIDE_APART = 10 -- studs between two of their trees
local MOUNT_SPECIES = { "Parasaur", "Raptor", "TRex", "Trike", "Stego", "Ankylo" }
local FLY_SPECIES = { "Pteranodon", "Quetzal", "Rhampho", "Pterodac", "Ornitho", "Tupux" }
local FLY_OUT = 110
local FLY_HEIGHT = 45
local FLY_RADIUS = 70
local FLY_SPEED = 0.35
local FLY_LAG = 0.11
local FLY_SPREAD = 5
local FLY_BOB = 1.5
local FLY_BANK = math.rad(18)
local SEAT = 1.2 -- studs from the dino's back to the rider's root (as Ride)
local TREE_KINDS = { Tree = true, Prop_Tree_Round = true, Prop_Tree_Pine = true }
local TRUNKS = { TrunkCollider = true, Trunk = true }

local rng = Random.new()
local folder = nil
local puppets = {} -- { model, humanoid, root, tracks, mode, keys, keyModels, dino, ... }
local owner = nil
local hooked = false
local running = false
local Keys -- (required on first use: Studio only)

local function flat(v)
	return Vector3.new(v.X, 0, v.Z)
end

local function ownerRoot()
	local c = owner and owner.Character
	return c and c:FindFirstChild("HumanoidRootPart")
end

local groundRay = RaycastParams.new()
groundRay.FilterType = Enum.RaycastFilterType.Exclude
groundRay.RespectCanCollide = true
local function groundAt(x, z, fromY)
	local skip = { folder }
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(skip, p.Character)
		end
	end
	groundRay.FilterDescendantsInstances = skip
	local hit = Workspace:Raycast(Vector3.new(x, (fromY or 0) + 60, z), Vector3.new(0, -400, 0), groundRay)
	return hit and hit.Position.Y or (fromY or 0)
end

-- ---------------------------------------------------------------------------
-- The avatars
-- ---------------------------------------------------------------------------

local function pick(list)
	return list[rng:NextInteger(1, #list)]
end

local function avatar(name)
	local d = Instance.new("HumanoidDescription")
	local skin, shirt, pants = pick(SKINS), pick(SHIRTS), pick(PANTS)
	d.HeadColor, d.LeftArmColor, d.RightArmColor = skin, skin, skin
	d.TorsoColor, d.LeftLegColor, d.RightLegColor = shirt, pants, pants
	local ok, model = pcall(function()
		return Players:CreateHumanoidModelFromDescription(d, Enum.HumanoidRigType.R15)
	end)
	if not ok or not model then -- (no avatar service: a copy of the owner in new colors)
		local c = owner and owner.Character
		if not c then
			return nil
		end
		c.Archivable = true
		model = c:Clone()
		for _, part in ipairs(model:GetDescendants()) do
			if part:IsA("Accessory") or part:IsA("Shirt") or part:IsA("Pants") or part:IsA("ShirtGraphic") then
				part:Destroy()
			elseif part:IsA("BasePart") and part.Name ~= "HumanoidRootPart" then
				part.Color = (string.find(part.Name, "Leg") or string.find(part.Name, "Foot")) and pants
					or (string.find(part.Name, "Torso") and shirt) or skin
			end
		end
	end
	for _, s in ipairs(model:GetDescendants()) do
		if s:IsA("LocalScript") or s:IsA("Script") then
			s:Destroy()
		end
	end
	model.Name = name
	local humanoid = model:FindFirstChildOfClass("Humanoid")
	humanoid.DisplayName = name
	humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.Viewer
	return model
end

local function play(p, name, speed)
	if p.playing ~= name then
		for key, track in pairs(p.tracks) do
			if key ~= name and track.IsPlaying then
				track:Stop(0.15)
			end
		end
		local track = p.tracks[name]
		if track then
			track:Play(0.15)
		end
		p.playing = name
	end
	local track = name and p.tracks[name]
	if track and speed then
		track:AdjustSpeed(speed)
	end
end

local function spawnOne(at)
	local name = NAMES[(#puppets % #NAMES) + 1]
	local model = avatar(name)
	if not model then
		return
	end
	local humanoid = model:FindFirstChildOfClass("Humanoid")
	local root = model:FindFirstChild("HumanoidRootPart")
	model.Parent = folder
	model:PivotTo(CFrame.new(at + Vector3.new(0, humanoid.HipHeight + root.Size.Y / 2 + 0.2, 0)))
	pcall(function()
		root:SetNetworkOwner(nil) -- (the server moves them: every screen sees the same)
	end)
	local animator = humanoid:FindFirstChildOfClass("Animator")
	if not animator then
		animator = Instance.new("Animator")
		animator.Parent = humanoid
	end
	local tracks = {}
	for key, id in pairs(ANIMS) do
		local a = Instance.new("Animation")
		a.AnimationId = id
		local ok, track = pcall(function()
			return animator:LoadAnimation(a)
		end)
		if ok then
			track.Looped = key ~= "Fall"
			tracks[key] = track
		end
	end
	table.insert(puppets, { model = model, humanoid = humanoid, root = root, tracks = tracks, mode = "Stop", keys = 0,
		keyModels = {}, home = at, hip = humanoid.HipHeight, nextWander = 0 })
end

-- a small copy of an asset model, every part loose (welded by the caller), not colliding
local function assetCopy(name, size)
	local assets = ServerStorage:FindFirstChild("Assets")
	local source = assets and assets:FindFirstChild(name, true)
	if not source then
		return nil
	end
	local model = Instance.new("Model")
	source:Clone().Parent = model
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.Massless = false, false, false, false, true
		elseif d:IsA("Script") or d:IsA("LocalScript") or d:IsA("ProximityPrompt") then
			d:Destroy()
		end
	end
	local cf, box = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, box.Y / 2, 0))
	model:ScaleTo(size / math.max(box.X, box.Y, box.Z, 0.1))
	return model
end

local function weldTo(model, part)
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			local w = Instance.new("WeldConstraint")
			w.Part0, w.Part1 = part, d
			w.Parent = d
		end
	end
end

local function showKeys(p)
	for _, m in ipairs(p.keyModels) do
		m:Destroy()
	end
	p.keyModels = {}
	local head = p.model:FindFirstChild("Head")
	if not head or p.keys <= 0 then
		return
	end
	local outline = Instance.new("Highlight")
	outline.FillColor, outline.OutlineColor = CARRY_COLOR, CARRY_COLOR
	outline.FillTransparency, outline.OutlineTransparency = 0.8, 0
	outline.DepthMode = Enum.HighlightDepthMode.Occluded
	outline.Parent = p.model
	local glow = Instance.new("Attachment")
	local light = Instance.new("PointLight")
	light.Color, light.Range, light.Brightness = CARRY_COLOR, 14, 2
	light.Parent = glow
	local sparkles = Instance.new("ParticleEmitter")
	sparkles.Color = ColorSequence.new(CARRY_COLOR, Color3.fromRGB(255, 250, 210))
	sparkles.Rate = 25
	sparkles.Lifetime = NumberRange.new(0.8, 1.3)
	sparkles.Speed = NumberRange.new(3, 6)
	sparkles.SpreadAngle = Vector2.new(35, 35)
	sparkles.EmissionDirection = Enum.NormalId.Top
	sparkles.Size = NumberSequence.new(0.5, 0)
	sparkles.LightEmission = 1
	sparkles.Parent = glow
	glow.Parent = p.root
	local label = Instance.new("BillboardGui")
	label.Size = CARRY_LABEL
	label.StudsOffsetWorldSpace = Vector3.new(0, CARRY_LABEL_UP, 0)
	label.AlwaysOnTop = true
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBold
	text.TextScaled = true
	text.TextColor3 = CARRY_COLOR
	text.TextStrokeTransparency = 0
	text.Text = "🎁 ×" .. p.keys
	text.Parent = label
	label.Parent = head
	p.keyModels = { outline, glow, label }
end

local function dismount(p)
	if p.dino then
		p.dino:Destroy()
		p.dino = nil
		p.humanoid.HipHeight = p.hip
	end
end

local function mount(p, species)
	if p.dino then
		return
	end
	local c = Config.Ride
	species = species or pick(MOUNT_SPECIES)
	local dino = assetCopy("Dino_" .. species, c.MountHeight)
	if not dino then
		return
	end
	local _, box = dino:GetBoundingBox()
	local hip = box.Y * c.BackHeight + SEAT - p.root.Size.Y / 2
	p.humanoid.HipHeight = hip
	p.root.CFrame = p.root.CFrame + Vector3.new(0, hip - p.hip, 0) -- (lifted onto its back)
	-- the dino's feet on the ground under the rider, a little ahead (the rider sits behind its middle)
	dino:PivotTo(p.root.CFrame * CFrame.new(0, -(hip + p.root.Size.Y / 2), -c.SeatForward * math.max(box.X, box.Z)))
	weldTo(dino, p.root)
	dino.Name = "Mount"
	dino.Parent = p.model
	p.dino = dino
end

local function mark(p)
	local head = p.model:FindFirstChild("Head")
	if not head then
		return
	end
	local b = Instance.new("BillboardGui")
	b.Size = MARK_SIZE
	b.StudsOffsetWorldSpace = Vector3.new(0, 3, 0)
	b.AlwaysOnTop = true
	local t = Instance.new("TextLabel")
	t.Size = UDim2.fromScale(1, 1)
	t.BackgroundTransparency = 1
	t.TextScaled = true
	t.Text = DIZZY_MARK
	t.Parent = b
	b.Parent = head
	task.delay(Config.Slap.FlightSeconds + Config.Slap.GroggySeconds + 0.5, function()
		b:Destroy()
	end)
end

-- ---------------------------------------------------------------------------
-- A slap reaching one
-- ---------------------------------------------------------------------------

local function throw(p, from, level)
	p.hidden = false
	p.flying = nil
	p.root.Anchored = false
	if p.keys > 0 then
		Keys.scatter(p.root.Position, Keys.rollBoxes(p.keys), nil, true)
		p.keys = 0
		showKeys(p)
	end
	dismount(p)
	local away = flat(p.root.Position - from)
	away = away.Magnitude > 0.1 and away.Unit or flat(p.root.CFrame.LookVector * -1).Unit
	local flight = Config.Slap.FlightSeconds
	local studs = Formulas.slapKnockback(level or 1)
	p.humanoid.PlatformStand = true
	play(p, "Fall")
	p.root.AssemblyLinearVelocity = away * (studs / flight) + Vector3.new(0, Workspace.Gravity * flight / 2, 0)
	p.root.AssemblyAngularVelocity = Vector3.new(rng:NextNumber(-6, 6), rng:NextNumber(-4, 4), rng:NextNumber(-6, 6))
	p.downUntil = os.clock() + flight + Config.Slap.GroggySeconds
	mark(p)
	if p.mode == "Hide" or p.mode == "Race" then
		p.mode = "Wander" -- (found / off its dino: it strolls about after)
		p.home = p.root.Position
	end
end

local function onSlap(slapper, root, reach)
	if not RunService:IsStudio() then
		return {}
	end
	local spots = {}
	local look = flat(root.CFrame.LookVector)
	look = look.Magnitude > 0.01 and look.Unit or Vector3.zAxis
	for _, p in ipairs(puppets) do
		if p.root.Parent and not p.downUntil then
			local d = flat(p.root.Position - root.Position)
			local far = d.Magnitude
			if far <= reach + BODY and (far <= Config.Slap.CloseRadius or (far > 0.01 and d.Unit:Dot(look) >= Config.Slap.FrontDot)) then
				throw(p, root.Position, slapper:GetAttribute("SlapLevel") or 1)
				table.insert(spots, p.root.Position)
			end
		end
	end
	return spots
end

-- ---------------------------------------------------------------------------
-- What each does
-- ---------------------------------------------------------------------------

local function walkTo(p, at, speed)
	p.humanoid.WalkSpeed = speed or WALK
	p.humanoid:MoveTo(Vector3.new(at.X, p.root.Position.Y, at.Z))
	p.goal = at
end

local function wander(p)
	if os.clock() >= p.nextWander then
		p.nextWander = os.clock() + rng:NextNumber(WANDER_EVERY[1], WANDER_EVERY[2])
		local a, r = rng:NextNumber(0, 2 * math.pi), rng:NextNumber(4, WANDER_RADIUS)
		walkTo(p, p.home + Vector3.new(math.cos(a) * r, 0, math.sin(a) * r))
	end
end

local function nearestPlayer(position, range)
	local best, bestD = nil, range
	for _, pl in ipairs(Players:GetPlayers()) do
		local r = pl.Character and pl.Character:FindFirstChild("HumanoidRootPart")
		local d = r and flat(r.Position - position).Magnitude
		if d and d < bestD then
			best, bestD = r, d
		end
	end
	return best
end

local function carryAway(p)
	local chaser = nearestPlayer(p.root.Position, FLEE_RANGE)
	if chaser then
		local away = flat(p.root.Position - chaser.Position)
		away = away.Magnitude > 0.1 and away.Unit or Vector3.xAxis
		walkTo(p, p.root.Position + away * FLEE_STEP, WALK * 1.1)
	else
		wander(p)
	end
end

local function altarMiddle()
	local map = Workspace:FindFirstChild("Map")
	local zone = map and map:FindFirstChild("KeyZone")
	local altar = zone and zone:FindFirstChild("Zone_KeyAltar")
	return altar and altar:GetPivot().Position or Vector3.new(0, groundAt(0, 0), 0)
end

local function altarStep(p, middle)
	if p.keys >= ALTAR_FULL then
		carryAway(p)
		return
	end
	local best, bestD = nil, math.huge
	for _, k in ipairs(Keys.groundKeys()) do
		local spot = Vector3.new(k.x, 0, k.z)
		if flat(spot - middle).Magnitude <= ALTAR_SEEK then
			local d = flat(spot - p.root.Position).Magnitude
			if d < bestD then
				best, bestD = k, d
			end
		end
	end
	if best and bestD <= GRAB_REACH then
		if Keys.grab(best.id) then
			p.keys += 1
			showKeys(p)
		end
	elseif best then
		walkTo(p, Vector3.new(best.x, 0, best.z), WALK * 1.15)
	elseif not p.waitSpot or flat(p.root.Position - p.waitSpot).Magnitude < 2 then
		local a, r = rng:NextNumber(0, 2 * math.pi), rng:NextNumber(ALTAR_RING[1], ALTAR_RING[2])
		p.waitSpot = middle + Vector3.new(math.cos(a) * r, 0, math.sin(a) * r)
		walkTo(p, p.waitSpot)
	end
end

local function follow(p, i)
	local root = ownerRoot()
	if not root then
		return
	end
	local riding = owner:GetAttribute("Riding")
	if riding and not p.dino then
		mount(p)
	end
	local back = flat(root.CFrame.LookVector)
	back = back.Magnitude > 0.01 and -back.Unit or Vector3.zAxis
	local side = Vector3.new(-back.Z, 0, back.X)
	local spot = root.Position + back * FOLLOW_GAP * (1 + math.floor((i - 1) / 2)) + side * ((i % 2 == 0) and 4 or -4)
	if flat(spot - p.root.Position).Magnitude > 2 then
		local mine = owner.Character:FindFirstChildOfClass("Humanoid")
		walkTo(p, spot, (mine and mine.WalkSpeed or WALK) * 1.15)
	else
		p.humanoid:MoveTo(p.root.Position)
	end
end

-- the road race: the compass angle round the map's middle (as Race: 0 = north, going up)
local function angleOf(position)
	return math.atan2(position.X, -position.Z)
end

local function raceStep(p)
	local r = p.race
	if r.state == "Wait" then
		local racing = owner and owner:GetAttribute("Racing")
		if racing == "Go" or (not r.withMe and os.clock() >= r.goAt) then
			r.state, r.lastA, r.gone = "Go", angleOf(p.root.Position), 0
			r.nextBoost = os.clock() + rng:NextNumber(BOOST_EVERY[1], BOOST_EVERY[2])
		end
		return
	elseif r.state ~= "Go" then
		return
	end
	local a = angleOf(p.root.Position)
	local step = (a - r.lastA + math.pi) % (2 * math.pi) - math.pi
	r.gone += step
	r.lastA = a
	if r.gone >= 2 * math.pi + math.rad(Config.Race.StartBack) then
		r.state = "Done"
		p.humanoid:MoveTo(p.root.Position)
		return
	end
	local speed = Config.Race.Speed * r.speed
	if os.clock() >= r.nextBoost then
		r.nextBoost = os.clock() + rng:NextNumber(BOOST_EVERY[1], BOOST_EVERY[2])
		if rng:NextNumber() < BUMP_CHANCE then -- "쾅": knocked back along the road, still riding
			local ahead = Vector3.new(math.cos(a), 0, math.sin(a))
			p.root.AssemblyLinearVelocity = -ahead * BUMP.Back + Vector3.new(0, BUMP.Up, 0)
		else
			r.boostUntil = os.clock() + BOOST.Seconds
		end
	end
	if r.boostUntil and os.clock() < r.boostUntil then
		speed *= BOOST.Multiplier
	end
	local t = a + RACE_STEP
	walkTo(p, Vector3.new(math.sin(t), 0, -math.cos(t)) * r.radius, speed)
end

local function startRace()
	local root = ownerRoot()
	if not root then
		return
	end
	local withMe = owner:GetAttribute("Racing") ~= nil
	local c = Config.Race
	local at, a
	if withMe then
		at = root.Position
		a = angleOf(at)
	else
		a = math.rad(c.FinishAngle - c.StartBack)
		at = Vector3.new(math.sin(a), 0, -math.cos(a)) * c.Radius
	end
	local out = Vector3.new(math.sin(a), 0, -math.cos(a))
	local ahead = Vector3.new(math.cos(a), 0, math.sin(a))
	for i, p in ipairs(puppets) do
		local spot = RACE_SPOTS[(i - 1) % #RACE_SPOTS + 1]
		local where = flat(at) + out * spot[1] + ahead * spot[2]
		dismount(p)
		p.downUntil, p.hidden = nil, false
		p.humanoid.PlatformStand = false
		p.root.Anchored = false
		local y = groundAt(where.X, where.Z, at.Y)
		p.model:PivotTo(CFrame.lookAt(Vector3.new(where.X, y + p.hip + p.root.Size.Y / 2 + 0.3, where.Z),
			Vector3.new(where.X, y + p.hip + p.root.Size.Y / 2 + 0.3, where.Z) + ahead))
		mount(p)
		p.mode = "Race"
		p.race = { state = "Wait", withMe = withMe, goAt = os.clock() + RACE_COUNT, radius = flat(where).Magnitude,
			speed = rng:NextNumber(RACE_SPEEDS[1], RACE_SPEEDS[2]) }
	end
	return withMe
end

local function hideAll()
	local root = ownerRoot()
	local map = Workspace:FindFirstChild("Map")
	if not root or not map then
		return 0
	end
	local trees = {}
	for _, m in ipairs(map:GetDescendants()) do
		if m:IsA("Model") and TREE_KINDS[m.Name] then
			local top = nil
			for _, part in ipairs(m:GetChildren()) do
				if part:IsA("BasePart") and TRUNKS[part.Name] then
					local y = part.Position.Y + part.Size.Y / 2
					if not top or y > top.Y then
						top = Vector3.new(part.Position.X, y, part.Position.Z)
					end
				end
			end
			local d = top and flat(top - root.Position).Magnitude
			if d and d <= HIDE_RANGE then
				table.insert(trees, { top = top, d = d })
			end
		end
	end
	table.sort(trees, function(x, y)
		return x.d < y.d
	end)
	local chosen = {}
	for _, t in ipairs(trees) do
		local apart = true
		for _, c in ipairs(chosen) do
			apart = apart and flat(c - t.top).Magnitude >= HIDE_APART
		end
		if apart then
			table.insert(chosen, t.top)
		end
		if #chosen >= #puppets then
			break
		end
	end
	for i, p in ipairs(puppets) do
		local top = chosen[i]
		if top then
			dismount(p)
			p.downUntil = nil
			p.humanoid.PlatformStand = false
			p.root.Anchored = true
			p.model:PivotTo(CFrame.new(top + Vector3.new(0, p.hip + p.root.Size.Y / 2, 0))
				* CFrame.Angles(0, rng:NextNumber(0, 2 * math.pi), 0))
			p.hidden = true
			p.mode = "Hide"
		end
	end
	return #chosen
end

local function tick()
	local middle = nil
	for i = #puppets, 1, -1 do
		local p = puppets[i]
		if not p.model.Parent or not p.root.Parent then
			table.remove(puppets, i)
		end
	end
	for i, p in ipairs(puppets) do
		if p.downUntil then
			if os.clock() >= p.downUntil then -- up again
				p.downUntil = nil
				p.humanoid.PlatformStand = false
				p.root.AssemblyAngularVelocity = Vector3.zero
				local look = flat(p.root.CFrame.LookVector)
				look = look.Magnitude > 0.01 and look.Unit or Vector3.zAxis
				p.root.CFrame = CFrame.lookAt(p.root.Position + Vector3.new(0, 1, 0), p.root.Position + Vector3.new(0, 1, 0) + look)
				p.humanoid:ChangeState(Enum.HumanoidStateType.GettingUp)
			end
		elseif not p.hidden then
			if p.mode == "Keys" then
				carryAway(p)
			elseif p.mode == "Altar" then
				middle = middle or altarMiddle()
				altarStep(p, middle)
			elseif p.mode == "Race" and p.race then
				raceStep(p)
			elseif p.mode == "Follow" then
				follow(p, i)
			elseif p.mode == "Wander" then
				wander(p)
			end
		end
		-- the animation for what it does
		if not p.downUntil then
			local speed = flat(p.root.AssemblyLinearVelocity).Magnitude
			if p.dino or p.hidden then
				play(p, p.dino and "Sit" or "Idle")
			elseif speed > MOVING then
				play(p, "Run", speed / RUN_ANIM_SPEED)
			else
				play(p, "Idle")
			end
		end
	end
end

local function free(p)
	if p.hidden then
		p.hidden = false
		p.root.Anchored = false
	end
	if p.flying then
		p.flying = nil
		dismount(p)
		local at = p.root.Position
		p.root.CFrame = CFrame.new(at.X, groundAt(at.X, at.Z, at.Y) + p.hip + p.root.Size.Y / 2 + 0.2, at.Z)
		p.root.Anchored = false
	end
	p.race = nil
end

local flyCenter, flyConn = nil, nil
local function flyStep()
	if not flyCenter then
		return
	end
	local t = os.clock()
	local n = 0
	for _, p in ipairs(puppets) do
		if p.flying and p.root.Parent then
			n += 1
			local row = math.ceil((n - 1) / 2)
			local side = (n % 2 == 0 and 1 or -1) * row * FLY_SPREAD
			local a = t * FLY_SPEED - row * FLY_LAG
			local out = Vector3.new(math.cos(a), 0, math.sin(a))
			local ahead = Vector3.new(-math.sin(a), 0, math.cos(a))
			local at = flyCenter + out * (FLY_RADIUS + side) + Vector3.new(0, math.sin(t * 2 + n) * FLY_BOB + row, 0)
			p.root.CFrame = CFrame.lookAt(at, at + ahead) * CFrame.Angles(0, 0, FLY_BANK)
		end
	end
end

local function clear()
	for _, p in ipairs(puppets) do
		p.model:Destroy()
	end
	puppets = {}
end

-- ---------------------------------------------------------------------------
-- The command (TestCommands ;fake); returns the reply
-- ---------------------------------------------------------------------------

FakePlayers.altarMiddle = altarMiddle

function FakePlayers.command(player, args)
	if not RunService:IsStudio() then
		return nil -- (never in a real game)
	end
	Keys = Keys or require(script.Parent:WaitForChild("Keys"))
	if not hooked then
		hooked = true
		local Combat = require(script.Parent:WaitForChild("Combat"))
		Combat.onSlap(onSlap)
		Combat.onSafeSlap(onSlap)
		Players.PlayerRemoving:Connect(function(p)
			if p == owner then
				clear()
			end
		end)
	end
	if not folder or not folder.Parent then
		folder = Instance.new("Folder")
		folder.Name = "FakePlayers"
		folder.Parent = Workspace
	end
	owner = player
	if not running then
		running = true
		task.spawn(function()
			while true do
				task.wait(TICK)
				local ok, err = pcall(tick)
				if not ok then
					warn("[FakePlayers] " .. tostring(err))
				end
			end
		end)
	end
	local word = string.lower(args[1] or "")
	local n = tonumber(word)
	local root = ownerRoot()
	if n then
		if not root then
			return "캐릭터가 없어요"
		end
		clear()
		n = math.clamp(math.floor(n), 1, MAX)
		for i = 1, n do
			local a = (i / n) * 2 * math.pi + rng:NextNumber(-0.3, 0.3)
			local r = rng:NextNumber(SPAWN_RING[1], SPAWN_RING[2])
			local x, z = root.Position.X + math.cos(a) * r, root.Position.Z + math.sin(a) * r
			spawnOne(Vector3.new(x, groundAt(x, z, root.Position.Y), z))
		end
		return string.format("가짜 플레이어 %d명 (;fake keys / altar / race / hide / follow / wander / ride / fly / stop / clear)", #puppets)
	elseif word == "clear" then
		clear()
		return "가짜 플레이어를 모두 치웠어요"
	end
	if #puppets == 0 then
		return "먼저 ;fake 3 처럼 불러 주세요"
	end
	for _, p in ipairs(puppets) do
		if word ~= "hide" and word ~= "ride" then
			free(p)
		end
	end
	if word == "fly" then
		local middle = altarMiddle()
		local away = flat((root and root.Position or middle + Vector3.xAxis) - middle)
		away = away.Magnitude > 1 and away.Unit or Vector3.xAxis
		local spot = middle + away * FLY_OUT
		flyCenter = Vector3.new(spot.X, groundAt(spot.X, spot.Z, middle.Y) + FLY_HEIGHT, spot.Z)
		for i, p in ipairs(puppets) do
			dismount(p)
			p.keys = 0
			showKeys(p)
			p.mode, p.flying = "Fly", true
			p.root.Anchored = true
			mount(p, FLY_SPECIES[(i - 1) % #FLY_SPECIES + 1])
		end
		if not flyConn then
			flyConn = RunService.Heartbeat:Connect(flyStep)
		end
		flyStep()
		return "공룡을 타고 하늘을 날아요 (배틀필드 위를 빙빙)"
	end
	if word == "keys" then
		for _, p in ipairs(puppets) do
			dismount(p)
			p.mode, p.home = "Keys", p.root.Position
			p.keys = rng:NextInteger(KEYS_HELD[1], KEYS_HELD[2])
			showKeys(p)
		end
		return "열쇠를 들고 도망 다녀요. 찰싹하면 열쇠가 쏟아져요"
	elseif word == "altar" then
		local middle = altarMiddle()
		for _, p in ipairs(puppets) do
			dismount(p)
			p.mode, p.home, p.waitSpot = "Altar", middle, nil
		end
		return "제단 둘레에서 기다리다 열쇠가 떨어지면 달려가요 (;drop 으로 바로 떨어뜨리기)"
	elseif word == "race" then
		local withMe = startRace()
		return withMe and "내 옆에 줄 섰어요. 내 레이스가 시작되면 같이 출발해요"
			or "출발선에 줄 섰어요. 3초 뒤 출발 (레이스 연습 중에 쓰면 내 옆에 서요)"
	elseif word == "hide" then
		local hidden = hideAll()
		return string.format("나무 %d그루에 숨었어요. 나무 앞에서 찰싹하면 떨어져요", hidden)
	elseif word == "follow" then
		for _, p in ipairs(puppets) do
			p.mode = "Follow"
		end
		return "나를 따라와요 (내가 공룡을 타면 같이 타요)"
	elseif word == "wander" then
		for _, p in ipairs(puppets) do
			dismount(p)
			p.mode, p.home = "Wander", p.root.Position
		end
		return "주변을 돌아다녀요"
	elseif word == "ride" then
		local any = false
		for _, p in ipairs(puppets) do
			any = any or p.dino ~= nil
		end
		for _, p in ipairs(puppets) do
			if any then
				dismount(p)
			else
				mount(p)
			end
		end
		return any and "공룡에서 내렸어요" or "공룡을 탔어요"
	elseif word == "stop" then
		for _, p in ipairs(puppets) do
			p.mode = "Stop"
			p.humanoid:MoveTo(p.root.Position)
		end
		return "멈췄어요"
	end
	return "사용법: ;fake 3 / keys / altar / race / hide / follow / wander / ride / fly / stop / clear"
end

return FakePlayers
