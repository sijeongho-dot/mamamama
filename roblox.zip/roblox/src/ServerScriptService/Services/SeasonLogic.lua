--[[
SeasonLogic: the rules of the season pass, without Roblox (2026-10-02, design 2.15; tested by
tools/tests/season_logic_test.lua; the Season service runs them). Config.Season holds the numbers.

- Seasons: Config.Season.Days days each from StartDay (days of Config.Rewards, RewardLogic.dayNumber);
  season 1 starts on StartDay, 0 before it. Themes go round by season.
- profile.Season = { Id, Xp, Free = { ["tier"] = true }, Paid = { ... }, Premium, PlayDay, PlayMinutes }:
  this season's XP, the tiers taken on each track, whether its pass is bought, and the minutes of play
  counted today (PlayMinutesPerDay at most pay XP).
- A new season (ensure): the rewards reached and not taken of the old one are handed back to be given
  (the pass ones only with its pass), then everything starts over (the pass too: bought each season).
- Tier: 1 at the start, then one more every XpPerTier XP, Tiers at most. A tier's free reward is taken once it is reached; its pass
  reward with the pass. Taking all at once (claimAll) goes tier by tier, free first.
]]

local Config = if game then require(game:GetService("ReplicatedStorage"):WaitForChild("Config")) else CONFIG

local SeasonLogic = {}

local TRACKS = { "Free", "Paid" }
SeasonLogic.TRACKS = TRACKS

-- the season a day is in (0 before the first), the day in it (1..Days) and the days left after today
function SeasonLogic.season(day)
	local c = Config.Season
	if day < c.StartDay then
		return 0, 0, c.StartDay - day
	end
	local since = day - c.StartDay
	local id = since // c.Days + 1
	local inSeason = since % c.Days + 1
	return id, inSeason, c.Days - inSeason
end

-- the theme of a season (round and round)
function SeasonLogic.theme(id)
	local list = Config.Season.Themes
	return list[(math.max(id, 1) - 1) % #list + 1], (math.max(id, 1) - 1) % #list + 1
end

local function fresh(id)
	return { Id = id, Xp = 0, Free = {}, Paid = {}, Premium = false, PlayDay = 0, PlayMinutes = 0 }
end

-- the tier reached with this much XP (1..Tiers: a season starts at tier 1, its rewards free straight away;
-- 2026-10-02 "1레벨은 무료로"), the XP into the next tier and what it needs (0 at the top)
function SeasonLogic.tier(xp)
	local c = Config.Season
	local tier = math.min(c.Tiers, xp // c.XpPerTier + 1)
	if tier >= c.Tiers then
		return tier, 0, 0
	end
	return tier, xp - (tier - 1) * c.XpPerTier, c.XpPerTier
end

local function rewardOf(track, tier)
	local list = Config.Season[track]
	return list and list[tier]
end
SeasonLogic.reward = rewardOf

-- may that tier of that track be taken now?
function SeasonLogic.ready(profile, track, tier)
	local s = profile.Season
	if not rewardOf(track, tier) or s.Id < 1 or s[track][tostring(tier)] then
		return false
	end
	if track == "Paid" and not s.Premium then
		return false
	end
	return SeasonLogic.tier(s.Xp) >= tier
end

-- every reward that may be taken now: { { track, tier, reward }, ... } in order
function SeasonLogic.readyList(profile)
	local list = {}
	local reached = SeasonLogic.tier(profile.Season.Xp)
	for tier = 1, reached do
		for _, track in ipairs(TRACKS) do
			if SeasonLogic.ready(profile, track, tier) then
				table.insert(list, { track, tier, rewardOf(track, tier) })
			end
		end
	end
	return list
end

function SeasonLogic.readyCount(profile)
	return #SeasonLogic.readyList(profile)
end

-- make sure the profile is in today's season; a new one hands back the old one's untaken rewards:
-- returns { { track, tier, reward }, ... } (may be empty) and the old season's id, or nil when nothing changed
function SeasonLogic.ensure(profile, day)
	local id = SeasonLogic.season(day)
	local s = profile.Season
	if s.Id == id then
		return nil
	end
	local leftover = s.Id >= 1 and SeasonLogic.readyList(profile) or {}
	profile.Season = fresh(id)
	return leftover, s.Id
end

-- XP added; returns the tiers reached by it ({ tier, ... })
function SeasonLogic.addXp(profile, amount)
	local s = profile.Season
	if s.Id < 1 or amount <= 0 then
		return {}
	end
	local before = SeasonLogic.tier(s.Xp)
	s.Xp += amount
	local after = SeasonLogic.tier(s.Xp)
	local reached = {}
	for t = before + 1, after do
		table.insert(reached, t)
	end
	return reached
end

-- minutes of play today: the XP they pay (PlayMinutesPerDay a day at most); returns that XP
function SeasonLogic.playXp(profile, day, minutes)
	local s = profile.Season
	local x = Config.Season.Xp
	if s.PlayDay ~= day then
		s.PlayDay, s.PlayMinutes = day, 0
	end
	local counted = math.max(0, math.min(minutes, x.PlayMinutesPerDay - s.PlayMinutes))
	s.PlayMinutes += counted
	return counted * x.PlayMinute
end

-- take a tier's reward: the reward or nil
function SeasonLogic.claim(profile, track, tier)
	if not SeasonLogic.ready(profile, track, tier) then
		return nil
	end
	profile.Season[track][tostring(tier)] = true -- (string keys: a saved table stays a dictionary)
	return rewardOf(track, tier)
end

-- take everything ready: { { track, tier, reward }, ... }
function SeasonLogic.claimAll(profile)
	local list = SeasonLogic.readyList(profile)
	for _, item in ipairs(list) do
		profile.Season[item[1]][tostring(item[2])] = true
	end
	return list
end

-- the pass bought for this season: false when it was already (or there is no season)
function SeasonLogic.buyPass(profile)
	local s = profile.Season
	if s.Id < 1 or s.Premium then
		return false
	end
	s.Premium = true
	return true
end

return SeasonLogic
