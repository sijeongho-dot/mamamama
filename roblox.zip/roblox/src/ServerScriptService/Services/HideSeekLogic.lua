--[[
HideSeekLogic: the rules of 🙈 hide-and-seek (2026-10-03, "숨박꼭질 기능도 만들자"), without Roblox: the rooms, who
is in which, ready, the start (the seeker picked at random), who is out, and who won. The HideSeek service moves
the players, keeps the time and saves the records; tools/tests/hideseek_test.lua tests this.

A room: { Id, Host (userId), Members (userIds in joining order), Ready ([userId] = true), Phase ("Waiting",
"Hiding", "Seeking", "Done"), Seeker (userId), Out ([userId] = "Tagged" | "Gave up"), Recorded ([userId] = true:
their win or loss is counted), Ranked (2026-10-04: true = 🏆 랭킹전, the records are saved; false = 🎈 일반전), Stake (a
ranked room's Config.Ranked.Stake.Grades Id, the host's pick) }.
]]

local Config = if game then require(game:GetService("ReplicatedStorage"):WaitForChild("Config")) else CONFIG
local C = Config.HideSeek

local HideSeekLogic = {}

function HideSeekLogic.new()
	return { Rooms = {}, NextId = 1, RoomOf = {} } -- RoomOf: [userId] = room
end

function HideSeekLogic.roomOf(state, userId)
	return state.RoomOf[userId]
end

local function count(state)
	local n = 0
	for _ in pairs(state.Rooms) do
		n += 1
	end
	return n
end

local function stakeKnown(stake)
	for _, g in ipairs(Config.Ranked.Stake.Grades) do
		if g.Id == stake then
			return true
		end
	end
	return false
end

-- open a room with this player in it (ranked: 🏆 랭킹전, else 🎈 일반전): the room, or nil and why
function HideSeekLogic.create(state, userId, ranked, stake)
	if ranked == true and not stakeKnown(stake) then
		return nil, "없는 방이에요"
	end
	if state.RoomOf[userId] then
		return nil, "이미 방에 있어요"
	end
	if count(state) >= C.MaxRooms then
		return nil, "🚪 방이 가득 찼어요. 다른 방에 들어가요"
	end
	local room = { Id = state.NextId, Host = userId, Members = { userId }, Ready = {}, Phase = "Waiting", Out = {},
		Recorded = {}, Ranked = ranked == true, Stake = ranked == true and stake or nil }
	state.NextId += 1
	state.Rooms[room.Id] = room
	state.RoomOf[userId] = room
	return room
end

function HideSeekLogic.join(state, userId, roomId)
	local room = state.Rooms[roomId]
	if state.RoomOf[userId] then
		return nil, "이미 방에 있어요"
	elseif not room then
		return nil, "없는 방이에요"
	elseif room.Phase ~= "Waiting" then
		return nil, "이미 시작한 방이에요"
	elseif #room.Members >= C.MaxPlayers then
		return nil, "방이 꽉 찼어요"
	end
	table.insert(room.Members, userId)
	state.RoomOf[userId] = room
	return room
end

-- out of their room (leaving the game, the window's 나가기): the room it left. In a game, it counts as giving up
-- (HideSeekLogic.giveUp first); a room left empty, or done, goes
function HideSeekLogic.leave(state, userId)
	local room = state.RoomOf[userId]
	if not room then
		return nil
	end
	state.RoomOf[userId] = nil
	local i = table.find(room.Members, userId)
	if i then
		table.remove(room.Members, i)
	end
	room.Ready[userId] = nil
	if room.Host == userId then
		room.Host = room.Members[1]
	end
	if #room.Members == 0 then
		state.Rooms[room.Id] = nil
	end
	return room
end

function HideSeekLogic.setReady(state, userId, ready)
	local room = state.RoomOf[userId]
	if not room or room.Phase ~= "Waiting" then
		return nil
	end
	room.Ready[userId] = ready and true or nil
	return room
end

-- every member ready, and enough of them
function HideSeekLogic.canStart(room)
	if room.Phase ~= "Waiting" or #room.Members < C.MinPlayers then
		return false
	end
	for _, userId in ipairs(room.Members) do
		if not room.Ready[userId] then
			return false
		end
	end
	return true
end

-- the game starts: a seeker at random (rng() in [0, 1)), the others hide. Returns the seeker
function HideSeekLogic.start(room, rng)
	room.Seeker = room.Members[math.clamp(math.floor(rng() * #room.Members) + 1, 1, #room.Members)]
	room.Phase = "Hiding"
	room.Out, room.Recorded, room.OutOrder = {}, {}, {}
	return room.Seeker
end

function HideSeekLogic.hiders(room)
	local list = {}
	for _, userId in ipairs(room.Members) do
		if userId ~= room.Seeker then
			table.insert(list, userId)
		end
	end
	return list
end

-- the hiders still in
function HideSeekLogic.left(room)
	local n = 0
	for _, userId in ipairs(HideSeekLogic.hiders(room)) do
		if not room.Out[userId] then
			n += 1
		end
	end
	return n
end

function HideSeekLogic.isHider(room, userId)
	return room.Phase ~= "Waiting" and room.Phase ~= "Done" and userId ~= room.Seeker and table.find(room.Members, userId)
		~= nil and not room.Out[userId]
end

-- the seeker slapped a hider while seeking: true when that put them out (their loss is to be recorded)
function HideSeekLogic.tag(room, seekerId, hiderId)
	if room.Phase ~= "Seeking" or seekerId ~= room.Seeker or not HideSeekLogic.isHider(room, hiderId) then
		return false
	end
	room.Out[hiderId] = "Tagged"
	room.Recorded[hiderId] = true
	table.insert(room.OutOrder, hiderId)
	return true
end

-- a player in a game gives up (a reset, leaving, the window's 나가기): true when it counted (their loss)
function HideSeekLogic.giveUp(room, userId)
	if room.Phase ~= "Hiding" and room.Phase ~= "Seeking" or room.Recorded[userId] then
		return false
	end
	if userId == room.Seeker then
		room.SeekerGaveUp = true
	elseif not HideSeekLogic.isHider(room, userId) then
		return false
	else
		room.Out[userId] = "Gave up"
		table.insert(room.OutOrder, userId)
	end
	room.Recorded[userId] = true
	return true
end

-- who has won now: "Seeker" (no hider left), "Hiders" (the seeker gave up, or timeUp), or nil (still on)
function HideSeekLogic.winner(room, timeUp)
	if room.Phase ~= "Hiding" and room.Phase ~= "Seeking" then
		return nil
	end
	if room.SeekerGaveUp then
		return "Hiders"
	elseif HideSeekLogic.left(room) == 0 then
		return "Seeker"
	elseif timeUp then
		return "Hiders"
	end
	return nil
end

-- (2026-10-06) the places for a ranked game's keys, best first: groups of userIds (a group shares its place). The
-- winners first (the seeker alone, or every hider still in), then the seeker when it lost, then the caught hiders (the
-- last caught first), then those who gave up (the seeker last if it gave up)
function HideSeekLogic.places(room, winner)
	local order = {}
	local survivors = {}
	for _, userId in ipairs(HideSeekLogic.hiders(room)) do
		if not room.Out[userId] then
			table.insert(survivors, userId)
		end
	end
	if winner == "Seeker" then
		table.insert(order, { room.Seeker })
	elseif #survivors > 0 then
		table.insert(order, survivors)
	end
	if winner ~= "Seeker" and not room.SeekerGaveUp then
		table.insert(order, { room.Seeker })
	end
	local outOrder = room.OutOrder or {}
	for _, reason in ipairs({ "Tagged", "Gave up" }) do
		for i = #outOrder, 1, -1 do
			if room.Out[outOrder[i]] == reason then
				table.insert(order, { outOrder[i] })
			end
		end
	end
	if room.SeekerGaveUp then
		table.insert(order, { room.Seeker })
	end
	return order
end

-- the game ends with that winner: { Wins = { userIds }, Losses = { userIds } } not counted yet; the room waits again
function HideSeekLogic.finish(room, winner)
	local result = { Wins = {}, Losses = {} }
	local function count(userId, won)
		if not room.Recorded[userId] and table.find(room.Members, userId) then
			room.Recorded[userId] = true
			table.insert(won and result.Wins or result.Losses, userId)
		end
	end
	count(room.Seeker, winner == "Seeker")
	for _, userId in ipairs(HideSeekLogic.hiders(room)) do
		count(userId, winner == "Hiders" and not room.Out[userId])
	end
	room.Phase = "Waiting"
	room.Ready, room.Seeker, room.SeekerGaveUp = {}, nil, nil
	room.Out = {}
	return result
end

function HideSeekLogic.radarPick(seeker, samples, moveStuds)
	local best, bestDistance = nil, math.huge
	for _, sample in ipairs(samples) do
		local dx, dy, dz = sample.to.X - sample.from.X, sample.to.Y - sample.from.Y, sample.to.Z - sample.from.Z
		if dx * dx + dy * dy + dz * dz > moveStuds * moveStuds then
			local ex, ez = sample.to.X - seeker.X, sample.to.Z - seeker.Z
			local distance = math.sqrt(ex * ex + ez * ez)
			if distance < bestDistance then
				best, bestDistance = sample, distance
			end
		end
	end
	return best, bestDistance
end

function HideSeekLogic.bellBlur(moved, left)
	local blur = (moved or math.huge) < C.BellStillStuds and C.BellBlurStill or C.BellBlurMoving
	return left <= C.FinalSeconds and blur * C.BellFinalBlur or blur
end

-- the room list for the clients: { { Id, Host, Members = { userIds }, Ready = { userIds }, Phase, Seeker, Ranked } }
function HideSeekLogic.snapshot(state)
	local list = {}
	for _, room in pairs(state.Rooms) do
		local ready = {}
		for _, userId in ipairs(room.Members) do
			if room.Ready[userId] then
				table.insert(ready, userId)
			end
		end
		table.insert(list, { Id = room.Id, Host = room.Host, Members = table.clone(room.Members), Ready = ready,
			Phase = room.Phase, Seeker = room.Seeker, Ranked = room.Ranked, Stake = room.Stake })
	end
	table.sort(list, function(a, b)
		return a.Id < b.Id
	end)
	return list
end

return HideSeekLogic
