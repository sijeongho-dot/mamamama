--[[
MoneyPile: the money the defense dinos earned while the player was away (design 2.13 자리 비운 동안)
waits as a pile of money beside their spawn pad, on the side away from the rebirth sign, until they walk
up and touch it (2026-10-01: the arena's middle, then the middle of the base, the arena again with a
light pillar, now by the spawn pad where everyone arrives).

- Rewards.payOffline adds the time away's money to profile.OfflinePending (saved: leaving before
  picking it up keeps it for next time, and more time away adds to it).
- While a player has some waiting and has a base, a cone of bundled bills stands there (one mesh,
  Prop_MoneyPile_1-5, or parts without them), in proportion to the money: as many bundles as its share of the most that can wait at the player's level
  (RewardLogic.offlineMax: a full day away) between BUNDLES_MIN and BUNDLES_MAX (2026-10-03: no light
  pillar over it any more), with a "💰 자리 비운 동안 번 돈" label over it (folder MoneyPile under the base).
- The owner touching it (within PICK_RANGE of its middle, checked here on the server) gets it all
  (PlayerData.addMoney "offline"); the pile bursts and goes, and Net push MoneyPop(userId, amount) shows
  "+12,345원" rising over the owner's head on every screen.
- (2026-10-01, "the pile stays after taking it") a pile only stays while its owner still has money waiting:
  every check a pile whose owner has none left goes, and every SWEEP_EVERY seconds any MoneyPile in a base
  that isn't its owner's pile now goes too.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ServerStorage = game:GetService("ServerStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local ServerMeter = require(script.Parent:WaitForChild("ServerMeter")) -- (2026-10-04: its loop timed, Watchdog)
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))

local MoneyPile = {}

-- display only
local BILL_SIZE = Vector3.new(2, 0.5, 1)
local BILL_COLOR = Color3.fromRGB(110, 190, 90)
local BAND_COLOR = Color3.fromRGB(245, 225, 120)
-- bundles = BUNDLES_MIN + (BUNDLES_MAX − BUNDLES_MIN) × (the money ÷ the most that can wait): the cone's
-- foot and height grow with it (an hour away about 40, a night about 160, a full day 260)
local BUNDLES_MIN, BUNDLES_MAX = 12, 260
local LAYER_SHRINK = 0.9 -- each layer up is this much narrower (a tall cone)
-- (2026-10-03, "덩어리 메시로 바꿔") the pile as one mesh (tools/make_moneypile.py, ServerStorage.Assets): the model
-- with the nearest bundle count, scaled by the cube root of the counts' ratio; without them, bundles of parts
-- (two parts a bundle, up to 520 sent to every player at once)
local PILE_MODELS = { { "Prop_MoneyPile_1", 12 }, { "Prop_MoneyPile_2", 40 }, { "Prop_MoneyPile_3", 100 },
	{ "Prop_MoneyPile_4", 180 }, { "Prop_MoneyPile_5", 260 } }
-- (2026-10-04: was 15 studs beside it, away from the rebirth sign; the training ground's rock stands there now) studs in
-- front of the spawn pad's middle, toward the base's entrance: where a player who comes back sees it first
local FRONT_OF_SPAWN = 13
local LABEL_COLOR = Color3.fromRGB(255, 230, 120)
local LABEL_ABOVE = 4 -- studs over the pile's top for its label
local LABEL_SIZE = UDim2.fromOffset(260, 56)
local CHECK_EVERY = 0.2
local SWEEP_EVERY = 2 -- seconds between the looks for stray piles
local PICK_MARGIN = 3 -- studs past the pile's foot (flat) that count as touching it
local PICK_HEIGHT = 16 -- studs above or below the pile's foot that still count
-- (2026-10-04, "오프라인 머니 있으면 그 바닥에 원형 노란 오라 놔줘. 눈에 띄게") a glowing yellow disc on the ground under the
-- pile (AURA_PAD studs past its foot) with a ring round its edge, and a warm light
local AURA_PAD = 4
local AURA_COLOR = Color3.fromRGB(255, 215, 70)
local AURA_TRANSPARENCY = 0.45
local AURA_RING_WIDTH = 0.8 -- studs: the brighter edge
local AURA_LIGHT_RANGE = 16

local piles = {} -- [player] = { model, center, amount }

local function removePile(player)
	local p = piles[player]
	if p then
		p.model:Destroy()
		piles[player] = nil
	end
end

-- the pile as one mesh of about `bills` bundles, its bottom middle at center, in model; its height and foot
-- radius, or nil without the models
local function meshPile(model, center, bills)
	local assets = ServerStorage:FindFirstChild("Assets")
	local best
	for _, m in ipairs(PILE_MODELS) do
		if not best or math.abs(math.log(m[2] / bills)) < math.abs(math.log(best[2] / bills)) then
			best = m
		end
	end
	local source = assets and assets:FindFirstChild(best[1], true)
	if not source then
		return nil
	end
	local pile = source:Clone()
	if pile:IsA("BasePart") then
		local holder = Instance.new("Model")
		pile.Parent = holder
		pile = holder
	end
	pile.Name = "Bills"
	for _, d in ipairs(pile:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
		end
	end
	pile:ScaleTo((bills / best[2]) ^ (1 / 3))
	local cf, size = pile:GetBoundingBox()
	pile:PivotTo(pile:GetPivot() + (center - Vector3.new(cf.Position.X, cf.Position.Y - size.Y / 2, cf.Position.Z)))
	pile.Parent = model
	return size.Y, math.max(1.5, math.max(size.X, size.Z) / 2)
end

-- a cone of money bundles in rings, layer on layer
local function buildPile(center, amount, most)
	local model = Instance.new("Model")
	model.Name = "MoneyPile"
	local share = math.clamp(amount / math.max(most, 1), 0, 1)
	local bills = math.floor(BUNDLES_MIN + (BUNDLES_MAX - BUNDLES_MIN) * share + 0.5)
	-- the foot's radius that a cone of LAYER_SHRINK holds `bills` bundles (rings of 2πr / bundle length)
	local foot = math.max(1.5, bills * BILL_SIZE.X * (1 - LAYER_SHRINK) / (2 * math.pi))
	local placed, layer, radius = 0, 0, foot
	local height, meshFoot = meshPile(model, center, bills)
	if height then
		foot, placed = meshFoot, bills -- (no bundles of parts)
	end
	while placed < bills and radius > 0.3 do
		local ring = math.max(1, math.floor(2 * math.pi * radius / BILL_SIZE.X))
		for k = 1, ring do
			if placed >= bills then
				break
			end
			local a = (k + layer * 0.5) / ring * 2 * math.pi
			local at = center + Vector3.new(math.cos(a) * radius, BILL_SIZE.Y * (layer + 0.5), math.sin(a) * radius)
			local bill = Instance.new("Part")
			bill.Name = "Bills"
			bill.Size = BILL_SIZE
			bill.CFrame = CFrame.new(at) * CFrame.Angles(0, -a + math.rad((k * 37) % 30 - 15), 0)
			bill.Anchored, bill.CanCollide, bill.CanQuery, bill.CanTouch = true, false, false, false
			bill.Color = BILL_COLOR
			bill.Material = Enum.Material.SmoothPlastic
			bill.Parent = model
			local band = Instance.new("Part") -- the paper band round each bundle
			band.Name = "Band"
			band.Size = Vector3.new(0.35, BILL_SIZE.Y + 0.05, BILL_SIZE.Z + 0.05)
			band.CFrame = bill.CFrame
			band.Anchored, band.CanCollide, band.CanQuery, band.CanTouch = true, false, false, false
			band.Color = BAND_COLOR
			band.Parent = model
			placed += 1
		end
		layer += 1
		radius *= LAYER_SHRINK
	end
	local top = Instance.new("Part") -- (invisible) where the label hangs
	top.Name = "LabelAnchor"
	top.Size = Vector3.one
	top.Transparency = 1
	top.Anchored, top.CanCollide, top.CanQuery, top.CanTouch = true, false, false, false
	top.CFrame = CFrame.new(center + Vector3.new(0, (height or BILL_SIZE.Y * layer) + LABEL_ABOVE, 0))
	top.Parent = model
	local gui = Instance.new("BillboardGui")
	gui.Size = LABEL_SIZE
	gui.AlwaysOnTop = true
	gui.MaxDistance = 120
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBold
	text.TextScaled = true
	text.TextColor3 = LABEL_COLOR
	text.TextStrokeTransparency = 0.2
	text.Text = string.format("💰 자리 비운 동안 번 돈\n%s원 · 만져서 받기", Formulas.shortNumber(amount))
	text.Parent = gui
	gui.Parent = top
	-- the yellow aura on the ground (a disc, a brighter ring at its edge, a light)
	local radius = foot + AURA_PAD
	local function disc(name, diameter, lift, transparency)
		local d = Instance.new("Part")
		d.Name = name
		d.Shape = Enum.PartType.Cylinder
		d.Size = Vector3.new(0.1, diameter, diameter)
		d.CFrame = CFrame.new(center + Vector3.new(0, lift, 0)) * CFrame.Angles(0, 0, math.pi / 2)
		d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
		d.Material = Enum.Material.Neon
		d.Color = AURA_COLOR
		d.Transparency = transparency
		d.Parent = model
		return d
	end
	disc("AuraRing", radius * 2, 0.06, AURA_TRANSPARENCY - 0.2)
	local inner = disc("Aura", (radius - AURA_RING_WIDTH) * 2, 0.08, AURA_TRANSPARENCY + 0.15)
	local glow = Instance.new("PointLight")
	glow.Color = AURA_COLOR
	glow.Range = AURA_LIGHT_RANGE
	glow.Brightness = 1.5
	glow.Parent = inner
	-- (2026-10-03, "오프라인 돈에 빛줄기 효과 제거": the tall gold light pillar and its light are gone)
	local sparkle = Instance.new("ParticleEmitter")
	sparkle.Rate = 6
	sparkle.Lifetime = NumberRange.new(0.8, 1.4)
	sparkle.Speed = NumberRange.new(2, 4)
	sparkle.Size = NumberSequence.new(0.5, 0)
	sparkle.LightEmission = 1
	sparkle.Color = ColorSequence.new(LABEL_COLOR)
	sparkle.Parent = top
	return model, foot
end

-- in front of the base's spawn pad (toward the entrance), on the ground
local function pileSpot(folder)
	local spawn = folder:FindFirstChild("SpawnLocation", true)
	local zone = folder:FindFirstChild("SafeZone")
	if not spawn or not zone then
		return nil
	end
	local flat = Vector3.new(zone.Position.X, 0, zone.Position.Z)
	if flat.Magnitude < 1e-3 then
		return nil
	end
	local out = flat.Unit -- (from the map's middle through the plot: the entrance is the other way)
	return Vector3.new(spawn.Position.X, spawn.Position.Y, spawn.Position.Z) - out * FRONT_OF_SPAWN
end

-- the pile as it should be for this player now (none, or one the size of what waits)
local function refresh(player, profile)
	local amount = profile and profile.OfflinePending or 0
	local index = Bases.of(player)
	local folder = index and Bases.folder(index)
	local spot = folder and pileSpot(folder)
	local p = piles[player]
	if amount <= 0 or not spot then
		removePile(player)
		return
	end
	if p and p.amount == amount and p.index == index then
		return
	end
	removePile(player)
	local ignore = {}
	for _, name in ipairs({ "DefenseUnits", "FarmUnits", "MoneyPile" }) do
		local f = folder:FindFirstChild(name)
		if f then
			table.insert(ignore, f)
		end
	end
	local center = Vector3.new(spot.X, Bases.groundBelow(spot + Vector3.new(0, 20, 0), ignore), spot.Z)
	local model, foot = buildPile(center, amount, RewardLogic.offlineMax(profile.Stats.IdleMoneyRate or 0))
	model.Parent = folder
	piles[player] = { model = model, center = center, amount = amount, index = index, reach = foot + PICK_MARGIN }
end

local function collect(player)
	local profile = PlayerData.get(player)
	local amount = profile and profile.OfflinePending or 0
	removePile(player)
	if amount <= 0 then
		return
	end
	PlayerData.update(player, function(p)
		p.OfflinePending = 0
	end)
	PlayerData.addMoney(player, amount, "offline")
	Net.pushAll("MoneyPop", player.UserId, amount)
	removePile(player)
end

function MoneyPile.init()
	PlayerData.onLoaded(refresh)
	PlayerData.onChanged(refresh)
	local function watch(player)
		player:GetAttributeChangedSignal("Base"):Connect(function()
			refresh(player, PlayerData.get(player))
		end)
	end
	Players.PlayerAdded:Connect(watch)
	for _, player in ipairs(Players:GetPlayers()) do
		watch(player)
	end
	Players.PlayerRemoving:Connect(removePile)
	local since, sinceSweep = 0, 0
	RunService.Heartbeat:Connect(ServerMeter.wrap("MoneyPile", function(dt)
		since += dt
		sinceSweep += dt
		if since < CHECK_EVERY then
			return
		end
		since = 0
		for player, p in pairs(piles) do
			local profile = PlayerData.get(player)
			local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
			if not profile or (profile.OfflinePending or 0) <= 0 or not p.model.Parent then
				removePile(player) -- (nothing waits any more: no pile)
			elseif root and Vector3.new(root.Position.X - p.center.X, 0, root.Position.Z - p.center.Z).Magnitude <= p.reach
				and math.abs(root.Position.Y - p.center.Y) < PICK_HEIGHT then
				collect(player)
			end
		end
		if sinceSweep >= SWEEP_EVERY then -- stray piles: not the pile of anyone now
			sinceSweep = 0
			local current = {}
			for _, p in pairs(piles) do
				current[p.model] = true
			end
			for index = 1, Config.Map.BaseCount do
				local folder = Bases.folder(index)
				for _, child in ipairs(folder and folder:GetChildren() or {}) do
					if child.Name == "MoneyPile" and child:IsA("Model") and not current[child] then
						child:Destroy()
					end
				end
			end
		end
	end))
end

return MoneyPile
