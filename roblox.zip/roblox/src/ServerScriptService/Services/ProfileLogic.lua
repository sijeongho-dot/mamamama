--[[
ProfileLogic: the rules of a saved profile, without any Roblox service, so they can be tested
outside Studio (tools/tests/profile_logic_test.lua).

A profile is one player's save. The DataStore key also holds a session lock:
	Lock = { Id = <server session id>, Time = <os.time() of the last save> }
Only the server holding the lock writes the profile. A lock older than Config.Data.SessionLockTimeout
belongs to a server that crashed and may be taken over.

Everything takes Config as an argument; nothing here reads a service or the clock itself.
]]

local ProfileLogic = {}

-- a fresh profile for a new player
function ProfileLogic.new(config)
	return {
		Version = config.Data.Version,
		Money = config.Data.StartMoney,
		Keys = config.Data.StartKeys, -- keys already brought home (carried keys are not saved)
		SpecialKeys = { Silver = 0, Gold = 0, Ruby = 0, Diamond = 0, Rainbow = 0 }, -- better key grades brought home (Config.Keys.Types)
		DefenseLevel = 1,
		PromotionRetryAt = 0, -- os.time() after a failed promotion fight before the next try
		-- (2026-10-05) the last lost promotion fight's weakest point, kept until a level is won (Defense, the 🩺 board):
		-- { Level, Tries, Kind, Icon, Head, Body } (Korean words), {} when none
		PromoAdvice = {},
		PromoKills = 0,
		Rebirths = 0,
		Training = {}, -- (2026-10-04) seconds trained toward each track's next level (Training service)
		TrainBoostUntil = 0,
		TrainGear = {}, -- (2026-10-04) [station Id] = 🔧 gear level (Training)
		LaunchGiftAt = 0, -- (2026-10-04) os.time() the launch gift dino was given (LaunchGift), 0 = not yet
		LaunchGiftShown = false, -- its celebration window has been shown (or sent to the tutorial field to show)
		-- (2026-10-04, "본게임에서 광질 조금 하다 가던데") seconds played in all (RewardLogic.addPlayed): the 🐣 rookie mining
		-- buff while under Config.Mining.Rookie.Minutes; and the first-play funnel's steps already logged (Analytics)
		PlaySeconds = 0,
		FirstPlay = { Steps = {}, Funnel = config.Analytics.FirstPlay.Name },
		FreeDraw = false, -- (2026-10-04) the first free draw given or not needed (Config.StarterMissions.FirstDraw; Rewards)
		Graduated = false,
		IslandShown = false,
		Upgrades = {
			PickaxeTier = 1,
			PickaxePower = 0, -- power steps of the current tier
			PickaxeSpeed = 0, -- the speed track, all tiers
			Bag = 1,
			Slap = 1,
			MoveSpeed = 0,
			Slots = 0, -- placement slots bought (Config.Placement.SlotUpgrade)
			FarmSlots = 0, -- farm slots bought at the farm sign (Config.Farm.SlotUpgrade)
		},
		Carry = {}, -- minerals in the bag: { ["Grade/Size"] = count } (kept when hit, emptied by depositing)
		FoundKeys = 0, -- keys found in minerals, riding in the bag until the deposit bin (Config.Mining.KeyChancePercent)
		Units = {}, -- collected dinos: { Id, Species, Rarity, Size, Mutation }
		Placed = {}, -- dinos on the defense platform: { [unit Id] = { X, Z } } in the arena's flat coordinates
		DefenseMap = config.Defense.Maps[1].Id, -- (2026-10-06) the defense map played (Config.Defense.Maps)
		MapLayout = 0, -- the Config.Defense.LayoutVersion the saved layouts were made for (older: laid out again)
		Targeting = {}, -- (2026-10-06) 🎯 a placed dino's target mode when not Auto: { [unit Id] = "First" | "Strong" | ... }
		MapWins = {},
		MapPlacements = {}, -- the other maps' layouts, kept while away: { [map Id] = { [unit Id] = { X, Z } } }
		Settings = { -- what this player's screen hides (less lag): the dinos and fossils on their own track and others'
			HideMyDinos = false, HideMyFossils = false, HideOtherDinos = false, HideOtherFossils = false,
		MuteMusic = false, -- the background music (Music): on (before 2026-10-01; now MusicVolume)
		MusicVolume = 0.6, MasterVolume = 1, -- 0 to 1: the 보기 설정 sound bars (the music; every sound)
		-- (2026-10-02, "배경음이 80이 아니라 60이 기본이고 지금 볼륨 그대로, 100 되면 더 커지게"; was 80%) the
		-- music bar's 60% plays the songs as loud as 100% did at first (StarterPlayerScripts/Music): new saves
		-- start at 60%, and an old save's bar is moved once (ProfileLogic.migrate) so it sounds the same.
		-- MusicScale: the bar's "as before" point the save is on (nil: 100%, the first one)
		MusicScale = 0.6,
		HideMineralNames = true, -- the names over the minerals start off (switch them on in 보기 설정)
		HideWildlife = false, HideAuras = false, HideReach = false, HideWeather = false, -- for weak phones (보기 설정)
		HideMyFarm = false, HideOtherFarm = false, -- the farm pens' dinos (HideMyDinos / HideOtherDinos: the platforms')
		HideFarmLabels = false, -- (2026-10-01) the "💰 돈 +0.4%" over every farm dino
		AutoMineOff = false, -- (2026-10-02) the ⛏️ auto mining pass on (its button switches it) ...
		AutoNoMinerals = false, AutoFruit = false, -- ... mining minerals, not fruit (the button's modes: AutoMine)
		},
		Mount = "", -- the species this player rides (Ride service); "" = Config.Ride.DefaultSpecies
		MountRarity = "", -- the rarity of it chosen for its aura (Ride service); "" = the best one owned
		MountSize = "",
		-- bombs held (Bombs service); (2026-10-04, "처음 시작하면 똥폭탄이랑 일반 폭탄 3개씩 줘 인벤에 있어야 써보고 사지")
		-- a new player starts with Config.Bombs.StarterCount of each ("게임 처음 시작하면 이야 폭탄 지급은": new players only)
		Bombs = { Egg = config.Bombs.StarterCount, Poop = config.Bombs.StarterCount },
		PityCount = 0, -- (2026-10-02) draws in a row below Config.Gacha.Pity.Rarity (뽑기 천장, Formulas.applyPity)
		Fruit = 0, -- (2026-10-02) 🍎 food from the trees' fruit, for growing dinos (Fruits service, Config.Fruit)
		-- Robux (Monetization service): receipts already granted (PurchaseId -> os.time, the last few), the
		-- products bought (counts), whether a first purchase happened, the offers shown, the passes owned
		Purchases = { Receipts = {}, Bought = {}, FirstDone = false, Offers = {} },
		Passes = {},
		SpeedUntil = 0, -- os.time() the speed potion lasts until
		MoneyBoostUntil = 0, -- os.time() the 1-hour money ×2 lasts until (Monetization)
		CommunityClaimed = false, -- the community (group) reward taken (Community service)
		Hints = {}, -- [tip Id] = true: Coco's tips already shown (Config.Hints; Tutorial service)
		SeenKinds = {},
		FreeReviveUsed = false,
		Farm = {}, -- dinos registered on the farm: { [unit Id] = true } (not placeable while there)
		FarmLock = {},
		Collection = {}, -- species × rarity ever owned: { ["TRex/Common"] = true }
		Skins = {}, -- slap skins unlocked: { [skin Id] = true } (Config.Slap.Skins)
		SlapSkin = "", -- the slap skin worn (a skin Id); "" = the slap level's own look
		-- the tutorial (2026-10-01, Tutorial service, TutorialLogic): the step index, progress in it, done,
		-- and whether this run is a replay from 설정 (help off); (2026-10-02) Did: the steps finished (a replay's
		-- hands-on steps done before only show their card)
		Tutorial = { Step = 1, Count = 0, Done = false, Replay = false, Did = {} },
		-- the beginner mission board after it (StarterMissions service, StarterLogic): the mission index,
		-- the count of an event mission, done
		Starter = { Step = 1, Count = 0, Done = false },
		Ever = {},
		LuckUntil = 0, -- os.time() the draw luck boost lasts until (the 🍀 reward; the luck potion later)
		GuaranteedDraws = {}, -- { [rarity Id] = n }: draws whose first dino is at least that rarity (Gacha)
		NextUnitId = 1, -- new dinos get Id "U" .. NextUnitId (short, the save stays small)
		Boxes = {},
		NextBoxId = 1,
		BoxRush = 0,
		FreeSkips = config.Boxes.FreeSkips,
		Stats = { Joins = 0, FirstJoin = 0, LastJoin = 0, PlayTime = 0, Draws = 0,
			LastSeen = 0, -- os.time() last seen online (offline earnings, Rewards)
			IdleMoneyRate = 0 }, -- money a second the arena really made idle, lately (Defense; offline earnings)
		Daily = { Day = 0, Missions = {}, AllClaimed = false, -- today's missions (RewardLogic) ...
			Played = 0, Gifts = {} }, -- ... and today's play time (seconds) and playtime gifts taken ({ ["1"] = true })
		Weekly = { Week = 0, Keys = 0, Claimed = {}, Progress = {}, Steps = {} }, -- the weekly challenges (RewardLogic)
		-- (2026-10-02) ♾️ 무한 도전 (RewardLogic): this week's best waves and milestones taken, the best ever, last
		-- week's best (its rank reward) and the last week whose rank was paid
		Challenge = { Week = 0, Best = 0, AllBest = 0, Claimed = {}, LastWeek = 0, LastBest = 0, RankPaid = 0 },
		-- (2026-10-02) the collection milestones and rarity rows already paid ({ ["360"] = true }, { ["Legendary:10"] = true })
		CollectionPaid = { Milestones = {}, Rows = {} },
		DexKing = false,
		StorySeen = {},
		-- (2026-10-02) attendance (RewardLogic.checkIn): the last day checked in, the streak day (1-7) and whether
		-- today's was taken; this month (year × 100 + month), its days and the milestones taken ({ ["7"] = true })
		-- (2026-10-02, the calendar) MonthLog: the dates of this month checked in ({ ["5"] = true })
		Attendance = { Day = 0, Streak = 0, StreakClaimed = true, Month = 0, MonthDays = 0, MonthClaimed = {}, MonthLog = {} },
		-- (2026-10-02) friends played with today (RewardLogic.friendBonus): { ["UserId"] = true }
		FriendBonus = { Day = 0, Paid = {} },
		Help = { Day = 0, Count = 0 },
		Bounty = { Day = 0, Money = 0, LastMoney = 0 },
		HideSeek = { Wins = 0, Losses = 0 }, -- (2026-10-03) 🙈 hide-and-seek games won and lost (HideSeek service)
		-- (2026-10-04) 🏆 랭킹전 (RewardLogic.rankedWin): this week's counted wins of each game (Config.Ranked.Games), the
		-- rivals beaten this week ({ ["H12345"] = wins counted against them }), the last week played and its wins (its
		-- rank reward), and the last week whose rank was paid, each game
		-- (2026-10-04, the night boss's ③) "Boss": this week's 🧟 bosses helped down (RewardLogic.rankedAdd), no rivals
		Ranked = { Week = 0, Hide = 0, Race = 0, Boss = 0, Rivals = {}, LastWeek = 0, LastHide = 0, LastRace = 0, LastBoss = 0,
			PaidHide = 0, PaidRace = 0, PaidBoss = 0, StakeDay = 0, StakeGames = 0 },
		-- (2026-10-04, the night boss's ②③; Zombies service) the night bosses helped slap down, ever (the hunt titles,
		-- Config.Zombies.Boss.HuntTitles), and the 🦴 bones of each boss kind toward its zombie dino
		BossHunt = { Hunts = 0, Bones = { Rex = 0, Trike = 0, Ptera = 0 } },
		-- (2026-10-04) 🎉 the launch event (RewardLogic, Config.LaunchEvent): its Id, each mission's progress and reward
		-- taken ({ ["3"] = n }, { ["3"] = true }), the all-done reward taken; the events whose title was had ({ Launch1 = true })
		Event = { Id = "", Progress = {}, Claimed = {}, AllClaimed = false },
		EventTitles = {},
		Race = { Wins = 0, Losses = 0, SkyWins = 0, SkyLosses = 0, -- dino races won and lost: the road race, the sky race (Race service)
			BestRoad = 0, BestSky = 0, TrialRoad = 0,
			Medals = { Road = 0, Sky = 0 } }, -- (2026-10-02) the best time of a race won over the line, seconds (0 = none yet)
		-- (2026-10-02, the beta tools; BetaLog service) the update news last seen (Config.Beta.News.Version) and
		-- today's bug reports (the day, how many, os.time() of the last)
		NewsSeen = "",
		-- (2026-10-02) the season pass (SeasonLogic): this season, its XP, the tiers taken on each track ({ ["3"] = true }),
		-- its pass bought, today's minutes of play counted for XP
		Season = { Id = 0, Xp = 0, Free = {}, Paid = {}, Premium = false, PlayDay = 0, PlayMinutes = 0 },
		BugReports = { Day = 0, Count = 0, Last = 0 },
		Survey = { Asked = 0, Vote = 0 },
		LikeAsk = { Count = 0, At = 0, Fav = false },
		OfflinePending = 0, -- money earned while away, waiting as a pile in the arena (MoneyPile service) -- bounty money taken: today (Day, Money) and when (os.time)
		Comeback = { Days = 0, Last = 0, Count = 0 },
		Unlocks = { Open = {} },
	}
end

local MUSIC_SCALE = 0.6 -- the music bar's "as loud as at first" point (StarterPlayerScripts/Music BAR_NORMAL)

local function copy(value)
	if type(value) ~= "table" then
		return value
	end
	local out = {}
	for k, v in pairs(value) do
		out[k] = copy(v)
	end
	return out
end
ProfileLogic.copy = copy

-- fill anything missing from defaults (keys added to the save format later), keep everything else
local function reconcile(profile, defaults)
	for k, v in pairs(defaults) do
		if profile[k] == nil then
			profile[k] = copy(v)
		elseif type(v) == "table" and type(profile[k]) == "table" and next(v) ~= nil then
			reconcile(profile[k], v)
		end
	end
	return profile
end

-- bring an old save up to the current format. Add a step here whenever Config.Data.Version goes up.
local OLD_LEVELS_PER_TIER = 100 -- (version 1 saves: every tier, the first too, was 100 levels)
local MIGRATIONS = {
	-- [2] = function(profile) ... end, -- turns a version 1 profile into version 2
	-- (2026-10-01, the short first tier) a reborn save keeps the level it shows: an old 🟢LV 12 (real
	-- LV 112) is 🟢LV 12 again (real LV 42). Saves that never reborn are cut to the first tier's top below
	[2] = function(profile, config)
		local rebirths = profile.Rebirths or 0
		if rebirths > 0 and type(profile.DefenseLevel) == "number" then
			local r = config.Rebirth
			local shown = math.max(1, profile.DefenseLevel - rebirths * OLD_LEVELS_PER_TIER)
			profile.DefenseLevel = r.FirstTierLevels + (rebirths - 1) * r.LevelsPerTier + shown
		end
	end,
	[3] = function(profile)
		local open = type(profile.Unlocks) == "table" and profile.Unlocks.Open
		local rooms = type(open) == "table" and open.GameRooms
		if type(rooms) == "table" and type(rooms.Step) == "number" and rooms.Step >= 2 then
			rooms.Step += 2
			rooms.Count = 0
		end
	end,
	[4] = function(profile)
		local open = type(profile.Unlocks) == "table" and profile.Unlocks.Open
		local rooms = type(open) == "table" and open.GameRooms
		if type(rooms) == "table" and type(rooms.Step) == "number" and rooms.Step >= 2 then
			rooms.Step += 1
			rooms.Count = 0
		end
	end,
}

function ProfileLogic.migrate(profile, config)
	profile.Version = profile.Version or 1
	while profile.Version < config.Data.Version do
		local step = MIGRATIONS[profile.Version + 1]
		if step then
			step(profile, config)
		end
		profile.Version += 1
	end
	-- (2026-10-01) a save from before the tutorial: its player knows the game already (reconcile below
	-- would otherwise give it a new player's tutorial)
	if type(profile.Tutorial) ~= "table" then
		profile.Tutorial = { Step = 0, Count = 0, Done = true, Replay = false }
		if type(profile.Starter) ~= "table" then -- nor the beginner missions
			profile.Starter = { Step = 0, Count = 0, Done = true }
		end
	end
	-- (2026-10-02) the music bar's new scale (see ProfileLogic.new): an old save's bar moved once from its
	-- scale (nil = 1, or 0.8) to 0.6, so the music sounds the same
	local settings = profile.Settings
	if type(settings) == "table" and settings.MusicScale ~= MUSIC_SCALE then
		local from = type(settings.MusicScale) == "number" and settings.MusicScale > 0 and settings.MusicScale or 1
		if type(settings.MusicVolume) == "number" then
			settings.MusicVolume = math.clamp(math.floor(settings.MusicVolume * MUSIC_SCALE / from / 0.05 + 0.5) * 0.05, 0, 1)
		end
		settings.MusicScale = MUSIC_SCALE
	end
	-- (2026-10-04) a save from before play time was counted has played already: no 🐣 rookie buff, no first-play funnel
	if profile.PlaySeconds == nil then
		profile.PlaySeconds = config.Mining.Rookie.Minutes * 60
		profile.FirstPlay = { Steps = {}, Done = true }
		profile.FreeDraw = true -- (and no first free draw)
	end
	if type(profile.FirstPlay) == "table" and profile.FirstPlay.Funnel == nil then
		profile.FirstPlay.Funnel = "FirstPlay"
	end
	if type(profile.Unlocks) ~= "table" then
		profile.Unlocks = {}
	end
	if profile.Graduated == nil then
		local open = type(profile.Unlocks.Open) == "table" and profile.Unlocks.Open or {}
		profile.Graduated = profile.Stash == nil and ((profile.Rebirths or 0) > 0 or open.GameRooms == true)
		profile.IslandShown = profile.Graduated
	end
	if type(profile.Ever) ~= "table" then
		profile.Ever = {}
		local twists = config.Defense.Twists
		if (profile.Rebirths or 0) > 0 or (twists and (profile.DefenseLevel or 1) >= twists.FromLevel) then
			profile.Ever.TwistWin = 1
		end
	end
	profile.Unlocks.All = nil
	profile.Unlocks.Seen = nil
	if type(profile.Unlocks.Open) ~= "table" then
		profile.Unlocks.Open = {}
	end

	for id, o in pairs(profile.Unlocks.Open) do
		local steps = nil
		for _, u in ipairs(config.Unlocks) do
			if u.Id == id then
				steps = u.Steps
			end
		end
		if steps and #steps > 0 and type(o) == "table" and type(o.Step) == "number" and o.Step > #steps then
			profile.Unlocks.Open[id] = true
		elseif not steps or not (o == true or (type(o) == "table" and type(o.Step) == "number" and steps[o.Step] ~= nil)) then
			profile.Unlocks.Open[id] = nil
		elseif type(o) == "table" and type(o.Count) ~= "number" then
			o.Count = 0
		end
	end
	profile = reconcile(profile, ProfileLogic.new(config))
	-- (2026-10-01) every rebirth opens a level tier: a profile reborn under an old rule starts its tier at
	-- LV 1, like a new rebirth, and stays inside it (the first tier is FirstTierLevels long since 2026-10-01)
	local r = config.Rebirth
	local function start(t)
		return t <= 0 and 1 or r.FirstTierLevels + (t - 1) * r.LevelsPerTier + 1
	end
	profile.DefenseLevel = math.clamp(profile.DefenseLevel, start(profile.Rebirths), start(profile.Rebirths + 1) - 1)
	return profile
end

local CARRIED = { "Settings", "NewsSeen", "BugReports", "Survey", "LikeAsk", "Passes", "Purchases", "FirstPlay" }

function ProfileLogic.veteran(profile)
	return (profile.Rebirths or 0) > 0 or (profile.DefenseLevel or 1) > 1
end

function ProfileLogic.pastTutorial(profile, config)
	return profile.Graduated == true or (profile.Rebirths or 0) > 0
		or (profile.DefenseLevel or 1) > config.StarterMissions.TutorialLevel
end

local function startOver(old, config)
	local kept = copy(old)
	kept.Stash, kept.Lock, kept.DevReplay, kept.DevWipe, kept.Welcome, kept.FreshStart = nil, nil, nil, nil, nil, nil
	local profile = ProfileLogic.new(config)
	for _, key in ipairs(CARRIED) do
		if kept[key] ~= nil then
			profile[key] = copy(kept[key])
		end
	end
	if type(kept.Tutorial) == "table" then
		profile.Tutorial = copy(kept.Tutorial)
	end
	profile.Tutorial.Done = true
	profile.Tutorial.IntroSeen = nil
	profile.Tutorial.ReplayAt, profile.Tutorial.ReplayPart, profile.Tutorial.ReplayCore = 0, nil, nil
	profile.Starter.Order = config.StarterMissions.Order
	profile.StarterReplay = config.Developers.StarterReplay
	profile.Onboard = 1
	return profile, kept
end

function ProfileLogic.stash(old, config)
	local profile, kept = startOver(old, config)
	profile.LaunchGiftAt = kept.LaunchGiftAt or profile.LaunchGiftAt
	profile.LaunchGiftShown = kept.LaunchGiftShown or profile.LaunchGiftShown
	profile.Welcome = "Hello"
	profile.Stash = kept
	return profile
end

function ProfileLogic.restart(old, config)
	local profile = startOver(old, config)
	profile.Welcome = "Fresh"
	return profile
end

function ProfileLogic.settle(profile)
	profile.Stash, profile.FreshStart = nil, nil
	profile.IslandShown = profile.IslandShown or profile.Graduated == true
	profile.Welcome = "Kept"
	return profile
end

function ProfileLogic.skipPractice(old, practice)
	local stats = type(practice.Stats) == "table" and practice.Stats or {}
	local seen, started = stats.LastSeen or 0, stats.FirstJoin or 0
	local last = type(old.Stats) == "table" and old.Stats.LastSeen or 0
	if seen > 0 and started > 0 and last > 0 then
		old.Stats.LastSeen = seen - math.max(0, started - last)
	end
end

function ProfileLogic.restore(profile, config)
	local old = ProfileLogic.migrate(copy(profile.Stash), config)
	for _, key in ipairs(CARRIED) do
		if profile[key] ~= nil then
			old[key] = copy(profile[key])
		end
	end
	if type(profile.Stats) == "table" and type(profile.Stats.PlayTime) == "number" then
		old.Stats.PlayTime += profile.Stats.PlayTime
	end
	ProfileLogic.skipPractice(old, profile)
	for _, u in ipairs(config.Unlocks) do
		old.Unlocks.Open[u.Id] = true
	end
	old.Graduated = true
	old.IslandShown = true
	old.StarterReplay = math.max(old.StarterReplay or 0, config.Developers.StarterReplay)
	old.Stash, old.FreshStart, old.DevReplay, old.DevWipe = nil, nil, nil, nil
	old.Onboard = 1
	old.Welcome = "Back"
	return old
end

local function lockedByOther(stored, sessionId, now, config)
	local lock = stored and stored.Lock
	return lock ~= nil and lock.Id ~= sessionId and now - lock.Time < config.Data.SessionLockTimeout
end

--[[
The UpdateAsync transform for loading: take the lock and return the profile to use.
Returns newStored, result where result is
	{ status = "ok", profile = <profile> }   the lock is ours, write newStored
	{ status = "locked", lock = <lock> }     another live server holds it, write nothing (newStored nil)
]]
function ProfileLogic.claim(stored, sessionId, now, config)
	if lockedByOther(stored, sessionId, now, config) then
		return nil, { status = "locked", lock = stored.Lock }
	end
	local profile = stored and copy(stored) or ProfileLogic.new(config)
	profile.Lock = nil
	profile = ProfileLogic.migrate(profile, config)
	local newStored = copy(profile)
	newStored.Lock = { Id = sessionId, Time = now }
	return newStored, { status = "ok", profile = profile }
end

--[[
The UpdateAsync transform for saving. Writes profile (with the lock refreshed, or released when
release is true) only while this session holds the lock; if another server took it over (this one
stalled past the timeout), returns nil so nothing is overwritten.
]]
function ProfileLogic.save(stored, profile, sessionId, now, release, config)
	local lock = stored and stored.Lock
	if lock and lock.Id ~= sessionId then
		return nil
	end
	local newStored = copy(profile)
	newStored.Lock = (not release) and { Id = sessionId, Time = now } or nil
	return newStored
end

-- a short, safe view of the profile for the player's own client
-- everything the player owns, for the inventory window (StarterPlayerScripts/Inventory): a copy
function ProfileLogic.inventory(profile)
	return {
		Money = profile.Money,
		Keys = profile.Keys,
		SpecialKeys = copy(profile.SpecialKeys),
		Carry = copy(profile.Carry),
		Upgrades = copy(profile.Upgrades),
		DefenseLevel = profile.DefenseLevel,
		Rebirths = profile.Rebirths,
		Units = copy(profile.Units),
		Placed = copy(profile.Placed),
		Farm = copy(profile.Farm),
		Mount = profile.Mount,
		Skins = copy(profile.Skins),
		SlapSkin = profile.SlapSkin,
		Collected = (function()
			local n = 0
			for _ in pairs(profile.Collection) do
				n += 1
			end
			return n
		end)(),
	}
end

function ProfileLogic.summary(profile)
	return {
		Money = profile.Money,
		Keys = profile.Keys,
		DefenseLevel = profile.DefenseLevel,
		Rebirths = profile.Rebirths,
		Upgrades = copy(profile.Upgrades),
		UnitCount = #profile.Units,
	}
end

return ProfileLogic
