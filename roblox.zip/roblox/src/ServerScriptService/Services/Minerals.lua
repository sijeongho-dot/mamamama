--[[
Minerals: mineral nodes on the mineral ring and mining them (design 2.3 자원 채취).

Nodes
- Up to Config.Minerals.MaxOnServer nodes stand on the OreSpawns points MapBuilder made
  (Workspace.Map.OreSpawns), never overlapping (Config.Minerals.Gap). A mined-out node comes back
  Config.Minerals.RespawnDelay seconds later on a free point within NearRespawnRadius of it if there is
  one (else anywhere); every RespawnDelay seconds one more is tried while there are fewer than MaxOnServer
  (a node that found no free point comes later). A node nobody is mining goes after its Lifetime (a
  random time in the range; 2026-10-01) and a new one is rolled somewhere, so the ring keeps changing.
  Never while someone mines it (2026-10-01, "미네랄 수집중엔 안 사라지게"): it waits past its time; once
  the mining stops (finished, walked off, slapped away, stopped), a node past its time may go.
- Grade and size are rolled separately (Formulas.rollGrade / rollSize). Every node also gets its own
  scale in [RandomScaleMin, RandomScaleMax]: it is that much bigger and holds that many more turns
  (Formulas.nodeTurns). It shows ModelHeight × DisplayScale × scale tall, using the size's model from
  ServerStorage.Assets (Ore_Shard, ...) or a grey box in the grade's color.
- The crystal part of the model (Ore_<size>_Crystal, white in the FBX) takes the grade's color;
  starlight's crystals are marked (attribute Crystal) and change color on the clients (MiningFx).
- Aura by grade and size: aura level = (grade number − 1) + (size number − 1), 0 to 8. From level
  1 sparkles, from 2 a glow light, from 4 a shimmering shell; bigger and brighter with the level.
  Its colors go from the grade's color to the size's color (AURA_SIZE_COLORS).
- Each node's name label is in its grade's color. (Jackpots that appear during play were announced to
  everyone until 2026-10-04.)

Mining (all decided here; the client only taps and draws)
- Tapping a node starts mining it; the "⛏ 그만" button (Net request Mine again) stops. Tapping the
  node itself again does not stop it (2026-10-01: a tap on the crystal while mining stopped it by
  accident, and a node past its time then went). Mining goes in turns: each turn lasts
  Formulas.mineSeconds (hardness vs. the pickaxe: a weak pickaxe on a hard grade takes very long),
  the character swings and a loading bar fills (clients draw both from the player attributes
  Mining, MineStart, MineDuration), then the turn's minerals go into the bag. Turns repeat
  until the node is empty, the bag is full, the player walks off (Config.Mining.Range) or stops.
  A turn cut short (walked off, slapped away, stunned, stopped) is kept for that player on that node
  (up to MAX_KEPT_PROGRESS): mining it again carries on from there, the loading bar included.
  A turn yields Formulas.yieldPerTurn (the tier's Yield × the node size's YieldMultiplier). Rain and storms (Weather) double the yield and the turn speed.
- (2026-10-04, "본게임에서 광질 조금 하다 가던데") a node too hard for the player's pickaxe (a turn over
  Config.Mining.LockSeconds, Formulas.mineLocked) is not started: Net push MineLocked (the client says "🔒 … n티어
  곡괭이부터", shows the lock on the button and points at one it can mine, MiningFx). A new player's first minutes (🐣 Config.Mining.Rookie, by the
  saved play time) mine faster. Every finished turn tells the miner what went into the bag and what it will pay
  (Net push Mined: the "+1 💧 💰+32" over their head).
- Each mineral may hold a key (Formulas.mineKeys: its value × Config.Mining.KeyFindShare ÷ the shop key
  price at the player's level): found keys
  ride in the bag (profile FoundKeys, player attribute FoundKeys) until the deposit bin banks them.
- The pickaxe of the player's tier is held in the right hand: Pickaxe_T<tier> from Assets or a grey box.
- The bag of the player's level is worn on the back (Config.Bag.Looks, a new look every 5 levels).
- Player attributes for the HUD: BagCount, BagCapacity, PickaxeTier, PickaxePower, PickaxeSpeed, BagLevel.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Weather = require(script.Parent:WaitForChild("Weather"))
local DayNight = require(script.Parent:WaitForChild("DayNight"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))
-- the daily missions' kinds: "RareMine" counts minerals of this grade and up (3: 포도석), "BigMineral" these sizes emptied
local RARE_MINE_GRADE = 3
local BIG_SIZES = { Boulder = true, Vein = true }

local Minerals = {}

local rng = Random.new()
local nodesFolder = nil
local spawnPoints = {} -- list of BaseParts
local nodes = {} -- [model] = { grade, size, turnsLeft, turns, point, radius, miners = { [player] = true } }
local usedPoints = {} -- [point] = model
local gradeCounts = {} -- [gradeId] = nodes on the server
local mining = {} -- [player] = model being mined
local turns = {} -- [player] = { model, started (os.clock), duration } of the turn under way
local heldTier = {} -- [player] = tier of the pickaxe in the hand
local rookieTold = {} -- [player] = true once the 🐣 rookie buff was told this session (its first mining)
local wornBag = {} -- [player] = the bag model's name on the back

-- display-only sizes (not game values)
local LABEL_HEIGHT = 2
local TREASURE_MARK_SIZE = UDim2.fromScale(12, 3.1)
local TREASURE_MARK_UP = 4
local TREASURE_MARK_DISTANCE = 2000
local TREASURE_TRIES = 40
local TREASURE_RETRY = 10
local TREASURE_MARK_TEXT = "💰 특급석"
local TREASURE_COMING = "💰 특급석 등장! 한 사람당 가방 한 번만큼"
local TREASURE_KEY_TEXT = "🔑 특급석 속에 %s! 바로 내 거예요"
local TREASURE_KEY_ALL = "💰 %s님이 특급석에서 %s를 찾았어요!"
local TREASURE_ONCE = "💰 이번 특급석은 다 캤어요! 🎒 가방을 키우면 다음엔 더 많이"
local TREASURE_DONE = "💰 특급석 %d개 다 챙겼어요! 🎒 가방을 키우면 다음엔 더 많이"
local TREASURE_SMALL = "🎒 특급석 1개 = 🎒%d칸 · 💰%s원! 가방이 작아요 · 가방을 키우면 캘 수 있어요"
local TREASURE_FULL = "🎒 가방 자리 부족! 특급석 1개 = 🎒%d칸 · 💰%s원"
local treasureAt = math.huge
local MAX_KEPT_PROGRESS = 0.95 -- a kept half-done turn still needs a moment when mining starts again
local GREY_PICKAXE = { handle = Vector3.new(0.3, 3.2, 0.3), head = Vector3.new(2.2, 0.45, 0.45) }
local HAND_GRIP = CFrame.new(0, -0.2, 0) * CFrame.Angles(-math.pi / 2, 0, 0) -- pickaxe's up axis points forward
local BAG_RAISE = 0.15 -- studs: the bag's back face a little above the torso's middle
local AURA_SIZE_COLORS = { -- the aura fades from the grade's color to this, by size
	Shard = nil, -- the grade's color only
	Chunk = Color3.fromRGB(255, 255, 255),
	Boulder = Color3.fromRGB(255, 205, 80),
	Vein = Color3.fromRGB(255, 110, 220),
}
local RAINBOW = ColorSequence.new({ -- starlight
	ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 90, 90)), ColorSequenceKeypoint.new(0.25, Color3.fromRGB(255, 220, 80)),
	ColorSequenceKeypoint.new(0.5, Color3.fromRGB(90, 230, 120)), ColorSequenceKeypoint.new(0.75, Color3.fromRGB(80, 160, 255)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(200, 100, 255)),
})
local AURA = {
	SparkleFrom = 1, LightFrom = 2, ShellFrom = 4, -- aura levels
	Rate = 3, RatePerLevel = 3, -- sparkles per second
	SparkleSize = 0.35, SparkleSizePerLevel = 0.08,
	LightRange = 6, LightRangePerLevel = 2.5, LightBrightness = 0.6, LightBrightnessPerLevel = 0.25,
	ShellScale = 1.25, ShellTransparency = 0.55,
}

local function assets()
	return ServerStorage:FindFirstChild("Assets")
end

-- ---------------------------------------------------------------------------
-- Bag status for the HUD
-- ---------------------------------------------------------------------------

local function doubleBag(player)
	local profile = PlayerData.get(player)
	return profile ~= nil and profile.Passes ~= nil and profile.Passes.DoubleBag == true -- (Monetization)
end

local equipPickaxe -- defined below
local wearBag -- defined below

local function refreshBag(player, profile)
	profile = profile or PlayerData.get(player)
	if not profile then
		return
	end
	local count = Formulas.carryCount(profile.Carry)
	local capacity = Formulas.bagCapacity(Formulas.trained(profile.Upgrades, profile.Training).Bag, doubleBag(player))
	player:SetAttribute("BagCount", count)
	player:SetAttribute("BagCapacity", capacity)
	player:SetAttribute("FoundKeys", profile.FoundKeys or 0) -- keys found in minerals, in the bag
	player:SetAttribute("BagLevel", profile.Upgrades.Bag)
	player:SetAttribute("PickaxeTier", profile.Upgrades.PickaxeTier)
	player:SetAttribute("PickaxePower", profile.Upgrades.PickaxePower)
	player:SetAttribute("PickaxeSpeed", profile.Upgrades.PickaxeSpeed)
	if heldTier[player] ~= profile.Upgrades.PickaxeTier then
		equipPickaxe(player)
	end
	wearBag(player, profile.Upgrades.Bag)
	local head = player.Character and player.Character:FindFirstChild("Head")
	local sign = head and head:FindFirstChild("BagFull")
	if head and count >= capacity and not sign then
		sign = Instance.new("BillboardGui")
		sign.Name = "BagFull"
		sign.Size = UDim2.fromOffset(160, 40)
		sign.StudsOffsetWorldSpace = Vector3.new(0, 2.5, 0)
		sign.AlwaysOnTop = true
		local label = Instance.new("TextLabel")
		label.Size = UDim2.fromScale(1, 1)
		label.BackgroundTransparency = 1
		label.Text = "가방 가득!"
		label.TextScaled = true
		label.Font = Enum.Font.FredokaOne
		label.TextColor3 = Color3.fromRGB(255, 90, 70)
		label.TextStrokeTransparency = 0.3
		label.Parent = sign
		sign.Parent = head
	elseif sign and count < capacity then
		sign:Destroy()
	end
end
Minerals.refreshBag = refreshBag

-- ---------------------------------------------------------------------------
-- The pickaxe in the hand (seen by everyone)
-- ---------------------------------------------------------------------------

local function greyPickaxe()
	local model = Instance.new("Model")
	local handle = Instance.new("Part")
	handle.Name = "Handle"
	handle.Size = GREY_PICKAXE.handle
	handle.Color = Color3.fromRGB(140, 95, 55)
	handle.Parent = model
	local head = Instance.new("Part")
	head.Name = "Head"
	head.Size = GREY_PICKAXE.head
	head.Color = Color3.fromRGB(150, 150, 160)
	head.CFrame = handle.CFrame * CFrame.new(0, GREY_PICKAXE.handle.Y / 2, 0)
	head.Parent = model
	model.WorldPivot = handle.CFrame * CFrame.new(0, -GREY_PICKAXE.handle.Y / 2 + 0.4, 0) -- grip near the bottom
	return model
end

equipPickaxe = function(player)
	local profile = PlayerData.get(player)
	local character = player.Character
	local hand = character and (character:FindFirstChild("RightHand") or character:FindFirstChild("Right Arm"))
	if not profile or not hand then
		return
	end
	local old = character:FindFirstChild("HeldPickaxe")
	if old then
		old:Destroy()
	end
	local tier = profile.Upgrades.PickaxeTier
	local source = assets() and assets():FindFirstChild(Config.Pickaxe.ModelPrefix .. tier, true)
	local model
	if source then
		model = Instance.new("Model")
		source:Clone().Parent = model
		-- the importer keeps the Blender origin (the grip) as the pivot of the mesh
		model.WorldPivot = source:GetPivot()
	else
		model = greyPickaxe()
	end
	model.Name = "HeldPickaxe"
	model:PivotTo(hand.CFrame * HAND_GRIP)
	for _, part in ipairs(model:GetDescendants()) do
		if part:IsA("BasePart") then
			part.Anchored = false
			part.CanCollide = false
			part.CanQuery = false
			part.CanTouch = false
			part.Massless = true
			local weld = Instance.new("WeldConstraint")
			weld.Part0 = hand
			weld.Part1 = part
			weld.Parent = part
		end
	end
	model.Parent = character
	heldTier[player] = tier
end

-- the bag of the player's level on the back: Config.Bag.Looks, a new look every LevelsPerLook levels
-- (Bag_Cloth ... Bag_Dimension from Assets; none without the asset). The model's origin (its pivot)
-- is the middle of its flat back face; the bag's body sticks out from there, so the direction from
-- the origin to the body's middle is "out of the player's back", whatever way the model was imported.
wearBag = function(player, level)
	local character = player.Character
	local torso = character and (character:FindFirstChild("UpperTorso") or character:FindFirstChild("Torso"))
	local b = Config.Bag
	local look = b.Looks[math.min(#b.Looks, (level - 1) // b.LevelsPerLook + 1)]
	if not torso or wornBag[player] == look then
		return
	end
	local old = character:FindFirstChild("WornBag")
	if old then
		old:Destroy()
	end
	wornBag[player] = look
	local source = assets() and assets():FindFirstChild(look, true)
	if not source then
		return
	end
	local model = Instance.new("Model")
	model.Name = "WornBag"
	local copy = source:Clone()
	copy.Parent = model
	local face = copy:GetPivot().Position
	model.WorldPivot = CFrame.new(face)
	local box = model:GetBoundingBox()
	local out = Vector3.new(box.Position.X - face.X, 0, box.Position.Z - face.Z)
	out = out.Magnitude > 1e-3 and out.Unit or Vector3.new(0, 0, 1)
	model.WorldPivot = CFrame.lookAt(face, face - out) -- looking the way the player looks, body behind
	model:PivotTo(torso.CFrame * CFrame.new(0, BAG_RAISE, torso.Size.Z / 2))
	for _, part in ipairs(model:GetDescendants()) do
		if part:IsA("BasePart") then
			part.Anchored = false
			part.CanCollide = false
			part.CanQuery = false
			part.CanTouch = false
			part.Massless = true
			local weld = Instance.new("WeldConstraint")
			weld.Part0 = torso
			weld.Part1 = part
			weld.Parent = part
		end
	end
	model.Parent = character
end

-- ---------------------------------------------------------------------------
-- Nodes
-- ---------------------------------------------------------------------------

local function nodeLabel(model)
	local info = nodes[model]
	local gui = model:FindFirstChild("Info")
	if info and gui then
		gui.TextLabel.Text = info.grade == Config.Minerals.Special.Id and Formulas.grade(info.grade).Name .. " · ♾️"
			or string.format("%s %s · %d/%d", Formulas.grade(info.grade).Name, Formulas.size(info.size).Name,
				math.ceil(info.turnsLeft), info.turns)
	end
end

local function makeNodeModel(gradeId, sizeId, height)
	local grade, size = Formulas.grade(gradeId), Formulas.size(sizeId)
	local source = assets() and assets():FindFirstChild(size.Model, true)
	local model = Instance.new("Model")
	model.Name = "Mineral"
	if source then
		source:Clone().Parent = model
		local _, bounds = model:GetBoundingBox()
		model:ScaleTo(height / bounds.Y)
		-- the crystal takes the grade's color (the rock stays gray)
		local color = Color3.fromRGB(table.unpack(grade.Rgb))
		local crystals = {}
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") and string.find(d.Name, "Crystal") then
				table.insert(crystals, d)
			end
		end
		if #crystals == 0 then -- imported without part names: the near-white parts are the crystals
			for _, d in ipairs(model:GetDescendants()) do
				if d:IsA("BasePart") then
					local _, saturation, value = d.Color:ToHSV()
					if value > 0.8 and saturation < 0.15 then
						table.insert(crystals, d)
					end
				end
			end
		end
		for _, part in ipairs(crystals) do
			part.Color = color
			part:SetAttribute("Crystal", true)
		end
	else -- grey box: a block in the grade's color
		local part = Instance.new("Part")
		part.Name = "Rock"
		part.Size = Vector3.new(height * 0.9, height, height * 0.9)
		part.Color = Color3.fromRGB(table.unpack(grade.Rgb))
		part.Material = Enum.Material.SmoothPlastic
		part.Parent = model
	end
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored = true
		end
	end
	return model
end
Minerals.nodeModel = makeNodeModel -- (a mineral's model in its grade's color: also the MineralGuide boards)

local function place(model, point)
	local cf, bounds = model:GetBoundingBox()
	model.PrimaryPart = nil
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, bounds.Y / 2, 0))
	model:PivotTo(CFrame.new(point.Position) * CFrame.Angles(0, rng:NextNumber(0, 2 * math.pi), 0))
	return bounds
end

-- the name over a node, in its grade's color (starlight's cycles on the clients, MiningFx)
local function addLabel(model, bounds, gradeId)
	local gui = Instance.new("BillboardGui")
	gui.Name = "Info"
	gui.Size = UDim2.fromOffset(190, 28)
	gui.StudsOffsetWorldSpace = Vector3.new(0, bounds.Y / 2 + LABEL_HEIGHT, 0)
	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 0.4
	label.BackgroundColor3 = Color3.fromRGB(20, 20, 30)
	label.TextColor3 = Color3.fromRGB(table.unpack(Formulas.grade(gradeId).Rgb))
	label.TextStrokeTransparency = 0.5
	label.TextScaled = true
	label.Font = Enum.Font.GothamBold
	label.Parent = gui
	gui.Adornee = model:FindFirstChildWhichIsA("BasePart", true)
	gui.Parent = model
end

-- sparkles, glow and a shimmering shell, stronger for better grades and bigger sizes
local function addAura(model, gradeId, sizeId)
	local level = (Formulas.gradeNumber(gradeId) - 1) + (table.find({ "Shard", "Chunk", "Boulder", "Vein" }, sizeId) or 1) - 1
	if level < AURA.SparkleFrom then
		return
	end
	local gradeColor = Color3.fromRGB(table.unpack(Formulas.grade(gradeId).Rgb))
	local sizeColor = AURA_SIZE_COLORS[sizeId] or gradeColor
	local colors = gradeId == "Starlight" and RAINBOW or ColorSequence.new(gradeColor, sizeColor)
	local cf, bounds = model:GetBoundingBox()

	local holder = Instance.new("Part")
	holder.Name = "Aura"
	holder.Anchored = true
	holder.CanCollide = false
	holder.CanQuery = false
	holder.CanTouch = false
	holder.CastShadow = false
	holder.Transparency = 1
	holder.Shape = Enum.PartType.Ball
	local d = math.max(bounds.X, bounds.Y, bounds.Z) * AURA.ShellScale
	holder.Size = Vector3.new(d, d, d)
	holder.CFrame = CFrame.new(cf.Position)
	holder.Parent = model

	local sparkles = Instance.new("ParticleEmitter")
	sparkles.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	sparkles.Color = colors
	sparkles.LightEmission = 1
	sparkles.Rate = AURA.Rate + level * AURA.RatePerLevel
	sparkles.Lifetime = NumberRange.new(1, 1.8)
	sparkles.Speed = NumberRange.new(0.5, 1.5)
	sparkles.SpreadAngle = Vector2.new(180, 180)
	sparkles.Shape = Enum.ParticleEmitterShape.Sphere
	sparkles.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
	local size = AURA.SparkleSize + level * AURA.SparkleSizePerLevel
	sparkles.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.3, size),
		NumberSequenceKeypoint.new(1, 0) })
	sparkles.Parent = holder

	if level >= AURA.LightFrom then
		local light = Instance.new("PointLight")
		light.Color = gradeColor
		light.Range = AURA.LightRange + level * AURA.LightRangePerLevel
		light.Brightness = AURA.LightBrightness + level * AURA.LightBrightnessPerLevel
		light.Parent = holder
	end
	if level >= AURA.ShellFrom then
		holder.Transparency = AURA.ShellTransparency
		holder.Material = Enum.Material.ForceField
		holder.Color = sizeColor
		if gradeId == "Starlight" then
			holder:SetAttribute("Crystal", true) -- changes color with the crystal
		end
	end
end

-- a free spawn point where a node of this radius touches no other node
-- is there room at this spawn point for a node of this radius (Config.Minerals.Gap from the others)?
local function roomAt(point, radius)
	for _, info in pairs(nodes) do
		local d = (Vector3.new(point.Position.X, 0, point.Position.Z) - Vector3.new(info.point.Position.X, 0, info.point.Position.Z)).Magnitude
		if d < radius + info.radius + Config.Minerals.Gap then
			return false
		end
	end
	return true
end

-- (2026-10-02, "크리스탈이 생성될때 유저가 거기있으면 끼는 문제 발생") no player stands where a node of this radius
-- would come up (Config.Minerals.PlayerClear past its edge: a mount too)
local function clearOfPlayers(point, radius)
	for _, player in ipairs(Players:GetPlayers()) do
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if root then
			local d = Vector3.new(root.Position.X - point.Position.X, 0, root.Position.Z - point.Position.Z).Magnitude
			if d < radius + Config.Minerals.PlayerClear then
				return false
			end
		end
	end
	return true
end

-- the free spawn points in random order
local function freePoints()
	local free = {}
	for _, point in ipairs(spawnPoints) do
		if not usedPoints[point] then
			table.insert(free, point)
		end
	end
	for i = #free, 2, -1 do
		local j = rng:NextInteger(1, i)
		free[i], free[j] = free[j], free[i]
	end
	return free
end

local SPOT_GUESS = 0.5 -- a node's footprint radius is about this × its height (a first check before building it)
local HOME_CLEAR = Vector3.new(8, 5, 8)
local HOME_CLEAR_UP = 3.5
local stopMining -- defined below
local spawnNode
local setUpNode
local spawnHome
local homeNodes = {}

local function removeNode(model, near)
	local info = nodes[model]
	if not info then
		return
	end
	for player in pairs(info.miners) do
		if mining[player] == model then
			stopMining(player, nil)
		end
	end
	nodes[model] = nil
	usedPoints[info.point] = nil
	if info.home then
		gradeCounts[info.grade] -= 1
		model:Destroy()
		local slots = homeNodes[info.home]
		if slots and slots[info.slot] == model then
			slots[info.slot] = nil
			task.delay(Config.Minerals.Home.RespawnSeconds, spawnHome, info.home, info.slot)
		end
		return
	end
	gradeCounts[info.grade] -= 1
	if info.grade == Config.Minerals.Special.Id then
		ReplicatedStorage:SetAttribute("TreasureSpot", nil)
		ReplicatedStorage:SetAttribute("TreasureEndsAt", nil)
	end
	model:Destroy()
	task.delay(Config.Minerals.RespawnDelay, spawnNode, true, near)
end

-- free points within NearRespawnRadius of `near` first (each part shuffled), then the rest
local function pointsNear(near)
	local all = freePoints()
	if not near then
		return all
	end
	local close, far = {}, {}
	local r = Config.Minerals.NearRespawnRadius
	for _, p in ipairs(all) do
		local d = Vector3.new(p.Position.X - near.X, 0, p.Position.Z - near.Z).Magnitude
		table.insert(d <= r and close or far, p)
	end
	for _, p in ipairs(far) do
		table.insert(close, p)
	end
	return close
end

spawnNode = function(announce, near)
	local count = 0
	for _, info in pairs(nodes) do
		if not info.home then
			count += 1
		end
	end
	if count >= Config.Minerals.MaxOnServer then
		return
	end
	-- the spot first: its depth in the ring makes rarer grades and bigger sizes likelier further in
	-- (Formulas.rollGrade / rollSize); a few spots are tried for one with room for what was rolled
	local grade, size, scale, model, radius, bounds, point
	for _, candidate in ipairs(pointsNear(near)) do
		local depth = Formulas.mineralDepth(candidate.Position.X, candidate.Position.Z)
		grade = Formulas.rollGrade(rng:NextNumber(), gradeCounts, depth)
		size = Formulas.rollSize(rng:NextNumber(), depth)
		if not grade or not size then
			return
		end
		scale = rng:NextNumber(Config.Minerals.RandomScaleMin, Config.Minerals.RandomScaleMax)
		local height = size.ModelHeight * Config.Minerals.DisplayScale * scale
		-- (room checked before building: the model's footprint is about its height, the widest is checked below)
		local guess = height * SPOT_GUESS
		if roomAt(candidate, guess) and clearOfPlayers(candidate, guess) then
			model = makeNodeModel(grade.Id, size.Id, height)
			_, bounds = model:GetBoundingBox()
			radius = math.max(bounds.X, bounds.Z) / 2
			if roomAt(candidate, radius) and clearOfPlayers(candidate, radius) then
				point = candidate
				break
			end
			model:Destroy()
			model = nil
		end
	end
	if not point then
		return
	end
	bounds = place(model, point)
	local life = Config.Minerals.Lifetime
	setUpNode(model, grade.Id, size.Id, Formulas.nodeTurns(size.Id, scale), point, radius, bounds, rng:NextNumber(life[1], life[2]))
end

setUpNode = function(model, gradeId, sizeId, turns, point, radius, bounds, life)
	model:SetAttribute("Grade", gradeId)
	model:SetAttribute("Size", sizeId)
	model:SetAttribute("TurnsLeft", turns) -- (the ⛏️ auto mining pass weighs what is left: StarterPlayerScripts/AutoMine)
	nodes[model] = { grade = gradeId, size = sizeId, turns = turns, turnsLeft = turns, point = point, radius = radius,
		miners = {}, progress = {}, expiresAt = os.clock() + life }
	usedPoints[point] = model
	gradeCounts[gradeId] = (gradeCounts[gradeId] or 0) + 1
	addLabel(model, bounds, gradeId)
	nodeLabel(model)
	addAura(model, gradeId, sizeId)

	model:SetAttribute("Radius", radius) -- the client's "캐기!" button shows within Mining.Range of the edge
	local click = Instance.new("ClickDetector")
	click.MaxActivationDistance = Config.Mining.Range + radius
	click.Parent = model
	click.MouseClick:Connect(function(player)
		if mining[player] ~= model then -- (only starts: stopping is the button's)
			Minerals.toggle(player, model)
		end
	end)
	model.Parent = nodesFolder

	-- (2026-10-04, "거대광석이나 햇빛석이나 이런 알림은 굳이 필요 없는거 같은데": the "💎 … 등장! 들판에서 찾아봐요"
	-- notice to everyone is gone; the node still shows its aura and colored name)
end

local function homeSpot(index, slot)
	local folder = Bases.folder(index)
	local zone = folder and folder:FindFirstChild("SafeZone")
	local spec = Config.Minerals.Home.Spots[slot]
	if not zone or not spec then
		return nil
	end
	local flat = Vector3.new(zone.Position.X, 0, zone.Position.Z)
	if flat.Magnitude < 1e-3 then
		return nil
	end
	local out = flat.Unit
	local right = out:Cross(Vector3.yAxis).Unit
	local at = flat + right * spec[1] + out * (spec[2] - zone.Size.Z / 2)
	local ignore = { nodesFolder, zone }
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	local ground = Bases.groundBelow(Vector3.new(at.X, zone.Position.Y, at.Z), ignore)
	local params = OverlapParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = ignore
	params.RespectCanCollide = false
	local box = Workspace:GetPartBoundsInBox(CFrame.new(at.X, ground + HOME_CLEAR_UP, at.Z), HOME_CLEAR, params)
	if #box > 0 or not clearOfPlayers({ Position = at }, HOME_CLEAR.X / 2) then
		return nil
	end
	return Vector3.new(at.X, ground, at.Z)
end

spawnHome = function(index, slot)
	local h = Config.Minerals.Home
	local folder = Bases.folder(index)
	if not folder or not folder:GetAttribute("OwnerUserId") or not Unlocks.homeQuarry(index) then
		return
	end
	homeNodes[index] = homeNodes[index] or {}
	if homeNodes[index][slot] then
		return
	end
	local at = nil
	for k = slot, #h.Spots do
		local taken = false
		for _, m in pairs(homeNodes[index]) do
			local info = nodes[m]
			if info and info.spot == k then
				taken = true
			end
		end
		if not taken then
			at = homeSpot(index, k)
			if at then
				local grade, size = Formulas.grade(h.Grade), Formulas.size(h.Size)
				local model = makeNodeModel(grade.Id, size.Id, size.ModelHeight * Config.Minerals.DisplayScale)
				local point = { Position = at }
				local bounds = place(model, point)
				local _, box = model:GetBoundingBox()
				setUpNode(model, grade.Id, size.Id, Formulas.nodeTurns(size.Id, 1), point, math.max(box.X, box.Z) / 2, bounds,
					math.huge)
				nodes[model].home, nodes[model].slot, nodes[model].spot = index, slot, k
				model:SetAttribute("Home", index)
				homeNodes[index][slot] = model
				return
			end
		end
	end
	task.delay(h.RespawnSeconds, spawnHome, index, slot)
end

local function clearHome(index)
	for _, model in pairs(homeNodes[index] or {}) do
		local info = nodes[model]
		if info then
			for player in pairs(info.miners) do
				if mining[player] == model then
					stopMining(player, nil)
				end
			end
			nodes[model] = nil
			usedPoints[info.point] = nil
			gradeCounts[info.grade] -= 1
		end
		model:Destroy()
	end
	homeNodes[index] = nil
end

local function refreshHome(index)
	local folder = Bases.folder(index)
	if folder and folder:GetAttribute("OwnerUserId") and Unlocks.homeQuarry(index) then
		for slot = 1, Config.Minerals.Home.Count do
			spawnHome(index, slot)
		end
	else
		clearHome(index)
	end
end

local function treasureMark(model, bounds)
	local sp = Config.Minerals.Special
	local mark = Instance.new("BillboardGui")
	mark.Name = "TreasureMark"
	mark.Size = TREASURE_MARK_SIZE
	mark.StudsOffsetWorldSpace = Vector3.new(0, bounds.Y / 2 + TREASURE_MARK_UP, 0)
	mark.AlwaysOnTop = true
	mark.MaxDistance = TREASURE_MARK_DISTANCE
	mark.LightInfluence = 0
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBlack
	text.TextScaled = true
	text.TextColor3 = Color3.fromRGB(table.unpack(sp.Rgb))
	text.TextStrokeTransparency = 0.2
	text.Text = TREASURE_MARK_TEXT
	text.Parent = mark
	mark.Adornee = model:FindFirstChildWhichIsA("BasePart", true)
	mark.Parent = model
end

local function spawnTreasure()
	local sp = Config.Minerals.Special
	local height = Formulas.size(sp.Size).ModelHeight * Config.Minerals.DisplayScale
	local points = freePoints()
	for _ = 1, math.min(TREASURE_TRIES, #points) do
		local candidate = points[rng:NextInteger(1, #points)]
		if roomAt(candidate, height * SPOT_GUESS) and clearOfPlayers(candidate, height * SPOT_GUESS) then
			local model = makeNodeModel(sp.Id, sp.Size, height)
			local _, bounds = model:GetBoundingBox()
			local radius = math.max(bounds.X, bounds.Z) / 2
			if roomAt(candidate, radius) and clearOfPlayers(candidate, radius) then
				bounds = place(model, candidate)
				setUpNode(model, sp.Id, sp.Size, 1, candidate, radius, bounds, sp.LifeSeconds)
				treasureMark(model, bounds)
				local cf = model:GetBoundingBox()
				ReplicatedStorage:SetAttribute("TreasureSpot", cf.Position - Vector3.new(0, bounds.Y / 2, 0))
				ReplicatedStorage:SetAttribute("TreasureHeight", bounds.Y)
				ReplicatedStorage:SetAttribute("TreasureEndsAt", Workspace:GetServerTimeNow() + sp.LifeSeconds)
				Net.pushAll("Banner", TREASURE_COMING, "Gold")
				return true
			end
			model:Destroy()
		end
	end
	return false
end

-- ---------------------------------------------------------------------------
-- Mining
-- ---------------------------------------------------------------------------

local function say(player, text)
	Net.push(player, "Notice", "⛏️ 채굴", text)
end

-- how many are mining a node, as its attribute Miners (StarterPlayerScripts/AutoMine)
local function markBusy(model, info)
	local n = 0
	for _ in pairs(info.miners) do
		n += 1
	end
	model:SetAttribute("Miners", n > 0 and n or nil)
end

stopMining = function(player, reason)
	local model = mining[player]
	mining[player] = nil
	local info = model and nodes[model]
	if info then
		info.miners[player] = nil
		markBusy(model, info)
		-- a turn cut short (walked off, slapped away, stunned) keeps its progress for this player on
		-- this node: coming back carries on from there
		local turn = turns[player]
		if turn and turn.model == model and turn.duration > 0 then
			info.progress[player] = math.clamp((os.clock() - turn.started) / turn.duration, 0, MAX_KEPT_PROGRESS)
		end
	end
	turns[player] = nil
	player:SetAttribute("Mining", false)
	if reason then
		say(player, reason)
	end
end

-- may this player keep mining this node? returns true or false, reason
local function treasureLeft(player, profile, info, slots)
	local up = Formulas.trained(profile.Upgrades, profile.Training)
	local most = math.min(math.floor(Formulas.bagCapacity(up.Bag, doubleBag(player)) / slots), Config.Minerals.Special.MaxUnits)
	return most - (info.taken and info.taken[player.UserId] or 0)
end

local function canMine(player, model)
	local info = nodes[model]
	if not info or info.turnsLeft <= 0 then
		return false, nil
	end
	local profile = PlayerData.get(player)
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not profile or not root or not humanoid or humanoid.Health <= 0 then
		return false, nil
	end
	if SafeZones.inSky(player, root.Position) then -- (2026-10-04) on a flying dino over the battlefield: only looking
		return false, "🦅 하늘 구경 중엔 못 캐요"
	end
	local cf = model:GetBoundingBox()
	if info.home and info.home ~= Bases.of(player) then
		return false, "🏠 내 기지 광물만 캘 수 있어요"
	elseif not info.home and Unlocks.closedAt(player, cf.Position) then
		return false, "🌫️ 아직 닫힌 곳이에요"
	end
	local edge = (Vector3.new(root.Position.X, 0, root.Position.Z) - Vector3.new(cf.X, 0, cf.Z)).Magnitude - info.radius
	if edge > Config.Mining.Range then
		return false, "📏 너무 멀어요. 가까이 가서 캐세요"
	end
	local room = Formulas.bagCapacity(Formulas.trained(profile.Upgrades, profile.Training).Bag, doubleBag(player))
		- Formulas.carryCount(profile.Carry)
	local special = info.grade == Config.Minerals.Special.Id
	local slots = special and Formulas.treasureSlots() or Formulas.bagSlots(info.grade)
	if special then
		local up = Formulas.trained(profile.Upgrades, profile.Training)
		if Formulas.bagCapacity(up.Bag, doubleBag(player)) < slots then
			local worth = Formulas.carryValue({ [Formulas.carryKey(info.grade, tostring(slots))] = 1 }, profile.DefenseLevel)
			return false, string.format(TREASURE_SMALL, slots, Formulas.shortNumber(worth))
		end
		if treasureLeft(player, profile, info, slots) <= 0 then
			return false, TREASURE_ONCE
		end
	end
	if room < slots then
		if special then
			local worth = Formulas.carryValue({ [Formulas.carryKey(info.grade, tostring(slots))] = 1 }, profile.DefenseLevel)
			return false, string.format(TREASURE_FULL, slots, Formulas.shortNumber(worth))
		end
		return false, "🎒 가방 가득! 기지 입금통에 넣으세요"
	end
	return true
end

-- a 대박 광물 (Config.Mining.Jackpot): money at once, keys into the bag, maybe a silver key, a burst for all
local function jackpot(player, model, profile)
	local j = Config.Mining.Jackpot
	local money = Formulas.jackpotMoney(profile.DefenseLevel, rng:NextNumber())
	local silver = rng:NextNumber() * 100 < j.SilverChancePercent
	PlayerData.update(player, function(p)
		p.FoundKeys = (p.FoundKeys or 0) + j.Keys
		if silver then
			Formulas.addSavedKeys(p, "Silver", 1)
		end
	end)
	PlayerData.addMoney(player, money, "jackpot")
	Rewards.add(player, "Jackpot", 1) -- daily missions and weekly challenges
	Net.push(player, "Notice", "🌟 대박 광물!", string.format("+%s원 · 🔑 열쇠 %d개 (가방)%s", Formulas.shortNumber(money), j.Keys,
		silver and " · 은 열쇠 1개!" or ""))
	Net.push(player, "KeyFound", j.Keys)
	Net.pushAll("Jackpot", player.UserId, model:GetBoundingBox().Position, money)
end

-- one finished turn: minerals into the bag, one turn off the node
local function collect(player, model, boost)
	local info = nodes[model]
	local profile = PlayerData.get(player)
	local up = Formulas.trained(profile.Upgrades, profile.Training)
	local room = Formulas.bagCapacity(up.Bag, doubleBag(player)) - Formulas.carryCount(profile.Carry)
	-- bigger nodes give more a turn; rain and storms double it (Weather)
	local nightYield = Formulas.nightMining(DayNight.isNight()) -- and more at night ...
		* Formulas.dayBuff(ReplicatedStorage:GetAttribute("DayBuff"), "Mining") -- ... and the day after a 🦅 boss
	local turnsTaken = info.grade == Config.Minerals.Special.Id and 1 or math.min(boost or 1, math.max(info.turnsLeft, 1))
	local base = Formulas.yieldPerTurn(up.PickaxeTier, info.grade, info.size) * Formulas.weather(Weather.current()).MiningYieldMultiplier
		* nightYield * turnsTaken
	local bonuses = Formulas.bonuses(profile)
	local mined = info.grade == Config.Minerals.Special.Id and Config.Minerals.Special.FixedYield
		or Formulas.bonusYield(base, bonuses.Mining, rng:NextNumber())
	local special = info.grade == Config.Minerals.Special.Id
	local slots = special and Formulas.treasureSlots() or Formulas.bagSlots(info.grade)
	local amount = math.min(mined, math.floor(room / slots))
	if special then
		amount = math.min(amount, treasureLeft(player, profile, info, slots))
		info.taken = info.taken or {}
		info.taken[player.UserId] = (info.taken[player.UserId] or 0) + amount
		if amount > 0 and treasureLeft(player, profile, info, slots) <= 0 then
			say(player, string.format(TREASURE_DONE, info.taken[player.UserId]))
		end
	end
	local key = Formulas.carryKey(info.grade, special and tostring(slots) or info.size)
	Rewards.add(player, "Mine", amount) -- daily missions
	if DayNight.isNight() then
		Rewards.add(player, "NightMine", amount)
	end
	if Formulas.gradeNumber(info.grade) >= RARE_MINE_GRADE then
		Rewards.add(player, "RareMine", amount)
	end
	Rewards.add(player, "Mine" .. info.grade, amount) -- by grade (the beginner missions: MineSprout)
	if not info.home and amount > 0 then
		Unlocks.fieldMined(player, model:GetPivot().Position, amount)
	end
	local found = Formulas.mineKeys(amount, info.grade, info.size, profile.DefenseLevel, function()
		return rng:NextNumber()
	end, up.Bag)
	PlayerData.update(player, function(p)
		p.Carry[key] = (p.Carry[key] or 0) + amount
		p.FoundKeys = (p.FoundKeys or 0) + found
	end)
	-- (2026-10-04, "본게임에서 광질 조금 하다 가던데": a mineral went into the bag without a sign) "+1 💧 💰+32" over me (MiningFx):
	-- what these will pay at the deposit bin (Deposit: the farm/collection/rebirth bonus, the friends' boost)
	if special and amount > 0 then
		for _ = 1, amount do
			local kind = Formulas.treasureKey(up.Bag, rng:NextNumber())
			if kind then
				PlayerData.update(player, function(p)
					Formulas.addSavedKeys(p, kind, 1)
				end)
				local keyName = Formulas.keyType(kind).Name
				Net.push(player, "Notice", "💰 특급석", string.format(TREASURE_KEY_TEXT, keyName))
				if kind == "Diamond" or kind == "Rainbow" then
					Net.pushAll("Notice", "💰 특급석", string.format(TREASURE_KEY_ALL, player.DisplayName, keyName))
				end
			end
		end
	end
	if amount > 0 then
		local worth = Formulas.carryValue({ [key] = amount }, profile.DefenseLevel) * (1 + bonuses.Money)
			* Formulas.friendBoost(player:GetAttribute("Friends"))
		Net.push(player, "Mined", amount, info.grade, math.floor(worth + 0.5))
	end
	if found > 0 then
		Net.push(player, "Notice", "🔑 광물 속 열쇠!", string.format("🔑 열쇠 %d개 찾았어요! 기지 입금통에 넣으면 내 거예요", found))
		Net.push(player, "KeyFound", found)
	end
	if info.grade ~= Config.Minerals.Special.Id and rng:NextNumber() * 100 < Config.Mining.Jackpot.ChancePercent then
		jackpot(player, model, PlayerData.get(player))
	end
	if special then
		return
	end
	info.turnsLeft -= turnsTaken
	model:SetAttribute("TurnsLeft", math.ceil(info.turnsLeft))
	if info.turnsLeft <= 0 then
		if BIG_SIZES[info.size] then
			Rewards.add(player, "BigMineral", 1) -- the daily mission: emptied a boulder or a giant vein
		end
		removeNode(model, info.point.Position)
	else
		nodeLabel(model)
	end
end

-- stop this player's mining now (e.g. before a teleport)
function Minerals.stopMining(player)
	stopMining(player, nil)
end

-- tapping a node, or its "캐기!" button (Net request Mine): start mining it, or stop if already
function Minerals.toggle(player, model)
	if not nodes[model] then
		return
	end
	if mining[player] == model then
		stopMining(player, nil)
	else
		Minerals.startMining(player, model)
	end
end

function Minerals.startMining(player, model)
	local info = nodes[model]
	if not info or not PlayerData.isLoaded(player) then
		return
	end
	local ok, reason = canMine(player, model)
	if not ok then
		return say(player, reason or "지금은 캘 수 없어요")
	end
	-- (2026-10-04, "본게임에서 광질 조금 하다 가던데") too hard for this pickaxe: not started (the button shows 🔒 and
	-- points at one that can be mined: MiningFx)
	local up = Formulas.trained(PlayerData.get(player).Upgrades, PlayerData.get(player).Training)
	if Formulas.mineLocked(up.PickaxeTier, up.PickaxePower, up.PickaxeSpeed, info.grade) then
		Net.push(player, "MineLocked", info.grade) -- (the notice and the arrow to one that can be mined: MiningFx)
		return
	end
	local rookie, rookieLeft = Formulas.rookieSpeed(PlayerData.get(player).PlaySeconds)
	if rookie > 1 and not rookieTold[player] then -- (2026-10-04) 🐣 told when the first mining starts
		rookieTold[player] = true
		say(player, string.format("🐣 초보 버프! 앞으로 %d분 동안 캐기 %d배 빨라요", math.ceil(rookieLeft / 60), rookie))
	end
	stopMining(player, nil)
	mining[player] = model
	info.miners[player] = true
	markBusy(model, info)

	task.spawn(function()
		while mining[player] == model do
			local profile = PlayerData.get(player)
			local node = nodes[model]
			if not profile or not node then -- left the game, or someone else finished the node
				if mining[player] == model then
					stopMining(player, nil)
				end
				break
			end
			local p = Formulas.trained(profile.Upgrades, profile.Training)
			local duration = Formulas.mineSeconds(p.PickaxeTier, p.PickaxePower, p.PickaxeSpeed, node.grade)
				/ (doubleBag(player) and 1 + Config.GamePasses.DoubleBag.MiningSpeedBonus or 1) -- the 🎒 pass
				/ Formulas.weather(Weather.current()).MiningSpeedMultiplier -- rain and storms: faster turns
				/ select(2, Formulas.nightMining(DayNight.isNight())) -- and at night
				/ Formulas.dayBuff(ReplicatedStorage:GetAttribute("DayBuff"), "Mining") -- and the day after a 🦅 boss
				/ Formulas.rookieSpeed(profile.PlaySeconds) -- (2026-10-04) and a new player's first minutes (🐣)
			local boost
			duration, boost = Formulas.turnFloor(duration)
			local done = node.progress[player] or 0 -- a turn left half done here before
			node.progress[player] = nil
			player:SetAttribute("MineStart", Workspace:GetServerTimeNow() - done * duration)
			player:SetAttribute("MineDuration", duration)
			player:SetAttribute("Mining", true)
			local started = os.clock() - done * duration
			turns[player] = { model = model, started = started, duration = duration }
			while mining[player] == model and os.clock() - started < duration do -- the loading bar fills
				task.wait(math.min(duration, Config.MoveGuard.CheckInterval))
				local can, why = canMine(player, model)
				if not can then
					stopMining(player, why)
				end
			end
			if mining[player] ~= model then
				break
			end
			turns[player] = nil -- finished: nothing half done to keep
			collect(player, model, boost)
			local can, why = canMine(player, model)
			if not can then
				if mining[player] == model then
					stopMining(player, why)
				end
				break
			end
		end
	end)
end

function Minerals.testTreasure()
	for model, info in pairs(nodes) do
		if info.grade == Config.Minerals.Special.Id then
			removeNode(model)
		end
	end
	return spawnTreasure()
end

function Minerals.init()
	local map = Workspace:FindFirstChild("Map")
	local points = map and map:FindFirstChild("OreSpawns")
	if not points then
		warn("[Minerals] Workspace.Map.OreSpawns가 없습니다. roblox/MapBuilder.lua를 먼저 실행하세요.")
	else
		for _, p in ipairs(points:GetChildren()) do
			if p:IsA("BasePart") then
				table.insert(spawnPoints, p)
			end
		end
		points.Parent = game:GetService("ServerStorage")
	end
	nodesFolder = Workspace:FindFirstChild("Minerals") or Instance.new("Folder")
	nodesFolder.Name = "Minerals"
	nodesFolder.Parent = Workspace
	for _ = 1, Config.Minerals.MaxOnServer do
		spawnNode(false) -- the first fill: no announcements
	end
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			folder:GetAttributeChangedSignal("OwnerUserId"):Connect(function()
				refreshHome(index)
			end)
			refreshHome(index)
		end
	end
	Unlocks.onStage(refreshHome)
	treasureAt = os.clock() + Config.Minerals.Special.FirstSeconds
	task.spawn(function() -- top up: a node that found no free point is tried again later; old ones go
		while true do
			task.wait(Config.Minerals.RespawnDelay)
			local now = os.clock()
			local expired = {}
			local busy = {} -- every node someone is mining now (or is in a turn on)
			for _, model in pairs(mining) do
				busy[model] = true
			end
			for _, turn in pairs(turns) do
				busy[turn.model] = true
			end
			for model, info in pairs(nodes) do
				if now >= info.expiresAt and not next(info.miners) and not busy[model] then
					table.insert(expired, model)
				end
			end
			for _, model in ipairs(expired) do
				removeNode(model) -- (its replacement comes anywhere)
			end
			spawnNode(true)
			if now >= treasureAt and #Players:GetPlayers() > 0 then
				local every = Config.Minerals.Special.EverySeconds
				treasureAt = now + (spawnTreasure() and rng:NextNumber(every[1], every[2]) or TREASURE_RETRY)
			end
		end
	end)

	Net.onRequest("Mine", { "Instance" }, function(player, model)
		Minerals.toggle(player, model)
	end)
	-- the ⛏️ auto mining pass (Config.GamePasses.AutoMine): its owner's own screen walks to the best mineral,
	-- asks Mine and walks home to empty the bag (StarterPlayerScripts/AutoMine, 2026-10-02: was only "start the
	-- nearest mineral in reach"); the server checks every turn the same as a tap
	PlayerData.onLoaded(refreshBag)
	PlayerData.onChanged(refreshBag)
	local function watch(player)
		player:GetAttributeChangedSignal("TrainReal_Bag"):Connect(function()
			refreshBag(player)
		end)
		player.CharacterAdded:Connect(function()
			stopMining(player, nil)
			heldTier[player] = nil
			wornBag[player] = nil
			task.defer(refreshBag, player)
		end)
	end
	Players.PlayerAdded:Connect(watch)
	for _, player in ipairs(Players:GetPlayers()) do
		watch(player)
	end
	Players.PlayerRemoving:Connect(function(player)
		stopMining(player, nil)
		heldTier[player] = nil
		wornBag[player] = nil
		rookieTold[player] = nil
		for _, info in pairs(nodes) do
			info.progress[player] = nil
		end
	end)
end

return Minerals
