--[[
FenceLook: a reborn player's base fence turns into crystal of the rebirth tier's color (2026-10-01, "after a
rebirth the fence could look different, like minerals"): every Rail and Post in the base's Fence folders
becomes see-through shining glass in the tier's color (the colors of Config.Rebirth.TierMarks: 🟢 emerald,
🔵 sapphire, 🟣 amethyst, 🟠 amber, 🔴 ruby, ⭐ gold), with a soft glow on the posts, and every post wears
its tier's own top ("each rebirth a different fence shape"): 🟢 one tall crystal spike, 🔵 a round gem,
🟣 a cluster of three shards, 🟠 a drop of amber on a bead, 🔴 a cut diamond, ⭐ a crown of spikes round an orb
(in a CrystalTops folder beside the posts). It follows the base's
owner (base folder attribute OwnerUserId) and their rebirths (player attribute Rebirths); a base without a
reborn owner gets its wooden fence back. Display only.
(2026-10-01, "the fence didn't change, shape or color") a crystal fence is also taller and thicker (posts
POST_GROW taller, rails RAIL_GROW thicker, tops TOP_SCALE as big), and besides the owner and rebirth
signals every base is checked every RECHECK_EVERY seconds (base folder attribute FenceTier: the tier on
show), so a missed signal can't leave the wooden fence. Each change is written to the server's log.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Bases = require(script.Parent:WaitForChild("Bases"))

local FenceLook = {}

-- display only: per rebirth tier (1 = one rebirth; the last repeats), like the tier marks
local CRYSTALS = {
	{ Color = Color3.fromRGB(60, 210, 120), Name = "에메랄드" }, -- 🟢
	{ Color = Color3.fromRGB(70, 140, 255), Name = "사파이어" }, -- 🔵
	{ Color = Color3.fromRGB(175, 95, 235), Name = "자수정" }, -- 🟣
	{ Color = Color3.fromRGB(255, 155, 45), Name = "호박" }, -- 🟠
	{ Color = Color3.fromRGB(235, 45, 75), Name = "루비" }, -- 🔴
	{ Color = Color3.fromRGB(255, 210, 70), Name = "황금" }, -- ⭐
}
local CRYSTAL_TRANSPARENCY = 0.15
local CRYSTAL_REFLECTANCE = 0.25
local POST_GLOW_RANGE = 6
local POST_GLOW_BRIGHTNESS = 0.6
local POST_GLOW_EVERY = 3 -- every 3rd post glows (lights are not free)
local TOP_FOLDER = "CrystalTops"
local POST_GROW = 1.6 -- studs taller (the bottom stays on the ground)
local RAIL_GROW = 1.6 -- times as thick
local TOP_SCALE = 1.6 -- the tops' pieces, times as big
local RECHECK_EVERY = 3 -- seconds

-- each tier's post top: a list of pieces { shape, size, offset from the post's top (CFrame) }
local TOPS = {
	{ { "Block", Vector3.new(0.7, 2.4, 0.7), CFrame.new(0, 1.1, 0) * CFrame.Angles(0, math.rad(45), math.rad(6)) } }, -- spike
	{ { "Ball", Vector3.one * 1.5, CFrame.new(0, 0.7, 0) } }, -- a round gem
	{ -- a cluster of three shards
		{ "Block", Vector3.new(0.45, 1.6, 0.45), CFrame.new(0, 0.75, 0) * CFrame.Angles(0, math.rad(45), 0) },
		{ "Block", Vector3.new(0.4, 1.2, 0.4), CFrame.new(0.3, 0.5, 0) * CFrame.Angles(0, 0, math.rad(-28)) },
		{ "Block", Vector3.new(0.4, 1.1, 0.4), CFrame.new(-0.3, 0.45, 0.1) * CFrame.Angles(math.rad(15), 0, math.rad(28)) },
	},
	{ -- a drop of amber on a bead
		{ "Ball", Vector3.one * 0.8, CFrame.new(0, 0.35, 0) },
		{ "Ball", Vector3.new(1.2, 1.5, 1.2), CFrame.new(0, 1.3, 0) },
	},
	{ { "Block", Vector3.one * 1.1, CFrame.new(0, 0.9, 0) * CFrame.Angles(math.rad(45), 0, math.rad(45)) } }, -- cut diamond
	{ -- a crown: an orb with four spikes round it
		{ "Ball", Vector3.one * 1, CFrame.new(0, 0.6, 0) },
		{ "Block", Vector3.new(0.3, 1.1, 0.3), CFrame.new(0.45, 0.8, 0) * CFrame.Angles(0, 0, math.rad(-20)) },
		{ "Block", Vector3.new(0.3, 1.1, 0.3), CFrame.new(-0.45, 0.8, 0) * CFrame.Angles(0, 0, math.rad(20)) },
		{ "Block", Vector3.new(0.3, 1.1, 0.3), CFrame.new(0, 0.8, 0.45) * CFrame.Angles(math.rad(20), 0, 0) },
		{ "Block", Vector3.new(0.3, 1.1, 0.3), CFrame.new(0, 0.8, -0.45) * CFrame.Angles(math.rad(-20), 0, 0) },
	},
}

-- the fence parts of a base (all its Fence folders)
local function fenceParts(folder)
	local parts = {}
	for _, f in ipairs(folder:GetDescendants()) do
		if f:IsA("Folder") and f.Name == "Fence" then
			for _, p in ipairs(f:GetChildren()) do
				if p:IsA("BasePart") then
					table.insert(parts, p)
				end
			end
		end
	end
	return parts
end

-- the tier's tops on every post (old ones go first)
local function placeTops(folder, tier, crystal)
	for _, f in ipairs(folder:GetDescendants()) do
		if f.Name == TOP_FOLDER then
			f:Destroy()
		end
	end
	if not crystal then
		return
	end
	local top = TOPS[math.min(tier, #TOPS)]
	for _, fence in ipairs(folder:GetDescendants()) do
		if fence:IsA("Folder") and fence.Name == "Fence" then
			local holder = Instance.new("Folder")
			holder.Name = TOP_FOLDER
			for _, post in ipairs(fence:GetChildren()) do
				if post:IsA("BasePart") and post.Name == "Post" then
					local at = post.CFrame * CFrame.new(0, post.Size.Y / 2, 0)
					for _, piece in ipairs(top) do
						local p = Instance.new("Part")
						p.Name = "CrystalTop"
						p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, false
						p.Shape = Enum.PartType[piece[1]]
						p.Size = piece[2] * TOP_SCALE
						local offset = piece[3]
						p.CFrame = at * (offset - offset.Position + offset.Position * TOP_SCALE)
						p.Color = crystal.Color
						p.Material = Enum.Material.Glass
						p.Transparency = CRYSTAL_TRANSPARENCY
						p.Reflectance = CRYSTAL_REFLECTANCE
						p.Parent = holder
					end
				end
			end
			holder.Parent = fence.Parent -- (beside the Fence folder: its parts stay just the rails and posts)
		end
	end
end

local function apply(folder, tier)
	local crystal = tier > 0 and CRYSTALS[math.min(tier, #CRYSTALS)] or nil
	local parts = fenceParts(folder)
	local posts = 0
	for _, p in ipairs(parts) do
		if p:GetAttribute("WoodColor") == nil then -- the wooden look, to give back
			p:SetAttribute("WoodColor", p.Color)
			p:SetAttribute("WoodMaterial", p.Material.Name)
		end
		if p:GetAttribute("WoodSize") == nil then
			p:SetAttribute("WoodSize", p.Size)
			p:SetAttribute("WoodCFrame", p.CFrame)
		end
		local glow = p:FindFirstChild("CrystalGlow")
		local woodSize, woodCFrame = p:GetAttribute("WoodSize"), p:GetAttribute("WoodCFrame")
		if crystal then -- taller posts (from the ground up), thicker rails
			if p.Name == "Post" then
				p.Size = woodSize + Vector3.new(0, POST_GROW, 0)
				p.CFrame = woodCFrame * CFrame.new(0, POST_GROW / 2, 0)
			else
				p.Size = Vector3.new(woodSize.X * RAIL_GROW, woodSize.Y * RAIL_GROW, woodSize.Z)
				p.CFrame = woodCFrame
			end
		else
			p.Size, p.CFrame = woodSize, woodCFrame
		end
		if crystal then
			p.Color = crystal.Color
			p.Material = Enum.Material.Glass
			p.Transparency = CRYSTAL_TRANSPARENCY
			p.Reflectance = CRYSTAL_REFLECTANCE
			if p.Name == "Post" then
				posts += 1
				if posts % POST_GLOW_EVERY == 0 then
					glow = glow or Instance.new("PointLight")
					glow.Name = "CrystalGlow"
					glow.Color = crystal.Color
					glow.Range = POST_GLOW_RANGE
					glow.Brightness = POST_GLOW_BRIGHTNESS
					glow.Parent = p
				end
			end
		else
			p.Color = p:GetAttribute("WoodColor")
			p.Material = Enum.Material[p:GetAttribute("WoodMaterial")] or Enum.Material.Plastic
			p.Transparency = 0
			p.Reflectance = 0
			if glow then
				glow:Destroy()
			end
		end
	end
	placeTops(folder, tier, crystal) -- (after the posts have their height)
	folder:SetAttribute("FenceTier", tier)
	if #parts == 0 then
		warn(string.format("[FenceLook] %s: 울타리(Fence 폴더의 Rail·Post)를 못 찾았어요. MapBuilder.lua로 만든 맵인지 확인하세요",
			folder.Name))
	else
		print(string.format("[FenceLook] %s 울타리: %s (부품 %d개)", folder.Name,
			crystal and string.format("%s %d단계", crystal.Name, tier) or "나무", #parts))
	end
end

local function refresh(index)
	local folder = Bases.folder(index)
	if not folder then
		return
	end
	local owner = Players:GetPlayerByUserId(folder:GetAttribute("OwnerUserId") or 0)
	local tier = owner and (owner:GetAttribute("Rebirths") or 0) or 0
	if folder:GetAttribute("FenceTier") ~= tier then
		apply(folder, tier)
	end
end

function FenceLook.init()
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			folder:GetAttributeChangedSignal("OwnerUserId"):Connect(function()
				refresh(index)
			end)
			local ok, err = pcall(refresh, index) -- (one base's trouble doesn't stop the rest)
			if not ok then
				warn("[FenceLook]", err)
			end
		end
	end
	local function watch(player)
		player:GetAttributeChangedSignal("Rebirths"):Connect(function()
			local index = Bases.of(player)
			if index then
				refresh(index)
			end
		end)
	end
	Players.PlayerAdded:Connect(watch)
	for _, player in ipairs(Players:GetPlayers()) do
		watch(player)
	end
	task.spawn(function() -- (a missed signal can't leave a base's fence wrong for long)
		while true do
			task.wait(RECHECK_EVERY)
			for index = 1, Config.Map.BaseCount do
				local ok, err = pcall(refresh, index)
				if not ok then
					warn("[FenceLook]", err)
				end
			end
		end
	end)
end

return FenceLook
