--[[
Enhance: dino enhancement (Config.Enhance), at the enhance stall in front of the player's own defense
arena. The stall is made when the server starts: a copy of the base's shop stall (Base_Shop, or a grey
box without it) named EnhanceStall, next to the DefenseSign toward the middle of the plot, with a
"🦖 공룡 강화" title and a "공룡 강화" prompt (Kind "Enhance") that opens the enhance window on the
client (StarterPlayerScripts/Placement). A base that already has an EnhanceStall keeps it.

Net ask Enhance(targetId, { fodderId, ... }), only near the player's own stall, feeds one of
the player's dinos others (any species since 2026-10-01; its own species gives the most) that are neither
placed nor on the farm: they are used up and give their experience (Formulas.fodderExp: bigger and rarer
ones more, another species Enhance.OtherSpeciesShare of it), the dino levels up when it has
enough (Formulas.enhanceNeed, harder for higher rarities and higher levels), and each level adds
attack (Formulas.levelPower). The collection keeps the used-up dinos. Answers
{ Level, Exp, Gained } or { Error }.

Net ask Merge({ id, id, id }, keepId), at the same stall (합성): Config.Merge.Count dinos of the same
rarity, all at the top level, neither placed nor on the farm (Formulas.canMerge), are used up and make
one dino of the next rarity: keepId's species and mutation; its size and level from the three's
(Formulas.mergeResult, 2026-10-02: bigger and higher ones make a bigger, higher one; three at the top make
about 2/3 of the best). It joins the collection; rare results are announced. Answers { Unit } or
{ Error }.

Net ask Feed(unitId, amount), at the same stall (🍎 먹이, 2026-10-02, Config.Fruit; 2026-10-06 food adds up on the dino, unit.Fed): grows one of the player's dinos one
size with the food from the trees' fruit (profile Fruit, Fruits service; Formulas.canFeed / feed: a placed dino
must still fit its place). Answers { Unit, Fruit, Grew, Put } or { Error }.

Player attribute MergeReady: a merge is possible now (Formulas.mergeReady; Coco's 🧬 tip).
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))

local MERGE_ANNOUNCE_FROM = "Legendary" -- merges into this rarity and up are told to everyone

local Enhance = {}

-- display only
local STALL_SIDE = 13
local TITLE_COLOR = Color3.fromRGB(255, 200, 120)
local STALL_COLOR = Color3.fromRGB(200, 120, 40)
local RANGE_SLACK = 4 -- the server allows a little more than the prompt's range (lag)

local stalls = {} -- [base number] = stall model

local function makeStall(index, folder)
	local sign = folder:FindFirstChild("DefenseSign", true)
	if not sign or not sign:IsA("BasePart") then
		warn(string.format("[Enhance] Base%d에 DefenseSign이 없어 강화 가판대를 못 놓았습니다", index))
		return nil
	end
	local look = Vector3.new(sign.CFrame.LookVector.X, 0, sign.CFrame.LookVector.Z).Unit -- toward the entrance
	local right = Vector3.new(sign.CFrame.RightVector.X, 0, sign.CFrame.RightVector.Z).Unit
	local zone = folder:FindFirstChild("SafeZone")
	local middle = zone and zone.Position or sign.Position
	local side = (middle - sign.Position):Dot(right) >= 0 and 1 or -1
	local spot = sign.Position + right * side * STALL_SIDE
	local stall = Bases.copyStall(folder, "EnhanceStall", spot, look, STALL_COLOR, "🦖 공룡 강화")
	Bases.title(stall, "🦖 공룡 강화", TITLE_COLOR)
	return stall
end

local function setMergeReady(player)
	local profile = PlayerData.get(player)
	player:SetAttribute("MergeReady", profile ~= nil and Formulas.mergeReady(profile) or nil)
end

local function enhance(player, targetId, fodderIds)
	if not Unlocks.check(player, "Enhance") then
		return { Error = "🔒 아직 잠겨 있어요" }
	end
	local profile = PlayerData.get(player)
	if not profile or #fodderIds > Config.Enhance.MaxFodder then
		return { Error = "잘못된 요청이에요" }
	end
	local stall = stalls[Bases.of(player)]
	if not stall or not Bases.near(player, stall, Config.Enhance.StallRange + RANGE_SLACK) then
		return { Error = "⬆️ 아레나 앞 강화 가판대에서 해요" }
	end
	local ids = {}
	for i = 1, #fodderIds do
		if type(fodderIds[i]) ~= "string" then
			return { Error = "잘못된 요청이에요" }
		end
		ids[i] = fodderIds[i]
	end
	local ok, why = Formulas.canEnhance(profile, targetId, ids)
	if not ok then
		return { Error = why }
	end
	local used = {}
	for _, id in ipairs(ids) do
		used[id] = true
	end
	local result = nil
	PlayerData.update(player, function(p)
		local exp, target = 0, nil
		for _, u in ipairs(p.Units) do
			if u.Id == targetId then
				target = u
			end
		end
		for i = #p.Units, 1, -1 do
			local u = p.Units[i]
			if used[u.Id] then
				exp += Formulas.fodderExp(u, target)
				table.remove(p.Units, i)
			end
		end
		local gained = Formulas.addExp(target, exp)
		result = { Level = Formulas.unitLevel(target), Exp = target.Exp, Gained = gained, Used = #ids, ExpAdded = exp }
	end)
	Rewards.add(player, "Enhance", 1) -- daily missions
	setMergeReady(player)
	return result
end

local function feed(player, unitId, amount)
	if not Unlocks.check(player, "Enhance") then
		return { Error = "🔒 아직 잠겨 있어요" }
	end
	local profile = PlayerData.get(player)
	if not profile then
		return { Error = "잘못된 요청이에요" }
	end
	local stall = stalls[Bases.of(player)]
	if not stall or not Bases.near(player, stall, Config.Enhance.StallRange + RANGE_SLACK) then
		return { Error = "⬆️ 아레나 앞 강화 가판대에서 해요" }
	end
	local ok, giveOrWhy = Formulas.canFeed(profile, unitId, amount)
	if not ok then
		return { Error = giveOrWhy }
	end
	local fruitBefore = profile.Fruit or 0
	local grown, grew = nil, false
	PlayerData.update(player, function(p)
		grown, grew = Formulas.feed(p, unitId, giveOrWhy)
	end)
	local fruit = PlayerData.get(player).Fruit
	player:SetAttribute("Fruit", fruit)
	if not grown then
		return { Error = "⏳ 잠시 뒤에 다시 해 보세요" }
	end
	Rewards.add(player, "Feed", 1) -- (2026-10-03: the tutorial field's 🍎 먹이 step)
	return { Unit = grown, Fruit = fruit, Grew = grew, Put = fruitBefore - fruit }
end

local function merge(player, ids, keepId)
	if not Unlocks.check(player, "Enhance") then
		return { Error = "🔒 아직 잠겨 있어요" }
	end
	local profile = PlayerData.get(player)
	if not profile or #ids > Config.Merge.Count or type(keepId) ~= "string" then
		return { Error = "잘못된 요청이에요" }
	end
	local stall = stalls[Bases.of(player)]
	if not stall or not Bases.near(player, stall, Config.Enhance.StallRange + RANGE_SLACK) then
		return { Error = "⬆️ 아레나 앞 강화 가판대에서 해요" }
	end
	local list = {}
	for i = 1, #ids do
		if type(ids[i]) ~= "string" then
			return { Error = "잘못된 요청이에요" }
		end
		list[i] = ids[i]
	end
	local ok, rarityOrWhy = Formulas.canMerge(profile, list, keepId, profile.DefenseLevel)
	if not ok then
		return { Error = rarityOrWhy }
	end
	local used = {}
	for _, id in ipairs(list) do
		used[id] = true
	end
	local made = nil
	PlayerData.update(player, function(p)
		local units = {}
		for i = #p.Units, 1, -1 do
			if used[p.Units[i].Id] then
				table.insert(units, table.remove(p.Units, i))
			end
		end
		made = Formulas.mergeResult(units, keepId, rarityOrWhy)
		made.Id = "U" .. p.NextUnitId
		p.NextUnitId += 1
		table.insert(p.Units, made)
		Formulas.recordCollection(p, made)
	end)
	if (Formulas.rarity(made.Rarity .. "#") or 0) >= Formulas.rarity(MERGE_ANNOUNCE_FROM .. "#") then
		Net.pushAll("Notice", "🧬 합성 대성공!", string.format("🧬 %s님이 합성으로 %s %s 탄생!", player.DisplayName,
			Formulas.rarity(made.Rarity).Name, Formulas.species(made.Species).Name))
	end
	if Formulas.chatFind(made.Rarity) then
		Net.pushAll("BigFind", player.DisplayName, "Merge", made.Rarity, made.Species)
	end
	setMergeReady(player)
	Rewards.add(player, "Merge", 1) -- (2026-10-03: the tutorial field's 🧬 합성 step)
	return { Unit = made }
end

function Enhance.init()
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			local stall = folder:FindFirstChild("EnhanceStall") or makeStall(index, folder)
			if stall then
				stalls[index] = stall
				Bases.prompt(stall, "Enhance", index, "공룡 강화", Config.Enhance.StallRange) -- the client opens the window
			end
		end
	end
	Net.onAsk("Enhance", { "string", "table" }, enhance)
	Net.onAsk("Merge", { "table", "string" }, merge)
	Net.onAsk("Feed", { "string", "number" }, feed)
	PlayerData.onLoaded(setMergeReady)
end

return Enhance
