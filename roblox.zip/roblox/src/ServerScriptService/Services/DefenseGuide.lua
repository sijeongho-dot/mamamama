--[[
DefenseGuide: a board beside every base's defense sign (DefenseSign, in front of the defense field)
that tells what the defense level gives (2026-10-01, "디펜스 앞에 게시판 만들어서 보상에 대해 적어주자"):
the keys a won promotion pays (Config.Defense.Promotion), the species and rarities each level opens
(Config.Species, Config.Rarities), what grows with the level (money a kill, the keys' worth at home,
chests) and rebirth at the top of the tier (Config.Rebirth). Written from Config when the server starts,
for all eight bases, facing the same way as the sign. Display only.
Beside it (further from the sign) the "🧪 공룡 속성" board (2026-10-01): each attribute's emoji, name and
what it does, and a last line Defense fills with the owner's next promotion boss attribute (DefenseGuide.nextBossLabel).
(2026-10-04) Both in pictures (tiles: a big emoji, a few words; the bosses' weaknesses a row of "🔥→💧"), and a
"📖 자세히 보기" prompt on each (Kind "DefenseGuide" / "AttributeGuide") opens the whole story on the screen
(StarterPlayerScripts/GuideBoards).
(2026-10-05, "디펜스 보상, 공룡속성 게시판을 훈련장 건너편에 세우고 디펜스 아레나쪽을 바라보도록, 거기에 새로운 게시판을 넣고
(공룡속성 자리) 거기에 실패 이유를 적어주자" → A: the training ground's front) the two boards stand side by side at the plot's
front, past the training ground from the arena (plot u GUIDE_U.., v BOARDS_V), facing the arena. Where the 🧪 board stood
(beside the defense sign) the 🩺 승급전 분석 board: the base owner's last lost promotion fight's weakest point (Defense:
DefenseGuide.showAdvice, the profile's PromoAdvice) in a big picture and a few lines, until a level is won.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))
local Bases = require(script.Parent:WaitForChild("Bases"))

local DefenseGuide = {}

-- display only
-- (2026-10-02, "이런 자막은 거의 안 보이는데 차라리 가판대들 크기를 키우고 자막도 크기를 키우지": were 12 × 10 and
-- 10 × 9 with every line squeezed into one row) bigger boards; a long line gets more rows (ROWS) and wraps
-- at a big size; every line's text at most TEXT_MAX pixels so they read alike
local BOARD_SIZE = Vector3.new(17, 17, 0.4) -- (2026-10-04: was 14 high; "간판을 늘려서라도 어떻게든 이해 잘되고")
local BOARD_BOTTOM = 1.5 -- studs over the ground
local POST_SIZE = Vector3.new(0.5, BOARD_BOTTOM + 17, 0.5)
local TEXT_MAX = { title = 70, head = 56, body = 46 } -- pixels (PIXELS_PER_STUD a stud)
local SIDE_GAP = 25 -- studs between the defense sign and the board (2026-10-01: was 2, in front of the arena it hid the fight; then 50, past the arena's edge; then a little back, 40;
-- 2026-10-02, "간판 위치가 가로등에 가려져 게다가 울타리 밖으로 나갔어": with the bigger boards the 🧪 board stood past the
-- fence (plot u 95-110, the fence at 105) behind the street lamp at u 100: now both inside, the 🧪 board's edge at u 95.5)
local SIGN_ABOVE_GROUND = 3.5 -- (MapBuilder) the defense sign's middle over the ground, if its posts are missing
local PIXELS_PER_STUD = 40
local COLOR_BOARD = Color3.fromRGB(45, 55, 75)
local COLOR_POST = Color3.fromRGB(110, 80, 55)
local COLOR_TITLE = Color3.fromRGB(255, 220, 90)
local COLOR_HEAD = Color3.fromRGB(150, 210, 255)
local COLOR_TEXT = Color3.new(1, 1, 1)
local TITLE_COLOR = Color3.fromRGB(150, 210, 255)
local ATTR_BOARD_SIZE = Vector3.new(15, 18, 0.4) -- (2026-10-04: was 13 high)
local ATTR_GAP = 2 -- studs between the guide board and the attribute board
local ATTR_TITLE_COLOR = Color3.fromRGB(255, 220, 120)
local ATTR_NEXT_COLOR = Color3.fromRGB(255, 160, 140)

local nextLabels = {} -- [base number] = the attribute board's "다음 승급전 보스" line
-- (2026-10-05) the moved boards: plot coordinates (Training's: u across, v in from the entrance) of the 📜 board's middle;
-- the 🧪 one beside it; both turned toward the arena's middle (MapBuilder: at(52.5, 111))
local GUIDE_U, BOARDS_V = 64, 8
local ARENA_U, ARENA_V = 52.5, 111
local PROP_CLEARANCE = 3 -- studs: a base decoration this near a moved board is taken away
-- the 🩺 board (where the 🧪 one was)
local ADVICE_TITLE_COLOR = Color3.fromRGB(255, 150, 150)
local ADVICE_HEAD_COLOR = Color3.fromRGB(255, 225, 120)
local ADVICE_FOOT_COLOR = Color3.fromRGB(170, 190, 220)
local adviceLabels = {} -- [base number] = { icon, head, body, foot }
local ADVICE_SHIFT = 7
local DAMAGE_BOARD_SIZE = Vector3.new(24, 20, 0.4)
local DAMAGE_GAP = 2.5
local DAMAGE_BOARD_COLOR = Color3.fromRGB(30, 36, 58)
local DAMAGE_TITLE_COLOR = Color3.fromRGB(255, 205, 90)
local adviceShown = {} -- [base number] = the advice to show (false: nobody's base; nil: no loss to show)

local function part(props, parent)
	local p = Instance.new("Part")
	p.Anchored = true
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Material = Enum.Material.WoodPlanks
	for k, v in pairs(props) do
		p[k] = v
	end
	p.Parent = parent
	return p
end

-- (2026-10-04, "공룡 속성도 표나 그림으로 그려서 알기 편하게 바꿔 글로 짜라락 써놓지 말고. 디펜스 레벨 간판도", "자세하게
-- 알았으면 좋겠다 싶은건 그냥 가까이 가서 눌러서 보게 하면 되잖아. 그렇다고 설명 개같이 하지말고 간판에") the boards are
-- pictures: tiles of a big emoji and a few words; the long story opens from a "📖 자세히 보기" prompt on each board
-- (StarterPlayerScripts/GuideBoards: its window)
local TILE_COLOR = Color3.fromRGB(62, 76, 104)
local TILE_GAP = 0.02 -- of the board
local PROMPT_RANGE = 14 -- studs
local ATTR_SHORT = { -- each attribute in a few words (the long one: Formulas.attributeText, in the window)
	Fire = "💥 펑! + 🔥 화상", Ice = "🧊 얼림 · 느리게", Electric = "⛓️ 여러 마리 찌릿",
	Water = "💦 젖게 → ⚡❄️ 더 세게", Earth = "👊 뒤로 밀기", Poison = "🟢 독 웅덩이", Neutral = "👑 보스에 세요",
}

local function title(gui, text, color, h)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = Enum.Font.GothamBlack
	l.TextScaled = true
	l.TextColor3 = color
	l.Text = text
	l.Position = UDim2.fromScale(0.04, 0.01)
	l.Size = UDim2.fromScale(0.92, h)
	local cap = Instance.new("UITextSizeConstraint")
	cap.MaxTextSize = TEXT_MAX.title
	cap.Parent = l
	l.Parent = gui
	return l
end

local function surface(part, parent)
	local gui = Instance.new("SurfaceGui")
	gui.AutoLocalize = false
	gui.Face = Enum.NormalId.Front
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud = PIXELS_PER_STUD
	gui.Parent = part
	return gui
end

local function prompt(part, kind)
	local p = Instance.new("ProximityPrompt")
	p.Name = "GuidePrompt"
	p.ActionText = "📖 자세히 보기"
	p.ObjectText = ""
	p.HoldDuration = 0
	p.RequiresLineOfSight = false
	p.MaxActivationDistance = PROMPT_RANGE
	p:SetAttribute("Kind", kind) -- (StarterPlayerScripts/GuideBoards)
	p.Parent = part
end

-- the defense board: a table, a row a reward - when (left) → what you get (right), from Config. (2026-10-04, "디펜스
-- 레벨 보상 바뀐거 뭐라는 건지 하나도 이해 안 돼": six picture tiles with a few words each read as riddles)
local TABLE_WHEN_SHARE = 0.42 -- of a row's width: the "when" cell
local TABLE_WHEN_COLOR = Color3.fromRGB(44, 54, 76)
local function cell(parent, text, x, w, color, bg)
	local f = Instance.new("Frame")
	f.BackgroundColor3 = bg or TILE_COLOR
	f.Position = UDim2.fromScale(x, 0)
	f.Size = UDim2.fromScale(w, 1)
	f.Parent = parent
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.15, 0)
	round.Parent = f
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = Enum.Font.GothamBlack
	l.TextScaled = true
	l.TextWrapped = true
	l.TextColor3 = color or COLOR_TEXT
	l.Text = text
	l.Position = UDim2.fromScale(0.04, 0.08)
	l.Size = UDim2.fromScale(0.92, 0.84)
	local cap = Instance.new("UITextSizeConstraint")
	cap.MaxTextSize = TEXT_MAX.body
	cap.Parent = l
	l.Parent = f
	return f, l
end

-- (2026-10-04, "디펜스 레벨 보상에 은 열쇠 1개 더 이런 식이면 은열쇠를 박아두라고. 열쇠도 열쇠 모델링을 넣고") the key's own
-- model at the cell's left (ReplicatedStorage.KeyModels, made by the Keys service after this one: waited for)
local KEY_VIEW_SHARE = 0.26 -- of the cell's width
local function keyPicture(f, label, gradeId)
	label.Position = UDim2.fromScale(KEY_VIEW_SHARE + 0.04, 0.08)
	label.Size = UDim2.fromScale(1 - KEY_VIEW_SHARE - 0.08, 0.84)
	local view = Instance.new("ViewportFrame")
	view.BackgroundTransparency = 1
	view.Position = UDim2.fromScale(0.02, 0.04)
	view.Size = UDim2.fromScale(KEY_VIEW_SHARE, 0.92)
	view.Ambient = Color3.fromRGB(190, 190, 190)
	view.LightColor = Color3.new(1, 1, 1)
	view.LightDirection = Vector3.new(-1, -1, -1)
	view.Parent = f
	task.spawn(function()
		local models = ReplicatedStorage:WaitForChild("KeyModels", 120)
		local source = models and models:WaitForChild("Key_" .. gradeId, 30)
		if not source or not view.Parent then
			return
		end
		local model = source:Clone()
		local cf, size
		if model:IsA("Model") then
			cf, size = model:GetBoundingBox()
		else
			cf, size = model.CFrame, model.Size
		end
		local far = math.max(size.X, size.Y, size.Z) * 1.5
		local camera = Instance.new("Camera")
		camera.FieldOfView = 40
		camera.CFrame = CFrame.lookAt(cf.Position + Vector3.new(far * 0.5, far * 0.3, far), cf.Position)
		camera.Parent = view
		view.CurrentCamera = camera
		model.Parent = view
	end)
end

local function defenseTiles(gui)
	local promo = Config.Defense.Promotion
	local top = Config.Rebirth.FirstTierLevels
	local rows = {
		{ "👑 보스 웨이브 깨면", string.format("🎁 공룡 상자 + 열쇠 %d개 (레벨 %d마다 +1개)", promo.KeysBase - promo.RoadKeys,
			promo.KeysEveryLevels), nil, "Normal" },
	}
	local milestones = {}
	for _, m in ipairs(promo.Milestones) do
		table.insert(milestones, m)
	end
	table.sort(milestones, function(x, y)
		return x.Every < y.Every
	end)
	for _, m in ipairs(milestones) do
		for _, t in ipairs(Config.Keys.Types) do
			if t.Id == m.Grade then
				local at = {}
				for level = m.Every, math.min(top, m.Every * 3), m.Every do
					table.insert(at, tostring(level))
				end
				if #at > 0 then
					table.insert(rows, { string.format("⭐ %s … 레벨", table.concat(at, " · ")), Formulas.promotionBoxName(t.Id),
						nil, t.Id })
				end
			end
		end
	end
	local levels = {}
	for _, sp in ipairs(Config.Species) do
		if not sp.UnlockRebirths and sp.UnlockLevel > 1 and not table.find(levels, sp.UnlockLevel) then
			table.insert(levels, sp.UnlockLevel)
		end
	end
	table.sort(levels)
	local first = {}
	for i = 1, math.min(3, #levels) do
		table.insert(first, tostring(levels[i]))
	end
	table.insert(rows, { string.format("🦖 %s … 레벨", table.concat(first, " · ")), "새 공룡이 뽑기에 나와요" })
	table.insert(rows, { "📈 레벨이 오를수록", "💰 돈 · 🔑 열쇠 · 🎁 상자 더 많이" })
	table.insert(rows, { string.format("🔄 %d 레벨", top), "환생! 더 좋은 등급 공룡", COLOR_TITLE })
	title(gui, "🛡️ 디펜스 레벨 보상", COLOR_TITLE, 0.1)
	local head = Instance.new("Frame")
	head.BackgroundTransparency = 1
	head.Position = UDim2.fromScale(TILE_GAP, 0.12)
	head.Size = UDim2.fromScale(1 - TILE_GAP * 2, 0.07)
	head.Parent = gui
	cell(head, "언제?", 0, TABLE_WHEN_SHARE - TILE_GAP / 2, COLOR_HEAD, COLOR_BOARD)
	cell(head, "받는 것", TABLE_WHEN_SHARE + TILE_GAP / 2, 1 - TABLE_WHEN_SHARE - TILE_GAP / 2, COLOR_HEAD, COLOR_BOARD)
	local y, bottom = 0.2, 0.98
	local h = (bottom - y - TILE_GAP * (#rows - 1)) / #rows
	for _, r in ipairs(rows) do
		local line = Instance.new("Frame")
		line.BackgroundTransparency = 1
		line.Position = UDim2.fromScale(TILE_GAP, y)
		line.Size = UDim2.fromScale(1 - TILE_GAP * 2, h)
		line.Parent = gui
		cell(line, r[1], 0, TABLE_WHEN_SHARE - TILE_GAP / 2, COLOR_HEAD, TABLE_WHEN_COLOR)
		local got, gotLabel = cell(line, r[2], TABLE_WHEN_SHARE + TILE_GAP / 2, 1 - TABLE_WHEN_SHARE - TILE_GAP / 2, r[3])
		if r[4] then -- (a key: its picture)
			keyPicture(got, gotLabel, r[4])
		end
		y += h + TILE_GAP
	end
end

-- the attribute board: a table, a row an attribute in its own color - 속성 | 하는 일 | 👑 이 보스에 세요 - so a boss's
-- weakness is on the row of the dino that beats it (2026-10-04, "공룡 속성도 약점저렇게 늘어놓은거 맘에 안들어": was a
-- separate line of "🔥→💧" tiles); at the bottom the owner's next boss (Defense writes it)
local ATTR_COLORS = {
	Fire = Color3.fromRGB(150, 70, 45), Ice = Color3.fromRGB(60, 110, 150), Electric = Color3.fromRGB(140, 120, 40),
	Water = Color3.fromRGB(45, 90, 160), Earth = Color3.fromRGB(110, 80, 50), Poison = Color3.fromRGB(80, 120, 60),
	Neutral = Color3.fromRGB(90, 90, 100),
}
local ATTR_COLUMNS = { 0.26, 0.48, 0.26 } -- of a row: the attribute, what it does, the boss it beats
local function attributeTiles(gui, index)
	local ids = Config.Defense.Boss.AttributeOrder
	local B = Config.Defense.Boss
	local beats = {} -- [attribute] = the boss attribute it is that boss's weakness for
	for _, id in ipairs(ids) do
		local w = B.Weakness[id]
		if w then
			beats[w] = beats[w] or {}
			table.insert(beats[w], id)
		end
	end
	title(gui, "🧪 공룡 속성", ATTR_TITLE_COLOR, 0.08)
	local function rowAt(y, h, cells, bg)
		local line = Instance.new("Frame")
		line.BackgroundTransparency = 1
		line.Position = UDim2.fromScale(TILE_GAP, y)
		line.Size = UDim2.fromScale(1 - TILE_GAP * 2, h)
		line.Parent = gui
		local x = 0
		for i, text in ipairs(cells) do
			local w = ATTR_COLUMNS[i] - (i < #cells and TILE_GAP / 2 or 0)
			cell(line, text, x, w, bg and COLOR_TEXT or COLOR_HEAD, bg or COLOR_BOARD)
			x += ATTR_COLUMNS[i] + TILE_GAP / 2
		end
	end
	rowAt(0.1, 0.06, { "속성", "하는 일", "👑 이 보스에 세요" })
	local y, bottom = 0.17, 0.88
	local h = (bottom - y - TILE_GAP * (#ids - 1)) / #ids
	for _, id in ipairs(ids) do
		local a = Config.Attributes[id]
		local bosses = {}
		for _, boss in ipairs(beats[id] or {}) do
			table.insert(bosses, Config.Attributes[boss].Icon)
		end
		rowAt(y, h, { a.Icon .. " " .. a.Name, ATTR_SHORT[id] or "", #bosses > 0 and table.concat(bosses, " ") .. " 보스" or "-" },
			ATTR_COLORS[id] or TILE_COLOR)
		y += h + TILE_GAP
	end
	local nextLine = title(gui, "", ATTR_NEXT_COLOR, 0.08)
	nextLine.Position = UDim2.fromScale(0.04, 0.9)
	nextLabels[index] = nextLine
end

-- the 🩺 board's words for a base: an advice table (Defense), nil (the owner has no lost fight to show) or false (no owner)
local function drawAdvice(index)
	local l = adviceLabels[index]
	if not l then
		return
	end
	local a = adviceShown[index]
	if a then
		l.icon.Text = a.Icon or "⚔️"
		l.head.Text = a.Head or ""
		l.body.Text = a.Body or ""
		l.foot.Text = string.format("👑 %s 보스 · %d번 졌어요 · 깨면 지워져요", Formulas.levelText(a.Level or 1), a.Tries or 1)
	elseif a == nil then
		l.icon.Text = "✅"
		l.head.Text = "진 보스 웨이브가 없어요"
		l.body.Text = "보스 웨이브에서 지면 여기에" .. "\n" .. "가장 부족한 점이 나와요"
		l.foot.Text = ""
	else
		local folder = Bases.folder(index)
		l.icon.Text = "🩺"
		l.head.Text = folder and folder:GetAttribute("OwnerUserId") and "⏳ 불러오는 중" or "빈 기지"
		l.body.Text = ""
		l.foot.Text = ""
	end
end

local function adviceBoard(gui, index)
	title(gui, "🩺 보스 분석", ADVICE_TITLE_COLOR, 0.08)
	local sub = title(gui, "가장 부족한 것", COLOR_HEAD, 0.05)
	sub.Position = UDim2.fromScale(0.04, 0.1)
	local function label(y, h, max, color)
		local l = Instance.new("TextLabel")
		l.BackgroundTransparency = 1
		l.Font = Enum.Font.GothamBlack
		l.TextScaled = true
		l.TextWrapped = true
		l.TextColor3 = color
		l.Text = ""
		l.Position = UDim2.fromScale(0.05, y)
		l.Size = UDim2.fromScale(0.9, h)
		local cap = Instance.new("UITextSizeConstraint")
		cap.MaxTextSize = max
		cap.Parent = l
		l.Parent = gui
		return l
	end
	adviceLabels[index] = {
		icon = label(0.17, 0.22, TEXT_MAX.title * 2.2, COLOR_TEXT),
		head = label(0.41, 0.11, TEXT_MAX.title, ADVICE_HEAD_COLOR),
		body = label(0.54, 0.33, TEXT_MAX.body, COLOR_TEXT),
		foot = label(0.9, 0.07, TEXT_MAX.body * 0.8, ADVICE_FOOT_COLOR),
	}
	drawAdvice(index)
end

-- (2026-10-05) a base's 🩺 board (Defense): advice (a table), nil (the owner has no loss to show) or false (nobody's base)
function DefenseGuide.showAdvice(index, advice)
	if not index then
		return
	end
	adviceShown[index] = advice
	drawAdvice(index)
end

-- (2026-10-05) a point of the plot (Training's coordinates), from the base's SafeZone
local function plotPoint(folder)
	local zone = folder:FindFirstChild("SafeZone")
	local flat = zone and Vector3.new(zone.Position.X, 0, zone.Position.Z)
	if not flat or flat.Magnitude < 1e-3 then
		return nil
	end
	local out = flat.Unit
	local right = out:Cross(Vector3.yAxis).Unit
	local front = flat - out * Config.Map.PlotDepth / 2
	return function(u, v)
		return front + right * u + out * v
	end, zone
end

local function build(folder, holder, index)
	local sign = folder:FindFirstChild("DefenseSign")
	if not sign or not sign:IsA("BasePart") then
		return false
	end
	-- beside the sign, well off to the side away from the farm sign (the arena's fight stays in view)
	local farm = folder:FindFirstChild("FarmSign")
	local step = sign.Size.X / 2 + SIDE_GAP + BOARD_SIZE.X / 2
	local a, b = sign.CFrame * CFrame.new(step, 0, 0), sign.CFrame * CFrame.new(-step, 0, 0)
	local spot = a
	if farm and (b.Position - farm.Position).Magnitude > (a.Position - farm.Position).Magnitude then
		spot = b
	end
	-- on the ground: the plot's floor is flat, so the sign's posts' feet (MapBuilder stands them on it) give
	-- its height. (The sign's own bottom is 2.2 studs up on the posts, which left the board floating; a
	-- ray down from above hit other things first - the plot's invisible SafeZone box, then the arena's
	-- big collision box - and put it high in the sky.)
	local ground = sign.Position.Y - SIGN_ABOVE_GROUND
	for _, d in ipairs(folder:GetDescendants()) do
		if d.Name == "DefenseSignPost" and d:IsA("BasePart") then
			ground = d.Position.Y - d.Size.Y / 2
			break
		end
	end
	local oldBase = CFrame.new(spot.Position.X, ground, spot.Position.Z) * spot.Rotation
	local model = Instance.new("Model")
	model.Name = "DefenseGuide" .. folder.Name
	-- (2026-10-05) the 🩺 board where the 🧪 one stood: on the far side of the old 📜 spot from the sign
	local away = (spot.Position - sign.Position).Unit
	local adviceBase = oldBase + away * ADVICE_SHIFT
	local adviceBoardPart = part({ Name = "AdviceBoard", Size = ATTR_BOARD_SIZE, Color = COLOR_BOARD,
		CFrame = adviceBase * CFrame.new(0, BOARD_BOTTOM + ATTR_BOARD_SIZE.Y / 2, 0) }, model)
	for _, x in ipairs({ -ATTR_BOARD_SIZE.X / 2 + 0.6, ATTR_BOARD_SIZE.X / 2 - 0.6 }) do
		part({ Name = "Post", Size = Vector3.new(POST_SIZE.X, BOARD_BOTTOM + ATTR_BOARD_SIZE.Y, POST_SIZE.Z), Color = COLOR_POST,
			CFrame = adviceBase * CFrame.new(x, (BOARD_BOTTOM + ATTR_BOARD_SIZE.Y) / 2, 0.3) }, model)
	end
	adviceBoard(surface(adviceBoardPart), index)
	local damageBase = adviceBase + away * (ATTR_BOARD_SIZE.X / 2 + DAMAGE_GAP + DAMAGE_BOARD_SIZE.X / 2)
	local damageBoard = part({ Name = "DamageBoard", Size = DAMAGE_BOARD_SIZE, Color = DAMAGE_BOARD_COLOR,
		Material = Enum.Material.SmoothPlastic, CFrame = damageBase * CFrame.new(0, BOARD_BOTTOM + DAMAGE_BOARD_SIZE.Y / 2, 0) }, model)
	damageBoard:SetAttribute("BaseIndex", index)
	for _, x in ipairs({ -DAMAGE_BOARD_SIZE.X / 2 + 0.6, DAMAGE_BOARD_SIZE.X / 2 - 0.6 }) do
		part({ Name = "Post", Size = Vector3.new(POST_SIZE.X, BOARD_BOTTOM + DAMAGE_BOARD_SIZE.Y, POST_SIZE.Z), Color = COLOR_POST,
			CFrame = damageBase * CFrame.new(x, (BOARD_BOTTOM + DAMAGE_BOARD_SIZE.Y) / 2, 0.3) }, model)
	end
	prompt(damageBoard, "DamageBoard")
	-- the 📜 and 🧪 boards at the plot's front, past the training ground, turned to the arena (else where they were)
	local at, zone = plotPoint(folder)
	local base = damageBase + away * (DAMAGE_BOARD_SIZE.X / 2 + ATTR_GAP + BOARD_SIZE.X / 2)
	local attrBase = base + away * ((BOARD_SIZE.X + ATTR_BOARD_SIZE.X) / 2 + ATTR_GAP)
	if at then
		local width = (BOARD_SIZE.X + ATTR_BOARD_SIZE.X) / 2 + ATTR_GAP
		local mid = at(GUIDE_U + width / 2, BOARDS_V)
		local arena = at(ARENA_U, ARENA_V)
		local turn = CFrame.lookAt(mid, Vector3.new(arena.X, mid.Y, arena.Z)).Rotation
		local function onGround(p)
			return CFrame.new(p.X, Bases.groundBelow(Vector3.new(p.X, zone.Position.Y, p.Z), { zone }), p.Z) * turn
		end
		base = onGround(mid - turn.RightVector * width / 2)
		attrBase = onGround(mid + turn.RightVector * width / 2)
		-- the base's decor (MapBuilder's rocks, bushes along the fence) never stands in a board
		local props = folder:FindFirstChild("BaseProps")
		for _, prop in ipairs(props and props:GetChildren() or {}) do
			local cf = prop:IsA("Model") and prop:GetBoundingBox() or prop:IsA("BasePart") and prop.CFrame
			if cf then
				for _, c in ipairs({ { base, BOARD_SIZE.X }, { attrBase, ATTR_BOARD_SIZE.X } }) do
					local gap = Vector3.new(cf.Position.X - c[1].Position.X, 0, cf.Position.Z - c[1].Position.Z).Magnitude
					if gap < c[2] / 2 + PROP_CLEARANCE then
						prop:Destroy()
						break
					end
				end
			end
		end
	end
	local board = part({ Name = "Board", Size = BOARD_SIZE, Color = COLOR_BOARD,
		CFrame = base * CFrame.new(0, BOARD_BOTTOM + BOARD_SIZE.Y / 2, 0) }, model)
	for _, x in ipairs({ -BOARD_SIZE.X / 2 + 0.6, BOARD_SIZE.X / 2 - 0.6 }) do
		part({ Name = "Post", Size = POST_SIZE, Color = COLOR_POST, CFrame = base * CFrame.new(x, POST_SIZE.Y / 2, 0.3) }, model)
	end
	defenseTiles(surface(board))
	prompt(board, "DefenseGuide")
	local attr = part({ Name = "AttributeBoard", Size = ATTR_BOARD_SIZE, Color = COLOR_BOARD,
		CFrame = attrBase * CFrame.new(0, BOARD_BOTTOM + ATTR_BOARD_SIZE.Y / 2, 0) }, model)
	for _, x in ipairs({ -ATTR_BOARD_SIZE.X / 2 + 0.6, ATTR_BOARD_SIZE.X / 2 - 0.6 }) do
		part({ Name = "Post", Size = Vector3.new(POST_SIZE.X, BOARD_BOTTOM + ATTR_BOARD_SIZE.Y, POST_SIZE.Z), Color = COLOR_POST,
			CFrame = attrBase * CFrame.new(x, (BOARD_BOTTOM + ATTR_BOARD_SIZE.Y) / 2, 0.3) }, model)
	end
	attributeTiles(surface(attr), index)
	prompt(attr, "AttributeGuide")
	model.Parent = holder
	Bases.title(board, "📜 디펜스 보상", TITLE_COLOR)
	Bases.title(attr, "🧪 공룡 속성", ATTR_TITLE_COLOR)
	Bases.title(adviceBoardPart, "🩺 보스 분석", ADVICE_TITLE_COLOR)
	Bases.title(damageBoard, "📊 공룡 피해", DAMAGE_TITLE_COLOR)
	return true
end

-- the attribute board's last line for a base (nil before the boards are built): Defense writes the owner's
-- next promotion boss attribute there
function DefenseGuide.nextBossLabel(index)
	return index and nextLabels[index]
end

function DefenseGuide.init()
	local map = Workspace:FindFirstChild("Map")
	if not map then
		return
	end
	local holder = map:FindFirstChild("DefenseGuides") or Instance.new("Folder")
	holder.Name = "DefenseGuides"
	holder:ClearAllChildren()
	holder.Parent = map
	local made = 0
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder and build(folder, holder, index) then
			made += 1
			folder:GetAttributeChangedSignal("OwnerUserId"):Connect(function()
				drawAdvice(index)
			end)
		end
	end
	print(string.format("[DefenseGuide] 디펜스 보상 게시판 %d개", made))
end

return DefenseGuide
