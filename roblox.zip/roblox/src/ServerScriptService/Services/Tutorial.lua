--[[
Tutorial: a new player's first minutes (design 10). Coco (StarterPlayerScripts/Tutorial) shows one thing at a time;
this service keeps the state (profile.Tutorial, rules in TutorialLogic) and decides when a step is done.

(2026-10-03, "튜토리얼 필드를 새로 만들고 … 거기로 보내서 체험할 수 있는거 다해보게 하자", chosen: 나만의 튜토리얼 서버;
was the player's own base on the shared map since 2026-10-01) The steps run on a tutorial field (TutorialField: a server
of the player's own, on a save apart). This service plays two parts:
- On the main game: a player whose real save has not done the tutorial is sent to a field (TutorialLogic.mainAction).
  (2026-10-04) A first run never started is asked about first, after the language (player attribute TutorialAsk,
  Net request TutorialChoice): "no" marks it done with its reward still due, as a skip.
  When they come back, the field's result goes into the real save (TutorialLogic.applyField): done, and the first
  finish pays Config.Tutorial.Field.Reward and RewardLuckMinutes (player attribute TutorialWelcome "paid" / "done" /
  "skipped" for Coco's welcome-back card). 설정's replay (Net request TutorialReplay(part?)) sends them to a field again
  (no reward). If the trip can't be made, the real save is marked done so the game works ("failed").
- (2026-10-03, "30이나 걸려 튜토가??" → "그렇게 바꿔") the first run is the short core; the Lesson parts
  (Config.Tutorial.Parts) are learned later the same way as a part's replay (Net request TutorialReplay(part)), and
  the first finish of each pays its Reward when they come back (TutorialLogic.applyField; TutorialWelcome "lesson",
  TutorialLesson = the part). Player attributes LessonsDue (the lessons whose reward is still to come) and
  LessonsOffered (the ones Coco asked about; Net request LessonOffered(part) adds one), comma lists, for
  StarterPlayerScripts/Lessons and 설정.
- On a field: the steps. A fresh run starts from a new save (PlayerData.onPrepare: TutorialLogic.freshRun), so a
  replay plays everything for real; a step's Setup makes sure of what it needs (money, a water and an ice dino placed,
  spare dinos, food, a merge set, bombs) and brings the weather, the night, the night boss or a chest. The day and
  the weather hold still otherwise (DayNight.hold, Weather.hold). The end (the last card, or a held skip) saves and
  sends the player home (TutorialField.toMain).

- Steps (Config.Tutorial.Steps) end on game events the other services already report (Rewards.onAdd:
  Mine, Deposit, Draws, Place, KeysHome, Promotion, FruitPick: a fruit picked up after slapping a tree, Fruits), on reaching a spot (checked here every
  CHECK_EVERY: the key zone, the enhance stall, the farm sign, the ride pedestal, the key stall), on
  slapping the practice dummy (Combat.onSafeSlap) or when the client says so (Net request
  TutorialStepDone: the hatching, pressing 보상).
- The first run helps: nobody can hit the player, nor can they hit others (player attribute
  TutorialShield, Combat; only up to Config.Tutorial.ShieldUntilStep and ShieldMinutes after the first
  join), the promotion step is easier (TutorialEasy, Defense; only on EasyStep), the first draw gives a rare dino and the second an ice one
  (Gacha.setOverride), a key is made sure of / given (EnsureKeys, GiftKeys), the dummy drops a key and
  one is put in the player's hands at the center (CarryKeys). A replay (Net request TutorialReplay, from
  설정; the whole or one of Config.Tutorial.Parts) only shows the way: none of that.
- Net request TutorialSkip ends it (the client holds the skip button down first): a replay only of a part finished
  before, or of the whole with every part finished (2026-10-03; TutorialLogic.canSkip, player attribute
  TutorialCanSkip; the real save's finished parts come along: TutorialField joinData Done). (2026-10-04, "튜토리얼
  스킵도 가능하게 하자. 그리고 보상은 나중에 튜토리얼 다시하기로 다시 얻을 수 있게") the first run too: no reward then,
  the real save keeps it due (TutorialLogic.coreDue, player attribute TutorialCoreDue), and 설정's "처음부터 전부"
  (TutorialReplay with no part) plays the first run again (joinData Again, the real save's ReplayCore); finished, it
  pays the first run's reward.
- (2026-10-02, "다시하기 한 사람은 직접 하는 부분은 이미 돼 있으면 넘어가게") a replay's hands-on steps finished before,
  and a step whose Needs (Config.Tutorial) is not met now (no dino placed, no combo team), only show Coco's card
  (player attribute TutorialSkip "did" / "cant"); reading it moves on (TutorialStepDone).
- Player attributes for the client: TutorialStep (the step's Id), TutorialIndex, TutorialCount,
  TutorialTotal, TutorialTarget (Vector3: where the beam points), TutorialTargetKind (the Target name;
  "Mineral" is found by the client), TutorialReplay.
- The steps finished on a first run go to Roblox's onboarding funnel (AnalyticsService), to see where
  players stop.
- The practice dummy (ServerStorage.Assets Tutorial_Dummy, a plain stand-in without it) stands in the
  player's base while that step runs.
- Coco's and the egg's models (Guide_Coco, Coco_Egg) are copied to ReplicatedStorage.TutorialModels.
- Coco's tips after the tutorial (Config.Hints, StarterPlayerScripts/Hints; 2026-10-01): the ones already
  shown are kept in profile Hints and told to the client as player attribute HintsSeen ("Night,Boss,...");
  Net request HintSeen(id) adds one (only ids in Config.Hints, each once) and shows it as a Notice.
]]

local AnalyticsService = game:GetService("AnalyticsService")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Lang = require(Shared:WaitForChild("Lang"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local TutorialLogic = require(script.Parent:WaitForChild("TutorialLogic"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local Keys = require(script.Parent:WaitForChild("Keys"))
local Gacha = require(script.Parent:WaitForChild("Gacha"))
local Boxes = require(script.Parent:WaitForChild("Boxes"))
local Combat = require(script.Parent:WaitForChild("Combat"))
local Fruits = require(script.Parent:WaitForChild("Fruits"))
local TutorialField = require(script.Parent:WaitForChild("TutorialField"))
local LaunchGift = require(script.Parent:WaitForChild("LaunchGift"))
local ProfileLogic = require(script.Parent:WaitForChild("ProfileLogic"))
local DayNight = require(script.Parent:WaitForChild("DayNight"))
local Weather = require(script.Parent:WaitForChild("Weather"))
local Zombies = require(script.Parent:WaitForChild("Zombies"))
local Treasure = require(script.Parent:WaitForChild("Treasure"))
local Bombs = require(script.Parent:WaitForChild("Bombs"))
local Defense = require(script.Parent:WaitForChild("Defense"))
local SpeedPads = require(script.Parent:WaitForChild("SpeedPads"))

local Tutorial = {}

local CHECK_EVERY = 0.5 -- seconds between the checks of where tutorial players are
local LANGUAGE_WAIT = 120 -- seconds the first-join language picker waits before going on in English
local INTRO_WAIT = 120
local INTRO_WAIT_MORE = 5
local cinemaUntil = {}
local introRuns = {}
local DUMMY_HIT_SLACK = 3 -- studs past the slap's reach that still hit the dummy (it is wide)
local DUMMY_HEIGHT = 4 -- the stand-in dummy's height
local DUMMY_REMOVE_DELAY = 1.5 -- seconds the dummy stays after its last slap (the hit shows)
local CENTER_SLACK = 5 -- studs past the key zone's edge that count as there
local MODEL_NAMES = { "Guide_Coco", "Coco_Egg", "Fx_BoneStar" } -- copied for the clients

local dummies = {} -- [player] = the dummy model
local choices = {} -- [player] = true / false: the answer to "튜토리얼 할까요?" (TutorialAsk)
local chestSpots = {} -- [player] = where the chest step's chest stands
local padSpots = {} -- [player] = where the speed pad step's pad lies
local FIELD = Config.Tutorial.Field

local function onField()
	return TutorialField.isField()
end

-- the help a run gets (keys made sure of, fixed draws, the dummy's key, the key in hand, the easier promotion):
-- every run on a field (a fresh save each time), only the first otherwise
local function helped(t)
	return onField() or TutorialLogic.firstRun(t)
end
local lastSearch = {} -- [player] = os.clock() of the last "carry home" check

local function state(player)
	local profile = PlayerData.get(player)
	return profile and profile.Tutorial
end

local function active(player)
	local t = state(player)
	return onField() and t ~= nil and not t.Done -- (the steps run on a tutorial field only)
end

local function assets()
	return ServerStorage:FindFirstChild("Assets")
end

-- where a named spot of the player's base is (nil if not there)
local function baseSpot(player, name)
	local folder = Bases.folderOf(player)
	local inst = folder and folder:FindFirstChild(name, true)
	return inst and Bases.position(inst)
end

local function centerSpot()
	return Vector3.new(0, Bases.groundBelow(Vector3.new(0, 60, 0), {}), 0)
end

local function homeSpot(player)
	local c = player:GetAttribute("BaseCenter")
	return typeof(c) == "Vector3" and c or nil
end

-- the spot a step's Target / Reach names
local function spotOf(player, name)
	if name == "Center" then
		return centerSpot()
	elseif name == "Home" then
		return homeSpot(player)
	elseif name == "Dummy" then
		local d = dummies[player]
		return d and d.Parent and d:GetPivot().Position or nil
	elseif name == "DepositBin" then
		return baseSpot(player, "Base_DepositBin")
	elseif name == "Mineral" then
		return nil -- (the client finds the nearest one)
	elseif name == "FruitTree" then -- (2026-10-02) the fruit tree nearest the base's middle (Fruits)
		local home = homeSpot(player)
		return home and Fruits.nearestTree(home)
	elseif name == "Chest" then
		return chestSpots[player]
	elseif name == "SpeedPad" then
		return padSpots[player]
	elseif name == "Zombie" then
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		return root and Zombies.nearest(root.Position)
	elseif name == "Boss" then
		return Zombies.bossAt()
	elseif name == "AttributeBoard" then -- (DefenseGuide: beside the base's defense guide, in Map.DefenseGuides)
		local folder = Bases.folderOf(player)
		local guides = folder and Workspace:FindFirstChild("Map") and Workspace.Map:FindFirstChild("DefenseGuides")
		local guide = guides and guides:FindFirstChild("DefenseGuide" .. folder.Name)
		local board = guide and guide:FindFirstChild("AttributeBoard", true)
		return board and Bases.position(board)
	end
	return baseSpot(player, name)
end

-- ---------------------------------------------------------------------------
-- The practice dummy
-- ---------------------------------------------------------------------------

local function removeDummy(player)
	local d = dummies[player]
	dummies[player] = nil
	if d then
		d:Destroy()
	end
end

local function standIn()
	local model = Instance.new("Model")
	local body = Instance.new("Part")
	body.Name = "Body"
	body.Size = Vector3.new(1.6, DUMMY_HEIGHT, 1.6)
	body.Color = Color3.fromRGB(216, 178, 122)
	body.Anchored = true
	body.Parent = model
	model.PrimaryPart = body
	return model
end

local function placeDummy(player)
	removeDummy(player)
	local folder = Bases.folderOf(player)
	local zone = folder and folder:FindFirstChild("SafeZone")
	if not zone then
		return
	end
	local t = Config.Tutorial
	local look = Vector3.new(zone.CFrame.LookVector.X, 0, zone.CFrame.LookVector.Z).Unit -- from the entrance inward
	local right = Vector3.new(zone.CFrame.RightVector.X, 0, zone.CFrame.RightVector.Z).Unit
	local spot = Vector3.new(zone.Position.X, zone.Position.Y, zone.Position.Z) + look * (t.DummyDistance - zone.Size.Z / 2)
		+ right * t.DummySide
	local source = assets() and assets():FindFirstChild("Tutorial_Dummy", true)
	local model = source and source:Clone() or standIn()
	model.Name = "TutorialDummy"
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored = true
			d.CanCollide = false
		end
	end
	local ground = Bases.groundBelow(spot, { model })
	local base = Vector3.new(spot.X, ground, spot.Z)
	model:PivotTo(CFrame.lookAt(base, base - look)) -- facing the entrance
	local cf, size = model:GetBoundingBox()
	model:PivotTo(model:GetPivot() + Vector3.new(0, ground - (cf.Position.Y - size.Y / 2), 0)) -- standing on the ground
	model.Parent = folder
	dummies[player] = model
end

-- ---------------------------------------------------------------------------
-- State → the client, and what a step does when it starts
-- ---------------------------------------------------------------------------

local function publish(player)
	local t = state(player)
	local s, i = nil, nil
	if t and onField() then -- (the main game shows no steps: they run on the field)
		s, i = TutorialLogic.current(t)
	end
	player:SetAttribute("TutorialStep", s and s.Id or nil)
	player:SetAttribute("TutorialIndex", i)
	player:SetAttribute("TutorialCount", s and t.Count or nil)
	player:SetAttribute("TutorialTotal", s and #Config.Tutorial.Steps or nil)
	player:SetAttribute("TutorialReplay", s and t.Replay or nil)
	player:SetAttribute("TutorialSkip", s and t.Skip or nil)
	-- (2026-10-03) the skip button only for a replay of what was finished before (TutorialLogic.canSkip)
	player:SetAttribute("TutorialCanSkip", (s and TutorialLogic.canSkip(t)) or nil)
	local first = t ~= nil and helped(t)
	local c = Config.Tutorial
	local profile = PlayerData.get(player)
	local fresh = profile ~= nil and os.time() - (profile.Stats.FirstJoin or 0) < c.ShieldMinutes * 60
	local shield = first and i ~= nil and i <= (TutorialLogic.index(c.ShieldUntilStep) or 0) and fresh
	player:SetAttribute("TutorialShield", shield or nil)
	player:SetAttribute("TutorialEasy", (first and s ~= nil and s.Id == c.EasyStep) or nil)
	local target = s and s.Target
	player:SetAttribute("TutorialTargetKind", target)
	player:SetAttribute("TutorialTarget", target and spotOf(player, target) or nil)
end

-- does the player have what the step needs (Config.Tutorial: Needs)?
local function hasNeeds(profile, needs)
	if not needs then
		return true
	end
	local byId = {}
	for _, u in ipairs(profile.Units) do
		byId[u.Id] = u
	end
	local placed, attributes = 0, {}
	for id in pairs(profile.Placed) do
		local unit = byId[id]
		if unit then
			placed += 1
			attributes[Formulas.species(unit.Species).Attribute] = true
		end
	end
	if needs == "Placed" then
		return placed > 0
	elseif needs == "ComboTeam" then
		return attributes.Water == true and (attributes.Ice == true or attributes.Electric == true)
	end
	return true
end

-- ---------------------------------------------------------------------------
-- A step's Setup on the field (Config.Tutorial.Steps): what it makes sure of as it starts
-- ---------------------------------------------------------------------------

-- a spot just outside the base's entrance, `out` studs onto the battlefield
local function outsideGate(player, out)
	local folder = Bases.folderOf(player)
	local zone = folder and folder:FindFirstChild("SafeZone")
	if not zone then
		return nil
	end
	local look = Vector3.new(zone.CFrame.LookVector.X, 0, zone.CFrame.LookVector.Z).Unit -- (from the entrance inward)
	local at = Vector3.new(zone.Position.X, 0, zone.Position.Z) - look * (zone.Size.Z / 2 + out)
	return Vector3.new(at.X, Bases.groundBelow(at + Vector3.new(0, 80, 0), {}), at.Z)
end

local function newUnit(p, species, rarity, size, level)
	local unit = { Id = "U" .. p.NextUnitId, Species = species, Rarity = rarity, Size = size or "Young",
		Level = level and level > 1 and level or nil, Exp = level and 0 or nil }
	p.NextUnitId += 1
	table.insert(p.Units, unit)
	Formulas.recordCollection(p, unit)
	return unit
end

local function firstOfAttribute(attribute)
	for _, sp in ipairs(Config.Species) do
		if sp.Attribute == attribute and sp.Theme ~= "Variant" and (sp.UnlockLevel or 1) <= 1 then
			return sp.Id
		end
	end
	for _, sp in ipairs(Config.Species) do
		if sp.Attribute == attribute and sp.Theme ~= "Variant" then
			return sp.Id
		end
	end
	return Config.Species[1].Id
end

local function spare(p, unit)
	return not p.Placed[unit.Id] and not p.Farm[unit.Id]
end

-- a place by the road for a unit, the best first (nil when none fits); after: only past this far along the road
local function edgeSpot(p, unit, after)
	local byId = {}
	for _, u in ipairs(p.Units) do
		byId[u.Id] = u
	end
	local others = {}
	for id, pos in pairs(p.Placed) do
		if byId[id] and id ~= unit.Id then
			table.insert(others, { X = pos.X, Z = pos.Z, Footprint = Formulas.unitStats(byId[id]).Footprint })
		end
	end
	local stats = Formulas.unitStats(unit)
	if Formulas.isSea(stats) then
		local at = Formulas.autoLayout({ { Id = unit.Id, Stats = stats } }, p.DefenseMap, others)[unit.Id]
		if at then
			return at.X, at.Z
		end
		return nil
	end
	local footprint = stats.Footprint
	local path = Formulas.lanePath(p.DefenseMap)
	for _, spot in ipairs(Formulas.layoutSpots(p.DefenseMap, Formulas.unitStats(unit).Reach, footprint)) do
		local _, along = Formulas.laneDistance(path, spot[1], spot[2])
		if along > (after or -1) and Formulas.placementFits(spot[1], spot[2], footprint, others, p.DefenseMap) then
			return spot[1], spot[2]
		end
	end
	return after and edgeSpot(p, unit) or nil
end

-- a 💧 water and an ❄️ ice dino by the road (the 조합 / 승급전 steps), the ice one further along: a fossil
-- wetted first meets the ice soon after
local function ensureTeam(p)
	local waterAlong = nil
	for _, attribute in ipairs({ "Water", "Ice" }) do
		local placed, owned = nil, nil
		for _, u in ipairs(p.Units) do
			if Formulas.species(u.Species).Attribute == attribute then
				if p.Placed[u.Id] then
					placed = u
				elseif not p.Farm[u.Id] then
					owned = owned or u
				end
			end
		end
		if not placed then
			local unit = owned or newUnit(p, firstOfAttribute(attribute), "Rare")
			local count = 0
			for _ in pairs(p.Placed) do
				count += 1
			end
			if count < Formulas.profileSlots(p) then
				local x, z = edgeSpot(p, unit, attribute == "Ice" and waterAlong or nil)
				if x then
					p.Placed[unit.Id] = { X = math.floor(x * 100 + 0.5) / 100, Z = math.floor(z * 100 + 0.5) / 100 }
					placed = unit
				end
			end
		end
		local at = placed and p.Placed[placed.Id]
		if attribute == "Water" and at then
			local _, along = Formulas.laneDistance(Formulas.lanePath(p.DefenseMap), at.X, at.Z)
			waterAlong = along
		end
	end
end

local function setup(player, s)
	local need = s.Setup
	if not need or not onField() then
		return
	end
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	if need.Money then
		local amount = need.Money
		if amount == "Shop" then
			amount = Formulas.nextPickaxePrice(profile.Upgrades.PickaxeTier, profile.DefenseLevel) or 0
		elseif amount == "Keys" then
			amount = Formulas.keyShopPrice(profile.DefenseLevel, "Normal") * Config.Gacha.KeyBuyCounts[1]
		elseif amount == "Slot" then
			amount = Formulas.nextSlotCost(profile.Upgrades.Slots, profile.DefenseLevel) or 0
		end
		if type(amount) == "number" and profile.Money < amount then
			PlayerData.addMoney(player, amount - profile.Money, "tutorial")
		end
	end
	PlayerData.update(player, function(p)
		if need.Team then
			ensureTeam(p)
		end
		if need.Fodder then
			local have = 0
			for _, u in ipairs(p.Units) do
				if spare(p, u) and u.Rarity == Config.Rarities[1].Id then
					have += 1
				end
			end
			for _ = have + 1, FIELD.Fodder do
				newUnit(p, Config.Species[1].Id, Config.Rarities[1].Id)
			end
		end
		if need.Food then -- (what was brought home first; topped up to the cheapest feed)
			local cheapest = nil
			for _, u in ipairs(p.Units) do
				local cost = Formulas.feedNeed(u)
				if cost and cost > 0 and not p.Farm[u.Id] then
					cheapest = math.min(cheapest or cost, cost)
				end
			end
			p.Fruit = math.max(p.Fruit or 0, cheapest or 0)
		end
		if need.MergeSet then
			local have = 0
			for _, u in ipairs(p.Units) do
				if spare(p, u) and u.Rarity == FIELD.MergeRarity and Formulas.unitLevel(u) >= Config.Merge.Level then
					have += 1
				end
			end
			for i = have + 1, Config.Merge.Count do
				newUnit(p, Config.Species[(i - 1) % 3 + 1].Id, FIELD.MergeRarity, "Young", Config.Merge.Level)
			end
		end
		if need.Spare then
			local any = false
			for _, u in ipairs(p.Units) do
				any = any or spare(p, u)
			end
			if not any then
				newUnit(p, Config.Species[1].Id, Config.Rarities[1].Id)
			end
		end
	end)
	player:SetAttribute("Fruit", PlayerData.get(player).Fruit)
	player:SetAttribute("UnitsVersion", (player:GetAttribute("UnitsVersion") or 0) + 1)
	if need.Bombs then
		for kind, n in pairs(FIELD.Bombs) do
			n = FIELD.BombsFull and Config.Bombs.MaxHeld or n -- (2026-10-03: full)
			local have = (PlayerData.get(player).Bombs or {})[kind] or 0
			if have < n then
				Bombs.give(player, kind, n - have)
			end
		end
	end
	if need.Night ~= nil and DayNight.isNight() ~= need.Night then
		DayNight.set(need.Night)
	end
	if need.Weather and Weather.current() ~= need.Weather then
		Weather.set(need.Weather)
	end
	-- a practice boss: FIELD.BossHealth health (2026-10-03: was FIELD.BossSlaps slaps' worth). (2026-10-03, "왜 아직도 튜토보스 체력이 50이야": the
	-- night set just above brings the real night boss up at full health, and this used to leave any boss that was up
	-- alone; now a boss stronger than the practice one is made the practice one)
	local practiceHp = FIELD.BossHealth
	if need.Boss and (not Zombies.bossAt() or Zombies.bossMaxHp() > practiceHp) then
		local at = outsideGate(player, FIELD.BossOut)
		if at then
			Zombies.testBoss(at, practiceHp)
		end
	end
	if need.StopChallenge then
		Defense.stopChallenge(player)
	end
	if need.SpeedPad then
		local at = outsideGate(player, FIELD.PadOut)
		if at then
			padSpots[player] = at
			SpeedPads.spawnAt(at)
		end
	end
	if need.Chest then
		local at = outsideGate(player, FIELD.ChestOut)
		if at then
			chestSpots[player] = at
			Treasure.spawnNow(at, "Money")
		end
	end
end

local function onEnter(player)
	local t = state(player)
	local s = t and TutorialLogic.current(t)
	local profile = PlayerData.get(player)
	if s and not t.Skip then
		setup(player, s)
		profile = PlayerData.get(player)
	end
	if s and s.Needs == "Carrying" and not t.Skip and (player:GetAttribute("CarriedFruit") or 0) == 0 then
		PlayerData.update(player, function(p) -- (picked inside the base: already food)
			TutorialLogic.markDone(p.Tutorial)
		end)
	elseif s and s.Needs and s.Needs ~= "Carrying" and not t.Skip and profile and not hasNeeds(profile, s.Needs) then
		PlayerData.update(player, function(p)
			TutorialLogic.markCant(p.Tutorial)
		end)
	end
	if s and s.Id == "Dummy" then
		placeDummy(player)
	else
		removeDummy(player)
	end
	if not s or not helped(t) then
		return
	end
	if s.EnsureKeys or s.GiftKeys then
		PlayerData.update(player, function(p)
			local have = Formulas.savedKeys(p, "Normal")
			local give = (s.GiftKeys or 0) + math.max(0, (s.EnsureKeys or 0) - have)
			if give > 0 then
				Formulas.addSavedKeys(p, "Normal", give)
			end
		end)
		if s.GiftKeys then
			Net.push(player, "Notice", "🎁 코코의 선물", string.format("열쇠 %d개!", s.GiftKeys))
		end
	end
end

-- the run is over (the last card, or a held skip): saved, then home to the main game
local function finished(player)
	removeDummy(player)
	chestSpots[player] = nil
	PlayerData.update(player, function(p)
		p.Tutorial.Finished = not p.Tutorial.Skipped
	end)
	PlayerData.saveNow(player)
	local t = state(player)
	Net.push(player, "Notice", "🏠 내 기지로 가요!", t and t.Skipped and t.Replay
		and "📖 배우기를 나왔어요! ⚙️ → 📖 코코에게 배우기로 언제든 다시 해요"
		or t and t.Skipped and "튜토리얼을 건너뛰었어요! 🎁 선물은 ⚙️ → 📖 코코에게 배우기를 끝까지 하면 받아요"
		or "🎉 튜토리얼 완료! 이제 진짜 시작이에요")
	task.delay(FIELD.LeaveDelay, function()
		if player.Parent and not TutorialField.toMain(player) then
			player:Kick("본 게임으로 가지 못했어요. 다시 들어와 주세요 (튜토리얼은 끝난 것으로 저장됐어요)")
		end
	end)
end

-- change the state (fn(t) -> true when a step ended), then tell the client and start the next step
local function change(player, fn)
	if not active(player) then
		return
	end
	local ended, first, endedIndex, endedId = false, false, nil, nil
	PlayerData.update(player, function(p)
		local t = p.Tutorial
		local s, i = TutorialLogic.current(t)
		first = TutorialLogic.firstRun(t) and not t.Again -- (a first run played again: not the funnel's)
		endedIndex, endedId = i, s and s.Id
		ended = fn(t) == true
	end)
	if not ended then
		publish(player) -- (the count moved)
		return
	end
	if first and endedIndex then
		pcall(function()
			AnalyticsService:LogOnboardingFunnelStepEvent(player, endedIndex, endedId)
		end)
	end
	if active(player) then
		onEnter(player)
	else
		finished(player)
	end
	publish(player)
end

-- ---------------------------------------------------------------------------
-- Steps that end on reaching a spot (and keys lost on the way home)
-- ---------------------------------------------------------------------------

local function checkPlayer(player)
	local t = state(player)
	local s = t and TutorialLogic.current(t)
	if not s then
		return
	end
	local profile = PlayerData.get(player)
	if player:GetAttribute("TutorialShield") and profile
		and os.time() - (profile.Stats.FirstJoin or 0) >= Config.Tutorial.ShieldMinutes * 60 then
		publish(player) -- (the shield's time is up)
	end
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if s.Target and s.Target ~= "Mineral" then
		local now = spotOf(player, s.Target)
		if now and player:GetAttribute("TutorialTarget") ~= now then
			player:SetAttribute("TutorialTarget", now) -- (a dummy placed, a base loaded)
		end
	end
	if s.Reach and root and not t.Skip and not (s.Info and (t.Count or 0) >= 1) then -- (an Info step: arrived, its card is up)
		local spot = spotOf(player, s.Reach)
		local range = s.Reach == "Center" and Config.Map.KeyZoneRadius + CENTER_SLACK or Config.Tutorial.ReachRange
		if spot and Vector3.new(root.Position.X - spot.X, 0, root.Position.Z - spot.Z).Magnitude <= range then
			change(player, function(st)
				return TutorialLogic.reached(st, s.Reach)
			end)
			if helped(t) and s.CarryKeys then
				Keys.give(player, s.CarryKeys, "Normal")
				Net.push(player, "Notice", "🎁 선물상자를 받았어!", "머리 위에 들고 기지로 가져가자")
			end
		end
	end
	-- the key to carry home was lost (a new central drop clears carried keys, or it fell): fetch another
	if s.Id == "CarryHome" and Keys.carried(player) == 0 and os.clock() - (lastSearch[player] or 0) > 3 then
		lastSearch[player] = os.clock()
		task.delay(2, function() -- (a key just brought home ends the step first)
			local again = state(player)
			local cur = again and TutorialLogic.current(again)
			if cur and cur.Id == "CarryHome" and Keys.carried(player) == 0 then
				PlayerData.update(player, function(p)
					p.Tutorial.Step = TutorialLogic.index("CenterKey") or p.Tutorial.Step
					p.Tutorial.Count = 0
				end)
				onEnter(player)
				publish(player)
			end
		end)
	end
end

-- ---------------------------------------------------------------------------

function Tutorial.intro(player)
	local run = {}
	introRuns[player] = run
	player:SetAttribute("CocoIntro", true)
	task.delay(INTRO_WAIT, function()
		while player.Parent and introRuns[player] == run and player:GetAttribute("CocoIntro") and cinemaUntil[player] do
			task.wait(INTRO_WAIT_MORE)
		end
		if player.Parent and introRuns[player] == run and player:GetAttribute("CocoIntro") then
			if PlayerData.get(player) then
				PlayerData.update(player, function(p)
					p.Tutorial.IntroSeen = Config.Tutorial.IntroVersion
				end)
			end
			player:SetAttribute("CocoIntro", nil)
			Rewards.add(player, "IntroDone", 1)
		end
	end)
end

-- the run ends here (a held skip; the Studio test command ;tutorialend whatever the run): saved, then home
function Tutorial.skip(player)
	if not active(player) then
		return
	end
	PlayerData.update(player, function(p)
		p.Tutorial.Skipped = true
		TutorialLogic.skip(p.Tutorial)
	end)
	finished(player)
	publish(player)
end

local cinemaFocus = {}

local function focusPart(player)
	local part = cinemaFocus[player]
	if part and part.Parent then
		return part
	end
	local map = Workspace:FindFirstChild("Map")
	local zone = map and map:FindFirstChild("KeyZone")
	local altar = zone and zone:FindFirstChild("Zone_KeyAltar")
	part = Instance.new("Part")
	part.Name = "CinemaFocus"
	part.Anchored, part.CanCollide, part.CanQuery, part.CanTouch = true, false, false, false
	part.Transparency = 1
	part.Size = Vector3.one
	part.Position = altar and altar:GetPivot().Position or Vector3.zero
	part.Parent = Workspace
	cinemaFocus[player] = part
	return part
end

local function dropFocus(player)
	player.ReplicationFocus = nil
	if cinemaFocus[player] then
		cinemaFocus[player]:Destroy()
		cinemaFocus[player] = nil
	end
end

function Tutorial.init()
	Net.onRequest("CinemaFocus", { "boolean" }, function(player, on)
		if on then
			player.ReplicationFocus = focusPart(player)
			local token = os.clock()
			cinemaUntil[player] = token
			task.delay(Config.Tutorial.CinemaFocusSeconds, function()
				if cinemaUntil[player] == token and player.Parent then
					cinemaUntil[player] = nil
					dropFocus(player)
				end
			end)
		else
			cinemaUntil[player] = nil
			dropFocus(player)
		end
	end)
	Net.onRequest("CinemaFocusAt", { "Vector3" }, function(player, at)
		if not cinemaUntil[player] or at.X ~= at.X or at.Y ~= at.Y or at.Z ~= at.Z or math.abs(at.Y) > Config.Map.Radius
			or Vector3.new(at.X, 0, at.Z).Magnitude > Config.Map.Radius then
			return
		end
		focusPart(player).Position = at
		player.ReplicationFocus = cinemaFocus[player]
	end)
	Players.PlayerRemoving:Connect(function(player)
		cinemaUntil[player] = nil
		introRuns[player] = nil
		if cinemaFocus[player] then
			cinemaFocus[player]:Destroy()
			cinemaFocus[player] = nil
		end
	end)
	-- the models the clients draw Coco and the egg with
	local folder = ReplicatedStorage:FindFirstChild("TutorialModels") or Instance.new("Folder")
	folder.Name = "TutorialModels"
	for _, name in ipairs(MODEL_NAMES) do
		local source = assets() and assets():FindFirstChild(name, true)
		if source and not folder:FindFirstChild(name) then
			source:Clone().Parent = folder
		elseif not source then
			warn(string.format("[Tutorial] ServerStorage.Assets에 %s 모델이 없어 코코를 대신 그려요", name))
		end
	end
	for _, name in pairs(Config.Story.Pictures) do
		local source = assets() and assets():FindFirstChild(name, true)
		if source and not folder:FindFirstChild(name) then
			source:Clone().Parent = folder
		elseif not source then
			warn(string.format("[Tutorial] ServerStorage.Assets에 %s 그림이 없어 마녀 대신 🧙를 보여요", name))
		end
	end
	folder.Parent = ReplicatedStorage

	-- Coco's tips: the ones already shown
	local tipIds = {}
	for _, tip in ipairs(Config.Hints.Tips) do
		tipIds[tip.Id] = tip.Text
	end
	-- (2026-10-03) the lessons for the client: still paying a reward, already offered
	local function mirrorLessons(player, profile)
		local due, offered = {}, {}
		for _, part in ipairs(Config.Tutorial.Parts) do
			if part.Lesson then
				if TutorialLogic.lessonDue(profile.Tutorial, part.Id) then
					table.insert(due, part.Id)
				end
				if profile.Tutorial.Offered and profile.Tutorial.Offered[part.Id] then
					table.insert(offered, part.Id)
				end
			end
		end
		player:SetAttribute("LessonsDue", table.concat(due, ","))
		player:SetAttribute("TutorialCoreDue", TutorialLogic.coreDue(profile.Tutorial) or nil) -- (2026-10-04)
		-- (2026-10-04, "클리어한 튜토리얼 파트는 회색버튼으로") the parts finished, for 설정's list
		player:SetAttribute("TutorialPartsDone", table.concat(TutorialLogic.mainPartsDone(profile.Tutorial), ","))
		player:SetAttribute("LessonsOffered", table.concat(offered, ","))
	end
	Net.onRequest("LessonOffered", { "string" }, function(player, id)
		local profile = PlayerData.get(player)
		local part = TutorialLogic.part(id)
		if onField() or not profile or not part or not part.Lesson then
			return
		end
		PlayerData.update(player, function(p)
			p.Tutorial.Offered = p.Tutorial.Offered or {}
			p.Tutorial.Offered[id] = true
		end)
		mirrorLessons(player, PlayerData.get(player))
	end)
	local function mirrorHints(player, profile)
		local seen = {}
		for id in pairs(profile.Hints or {}) do
			table.insert(seen, id)
		end
		table.sort(seen)
		player:SetAttribute("HintsSeen", table.concat(seen, ","))
	end
	Net.onRequest("HintSeen", { "string" }, function(player, id)
		local profile = PlayerData.get(player)
		if not tipIds[id] or not profile or (profile.Hints and profile.Hints[id]) then
			return
		end
		Net.push(player, "Notice", "🐣 코코의 팁", tipIds[id], nil, nil, id)
		PlayerData.update(player, function(p)
			p.Hints = p.Hints or {}
			p.Hints[id] = true
		end)
		mirrorHints(player, PlayerData.get(player))
	end)
	-- the field: a fresh run starts from a new save (the steps done before kept), and the day and weather hold still
	local fieldStarted = false
	PlayerData.onPrepare(function(player, profile)
		if not onField() then
			return nil
		end
		if not fieldStarted then
			fieldStarted = true
			DayNight.hold(true)
			Weather.hold(true)
		end
		local joinData = TutorialField.joinData(player)
		local language = Lang.NAMES[joinData.Language or ""] and joinData.Language or nil -- (the main game's choice)
		if TutorialLogic.fieldArrive(profile.Tutorial, joinData) == "resume" then
			-- (2026-10-03, "튜토리얼 도중에 나가면, 다음에 들어왔을때 그 중단부분부터 다시할 수 있게") the step it stopped
			-- at starts again (its setup and card again, what was done in it kept)
			profile.Settings.Language = language or profile.Settings.Language
			TutorialLogic.upgrade(profile.Tutorial)
			TutorialLogic.know(profile.Tutorial, joinData.Done) -- (the parts the real save knows finished: canSkip)
			TutorialLogic.settle(profile.Tutorial) -- (a first run saved before the lessons may stand on one)
			player:SetAttribute("TutorialOpening", "Resume")
			task.delay(3, function()
				if player.Parent then
					Net.push(player, "Notice", "📖 이어서 해요!", "▶️ 멈췄던 곳부터 다시 시작해요")
				end
			end)
			return nil
		end
		local fresh = ProfileLogic.new(Config)
		fresh.Settings.Language = language
		fresh.Tutorial = TutorialLogic.freshRun(profile.Tutorial, joinData, os.time())
		fresh.Stats.FirstJoin = os.time()
		if joinData.Replay and joinData.Part then
			player:SetAttribute("TutorialOpening", "Part")
		end
		if joinData.Again and not joinData.Replay then -- (2026-10-04) the skipped first run again: its reward at the end
			task.delay(3, function()
				if player.Parent then
					Net.push(player, "Notice", "🎁 튜토리얼 보상 받기", "끝까지 하면 🎁 튜토리얼 완료 보상! 여기서 얻은 것은 연습용이에요")
				end
			end)
		end
		if joinData.Replay then
			task.delay(3, function()
				if joinData.Lesson then -- (2026-10-03) a lesson not learned yet: its reward at the end
					Net.push(player, "Notice", "📖 코코에게 배우기", "끝까지 배우면 🎁 보상! 여기서 얻은 것은 연습용이에요")
				else
					Net.push(player, "Notice", "📖 튜토리얼 다시 하기", "📖 다시 하기는 보상이 없어요. 여기서 얻은 것은 연습용이에요")
				end
			end)
		end
		return fresh
	end)
	-- (2026-10-03, "게임 시작 시 언어부터 선택하게 해서 코코가 튜토리얼 말할 때도 언어가 설정돼서 나오게") a player who
	-- never chose a language picks one first (player attribute LanguagePick: StarterPlayerScripts/LanguagePick; Settings'
	-- SetLanguage clears it), waited for up to LANGUAGE_WAIT seconds
	local function pickLanguage(player)
		local profile = PlayerData.get(player)
		if not profile or profile.Settings.Language then
			return
		end
		player:SetAttribute("LanguagePick", true)
		local started = os.clock()
		while player.Parent and player:GetAttribute("LanguagePick") and os.clock() - started < LANGUAGE_WAIT do
			task.wait(0.2)
		end
		player:SetAttribute("LanguagePick", nil)
	end
	-- (2026-10-04, "처음에 언어 선택하고 튜토리얼 할지말지 누르는 창도 띄워주자. 네 아니요 하나 누르면 정말요? 라면서 한 번 더
	-- 체크해주고") then asked whether to play the tutorial (player attribute TutorialAsk: StarterPlayerScripts/TutorialAsk,
	-- which asks "정말요?" itself before sending Net request TutorialChoice(yes)); (2026-10-04, "3분 지나도 안 보내고 계속
	-- 기다리게 해") waited for as long as it takes: nobody goes to the field without saying yes. Returns the answer
	local function askTutorial(player)
		choices[player] = nil
		player:SetAttribute("TutorialAsk", true)
		while player.Parent and choices[player] == nil do
			task.wait(0.2)
		end
		player:SetAttribute("TutorialAsk", nil)
		local yes = choices[player] == true
		choices[player] = nil
		return yes
	end
	Tutorial.ask = askTutorial -- (Studio's ;tutorialask: TestCommands)
	Net.onRequest("ReplayIntro", {}, function(player)
		local profile = PlayerData.get(player)
		if not onField() and not active(player) and not player:GetAttribute("CocoIntro") and profile and profile.Graduated then
			Net.push(player, "IslandCinematic")
		end
	end)
	Net.onRequest("CocoIntroDone", {}, function(player)
		if player:GetAttribute("CocoIntro") and PlayerData.get(player) then
			PlayerData.update(player, function(p)
				p.Tutorial.IntroSeen = Config.Tutorial.IntroVersion
			end)
			Rewards.add(player, "IntroDone", 1)
		end
		player:SetAttribute("CocoIntro", nil)
	end)
	Net.onRequest("TutorialChoice", { "boolean" }, function(player, yes)
		if player:GetAttribute("TutorialAsk") then
			choices[player] = yes
		end
	end)

	-- the main game: send them to a field, or take in what a field run ended with
	local function onMainLoaded(player, profile)
		if profile.Tutorial.Done and (profile.Tutorial.ReplayAt or 0) == 0 then
			if (profile.Tutorial.IntroSeen or 0) < Config.Tutorial.IntroVersion then
				Tutorial.intro(player)
			end
			return
		end
		if RunService:IsStudio() and not PlayerData.isPersistent(player) then
			-- Studio without saves: no field to go to (TutorialField.decide), so the game as if it were done
			PlayerData.update(player, function(p)
				p.Tutorial.Done = true
			end)
			return
		end
		local field = TutorialField.fieldProfile(player.UserId)
		local fieldT = field and field.Tutorial
		local action = TutorialLogic.mainAction(profile.Tutorial, fieldT)
		if not player.Parent then
			return
		end
		if action == "apply" then
			local first = not profile.Tutorial.Done
			local pay = nil
			PlayerData.update(player, function(p)
				pay = TutorialLogic.applyField(p.Tutorial, fieldT)
				if pay == "Core" then
					p.LuckUntil = math.max(p.LuckUntil or 0, os.time()) + FIELD.RewardLuckMinutes * 60
				end
			end)
			if pay == "Core" then
				Rewards.grant(player, FIELD.Reward, "🎉 튜토리얼 완료 보상")
				player:SetAttribute("TutorialWelcome", "paid")
			elseif pay then -- (2026-10-03) a lesson learned the first time
				Rewards.grant(player, TutorialLogic.part(pay).Reward, "📖 배움 보상")
				player:SetAttribute("TutorialLesson", pay)
				player:SetAttribute("TutorialWelcome", "lesson")
			elseif first then
				player:SetAttribute("TutorialWelcome", fieldT.Skipped and "skipped" or "done")
			end
			mirrorLessons(player, PlayerData.get(player))
		elseif action == "field" then
			if not player.Parent then
				return
			end
			local first = not profile.Tutorial.Done
			if first and fieldT == nil and not Config.Tutorial.FirstRun then
				if player.Parent then
					PlayerData.update(player, function(p)
						p.Tutorial.Done = true
					end)
					mirrorLessons(player, PlayerData.get(player))
					Tutorial.intro(player)
				end
				return
			end
			-- (2026-10-04) a first run never started is asked about first; "no": done, its reward waiting for 설정's
			-- "처음부터 전부" (as a skip), and Coco's card says so (TutorialWelcome "skipped")
			if first and fieldT == nil and not askTutorial(player) then
				if player.Parent then
					PlayerData.update(player, function(p)
						p.Tutorial.Done = true
						if not p.Tutorial.Paid then
							p.Tutorial.Unpaid = true
						end
					end)
					mirrorLessons(player, PlayerData.get(player))
					player:SetAttribute("TutorialWelcome", "skipped")
				end
				return
			end
			if not player.Parent then
				return
			end
			player:SetAttribute("TutorialTravel", true) -- (the client: "튜토리얼 필드로 가는 중")
			local again = not first and profile.Tutorial.ReplayCore == true -- (2026-10-04: the first run again)
			local replay = not first and not again
			local language = PlayerData.get(player).Settings.Language or Lang.code(player)
			if not TutorialField.toField(player, { Replay = replay, Again = again, Part = profile.Tutorial.ReplayPart,
				Asked = profile.Tutorial.ReplayAt, Language = language, LaunchGift = LaunchGift.takeForField(player) })
				and player.Parent then
				player:SetAttribute("TutorialTravel", nil)
				PlayerData.update(player, function(p)
					p.Tutorial.Done = true
					p.Tutorial.ReplayAt, p.Tutorial.ReplayPart, p.Tutorial.ReplayCore = 0, nil, nil
					if first and not p.Tutorial.Paid then
						p.Tutorial.Unpaid = true -- (2026-10-04: its reward later, 설정's "처음부터 전부")
					end
				end)
				mirrorLessons(player, PlayerData.get(player))
				if first then
					player:SetAttribute("TutorialWelcome", "failed")
				end
				Net.push(player, "Notice", "🐣 튜토리얼", "튜토리얼 필드로 가지 못했어요. ⚙️ 설정 → 📖 코코에게 배우기로 다시 해 보세요")
			end
		elseif (profile.Tutorial.ReplayAt or 0) > 0 then
			PlayerData.update(player, function(p) -- (the replay asked has been played)
				p.Tutorial.ReplayAt, p.Tutorial.ReplayPart, p.Tutorial.ReplayCore = 0, nil, nil
			end)
		end
	end
	PlayerData.onLoaded(function(player, profile)
		mirrorHints(player, profile)
		if onField() then
			-- (Studio's first test: no language came with them; asked before the steps show, the opening waits for it)
			task.spawn(pickLanguage, player)
			if active(player) then
				onEnter(player)
			end
			publish(player)
		else
			publish(player)
			mirrorLessons(player, profile)
			onMainLoaded(player, profile)
		end
	end)
	Rewards.onAdd(function(player, kind, amount)
		-- (2026-10-03, "튜토도중 서버지연 4초 걸림": every reward event (each mining turn, each fossil kill, money…) went
		-- through PlayerData.update and woke every onChanged listener, several times a second in a fight) only the
		-- event the step now waits for
		local t = state(player)
		local s = t and TutorialLogic.current(t)
		if not s or s.Event ~= kind then
			return
		end
		change(player, function(t)
			return TutorialLogic.event(t, kind, amount)
		end)
	end)
	Boxes.setQuick(function()
		return onField() and Config.Boxes.TutorialSeconds or nil
	end)
	-- the first run's fixed draws
	Gacha.setOverride(function(player)
		local t = state(player)
		local s = t and TutorialLogic.current(t)
		if not s or not s.Forced or not helped(t) then
			return nil
		end
		local forced = { Rarity = s.Forced.Rarity }
		if s.Forced.Attribute then
			for _, sp in ipairs(Config.Species) do
				if sp.Attribute == s.Forced.Attribute and sp.Theme ~= "Variant" then -- (not a variant: better keys only)
					forced.Species = sp.Id -- the first one of that attribute (an early, friendly species)
					break
				end
			end
		end
		return forced
	end)
	-- slapping the practice dummy (it stands in the base, where a slap otherwise hits fossils)
	Combat.onSafeSlap(function(player, root, reach)
		local d = dummies[player]
		local t = state(player)
		local s = t and TutorialLogic.current(t)
		if not d or not d.Parent or not s or s.Id ~= "Dummy" then
			return nil
		end
		local at = d:GetPivot().Position
		if Vector3.new(at.X - root.Position.X, 0, at.Z - root.Position.Z).Magnitude > reach + DUMMY_HIT_SLACK then
			return nil
		end
		local first = helped(t)
		change(player, function(st)
			return TutorialLogic.event(st, "DummyHit", 1)
		end)
		local after = state(player)
		local now = after and TutorialLogic.current(after)
		if not now or now.Id ~= "Dummy" then -- that was the last slap: it drops a key, then goes
			if first then
				Keys.scatter(at, Keys.rollBoxes(Config.Tutorial.DummyDropKeys))
			end
			dummies[player] = d -- (kept a moment for the hit to show)
			task.delay(DUMMY_REMOVE_DELAY, function()
				if dummies[player] == d then
					removeDummy(player)
				else
					d:Destroy()
				end
			end)
		end
		return { at + Vector3.new(0, 2, 0) }
	end)

	Net.onRequest("TutorialStepDone", { "string" }, function(player, id)
		change(player, function(t)
			return TutorialLogic.clientDone(t, id)
		end)
	end)
	-- (2026-10-03, "튜토리얼 건너뛰기는 이미 그파트 완료한 사람만 가능하게") a replay only of what was finished before;
	-- (2026-10-04) the first run always (its reward later)
	Net.onRequest("TutorialSkip", {}, function(player)
		if not active(player) or not TutorialLogic.canSkip(state(player)) then
			return
		end
		Tutorial.skip(player)
	end)
	-- part: nil (the whole) or a Config.Tutorial.Parts Id (2026-10-02, "튜토리얼 다시보기 파트별로"); on the main
	-- game, to a field again (2026-10-03: no reward)
	Net.onRequest("TutorialReplay", { "any" }, function(player, part)
		local profile = PlayerData.get(player)
		if onField() or not profile or not profile.Tutorial.Done or player:GetAttribute("TutorialTravel") then
			return
		end
		if part ~= nil and (type(part) ~= "string" or not TutorialLogic.part(part)) then
			return
		end
		local asked = os.time()
		-- (2026-10-04) the whole, with the skipped first run's reward still due: the first run again, paying it
		local again = part == nil and TutorialLogic.coreDue(profile.Tutorial)
		PlayerData.update(player, function(p)
			p.Tutorial.ReplayAt, p.Tutorial.ReplayPart = asked, part
			p.Tutorial.ReplayCore = again or nil
		end)
		PlayerData.saveNow(player) -- (Studio comes back to it on the next run)
		player:SetAttribute("TutorialTravel", true)
		local lesson = part ~= nil and TutorialLogic.lessonDue(profile.Tutorial, part) or nil -- (the field says so)
		if not TutorialField.toField(player, { Replay = not again, Again = again, Part = part, Asked = asked,
			Language = Lang.code(player), Lesson = lesson, Done = TutorialLogic.mainPartsDone(profile.Tutorial),
			LaunchGift = LaunchGift.takeForField(player) })
			and player.Parent then
			player:SetAttribute("TutorialTravel", nil)
			PlayerData.update(player, function(p)
				p.Tutorial.ReplayAt, p.Tutorial.ReplayPart, p.Tutorial.ReplayCore = 0, nil, nil
			end)
			Net.push(player, "Notice", "🐣 튜토리얼", "⚠️ 튜토리얼 필드로 가지 못했어요. 잠시 뒤에 다시 해 보세요")
		end
	end)

	task.spawn(function()
		while true do
			task.wait(CHECK_EVERY)
			for _, player in ipairs(Players:GetPlayers()) do
				if active(player) then
					checkPlayer(player)
				end
			end
		end
	end)
	Players.PlayerRemoving:Connect(function(player)
		removeDummy(player)
		lastSearch[player] = nil
		choices[player] = nil
		chestSpots[player] = nil
		padSpots[player] = nil
	end)
end

return Tutorial
