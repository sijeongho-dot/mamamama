--[[
PlayerData: loads, holds and saves every player's profile (server only).

- Session lock (design 기술 원칙): a profile is only written by the server that holds its lock, so
  the same account playing on two servers never overwrites itself. See ProfileLogic.
- Joining while another server still holds the lock (2026-10-01: a player disconnected (277) and
  joined another server while the old one still counted them in, then was kicked "couldn't load"
  after about 30 seconds): the joining server asks the holder over MessagingService
  (Config.Data.ReleaseTopic) to let go. The holder disconnects the leftover player there (leaving saves
  and releases the lock) or, with no such player, just releases it. Meanwhile the player waits up to
  Config.Data.LoadWaitSeconds (player attribute DataWait: the client shows "loading" in LagCheck) before
  the kick; a lock not refreshed for SessionLockTimeout (a crashed server) is taken over.
- Saves every Config.Data.AutosaveInterval seconds, when the player leaves and when the server
  shuts down (BindToClose).
- If Studio has no DataStore access (Game Settings > Security > Enable Studio Access to API
  Services is off), the player plays with an unsaved profile and gets a notice.
- In Studio a save locked by an earlier test (stopped before it let go) or any other load failure
  (an unpublished place) never makes the player wait: an unsaved copy of the save (or a new one) at once.
- The client sees money, keys and level through leaderstats; it can change its own copy, but that
  never reaches the server or the save.

- (2026-10-03) On a tutorial field (TutorialField) every profile is the field's own save
  (Config.Tutorial.Field.StoreName), never the real one; in Studio TutorialField.decide reads the player's real
  save first to tell which this test is. PlayerData.onPrepare(fn) may swap a profile just loaded before anyone
  sees it (the Tutorial service starts a fresh field run).

Only server code changes a profile, and only through the functions below.
]]

local DataStoreService = game:GetService("DataStoreService")
local HttpService = game:GetService("HttpService")
local MessagingService = game:GetService("MessagingService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))
local ProfileLogic = require(script.Parent:WaitForChild("ProfileLogic"))
local TutorialField = require(script.Parent:WaitForChild("TutorialField"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))

local PlayerData = {}

local SESSION_ID = HttpService:GenerateGUID(false)
local mainStore = nil -- the DataStore, or nil when saving is not available
local fieldStore = nil -- (2026-10-03) the tutorial field's saves
local store = nil -- the one this server uses (set once the server knows whether it is a tutorial field)
local sessions = {} -- [player] = { profile, persistent, saving, joinedAt }
local releasing = {} -- [userId] = true while the save of a player who just left is still running
local loadedCallbacks = {}
local prepareCallbacks = {} -- PlayerData.onPrepare
local changedCallbacks = {}
local moneyCallbacks = {} -- PlayerData.onMoney
local leavingCallbacks = {}

local function storeKey(player)
	return "Player_" .. player.UserId
end
local function userKey(userId)
	return "Player_" .. userId
end

local function isNoAccessError(err)
	local text = tostring(err)
	return text:find("StudioAccessToApisNotAllowed") ~= nil or text:find("403") ~= nil
end

-- ---------------------------------------------------------------------------
-- leaderstats (what the client sees)
-- ---------------------------------------------------------------------------

local STATS = { -- leaderstats name -> profile field
	{ "돈", "Money" },
	{ "열쇠", "Keys" },
}
-- the defense level: leaderstats shows the tier's text ("🟢LV 7", Formulas.levelText); scripts read the
-- real level from the player's DefenseLevel attribute
local LEVEL_STAT = "레벨"

local function mirror(player, profile)
	local folder = player:FindFirstChild("leaderstats")
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = "leaderstats"
		folder.Parent = player
	end
	for _, stat in ipairs(STATS) do
		local value = folder:FindFirstChild(stat[1])
		if value and not value:IsA("StringValue") then
			value:Destroy()
			value = nil
		end
		if not value then
			value = Instance.new("StringValue")
			value.Name = stat[1]
			value.Parent = folder
		end
		value.Value = Formulas.shortNumber(profile[stat[2]])
		player:SetAttribute(stat[2], profile[stat[2]])
	end
	local level = folder:FindFirstChild(LEVEL_STAT)
	if level and not level:IsA("StringValue") then
		level:Destroy() -- (an IntValue before 2026-10-01)
		level = nil
	end
	if not level then
		level = Instance.new("StringValue")
		level.Name = LEVEL_STAT
		level.Parent = folder
	end
	player:SetAttribute("DefenseLevel", profile.DefenseLevel)
	level.Value = Formulas.levelText(profile.DefenseLevel, profile.Rebirths)
end

-- ---------------------------------------------------------------------------
-- Loading and saving
-- ---------------------------------------------------------------------------

-- ask the server holding this player's lock to let go (it answers in the ReleaseTopic subscriber)
local function askRelease(player, lock)
	if type(lock) ~= "table" or type(lock.Id) ~= "string" then
		return
	end
	local ok, err = pcall(function()
		MessagingService:PublishAsync(Config.Data.ReleaseTopic, { UserId = player.UserId, Holder = lock.Id })
	end)
	if not ok then
		warn(string.format("[PlayerData] %s: couldn't ask the other server to let go (%s)", player.Name, tostring(err)))
	end
end

local function load(player)
	TutorialField.decide(player) -- (Studio: the field or the main game, from this player's real save)
	store = TutorialField.isField() and fieldStore or mainStore
	if not store then
		return ProfileLogic.new(Config), false
	end
	local started = os.clock()
	local asked = false
	local attempt = 0
	while true do
		attempt += 1
		local result
		local ok, err = pcall(function()
			store:UpdateAsync(storeKey(player), function(stored)
				local newStored, r = ProfileLogic.claim(stored, SESSION_ID, os.time(), Config)
				result = r
				return newStored -- nil = write nothing (locked by another server)
			end)
		end)
		if ok and result and result.status == "ok" then
			return result.profile, true
		end
		if not ok and isNoAccessError(err) then
			return ProfileLogic.new(Config), false
		end
		local locked = ok and result and result.status == "locked"
		if RunService:IsStudio() and (locked or not ok) then
			-- (2026-10-02, "게임 캐릭터는 열쇠제단 쪽에 생성되고 나머지 전부 오작동") Studio never waits: a test
			-- stopped before its leaving save let go keeps the lock for SessionLockTimeout, and a place not
			-- published can't use DataStores at all. Waiting LoadWaitSeconds left the player at the altar
			-- with nothing working, so Studio plays at once on an unsaved copy of the save (or a new one)
			local stored = nil
			if locked then
				pcall(function()
					stored = store:GetAsync(storeKey(player))
				end)
			end
			local profile = ProfileLogic.new(Config)
			if type(stored) == "table" then
				profile = ProfileLogic.copy(stored)
				profile.Lock = nil
				profile = ProfileLogic.migrate(profile, Config)
			end
			if locked then
				warn(string.format("[PlayerData] Studio: 저장이 이전 테스트에 잠겨 있음(멈춘 테스트가 잠금을 못 풀었음, 최대 %d초 뒤 풀림) — 이번 테스트는 저장된 진행을 보여 주되 저장하지 않습니다", Config.Data.SessionLockTimeout))
			else
				warn(string.format("[PlayerData] Studio: 저장을 불러오지 못함(%s) — 이번 테스트는 새 데이터로, 저장하지 않습니다", tostring(err)))
			end
			return profile, false
		end
		if not player.Parent then
			return nil -- left while loading
		end
		if locked and not asked then
			asked = true
			task.spawn(askRelease, player, result.lock)
		end
		player:SetAttribute("DataWait", true)
		warn(string.format("[PlayerData] %s: load attempt %d failed (%s)", player.Name, attempt,
			locked and "saved on another server, asked it to let go" or tostring(err)))
		if os.clock() - started >= Config.Data.LoadWaitSeconds then
			return nil
		end
		task.wait(math.min(Config.Data.RetryDelay * attempt, Config.Data.RetryDelayMax))
	end
end

-- another server asks this one to let go of a player's save (see askRelease)
local function onReleaseAsked(message)
	local data = type(message) == "table" and message.Data
	if type(data) ~= "table" or data.Holder ~= SESSION_ID or type(data.UserId) ~= "number" then
		return
	end
	local player = Players:GetPlayerByUserId(data.UserId)
	if player and sessions[player] then
		-- the same account joined another server: this one is a leftover connection. Leaving saves and
		-- lets go (onPlayerRemoving)
		player:Kick("다른 서버에 다시 들어갔어요.")
		return
	end
	if player or releasing[data.UserId] then
		return -- still loading here, or the leaving save is running and lets go when done
	end
	-- nobody here: a lock left behind (the last save failed): let go of it if it is still ours
	pcall(function()
		store:UpdateAsync(userKey(data.UserId), function(stored)
			if type(stored) ~= "table" or type(stored.Lock) ~= "table" or stored.Lock.Id ~= SESSION_ID then
				return nil
			end
			stored.Lock = nil
			return stored
		end)
	end)
end

local function saveNow(player, release)
	local session = sessions[player]
	if not session or not session.persistent then
		return true
	end
	while session.saving do -- one save at a time per player
		task.wait()
	end
	session.saving = true
	local profile = ProfileLogic.copy(session.profile)
	local done, err = false, nil
	for attempt = 1, Config.Data.SaveAttempts do
		local ok, e = pcall(function()
			store:UpdateAsync(storeKey(player), function(stored)
				return ProfileLogic.save(stored, profile, SESSION_ID, os.time(), release, Config)
			end)
		end)
		if ok then
			done = true
			break
		end
		err = e
		task.wait(Config.Data.RetryDelay * attempt)
	end
	session.saving = false
	if not done then
		warn(string.format("[PlayerData] %s: save failed (%s)", player.Name, tostring(err)))
	end
	return done
end

-- the same account's earlier connection still here (a phone that lost its link and came straight back: AutoRejoin)
-- (sent off at once: leaving saves and lets go, onPlayerRemoving)
local function leftover(player)
	local found = false
	for other in pairs(sessions) do
		if other ~= player and other.UserId == player.UserId then
			found = true
			if other.Parent then
				other:Kick("다시 들어왔어요.")
			end
		end
	end
	return found
end

local function onPlayerAdded(player)
	-- rejoined this server before the leaving save finished, or (2026-10-05, AutoRejoin) before Roblox let the old
	-- connection go: its leaving save comes first, so this one loads what it saved
	local waitedFor = os.clock()
	while (releasing[player.UserId] or leftover(player)) and os.clock() - waitedFor < Config.Data.LoadWaitSeconds do
		task.wait(0.1)
	end
	local profile, persistent = load(player)
	if not player.Parent then -- left while loading: give the lock back right away
		if profile and persistent then
			sessions[player] = { profile = profile, persistent = true, saving = false, joinedAt = os.clock() }
			saveNow(player, true)
			sessions[player] = nil
		end
		return
	end
	player:SetAttribute("DataWait", nil)
	if not profile then
		player:Kick("저장된 데이터를 불러오지 못했어요. 1분쯤 뒤에 다시 들어와 주세요.")
		return
	end
	for _, fn in ipairs(prepareCallbacks) do
		profile = fn(player, profile) or profile
	end
	profile.Stats.Joins += 1
	profile.Stats.LastJoin = os.time()
	if profile.Stats.FirstJoin == 0 then
		profile.Stats.FirstJoin = profile.Stats.LastJoin
	end
	sessions[player] = { profile = profile, persistent = persistent, saving = false, joinedAt = os.clock() }
	mirror(player, profile)
	if not persistent then -- the client tells the player when it reads GetMyData (Saved = false)
		warn("[PlayerData] 저장 없이 플레이합니다: Studio에서 API 서비스 접근이 꺼져 있거나 DataStore를 쓸 수 없습니다.")
	end
	for _, fn in ipairs(loadedCallbacks) do
		-- (2026-10-04) each listener's work up to its first wait, timed (Watchdog: a stall on someone's join)
		local started = os.clock()
		task.spawn(fn, player, profile)
		if PlayerData.meter then
			PlayerData.meter("loaded", debug.info(fn, "s"), os.clock() - started)
		end
	end
end

local function onPlayerRemoving(player)
	local session = sessions[player]
	if not session then
		return
	end
	session.profile.Stats.PlayTime += math.floor(os.clock() - session.joinedAt)
	for _, fn in ipairs(leavingCallbacks) do
		task.spawn(fn, player, session.profile)
	end
	releasing[player.UserId] = true
	saveNow(player, true)
	sessions[player] = nil
	releasing[player.UserId] = nil
end

-- ---------------------------------------------------------------------------
-- Public API (server only)
-- ---------------------------------------------------------------------------

function PlayerData.init()
	local ok, result = pcall(function()
		return DataStoreService:GetDataStore(Config.Data.StoreName)
	end)
	mainStore = ok and result or nil
	local okField, field = pcall(function()
		return DataStoreService:GetDataStore(Config.Tutorial.Field.StoreName)
	end)
	fieldStore = okField and field or nil
	store = TutorialField.isField() and fieldStore or mainStore
	if not store then
		warn("[PlayerData] DataStore를 쓸 수 없어 저장 없이 진행합니다: " .. tostring(result))
	end

	if store then
		local subscribed, err = pcall(function()
			return MessagingService:SubscribeAsync(Config.Data.ReleaseTopic, onReleaseAsked)
		end)
		if not subscribed then
			warn("[PlayerData] 다른 서버의 저장 잠금 해제 요청을 못 받아요: " .. tostring(err))
		end
	end
	Players.PlayerAdded:Connect(onPlayerAdded)
	Players.PlayerRemoving:Connect(onPlayerRemoving)
	for _, player in ipairs(Players:GetPlayers()) do
		task.spawn(onPlayerAdded, player)
	end

	task.spawn(function() -- autosave
		while true do
			local list = {}
			for player in pairs(sessions) do
				table.insert(list, player)
			end
			if #list == 0 then
				task.wait(Config.Data.AutosaveInterval)
			end
			for _, player in ipairs(list) do
				task.wait(Config.Data.AutosaveInterval / #list)
				if sessions[player] then
					task.spawn(saveNow, player, false)
				end
			end
		end
	end)

	game:BindToClose(function()
		local pending = 0
		for player in pairs(sessions) do
			pending += 1
			task.spawn(function()
				saveNow(player, true)
				pending -= 1
			end)
		end
		local started = os.clock()
		while pending > 0 and os.clock() - started < Config.Data.CloseTimeout do
			task.wait(0.1)
		end
	end)

	Net.setReadyCheck(PlayerData.isLoaded)
	Net.onAsk("GetInventory", {}, function(player)
		return ProfileLogic.inventory(sessions[player].profile)
	end)
	Net.onAsk("GetMyData", {}, function(player)
		local summary = ProfileLogic.summary(sessions[player].profile)
		summary.Saved = sessions[player].persistent
		return summary
	end)
end

function PlayerData.isLoaded(player)
	return sessions[player] ~= nil
end

function PlayerData.isPersistent(player)
	local session = sessions[player]
	return session ~= nil and session.persistent
end

function PlayerData.isPractice(player)
	local session = sessions[player]
	return session ~= nil and session.profile.Stash ~= nil
end

-- (2026-10-03) fn(player, profile) -> a profile to use instead (or nil: keep it), as a profile is loaded, before
-- PlayerData.onLoaded (the Tutorial service: a fresh tutorial field run)
function PlayerData.onPrepare(fn)
	table.insert(prepareCallbacks, fn)
end

-- save now and wait for it (the tutorial field, before the player is sent away)
function PlayerData.saveNow(player)
	return saveNow(player, false)
end

-- fn(player, profile) runs when a player's profile is ready (and for players already loaded)
function PlayerData.onLoaded(fn)
	table.insert(loadedCallbacks, fn)
	for player, session in pairs(sessions) do
		task.spawn(fn, player, session.profile)
	end
end

function PlayerData.onLeaving(fn)
	table.insert(leavingCallbacks, fn)
end

-- fn(player, profile) runs after every change made through PlayerData
function PlayerData.onChanged(fn)
	table.insert(changedCallbacks, fn)
end

-- fn(player, change, reason, balance) after every addMoney (change > 0) and spendMoney (change < 0), for the
-- Analytics service (2026-10-02)
function PlayerData.onMoney(fn)
	table.insert(moneyCallbacks, fn)
end

local function moneyMoved(player, change, reason)
	local profile = sessions[player] and sessions[player].profile
	for _, fn in ipairs(moneyCallbacks) do
		task.spawn(fn, player, change, reason, profile and profile.Money or 0)
	end
end

-- read-only use: do not change the returned table, use update / addMoney / ... instead
function PlayerData.get(player)
	local session = sessions[player]
	return session and session.profile
end

-- change a profile: fn(profile) edits it in place. Returns false if the player has no profile.
local changePending = {} -- [player] = true while the listeners are due this frame

function PlayerData.update(player, fn)
	local session = sessions[player]
	if not session then
		return false
	end
	fn(session.profile)
	mirror(player, session.profile)
	-- (2026-10-04, "게임 매끄럽게 돌아가게 최적화 해") the listeners see the profile once a frame at most: money changes
	-- several times a second (defense kills, deposits, chests), and each change woke every listener
	if not changePending[player] then
		changePending[player] = true
		task.defer(function()
			changePending[player] = nil
			local now = sessions[player]
			if not now or not player.Parent then
				return
			end
			for _, cb in ipairs(changedCallbacks) do
				task.spawn(function()
					local started = os.clock()
					cb(player, now.profile)
					if PlayerData.meter then
						PlayerData.meter("changed", debug.info(cb, "s"), os.clock() - started)
					end
				end)
			end
		end)
	end
	return true
end

local function validAmount(amount)
	return type(amount) == "number" and amount == amount and amount ~= math.huge and amount ~= -math.huge
end

-- money only ever changes here; amounts are rounded to whole numbers
-- money earned by playing gets the friends-on-the-server buff (Friends service, player attribute Friends)
-- and the day buff the night's boss left (ReplicatedStorage attribute DayBuff, Zombies service: "Money"
-- for all of it, "Defense" for defense kills)
local FRIEND_BOOSTED = { deposit = true, defense = true, treasure = true }
-- money the 게임머니 2배 pass and the 1-hour boost double: what's earned by playing (the 대박 광물 too)
local PAID_BOOSTED = { deposit = true, defense = true, treasure = true, jackpot = true }

-- earned money this session, for the Robux money packs' "an hour of your income" (Monetization)
local earned = {} -- [player] = { money, since (os.clock) }
Players.PlayerRemoving:Connect(function(player)
	earned[player] = nil
end)

-- money earned an hour by playing this session (deposits, defense, chests; before the boosts), nil
-- in the first minutes (too little to tell)
function PlayerData.hourlyIncome(player)
	local e = earned[player]
	local minutes = e and (os.clock() - e.since) / 60
	if not minutes or minutes < 10 then
		return nil
	end
	return e.money / minutes * 60
end

function PlayerData.addMoney(player, amount, reason)
	assert(validAmount(amount) and amount >= 0, "addMoney: bad amount " .. tostring(amount))
	if FRIEND_BOOSTED[reason] then
		local e = earned[player] or { money = 0, since = os.clock() }
		earned[player] = e
		e.money += amount
		local buff = ReplicatedStorage:GetAttribute("DayBuff")
		amount *= Formulas.friendBoost(player:GetAttribute("Friends")) * Formulas.dayBuff(buff, "Money")
		if reason == "defense" then
			amount *= Formulas.dayBuff(buff, "Defense")
		end
	end
	if PAID_BOOSTED[reason] then
		-- the 게임머니 2배 pass or the 1-hour money boost (Monetization): one of them, never both (×2, not ×4)
		local profile = PlayerData.get(player)
		if profile and profile.Passes and profile.Passes.DoubleMoney then
			amount *= Config.GamePasses.DoubleMoney.MoneyMultiplier
		elseif profile and (profile.MoneyBoostUntil or 0) > os.time() then
			amount *= Config.Products.MoneyBoost.MoneyMultiplier
		end
	end
	local ok = PlayerData.update(player, function(profile)
		profile.Money += math.floor(amount + 0.5)
	end)
	if ok and amount >= 0.5 then
		moneyMoved(player, math.floor(amount + 0.5), reason)
	end
	return ok
end

-- takes the money only if there is enough; returns true when paid
function PlayerData.spendMoney(player, amount, reason)
	assert(validAmount(amount) and amount >= 0, "spendMoney: bad amount " .. tostring(amount))
	amount = math.floor(amount + 0.5)
	local profile = PlayerData.get(player)
	if not profile or profile.Money < amount then
		return false
	end
	local ok = PlayerData.update(player, function(p)
		p.Money -= amount
	end)
	if ok and amount > 0 then
		moneyMoved(player, -amount, reason)
	end
	return ok
end

function PlayerData.save(player)
	return saveNow(player, false)
end

function PlayerData.markStored(player, fn)
	if not mainStore then
		return false
	end
	return (pcall(function()
		mainStore:UpdateAsync(storeKey(player), function(stored)
			if type(stored) ~= "table" then
				return nil
			end
			fn(stored)
			return stored
		end)
	end))
end

-- Studio test commands only: replace the profile with a fresh one
function PlayerData.reset(player)
	assert(RunService:IsStudio(), "PlayerData.reset is for Studio tests only")
	local session = sessions[player]
	if session then
		session.profile = ProfileLogic.new(Config)
		PlayerData.update(player, function() end)
	end
end

return PlayerData
