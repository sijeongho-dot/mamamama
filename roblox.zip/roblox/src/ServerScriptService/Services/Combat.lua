--[[
Combat: slaps and respawns (design 2.6 배틀필드, 2.7 기지에서 다시 시작, 7 손바닥).

- There is no health: a slap does not hurt. (Roblox's health bar is turned off.)
- Slap (Net request Slap(position, facing), the client only asks; the slapper's own position and facing on
  their screen are used when within Config.Slap.LagStuds of the server's, and a running target counts also
  where it was TargetLagSeconds ago: what the slapper saw, 2026-10-01): the server checks the slapper is alive (carrying keys is fine: a
  carrier can fight back), not mining, past the cooldown and outside every base (Shared/SafeZones), then hits
  every other player in front within Formulas.slapReach who is alive, outside every base and not
  invulnerable (2026-10-01: all of them, was only the nearest), and not right by a boss (Combat.protect:
  close enough to slap it, the boss's body + their own reach).
  A hit drops every carried key and throws the target high, Formulas.slapKnockback(slapper's level) studs away (the target's client flies it;
  MoveGuard lets it through); after landing it lies groggy for GroggySeconds. Flying and groggy it
  can't move (MoveGuard.stun), can't be slapped (InvulnerableUntil) and can't slap either (2026-10-03, "날아가는
  도중엔 찰싹이 안 되게 해": a thrown player hit back the slapper and both flew; downUntil),
  and hitting the server's #1 (player attribute Bounty) moves BountyBonusKeys of the #1's saved keys
  straight into the slapper's saved keys, one for one (never onto the ground: picked up and carried
  home they counted × the home value, so two friends could multiply keys), at most every
  BountyCooldown seconds per #1 and once per BountyPairCooldown for the same slapper and #1; the
  slapper also gets BountyMoneyChests treasure chests' worth at their own level, at most every
  BountyMoneyCooldown seconds and BountyMoneyPerDay times a day (saved in the profile's Bounty, so
  rejoining or changing servers doesn't start them over), and one #1 pays out money to at most
  BountyMoneyPerTopHour slappers an hour (Rewards.grant). Roblox friends get no bounty from each other
  at all (they could take turns being #1 and slapping each other). Cooldowns go by UserId and stay
  after leaving.
- Other things on the battlefield take the same slap (Combat.onSlap: the zombie dinos and the night's
  bosses). A hook given the slapper, their root, reach and slap level returns where it hit things (a
  list, maybe empty).
- Inside the player's own base a slap hits every fossil in reach on their own defense track instead
  (Defense.slapFossil: damage by slap level, Formulas.slapFossilDamage; the kill
  pays as usual). SlapFx then carries where the fossils were hit.
  Every swing is shown to everyone (Net push SlapFx).
- A character that still dies (fell off the world, reset): carried keys scatter, and Roblox respawns
  it at the player's base after Players.RespawnTime (Config.Respawn.Delay). After spawning:
  Config.Respawn.Invulnerability seconds of invulnerability (attribute InvulnerableUntil, server
  time). Attribute KnockedOutAt (server time) lets the client count down.
- Bounty: the player with the most saved keys (at least 1) is the server's #1.
- Combat.blast(player, at, reach, level): an egg bomb (Bombs service) is a slap from the bomb, all round.
- 🙈 Hide-and-seek (2026-10-03, HideSeek service; player attributes HideSeekRoom / HideSeekRole / HideSeekPhase):
  players in a game and everyone else never hit each other (slaps, bombs, zombies: Combat.hittable); a hider
  can't slap; the seeker's slap while seeking hits only their own room's hiders, and puts them out instead of
  throwing them (Combat.onTag).
- 🦅 (2026-10-04) a player on a flying dino over the battlefield (Shared/SafeZones.inSky) is only looking: their slap
  does nothing (a notice says so), and no slap, bomb, zombie or boss hits or throws them (Combat.throw does nothing).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local Keys = require(script.Parent:WaitForChild("Keys"))
local Defense = require(script.Parent:WaitForChild("Defense"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))

local Combat = {}

local KNOCKBACK_GRACE = 1.5 -- seconds MoveGuard lets a knocked-back player fly
local LAG_SLACK = 2 -- studs a slapper's own position may be off beyond what their speed explains
local BOUNTY_EVERY = 5 -- seconds between checks of who is #1

local lastSlap = {} -- [player] = os.clock()
local downUntil = {} -- [player] = os.clock() a throw's flight and groggy end (no slapping till then)
local HOUR = 3600
local lastBountyDrop = {} -- [#1 UserId] = os.clock() (kept after leaving: rejoining doesn't reset it)
local lastBountyPair = {} -- ["slapper id:#1 id"] = os.clock()
local topPayouts = {} -- [#1 UserId] = { os.clock() of each money payout in the last hour }
local friendsKnown = {} -- ["small id:big id"] = true / false (Player:IsFriendsWith, asked once)

local function friends(a, b)
	local key = math.min(a.UserId, b.UserId) .. ":" .. math.max(a.UserId, b.UserId)
	if friendsKnown[key] == nil then
		local ok, result = pcall(a.IsFriendsWith, a, b.UserId)
		if not ok then
			return true -- can't tell now: no bounty this time (asked again next time)
		end
		friendsKnown[key] = result == true
	end
	return friendsKnown[key]
end

-- may this #1 pay out bounty money now? (at most BountyMoneyPerTopHour in the last hour)
local function topCanPay(target, now)
	local list = topPayouts[target.UserId] or {}
	local kept = {}
	for _, t in ipairs(list) do
		if now - t < HOUR then
			table.insert(kept, t)
		end
	end
	topPayouts[target.UserId] = kept
	return #kept < Config.Keys.BountyMoneyPerTopHour
end
local slapHooks = {} -- Combat.onSlap
local protectors = {} -- Combat.protect
local safeSlapHooks = {} -- Combat.onSafeSlap
local tagHook = nil -- Combat.onTag

-- (2026-10-03) the seeker's slap reached a hider of their hide-and-seek room: fn(seeker, hider) (HideSeek)
function Combat.onTag(fn)
	tagHook = fn
end

-- (2026-10-03) the hide-and-seek room this player is playing in, or nil
local function gameOf(player)
	return player:GetAttribute("HideSeekRoom")
end

-- may this slapper hit that player? Players in a hide-and-seek game only meet their own room: the seeker,
-- while seeking, hits its hiders; nobody else hits them or is hit by them
local function meets(player, other)
	local mine, theirs = gameOf(player), gameOf(other)
	if mine == nil and theirs == nil then
		return true
	end
	return mine == theirs and player:GetAttribute("HideSeekRole") == "Seeker"
		and player:GetAttribute("HideSeekPhase") == "Seeking" and other:GetAttribute("HideSeekRole") == "Hider"
end

-- when this player last slapped (os.clock(), nil if not yet): Wildlife checks a wild dino's kick or slap back
function Combat.slappedAt(player)
	return lastSlap[player]
end

-- something else a slap on the battlefield hits too: fn(player, root, reach, level) -> { where it hit }
function Combat.onSlap(fn)
	table.insert(slapHooks, fn)
end

-- something a slap hits off the battlefield (in a base or the safe land): fn(player, root, reach, level) ->
-- { where it hit }, asked before the base's fossils (the tutorial's practice dummy)
function Combat.onSafeSlap(fn)
	table.insert(safeSlapHooks, fn)
end

-- places where players can't be slapped: fn(position, that player's slap reach) -> true when protected
-- (Zombies: right around a boss, so the ones hitting it don't throw each other away)
function Combat.protect(fn)
	table.insert(protectors, fn)
end

local function alive(player)
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if humanoid and root and humanoid.Health > 0 then
		return humanoid, root
	end
	return nil
end

-- attacks count only inside the battlefield flags (Shared/SafeZones)
local function inBattlefield(position)
	return not SafeZones.isSafe(position)
end

local function slapLevel(player)
	local profile = PlayerData.get(player)
	return profile and Formulas.trained(profile.Upgrades, profile.Training).Slap or 1
end

local function invulnerable(player)
	return (player:GetAttribute("InvulnerableUntil") or 0) > Workspace:GetServerTimeNow()
end

local function protected(other, position)
	if other:GetAttribute("TutorialShield") then -- the tutorial's first run: nobody can hit them
		return true
	end
	if #protectors == 0 then
		return false
	end
	local reach = Formulas.slapReach(slapLevel(other))
	for _, fn in ipairs(protectors) do
		if fn(position, reach) then
			return true
		end
	end
	return false
end

-- every valid target in front of the slapper, nearest first
local function findTargets(player, root, reach)
	if player:GetAttribute("TutorialShield") then -- (the tutorial's shielded player can't hit others either)
		return {}
	end
	local look = root.CFrame.LookVector
	local flatLook = Vector3.new(look.X, 0, look.Z).Unit
	local found, distances = {}, {}
	for _, other in ipairs(Players:GetPlayers()) do
		if other ~= player then
			local humanoid, otherRoot = alive(other)
			-- (2026-10-04, hide-and-seek on the whole map) a hider is tagged anywhere, the others only on the battlefield
			if humanoid and (inBattlefield(otherRoot.Position) or gameOf(other)) and not invulnerable(other)
				and meets(player, other)
				and not SafeZones.inSky(other, otherRoot.Position) then
				-- where it is now, or where it was a moment ago (what the slapper's screen shows of a runner)
				local moving = otherRoot.AssemblyLinearVelocity
				local back = Vector3.new(moving.X, 0, moving.Z) * Config.Slap.TargetLagSeconds
				for _, at in ipairs({ otherRoot.Position, otherRoot.Position - back }) do
					local offset = at - root.Position
					local flat = Vector3.new(offset.X, 0, offset.Z)
					local distance = flat.Magnitude
					local inFront = distance < Config.Slap.CloseRadius or flat.Unit:Dot(flatLook) >= Config.Slap.FrontDot
					if distance <= reach and inFront and math.abs(offset.Y) <= reach and not protected(other, otherRoot.Position) then
						table.insert(found, other)
						distances[other] = distance
						break
					end
				end
			end
		end
	end
	table.sort(found, function(a, b)
		return distances[a] < distances[b]
	end)
	return found
end

-- one player hit by a slap: the bounty if it is the #1, then the throw
local function hitPlayer(player, root, level, target, now)
	local targetProfile = PlayerData.get(target)
	local pair = player.UserId .. ":" .. target.UserId
	if target:GetAttribute("Bounty") and targetProfile
		and now - (lastBountyDrop[target.UserId] or -math.huge) >= Config.Keys.BountyCooldown
		and now - (lastBountyPair[pair] or -math.huge) >= Config.Keys.BountyPairCooldown and not friends(player, target) then
		-- the #1's own saved keys, one for one to the slapper: nothing is made from nothing
		local n = math.min(Config.Keys.BountyBonusKeys, targetProfile.Keys)
		if n > 0 then
			lastBountyDrop[target.UserId] = now
			lastBountyPair[pair] = now
			PlayerData.update(target, function(p)
				Formulas.addSavedKeys(p, "Normal", -n)
			end)
			PlayerData.update(player, function(p)
				Formulas.addSavedKeys(p, "Normal", n)
			end)
			Net.pushAll("Notice", "👑 현상금!", string.format("%s님이 👑 1등 %s님을 찰싹! 🔑 열쇠 %d개를 가져갔어요",
				player.DisplayName, target.DisplayName, n))
			local profile = PlayerData.get(player)
			local clock, day = os.time(), RewardLogic.dayNumber(os.time())
			if profile and Formulas.bountyMoneyReady(profile.Bounty, clock, day) and topCanPay(target, now) then
				table.insert(topPayouts[target.UserId], now)
				PlayerData.update(player, function(p)
					local today = p.Bounty.Day == day and p.Bounty.Money or 0
					p.Bounty = { Day = day, Money = today + 1, LastMoney = clock }
				end)
				Rewards.grant(player, { MoneyChests = Config.Keys.BountyMoneyChests }, "💰 현상금") -- by the slapper's level
			end
		end
	end
	Combat.throw(target, root.Position, Formulas.slapKnockback(level), root.CFrame.LookVector)
	Rewards.add(player, "Slaps", 1) -- daily missions
end

local function slap(player, seenAt, seenLook)
	local humanoid, root = alive(player)
	if not humanoid or not PlayerData.isLoaded(player) then
		return
	end
	-- (2026-10-01) the slapper's own position and facing from their screen, when near where the server
	-- has them (running, the server's copy is a little behind): what they aimed at is what is checked
	-- (how far: what the walk speed covers in the lag, so standing still it can't add reach)
	local slack = math.min(Config.Slap.LagStuds, MoveGuard.walkSpeed(player) * Config.Slap.TargetLagSeconds + LAG_SLACK)
	local flatSeen = Vector3.new(seenAt.X - root.Position.X, 0, seenAt.Z - root.Position.Z)
	local look = Vector3.new(seenLook.X, 0, seenLook.Z)
	if flatSeen.Magnitude <= slack and math.abs(seenAt.Y - root.Position.Y) <= Config.Slap.LagStuds
		and look.Magnitude > 0.5 and look.Magnitude < 1.5 then
		local at = Vector3.new(seenAt.X, root.Position.Y, seenAt.Z)
		root = { Position = at, CFrame = CFrame.lookAt(at, at + look.Unit) }
	end
	local now = os.clock()
	if now - (lastSlap[player] or -math.huge) < Config.Slap.Cooldown or (downUntil[player] or 0) > now then
		return
	end
	if player:GetAttribute("Mining") then
		return Net.push(player, "Notice", "👋 손바닥", "⛏️ 캐는 동안은 찰싹을 못 해요")
	end
	if player:GetAttribute("HideSeekRole") == "Hider" then -- (2026-10-03) hiders can't slap
		return Net.push(player, "Notice", "🙈 숨바꼭질", "숨는 사람은 찰싹을 못 써요")
	end
	if SafeZones.inSky(player, root.Position) then -- (2026-10-04) flying over the battlefield: only looking
		return Net.push(player, "Notice", "🦅", "🦅 하늘 구경 중엔 찰싹을 못 해요")
	end
	lastSlap[player] = now
	local level = slapLevel(player)
	local reach = Formulas.slapReach(level)
	if player:GetAttribute("HideSeekRole") == "Seeker" then -- (2026-10-03) the seeker's longer slap (HideSeek)
		reach *= Config.HideSeek.SeekerReach
	end
	if not inBattlefield(root.Position) then
		-- inside a base: the only things to slap are defense fossils (Defense)
		-- (and what Combat.onSafeSlap hooks hit: the tutorial's dummy)
		local spots = {}
		for _, hook in ipairs(safeSlapHooks) do
			for _, at in ipairs(hook(player, root, reach, level) or {}) do
				table.insert(spots, at)
			end
		end
		for _, at in ipairs(Defense.slapFossil(player, root.Position, reach, level)) do
			table.insert(spots, at)
		end
		-- (2026-10-04, "술래잡기 최대 영역을 그냥 맵 전체로 하자") the seeker tags its hiders off the battlefield too (meets:
		-- nobody else)
		local tagged = gameOf(player) and findTargets(player, root, reach) or {}
		local ids = {}
		for _, target in ipairs(tagged) do
			table.insert(ids, target.UserId)
		end
		Net.pushAll("SlapFx", player.UserId, ids, level, spots)
		for _, target in ipairs(tagged) do
			if tagHook then
				tagHook(player, target)
			end
		end
		return
	end
	-- everything in reach takes it (2026-10-01): zombies and bosses (the hooks) and players
	local spots = {}
	for _, hook in ipairs(slapHooks) do
		for _, at in ipairs(hook(player, root, reach, level) or {}) do
			table.insert(spots, at)
		end
	end
	local targets = findTargets(player, root, reach)
	local ids = {}
	for _, target in ipairs(targets) do
		table.insert(ids, target.UserId)
	end
	Net.pushAll("SlapFx", player.UserId, ids, level, spots)
	for _, target in ipairs(targets) do
		if gameOf(target) then -- (only the seeker's own hiders get here: meets) out, not thrown
			if tagHook then
				tagHook(player, target)
			end
		else
			hitPlayer(player, root, level, target, now)
		end
	end
end

-- an egg bomb going off at `at` (Bombs service): a slap from the bomb itself, all round, with the
-- thrower's slap reach and level: every other player in reach on the battlefield is thrown (the bounty
-- too), and the zombies and bosses take it (the slap hooks, given the bomb as a root looking straight
-- up, so "in front" is everywhere). Returns the players hit (UserIds) and where the others were hit.
function Combat.blast(player, at, reach, level, bossMultiplier)
	local spots, ids = {}, {}
	if not inBattlefield(at) then
		return ids, spots
	end
	-- (a fake root for the hooks; BossMultiplier: a boss takes this many slaps' worth)
	local bomb = { Position = at, CFrame = CFrame.lookAt(at, at + Vector3.yAxis), BossMultiplier = bossMultiplier, Bomb = true }
	for _, hook in ipairs(slapHooks) do
		for _, spot in ipairs(hook(player, bomb, reach, level) or {}) do
			table.insert(spots, spot)
		end
	end
	if player:GetAttribute("TutorialShield") then
		return ids, spots
	end
	local now = os.clock()
	for _, other in ipairs(Players:GetPlayers()) do
		if other ~= player then
			local humanoid, otherRoot = alive(other)
			if humanoid and inBattlefield(otherRoot.Position) and not invulnerable(other) and not gameOf(other)
				and not SafeZones.inSky(other, otherRoot.Position) then
				local offset = otherRoot.Position - at
				if Vector3.new(offset.X, 0, offset.Z).Magnitude <= reach and math.abs(offset.Y) <= reach
					and not protected(other, otherRoot.Position) then
					table.insert(ids, other.UserId)
					hitPlayer(player, { Position = at, CFrame = CFrame.new(at) }, level, other, now)
				end
			end
		end
	end
	return ids, spots
end

Combat.slapLevel = slapLevel
Combat.inBattlefield = inBattlefield
Combat.invulnerable = invulnerable
Combat.protected = protected

-- throw a player away from `from` by `studs`, like a slap (also a zombie dino's hit): carried keys
-- fall, thrown high, then groggy on the ground; flying and groggy they can't move or be hit again
function Combat.throw(target, from, studs, fallback)
	local _, targetRoot = alive(target)
	if not targetRoot or SafeZones.inSky(target, targetRoot.Position) then
		return
	end
	Keys.dropAll(target, targetRoot.Position)
	local away = targetRoot.Position - from
	away = Vector3.new(away.X, 0, away.Z)
	local back = fallback and Vector3.new(fallback.X, 0, fallback.Z) or Vector3.xAxis
	away = away.Magnitude > 0.1 and away.Unit or (back.Magnitude > 0.1 and back.Unit or Vector3.xAxis)
	local s = Config.Slap
	local down = s.FlightSeconds + s.GroggySeconds
	downUntil[target] = math.max(downUntil[target] or 0, os.clock() + down)
	target:SetAttribute("InvulnerableUntil", math.max(target:GetAttribute("InvulnerableUntil") or 0,
		Workspace:GetServerTimeNow() + down))
	MoveGuard.stun(target, down, "Groggy")
	MoveGuard.loosen(target, down + KNOCKBACK_GRACE)
	Net.push(target, "Knockback", away.X, away.Z, studs, s.FlightSeconds, s.GroggySeconds)
	Net.pushAll("FlyFx", target.UserId, s.FlightSeconds) -- (the whoosh on every screen near them)
end

-- can a zombie (or anything else that throws) hit this player now? alive, on the battlefield, not
-- flying or groggy or just respawned, not on a flying dino up over it
function Combat.hittable(player)
	local humanoid, root = alive(player)
	return humanoid ~= nil and inBattlefield(root.Position) and not invulnerable(player)
		and not player:GetAttribute("TutorialShield") and not player:GetAttribute("InTutorial") and not gameOf(player)
		and not SafeZones.inSky(player, root.Position),
		root
end

local function onCharacter(player, character)
	local humanoid = character:WaitForChild("Humanoid", 10)
	if not humanoid then
		return
	end
	humanoid.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff -- no health in this game
	humanoid.BreakJointsOnDeath = false -- falls over in one piece
	player:SetAttribute("KnockedOutAt", nil)
	downUntil[player] = nil -- (a new body is up)
	player:SetAttribute("InvulnerableUntil", Workspace:GetServerTimeNow() + Config.Respawn.Invulnerability)
	humanoid.Died:Connect(function()
		local root = character:FindFirstChild("HumanoidRootPart")
		Keys.dropAll(player, root and root.Position)
		player:SetAttribute("KnockedOutAt", Workspace:GetServerTimeNow())
	end)
end

function Combat.init()
	local function added(player)
		player.CharacterAdded:Connect(function(character)
			onCharacter(player, character)
		end)
		if player.Character then
			task.spawn(onCharacter, player, player.Character)
		end
	end
	Players.PlayerAdded:Connect(added)
	for _, player in ipairs(Players:GetPlayers()) do
		added(player)
	end
	Players.PlayerRemoving:Connect(function(player)
		lastSlap[player] = nil
		downUntil[player] = nil
	end)
	Net.onRequest("Slap", { "Vector3", "Vector3" }, slap)

	-- bounty: the most saved keys
	task.spawn(function()
		while true do
			task.wait(BOUNTY_EVERY)
			local top, most = nil, 0
			for _, player in ipairs(Players:GetPlayers()) do
				local profile = PlayerData.get(player)
				-- (2026-10-04) a developer is never the #1 (Config.Developers: no ranking)
				if profile and profile.Keys > most and not Formulas.isDeveloper(player.Name) then
					top, most = player, profile.Keys
				end
			end
			for _, player in ipairs(Players:GetPlayers()) do
				local isTop = player == top
				if (player:GetAttribute("Bounty") == true) ~= isTop then
					player:SetAttribute("Bounty", isTop)
				end
			end
		end
	end)
end

return Combat
