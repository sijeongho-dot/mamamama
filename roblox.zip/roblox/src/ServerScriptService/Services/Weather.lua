--[[
Weather: rain, thunderstorms and the rare rainbow sky for the whole server (Config.Weather).

Rare and short: every CheckInterval seconds of clear sky the weather is rolled
(Formulas.rollWeather); rain or a storm lasts MinSeconds-MaxSeconds (about a minute), then the sky
clears again. The fossil witch announces it on every screen (Story, her dialogue box), and while it lasts
defense kills pay DefenseMoneyMultiplier times as much (Defense reads Weather.defenseMultiplier()).

The aurora (Id "Aurora", NightOnly) is rolled once at each nightfall (Formulas.rollNightWeather, its
ChancePercent; it replaces whatever weather there was) and lasts the whole night, clearing at dawn; the
Zombies service sends out the aurora boss when it starts.

Every change (2026-10-01) is counted down first: Config.Weather.CountdownSeconds notes a second apart
("🌧️ 비 3초 뒤!", Config.Story.Explains.WeatherSoon) under the witch's line (one dialogue box, its note
changing), then the weather starts.
A weather's end is counted down so the sky clears right at its time. Weather.set skips it (;aurora);
Weather.change counts down too (;weather).

ReplicatedStorage attributes for the clients (StarterPlayerScripts/WeatherFx: rain, lightning,
darker sky, the weather line under the compass): Weather (Id) and WeatherUntil (server time).
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local DayNight = require(script.Parent:WaitForChild("DayNight"))
local Story = require(script.Parent:WaitForChild("Story"))

local Weather = {}

local rng = Random.new()
local current = "Clear"
local untilTime = 0 -- os.clock() when rain or a storm ends
local sinceCheck = 0
local coming = nil -- the change being counted down: a token (a new set or countdown stops the old one)

function Weather.current()
	return current
end

function Weather.defenseMultiplier()
	return Formulas.weather(current).DefenseMoneyMultiplier
end

-- start a weather now (seconds: how long; default a random length from its type)
function Weather.set(id, seconds)
	coming = nil -- (a countdown still running stops)
	local w = Formulas.weather(id)
	current = w.Id
	sinceCheck = 0
	if w.Id == "Clear" then
		untilTime = 0
		ReplicatedStorage:SetAttribute("Weather", "Clear")
		ReplicatedStorage:SetAttribute("WeatherUntil", nil)
		Story.showAll("WeatherClear", Story.explain("WeatherClear"))
		return
	end
	if not seconds and w.NightOnly then -- until dawn
		local left = (ReplicatedStorage:GetAttribute("PhaseEndsAt") or 0) - Workspace:GetServerTimeNow()
		seconds = math.max(w.MinSeconds, math.floor(left))
	end
	seconds = seconds or rng:NextInteger(w.MinSeconds, w.MaxSeconds)
	untilTime = os.clock() + seconds
	ReplicatedStorage:SetAttribute("Weather", w.Id)
	ReplicatedStorage:SetAttribute("WeatherUntil", Workspace:GetServerTimeNow() + seconds)
	Story.showAll("Weather" .. w.Id, Story.explain("Weather", w.Icon, w.Name, seconds, w.DefenseMoneyMultiplier,
		w.MiningYieldMultiplier, w.MoveSpeedMultiplier or 1))
end

-- count down Config.Weather.CountdownSeconds, then Weather.set(id, seconds)
local function countdownTo(id, seconds)
	local token = {}
	coming = token
	local w = Formulas.weather(id)
	task.spawn(function()
		for n = Config.Weather.CountdownSeconds, 1, -1 do
			if coming ~= token then
				return
			end
			Story.showAll("Weather" .. w.Id, Story.explain("WeatherSoon", w.Icon, w.Name, n))
			task.wait(1)
		end
		if coming == token then
			Weather.set(id, seconds)
		end
	end)
end

-- a change with its countdown (the test command ;weather, to see it)
Weather.change = countdownTo

-- (2026-10-03) the tutorial field (TutorialField): no weather comes or goes by itself while held
local held = false
function Weather.hold(on)
	held = on == true
end

function Weather.init()
	ReplicatedStorage:SetAttribute("Weather", "Clear")
	DayNight.onChange(function(night) -- nightfall may bring the aurora for the whole night; dawn ends it
		if held then
			return
		end
		if night then
			local id = Formulas.rollNightWeather(rng:NextNumber())
			if id then
				countdownTo(id)
			end
		elseif Formulas.weather(current).NightOnly then
			countdownTo("Clear")
		end
	end)
	task.spawn(function()
		while true do
			local dt = task.wait(1)
			if held then
				sinceCheck = 0
			elseif coming then -- (a change is being counted down)
				sinceCheck = 0
			elseif current ~= "Clear" then
				if os.clock() >= untilTime - Config.Weather.CountdownSeconds then -- clears right at its time
					countdownTo("Clear")
				end
			else
				sinceCheck += dt
				if sinceCheck >= Config.Weather.CheckInterval then
					sinceCheck = 0
					local id = Formulas.rollWeather(rng:NextNumber())
					if id ~= "Clear" then
						countdownTo(id)
					end
				end
			end
		end
	end)
end

return Weather
