--[[
Settings: the player's screen settings, saved in the profile (Settings) so they stay next time.

The "hide" switches, to cut lag and clutter: HideMineralNames (the names over the minerals), HideMyDinos, HideMyFossils, HideOtherDinos,
HideOtherFossils (the dinos on the platforms and the fossil monsters on the tracks, the player's
own and everyone else's), HideMyFarm, HideOtherFarm (the dinos in the farm pens), HideFarmLabels (what each
farm dino gives, over its head; 2026-10-01), HideWildlife (the wild dinos roaming the safe land), HideAuras (the rarity auras
round dinos), HideWeather (rain, lightning, rainbow, aurora and the milky way), HideTips (Coco's tips, StarterPlayerScripts/Hints;
2026-10-02). They are mirrored as player attributes of the same names; the clients
read them (StarterPlayerScripts/DefenseView hides, StarterPlayerScripts/ViewSettings switches).
Net request SetSetting(name, on) only accepts these names.
The language (2026-10-02, English then Spanish): Settings.Language "en" / "ko" / "es" (Shared/Lang.NAMES),
mirrored as the player attribute Language; Net request SetLanguage(code). Not chosen yet: English (a save
from before Spanish kept English = true / false: that one).

The sound bars (2026-10-01, 보기 설정): MusicVolume (the background music; it took the place of the
MuteMusic switch, which still reads as 0 when it was on) and MasterVolume (every sound in the game),
0 to 1 in steps of VOLUME_STEP, mirrored as number attributes. Net request SetVolume(name, value).
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))
local Lang = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Lang"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))

local Settings = {}

local VOLUME_NAMES = { "MusicVolume", "MasterVolume" }
local VOLUME_STEP = 0.05

local NAMES = { "HideMyDinos", "HideMyFossils", "HideOtherDinos", "HideOtherFossils", "HideMineralNames", "MuteMusic",
	"HideWildlife", "HideAuras", "HideReach", "HideWeather", "HideMyFarm", "HideOtherFarm", "HideFarmLabels", "HideTips",
	"AutoMineOff", -- (2026-10-02) the ⛏️ auto mining pass switched off (StarterPlayerScripts/AutoMine) ...
	"AutoNoMinerals", "AutoFruit", -- ... and what it does when on: no minerals, fruit (its button's modes)
	"LightMode", "HideMissionGuide",
	"LightModeManual", -- (2026-10-04) 🍃 switched on by hand
	"HideMyVIP", "HideMyDex", "HideMyRecord", -- (2026-10-04, "내 vip나 도감, 승패기록도 설정에서 키고 끌 수 있게") the line over my head -- (2026-10-04) 🍃 switched on by hand (not by a slow screen: that one lasts a session) -- (2026-10-04) 🍃 for a slow phone: no shadows, no ground patterns, grass or field props (LightMode)
	"HideNotices", "HideDefenseNotices" }

local function volumeOf(settings, name)
	local v = settings[name]
	if type(v) ~= "number" then
		v = (name == "MusicVolume" and settings.MuteMusic == true) and 0 or (name == "MusicVolume" and 0.6 or 1) -- (the old music switch)
	end
	return v
end

-- the saved language (see the top)
local function languageOf(settings, player)
	if Lang.NAMES[settings.Language] then
		return settings.Language
	end
	return settings.English == false and "ko" or Lang.deviceCode(player)
end

local function mirror(player, profile)
	for _, name in ipairs(NAMES) do
		player:SetAttribute(name, profile.Settings[name] == true)
	end
	player:SetAttribute("LightMode", profile.Settings.LightModeManual == true)
	player:SetAttribute("Language", languageOf(profile.Settings, player))
	for _, name in ipairs(VOLUME_NAMES) do
		player:SetAttribute(name, volumeOf(profile.Settings, name))
	end
end

local function setVolume(player, name, value)
	if not table.find(VOLUME_NAMES, name) or value ~= value then
		return
	end
	value = math.clamp(math.floor(value / VOLUME_STEP + 0.5) * VOLUME_STEP, 0, 1)
	PlayerData.update(player, function(p)
		p.Settings[name] = value
	end)
	player:SetAttribute(name, value)
end

local function set(player, name, on)
	if not table.find(NAMES, name) then
		return
	end
	PlayerData.update(player, function(p)
		p.Settings[name] = on
	end)
	player:SetAttribute(name, on)
end

function Settings.init()
	PlayerData.onLoaded(mirror)
	Net.onRequest("SetSetting", { "string", "boolean" }, set)
	Net.onRequest("SetLanguage", { "string" }, function(player, code)
		if Lang.NAMES[code] then
			PlayerData.update(player, function(p)
				p.Settings.Language = code
			end)
			player:SetAttribute("Language", code)
			player:SetAttribute("LanguagePick", nil) -- (2026-10-03: the first-join picker is answered)
		end
	end)
	Net.onRequest("SetVolume", { "string", "number" }, setVolume)
end

return Settings
