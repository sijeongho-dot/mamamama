local Config = if game then require(game:GetService("ReplicatedStorage"):WaitForChild("Config")) else CONFIG
local F = if game then require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Formulas"))
	else LOAD("ReplicatedStorage/Shared/Formulas")

local DeckAdvice = {}
local AREA = { AreaAround = true, PiercingLine = true, Splash = true }

local function support(stats)
	return stats.SlowAura or stats.Attribute == "Ice" or stats.Attribute == "Water"
end

local function spot(profile, field, incoming, outgoing)
	local taken = {}
	for _, u in ipairs(field.units) do
		if u.Id ~= outgoing then
			table.insert(taken, { X = u.X, Z = u.Z, Footprint = u.Stats.Footprint })
		end
	end
	local layout = F.autoLayout({ incoming }, field.mapId, taken)
	return layout[incoming.Id]
end

function DeckAdvice.plan(profile, field, kind, level, twist, leakedKind)
	local owned, live = {}, {}
	for _, unit in ipairs(profile.Units or {}) do owned[unit.Id] = unit end
	for _, unit in ipairs(field.units) do live[unit.Id] = unit end
	local ordered = table.clone(field.units)
	table.sort(ordered, function(a, b) return a.Id < b.Id end)
	for _, u in ipairs(ordered) do
		if u.active == false and not u.Rest and owned[u.Id] then
			local at = spot(profile, field, u, u.Id)
			if at then
				return { Action = "Move", In = u.Id, Out = u.Id, X = at.X, Z = at.Z,
					Reason = "📍 길에서 멀어 공격하지 못했어요" }
			end
		end
	end
	local weak = F.bossWeakness(F.bossAttribute(level))
	local enemy = leakedKind and F.fossilKind(leakedKind)
	local reserved = {}
	for _, id in ipairs(profile.Starter and profile.Starter.MergeDinos or {}) do reserved[id] = true end
	local scores = {}
	local function score(u)
		if scores[u.Id] == nil then scores[u.Id] = F.recommendStrength(u, level) end
		return scores[u.Id]
	end
	local function relevant(stats)
		if kind == "Area" then return AREA[stats.Attack] == true end
		if kind == "Matchup" then return stats.Attribute == weak end
		if kind == "Hidden" then return stats.Theme == "Sea" end
		if kind == "Immune" and enemy then
			return stats.Attack ~= enemy.ImmuneAttack and stats.Attribute ~= enemy.ImmuneAttribute
		end
		return true
	end
	local candidates = {}
	for _, u in ipairs(profile.Units or {}) do
		if not live[u.Id] and not (profile.Farm or {})[u.Id] and not reserved[u.Id] then
			local st = F.unitStats(u)
			if relevant(st) then
				table.insert(candidates, { Id = u.Id, Species = u.Species, Stats = st, Score = score(u) })
			end
		end
	end
	table.sort(candidates, function(a, b)
		if a.Score ~= b.Score then return a.Score > b.Score end
		return a.Id < b.Id
	end)
	local victims = {}
	for _, u in ipairs(field.units) do
		if owned[u.Id] and (u.Rest or not support(u.Stats)) then table.insert(victims, u) end
	end
	table.sort(victims, function(a, b)
		if (a.Rest == true) ~= (b.Rest == true) then return a.Rest == true end
		local da, db = (field.lastDealt or {})[a.Id] or 0, (field.lastDealt or {})[b.Id] or 0
		if da ~= db then return da < db end
		return a.Id < b.Id
	end)
	local room = #field.units < F.profileSlots(profile)
	for i = 1, math.min(#candidates, Config.Defense.Promotion.Advice.CandidateLimit) do
		local candidate = candidates[i]
		local options = room and { false } or victims
		for j = 1, math.min(#options, Config.Defense.Promotion.Advice.CandidateLimit) do
			local out = options[j]
			local improves = not out or out.Rest or ((kind == "Area" or kind == "Hidden" or kind == "Immune")
				and not relevant(out.Stats) and candidate.Score >= score(owned[out.Id]) * Config.Defense.Promotion.Advice.MinRoleStrengthShare)
				or candidate.Score > score(owned[out.Id])
			if not improves then continue end
			local team = { candidate }
			for _, u in ipairs(field.units) do
				if not out or u.Id ~= out.Id then table.insert(team, u) end
			end
			local resting = twist and F.twistBench(twist, team, level) or {}
			if resting[candidate.Id] then continue end
			local at = spot(profile, field, candidate, out and out.Id)
			if at then
				local reason = kind == "Area" and "💥 여러 적을 함께 때리는 역할이 필요해요"
					or kind == "Matchup" and "🎯 다음 보스의 약점 속성을 보완해요"
					or kind == "Hidden" and "🌊 바다 공룡으로 숨은 적을 찾아요"
					or kind == "Immune" and "🛡️ 빠져나간 적에게 통하는 공격이에요"
					or out and out.Rest and "💤 이번 규칙에서 공격 가능한 공룡이에요"
					or "⚔️ 보유 공룡 중 다음 보스 대응을 보완해요"
				return { Action = out and "Swap" or "Add", In = candidate.Id, Out = out and out.Id,
					X = at.X, Z = at.Z, Reason = reason }
			end
		end
	end
	if kind == "Area" or kind == "Matchup" or kind == "Hidden" or kind == "Immune" then
		return { Action = "Review", Reason = "🧩 보유 공룡과 배치 공간에 맞는 교체가 없어요" }
	end
	local id = F.enhancePick(profile.Units or {}, profile.Placed or {}, level)
	return { Action = "Enhance", In = id, Reason = "⬆️ 지금 보유한 덱은 강화할 공룡을 먼저 확인해요" }
end

function DeckAdvice.describe(profile, plan)
	local byId = {}
	for _, u in ipairs(profile.Units or {}) do byId[u.Id] = u end
	local incoming, outgoing = byId[plan.In], byId[plan.Out]
	local name = incoming and F.unitName(incoming) or "?"
	local action = plan.Action == "Move" and string.format("📍 %s → 길 가까이 이동", name)
		or plan.Action == "Swap" and string.format("🔄 %s → %s 교체", outgoing and F.unitName(outgoing) or "?", name)
		or plan.Action == "Add" and string.format("➕ %s 배치", name)
		or incoming and string.format("⬆️ %s 강화 확인", name) or plan.Reason
	return action .. "\n" .. plan.Reason
end

return DeckAdvice
