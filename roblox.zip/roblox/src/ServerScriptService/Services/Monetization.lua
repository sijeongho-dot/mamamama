--[[
Monetization: Robux purchases (design 11 과금 상품; stage 10, step 1, 2026-10-01).

- Developer products (Config.Monetization.ProductIds; the products' values in Config.Products,
  Config.KeyPacks, Config.MoneyPacks): MarketplaceService.ProcessReceipt grants each purchase once
  (profile Purchases.Receipts by PurchaseId, saved before saying it is granted; a failed save leaves it
  for Roblox to retry). What each gives:
    StarterPack (once per account): KeyHours of keys (Formulas.keyPackKeys), its special keys, LuckMinutes
      of luck ×2 (profile LuckUntil, as the starter missions' luck).
    LuckPotion / LuckPotionBig: Minutes of luck ×2.
    ServerLuckBoost / Big: everyone's draws get LuckMultiplier for Minutes (ReplicatedStorage attributes
      ServerLuck, ServerLuckUntil, ServerLuckBy; Gacha multiplies, capped like all luck); a big banner to
      the whole server and a crown over the buyer for CrownMinutes (player attribute LuckCrownUntil).
    MoneyBoost: money earned by playing ×2 for Minutes (profile MoneyBoostUntil, PlayerData.addMoney; with
      the DoubleMoney pass it adds nothing: never ×4; player attribute MoneyBoostUntil, server time).
    SpeedPotion / Big: +SpeedBonus move speed for Minutes (profile SpeedUntil; player attribute
      SpeedPotionUntil, server time; MoveGuard); more potions add time, not speed.
    RubyKeys: its special keys.
    SeasonPass: this season's pass rewards (Season.buyPass; 2026-10-02).
    BoxRush1-4: Seconds of 📦 box waiting skipped (Boxes.rush; Config.Boxes.Rush).
    KeyPack_<Id>: Hours of keys at the buyer's level; MoneyPack_<Id>: Hours of the buyer's own income
      (PlayerData.hourlyIncome).
  The very first key or money pack gives Config.Monetization.FirstPurchaseMultiplier times as much, at most
  FirstPurchaseMaxBonusHours more (not the starter pack: it doesn't use it up either).
- Game passes (Config.Monetization.GamePassIds; or made as developer products, PassProductIds, 2026-10-02:
  bought once through ProcessReceipt, then the same): owned ones are found on join (UserOwnsGamePassAsync)
  and on purchase, kept in profile Passes (player attributes Pass<Id>): DoubleMoney (PlayerData.addMoney),
  DoubleBag (Minerals), PlacementSlot and FarmSlots (Formulas), VIP (a tag in chat on every screen,
  DailyKeyHours of keys once a day; where paid random items are restricted, RestrictedDaily instead: speed
  potion minutes and bombs, 2026-10-02).
- Paid random items (Config.RestrictedProducts) are not sold where PolicyService restricts them
  (Policy.isRestricted, player attribute PaidRandomItemsRestricted): the client hides them and the
  starter pack is never offered there (a receipt Roblox already charged is still honored).
- The starter pack is offered (Net push Offer) once an account (2026-10-04; was once a session) on joining (2026-10-04, "구매 광고는 접속했을때 띄우고
  나중에 랜덤적으론 띄우지 말자. 튜토하는 사람은 튜토 끝나고"): Config.Monetization.OfferJoinSeconds after the player is free
  (the tutorial done, the language and the tutorial question answered), never on a tutorial field, while it
  is not bought; (2026-10-04, "구매 광고는 튜토 끝낸 사람에게만 뜨게 하자") never to one who skipped the tutorial and hasn't
  played it to the end since. (It was offered after the first draw and the first promotion lost.)
- Studio: a product or pass whose id is still 0 is granted at once (Net request StudioBuy, Studio only).
]]

local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local TutorialField = require(script.Parent:WaitForChild("TutorialField"))
local Policy = require(script.Parent:WaitForChild("Policy"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))

local Monetization = {}

local RECEIPTS_KEPT = 50 -- the newest purchase ids remembered in the save
local INCOME_MIRROR_EVERY = 30
local SPEED_END_MARGIN = 0.2 -- seconds after a speed potion ends before the walk speed is set again
local VIP_CHECK_EVERY = 300 -- seconds between checks for VIP's daily keys (a new day)
local OFFER_WAIT_CHECK = 2 -- seconds between looks while a joining player is not free yet (the language, the tutorial)
local OFFER_WAIT_MAX = 900 -- seconds a session waits for that at most

local M = Config.Monetization
local mirrorPasses -- defined below
local vipDaily -- defined below
-- (2026-10-03, the paid-products check) declared here: processReceipt, above where it is written, calls it. It was a
-- plain `local function` further down, so processReceipt called a nil global and a pass sold as a developer product
-- (💰 게임머니 2배 has no game pass: only that way) was never given; Roblox kept retrying the receipt
local givePass -- defined below
local productByAsset = {} -- [product id] = key
local passByAsset = {} -- [pass id] = key
local practiceTold = setmetatable({}, { __mode = "k" })

local function say(player, title, text)
	Net.push(player, "Notice", title, text)
end

-- the values of a product key: { kind, data }
local function product(key)
	if Config.Products[key] then
		return key, Config.Products[key]
	end
	local packKind, id = string.match(key, "^(%a+Pack)_(%a+)$")
	local list = packKind == "KeyPack" and Config.KeyPacks or packKind == "MoneyPack" and Config.MoneyPacks or nil
	for _, pack in ipairs(list or {}) do
		if pack.Id == id then
			return packKind, pack
		end
	end
	return nil
end

-- is this product or pass a paid random item (draws: Config.RestrictedProducts)?
local function randomItem(key)
	local kind = product(key)
	local group = (kind == "KeyPack" and "KeyPacks") or (kind == "MoneyPack" and "MoneyPacks") or key
	return table.find(Config.RestrictedProducts, group) ~= nil
end
Monetization.randomItem = randomItem

local function setLuck(player, minutes)
	PlayerData.update(player, function(p)
		p.LuckUntil = math.max(p.LuckUntil or 0, os.time()) + minutes * 60
	end)
	local profile = PlayerData.get(player)
	player:SetAttribute("Luck", Config.StarterMissions.LuckMultiplier) -- (StarterMissions keeps it after)
	player:SetAttribute("LuckEndsAt", profile.LuckUntil)
end

local function addSureDraw(player, rarity)
	PlayerData.update(player, function(p)
		p.GuaranteedDraws = p.GuaranteedDraws or {}
		p.GuaranteedDraws[rarity] = (p.GuaranteedDraws[rarity] or 0) + 1
	end)
	local n = 0
	for _, k in pairs(PlayerData.get(player).GuaranteedDraws) do
		n += k
	end
	player:SetAttribute("GuaranteedDraws", n)
end

-- the timed boosts for the screens (server time): the speed potion, the 1-hour money ×2
local function mirrorSpeed(player, profile)
	local left = (profile.SpeedUntil or 0) - os.time()
	player:SetAttribute("SpeedPotionUntil", left > 0 and Workspace:GetServerTimeNow() + left or nil)
	local money = (profile.MoneyBoostUntil or 0) - os.time()
	player:SetAttribute("MoneyBoostUntil", money > 0 and Workspace:GetServerTimeNow() + money or nil)
	MoveGuard.refresh(player)
	if left > 0 then -- (the walk speed is set, not checked: set it again when the potion runs out)
		task.delay(left + SPEED_END_MARGIN, function()
			if player.Parent then
				MoveGuard.refresh(player)
			end
		end)
	end
end

-- (2026-10-02) the limited luck potion while it lasts: player attributes LimitedPotion (Gacha's odds) and
-- LimitedPotionUntil (server time, the shop's line)
local function mirrorLimited(player, profile)
	local left = (profile.LimitedLuckUntil or 0) - os.time()
	player:SetAttribute("LimitedPotion", left > 0 or nil)
	player:SetAttribute("LimitedPotionUntil", left > 0 and Workspace:GetServerTimeNow() + left or nil)
	player:SetAttribute("LimitedBoughtWeek", profile.Purchases.LimitedWeek)
	if left > 0 then
		task.delay(left + SPEED_END_MARGIN, function()
			local p = player.Parent and PlayerData.get(player)
			if p and (p.LimitedLuckUntil or 0) <= os.time() then
				player:SetAttribute("LimitedPotion", nil)
				player:SetAttribute("LimitedPotionUntil", nil)
			end
		end)
	end
end

local function serverLuck(player, data)
	-- (also Monetization.serverLuck: the Rewards service's 14-day attendance gift)
	local now = Workspace:GetServerTimeNow()
	local untilNow = ReplicatedStorage:GetAttribute("ServerLuckUntil") or 0
	local active = untilNow > now
	local current = active and (ReplicatedStorage:GetAttribute("ServerLuck") or 1) or 1
	local seconds = data.Minutes * 60
	-- the same or a weaker boost on top of a running one adds its time; a stronger one starts over
	local ends = (active and data.LuckMultiplier <= current) and untilNow + seconds or now + seconds
	ReplicatedStorage:SetAttribute("ServerLuck", math.max(current, data.LuckMultiplier))
	ReplicatedStorage:SetAttribute("ServerLuckUntil", ends)
	ReplicatedStorage:SetAttribute("ServerLuckBy", player.DisplayName)
	ReplicatedStorage:SetAttribute("ServerLuckByUserId", player.UserId) -- (2026-10-02: the altar's sky panel shows their avatar)
	player:SetAttribute("LuckCrownUntil", math.max(player:GetAttribute("LuckCrownUntil") or 0, now + data.CrownMinutes * 60))
	Net.pushAll("Banner", string.format("🍀 %s님이 서버 모두에게 뽑기 행운 ×%d를 %d분 선물했어요! 지금 뽑으면 이득!",
		player.DisplayName, data.LuckMultiplier, data.Minutes), "Gold")
end

-- give what one purchase of key buys; returns the text for the notice
local function grant(player, key)
	local profile = PlayerData.get(player)
	local kind, data = product(key)
	if not profile or not kind then
		error("unknown product " .. tostring(key))
	end
	local level = profile.DefenseLevel
	local first = not profile.Purchases.FirstDone
	-- the first pack's extra hours (at most FirstPurchaseMaxBonusHours; Formulas.firstPurchaseBonusHours)
	local function withBonus(hours)
		return hours + (first and Formulas.firstPurchaseBonusHours(hours) or 0)
	end
	local parts = {}
	local reward = nil -- keys into the profile (RewardLogic.apply)
	if kind == "StarterPack" then
		reward = { Keys = Formulas.keyPackKeys(level, data.KeyHours), SpecialKeys = data.SpecialKeys }
		setLuck(player, data.LuckMinutes)
		local sure = Formulas.starterSureRarity(level)
		addSureDraw(player, sure)
		table.insert(parts, string.format("⭐ %s 확정 뽑기 1회", Formulas.rarity(sure).Name))
		table.insert(parts, string.format("🍀 행운 ×%d %d분", Config.StarterMissions.LuckMultiplier, data.LuckMinutes))
	elseif kind == "LuckPotion" or kind == "LuckPotionBig" then
		setLuck(player, data.Minutes)
		table.insert(parts, string.format("🍀 뽑기 행운 ×%d %d분", data.LuckMultiplier, data.Minutes))
	elseif kind == "ServerLuckBoost" or kind == "ServerLuckBoostBig" then
		serverLuck(player, data)
		table.insert(parts, string.format("🍀 서버 전체 행운 ×%d %d분 + 👑 제단 하늘에 내 이름", data.LuckMultiplier, data.Minutes))
	elseif kind == "SpeedPotion" or kind == "SpeedPotionBig" then
		PlayerData.update(player, function(p)
			p.SpeedUntil = math.max(p.SpeedUntil or 0, os.time()) + data.Minutes * 60
		end)
		mirrorSpeed(player, PlayerData.get(player))
		table.insert(parts, string.format("👟 이동속도 +%d%% %d분", math.floor(data.SpeedBonus * 100 + 0.5), data.Minutes))
	elseif kind == "MoneyBoost" then
		PlayerData.update(player, function(p)
			p.MoneyBoostUntil = math.max(p.MoneyBoostUntil or 0, os.time()) + data.Minutes * 60
		end)
		mirrorSpeed(player, PlayerData.get(player))
		table.insert(parts, string.format("💰 번 돈 ×%d %d분", data.MoneyMultiplier, data.Minutes))
	elseif kind == "RubyKeys" then
		reward = { SpecialKeys = data.SpecialKeys }
	elseif kind == "LimitedLuckPotion" then -- (2026-10-02)
		PlayerData.update(player, function(p)
			p.LimitedLuckUntil = math.max(p.LimitedLuckUntil or 0, os.time()) + data.Minutes * 60
		end)
		mirrorLimited(player, PlayerData.get(player))
		table.insert(parts, string.format("🎖️ 한정 공룡 확률 ×%d %d분", data.LimitedMultiplier, data.Minutes))
	elseif kind == "LimitedDino" then -- (2026-10-02) this week's limited dino, sure
		local week = Formulas.limitedWeek(os.time())
		local species = ReplicatedStorage:GetAttribute("LimitedSpecies") or Formulas.limitedSpecies(week)
			or Config.Limited.Roster[1]
		local unit = nil
		PlayerData.update(player, function(p)
			unit = { Id = "U" .. p.NextUnitId, Species = species, Rarity = Formulas.limitedDinoRarity(level), Size = data.Size,
				Limited = true }
			p.NextUnitId += 1
			table.insert(p.Units, unit)
			Formulas.recordCollection(p, unit)
			p.Purchases.LimitedWeek = week
		end)
		mirrorLimited(player, PlayerData.get(player))
		table.insert(parts, string.format("%s (%s · %s)", Formulas.unitName(unit), Formulas.rarity(unit.Rarity).Name,
			Formulas.dinoSize(unit.Size).Name))
	elseif kind == "SeasonPass" then -- (2026-10-02) this season's pass (Season service)
		table.insert(parts, require(script.Parent:WaitForChild("Season")).buyPass(player))
	elseif kind == "RaceRecordReset" then -- (2026-10-01) the race record back to 0-0
		-- (2026-10-03, "기록 초기화에 숨박꼭질 기록도 포함시키자") and the 🙈 hide-and-seek record (HideSeek service)
		PlayerData.update(player, function(p)
			p.Race = { Wins = 0, Losses = 0, SkyWins = 0, SkyLosses = 0 }
			p.HideSeek = { Wins = 0, Losses = 0 }
		end)
		for _, name in ipairs({ "RaceWins", "RaceLosses", "SkyWins", "SkyLosses", "HideWins", "HideLosses" }) do
			player:SetAttribute(name, 0)
		end
		require(script.Parent:WaitForChild("Leaderboards")).hideSeekWins(player, 0) -- (off the 🙈 ranking too)
		table.insert(parts, "🏁 레이스(지상·하늘)·🙈 숨바꼭질 기록 0승 0패로 초기화")
	elseif kind == "PromotionRevive" then
		if require(script.Parent:WaitForChild("Defense")).revive(player) then
			table.insert(parts, string.format("❤️ 목숨 %d개로 승급전을 이어해요!", data.Lives))
		else
			table.insert(parts, "⏳ 다음 보스 도전을 기다리지 않고 바로 할 수 있어요")
		end
	elseif string.match(kind, "^BoxRush%d$") then
		table.insert(parts, require(script.Parent:WaitForChild("Boxes")).rush(player, data.Seconds))
	elseif kind == "KeyPack" then
		local normal, gold = Formulas.keyPackSplit(level, withBonus(data.Hours), PlayerData.hourlyIncome(player)) -- (2026-10-02: part in gold keys)
		reward = { Keys = normal, SpecialKeys = { Gold = gold } }
		if not profile.Purchases.FirstKeyPack then -- (2026-10-02) the first key pack: a sure legendary draw too
			local rarity = Config.Monetization.FirstKeyPackGuaranteed
			PlayerData.update(player, function(p)
				p.Purchases.FirstKeyPack = true
			end)
			addSureDraw(player, rarity)
			player:SetAttribute("FirstKeyPackDone", true)
			table.insert(parts, string.format("⭐ %s 확정 뽑기 1회", Formulas.rarity(rarity).Name))
		end
	elseif kind == "MoneyPack" then
		local money = Formulas.moneyPackMoney(level, PlayerData.hourlyIncome(player), withBonus(data.Hours))
		PlayerData.addMoney(player, money, "purchase")
		table.insert(parts, "💰 " .. Formulas.shortNumber(money) .. "원")
	else
		error("no grant for " .. key)
	end
	if reward then
		PlayerData.update(player, function(p)
			RewardLogic.apply(p, reward)
		end)
		table.insert(parts, 1, RewardLogic.text(reward, level))
	end
	local countsAsFirst = kind == "KeyPack" or kind == "MoneyPack"
	PlayerData.update(player, function(p)
		p.Purchases.Bought[key] = (p.Purchases.Bought[key] or 0) + 1
		if kind == "KeyPack" or kind == "MoneyPack" then -- the packs bought today (M.PackDailyLimit)
			local day = RewardLogic.dayNumber(os.time())
			if p.Purchases.Day ~= day then
				p.Purchases.Day, p.Purchases.DayBought = day, {}
			end
			p.Purchases.DayBought = p.Purchases.DayBought or {}
			p.Purchases.DayBought[key] = (p.Purchases.DayBought[key] or 0) + 1
		end
		if countsAsFirst then
			p.Purchases.FirstDone = true
		end
	end)
	mirrorPasses(player, PlayerData.get(player))
	local text = table.concat(parts, " · ")
	if first and countsAsFirst then
		text = text .. string.format(" (첫 구매 보너스 +%g시간치!)", Formulas.firstPurchaseBonusHours(data.Hours))
	end
	return text
end

local function grantAndTell(player, key)
	local text = grant(player, key)
	say(player, "💎 구매 완료!", text .. " 받았어요. 고마워요!")
	Net.push(player, "PurchaseDone", key)
end

local function processReceipt(receipt)
	if TutorialField.isField() then
		-- (2026-10-03) never into a tutorial field's practice save: Roblox gives it again once they are back in the game
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	local player = Players:GetPlayerByUserId(receipt.PlayerId)
	local key = productByAsset[receipt.ProductId]
	if not player or not key or not PlayerData.isLoaded(player) then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	if PlayerData.isPractice(player) and key ~= "PromotionRevive" then
		if not practiceTold[player] then
			practiceTold[player] = true
			say(player, "💎 구매 완료!", "📦 예전 데이터가 돌아오면 바로 받아요 · 튜토리얼을 마치면 돌아와요")
		end
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	local profile = PlayerData.get(player)
	local id = tostring(receipt.PurchaseId)
	if profile.Purchases.Receipts[id] then
		return Enum.ProductPurchaseDecision.PurchaseGranted -- given already (a retry)
	end
	local passKey = string.match(key, "^Pass:(.+)$") -- (a pass sold as a developer product: kept for good)
	local ok, err
	if passKey then
		ok, err = pcall(givePass, player, passKey)
	else
		ok, err = pcall(grantAndTell, player, key)
	end
	if not ok then
		warn("[Monetization] grant failed:", key, err)
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	PlayerData.update(player, function(p)
		p.Purchases.Receipts[id] = os.time()
		local ids = {}
		for rid, at in pairs(p.Purchases.Receipts) do
			table.insert(ids, { rid, at })
		end
		table.sort(ids, function(a, b)
			return a[2] > b[2]
		end)
		for i = RECEIPTS_KEPT + 1, #ids do
			p.Purchases.Receipts[ids[i][1]] = nil
		end
	end)
	if not PlayerData.save(player) then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	return Enum.ProductPurchaseDecision.PurchaseGranted
end

-- passes: owned ones into the profile and attributes
function mirrorPasses(player, profile)
	for key in pairs(M.GamePassIds) do
		player:SetAttribute("Pass" .. key, profile.Passes[key] == true or nil)
	end
	player:SetAttribute("VIP", profile.Passes.VIP == true or nil)
	-- for the 💎 shop: the first purchase's bonus still ahead, the starter pack already bought
	player:SetAttribute("FirstPurchaseDone", profile.Purchases.FirstDone == true or nil)
	player:SetAttribute("FirstKeyPackDone", profile.Purchases.FirstKeyPack == true or nil)
	player:SetAttribute("StarterBought", (profile.Purchases.Bought.StarterPack or 0) > 0 or nil)
	-- the packs bought today, for the shop's daily limit (2026-10-01): PacksDay = that day's number
	player:SetAttribute("PacksDay", profile.Purchases.Day)
	for key, n in pairs(profile.Purchases.DayBought or {}) do
		player:SetAttribute("Today_" .. key, n)
	end
end

function givePass(player, key)
	PlayerData.update(player, function(p)
		p.Passes[key] = true
	end)
	mirrorPasses(player, PlayerData.get(player))
	MoveGuard.refresh(player)
	require(script.Parent:WaitForChild("Unlocks")).passBought(player, key)
	local names = { DoubleMoney = "💰 게임머니 2배", DoubleBag = "🎒 가방 용량 2배 + 빠른 채굴", PlacementSlot = "🦖 공룡 자리 +1",
		FarmSlots = "🌾 농장 칸 +10", VIP = "⭐ VIP", AutoMine = "⛏️ 자동 채굴" }
	say(player, "💎 게임패스!", (names[key] or key) .. " 이제 계속 적용돼요. 고마워요!")
	Net.push(player, "PurchaseDone", key)
	if key == "VIP" then -- (2026-10-02: today's VIP gift at once, not at the next check minutes later)
		task.delay(2, vipDaily, player)
	end
end

local function checkPasses(player)
	for key, id in pairs(M.GamePassIds) do
		if id > 0 then
			local ok, owns = pcall(MarketplaceService.UserOwnsGamePassAsync, MarketplaceService, player.UserId, id)
			local profile = PlayerData.get(player)
			if ok and owns and profile and not profile.Passes[key] then
				PlayerData.update(player, function(p)
					p.Passes[key] = true
				end)
				mirrorPasses(player, PlayerData.get(player))
				require(script.Parent:WaitForChild("Unlocks")).passBought(player, key)
			end
		end
	end
	local profile = PlayerData.get(player)
	if profile then
		mirrorPasses(player, profile)
	end
end

-- VIP: DailyKeyHours of keys once a day
function vipDaily(player, joining)
	local profile = PlayerData.get(player)
	if not profile or not profile.Passes.VIP then
		return
	end
	local today = RewardLogic.dayNumber(os.time())
	if profile.Purchases.VipDay == today then
		if joining then -- (2026-10-02, "vip 구매는 뭘 준 거, 뭐 안 보이잖아": never silent on joining)
			say(player, "⭐ VIP", "⭐ 오늘 VIP 선물은 벌써 받았어요! 내일 또 받아요")
		end
		return
	end
	local vip = Config.GamePasses.VIP
	if Policy.isRestricted(player) then -- (keys lead to draws: the stand-in, design 14)
		local alt = vip.RestrictedDaily
		PlayerData.update(player, function(p)
			p.Purchases.VipDay = today
			p.SpeedUntil = math.max(p.SpeedUntil or 0, os.time()) + alt.SpeedMinutes * 60
			for kind, n in pairs(alt.Bombs) do
				p.Bombs[kind] = math.min(Config.Bombs.MaxHeld, (p.Bombs[kind] or 0) + n)
			end
		end)
		mirrorSpeed(player, PlayerData.get(player))
		say(player, "⭐ VIP", string.format("오늘의 VIP 선물: 👟 이동속도 +%d%% %d분 + 💥 알 폭탄 %d개 + 💩 똥 폭탄 %d개!",
			math.floor(Config.Products.SpeedPotion.SpeedBonus * 100 + 0.5), alt.SpeedMinutes, alt.Bombs.Egg, alt.Bombs.Poop))
		return
	end
	local keys = Formulas.keyPackKeys(profile.DefenseLevel, vip.DailyKeyHours)
	local reward = { Keys = keys, SpecialKeys = vip.DailySpecialKeys }
	PlayerData.update(player, function(p)
		p.Purchases.VipDay = today
		RewardLogic.apply(p, reward)
	end)
	say(player, "⭐ VIP", string.format("오늘의 VIP 선물 %s 받았어요!", RewardLogic.text(reward, profile.DefenseLevel)))
end

-- the starter pack, offered on joining (not bought, not in the tutorial, allowed here): waits until the player is free
-- (the tutorial done or skipped, nothing asked of them), then OfferJoinSeconds
-- (2026-10-04, "첫구매 광고는 계정단 1번만 뜨게하자": was once a session) once an account: saved in Purchases.Offers
local function offerStarter(player)
	task.wait(M.OfferJoinSeconds)
	local profile = PlayerData.get(player)
	if not player.Parent or not profile or (profile.Purchases.Bought.StarterPack or 0) > 0 or Policy.isRestricted(player) then
		return
	end
	if M.ProductIds.StarterPack == 0 and not RunService:IsStudio() then
		return
	end
	Net.push(player, "Offer", "StarterPack", "Join")
end
Monetization.offerStarter = function(player)
	if not TutorialField.isField() then
		task.spawn(offerStarter, player)
	end
end

local function offerOnJoin(player)
	if TutorialField.isField() then
		return -- (a tutorial field: never)
	end
	-- (2026-10-04, "첫구매도 오늘 하루 안 보기 넣어줘도 되겠다": it was once an account, "첫구매 광고는 계정단 1번만") every
	-- join until bought, but not on a day the player said "🙈 오늘 하루 안 보기" (Rewards: HideAdToday)
	local first = PlayerData.get(player)
	local offers = first and first.Purchases.Offers
	if offers and offers.OfferHiddenDay == RewardLogic.dayNumber(os.time()) then
		return
	end
	local started = os.clock()
	while player.Parent and os.clock() - started < OFFER_WAIT_MAX do
		local profile = PlayerData.get(player)
		local busy = not profile or not profile.Tutorial.Done or player:GetAttribute("TutorialStep")
			or player:GetAttribute("LanguagePick") or player:GetAttribute("TutorialAsk") or player:GetAttribute("TutorialTravel")
		if not busy then
			-- (2026-10-04, "구매 광고는 튜토 끝낸 사람에게만 뜨게 하자") one who skipped the tutorial (its reward still
			-- waiting: TutorialLogic.coreDue) is never offered it; one who played it to the end is
			if not profile.Starter.Done then
				return
			end
			task.wait(M.OfferJoinSeconds)
			profile = PlayerData.get(player)
			if not player.Parent or not profile or (profile.Purchases.Bought.StarterPack or 0) > 0
				or player:GetAttribute("TutorialStep") or player:GetAttribute("TutorialTravel") or Policy.isRestricted(player) then
				return
			end
			if M.ProductIds.StarterPack == 0 and not RunService:IsStudio() then
				return -- not on sale yet
			end
			Net.push(player, "Offer", "StarterPack", "Join") -- (saved as shown when the screen says it is: OfferSeen)
			return
		end
		task.wait(OFFER_WAIT_CHECK)
	end
end

-- the whole server's draw luck × data.LuckMultiplier for data.Minutes, in player's name (a crown
-- data.CrownMinutes): what the server luck products give, also the attendance gift (Rewards)
Monetization.serverLuck = serverLuck

function Monetization.init()
	-- (2026-10-04) the screen put the starter pack's offer up: never again on this account
	Net.onRequest("OfferSeen", {}, function(player)
		if PlayerData.isLoaded(player) then
			PlayerData.update(player, function(p)
				p.Purchases.Offers = p.Purchases.Offers or {}
				p.Purchases.Offers.StarterPack = true
			end)
		end
	end)
	for key, id in pairs(M.ProductIds) do
		assert(product(key), "[Monetization] no product values for " .. key)
		if id > 0 then
			productByAsset[id] = key
		end
	end
	for key, id in pairs(M.GamePassIds) do
		assert(Config.GamePasses[key], "[Monetization] no game pass values for " .. key)
		if id > 0 then
			passByAsset[id] = key
		end
	end
	for key, id in pairs(M.PassProductIds or {}) do -- (passes sold as developer products: "Pass:<key>")
		assert(Config.GamePasses[key], "[Monetization] no game pass values for " .. key)
		if id > 0 and (M.GamePassIds[key] or 0) == 0 then
			productByAsset[id] = "Pass:" .. key
		end
	end
	MarketplaceService.ProcessReceipt = processReceipt
	MarketplaceService.PromptGamePassPurchaseFinished:Connect(function(player, passId, purchased)
		local key = passByAsset[passId]
		if purchased and key and PlayerData.isLoaded(player) then
			givePass(player, key)
		end
	end)
	Net.onRequest("DevGiftSeen", {}, function(player)
		if player:GetAttribute("DevGift") then
			PlayerData.update(player, function(p)
				p.DevGiftSeen = true
			end)
			player:SetAttribute("DevGift", nil)
		end
	end)
	PlayerData.onLoaded(function(player, profile)
		local gift = Config.DevGifts[player.Name]
		if gift and not profile.DevGiftSeen then
			PlayerData.update(player, function(p)
				for _, key in ipairs(gift.Passes) do
					p.Passes[key] = true
				end
			end)
			player:SetAttribute("DevGift", true)
		end
		mirrorPasses(player, profile)
		mirrorSpeed(player, profile)
		mirrorLimited(player, profile)
		task.spawn(function()
			checkPasses(player)
			vipDaily(player, true)
		end)
		task.spawn(offerOnJoin, player)
	end)
	task.spawn(function()
		while true do
			task.wait(INCOME_MIRROR_EVERY)
			for _, player in ipairs(Players:GetPlayers()) do
				local hourly = PlayerData.hourlyIncome(player)
				player:SetAttribute("HourlyIncome", hourly and math.floor(hourly) or nil)
			end
		end
	end)
	task.spawn(function()
		while true do
			task.wait(VIP_CHECK_EVERY)
			for _, player in ipairs(Players:GetPlayers()) do
				if PlayerData.isLoaded(player) then
					vipDaily(player)
				end
			end
		end
	end)
	-- Studio only: a product or pass without its id yet is granted at once (testing the shop)
	if RunService:IsStudio() then
		Net.onRequest("StudioBuy", { "string" }, function(player, key)
			if not RunService:IsStudio() or not PlayerData.isLoaded(player) then
				return
			end
			local profile = PlayerData.get(player)
			if key == "MoneyBoost" and profile.Passes.DoubleMoney then
				return say(player, "💎", "💰 돈 2배 패스가 있어서 안 사도 돼요")
			elseif M.ProductIds[key] ~= nil then
				grantAndTell(player, key)
			elseif M.GamePassIds[key] ~= nil then
				givePass(player, key)
			end
		end)
	end
end

return Monetization
