--[[
Limited: this week's limited dino (design 13 주간 한정 공룡; 2026-10-02, 개발 순서 11). The line-up is
Config.Limited only (Formulas.limitedWeek / limitedSpecies): changing it needs no code.

- ReplicatedStorage attributes LimitedSpecies (the species Id, nil when off) and LimitedEndsAt (os.time
  the week ends): Gacha gives it its share of every draw (Formulas.gachaOdds), the gacha window shows
  the banner with the time left. Looked at every Config.Limited.CheckEvery seconds; when the week turns,
  everyone gets a notice.
- Player attribute LimitedDinos: how many limited-marked dinos (unit.Limited, from the limited share)
  the player has, kept up to date on every profile change; RebirthLook draws 🎖️ over the head from it.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))

local Limited = {}

local function update(announce)
	local now = os.time()
	local species = Formulas.limitedSpecies(Formulas.limitedWeek(now))
	if ReplicatedStorage:GetAttribute("LimitedSpecies") == species then
		return
	end
	ReplicatedStorage:SetAttribute("LimitedSpecies", species)
	ReplicatedStorage:SetAttribute("LimitedEndsAt", species and Formulas.limitedEndsAt(now) or nil)
	if announce and species then
		Net.pushAll("Notice", "🎖️ 이번 주 한정 공룡", string.format("🎖️ %s! 이번 주에만 뽑기에서 나와요",
			Formulas.species(species).Name))
	end
end

local function count(player, profile)
	local n = 0
	for _, unit in ipairs(profile.Units) do
		n += unit.Limited and 1 or 0
	end
	local shown = n > 0 and n or nil
	if player:GetAttribute("LimitedDinos") ~= shown then
		player:SetAttribute("LimitedDinos", shown)
	end
end

function Limited.init()
	update(false)
	task.spawn(function()
		while true do
			task.wait(Config.Limited.CheckEvery)
			update(true)
		end
	end)
	PlayerData.onLoaded(count)
	PlayerData.onChanged(count)
end

return Limited
