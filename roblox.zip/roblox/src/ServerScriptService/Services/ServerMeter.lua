--[[
ServerMeter (2026-10-04, "3- 4명 있으니까 서버 지연 한 번 걸리는데"): times the server's per-frame loops for the Watchdog
service (its per-second "시간" line and the record of a stalled frame), like the screens' Shared/FrameMeter.

	RunService.Heartbeat:Connect(ServerMeter.wrap("Race", function(dt) ... end))
]]

local ServerMeter = {}

ServerMeter.sink = nil -- function(kind, name, seconds): set by Watchdog

function ServerMeter.wrap(name, fn)
	return function(...)
		local started = os.clock()
		fn(...)
		if ServerMeter.sink then
			ServerMeter.sink("loop", name, os.clock() - started)
		end
	end
end

return ServerMeter
