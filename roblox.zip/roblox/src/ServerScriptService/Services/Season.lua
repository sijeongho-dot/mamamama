--[[
Season: the season pass (2026-10-02, design 2.15; the rules are SeasonLogic's, the numbers Config.Season).

- Season XP: every minute online (up to Xp.PlayMinutesPerDay a day), each reward taken in the 🎁 / 📆
  windows (Rewards.onClaim, Xp[kind]) and each promotion won (Rewards.onAdd "Promotion"). A tier
  reached says so ("🏆 시즌 레벨 n!").
- Net ask GetSeason: everything the 🏆 window shows (the season, its theme, days left, XP, both tracks with
  each reward in words and its picture, what is taken and ready, the pass, its price). Net request
  ClaimSeason(track, tier) takes one, ClaimSeason("All", 0) everything ready.
- The pass: Robux product SeasonPass (Monetization calls Season.buyPass): the pass rewards of every tier,
  this season. Bought again in the same season (it can't be, the window hides it, but a charged receipt
  is honored): RepeatBuyKeyHours of keys instead. Not sold where paid random items are restricted.
- A new season (checked on joining and every minute): what was reached and not taken is given at once
  with a notice, and it all starts over.
- Rewards given: keys, KeyHours, special keys, money (RewardLogic), LuckMinutes (draw luck, as the
  attendance's), Bombs (each kind, up to Bombs.MaxHeld), Skin (the theme's slap skin), Dino (the theme's
  dino at the best rarity drawn at its full chance (Formulas.fullTopRarity) DinoRarityBelowTop down, at least DinoMinRarity; marked 🏆, unit.Season).
- Player attributes: SeasonReady (rewards waiting: the 🏆 button's badge), SeasonTier, SeasonPass,
  SeasonVersion (changes when something did: the open window asks again).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))
local SeasonLogic = require(script.Parent:WaitForChild("SeasonLogic"))
local Policy = require(script.Parent:WaitForChild("Policy"))

local Season = {}

local C = Config.Season
local MINUTE = 60

local function say(player, text)
	Net.push(player, "Notice", "🏆 시즌 패스", text)
end

local function today()
	return RewardLogic.dayNumber(os.time())
end

local function refresh(player)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	player:SetAttribute("SeasonReady", SeasonLogic.readyCount(profile))
	player:SetAttribute("SeasonTier", (SeasonLogic.tier(profile.Season.Xp)))
	player:SetAttribute("SeasonPass", profile.Season.Premium or nil)
	player:SetAttribute("SeasonVersion", (player:GetAttribute("SeasonVersion") or 0) + 1)
end

-- the season dino's rarity: the best rarity drawn at its full chance (Formulas.fullTopRarity; 2026-10-02: was the
-- best open one, which right after an awakening is one the draws give only rarely) DinoRarityBelowTop grades
-- down, at least DinoMinRarity
local function dinoRarity(level)
	local floor = Formulas.rarityRank(C.DinoMinRarity)
	return Config.Rarities[math.max(floor, Formulas.fullTopRarity(level) - C.DinoRarityBelowTop)].Id
end

-- a season reward in words (money and keys at this level); the theme names its skin and dino
local function rewardText(reward, level, theme)
	local parts = {}
	local plain = RewardLogic.text(reward, level) -- (no emoji: the picture beside it shows the key)
	if plain ~= "" then
		table.insert(parts, plain)
	end
	if reward.LuckMinutes then
		table.insert(parts, string.format("🍀 뽑기 행운 ×%g %d분", Config.StarterMissions.LuckMultiplier, reward.LuckMinutes))
	end
	if reward.Bombs then
		table.insert(parts, string.format("💣 폭탄 %d개씩", reward.Bombs))
	end
	if reward.Skin then
		table.insert(parts, string.format("👋 %s 스킨", Formulas.skin(theme.Skin).Name))
	end
	if reward.Dino then
		table.insert(parts, string.format("🏆 %s (%s · %s)", Formulas.species(theme.Dino).Name,
			Formulas.rarity(dinoRarity(level)).Name, Formulas.dinoSize(C.DinoSize).Name))
	end
	return table.concat(parts, " · ")
end

-- its picture in the window: the dino, the skin, luck, bombs, else the best key or money
local function rewardIcon(reward, theme)
	if reward.Dino then
		return { dino = theme.Dino }
	elseif reward.Skin then
		return "Skin"
	elseif reward.LuckMinutes then
		return "Luck"
	elseif reward.Bombs then
		return "Bombs"
	end
	return RewardLogic.icon(reward)
end

-- give rewards: { { track, tier, reward }, ... } of season `id`
local function give(player, list, id)
	if #list == 0 then
		return
	end
	local theme = SeasonLogic.theme(id)
	local profile = PlayerData.get(player)
	local level = profile.DefenseLevel
	local money, luck, words = 0, 0, {}
	PlayerData.update(player, function(p)
		for _, item in ipairs(list) do
			local reward = item[3]
			table.insert(words, rewardText(reward, level, theme))
			money += RewardLogic.apply(p, reward)
			if reward.LuckMinutes then
				luck += reward.LuckMinutes
			end
			for _, kind in ipairs(reward.Bombs and Config.Bombs.Kinds or {}) do
				p.Bombs[kind.Id] = math.min(Config.Bombs.MaxHeld, (p.Bombs[kind.Id] or 0) + reward.Bombs)
			end
			if reward.Skin then
				p.Skins[theme.Skin] = true
			end
			if reward.Dino then
				local unit = { Id = "U" .. p.NextUnitId, Species = theme.Dino, Rarity = dinoRarity(level), Size = C.DinoSize,
					Season = id }
				p.NextUnitId += 1
				table.insert(p.Units, unit)
				Formulas.recordCollection(p, unit)
			end
		end
		if luck > 0 then
			p.LuckUntil = math.max(p.LuckUntil or 0, os.time()) + luck * MINUTE
		end
	end)
	if money > 0 then
		PlayerData.addMoney(player, money, "reward")
	end
	if luck > 0 then -- (the screens' luck line, as the attendance's)
		player:SetAttribute("Luck", Config.StarterMissions.LuckMultiplier)
		player:SetAttribute("LuckEndsAt", PlayerData.get(player).LuckUntil)
	end
	say(player, table.concat(words, " + ") .. " 받았어요!")
end

-- the season of today; a new one gives what was left of the old
local function ensure(player)
	local profile = PlayerData.get(player)
	if not profile or profile.Season.Id == (SeasonLogic.season(today())) then
		return -- (the same season: no write, this runs every minute)
	end
	local leftover, old
	PlayerData.update(player, function(p)
		leftover, old = SeasonLogic.ensure(p, today())
	end)
	if leftover and #leftover > 0 then
		give(player, leftover, old)
		say(player, string.format("🏆 시즌 %d이 끝나서 못 받은 보상 %d개를 모두 받았어요!", old, #leftover))
	end
	if leftover then
		refresh(player)
	end
end

local function addXp(player, amount)
	if amount <= 0 or not PlayerData.isLoaded(player) then
		return
	end
	ensure(player)
	local reached
	PlayerData.update(player, function(p)
		reached = SeasonLogic.addXp(p, amount)
	end)
	if #reached > 0 then
		say(player, string.format("🏆 시즌 레벨 %d! 시즌 창에서 보상을 받아요", reached[#reached]))
	end
	refresh(player)
end

local function claim(player, track, tier)
	if not PlayerData.isLoaded(player) then
		return
	end
	ensure(player)
	local list = {}
	PlayerData.update(player, function(p)
		if track == "All" then
			list = SeasonLogic.claimAll(p)
		elseif type(tier) == "number" and (track == "Free" or track == "Paid") then
			local reward = SeasonLogic.claim(p, track, tier)
			list = reward and { { track, tier, reward } } or {}
		end
	end)
	give(player, list, PlayerData.get(player).Season.Id)
	refresh(player)
end

local function snapshot(player)
	local profile = PlayerData.get(player)
	if not profile then
		return nil
	end
	ensure(player)
	profile = PlayerData.get(player)
	local s = profile.Season
	local id, day, left = SeasonLogic.season(today())
	local theme, themeIndex = SeasonLogic.theme(id)
	local level = profile.DefenseLevel
	local tier, into, need = SeasonLogic.tier(s.Xp)
	local tiers = {}
	for t = 1, C.Tiers do
		local row = { Tier = t }
		for _, track in ipairs(SeasonLogic.TRACKS) do
			local reward = C[track][t]
			row[track] = { Text = rewardText(reward, level, theme), Icon = rewardIcon(reward, theme),
				Taken = s[track][tostring(t)] == true, Ready = SeasonLogic.ready(profile, track, t) }
		end
		tiers[t] = row
	end
	return {
		Id = id, Theme = theme.Name, ThemeIndex = themeIndex, Day = day, DaysLeft = left,
		Xp = s.Xp, Tier = tier, Into = into, Need = need, Tiers = tiers,
		Premium = s.Premium, Restricted = Policy.isRestricted(player), PassRobux = Config.Products.SeasonPass.Robux,
		PlayMinutes = s.PlayDay == today() and s.PlayMinutes or 0,
	}
end

-- Monetization: the SeasonPass product was bought; returns the words for the thank-you notice
function Season.buyPass(player)
	ensure(player)
	local bought = false
	PlayerData.update(player, function(p)
		bought = SeasonLogic.buyPass(p)
	end)
	refresh(player)
	if bought then
		return string.format("🏆 시즌 %d 패스 (지금까지 레벨의 패스 보상도 받을 수 있어요)", PlayerData.get(player).Season.Id)
	end
	local reward = { KeyHours = C.RepeatBuyKeyHours }
	PlayerData.update(player, function(p)
		RewardLogic.apply(p, reward)
	end)
	return RewardLogic.text(reward, PlayerData.get(player).DefenseLevel) .. " (이미 패스가 있어서 열쇠로)"
end

-- Studio tests (TestCommands): season XP now
function Season.addXp(player, amount)
	addXp(player, amount)
end

function Season.init()
	Net.onAsk("GetSeason", {}, snapshot)
	Net.onRequest("ClaimSeason", { "string", "number" }, claim)
	PlayerData.onLoaded(function(player)
		ensure(player)
		refresh(player)
	end)
	Rewards.onClaim(function(player, kind)
		addXp(player, C.Xp[kind] or 0)
	end)
	Rewards.onAdd(function(player, kind, amount)
		if kind == "Promotion" then
			addXp(player, C.Xp.Promotion * (amount or 1))
		end
	end)
	task.spawn(function() -- a minute online: play XP (and a new season at midnight)
		while true do
			task.wait(MINUTE)
			for _, player in ipairs(Players:GetPlayers()) do
				if PlayerData.isLoaded(player) then
					ensure(player)
					local xp = 0
					PlayerData.update(player, function(p)
						xp = SeasonLogic.playXp(p, today(), 1)
					end)
					if xp > 0 then
						addXp(player, xp)
					end
				end
			end
		end
	end)
end

return Season
