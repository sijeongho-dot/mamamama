--[[
BetaLog: the closed beta's tools on the server (2026-10-02, design 17 "업데이트 소식 창 + 버그 신고 버튼 +
오류 기록 저장"; Config.Beta).

- Bug reports: Net request BugReport(kind, text) from the 🐞 window (Shared/BetaWindows). Checked here: a
  kind from Config.Beta.ReportKinds, ReportMinLength..ReportMaxLength characters, ReportCooldown seconds
  apart and ReportsPerDay a day per player (profile BugReports). Kept with what the server knows of the
  moment (level, rebirths, money, keys, where the player stands, the tutorial step, players here, the
  server's frame rate line, the build) and the player's last RecentErrorsInReport script errors. The text
  is only read by the developer (Studio), never shown to other players.
- Script errors: on players' screens (Watchdog's ClientError calls BetaLog.clientError) and on the server
  (ScriptContext.Error). The same error (its first line, where it happened) is merged: a count, the first
  and last time, how many players, one sample.
- Both are collected and written every FlushSeconds (and when the server closes) to the DataStore
  Config.Beta.StoreName, one key a day for each ("Reports_<day>", "Errors_<day>"; the day of
  Config.Rewards), with UpdateAsync so every server adds to the same day. Without DataStore access
  (Studio with API access off) they only go to the output.
- Reading them: BetaLog.read(kind, day) (the Studio commands ;reports and ;errors in TestCommands).
- The update news (Config.Beta.News): on joining with news not seen yet (its Version and lines), Net push OpenNews after
  Delay; NewsSeen(version) from the window's 확인 records it, and then the attendance window opens if
  something waits there (Rewards.popupAttendance; it does not open over the news). A player who has not
  finished the tutorial is marked as having seen it (everything is new to them). Player attribute
  NewsPending while it is up.
]]

local DataStoreService = game:GetService("DataStoreService")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ScriptContext = game:GetService("ScriptContext")
local TextService = game:GetService("TextService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))

local BetaLog = {}

local B = Config.Beta
local SIGNATURE_LENGTH = 120 -- characters of an error's first line that make it "the same error"
local INSTALL_MARK = "GameInstall" -- the attribute tools/build_installer.py puts on every script (its build)

local store = nil
local reports = {} -- reports waiting to be written: { entry, ... }
local surveys = {}
local errors = {} -- errors waiting: [signature] = { M, T, C, Users = { [userId] = true }, First, Last, Who, Side }
local recent = {} -- [player] = { "message", ... }: their last script errors (for their next report)
local started = os.time()
local mailQueue = {}
local mailTarget = nil
local KST = 9 * 3600

local function today()
	return RewardLogic.dayNumber(os.time())
end

local function build()
	return script:GetAttribute(INSTALL_MARK) or "studio"
end

local function clip(text, n)
	text = tostring(text or "")
	return #text > n and string.sub(text, 1, n) or text
end

-- ---------------------------------------------------------------------------
-- collecting
-- ---------------------------------------------------------------------------

local function addError(side, message, trace, player)
	message = clip(message, B.ErrorTextLength)
	local first = string.match(message, "^[^\n]*") or message
	local signature = side .. ":" .. clip(first, SIGNATURE_LENGTH)
	local now = os.time()
	local e = errors[signature]
	if not e then
		e = { M = message, T = clip(trace, B.ErrorTextLength), C = 0, Users = {}, First = now, Side = side }
		errors[signature] = e
	end
	e.C += 1
	e.Last = now
	if player then
		e.Users[tostring(player.UserId)] = true
		e.Who = player.Name
		local list = recent[player] or {}
		table.insert(list, clip(first, SIGNATURE_LENGTH))
		while #list > B.RecentErrorsInReport do
			table.remove(list, 1)
		end
		recent[player] = list
	end
end

-- (2026-10-04, "폰으로 실제게임에서 데이터로 바꿔도 당시에 안 됐음" - error 279: the server took no one in) Watchdog: a
-- long server stall, kept with the errors (first line: what took the time, so the same cause is merged and counted)
function BetaLog.serverStall(cause, detail)
	addError("stall", cause, detail or "", nil)
end

-- Watchdog: a script error on a player's screen (already limited per minute there)
function BetaLog.clientError(player, message, trace)
	addError("client", message, trace, player)
end

local function kindOk(kind)
	for _, k in ipairs(B.ReportKinds) do
		if k.Id == kind then
			return true
		end
	end
	return false
end

local function say(player, text)
	Net.push(player, "Notice", "🐞 버그 신고", text)
end

local function mailUrl()
	if mailTarget == nil then
		local ok, secret = pcall(HttpService.GetSecret, HttpService, B.Mail.SecretName)
		mailTarget = ok and secret:AddPrefix(B.Mail.UrlPrefix):AddSuffix(B.Mail.UrlSuffix) or false
		if not mailTarget then
			print("[BetaLog] 버그 신고 메일 꺼짐: 비밀값 " .. B.Mail.SecretName .. "이 없어요 (docs/bug_mail.md)")
		end
	end
	return mailTarget or nil
end

local function kindName(kind)
	for _, k in ipairs(B.ReportKinds) do
		if k.Id == kind then
			return k.Name
		end
	end
	return kind
end

local function queueMail(player, entry)
	if not mailUrl() then
		return
	end
	local ok, safe = pcall(function()
		return TextService:FilterStringAsync(entry.Text, player.UserId):GetNonChatStringForBroadcastAsync()
	end)
	table.insert(mailQueue, string.format("%s · %s %s (%d) · LV %d · 🔄%d · 📍%s · 👥%d · 🛠️%s\n💬 %s\n⚠️ %s",
		os.date("!%m-%d %H:%M KST", entry.Time + KST), kindName(entry.Kind), entry.Name, entry.User, entry.Level or 0,
		entry.Rebirths or 0, entry.Where, entry.Players, tostring(entry.Build), ok and safe or B.Mail.FilterFailed,
		#entry.Errors > 0 and table.concat(entry.Errors, " / ") or "-"))
	while #mailQueue > B.Mail.MaxQueued do
		table.remove(mailQueue, 1)
	end
end

local function sendMail()
	local url = #mailQueue > 0 and mailUrl()
	if not url then
		return
	end
	local batch = {}
	while #mailQueue > 0 and #batch < B.Mail.MaxPerMail do
		table.insert(batch, table.remove(mailQueue, 1))
	end
	local ok, result = pcall(function()
		return HttpService:RequestAsync({
			Url = url,
			Method = "POST",
			Headers = { ["Content-Type"] = "application/json" },
			Body = HttpService:JSONEncode({
				subject = string.format(B.Mail.Subject, #batch),
				body = table.concat(batch, "\n\n") .. "\n\n" .. game.JobId,
			}),
		})
	end)
	if not ok then
		warn("[BetaLog] 버그 신고 메일을 못 보냈어요 (다음에 다시): " .. tostring(result))
		for i = #batch, 1, -1 do
			table.insert(mailQueue, 1, batch[i])
		end
		while #mailQueue > B.Mail.MaxQueued do
			table.remove(mailQueue, 1)
		end
	end
end

local function report(player, kind, text)
	local profile = PlayerData.get(player)
	if not profile or not kindOk(kind) then
		return
	end
	text = string.gsub(text, "^%s+", "")
	text = string.gsub(text, "%s+$", "")
	local length = utf8.len(text) or #text
	if length < B.ReportMinLength then
		return say(player, "✏️ 조금 더 자세히 적어 주세요")
	end
	if length > B.ReportMaxLength then
		text = string.sub(text, 1, utf8.offset(text, B.ReportMaxLength + 1) - 1)
	end
	local now, day = os.time(), today()
	local r = profile.BugReports
	if r.Day == day and r.Count >= B.ReportsPerDay then
		return say(player, "🐞 오늘은 신고를 많이 보냈어요. 내일 또 알려 주세요!")
	end
	if now - (r.Last or 0) < B.ReportCooldown then
		return say(player, string.format("⏱️ %d초 뒤에 다시 보낼 수 있어요", B.ReportCooldown - (now - r.Last)))
	end
	PlayerData.update(player, function(p)
		if p.BugReports.Day ~= day then
			p.BugReports.Day, p.BugReports.Count = day, 0
		end
		p.BugReports.Count += 1
		p.BugReports.Last = now
	end)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local at = root and root.Position
	local entry = {
		Time = now,
		User = player.UserId,
		Name = player.Name,
		Kind = kind,
		Text = text,
		Level = profile.DefenseLevel,
		Rebirths = profile.Rebirths,
		Money = math.floor(profile.Money),
		Keys = profile.Keys,
		Where = at and string.format("%d,%d,%d", at.X, at.Y, at.Z) or "-",
		Tutorial = player:GetAttribute("TutorialStep"),
		Language = player:GetAttribute("Language") or "en",
		Players = #Players:GetPlayers(),
		Server = string.match(ReplicatedStorage:GetAttribute("ServerStats") or "", "^[^\n]*") or "",
		Uptime = now - started,
		Build = build(),
		Errors = recent[player] or {},
	}
	table.insert(reports, entry)
	task.spawn(queueMail, player, entry)
	say(player, "고마워요! 신고가 개발자에게 전해졌어요 🙏")
	print(string.format("[BetaLog] 버그 신고 %s (%s): %s", player.Name, kind, text))
end

-- ---------------------------------------------------------------------------
-- writing
-- ---------------------------------------------------------------------------

-- a failed write: without DataStore access (Studio's API access off) stop trying, it only fills the output
local function failed(what, err)
	local text = tostring(err)
	if text:find("StudioAccessToApisNotAllowed") or text:find("403") then
		store = nil
		warn("[BetaLog] DataStore를 쓸 수 없어 신고·오류는 출력 창에만 남아요")
	else
		warn(string.format("[BetaLog] %s 저장 실패: %s", what, text))
	end
end

local function flush()
	local myReports, myErrors, mySurveys = reports, errors, surveys
	reports, errors, surveys = {}, {}, {}
	if #myReports == 0 and next(myErrors) == nil and next(mySurveys) == nil then
		return
	end
	if not store then
		return -- (no DataStore: they were printed when they came)
	end
	local day = today()
	if next(mySurveys) ~= nil then
		local ok, err = pcall(function()
			store:UpdateAsync("Survey_" .. day, function(old)
				old = type(old) == "table" and old or {}
				for key, n in pairs(mySurveys) do
					old[key] = (old[key] or 0) + n
				end
				return old
			end)
		end)
		if not ok then
			failed("설문", err)
		end
	end
	if #myReports > 0 then
		local ok, err = pcall(function()
			store:UpdateAsync("Reports_" .. day, function(old)
				old = type(old) == "table" and old or { List = {} }
				for _, r in ipairs(myReports) do
					table.insert(old.List, r)
				end
				while #old.List > B.ReportsKeptPerDay do
					table.remove(old.List, 1)
				end
				return old
			end)
		end)
		if not ok then
			failed("버그 신고", err)
		end
	end
	if store and next(myErrors) ~= nil then
		local ok, err = pcall(function()
			store:UpdateAsync("Errors_" .. day, function(old)
				old = type(old) == "table" and old or { Map = {}, Dropped = 0 }
				local count = 0
				for _ in pairs(old.Map) do
					count += 1
				end
				for signature, e in pairs(myErrors) do
					local users = 0
					for _ in pairs(e.Users) do
						users += 1
					end
					local saved = old.Map[signature]
					if saved then
						saved.C += e.C
						saved.Last = math.max(saved.Last, e.Last)
						saved.U = (saved.U or 0) + users
						saved.Who = e.Who or saved.Who
					elseif count < B.ErrorsKeptPerDay then
						old.Map[signature] = { M = e.M, T = e.T, C = e.C, U = users, First = e.First, Last = e.Last,
							Who = e.Who, Side = e.Side, Build = build() }
						count += 1
					else
						old.Dropped = (old.Dropped or 0) + e.C
					end
				end
				return old
			end)
		end)
		if not ok then
			failed("오류 기록", err)
		end
	end
end

-- a day's saved list (Studio commands): "Reports" -> { report, ... } oldest first; "Errors" -> { error, ... }
-- most frequent first. nil, why when it can't be read
function BetaLog.read(kind, day)
	if not store then
		return nil, "DataStore를 쓸 수 없어요 (스튜디오 API 접근을 켜세요)"
	end
	flush()
	local ok, data = pcall(function()
		return store:GetAsync(kind .. "_" .. (day or today()))
	end)
	if not ok then
		return nil, tostring(data)
	end
	if kind == "Reports" then
		return data and data.List or {}
	elseif kind == "Survey" then
		return data or {}
	end
	local list = {}
	for _, e in pairs(data and data.Map or {}) do
		table.insert(list, e)
	end
	table.sort(list, function(a, b)
		return a.C > b.C
	end)
	return list, data and data.Dropped or 0
end

BetaLog.today = today

-- ---------------------------------------------------------------------------
-- the update news
-- ---------------------------------------------------------------------------

local function newsKey()
	local h = 0
	local function add(text)
		for i = 1, #text do
			h = (h * 31 + string.byte(text, i)) % 2147483647
		end
	end
	for _, list in ipairs({ B.News.Items or {}, B.News.Fixes or {} }) do
		for _, item in ipairs(list) do
			add(item.Icon .. item.Text)
		end
	end
	add(B.News.Thanks or "")
	return B.News.Version .. "#" .. h
end
local NEWS_KEY = newsKey()

local function newsSeen(player, version)
	if version ~= B.News.Version or not player:GetAttribute("NewsPending") then
		return
	end
	player:SetAttribute("NewsPending", nil)
	PlayerData.update(player, function(p)
		p.NewsSeen = NEWS_KEY
	end)
	require(script.Parent:WaitForChild("Rewards")).popupAttendance(player)
end

local function newsOnJoin(player, profile)
	if profile.NewsSeen == NEWS_KEY and not RunService:IsStudio() then
		return
	end
	if not profile.Tutorial.Done or (profile.Stats.Joins or 0) <= 1 then
		PlayerData.update(player, function(p)
			p.NewsSeen = NEWS_KEY
		end)
		return
	end
	player:SetAttribute("NewsPending", true)
	task.delay(B.News.Delay, function()
		if player.Parent and player:GetAttribute("NewsPending") then
			Net.push(player, "OpenNews")
		end
	end)
end

local function surveyAnswer(player, up, reason)
	local profile = PlayerData.get(player)
	if not profile or (profile.Survey.Asked or 0) == 0 or (profile.Survey.Vote or 0) ~= 0 then
		return
	end
	local found = false
	for _, r in ipairs(up and B.Survey.Up or B.Survey.Down) do
		found = found or r.Id == reason
	end
	if not found then
		return
	end
	PlayerData.update(player, function(p)
		p.Survey.Vote = up and 1 or -1
		p.Survey.Reason = reason
	end)
	local key = (up and "Up_" or "Down_") .. reason
	surveys[key] = (surveys[key] or 0) + 1
	surveys[up and "Up" or "Down"] = (surveys[up and "Up" or "Down"] or 0) + 1
	print(string.format("[BetaLog] 설문 %s %s (%s)", up and "👍" or "👎", reason, player.Name))
	local Analytics = require(script.Parent:WaitForChild("Analytics"))
	Analytics.custom(player, up and "SurveyUp" or "SurveyDown")
	Analytics.custom(player, "Survey" .. key)
end

local function surveyAsk(player)
	local profile = PlayerData.get(player)
	if not profile or (profile.Survey.Asked or 0) ~= 0 or not profile.Tutorial.Done
		or (profile.PlaySeconds or 0) < B.Survey.AfterMinutes * 60 then
		return
	end
	if require(script.Parent:WaitForChild("TutorialField")).isField() then
		return
	end
	PlayerData.update(player, function(p)
		p.Survey.Asked = os.time()
	end)
	Net.push(player, "Survey")
end

local function mirrorLikeAsk(player, profile)
	local l = profile.LikeAsk or {}
	player:SetAttribute("LikeAsks", l.Count or 0)
	player:SetAttribute("LikeAskAt", l.At or 0)
	player:SetAttribute("LikeFav", l.Fav == true or nil)
end

local function likeAsk(player, kind)
	local profile = PlayerData.get(player)
	if not profile or (kind ~= "Shown" and kind ~= "Fav") then
		return
	end
	local l = profile.LikeAsk
	if kind == "Shown" and (l.Count >= B.LikeAsk.Times or os.time() - l.At < B.LikeAsk.GapMinutes * 60) then
		return
	end
	PlayerData.update(player, function(p)
		if kind == "Shown" then
			p.LikeAsk.Count += 1
			p.LikeAsk.At = os.time()
		else
			p.LikeAsk.Fav = true
		end
	end)
	mirrorLikeAsk(player, PlayerData.get(player))
	require(script.Parent:WaitForChild("Analytics")).custom(player, kind == "Shown" and "LikeAskShown" or "LikeAskFav")
end

function BetaLog.init()
	local ok, result = pcall(function()
		return DataStoreService:GetDataStore(B.StoreName)
	end)
	store = ok and result or nil
	Net.onRequest("BugReport", { "string", "string" }, report)
	Net.onAsk("GetReports", { "number" }, function(player, back)
		local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))
		if not Formulas.isDeveloper(player.Name) then
			return nil
		end
		local list = BetaLog.read("Reports", today() - math.clamp(math.floor(back), 0, B.InboxDays))
		local shown = {}
		for i = #(list or {}), math.max(1, #(list or {}) - B.InboxMax + 1), -1 do
			local r = list[i]
			table.insert(shown, { Time = r.Time, Name = r.Name, Kind = r.Kind, Level = r.Level, Text = r.Text,
				Errors = r.Errors and r.Errors[1] or nil })
		end
		return shown
	end)
	Net.onRequest("NewsSeen", { "string" }, newsSeen)
	Net.onRequest("SurveyAnswer", { "boolean", "string" }, surveyAnswer)
	Net.onRequest("LikeAsk", { "string" }, likeAsk)
	PlayerData.onLoaded(mirrorLikeAsk)
	task.spawn(function()
		while true do
			task.wait(B.Survey.CheckSeconds)
			for _, player in ipairs(Players:GetPlayers()) do
				if PlayerData.isLoaded(player) then
					surveyAsk(player)
				end
			end
		end
	end)
	PlayerData.onLoaded(newsOnJoin)
	ScriptContext.Error:Connect(function(message, trace)
		addError("server", message, trace, nil)
	end)
	Players.PlayerRemoving:Connect(function(player)
		recent[player] = nil
	end)
	task.spawn(function()
		while true do
			task.wait(B.FlushSeconds)
			flush()
		end
	end)
	task.spawn(function()
		while true do
			task.wait(B.Mail.EverySeconds)
			sendMail()
		end
	end)
	game:BindToClose(function()
		task.spawn(sendMail)
		flush()
	end)
end

return BetaLog
