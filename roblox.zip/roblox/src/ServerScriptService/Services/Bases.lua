--[[
Bases: gives each player one of the 8 bases built by roblox/MapBuilder.lua (Workspace.Map.Base1..8)
and puts them on that base's team, so they spawn at its SpawnLocation (team colors match).

- Player attribute "Base" = base number; base folder attribute "OwnerUserId".
- Players.RespawnTime = Config.Respawn.Delay (design: respawn at your own base).
- Bases.near(player, instance, range): is the player's character within range of instance?
  Used by every service that checks a request against a place (deposit bin, shop).
- Bases.bigStall(folder): the base's shop stall (Base_Shop) at STALL_SCALE (once; its copies, the
  key and enhance stalls, come out the same size).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Teams = game:GetService("Teams")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))

local Bases = {}

-- display only
local TITLE_HEIGHT = 2 -- studs over the top of a stall for its name
local BANNER_HEIGHT, BANNER_THICKNESS, BANNER_GAP, BANNER_MAX_WIDTH, BANNER_UP = 1.8, 0.4, 0.3, 9, 2.4 -- a copied stall's name board (studs; its middle BANNER_UP over the ground)
local PROMPT_NEAR, PROMPT_NEAR_PART = 3, 6 -- studs: how close a prompt shows (see Bases.prompt)
local PROMPT_SPOT_UP = 3 -- studs over a model's bottom for its prompt (about a player's middle)
local TITLE_MAX_DISTANCE = 90
local TITLE_SIZE = UDim2.fromScale(9, 2.2)
local TITLE_SIZE_BIG = UDim2.fromScale(20, 4.6)
local TITLE_MAX_DISTANCE_BIG = 400
local TITLE_HEIGHT_BIG = 14 -- big places are wide and low: their name floats well above them
local SUBTITLE_WIDTH = 1.3
local SUBTITLE_SHARE = 0.55
local SUBTITLE_GAP = 0.15
local SPAWN_UP = 4
local STALL_SCALE = 1.5 -- the shop stall (Base_Shop) and its copies, bigger than modeled so the dinos inside show
local STREAM_COUNT_AT = { 8, 60 }
local STREAM_COUNT_CHUNK = 3000
local STREAM_NEAR = 200

local owners = {} -- [base number] = player
local teams = {} -- [base number] = Team

local function map()
	return Workspace:FindFirstChild("Map")
end

function Bases.folder(index)
	local m = map()
	return m and m:FindFirstChild("Base" .. index)
end

function Bases.of(player)
	return player:GetAttribute("Base")
end

function Bases.folderOf(player)
	local index = Bases.of(player)
	return index and Bases.folder(index)
end

-- the position of an instance (part, model or anything with parts inside)
function Bases.position(instance)
	if instance:IsA("BasePart") then
		return instance.Position
	elseif instance:IsA("Model") then
		return instance:GetBoundingBox().Position
	end
	local part = instance:FindFirstChildWhichIsA("BasePart", true)
	return part and part.Position
end

function Bases.near(player, instance, range)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local pos = instance and Bases.position(instance)
	return root ~= nil and pos ~= nil and (root.Position - pos).Magnitude <= range
end

local function teamFor(index)
	if teams[index] then
		return teams[index]
	end
	local folder = Bases.folder(index)
	local colorName = folder and folder:GetAttribute("TeamColor")
	if not colorName then
		return nil
	end
	local team = Instance.new("Team")
	team.Name = "기지 " .. index
	team.TeamColor = BrickColor.new(colorName)
	team.AutoAssignable = false
	team.Parent = Teams
	teams[index] = team
	return team
end

local function assign(player)
	local had = player:GetAttribute("Base")
	if had and owners[had] == player then
		return had
	end
	for index = 1, Config.Map.BaseCount do
		if not owners[index] and Bases.folder(index) then
			owners[index] = player
			player:SetAttribute("Base", index)
			-- where the base is, for screens that have not streamed its parts in (the way home with keys)
			local zone = Bases.folder(index):FindFirstChild("SafeZone")
			if zone then
				player:SetAttribute("BaseCenter", (zone.CFrame * CFrame.new(0, -zone.Size.Y / 2, 0)).Position)
				player:SetAttribute("BaseSize", zone.Size)
			end
			Bases.folder(index):SetAttribute("OwnerUserId", player.UserId)
			local team = teamFor(index)
			if team then
				player.Team = team
				local character = player.Character
				local spawn = Bases.folder(index):FindFirstChild("SpawnLocation", true)
				if character and spawn and spawn:IsA("BasePart") then
					require(script.Parent:WaitForChild("MoveGuard")).allow(player)
					character:PivotTo(spawn.CFrame * CFrame.new(0, SPAWN_UP, 0))
				end
			end
			return index
		end
	end
	warn("[Bases] 빈 기지가 없습니다: " .. player.Name)
	player:Kick("서버가 가득 찼어요 (최대 " .. Config.Server.MaxPlayers .. "명). 다른 서버로 들어와 주세요")
	return nil
end

local function countStreamParts()
	local m = map()
	if not m then
		return
	end
	local radius = Workspace.StreamingEnabled and Workspace.StreamingTargetRadius or math.huge
	local r2 = radius * radius
	local n2 = STREAM_NEAR * STREAM_NEAR
	local centers, homes = {}, {}
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		local spawn = folder and folder:FindFirstChild("SpawnLocation", true)
		if spawn and spawn:IsA("BasePart") then
			centers[index] = spawn.Position
		end
		local zone = folder and folder:FindFirstChild("SafeZone")
		if zone then
			homes[index] = zone.Position
		end
	end
	local counts, near = {}, {}
	local stack, seen = { m }, 0
	while #stack > 0 do
		for _, d in ipairs(table.remove(stack):GetChildren()) do
			if d:IsA("BasePart") then
				local p = d.Position
				for index, c in pairs(centers) do
					local dx, dz = p.X - c.X, p.Z - c.Z
					if dx * dx + dz * dz <= r2 then
						counts[index] = (counts[index] or 0) + 1
					end
				end
				for index, h in pairs(homes) do
					local dx, dz = p.X - h.X, p.Z - h.Z
					if dx * dx + dz * dz <= n2 then
						near[index] = (near[index] or 0) + 1
					end
				end
			end
			table.insert(stack, d)
			seen += 1
			if seen % STREAM_COUNT_CHUNK == 0 then
				task.wait()
			end
		end
	end
	local most = 0
	for index in pairs(centers) do
		ReplicatedStorage:SetAttribute("StreamParts" .. index, counts[index] or 0)
		most = math.max(most, counts[index] or 0)
	end
	ReplicatedStorage:SetAttribute("StreamPartsMost", most)
	for index in pairs(homes) do
		ReplicatedStorage:SetAttribute("StreamNear" .. index, near[index] or 0)
	end
	ReplicatedStorage:SetAttribute("StreamNearRadius", STREAM_NEAR)
end

function Bases.init()
	for _, at in ipairs(STREAM_COUNT_AT) do
		task.delay(at, countStreamParts)
	end
	if not map() then
		warn("[Bases] Workspace.Map이 없습니다. roblox/MapBuilder.lua를 먼저 실행하세요.")
	end
	Players.RespawnTime = Config.Respawn.Delay
	if (Players.MaxPlayers or 0) > Config.Server.MaxPlayers then -- a place setting scripts can't change
		warn(string.format("[Bases] 서버 최대 인원이 %d명이에요. 기지는 %d개라서 %d명으로 맞춰 주세요: "
			.. "스튜디오 홈 > 게임 설정 > 장소(Places) > 최대 플레이어 수", Players.MaxPlayers, Config.Map.BaseCount,
			Config.Server.MaxPlayers))
	end
	Players.PlayerAdded:Connect(assign)
	Players.PlayerRemoving:Connect(function(player)
		local index = Bases.of(player)
		if index and owners[index] == player then
			owners[index] = nil
			local folder = Bases.folder(index)
			if folder then
				folder:SetAttribute("OwnerUserId", nil)
			end
		end
	end)
	for _, player in ipairs(Players:GetPlayers()) do
		task.spawn(assign, player)
	end
end

-- a name floating over a place ("🛒 상점", "💰 광물 입금소", "🦖 공룡 강화", ...), seen from afar.
-- big: a larger name seen from farther (the arena, the key altar); height: studs over the top instead
-- of the usual
function Bases.title(model, text, color, big, height)
	local old = model:FindFirstChild("Title")
	if old then
		old:Destroy()
	end
	local part = model:IsA("BasePart") and model or model:FindFirstChildWhichIsA("BasePart", true)
	if not part then
		return nil
	end
	local center, size = part.Position, part.Size
	if model:IsA("Model") then
		local cf
		cf, size = model:GetBoundingBox()
		center = cf.Position
	end
	local title = Instance.new("BillboardGui")
	title.Name = "Title"
	title.Size = big and TITLE_SIZE_BIG or TITLE_SIZE
	-- over the middle of the whole model, shown from its first part
	title.StudsOffsetWorldSpace = center - part.Position
		+ Vector3.new(0, size.Y / 2 + (height or (big and TITLE_HEIGHT_BIG or TITLE_HEIGHT)), 0)
	title.SizeOffset = Vector2.new(0, 0.5)
	title.MaxDistance = big and TITLE_MAX_DISTANCE_BIG or TITLE_MAX_DISTANCE
	title.Adornee = part
	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.Font = Enum.Font.GothamBold
	label.TextScaled = true
	label.TextColor3 = color or Color3.new(1, 1, 1)
	label.TextStrokeTransparency = 0.3
	label.Text = text
	label.Parent = title
	title.Parent = model
	return title
end

function Bases.subtitle(model, text, color)
	local old = model:FindFirstChild("TitleLine")
	if old then
		old:Destroy()
	end
	local title = model:FindFirstChild("Title")
	if not title then
		return nil
	end
	local line = title:Clone()
	line.Name = "TitleLine"
	local height = title.Size.Y.Scale * SUBTITLE_SHARE
	line.Size = UDim2.fromScale(title.Size.X.Scale * SUBTITLE_WIDTH, height)
	line.StudsOffsetWorldSpace = title.StudsOffsetWorldSpace - Vector3.new(0, height + SUBTITLE_GAP, 0)
	local label = line:FindFirstChildWhichIsA("TextLabel")
	if label then
		label.Text = text
		label.TextColor3 = color or Color3.new(1, 1, 1)
	end
	line.Parent = model
	return line
end

local function groundBelow(position, ignore)
	local params = RaycastParams.new()
	params.FilterDescendantsInstances = ignore
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true
	local hit = Workspace:Raycast(position + Vector3.new(0, 40, 0), Vector3.new(0, -120, 0), params)
	return hit and hit.Position.Y or position.Y
end
Bases.groundBelow = groundBelow -- the ground height under a position (the Ride pedestal)

-- another stall like the base's shop stall (a copy of Base_Shop without its prompts and title, or a
-- plain counter without it), standing on the ground at spot, its front toward look; named name,
-- put in the base folder. The enhance stall and the key stall are made this way.
function Bases.bigStall(folder)
	local shop = folder and folder:FindFirstChild("Base_Shop")
	if shop and shop:IsA("Model") and math.abs(shop:GetScale() - STALL_SCALE) > 1e-3 then
		shop:ScaleTo(STALL_SCALE) -- about its pivot, the bottom middle (MapBuilder): it stays on the ground
	end
	return shop
end

function Bases.copyStall(folder, name, spot, look, fallbackColor, bannerText)
	look = Vector3.new(look.X, 0, look.Z).Unit
	local shop = Bases.bigStall(folder)
	local stall
	if shop then
		stall = shop:Clone()
		for _, d in ipairs(stall:GetDescendants()) do
			if d:IsA("ProximityPrompt") or d:IsA("Script") or d:IsA("LocalScript") or d.Name == "Title"
				or (d:IsA("Attachment") and string.find(d.Name, "PromptSpot$")) then
				d:Destroy()
			end
		end
		-- keep the shop's turn relative to its facing, so the copy faces the same way as the shop does
		local shopPivot = shop:GetPivot()
		local shopFacing = CFrame.lookAt(shopPivot.Position, shopPivot.Position + look)
		local turn = shopFacing:ToObjectSpace(shopPivot).Rotation
		local ground = Vector3.new(spot.X, groundBelow(spot, { shop, stall }), spot.Z)
		stall:PivotTo(CFrame.lookAt(ground, ground + look) * turn)
	else
		stall = Instance.new("Model")
		local ground = Vector3.new(spot.X, groundBelow(spot, {}), spot.Z)
		local counter = Instance.new("Part")
		counter.Name = "Counter"
		counter.Size = Vector3.new(6, 3, 3)
		counter.CFrame = CFrame.lookAt(ground + Vector3.new(0, 1.5, 0), ground + Vector3.new(0, 1.5, 0) + look)
		counter.Color = fallbackColor
		counter.Anchored = true
		counter.Parent = stall
		stall.WorldPivot = CFrame.lookAt(ground, ground + look)
	end
	stall.Name = name
	-- (2026-10-02, "상점 앞인데 가판대 업글이 뜨네" → "아직도": a copy looks just like the shop, and its colors are
	-- painted into the mesh, so they can't be changed) a name board in the stall's own color across its front
	if bannerText then
		local cf, size = stall:GetBoundingBox()
		local width = math.min(size.X, size.Z, BANNER_MAX_WIDTH)
		-- (2026-10-02, "아직도": the roof board is out of sight up close) on the counter's front, at eye level, just in
		-- front of the stall's front edge (its corners measured along look)
		local front = -math.huge
		for _, x in ipairs({ -0.5, 0.5 }) do
			for _, z in ipairs({ -0.5, 0.5 }) do
				local corner = cf * CFrame.new(size.X * x, 0, size.Z * z)
				front = math.max(front, (corner.Position - cf.Position):Dot(look))
			end
		end
		local bottom = cf.Position.Y - size.Y / 2
		local at = Vector3.new(cf.Position.X, bottom + BANNER_UP, cf.Position.Z) + look * (front + BANNER_GAP)
		local board = Instance.new("Part")
		board.Name = "StallBanner"
		board.Anchored, board.CanCollide, board.CanQuery, board.CanTouch = true, false, false, false
		board.Size = Vector3.new(width, BANNER_HEIGHT, BANNER_THICKNESS)
		board.CFrame = CFrame.lookAt(at, at + look)
		board.Color = fallbackColor or Color3.new(1, 1, 1)
		board.Material = Enum.Material.SmoothPlastic
		board.Parent = stall
		for _, face in ipairs({ Enum.NormalId.Front, Enum.NormalId.Back }) do -- (readable from both sides)
			local gui = Instance.new("SurfaceGui")
			gui.Face = face
			gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
			gui.PixelsPerStud = 40
			gui.LightInfluence = 0
			gui.Parent = board
			local label = Instance.new("TextLabel")
			label.Size = UDim2.fromScale(1, 1)
			label.BackgroundTransparency = 1
			label.Font = Enum.Font.GothamBlack
			label.TextScaled = true
			label.TextColor3 = Color3.new(1, 1, 1)
			label.TextStrokeTransparency = 0.2
			label.Text = bannerText
			label.Parent = gui
			local pad = Instance.new("UIPadding")
			pad.PaddingLeft, pad.PaddingRight = UDim.new(0.04, 0), UDim.new(0.04, 0)
			pad.PaddingTop, pad.PaddingBottom = UDim.new(0.12, 0), UDim.new(0.12, 0)
			pad.Parent = label
		end
	end
	stall.Parent = folder
	return stall
end

-- a ProximityPrompt for a model; Kind and Base attributes let clients tell them apart.
-- (2026-10-02, "상점 앞인데 가판대 업글이 뜨네": it hung on the model's first part, which can sit anywhere in it, the
-- shop's at its back, so standing at the shop the stall beside it was "nearer") a model's prompt hangs on an
-- attachment at the middle of the model, PROMPT_SPOT_UP over its bottom, where players stand to use it.
-- (Client code reads where it is from the attachment's WorldPosition.)
function Bases.prompt(model, kind, baseIndex, actionText, range)
	local part = model:IsA("BasePart") and model or model:FindFirstChildWhichIsA("BasePart", true)
	if not part then
		return nil
	end
	local holder = part
	-- (2026-10-02, "가판대나 NPC나 바로 앞에가야 뜨게 하자 적용범위가 너무 넓어서 … 거리를 좀 더 좁혀도 돼") the prompt
	-- shows only right in front: PROMPT_NEAR studs past the thing's own half width (a part: PROMPT_NEAR_PART), never
	-- more than range. (The server's own checks keep range: a little slack once the prompt is up.)
	local reach = math.min(range, PROMPT_NEAR_PART)
	if not model:IsA("BasePart") then
		local cf, size = model:GetBoundingBox()
		reach = math.min(range, math.max(size.X, size.Z) / 2 + PROMPT_NEAR)
		local spot = Instance.new("Attachment")
		spot.Name = kind .. "PromptSpot"
		spot.Parent = part
		spot.WorldPosition = cf.Position - Vector3.new(0, size.Y / 2 - math.min(PROMPT_SPOT_UP, size.Y / 2), 0)
		holder = spot
	end
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = kind .. "Prompt"
	prompt.ActionText = actionText
	prompt.ObjectText = "기지 " .. baseIndex
	prompt.HoldDuration = 0
	prompt.RequiresLineOfSight = false
	prompt.MaxActivationDistance = reach
	prompt:SetAttribute("Kind", kind)
	prompt:SetAttribute("Base", baseIndex)
	prompt.Parent = holder
	return prompt
end

return Bases
