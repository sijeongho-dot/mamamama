--[[
Deposit: turning the bag into game money at the player's own base (design: 캐고, 들고, 기지에 넣어야
입금). Standing within Config.Deposit.Range of the player's own Base_DepositBin with something in the bag
empties it right away (2026-10-07, no button; checked every Config.Deposit.AutoCheckSeconds). The server pays Formulas.carryValue for the
whole bag and empties it. Deposited money can never be taken away. Keys found in the minerals
(profile FoundKeys) are banked at the same time like keys brought home from the altar
(Formulas.bankKeys: one for one, maybe a better grade).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))

local Deposit = {}

local rng = Random.new()

-- display only
local TITLE_COLOR = Color3.fromRGB(255, 220, 90)
local RING_THICKNESS = 0.15
local RING_TRANSPARENCY = 0.7
local RING_LIFT = 0.02

local function say(player, text)
	Net.push(player, "Notice", "💰 입금", text)
end

local function deposit(player, baseIndex, bin)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	if Bases.of(player) ~= baseIndex then
		return say(player, "💰 내 기지 입금통에 넣어요")
	end
	if not Bases.near(player, bin, Config.Deposit.Range) then
		return say(player, "💰 입금통에 더 가까이 가요")
	end
	local count = Formulas.carryCount(profile.Carry)
	local found = profile.FoundKeys or 0
	if count == 0 and found == 0 then
		return say(player, "🎒 가방이 비었어요! 광물을 캐 와요")
	end
	-- farm, collection and rebirth money bonus (Formulas.bonuses)
	local value = math.floor(Formulas.carryValue(profile.Carry, profile.DefenseLevel) * (1 + Formulas.bonuses(profile).Money) + 0.5)
	local saved, upgraded = Formulas.bankKeys({ Normal = found }, profile.DefenseLevel, function()
		return rng:NextNumber()
	end)
	PlayerData.update(player, function(p)
		p.Carry = {}
		p.FoundKeys = 0
		if found > 0 then
			for kind, n in pairs(saved) do
				Formulas.addSavedKeys(p, kind, n)
			end
		end
	end)
	if value > 0 then
		PlayerData.addMoney(player, value, "deposit")
	end
	Rewards.add(player, "Deposit", 1) -- daily missions
	local keysText = ""
	if found > 0 then
		local n = 0
		for _, k in pairs(saved) do
			n += k
		end
		keysText = string.format(" · 🔑 열쇠 %d개 내 거!%s", n,
			upgraded > 0 and string.format(" ⬆ %d개 윗등급", upgraded) or "")
	end
	local boost = Formulas.friendBoost(player:GetAttribute("Friends")) -- (PlayerData.addMoney pays it)
	say(player, string.format("💰 광물 %d개 넣었어요! +%s원%s%s", count, Formulas.shortNumber(value * boost + 0.5),
		boost > 1 and string.format(" (👥 친구 +%d%%)", math.floor((boost - 1) * 100 + 0.5)) or "", keysText))
end

function Deposit.init()
	-- (2026-10-02) the ⛏️ auto mining pass walks home with a full bag and empties it (StarterPlayerScripts/
	-- AutoMine): only for the pass's owners with it on, at their own bin, within Config.Deposit.Range as always
	Net.onRequest("AutoDeposit", {}, function(player)
		local profile = PlayerData.get(player)
		local index = Bases.of(player)
		if not profile or not profile.Passes.AutoMine or profile.Settings.AutoMineOff or not index then
			return
		end
		if Formulas.carryCount(profile.Carry) == 0 and (profile.FoundKeys or 0) == 0 then
			return
		end
		local folder = Bases.folder(index)
		local bin = folder and folder:FindFirstChild("Base_DepositBin")
		if bin and not bin:GetAttribute("Hidden") then
			deposit(player, index, bin)
		end
	end)
	local bins = {}
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		local bin = folder and folder:FindFirstChild("Base_DepositBin")
		if bin then
			bins[index] = bin
			Bases.title(bin, "💰 광물 입금소", TITLE_COLOR)
			local old = folder:FindFirstChild("DepositRing")
			if old then
				old:Destroy()
			end
			local at = Bases.position(bin)
			local ground = Bases.groundBelow(at, { bin })
			local ring = Instance.new("Part")
			ring.Name = "DepositRing"
			ring.Shape = Enum.PartType.Cylinder
			ring.Size = Vector3.new(RING_THICKNESS, Config.Deposit.Range * 2, Config.Deposit.Range * 2)
			ring.CFrame = CFrame.new(at.X, ground + RING_THICKNESS / 2 + RING_LIFT, at.Z) * CFrame.Angles(0, 0, math.rad(90))
			ring.Color = TITLE_COLOR
			ring.Material = Enum.Material.Neon
			ring.Transparency = RING_TRANSPARENCY
			ring.Anchored, ring.CanCollide, ring.CanQuery, ring.CanTouch, ring.CastShadow = true, false, false, false, false
			ring.Parent = folder
		elseif folder then
			warn(string.format("[Deposit] Base%d에 Base_DepositBin이 없습니다", index))
		end
	end
	task.spawn(function()
		while true do
			task.wait(Config.Deposit.AutoCheckSeconds)
			for _, player in ipairs(Players:GetPlayers()) do
				local index = Bases.of(player)
				local bin = index and bins[index]
				local profile = bin and PlayerData.get(player)
				if profile and not bin:GetAttribute("Hidden") and (Formulas.carryCount(profile.Carry) > 0 or (profile.FoundKeys or 0) > 0)
					and Bases.near(player, bin, Config.Deposit.Range) then
					deposit(player, index, bin)
				end
			end
		end
	end)
end

return Deposit
