local MemoryStoreService = game:GetService("MemoryStoreService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ServerScriptService = game:GetService("ServerScriptService")
local TeleportService = game:GetService("TeleportService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local TutorialField = require(script.Parent:WaitForChild("TutorialField"))
local Analytics = require(script.Parent:WaitForChild("Analytics"))

local Notify = {}

local N = Config.Notify
local api = nil
local looked = false
local pinged = {}
local dueMap = nil

local function sender(messageId)
	if messageId == "" then
		return nil
	end
	if not looked then
		looked = true
		local node = ServerScriptService
		for _, name in ipairs(N.Package) do
			node = node and node:FindFirstChild(name)
		end
		local ok, module = pcall(function()
			return node and node:IsA("ModuleScript") and require(node) or nil
		end)
		api = ok and type(module) == "table" and module.createUserNotification and module or nil
		if not api then
			warn("[Notify] ServerScriptService에 Open Cloud 패키지가 없어 친구 알림을 못 보내요")
		end
	end
	return api
end

local function send(toUserId, fromUserId)
	local ok, result = pcall(api.createUserNotification, toUserId, {
		payload = {
			messageId = N.FriendPlaying.MessageId,
			type = "MOMENT",
			parameters = { ["userId-friend"] = { int64Value = fromUserId } },
		},
		joinExperience = { launchData = N.JoinPrefix .. fromUserId },
		analyticsData = { category = "FriendPlaying" },
	})
	return ok and type(result) == "table" and result.statusCode == 200
end

local function sendBoxes(toUserId)
	local ok, result = pcall(api.createUserNotification, toUserId, {
		payload = { messageId = N.BoxReady.MessageId, type = "MOMENT" },
		joinExperience = { launchData = N.BoxLaunch },
		analyticsData = { category = "BoxReady" },
	})
	return ok and type(result) == "table" and result.statusCode == 200
end

local function boxesOn()
	return N.BoxReady.MessageId ~= "" and not RunService:IsStudio() and not TutorialField.isField()
end

local function boxMap()
	if dueMap == nil then
		local ok, map = pcall(MemoryStoreService.GetSortedMap, MemoryStoreService, N.BoxReady.Map)
		dueMap = ok and map or false
	end
	return dueMap or nil
end

local function scheduleBoxes(player, profile)
	if not boxesOn() or type(profile.Tutorial) ~= "table" or not profile.Tutorial.Done or profile.Stash then
		return
	end
	local now = os.time()
	local doneAt = 0
	for _, box in ipairs(profile.Boxes or {}) do
		doneAt = math.max(doneAt, tonumber(box.ReadyAt) or 0)
	end
	local map = boxMap()
	if map and doneAt >= now + N.BoxReady.MinMinutes * 60 then
		pcall(map.SetAsync, map, tostring(player.UserId), doneAt, doneAt - now + N.BoxReady.KeepHours * 3600, doneAt)
	end
end

local function unscheduleBoxes(player)
	local map = boxesOn() and boxMap()
	if map then
		pcall(map.RemoveAsync, map, tostring(player.UserId))
	end
end

local function sendDueBoxes()
	local map = boxMap()
	if not map or not sender(N.BoxReady.MessageId) then
		return
	end
	local now = os.time()
	local ok, items = pcall(map.GetRangeAsync, map, Enum.SortDirection.Ascending, N.BoxReady.Batch, nil, { sortKey = now })
	if not ok or type(items) ~= "table" then
		return
	end
	for _, item in ipairs(items) do
		local userId = tonumber(item.key)
		if type(item.value) == "table" and now - (tonumber(item.value.At) or 0) > N.BoxReady.PollEvery * 5 then
			pcall(map.RemoveAsync, map, item.key)
		elseif userId and type(item.value) == "number" then
			local mine = { Job = game.JobId, At = now }
			local claimed, value = pcall(map.UpdateAsync, map, item.key, function(old, sortKey)
				if type(old) ~= "number" then
					return nil
				end
				return mine, sortKey
			end, N.BoxReady.KeepHours * 3600)
			if claimed and type(value) == "table" and value.Job == mine.Job and value.At == mine.At then
				if not Players:GetPlayerByUserId(userId) then
					sendBoxes(userId)
				end
				pcall(map.RemoveAsync, map, item.key)
			end
		end
	end
end

local function friendIds(player)
	local ids = {}
	local ok, pages = pcall(Players.GetFriendsAsync, Players, player.UserId)
	while ok and pages and #ids < N.FriendPlaying.MaxFriends do
		for _, friend in ipairs(pages:GetCurrentPage()) do
			if #ids >= N.FriendPlaying.MaxFriends then
				break
			end
			if not Players:GetPlayerByUserId(friend.Id) then
				table.insert(ids, friend.Id)
			end
		end
		if pages.IsFinished then
			break
		end
		ok = pcall(pages.AdvanceToNextPageAsync, pages)
	end
	return ids
end

local function pingFriends(player)
	local profile = PlayerData.get(player)
	if pinged[player.UserId] or not profile or not profile.Tutorial.Done or not sender(N.FriendPlaying.MessageId) then
		return
	end
	pinged[player.UserId] = true
	local count = 0
	for _, id in ipairs(friendIds(player)) do
		if not player.Parent then
			break
		end
		if send(id, player.UserId) then
			count += 1
		end
		task.wait(N.FriendPlaying.Gap)
	end
	if count > 0 then
		Analytics.custom(player, "NotifyFriends")
	end
end

local function launchData(player)
	local ok, join = pcall(player.GetJoinData, player)
	local data = ok and type(join) == "table" and join.LaunchData
	return type(data) == "string" and data or nil
end

local function launchFriend(player)
	local data = launchData(player)
	local shared = data and data:match("^" .. N.SharePrefix .. "(%d+)$")
	return tonumber(data and data:match("^" .. N.JoinPrefix .. "(%d+)$") or shared), shared ~= nil
end

local function joinFriend(player, profile)
	local id, shared = launchFriend(player)
	if shared then
		Analytics.custom(player, "ShareJoin")
	end
	if not id or RunService:IsStudio() or TutorialField.isField() or not profile.Tutorial.Done then
		return
	end
	Analytics.custom(player, shared and "ShareJoinFriend" or "NotifyJoin")
	if Players:GetPlayerByUserId(id) then
		return
	end
	local ok, _, _, placeId, jobId = pcall(TeleportService.GetPlayerPlaceInstanceAsync, TeleportService, id)
	if not ok or placeId ~= game.PlaceId or type(jobId) ~= "string" or jobId == "" or jobId == game.JobId then
		return
	end
	local f = Config.FriendInvite
	local friend = not shared
	if shared then
		local ok, yes = pcall(player.IsFriendsWith, player, id)
		friend = ok and yes == true
	end
	if friend then
		Net.push(player, "Notice", "👥 친구에게 가요!",
			string.format("🔑 %d분 같이 놀면 둘 다 열쇠 %d개", f.MinutesTogether, f.Keys))
	else
		Net.push(player, "Notice", "📸 자랑 보고 왔군요!", "그 사람이 있는 서버로 가요")
	end
	task.wait(N.JoinDelay)
	if not player.Parent then
		return
	end
	local options = Instance.new("TeleportOptions")
	options.ServerInstanceId = jobId
	local moved = pcall(TeleportService.TeleportAsync, TeleportService, game.PlaceId, { player }, options)
	if not moved then
		Net.push(player, "Notice", "👥 친구 서버가 꽉 찼어요", "🔔 여기서 놀다가 친구를 초대해요")
	end
end

function Notify.testSelf(player, kind)
	if not RunService:IsStudio() then
		return nil
	end
	local id = kind == "boxes" and N.BoxReady.MessageId or N.FriendPlaying.MessageId
	if not sender(id) then
		return id == "" and "id" or "package"
	end
	if kind == "boxes" then
		return sendBoxes(player.UserId) and "sent" or "failed"
	end
	return send(player.UserId, player.UserId) and "sent" or "failed"
end

function Notify.init()
	PlayerData.onLoaded(function(player, profile)
		task.spawn(joinFriend, player, profile)
		task.spawn(unscheduleBoxes, player)
		if launchData(player) == N.BoxLaunch then
			Analytics.custom(player, "NotifyBoxJoin")
		end
		task.delay(N.FriendPlaying.AfterMinutes * 60, function()
			if player.Parent and not RunService:IsStudio() and not TutorialField.isField() then
				pingFriends(player)
			end
		end)
	end)
	PlayerData.onLeaving(scheduleBoxes)
	Net.onRequest("ShareDone", { "string" }, function(player, kind)
		if kind == "Box" or kind == "Rebirth" then
			Analytics.custom(player, "Share" .. kind)
		end
	end)
	if boxesOn() then
		task.spawn(function()
			task.wait(math.random() * N.BoxReady.PollEvery)
			while true do
				sendDueBoxes()
				task.wait(N.BoxReady.PollEvery)
			end
		end)
	end
end

return Notify
