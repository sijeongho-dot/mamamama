--[[
StreetLamps: street lamps in every base camp (design 2.12 낮과 밤), so the bases stay bright at night and in
dark weather: along the inside of the plot's fence (front corners, both sides of the entrance, the
sides, the back), at the gap into the two fields and along the fence between them. Display only, made
when the server starts, for all eight bases whether anyone has them or not, in their own folder
Workspace.Map.StreetLamps (each base's lamps stream in together when near; 2026-10-01: they were always sent).

The lamps light up (warm PointLight, the lamp head glows; 2026-10-04: the light itself only on the screens near it,
its attribute Lit read by StarterPlayerScripts/LampLights) while it is night (ReplicatedStorage attribute
Night, DayNight) or the weather is dark (Weather Rain or Storm, Weather service), and go out otherwise.
Only a base a player has lights up (2026-10-01; base folder attribute OwnerUserId): empty bases stay dark.
Round each base's defense field a few low spotlights stand on the ground at its edge (2026-10-06: off the roads that
now reach the fences), aimed up into it, lit by the same rule (2026-10-01, "the arena well seen at night: ground spotlights").
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Bases = require(script.Parent:WaitForChild("Bases"))

local StreetLamps = {}

-- display only
-- where the lamps stand, in plot coordinates: u across (− left, + right walking in), v from the plot's
-- front (0) to its back (PlotDepth); just inside the fence, clear of the stalls, the arena and the pen
local SPOTS = {
	{ -100, 4 }, { 100, 4 }, -- front corners
	{ -12, 4 }, { 12, 4 }, -- either side of the entrance
	{ 0, 57 }, -- the gap into the two fields
	{ -104, 60 }, { 104, 60 }, { -104, 110 }, { 104, 110 }, -- the sides, against the fence (the roads reach it)
	{ -104, 164 }, { 104, 164 }, { -2, 164 }, { 2, 164 }, -- the back corners, either side of the fence between the fields
}
local POST_SIZE = Vector3.new(0.6, 12, 0.6)
local HEAD_SIZE = Vector3.new(1.8, 1.4, 1.8)
local CAP_SIZE = Vector3.new(2.4, 0.4, 2.4)
local BASE_SIZE = Vector3.new(1.4, 0.6, 1.4)
local COLOR_POST = Color3.fromRGB(55, 58, 68)
local COLOR_LIGHT = Color3.fromRGB(255, 214, 150)
local COLOR_OFF = Color3.fromRGB(205, 200, 185)
local LIGHT_RANGE = 32 -- studs (was 45)
local LIGHT_BRIGHTNESS = 0.8 -- (was 2: too bright)
local DARK_WEATHER = { Rain = true, Storm = true }
-- the defense field's ground spotlights (plot coordinates as SPOTS): its corners and the middle of its sides, off the
-- roads, each aimed at SPOT_AIM (the arena's middle, MapBuilder at(52.5, 111))
local SPOT_SPOTS = { { 3, 63 }, { 102, 63 }, { 3, 112 }, { 102, 112 }, { 3, 162 }, { 102, 162 } }
local SPOT_AIM = { 52.5, 111 }
local FARM_SPOTS = { { -3, 63 }, { -102, 63 }, { -3, 112 }, { -102, 112 }, { -3, 162 }, { -102, 162 } }
local FARM_AIM = { -52.5, 111 }
local SPOT_BOX = Vector3.new(1.8, 0.8, 1.8)
local SPOT_LENS = Vector3.new(1.4, 1.4, 0.5)
local SPOT_TILT = math.rad(35) -- the lamp looks up this much toward the arena's middle
local SPOT_RANGE = 55
local SPOT_ANGLE = 70 -- degrees
local SPOT_BRIGHTNESS = 2.5
local COLOR_SPOT = Color3.fromRGB(255, 240, 200)

local lamps = {} -- { head, light, folder }

local function part(props, parent)
	local p = Instance.new("Part")
	p.Anchored = true
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Material = Enum.Material.SmoothPlastic
	for k, v in pairs(props) do
		p[k] = v
	end
	p.Parent = parent
	return p
end

local function lamp(at, parent, folder)
	local model = Instance.new("Model")
	model.Name = "StreetLamp"
	part({ Name = "Base", Size = BASE_SIZE, CFrame = CFrame.new(at + Vector3.new(0, BASE_SIZE.Y / 2, 0)), Color = COLOR_POST }, model)
	part({ Name = "Post", Size = POST_SIZE, CFrame = CFrame.new(at + Vector3.new(0, POST_SIZE.Y / 2, 0)), Color = COLOR_POST }, model)
	local head = part({ Name = "Head", Size = HEAD_SIZE, CanCollide = false,
		CFrame = CFrame.new(at + Vector3.new(0, POST_SIZE.Y + HEAD_SIZE.Y / 2, 0)), Color = COLOR_OFF }, model)
	part({ Name = "Cap", Size = CAP_SIZE, CanCollide = false,
		CFrame = CFrame.new(at + Vector3.new(0, POST_SIZE.Y + HEAD_SIZE.Y + CAP_SIZE.Y / 2, 0)), Color = COLOR_POST }, model)
	local light = Instance.new("PointLight")
	light.Name = "LampLight" -- (lit on each screen near its camera only: LampLights.client)
	light.Range = LIGHT_RANGE
	light.Brightness = LIGHT_BRIGHTNESS
	light.Color = COLOR_LIGHT
	light.Shadows = false
	light.Enabled = false
	light.Parent = head
	model.Parent = parent
	table.insert(lamps, { head = head, light = light, folder = folder })
end

-- a low spotlight on the ground at `at`, aimed up toward `toward`
local function spotlight(at, toward, parent, folder, name)
	local model = Instance.new("Model")
	model.Name = name
	local flat = Vector3.new(toward.X - at.X, 0, toward.Z - at.Z)
	flat = flat.Magnitude > 1e-3 and flat.Unit or Vector3.zAxis
	local base = CFrame.lookAt(at, at + flat)
	part({ Name = "Box", Size = SPOT_BOX, CFrame = base * CFrame.new(0, SPOT_BOX.Y / 2, 0), Color = COLOR_POST }, model)
	local lens = part({ Name = "Lens", Size = SPOT_LENS, CanCollide = false, Color = COLOR_OFF,
		CFrame = base * CFrame.new(0, SPOT_BOX.Y + SPOT_LENS.Y / 2 - 0.2, 0) * CFrame.Angles(SPOT_TILT, 0, 0) }, model)
	local light = Instance.new("SpotLight")
	light.Name = "LampLight"
	light.Face = Enum.NormalId.Front
	light.Range = SPOT_RANGE
	light.Angle = SPOT_ANGLE
	light.Brightness = SPOT_BRIGHTNESS
	light.Color = COLOR_SPOT
	light.Shadows = false
	light.Enabled = false
	light.Parent = lens
	model.Parent = parent
	table.insert(lamps, { head = lens, light = light, folder = folder, color = COLOR_SPOT })
end

-- the defense field's spotlights, round its edge
local function fieldSpotlights(folder, parent, plot, top, skip)
	for _, field in ipairs({ { SPOT_SPOTS, SPOT_AIM, "ArenaSpotlight" }, { FARM_SPOTS, FARM_AIM, "FarmSpotlight" } }) do
		local aim = plot(field[2][1], field[2][2])
		for _, spot in ipairs(field[1]) do
			local p = plot(spot[1], spot[2])
			local ground = Bases.groundBelow(Vector3.new(p.X, top, p.Z), skip)
			spotlight(Vector3.new(p.X, ground, p.Z), Vector3.new(aim.X, ground, aim.Z), parent, folder, field[3])
		end
	end
end

local function build(folder, parent)
	local zone = folder:FindFirstChild("SafeZone")
	if not zone then
		return
	end
	local flat = Vector3.new(zone.Position.X, 0, zone.Position.Z)
	if flat.Magnitude < 1e-3 then
		return
	end
	local out = flat.Unit -- from the map center through the plot
	local right = out:Cross(Vector3.yAxis).Unit
	local front = flat - out * Config.Map.PlotDepth / 2
	local model = Instance.new("Model")
	model.Name = "StreetLamps" .. folder.Name
	pcall(function()
		model.ModelStreamingMode = Enum.ModelStreamingMode.Atomic -- whole when near (was Persistent: every one at joining, a slower start)
	end)
	local function plot(u, v)
		return front + right * u + out * v
	end
	for _, spot in ipairs(SPOTS) do
		local p = plot(spot[1], spot[2])
		lamp(Vector3.new(p.X, Bases.groundBelow(Vector3.new(p.X, zone.Position.Y, p.Z), { parent, zone }), p.Z), model, folder)
	end
	fieldSpotlights(folder, model, plot, zone.Position.Y, { parent, zone, model })
	model.Parent = parent
end

local function refresh()
	local on = ReplicatedStorage:GetAttribute("Night") == true
		or DARK_WEATHER[ReplicatedStorage:GetAttribute("Weather") or "Clear"] == true
	for _, l in ipairs(lamps) do
		local lit = on and l.folder:GetAttribute("OwnerUserId") ~= nil
		-- (2026-10-04, "렉이 특히 밤에 더 걸리는거 같군": a full server lit over a hundred lights at night, every screen
		-- drawing all it could see) whether it is lit; each screen turns on those near its camera (LampLights.client)
		l.light:SetAttribute("Lit", lit)
		l.head.Material = lit and Enum.Material.Neon or Enum.Material.SmoothPlastic
		l.head.Color = lit and (l.color or COLOR_LIGHT) or COLOR_OFF
	end
end

function StreetLamps.init()
	local map = Workspace:FindFirstChild("Map")
	if not map then
		warn("[StreetLamps] Workspace.Map이 없어 가로등을 못 세웠습니다")
		return
	end
	local old = map:FindFirstChild("StreetLamps")
	if old then
		old:Destroy()
	end
	local holder = Instance.new("Folder")
	holder.Name = "StreetLamps"
	holder.Parent = map
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			build(folder, holder)
			folder:GetAttributeChangedSignal("OwnerUserId"):Connect(refresh)
		end
	end
	ReplicatedStorage:GetAttributeChangedSignal("Night"):Connect(refresh)
	ReplicatedStorage:GetAttributeChangedSignal("Weather"):Connect(refresh)
	refresh()
end

return StreetLamps
