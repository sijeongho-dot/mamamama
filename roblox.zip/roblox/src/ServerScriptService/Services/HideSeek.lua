--[[
HideSeek: 🙈 hide-and-seek on the battlefield (2026-10-03, "숨박꼭질 기능도 만들자 …"; design 2.11.2). The rules
(rooms, ready, the seeker, who is out, who won) are in HideSeekLogic; this moves the players, keeps the time,
saves the records and tells everyone.

- The board: a sign by the key altar (Workspace.HideSeek, Config.HideSeek.BoardAngle / BoardOut) with a
  "🙈 술래잡기" prompt (Kind "HideSeek"; StarterPlayerScripts/HideSeek opens the room window). Opening or joining a
  room is only done there, on the battlefield (Net requests HideSeekCreate, HideSeekJoin(roomId)); 준비 and 나가기
  (HideSeekReady(ready), HideSeekLeave) from anywhere. Net push HideSeekRooms(rooms) on every change; Net ask
  GetHideSeek -> { Rooms, Wins, Losses }.
- Start: MinPlayers or more in a room and all ready: StartSeconds later the game starts (one un-ready or leaving
  stops it). A member who can't play now (racing, in the tutorial, not alive) is taken out of the room first.
  The seeker is picked at random ("이번 술래는 …님이에요" to the room); carried keys fall, mining stops.
  The seeker is put at the key altar and held still (MoveGuard.stun, StunReason "HideSeek") for HideSeconds,
  marked red (a Highlight) for everyone; the hiders are put at random open spots on the battlefield (SpawnRadius,
  SpawnGap apart) and their names hidden (Humanoid.DisplayDistanceType; the clients hide their labels).
  Then SeekSeconds of seeking.
- Player attributes while in a game: HideSeekRoom (room id), HideSeekRole ("Seeker" | "Hider"), HideSeekPhase
  ("Hiding" | "Seeking"), HideSeekUntil (server time the phase ends), HideSeekLeft (hiders still in).
- In a game: the battlefield only (put back EdgeMargin inside its flags, MoveGuard.allow first; 2026-10-05 back from the
  whole map). Nobody can use 기지로
  (HomeTeleport) or throw bombs (Bombs); a hider can't slap; players in a game and the others can't hit each other
  (Combat). The seeker's slap while seeking puts a hider out (Combat.onTag): their loss, and home they go.
  (2026-10-04, "술래잡기가 다인이면 잡힌 사람은 관전자용 익룡 타고 배틀필드 공중에서 끝날때까지 구경하게") while others
  still play, a caught hider rides a spectator pterosaur (Ride.watch: C.WatchMount, C.WatchHeight up, only looking,
  can't get off; player attribute HideSeekWatch = the room) over the battlefield until the game ends, then home.
- Giving up: dying (a reset), 나가기 or leaving the game: a loss. The seeker giving up: the hiders win.
- The seeker's help (2026-10-03, "술래한테 이득을 좀 줘야 … 너무 어렵다", "일정시간마다 종울리기가 숨는자들에게
  강제된다든지"): while seeking the seeker runs SeekerSpeed times as fast (MoveGuard) and slaps SeekerReach times as
  far (Combat), and every hider's 🔔 bell rings by itself (Bell.force: the sound and the mark everyone sees)
  BellFirst seconds in, then every Formulas.hideSeekBellGap seconds (2026-10-04: by the part of the game and the
  hiders still in).
- Win or lose (2026-10-03, "승패 이후 승리! 패배! 같은 효과와 효과음"): Net push HideSeekResult(outcome "Win" |
  "Lose", why) to each player as their game ends (caught or given up: then; the rest at the end).
- 🕸️ Traps (2026-10-03, "숨는 사람들이 조그만 함정 바닥에 설치해두고 그걸 술래가 밟으면 잠시 멈추게해줘. 함정은 총
  3개 점프하면 피할 수 있을정도의 크기"): a hider puts one down at their feet (Net request HideSeekTrap), C.TrapCount a
  game (player attribute HideSeekTraps: how many left), on the ground, TrapCooldown apart, not by the seeker
  (TrapSeekerGap) or another trap (TrapGap). The look: Prop_HideTrap (ServerStorage.Assets, tools/make_trap.py; a
  flat disc without it) under Workspace.HideSeek.Traps, TrapSize wide, with an invisible box over it as high as a
  foot (a jump clears it). The seeker touching one while seeking: MoveGuard.stun TrapStunSeconds (StunReason
  "Trap"), the trap snaps shut (Prop_HideTrapShut) and goes; then traps don't catch them for TrapImmuneSeconds.
  Net push HideSeekTrapFx(kind "Set" | "Snap", position, caught userId, owner userId) to everyone (the sounds; on a
  snap the caught seeker and the trap's owner hear it wherever they are, 2026-10-03 "함정도 사람 걸려서 닫힐때
  소리나야해"). All gone when the game ends.
- The end: every hider out → the seeker wins; time up → the hiders still in win (the seeker and those out lose).
  Records: profile HideSeek { Wins, Losses }, player attributes HideWins / HideLosses (shown over their heads,
  StarterPlayerScripts/Race). The room waits again, nobody ready.
- 🏆 랭킹전 / 🎈 일반전 (2026-10-04, "술래잡기 레이스 둘다 랭킹전 일반전 있게 하자. 일반전은 기록이 안남고 랭킹전은 기록이
  남는", "랭킹전 보상도 주간 열쇠로"): a room is opened as one or the other (Net request HideSeekCreate(ranked)). Only a
  ranked game saves the wins and losses (and the all-server wins), and a win in it counts in this week's hide-and-seek
  ranking (RewardLogic.rankedWin: the seeker's against the hiders, a hider's against the seeker; Leaderboards pays the
  rank's keys when the week is over). Net push HideSeekResult(outcome, why, ranked, counted, week's wins).
- The window is the 🎮 놀이방 window's 🙈 tab (StarterPlayerScripts/GameRooms, 2026-10-04: with the 🏁 race rooms).
  Player attribute InRoom = "Hide" while in a room (the race rooms set "Race": one room at a time). A new room is told
  to the others with its mode.
]]

local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local Bell = require(script.Parent:WaitForChild("Bell"))
local Combat = require(script.Parent:WaitForChild("Combat"))
local Keys = require(script.Parent:WaitForChild("Keys"))
local Leaderboards = require(script.Parent:WaitForChild("Leaderboards"))
local Logic = require(script.Parent:WaitForChild("HideSeekLogic"))
local Minerals = require(script.Parent:WaitForChild("Minerals"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))
local Ride = require(script.Parent:WaitForChild("Ride"))

local HideSeek = {}

local C = Config.HideSeek
local TITLE = "🙈 숨바꼭질"
local SPOT_TRIES = 40 -- random spots tried for each hider
local ABOVE_GROUND = 3.5 -- studs over the ground a character is put
local ABOVE_SPAWN = 4 -- studs over the base's SpawnLocation a tagged hider lands
local OFF_GROUND = { "Decor", "FieldDecor", "BattlefieldFlags" } -- Map folders a hider is never put on
local SEEKER_COLOR = Color3.fromRGB(255, 70, 70)
local BOARD_WOOD = Color3.fromRGB(150, 105, 65)
local BOARD_FACE = Color3.fromRGB(255, 236, 190)
local BOARD_TEXT = Color3.fromRGB(90, 55, 30)
local BOARD_SIZE = Vector3.new(9, 6, 0.6) -- the sign's board (2026-10-03: taller, the top 3 on it)
local MEDALS = { "🥇", "🥈", "🥉" }
local BOARD_POST = Vector3.new(0.8, 9, 0.8)
local ATTRIBUTES = { "HideSeekRoom", "HideSeekRole", "HideSeekPhase", "HideSeekUntil", "HideSeekLeft", "HideSeekTraps",
	"HideSeekDisguise", "HideSeekDisguises", "HideSeekDisguiseToken", "HideSeekDisguiseReady" }
local TRAP_SHUT_SHOW = 1.5 -- seconds a snapped trap stays shut before it goes
local TRAP_HITBOX_HEIGHT = 1.4 -- studs over the ground a foot is on the trap (a jump lifts the feet well over it)
local TRAP_HITBOX_SHARE = 0.8 -- of its width: the edges don't catch
local TRAP_GROUND_BELOW = 8 -- studs: the ground must be this close under the hider's middle
local TRAP_COLOR = Color3.fromRGB(126, 143, 60) -- the plain disc without the models
local TRAP_BUTTON = Color3.fromRGB(255, 241, 201)
local TRAP_DISC_HIGH = { Prop_HideTrap = 0.3, Prop_HideTrapShut = 1.2 } -- (the plain stand-ins' heights)
local DISGUISE_FOLDERS = { "FieldDecor", "FieldGrass", "BattlefieldFlags", "Decor", "TrafficLights" }
local DISGUISE_PREFIX = "Thing_"
local DISGUISE_TRIES = 8
local DISGUISE_GROUND_REACH = 60
local DISGUISE_KEEP = { "DataModelMesh", "Decal", "SurfaceAppearance", "Model", "Folder" }

local state = Logic.new()
local rng = Random.new()
local board = nil -- the board model
-- (2026-10-04, "숨바꼭질 끝나고 원래 본인이 타고 있던 공룡을 되돌려주기도 하고") [player] = true while in a game they were
-- taken into off their own dino; after it, the os.clock() until which they are put back on it once off the battlefield
local rodeBefore = {}
local games = {} -- [room] = { endsAt = os.clock(), conns = { RBXScriptConnection }, traps = { trap }, trapsLeft =
-- { [userId] = n }, trapAt = { [userId] = os.clock() }, trapSafeUntil = os.clock() (the seeker walks over traps) }
local disguiseKinds = nil
local disguiseCopies = {}
local disguiseFolder = nil
local disguiseCount = 0

local function dropCopy(player)
	local copy = disguiseCopies[player]
	disguiseCopies[player] = nil
	if copy then
		copy:Destroy()
	end
end

local function say(player, text)
	Net.push(player, "Notice", TITLE, text)
end

local function byId(userId)
	return Players:GetPlayerByUserId(userId)
end

local function sayRoom(room, text, except)
	for _, userId in ipairs(room.Members) do
		local p = byId(userId)
		if p and userId ~= except then
			say(p, text)
		end
	end
end

local function alive(player)
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if humanoid and root and humanoid.Health > 0 then
		return character, root, humanoid
	end
	return nil
end

local function pushRooms()
	Net.pushAll("HideSeekRooms", Logic.snapshot(state))
end

-- (compass degrees: 0 = north = -Z, 90 = east = +X)
local function dir(degrees)
	local a = math.rad(degrees)
	return Vector3.new(math.sin(a), 0, -math.cos(a))
end

local function groundAt(x, z)
	local params = RaycastParams.new()
	local ignore = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	if board then
		table.insert(ignore, board)
	end
	params.FilterDescendantsInstances = ignore
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true -- the invisible Battlefield cylinder and SafeZones are not ground
	local hit = Workspace:Raycast(Vector3.new(x, 300, z), Vector3.new(0, -600, 0), params)
	if not hit then
		return nil
	end
	return hit.Position, hit.Instance
end

-- open ground (not a tree, a rock or a flag) at (x, z) on the battlefield, or nil
local function openGround(x, z)
	local at, part = groundAt(x, z)
	if not at then
		return nil
	end
	local map = Workspace:FindFirstChild("Map")
	for _, name in ipairs(OFF_GROUND) do
		local f = map and map:FindFirstChild(name)
		if f and part:IsDescendantOf(f) then
			return nil
		end
	end
	if SafeZones.isSafe(at + Vector3.new(0, 2, 0)) then
		return nil
	end
	return at
end

local function altarCenter()
	local map = Workspace:FindFirstChild("Map")
	local zone = map and map:FindFirstChild("KeyZone")
	local altar = zone and zone:FindFirstChild("Zone_KeyAltar")
	local at = altar and Bases.position(altar) or Vector3.zero
	return Vector3.new(at.X, 0, at.Z)
end

-- n random open spots on the battlefield, SpawnGap apart where it can
local function hidingSpots(n)
	local spots = {}
	local inner, outer = C.SpawnRadius[1], math.min(C.SpawnRadius[2], Config.Battlefield.Radius - C.EdgeMargin)
	for _ = 1, n do
		local best, bestGap = nil, -1
		for _ = 1, SPOT_TRIES do
			local angle = rng:NextNumber(0, 2 * math.pi)
			local r = math.sqrt(rng:NextNumber(inner * inner / (outer * outer), 1)) * outer -- even over the area
			local at = openGround(math.cos(angle) * r, math.sin(angle) * r)
			if at then
				local gap = math.huge
				for _, other in ipairs(spots) do
					gap = math.min(gap, (Vector3.new(other.X, 0, other.Z) - Vector3.new(at.X, 0, at.Z)).Magnitude)
				end
				if gap >= C.SpawnGap then
					best = at
					break
				elseif gap > bestGap then
					best, bestGap = at, gap
				end
			end
		end
		table.insert(spots, best or Vector3.new(0, 0, (inner + outer) / 2))
	end
	return spots
end

local function putAt(player, at, lookAt)
	local character = alive(player)
	if not character then
		return
	end
	local flat = Vector3.new(lookAt.X, at.Y, lookAt.Z)
	if (flat - at).Magnitude < 0.1 then
		flat = at + Vector3.new(0, 0, -1)
	end
	Minerals.stopMining(player)
	MoveGuard.allow(player)
	character:PivotTo(CFrame.lookAt(at, flat))
	local root = character:FindFirstChild("HumanoidRootPart")
	if root then
		root.AssemblyLinearVelocity = Vector3.zero
	end
end

local function sendHome(player)
	local folder = Bases.folderOf(player)
	local spawn = folder and folder:FindFirstChild("SpawnLocation", true)
	local character = alive(player)
	if spawn and spawn:IsA("BasePart") and character then
		Minerals.stopMining(player)
		MoveGuard.allow(player)
		character:PivotTo(spawn.CFrame * CFrame.new(0, ABOVE_SPAWN, 0))
	end
end

-- out of the game for good (the end, given up, caught and not watching, done watching): their own dino shown again, and
-- if the game took them off it, back on it (off the battlefield now, or as soon as they step out: step, MountBackSeconds)
local function giveBack(player)
	if not player or not player.Parent then
		return
	end
	local ride = rodeBefore[player] ~= nil
	if Ride.giveBack(player, ride) then
		rodeBefore[player] = nil
		say(player, "🦖 타던 공룡을 다시 태워 줬어요")
	elseif ride then
		rodeBefore[player] = os.clock() + C.MountBackSeconds
	end
end

-- a caught hider's watching from the sky is over (the game ended, they left the room, or fell off the dino): home
local function stopWatching(player)
	if player and player:GetAttribute("HideSeekWatch") then
		player:SetAttribute("HideSeekWatch", nil)
		Ride.unwatch(player, true)
		sendHome(player)
		giveBack(player)
	end
end

-- the record over their head
local function mirrorRecord(player)
	local profile = PlayerData.get(player)
	local record = profile and profile.HideSeek
	if record then
		player:SetAttribute("HideWins", record.Wins or 0)
		player:SetAttribute("HideLosses", record.Losses or 0)
	end
end

-- a win or a loss in a 🏆 랭킹전 room (2026-10-04: a 🎈 일반전 keeps nothing): the record, and a win against these rivals
-- (userIds) in this week's ranking (RewardLogic.rankedWin). Returns whether the win counted there
local function record(room, userId, won, rivals)
	local player = byId(userId)
	if not room.Ranked or not player or not PlayerData.get(player) then
		return false
	end
	local counted = false
	PlayerData.update(player, function(profile)
		profile.HideSeek = profile.HideSeek or { Wins = 0, Losses = 0 }
		local field = won and "Wins" or "Losses"
		profile.HideSeek[field] = (profile.HideSeek[field] or 0) + 1
		if won then
			counted = RewardLogic.rankedWin(profile, RewardLogic.weekNumber(os.time()), "Hide", rivals or {})
		end
	end)
	mirrorRecord(player)
	if won then -- (2026-10-03) the all-server ranking (Leaderboards)
		Leaderboards.hideSeekWins(player, PlayerData.get(player).HideSeek.Wins)
	end
	if counted then
		Leaderboards.rankedWin(player, "Hide")
	end
	return counted
end

-- the 🏆 승리! / 😢 패배! on their screen (StarterPlayerScripts/HideSeek), with the room's mode and, in a ranked room, whether
-- the win counted this week and the week's wins
local function result(room, userId, won, why, counted)
	local player = byId(userId)
	if player then
		local profile = PlayerData.get(player)
		Net.push(player, "HideSeekResult", won and "Win" or "Lose", why, room.Ranked == true, counted == true,
			room.Ranked and profile and profile.Ranked.Hide or 0)
		Rewards.add(player, "HideSeekGame", 1)
	end
end

local function pay(room, userId, won)
	local player = byId(userId)
	local g = games[room]
	if player and g and not g.paid[userId] then
		g.paid[userId] = true
		Rewards.miniGame(player, won)
	end
end

-- out of the game (out, given up, or the end): the attributes, the red mark and the hidden name back
local function release(player)
	if not player then
		return
	end
	for _, name in ipairs(ATTRIBUTES) do
		player:SetAttribute(name, nil)
	end
	dropCopy(player)
	-- (2026-10-04) off the default dino the game put them on outside the battlefield (not a watcher's pterosaur)
	if player:GetAttribute("Riding") and not player:GetAttribute("Watching") then
		Ride.getOff(player, nil, true)
	end
	local character = player.Character
	local mark = character and character:FindFirstChild("HideSeekMark")
	if mark then
		mark:Destroy()
	end
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if humanoid then
		humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.Viewer
	end
end

local function setLeft(room)
	local left = Logic.left(room)
	for _, userId in ipairs(room.Members) do
		local p = byId(userId)
		if p and p:GetAttribute("HideSeekRoom") == room.Id then
			p:SetAttribute("HideSeekLeft", left)
		end
	end
end

-- ---------------------------------------------------------------------------
-- 🕸️ Traps
-- ---------------------------------------------------------------------------

local function trapFolder()
	local folder = Workspace:FindFirstChild("HideSeek")
	local traps = folder and folder:FindFirstChild("Traps")
	if folder and not traps then
		traps = Instance.new("Folder")
		traps.Name = "Traps"
		traps.Parent = folder
	end
	return traps or Workspace
end

-- the trap's look (open: Prop_HideTrap, shut: Prop_HideTrapShut; a plain disc without the models), C.TrapSize wide,
-- its bottom middle at `at`, turned yaw radians round the up axis
local function trapLook(name, at, yaw)
	local assets = ServerStorage:FindFirstChild("Assets")
	local source = assets and assets:FindFirstChild(name, true)
	local model
	if source then
		model = source:Clone()
		if model:IsA("BasePart") then
			local holder = Instance.new("Model")
			model.Parent = holder
			model = holder
		end
	else
		model = Instance.new("Model")
		local disc = Instance.new("Part")
		disc.Shape = Enum.PartType.Cylinder
		disc.Size = Vector3.new(TRAP_DISC_HIGH[name] or 0.3, C.TrapSize, C.TrapSize)
		disc.CFrame = CFrame.Angles(0, 0, math.rad(90)) -- (a cylinder's axis is X: stood on end)
		disc.Color = TRAP_COLOR
		disc.Parent = model
		local button = disc:Clone()
		button.Size = Vector3.new(disc.Size.X + 0.15, C.TrapSize * 0.35, C.TrapSize * 0.35)
		button.Color = TRAP_BUTTON
		button.Parent = model
	end
	model.Name = name
	for _, part in ipairs(model:GetDescendants()) do
		if part:IsA("BasePart") then
			part.Anchored = true
			part.CanCollide = false
			part.CanQuery = false
			part.CanTouch = false
		end
	end
	local _, size = model:GetBoundingBox()
	local width = math.max(size.X, size.Z)
	if width > 0 then
		model:ScaleTo(model:GetScale() * C.TrapSize / width)
	end
	local box, high = model:GetBoundingBox()
	local bottom = CFrame.new(box.Position - Vector3.new(0, high.Y / 2, 0))
	model:PivotTo(CFrame.new(at) * CFrame.Angles(0, yaw, 0) * bottom:ToObjectSpace(model:GetPivot()))
	return model
end

HideSeek.trapLook = trapLook

local function removeTrap(g, trap)
	local i = table.find(g.traps, trap)
	if i then
		table.remove(g.traps, i)
	end
	if trap.conn then
		trap.conn:Disconnect()
		trap.conn = nil
	end
	for _, part in ipairs({ trap.model, trap.hitbox }) do
		part:Destroy()
	end
end

local function clearTraps(g)
	for _, trap in ipairs(table.clone(g.traps)) do
		removeTrap(g, trap)
	end
end

-- the seeker stepped on it: stopped a moment, the trap snaps shut and goes
local function snap(g, trap, seeker)
	local now = os.clock()
	if now < g.trapSafeUntil or not table.find(g.traps, trap) then
		return
	end
	g.trapSafeUntil = now + C.TrapStunSeconds + C.TrapImmuneSeconds
	trap.conn:Disconnect()
	trap.conn = nil
	trap.model:Destroy()
	trap.model = trapLook("Prop_HideTrapShut", trap.at, trap.yaw)
	trap.model.Parent = trapFolder()
	MoveGuard.stun(seeker, C.TrapStunSeconds, "Trap")
	Net.pushAll("HideSeekTrapFx", "Snap", trap.at, seeker.UserId, trap.owner)
	local owner = byId(trap.owner)
	if owner then
		say(owner, "🕸️ 술래가 내 함정에 걸렸어요!")
	end
	task.delay(TRAP_SHUT_SHOW, function()
		removeTrap(g, trap)
	end)
end

-- a hider puts a trap down at their feet (Net request HideSeekTrap)
local function placeTrap(player)
	if player:GetAttribute("HideSeekPractice") and not player:GetAttribute("HideSeekRoom") then
		return require(script.Parent:WaitForChild("Practice")).placeTrap(player)
	end
	local room = Logic.roomOf(state, player.UserId)
	local g = room and games[room]
	if not g or room.Phase == "Waiting" or player:GetAttribute("HideSeekRoom") ~= room.Id
		or player:GetAttribute("HideSeekRole") ~= "Hider" or room.Out[player.UserId] then
		return
	end
	local userId = player.UserId
	local left = g.trapsLeft[userId] or C.TrapCount
	local now = os.clock()
	if left <= 0 then
		return say(player, "🕸️ 함정을 다 썼어요")
	elseif now - (g.trapAt[userId] or -math.huge) < C.TrapCooldown then
		return
	end
	local character, root, humanoid = alive(player)
	if not character then
		return
	end
	local at = groundAt(root.Position.X, root.Position.Z)
	if humanoid.FloorMaterial == Enum.Material.Air or not at or root.Position.Y - at.Y > TRAP_GROUND_BELOW then
		return say(player, "🕸️ 땅 위에서 놓아요")
	end
	local flat = Vector3.new(at.X, 0, at.Z)
	local seeker = room.Seeker and byId(room.Seeker)
	local seekerRoot = seeker and select(2, alive(seeker))
	if seekerRoot and (Vector3.new(seekerRoot.Position.X, 0, seekerRoot.Position.Z) - flat).Magnitude < C.TrapSeekerGap then
		return say(player, "🕸️ 술래 가까이에는 놓을 수 없어요")
	end
	for _, other in ipairs(g.traps) do
		if (Vector3.new(other.at.X, 0, other.at.Z) - flat).Magnitude < C.TrapGap then
			return say(player, "🕸️ 다른 함정과 너무 가까워요")
		end
	end
	g.trapsLeft[userId] = left - 1
	g.trapAt[userId] = now
	player:SetAttribute("HideSeekTraps", left - 1)
	local yaw = rng:NextNumber(0, 2 * math.pi)
	local trap = { owner = userId, at = at, yaw = yaw }
	trap.model = trapLook("Prop_HideTrap", at, yaw)
	trap.model.Parent = trapFolder()
	local hitbox = Instance.new("Part")
	hitbox.Name = "TrapHitbox"
	hitbox.Anchored = true
	hitbox.CanCollide = false
	hitbox.CanQuery = false
	hitbox.Transparency = 1
	hitbox.Size = Vector3.new(C.TrapSize * TRAP_HITBOX_SHARE, TRAP_HITBOX_HEIGHT, C.TrapSize * TRAP_HITBOX_SHARE)
	hitbox.CFrame = CFrame.new(at + Vector3.new(0, TRAP_HITBOX_HEIGHT / 2, 0)) * CFrame.Angles(0, yaw, 0)
	hitbox.Parent = trapFolder()
	trap.hitbox = hitbox
	trap.conn = hitbox.Touched:Connect(function(part)
		local who = Players:GetPlayerFromCharacter(part:FindFirstAncestorOfClass("Model"))
		if who and who.UserId == room.Seeker and room.Phase == "Seeking" and games[room] == g
			and who:GetAttribute("HideSeekRoom") == room.Id then
			snap(g, trap, who)
		end
	end)
	table.insert(g.traps, trap)
	Net.pushAll("HideSeekTrapFx", "Set", at)
	say(player, string.format("🕸️ 함정을 놓았어요 (남은 함정 %d개)", left - 1))
end

local function finish(room, winner)
	local seekerId = room.Seeker
	local seeker = seekerId and byId(seekerId)
	local hiderIds = Logic.hiders(room) -- (before Logic.finish forgets the seeker)
	local order = Logic.places(room, winner)
	local outcome = Logic.finish(room, winner)
	if room.Staked and #room.Staked > 0 then
		local staked, groups = {}, {}
		for _, p in ipairs(room.Staked) do
			staked[p.UserId] = p
		end
		for _, group in ipairs(order) do
			local players = {}
			for _, userId in ipairs(group) do
				if staked[userId] then
					table.insert(players, staked[userId])
					staked[userId] = nil
				end
			end
			if #players > 0 then
				table.insert(groups, players)
			end
		end
		for _, p in pairs(staked) do
			table.insert(groups, { p })
		end
		Rewards.payStakes(groups, room.Stake)
	end
	room.Staked = nil
	local winWhy = winner == "Seeker" and "모두 찾아냈어요" or "끝까지 숨었어요"
	local loseWhy = winner == "Seeker" and "술래가 모두 찾았어요" or "⏱️ 시간 안에 다 못 찾았어요"
	for _, userId in ipairs(outcome.Wins) do
		-- (the seeker beat the hiders; a hider beat the seeker)
		local counted = record(room, userId, true, userId == seekerId and hiderIds or { seekerId })
		result(room, userId, true, winWhy, counted)
		pay(room, userId, true)
	end
	for _, userId in ipairs(outcome.Losses) do
		record(room, userId, false)
		result(room, userId, false, loseWhy)
		pay(room, userId, false)
	end
	local g = games[room]
	if g then
		for _, conn in ipairs(g.conns) do
			conn:Disconnect()
		end
		clearTraps(g)
		games[room] = nil
	end
	for _, userId in ipairs(room.Members) do
		local p = byId(userId)
		if p and p:GetAttribute("HideSeekRoom") == room.Id then
			release(p)
			giveBack(p)
		end
		if p and p:GetAttribute("HideSeekWatch") == room.Id then
			stopWatching(p)
		end
	end
	local seekerName = seeker and seeker.DisplayName or "?"
	if winner == "Seeker" then
		Net.pushAll("Notice", TITLE, string.format("🏆 술래 %s님이 모두 찾아내 이겼어요!", seekerName))
	else
		local names = {}
		for _, userId in ipairs(outcome.Wins) do
			local p = byId(userId)
			if p then
				table.insert(names, p.DisplayName)
			end
		end
		Net.pushAll("Notice", TITLE, string.format("🏆 끝까지 숨은 %s님이 이겼어요!", #names > 0 and table.concat(names, ", ")
			or "?"))
	end
	sayRoom(room, "✅ 다시 하려면 모두 준비를 눌러요")
	pushRooms()
end

local function checkEnd(room, timeUp)
	local winner = Logic.winner(room, timeUp)
	if winner then
		finish(room, winner)
	end
end

-- a player in a game gives up (a reset, 나가기, leaving the game): their loss
local function giveUp(player)
	local room = Logic.roomOf(state, player.UserId)
	if not room or not Logic.giveUp(room, player.UserId) then
		return
	end
	record(room, player.UserId, false)
	result(room, player.UserId, false, "기권했어요")
	local wasSeeker = room.Seeker == player.UserId
	release(player)
	giveBack(player)
	say(player, "기권해서 졌어요")
	sayRoom(room, string.format(wasSeeker and "술래 %s님이 기권했어요" or "%s님이 기권했어요", player.DisplayName), player.UserId)
	setLeft(room)
	checkEnd(room, false)
end

local function endDisguise(player, wait)
	player:SetAttribute("HideSeekDisguise", nil)
	player:SetAttribute("HideSeekDisguiseToken", nil)
	player:SetAttribute("HideSeekDisguiseReady", Workspace:GetServerTimeNow() + wait)
	dropCopy(player)
end

local function disguiseCatalog()
	if disguiseKinds then
		return disguiseKinds
	end
	disguiseKinds = {}
	local byName = {}
	for _, kind in ipairs(C.DisguiseKinds) do
		local entry = { kind = kind, things = {} }
		table.insert(disguiseKinds, entry)
		for _, name in ipairs(kind.Names or {}) do
			byName[name] = entry
		end
	end
	local function scan(folder)
		for _, child in ipairs(folder:GetChildren()) do
			local entry = byName[child.Name]
			if entry and child:IsA("Model") then
				table.insert(entry.things, child)
			elseif child:IsA("Folder") then
				scan(child)
			end
		end
	end
	local map = Workspace:FindFirstChild("Map")
	local stored = game:GetService("ServerStorage"):FindFirstChild("MapGrass")
	for _, name in ipairs(DISGUISE_FOLDERS) do
		local folder = map and map:FindFirstChild(name) or stored and stored:FindFirstChild(name)
		if folder then
			scan(folder)
		end
	end
	return disguiseKinds
end

local function pickDisguise()
	local options, total = {}, 0
	for _, entry in ipairs(disguiseCatalog()) do
		if not entry.kind.Names or #entry.things > 0 then
			table.insert(options, entry)
			total += entry.kind.Weight
		end
	end
	local roll = rng:NextNumber() * total
	for _, entry in ipairs(options) do
		roll -= entry.kind.Weight
		if roll <= 0 then
			return entry
		end
	end
	return options[#options]
end

local function copyThing(player, source)
	if not disguiseFolder then
		disguiseFolder = Instance.new("Folder")
		disguiseFolder.Name = "HideSeekDisguises"
		disguiseFolder.Parent = ReplicatedStorage
	end
	disguiseCount += 1
	local copy = source:Clone()
	copy.Name = DISGUISE_PREFIX .. disguiseCount
	local function untag(inst)
		for _, tag in ipairs(inst:GetTags()) do
			inst:RemoveTag(tag)
		end
	end
	untag(copy)
	for _, d in ipairs(copy:GetDescendants()) do
		untag(d)
		if d:IsA("BasePart") then
			if d.Transparency >= 1 then
				d:Destroy()
			else
				d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
			end
		else
			local keep = false
			for _, class in ipairs(DISGUISE_KEEP) do
				keep = keep or d:IsA(class)
			end
			if not keep then
				d:Destroy()
			end
		end
	end
	local box, size = source:GetBoundingBox()
	local bottom = box.Position.Y - size.Y / 2
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Include
	local map = Workspace:FindFirstChild("Map")
	params.FilterDescendantsInstances = { Workspace.Terrain, map and map:FindFirstChild("Ground") or Workspace.Terrain }
	local hit = Workspace:Raycast(box.Position + Vector3.new(0, size.Y / 2 + 1, 0),
		Vector3.new(0, -(size.Y + DISGUISE_GROUND_REACH), 0), params)
	copy:SetAttribute("Sink", hit and math.clamp(hit.Position.Y - bottom, 0, size.Y / 2) or 0)
	copy.Parent = disguiseFolder
	dropCopy(player)
	disguiseCopies[player] = copy
	return copy
end

local function disguise(player)
	local practice = player:GetAttribute("HideSeekPractice") == true and not player:GetAttribute("HideSeekRoom")
	local room = Logic.roomOf(state, player.UserId)
	if not practice and (not room or room.Phase == "Waiting" or player:GetAttribute("HideSeekRoom") ~= room.Id
		or player:GetAttribute("HideSeekRole") ~= "Hider" or room.Out[player.UserId]) then
		return
	end
	if player:GetAttribute("HideSeekDisguise") then
		endDisguise(player, C.DisguiseCooldown)
		return say(player, "🎭 변신을 풀었어요")
	end
	local left = player:GetAttribute("HideSeekDisguises") or 0
	local wait = (player:GetAttribute("HideSeekDisguiseReady") or 0) - Workspace:GetServerTimeNow()
	if left <= 0 then
		return say(player, "🎭 변신을 다 썼어요")
	elseif wait > 0 then
		return say(player, string.format("⏳ %d초 뒤에 다시 변신할 수 있어요", math.ceil(wait)))
	end
	if not alive(player) then
		return
	end
	if player:GetAttribute("Riding") and not player:GetAttribute("Watching") then
		Ride.getOff(player, nil, true)
	end
	local now = os.clock()
	player:SetAttribute("HideSeekDisguises", left - 1)
	local entry = pickDisguise()
	local look = nil
	if entry and entry.kind.Names then
		for _ = 1, DISGUISE_TRIES do
			local thing = entry.things[rng:NextInteger(1, #entry.things)]
			if thing.Parent then
				look = copyThing(player, thing).Name
				break
			end
		end
	end
	if not look then
		dropCopy(player)
		entry = nil
		for _, other in ipairs(disguiseCatalog()) do
			if not entry and not other.kind.Names then
				entry = other
			end
		end
		look = C.DisguiseSpecies[rng:NextInteger(1, #C.DisguiseSpecies)]
	end
	local token = look .. "#" .. tostring(now)
	player:SetAttribute("HideSeekDisguise", look)
	player:SetAttribute("HideSeekDisguiseToken", token)
	if practice then
		Unlocks.event(player, "HideDisguise", 1)
	end
	say(player, string.format("%s %d초 동안 숨어요", entry and entry.kind.Says or "🎭 변신!", C.DisguiseSeconds))
	task.delay(C.DisguiseSeconds, function()
		if player.Parent and player:GetAttribute("HideSeekDisguiseToken") == token then
			endDisguise(player, C.DisguiseCooldown)
			say(player, "🎭 변신이 풀렸어요")
		end
	end)
end

function HideSeek.clearDisguise(player)
	if player:GetAttribute("HideSeekDisguise") or player:GetAttribute("HideSeekDisguiseToken") then
		endDisguise(player, 0)
	end
	player:SetAttribute("HideSeekDisguiseReady", nil)
end

-- the seeker's slap reached a hider (Combat.onTag)
local function tag(seeker, hider)
	local room = Logic.roomOf(state, seeker.UserId)
	if not room or Logic.roomOf(state, hider.UserId) ~= room or not Logic.tag(room, seeker.UserId, hider.UserId) then
		return
	end
	record(room, hider.UserId, false)
	result(room, hider.UserId, false, "술래에게 잡혔어요")
	pay(room, hider.UserId, false)
	release(hider)
	Keys.dropAll(hider)
	-- (2026-10-04, "술래잡기가 다인이면 잡힌 사람은 관전자용 익룡 타고 배틀필드 공중에서 끝날때까지 구경하게") others still
	-- playing: up on a spectator pterosaur over the battlefield until the end (watch), else home at once
	if not Logic.winner(room, false) and Ride.watch(hider, C.WatchMount, C.WatchHeight) then
		hider:SetAttribute("HideSeekWatch", room.Id)
		say(hider, "👋 술래에게 잡혔어요! 🦅 익룡을 타고 하늘에서 끝까지 구경해요")
	else
		say(hider, "👋 술래에게 잡혔어요! 기지로 돌아가요")
		sendHome(hider)
		giveBack(hider)
	end
	local left = Logic.left(room)
	sayRoom(room, string.format("👋 %s님이 잡혔어요! 남은 사람 %d명", hider.DisplayName, left), hider.UserId)
	setLeft(room)
	checkEnd(room, false)
end

-- can this player play now? (else why not)
local function canPlay(player)
	if not alive(player) or not PlayerData.isLoaded(player) then
		return false, "🚫 지금은 숨바꼭질을 할 수 없어요"
	elseif player:GetAttribute("Racing") or player:GetAttribute("RacePractice") then
		return false, "🏁 레이스 중에는 숨바꼭질을 할 수 없어요"
	elseif player:GetAttribute("TutorialStep") then
		return false, "🐣 튜토리얼을 마치고 해요"
	elseif player:GetAttribute("InRoom") == "Race" then -- (2026-10-04: one room at a time)
		return false, "🏁 레이스 방에서 먼저 나와요"
	end
	return true
end

local function lacksStake(player, grade)
	if not Rewards.hasStake(player, grade) then
		say(player, string.format("🔑 이 랭킹전은 %s를 걸어야 해요 (등수가 높으면 더 많이 돌려받아요)", Rewards.stakeText(grade)))
		return true
	end
	return false
end

local function begin(room)
	-- those who can't play now are taken out of the room first
	for _, userId in ipairs(table.clone(room.Members)) do
		local p = byId(userId)
		local ok, why = true, nil
		if p then
			ok, why = canPlay(p)
		end
		if not ok then
			Logic.leave(state, userId)
			if p then
				p:SetAttribute("InRoom", nil)
				say(p, why)
				say(p, "방에서 나왔어요")
			end
		end
	end
	room.StartAt = nil
	if room.Ranked then
		for _, userId in ipairs(table.clone(room.Members)) do
			local p = byId(userId)
			if p and lacksStake(p, room.Stake) then
				Logic.leave(state, userId)
				p:SetAttribute("InRoom", nil)
				say(p, "방에서 나왔어요")
			end
		end
	end
	if not Logic.canStart(room) then
		sayRoom(room, "👥 사람이 모자라 시작하지 못했어요")
		pushRooms()
		return
	end
	room.Staked = {}
	if room.Ranked then
		for _, userId in ipairs(room.Members) do
			local p = byId(userId)
			if p and Rewards.takeStake(p, room.Stake) then
				table.insert(room.Staked, p)
			end
		end
	end
	local seekerId = Logic.start(room, function()
		return rng:NextNumber()
	end)
	local hiders = Logic.hiders(room)
	local hideUntil = Workspace:GetServerTimeNow() + C.HideSeconds
	local g = { endsAt = os.clock() + C.HideSeconds, conns = {}, traps = {}, trapsLeft = {}, trapAt = {}, trapSafeUntil = 0,
		paid = {} }
	games[room] = g
	local center = altarCenter()
	local spots = hidingSpots(#hiders)
	for i, userId in ipairs(room.Members) do
		local p = byId(userId)
		local character = p and alive(p)
		if p and character then
			local isSeeker = userId == seekerId
			if p:GetAttribute("Riding") then -- (joined from anywhere: off their dino before being taken there)
				rodeBefore[p] = true -- (given back after: giveBack)
				Ride.getOff(p, nil, true) -- (not put out of the battlefield first)
			end
			p:SetAttribute("HideSeekRoom", room.Id)
			p:SetAttribute("HideSeekRole", isSeeker and "Seeker" or "Hider")
			p:SetAttribute("HideSeekPhase", "Hiding")
			p:SetAttribute("HideSeekUntil", hideUntil)
			p:SetAttribute("HideSeekLeft", #hiders)
			Keys.dropAll(p)
			local humanoid = character:FindFirstChildOfClass("Humanoid")
			table.insert(g.conns, humanoid.Died:Connect(function()
				giveUp(p)
			end))
			if isSeeker then
				local angle = rng:NextNumber(0, 360)
				local at = center + dir(angle) * C.SeekerSpawnRadius
				local ground = groundAt(at.X, at.Z) or at
				putAt(p, ground + Vector3.new(0, ABOVE_GROUND, 0), center)
				MoveGuard.stun(p, C.HideSeconds, "HideSeek")
				local mark = Instance.new("Highlight")
				mark.Name = "HideSeekMark"
				mark.FillColor = SEEKER_COLOR
				mark.FillTransparency = 0.6
				mark.OutlineColor = SEEKER_COLOR
				-- (2026-10-03, "술래가 멀리서 윤곽으로 안 보이게": it showed through everything, from anywhere) only where
				-- the seeker can be seen; the screens show it only up close too (HideSeek.client SEEKER_MARK_NEAR)
				mark.DepthMode = Enum.HighlightDepthMode.Occluded
				mark.Parent = character
			else
				local k = table.find(hiders, userId) or i
				local at = spots[k] or spots[1]
				putAt(p, at + Vector3.new(0, ABOVE_GROUND, 0), center)
				humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
				p:SetAttribute("HideSeekTraps", C.TrapCount)
				p:SetAttribute("HideSeekDisguises", C.DisguiseCount)
			end
		end
	end
	for _, userId in ipairs(room.Members) do
		local p = byId(userId)
		if p then
			say(p, room.Ranked and "🏆 랭킹전! 이기면 기록이 남고 이번 주 순위에 들어가요" or "🎈 일반전이라 기록은 남지 않아요")
			if userId == seekerId then
				say(p, "⚡ 술래가 조금 더 빨라요! 속도 발판은 모두 써요") -- (2026-10-04: everyone uses the pads again)
			else
				say(p, string.format("🙈 %d초 안에 숨어요! 숨는 동안 찰싹은 못 써요", C.HideSeconds))
				say(p, string.format("🕸️ 함정 %d개를 놓을 수 있어요. 술래가 밟으면 %s초 멈춰요", C.TrapCount,
					tostring(C.TrapStunSeconds)))
				say(p, "⚡ 술래가 조금 더 빨라요! 속도 발판과 🌳 나무 오르기로 따돌려요")
			end
		end
	end
	pushRooms()
	checkEnd(room, false) -- (someone gone between)
end

local function toSeeking(room)
	room.Phase = "Seeking"
	local g = games[room]
	g.endsAt = os.clock() + C.SeekSeconds
	g.firstBell = os.clock() + C.BellFirst -- (then each hider's own clock, seekingStep)
	g.outsideSaid, g.nextBell, g.ringFrom, g.near = {}, {}, {}, {}
	g.nextRadar = os.clock() + C.RadarFirst
	g.radarWarned, g.radarFrom = false, nil
	local untilTime = Workspace:GetServerTimeNow() + C.SeekSeconds
	for _, userId in ipairs(room.Members) do
		local p = byId(userId)
		if p and p:GetAttribute("HideSeekRoom") == room.Id then
			p:SetAttribute("HideSeekPhase", "Seeking")
			p:SetAttribute("HideSeekUntil", untilTime)
			say(p, string.format("🔔 %d초 뒤부터 숨은 사람의 종이 저절로 울려요 (끝날수록 자주)", C.BellFirst))
			if userId == room.Seeker then -- (2026-10-04) 📡
				say(p, string.format("📡 %d초마다 탐지기: 움직이는 숨은 사람 쪽을 알려 줘요", C.RadarEvery))
			else
				say(p, "🤫 가만히 숨어 있으면 종 위치가 흐려져요")
				say(p, "📡 탐지기 경고가 뜨면 멈춰요! 움직이면 들켜요")
			end
		end
	end
	pushRooms()
end

-- the players of this game still in it (who see its bells)
local function gamePlayers(room)
	local players = {}
	for _, userId in ipairs(room.Members) do
		local p = byId(userId)
		if p and p:GetAttribute("HideSeekRoom") == room.Id then
			table.insert(players, p)
		end
	end
	return players
end

-- the hiders still in, with their root parts: { { userId, player, root } }
local function hidersIn(room)
	local list = {}
	for _, userId in ipairs(Logic.hiders(room)) do
		local p = not room.Out[userId] and byId(userId)
		if p and p:GetAttribute("HideSeekRoom") == room.Id then
			local _, root = alive(p)
			if root then
				table.insert(list, { userId = userId, player = p, root = root })
			end
		end
	end
	return list
end

local function seekerRoot(room)
	local seeker = byId(room.Seeker)
	if not seeker then
		return nil, nil
	end
	local _, root = alive(seeker)
	return seeker, root
end

local function radarWarn(room, players)
	for _, p in ipairs(players) do
		Net.push(p, "HideSeekRadarWarn", C.RadarWarnSeconds, p.UserId == room.Seeker)
	end
end

local function radarSweep(room, g)
	local seeker, root = seekerRoot(room)
	local hiders = hidersIn(room)
	local samples = {}
	for _, h in ipairs(hiders) do
		local from = g.radarFrom[h.userId]
		if from then
			table.insert(samples, { hider = h, from = from, to = h.root.Position })
		end
	end
	local best = nil
	if root then
		local pick, distance = Logic.radarPick(root.Position, samples, C.RadarMoveStuds)
		best = pick and pick.hider
		if best then
			local way = (best.root.Position - root.Position) * Vector3.new(1, 0, 1)
			way = way.Magnitude > 0.1 and way.Unit or Vector3.new(0, 0, -1)
			local band = distance <= C.RadarNear and "Near" or distance <= C.RadarMid and "Mid" or "Far"
			Net.push(seeker, "HideSeekRadar", "Seeker", way.X, way.Z, band)
		elseif seeker then
			Net.push(seeker, "HideSeekRadar", "Seeker")
		end
	end
	for _, sample in ipairs(samples) do
		local moved = (sample.to - sample.from).Magnitude > C.RadarMoveStuds
		Net.push(sample.hider.player, "HideSeekRadar", "Hider",
			sample.hider == best and "Caught" or moved and "Moved" or "Still")
	end
end

-- while seeking, every step: the bells, the radar and the near misses
local function seekingStep(room, g, now)
	local late = g.endsAt - now <= C.LateSeconds
	local final = g.endsAt - now <= C.FinalSeconds
	local hiders = hidersIn(room)
	local gap = Formulas.hideSeekBellGap(now - (g.endsAt - C.SeekSeconds), g.endsAt - now, #hiders)
	local players = nil
	for _, h in ipairs(hiders) do
		local outside = SafeZones.isSafe(h.root.Position)
		local due = g.nextBell[h.userId] or g.firstBell
		if now >= due then
			players = players or gamePlayers(room)
			local from = g.ringFrom[h.userId]
			local blur = Logic.bellBlur(from and (h.root.Position - from).Magnitude, g.endsAt - now)
			local angle, reach = rng:NextNumber() * 2 * math.pi, blur * math.sqrt(rng:NextNumber())
			local shown = h.root.Position + Vector3.new(math.cos(angle) * reach, 0, math.sin(angle) * reach)
			Bell.force(h.player, players, shown, blur)
			g.ringFrom[h.userId] = h.root.Position
			g.nextBell[h.userId] = now + gap * (outside and C.OutsideBellFactor or 1)
				* (1 + C.BellJitter * (2 * rng:NextNumber() - 1))
			if outside and not g.outsideSaid[h.userId] then -- (once a game: why it rings more)
				g.outsideSaid[h.userId] = true
				say(h.player, "🔔 들판 밖에 숨으면 종이 더 자주 울려요!")
			end
		elseif not g.ringFrom[h.userId] then
			g.ringFrom[h.userId] = h.root.Position
		end
	end
	-- (the line only the first time and when the late part starts: every 8 seconds it was a flood)
	if players then
		if final and not g.finalSaid then
			g.bellSaid, g.lateSaid, g.finalSaid = true, true, true
			sayRoom(room, string.format("🔔 마지막 %d초! 종이 더 자주, 더 정확하게 울려요!", C.FinalSeconds))
		elseif not g.bellSaid or (late and not g.lateSaid) then
			g.bellSaid, g.lateSaid = true, late or g.lateSaid
			sayRoom(room, late and "🔔 이제 종이 더 자주 울려요!" or "🔔 숨은 사람들의 종이 울렸어요!")
		end
	end
	if not g.radarWarned and now >= g.nextRadar - C.RadarWarnSeconds then
		g.radarWarned = true
		radarWarn(room, players or gamePlayers(room))
	end
	if not g.radarFrom and now >= g.nextRadar then
		g.radarFrom = {}
		for _, h in ipairs(hiders) do
			g.radarFrom[h.userId] = h.root.Position
		end
	elseif g.radarFrom and now >= g.nextRadar + C.RadarSampleSeconds then
		radarSweep(room, g)
		g.radarFrom, g.radarWarned = nil, false
		g.nextRadar += C.RadarEvery
	end
	local _, root = seekerRoot(room)
	if root then
		for _, h in ipairs(hiders) do
			local d = ((h.root.Position - root.Position) * Vector3.new(1, 0, 1)).Magnitude
			if d <= C.NearMissStuds then
				g.near[h.userId] = true
			elseif g.near[h.userId] and d >= C.NearMissClear then
				g.near[h.userId] = nil
				Net.push(h.player, "HideSeekNearMiss")
			end
		end
	end
end

-- nobody in a game leaves the battlefield: put back EdgeMargin inside its flags
local function confine(player)
	local character, root = alive(player)
	if not character then
		return
	end
	local flat = Vector3.new(root.Position.X, 0, root.Position.Z)
	local edge = Config.Battlefield.Radius
	if flat.Magnitude <= edge - 1 or flat.Magnitude < 1 then
		return
	end
	local back = flat.Unit * (edge - C.EdgeMargin)
	local ground = groundAt(back.X, back.Z) or Vector3.new(back.X, root.Position.Y - ABOVE_GROUND, back.Z)
	putAt(player, ground + Vector3.new(0, ABOVE_GROUND, 0), Vector3.zero)
	say(player, "숨바꼭질 중에는 ⚔️ 들판을 나갈 수 없어요")
end

local function step()
	local now = os.clock()
	-- (2026-10-04) put back on their own dino as soon as they are off the battlefield, out of any game, for a while
	for p, untilAt in pairs(rodeBefore) do
		if not p.Parent or (untilAt ~= true and now >= untilAt) then
			rodeBefore[p] = nil
		elseif untilAt ~= true and not p:GetAttribute("HideSeekRoom") and not p:GetAttribute("HideSeekWatch")
			and not p:GetAttribute("Racing") and Ride.giveBack(p, true) then
			rodeBefore[p] = nil
			say(p, "🦖 타던 공룡을 다시 태워 줬어요")
		end
	end
	for _, room in pairs(state.Rooms) do
		if room.Phase == "Waiting" then
			if room.StartAt and not Logic.canStart(room) then
				room.StartAt = nil
				sayRoom(room, "시작이 취소됐어요")
			elseif room.StartAt and now >= room.StartAt then
				begin(room)
			end
		else
			for _, userId in ipairs(room.Members) do
				local p = byId(userId)
				if p and p:GetAttribute("HideSeekRoom") == room.Id then
					confine(p)
				elseif p and p:GetAttribute("HideSeekWatch") == room.Id and not p:GetAttribute("Riding") then
					stopWatching(p) -- (off the dino some other way: a reset)
				end
			end
			local g = games[room]
			if g and room.Phase == "Seeking" and now < g.endsAt then
				seekingStep(room, g, now)
			end
			if g and now >= g.endsAt then
				if room.Phase == "Hiding" then
					toSeeking(room)
				else
					checkEnd(room, true)
				end
			end
		end
	end
end

-- (2026-10-03, "그 버튼으로도 숨바꼭질 열 수 있게 해 방. 가운데 가야만 열 수 있는건 좀") a room can be opened and joined
-- from anywhere (the board, or the 🙈 corner button): the game's start takes everyone onto the battlefield
local lastRoomNotice = {} -- [player] = os.clock() of their last room-opened notice to everyone
local lastRecruit = {} -- [player] = os.clock() of their last 📣 모집

local function create(player, ranked, grade)
	if not Unlocks.check(player, "GameRooms") then
		return
	end
	local ok, why = canPlay(player)
	if not ok then
		return say(player, why)
	end
	if ranked == true and lacksStake(player, grade) then
		return
	end
	local room, reason = Logic.create(state, player.UserId, ranked, grade)
	if not room then
		return say(player, reason)
	end
	player:SetAttribute("InRoom", "Hide")
	say(player, string.format("🚪 %d번 방을 열었어요. %d명 이상 모여 모두 준비하면 시작해요", room.Id, C.MinPlayers))
	-- (2026-10-04, "술래잡기 방 만들면 알림 가도 되게 해도 되나") everyone else here who could join hears of it, once
	-- every RoomNoticeGap seconds a player at most (opening and closing over and over is not news)
	if os.clock() - (lastRoomNotice[player] or -math.huge) >= C.RoomNoticeGap then
		lastRoomNotice[player] = os.clock()
		-- (2026-10-04) the corner button is 🎮 놀이방 now; the room's mode after it
		local text = string.format("🙈 %s님이 숨바꼭질 방을 열었어요! 왼쪽 아래 🎮 놀이방 버튼으로 들어와요", player.DisplayName)
			.. " · " .. (room.Ranked and "🏆 랭킹전 🔑 " .. Rewards.stakeText(room.Stake) or "🎈 일반전")
		for _, other in ipairs(Players:GetPlayers()) do
			if other ~= player and not other:GetAttribute("InRoom") and canPlay(other) then
				say(other, text)
				Net.push(other, "RoomCallFx") -- (2026-10-04: the 🎮 놀이방 button flashes, so they know where)
			end
		end
	end
	pushRooms()
end

-- (2026-10-04, "놀이방에서 내가 놀이방에서 기다리고 있다는 것 같은 모집을 위한 알림을 날릴 수 있게 해줘 서버 안 사람들에게.
-- 10초에 한 번씩", "방 만든 이후에 가능하게", "방장만 하는게 낫지") 📣 모집: the host of a waiting room tells everyone here
-- not in it, at most every C.RecruitGap seconds
local function recruit(player)
	local room = Logic.roomOf(state, player.UserId)
	if not room or room.Phase ~= "Waiting" then
		return say(player, "📣 방에 들어간 뒤에 모집할 수 있어요")
	end
	if room.Host ~= player.UserId then -- (2026-10-04, "방장만 하는게 낫지")
		return say(player, "📣 모집은 방장만 할 수 있어요")
	end
	local left = C.RecruitGap - (os.clock() - (lastRecruit[player] or -math.huge))
	if left > 0 then
		return say(player, string.format("📣 %d초 뒤에 다시 모집할 수 있어요", math.ceil(left)))
	end
	lastRecruit[player] = os.clock()
	local text = string.format("📣 %s님이 🙈 숨바꼭질 %d번 방에서 기다려요! (%d/%d명) 왼쪽 아래 🎮 놀이방 버튼으로 들어와요",
		player.DisplayName, room.Id, #room.Members, C.MaxPlayers) .. " · " .. (room.Ranked and "🏆 랭킹전 🔑 " .. Rewards.stakeText(room.Stake) or "🎈 일반전")
	local members = {}
	for _, userId in ipairs(room.Members) do
		members[userId] = true
	end
	for _, other in ipairs(Players:GetPlayers()) do
		if not members[other.UserId] then
			say(other, text)
			Net.push(other, "RoomCallFx")
		end
	end
	say(player, "📣 서버의 모두에게 모집 알림을 보냈어요")
end

local function join(player, roomId)
	if not Unlocks.check(player, "GameRooms") then
		return
	end
	local ok, why = canPlay(player)
	if not ok then
		return say(player, why)
	end
	local target = state.Rooms[roomId]
	if target and target.Ranked and lacksStake(player, target.Stake) then
		return
	end
	local room, reason = Logic.join(state, player.UserId, roomId)
	if not room then
		return say(player, reason)
	end
	player:SetAttribute("InRoom", "Hide")
	sayRoom(room, string.format("%s님이 들어왔어요", player.DisplayName), player.UserId)
	pushRooms()
end

local function leave(player)
	local room = Logic.roomOf(state, player.UserId)
	if not room then
		return
	end
	giveUp(player) -- (in a game: a loss)
	if player.Parent then
		stopWatching(player)
	end
	Logic.leave(state, player.UserId)
	if player.Parent then
		player:SetAttribute("InRoom", nil)
	end
	if state.Rooms[room.Id] then
		sayRoom(room, string.format("%s님이 방에서 나갔어요", player.DisplayName))
		if room.Phase ~= "Waiting" then
			setLeft(room)
			checkEnd(room, false)
		end
	end
	pushRooms()
end

-- (2026-10-04, "레이스 준비도 준비하면 알림으로 방 인원들한테 가고") a member readying (or not) is told to the rest of the
-- room, with how many are ready
local function sayReady(room, player, isReady)
	local n = 0
	for _, userId in ipairs(room.Members) do
		n += room.Ready[userId] and 1 or 0
	end
	sayRoom(room, isReady and string.format("✋ %s님 준비! (%d/%d명)", player.DisplayName, n, #room.Members)
		or string.format("%s님이 준비를 취소했어요 (%d/%d명)", player.DisplayName, n, #room.Members), player.UserId)
end

local function ready(player, isReady)
	local before = Logic.roomOf(state, player.UserId)
	local was = before ~= nil and before.Ready[player.UserId] == true
	local room = Logic.setReady(state, player.UserId, isReady)
	if not room then
		return
	end
	if was ~= (isReady == true) then
		sayReady(room, player, isReady)
	end
	if Logic.canStart(room) and not room.StartAt then
		room.StartAt = os.clock() + C.StartSeconds
		sayRoom(room, string.format("✅ 모두 준비 완료! %d초 뒤 시작해요", C.StartSeconds))
	end
	pushRooms()
end

local function makeBoard()
	local old = Workspace:FindFirstChild("HideSeek")
	if old then
		old:Destroy()
	end
	local folder = Instance.new("Folder")
	folder.Name = "HideSeek"
	folder.Parent = Workspace
	local center = altarCenter()
	local spot = center + dir(C.BoardAngle) * C.BoardOut
	local ground = groundAt(spot.X, spot.Z) or spot
	local facing = CFrame.lookAt(ground, Vector3.new(center.X, ground.Y, center.Z)) -- the face toward the altar
	local model = Instance.new("Model")
	model.Name = "Board"
	local function part(name, size, cf, color)
		local p = Instance.new("Part")
		p.Name = name
		p.Anchored = true
		p.Size = size
		p.CFrame = cf
		p.Color = color
		p.Material = Enum.Material.Wood
		p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
		p.Parent = model
		return p
	end
	local sign = part("Sign", BOARD_SIZE, facing * CFrame.new(0, BOARD_POST.Y - BOARD_SIZE.Y / 2, 0), BOARD_WOOD)
	for _, side in ipairs({ -1, 1 }) do
		part("Post", BOARD_POST, facing * CFrame.new(side * (BOARD_SIZE.X / 2 - 0.6), BOARD_POST.Y / 2, BOARD_SIZE.Z),
			BOARD_WOOD)
	end
	model.PrimaryPart = sign
	local gui = Instance.new("SurfaceGui")
	gui.Face = Enum.NormalId.Front
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud = 40
	gui.Parent = sign
	-- (2026-10-03, "숨박꼭질도 랭킹을..") the face: the title, "방 만들기 · 참가" and the all-server top HideSeekBoardTop by
	-- wins (ReplicatedStorage HideSeekTop, Leaderboards), each line its own label (each translated as a whole)
	local face = Instance.new("Frame")
	face.Size = UDim2.fromScale(0.94, 0.88)
	face.Position = UDim2.fromScale(0.03, 0.06)
	face.BackgroundColor3 = BOARD_FACE
	face.BorderSizePixel = 0
	face.Parent = gui
	local layout = Instance.new("UIListLayout")
	layout.SortOrder = Enum.SortOrder.LayoutOrder
	layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	layout.Parent = face
	local function line(text, height, order)
		local l = Instance.new("TextLabel")
		l.Size = UDim2.fromScale(0.96, height)
		l.BackgroundTransparency = 1
		l.TextColor3 = BOARD_TEXT
		l.Font = Enum.Font.FredokaOne
		l.TextScaled = true
		l.Text = text
		l.LayoutOrder = order
		l.Parent = face
		return l
	end
	line("🙈 숨바꼭질", 0.34, 1)
	line("방 만들기 · 참가", 0.18, 2)
	local rows = {}
	for i = 1, Config.Leaderboard.HideSeekBoardTop do
		rows[i] = line("", 0.16, 2 + i)
	end
	local function showTop()
		local ok, list = pcall(HttpService.JSONDecode, HttpService, ReplicatedStorage:GetAttribute("HideSeekTop") or "[]")
		list = ok and type(list) == "table" and list or {}
		for i, row in ipairs(rows) do
			local entry = list[i]
			row.Text = entry and string.format("%s %s · %d승", MEDALS[i] or "🏅", tostring(entry.Name), entry.Wins or 0)
				or (i == 1 and "🏆 아직 우승자가 없어요" or "")
		end
	end
	showTop()
	ReplicatedStorage:GetAttributeChangedSignal("HideSeekTop"):Connect(showTop)
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "HideSeekPrompt"
	prompt.ActionText = TITLE
	prompt.ObjectText = ""
	prompt.HoldDuration = 0
	prompt.RequiresLineOfSight = false
	prompt.MaxActivationDistance = C.BoardRange
	prompt:SetAttribute("Kind", "HideSeek")
	prompt.Parent = sign
	model.Parent = folder
	Bases.title(model, TITLE, BOARD_FACE)
	board = model
end

function HideSeek.init()
	makeBoard()
	PlayerData.onLoaded(mirrorRecord)
	Combat.onTag(tag)
	Net.onRequest("HideSeekCreate", { "boolean", "string" }, create)
	Net.onRequest("HideSeekJoin", { "number" }, join)
	Net.onRequest("HideSeekLeave", {}, leave)
	Net.onRequest("HideSeekReady", { "boolean" }, ready)
	Net.onRequest("HideSeekRecruit", {}, recruit)
	Net.onRequest("HideSeekTrap", {}, placeTrap)
	Net.onRequest("HideSeekDisguise", {}, disguise)
	Net.onAsk("GetHideSeek", {}, function(player)
		local profile = PlayerData.get(player)
		local record = profile and profile.HideSeek or {}
		local ranked = profile and profile.Ranked
		local week = RewardLogic.weekNumber(os.time())
		return { Rooms = Logic.snapshot(state), Wins = record.Wins or 0, Losses = record.Losses or 0,
			WeekWins = ranked and ranked.Week == week and ranked.Hide or 0 }
	end)
	Players.PlayerRemoving:Connect(function(player)
		lastRoomNotice[player], lastRecruit[player], rodeBefore[player] = nil, nil, nil
		dropCopy(player)
		if Logic.roomOf(state, player.UserId) then
			leave(player)
		end
	end)
	task.spawn(function()
		while true do
			task.wait(C.CheckEvery)
			local ok, err = pcall(step)
			if not ok then
				warn("[HideSeek] " .. tostring(err))
			end
		end
	end)
end

return HideSeek
