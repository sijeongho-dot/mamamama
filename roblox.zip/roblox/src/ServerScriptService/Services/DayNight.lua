--[[
DayNight: the game's day and night (design 2.12 낮과 밤).

- Config.DayNight: DaySeconds of day, then NightSeconds of night, over and over. The sun moves with it
  (Lighting.ClockTime, which every client sees): 6:00 to 18:00 through the day, 18:00 over midnight to
  6:00 through the night (dusk and dawn come with the moving sun).
- ReplicatedStorage attributes: Night (true at night), PhaseEndsAt (server time the day or night
  ends), for the clients' clock.
- A big banner, like the weather's, when night falls ("🌙 밤이 되었어요! 광물 캐기 1.5배 · 좀비 공룡
  조심") and when day comes. Mining is better at night (Formulas.nightMining, Minerals).
- The sun rises as the day starts and sets as the night starts; the moon the other way round. Both
  go east → south → west (Roblox's sky), clockwise seen from above.
- DayNight.onChange(fn(night)) for the Zombies service; DayNight.set(night) for Studio tests.
]]

local Lighting = game:GetService("Lighting")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local ServerMeter = require(script.Parent:WaitForChild("ServerMeter")) -- (2026-10-04: its loop timed, Watchdog)
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))

local DayNight = {}

-- display only
local DAY_START, DAY_END = 6, 18 -- clock hours the day runs through
local NIGHT_BANNER = "🌙 밤이 되었어요! 광물 캐기 %g배 · 좀비 공룡 조심 (%d분)"
local DAY_BANNER = "☀️ 낮이 되었어요! 좀비 공룡이 땅속으로 돌아가요 (%d분)"

local night = false
local phaseStart, phaseLength = 0, 0
local listeners = {}

local function begin(isNight, announce)
	night = isNight
	phaseStart = os.clock()
	phaseLength = isNight and Config.DayNight.NightSeconds or Config.DayNight.DaySeconds
	ReplicatedStorage:SetAttribute("Night", isNight)
	ReplicatedStorage:SetAttribute("PhaseEndsAt", Workspace:GetServerTimeNow() + phaseLength)
	if announce then -- a big banner like the weather's ("Night" / "Day" style it on the clients)
		local minutes = math.floor(phaseLength / 60 + 0.5)
		Net.pushAll("Banner", isNight and string.format(NIGHT_BANNER, Config.DayNight.NightMiningYield, minutes)
			or string.format(DAY_BANNER, minutes), isNight and "Night" or "Day")
	end
	for _, fn in ipairs(listeners) do
		task.spawn(fn, isNight)
	end
end

-- the clock hour now: the day spans DAY_START..DAY_END, the night DAY_END..24+DAY_START (over midnight)
local function clockNow()
	local k = math.clamp((os.clock() - phaseStart) / math.max(phaseLength, 1), 0, 1)
	if night then
		return (DAY_END + k * (24 - DAY_END + DAY_START)) % 24
	end
	return DAY_START + k * (DAY_END - DAY_START)
end

function DayNight.isNight()
	return night
end

function DayNight.onChange(fn)
	table.insert(listeners, fn)
end

-- Studio tests: night or day right now
function DayNight.set(isNight)
	begin(isNight, true)
end

-- (2026-10-03) the tutorial field (TutorialField): this phase stays until hold(false) (the clock stops moving on)
local held = false
function DayNight.hold(on)
	held = on == true
end

function DayNight.init()
	begin(false, false)
	local sinceClock = 0
	RunService.Heartbeat:Connect(ServerMeter.wrap("DayNight", function(dt)
		if held then
			phaseStart = math.max(phaseStart, os.clock() - phaseLength * 0.5) -- (stays in the phase's middle)
		elseif os.clock() - phaseStart >= phaseLength then
			begin(not night, true)
		end
		sinceClock += dt
		if sinceClock >= 0.5 then -- the sun moves smoothly enough at two steps a second
			sinceClock = 0
			Lighting.ClockTime = clockNow()
		end
	end))
end

return DayNight
