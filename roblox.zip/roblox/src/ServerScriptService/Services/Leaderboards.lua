--[[
Leaderboards: the all-server ranking on the central board (design 2.9 중앙 게시판). Each player's real
defense level (it goes on through the rebirth tiers, so it ranks rebirths too) is written to an
OrderedDataStore (Config.Leaderboard.StoreName) when it changes, at most every WriteSeconds, and when
they leave. Every ReadSeconds the server reads the top Config.Leaderboard.Top and puts them on
ReplicatedStorage as the attribute GlobalRanking (JSON: a list of { Name, Level }), which the board's
screen and window show (StarterPlayerScripts/Npcs). This server's own ranking needs nothing from here
(the clients rank the players they see). (2026-10-02) Also the best race times, road and sky (raceTime, readRaces:
attributes RaceTopRoad / RaceTopSky), shown in the mount window. Without DataStore access (Studio with API access off) the
list stays empty and the board says so.
(2026-10-02) ♾️ 무한 도전 (Config.Defense.Challenge): each week has its own OrderedDataStore (StoreName .. "_" .. week,
UserId -> this week's best waves). A player's best is written when it grows (challengeBest), on the regular pass
and when they leave; the week's top Challenge.Top go on ReplicatedStorage as ChallengeTop (JSON: a list of
{ Name, Waves }), with ChallengeWeekEnds (server time the week ends) and ChallengeRule (this week's rule's Id). Last week's rank pays its
RankRewards when the player is here in the new week (read once a week, RankRead deep, after the week has
settled for RANK_SETTLE seconds; RewardLogic.challengeRankDue keeps it to once).
(2026-10-03, "숨박꼭질도 랭킹을..") 🙈 hide-and-seek wins: Config.Leaderboard.HideSeekStoreName (UserId -> games won),
written at each win (Leaderboards.hideSeekWins, HideSeek service; 0 after the record reset product takes them off), its
top Config.Leaderboard.Top as HideSeekTop (JSON: a list of { Name, Wins }).
(2026-10-02, 도감 자랑하기) The collection count too: Config.Collection.StoreName (UserId -> pairs collected), written
with the defense level, its top Config.Leaderboard.Top as DexTop (JSON: a list of { Name, Count }) for the board.
(2026-10-04, "랭킹전 보상도 주간 열쇠로 주는 식 어때") 🏆 랭킹전: each game of Config.Ranked.Games ("Hide", "Race") has a store
per week (Config.Ranked.StoreName .. "_" .. game .. "_" .. week, UserId -> counted ranked wins, RewardLogic.rankedWin),
written at each counted win (Leaderboards.rankedWin) and when they leave; this week's top Config.Ranked.Top as
HideWeekTop / RaceWeekTop (JSON: a list of { Name, Wins }) for the 🎮 놀이방 window. (2026-10-04) "Boss": this week's 🧟
night bosses helped down (Zombies service), BossWeekTop, the same way. A finished week's rank pays
Config.Ranked.RankRewards (the rest with a win PlayReward) when the player is here in a later week, like the ♾️ one.
]]

local DataStoreService = game:GetService("DataStoreService")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))
local TutorialField = require(script.Parent:WaitForChild("TutorialField"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))

local Leaderboards = {}

local store = nil
local raceStores = {} -- (2026-10-02) { Road = OrderedDataStore, Sky = ... }: the best race times
local written = {} -- [player] = { level, at }
local names = {} -- [userId] = name (cached; looking names up is slow)
local dexStore = nil -- (2026-10-02) the collection counts
local hideStore = nil -- (2026-10-03) 🙈 hide-and-seek wins
local dexWritten = {} -- [player] = the count last written
local challengeStores = {} -- [week] = OrderedDataStore, or false when it could not be had
local challengeWritten = {} -- [player] = "week:best" last written
local lastRanks = {} -- [week] = { [userId] = rank }: a finished week's top RankRead (read once)
local rankedStores = {} -- (2026-10-04) [game .. ":" .. week] = OrderedDataStore, or false when it could not be had
local rankedWritten = {} -- [player] = { [game] = "week:wins" last written }
local rankedRanks = {} -- [game .. ":" .. week] = { [userId] = rank }: a finished week's top (read once)
local RANKED_TITLES = { -- the reward's line: a rank, or the play reward
	Hide = { "🙈 지난주 숨바꼭질 랭킹전 %d위!", "🙈 지난주 숨바꼭질 랭킹전 선물!" },
	Race = { "🏁 지난주 레이스 랭킹전 %d위!", "🏁 지난주 레이스 랭킹전 선물!" },
	Boss = { "🧟 지난주 보스 사냥 %d위!", "🧟 지난주 보스 사냥 선물!" }, -- (2026-10-04, the night boss's ③)
}
local RANK_SETTLE = 600 -- seconds into a new week before last week's list is read (the last writes land first)
local WEEK_EVERY = 60 -- seconds between updates of ChallengeWeekEnds

-- (2026-10-04, "나 Honey_anana 는 개발자 입장이라 랭킹에 안 올라야 할 거 같은데 모든 랭킹에서 나만 안뜨게 해줘") the developers
-- (Config.Developers) are never written to a ranking, are taken off every ranking when they come in, and are left out
-- of every list read (their UserIds looked up by name once)
local hiddenIds = {} -- [userId] = true
local function hidden(player)
	return Formulas.isDeveloper(player.Name)
end
local function shown(userId)
	return userId ~= nil and not hiddenIds[userId]
end
-- (2026-10-04, "전 서버 탑10에서도 내 닉네임 제외해") a top list reads this many more (the developers left out still leave
-- n), and keeps n
local function readCount(n)
	return n + #Config.Developers.Names
end
local ID_WAIT = 15 -- seconds the first read waits at most for the developers' UserIds
local idsReady = false -- the developers' UserIds looked up (the first read waits for it)


local function write(player, force)
	if hidden(player) then
		return -- (a developer: never ranked)
	end
	if TutorialField.isField() or PlayerData.isPractice(player) then
		return -- (2026-10-03: a tutorial field's practice save is never ranked)
	end
	local profile = store and PlayerData.get(player)
	if not profile or not PlayerData.isPersistent(player) then
		return
	end
	local last = written[player]
	local now = os.clock()
	if last and (last.level == profile.DefenseLevel or (not force and now - last.at < Config.Leaderboard.WriteSeconds)) then
		return
	end
	written[player] = { level = profile.DefenseLevel, at = now }
	local ok, err = pcall(function()
		store:SetAsync(tostring(player.UserId), profile.DefenseLevel)
	end)
	if not ok then
		warn("[Leaderboards] 저장 실패: " .. tostring(err))
	end
end

-- the collection count, when it grew since the last write (yields)
local function writeDex(player)
	if hidden(player) then
		return -- (a developer: never ranked)
	end
	if TutorialField.isField() or PlayerData.isPractice(player) then
		return -- (2026-10-03: a tutorial field's practice save is never ranked)
	end
	local count = player:GetAttribute("CollectionCount")
	if not dexStore or not count or count <= 0 or dexWritten[player] == count or not PlayerData.isPersistent(player) then
		return
	end
	dexWritten[player] = count
	local ok, err = pcall(function()
		dexStore:SetAsync(tostring(player.UserId), count)
	end)
	if not ok then
		dexWritten[player] = nil
		warn("[Leaderboards] 도감 기록 저장 실패: " .. tostring(err))
	end
end

local function nameOf(userId)
	if names[userId] then
		return names[userId]
	end
	local online = Players:GetPlayerByUserId(userId)
	if online then
		names[userId] = online.DisplayName
		return names[userId]
	end
	local ok, name = pcall(function()
		return Players:GetNameFromUserIdAsync(userId)
	end)
	names[userId] = ok and name or ("#" .. userId)
	return names[userId]
end

-- ---------------------------------------------------------------------------
-- ♾️ 무한 도전: the weekly ranking
-- ---------------------------------------------------------------------------

local function challengeStore(week)
	if challengeStores[week] == nil then
		local ok, s = pcall(function()
			return DataStoreService:GetOrderedDataStore(Config.Defense.Challenge.StoreName .. "_" .. week)
		end)
		challengeStores[week] = ok and s or false
	end
	return challengeStores[week] or nil
end

-- the player's best of their profile's week, when it changed since the last write (yields)
local function writeChallenge(player)
	if hidden(player) then
		return -- (a developer: never ranked)
	end
	if TutorialField.isField() or PlayerData.isPractice(player) then
		return -- (2026-10-03: a tutorial field's practice save is never ranked)
	end
	local profile = PlayerData.get(player)
	local c = profile and profile.Challenge
	if not c or c.Best <= 0 or not PlayerData.isPersistent(player) then
		return
	end
	local tag = c.Week .. ":" .. c.Best
	local s = challengeStore(c.Week)
	if challengeWritten[player] == tag or not s then
		return
	end
	challengeWritten[player] = tag
	local best = c.Best
	local ok, err = pcall(function()
		s:SetAsync(tostring(player.UserId), best)
	end)
	if not ok then
		challengeWritten[player] = nil -- tried again on the next pass
		warn("[Leaderboards] 무한 도전 기록 저장 실패: " .. tostring(err))
	end
end

-- the Defense service: this week's best grew
function Leaderboards.challengeBest(player)
	task.spawn(writeChallenge, player)
end

-- the collection's top: ReplicatedStorage attribute DexTop
local function readDex()
	if not dexStore then
		return
	end
	local ok, pages = pcall(function()
		return dexStore:GetSortedAsync(false, readCount(Config.Leaderboard.Top))
	end)
	if not ok then
		return
	end
	local list = {}
	for _, entry in ipairs(pages:GetCurrentPage()) do
		local userId = tonumber(entry.key)
		if shown(userId) and entry.value > 0 and #list < Config.Leaderboard.Top then
			table.insert(list, { Name = nameOf(userId), Count = entry.value })
		end
	end
	ReplicatedStorage:SetAttribute("DexTop", HttpService:JSONEncode(list))
end

-- this week's top: ReplicatedStorage attribute ChallengeTop
local function readChallenge()
	local s = challengeStore(RewardLogic.weekNumber(os.time()))
	if not s then
		return
	end
	local ok, pages = pcall(function()
		return s:GetSortedAsync(false, readCount(Config.Defense.Challenge.Top))
	end)
	if not ok then
		return
	end
	local list = {}
	for _, entry in ipairs(pages:GetCurrentPage()) do
		local userId = tonumber(entry.key)
		if shown(userId) and entry.value > 0 and #list < Config.Defense.Challenge.Top then
			table.insert(list, { Name = nameOf(userId), Waves = entry.value })
		end
	end
	ReplicatedStorage:SetAttribute("ChallengeTop", HttpService:JSONEncode(list))
end

-- a finished week's ranks ({ [userId] = rank }), nil until it can be read
local function ranksOf(week)
	if lastRanks[week] then
		return lastRanks[week]
	end
	if os.time() - RewardLogic.weekStart(week + 1) < RANK_SETTLE then
		return nil
	end
	local s = challengeStore(week)
	if not s then
		return nil
	end
	local ok, pages = pcall(function()
		return s:GetSortedAsync(false, Config.Defense.Challenge.RankRead)
	end)
	if not ok then
		return nil
	end
	local ranks = {}
	local rank = 0 -- (a developer left out moves the ones after up)
	for _, entry in ipairs(pages:GetCurrentPage()) do
		local userId = tonumber(entry.key)
		if shown(userId) then
			rank += 1
			ranks[userId] = rank
		end
	end
	lastRanks[week] = ranks
	return ranks
end

-- a played week's reward: its rank's row, or the play reward past them (rank nil: not in the read list);
-- also TestCommands ;weekprize
function Leaderboards.giveRankReward(player, rank)
	local reward, ranked = RewardLogic.challengeRankReward(rank)
	Rewards.grant(player, reward, ranked and string.format("♾️ 지난주 무한 도전 %d위!", rank)
		or "♾️ 지난주 무한 도전 참가 선물!")
end

-- last week's rank reward for everyone here who played it and was not paid yet
local function payRanks()
	local week = RewardLogic.weekNumber(os.time())
	for _, player in ipairs(Players:GetPlayers()) do
		if PlayerData.isLoaded(player) and PlayerData.isPersistent(player) then
			writeChallenge(player) -- (last week's best goes in before the profile turns to the new week)
			local due = nil
			PlayerData.update(player, function(p)
				due = RewardLogic.challengeRankDue(p, week)
			end)
			local ranks = due and ranksOf(due)
			if ranks and player.Parent then
				PlayerData.update(player, function(p)
					p.Challenge.RankPaid = due
				end)
				Leaderboards.giveRankReward(player, ranks[player.UserId])
			end
		end
	end
end

-- ---------------------------------------------------------------------------
-- 🏆 랭킹전 (2026-10-04): each game's weekly ranking by counted ranked wins
-- ---------------------------------------------------------------------------

local function rankedStore(game, week)
	local key = game .. ":" .. week
	if rankedStores[key] == nil then
		local ok, s = pcall(function()
			return DataStoreService:GetOrderedDataStore(Config.Ranked.StoreName .. "_" .. game .. "_" .. week)
		end)
		rankedStores[key] = ok and s or false
	end
	return rankedStores[key] or nil
end

-- the player's counted wins in that game, of their profile's week, when they changed since the last write (yields)
local function writeRanked(player, game)
	if hidden(player) then
		return -- (a developer: never ranked)
	end
	if TutorialField.isField() or PlayerData.isPractice(player) then
		return
	end
	local profile = PlayerData.get(player)
	local r = profile and profile.Ranked
	if not r or (r[game] or 0) <= 0 or not PlayerData.isPersistent(player) then
		return
	end
	local tag = r.Week .. ":" .. r[game]
	local s = rankedStore(game, r.Week)
	local done = rankedWritten[player] or {}
	rankedWritten[player] = done
	if done[game] == tag or not s then
		return
	end
	done[game] = tag
	local wins = r[game]
	local ok, err = pcall(function()
		s:SetAsync(tostring(player.UserId), wins)
	end)
	if not ok then
		done[game] = nil -- tried again on the next pass
		warn("[Leaderboards] 랭킹전 기록 저장 실패: " .. tostring(err))
	end
end

-- a counted ranked win (HideSeek, Race services): written at once
function Leaderboards.rankedWin(player, game)
	task.spawn(writeRanked, player, game)
end

-- this week's top of each game: ReplicatedStorage attributes HideWeekTop / RaceWeekTop
local function readRanked()
	local week = RewardLogic.weekNumber(os.time())
	for _, game in ipairs(Config.Ranked.Games) do
		local s = rankedStore(game, week)
		local ok, pages = false, nil
		if s then
			ok, pages = pcall(function()
				return s:GetSortedAsync(false, readCount(Config.Ranked.Top))
			end)
		end
		if ok then
			local list = {}
			for _, entry in ipairs(pages:GetCurrentPage()) do
				local userId = tonumber(entry.key)
				if shown(userId) and entry.value > 0 and #list < Config.Ranked.Top then
					table.insert(list, { Name = nameOf(userId), Wins = entry.value })
				end
			end
			ReplicatedStorage:SetAttribute(game .. "WeekTop", HttpService:JSONEncode(list))
		end
	end
end

-- a finished week's ranks in that game ({ [userId] = rank }), nil until it can be read
local function rankedRanksOf(game, week)
	local key = game .. ":" .. week
	if rankedRanks[key] then
		return rankedRanks[key]
	end
	if os.time() - RewardLogic.weekStart(week + 1) < RANK_SETTLE then
		return nil
	end
	local s = rankedStore(game, week)
	if not s then
		return nil
	end
	local ok, pages = pcall(function()
		return s:GetSortedAsync(false, Config.Ranked.RankRead)
	end)
	if not ok then
		return nil
	end
	local ranks = {}
	local rank = 0 -- (a developer left out moves the ones after up)
	for _, entry in ipairs(pages:GetCurrentPage()) do
		local userId = tonumber(entry.key)
		if shown(userId) then
			rank += 1
			ranks[userId] = rank
		end
	end
	rankedRanks[key] = ranks
	return ranks
end

-- a finished week's reward in that game: its rank's row, or the play reward past them (rank nil);
-- also TestCommands ;rankprize
function Leaderboards.giveRankedReward(player, game, rank)
	local reward, isRank = RewardLogic.rankedReward(rank)
	local titles = RANKED_TITLES[game] or RANKED_TITLES.Race
	Rewards.grant(player, reward, isRank and string.format(titles[1], rank) or titles[2])
end

-- last week's ranked rewards for everyone here who had a counted win in it and was not paid yet
local function payRanked()
	local week = RewardLogic.weekNumber(os.time())
	for _, player in ipairs(Players:GetPlayers()) do
		if PlayerData.isLoaded(player) and PlayerData.isPersistent(player) then
			for _, game in ipairs(Config.Ranked.Games) do
				writeRanked(player, game) -- (last week's wins go in before the profile turns to the new week)
			end
			for _, game in ipairs(Config.Ranked.Games) do
				local due = nil
				PlayerData.update(player, function(p)
					due = RewardLogic.rankedDue(p, week, game)
				end)
				local ranks = due and rankedRanksOf(game, due)
				if ranks and player.Parent then
					PlayerData.update(player, function(p)
						p.Ranked["Paid" .. game] = due
					end)
					Leaderboards.giveRankedReward(player, game, ranks[player.UserId])
				end
			end
		end
	end
end

-- (2026-10-02) a new personal best race time (Race service): written to that kind's store at once
function Leaderboards.raceTime(player, kind, seconds)
	if hidden(player) then
		return -- (a developer: never ranked)
	end
	if TutorialField.isField() or PlayerData.isPractice(player) then
		return -- (2026-10-03: a tutorial field's practice save is never ranked)
	end
	local s = raceStores[kind]
	if not s or not PlayerData.isPersistent(player) then
		return
	end
	task.spawn(function()
		local ok, err = pcall(function()
			s:SetAsync(tostring(player.UserId), math.floor(seconds * 100 + 0.5))
		end)
		if not ok then
			warn("[Leaderboards] 레이스 기록 저장 실패: " .. tostring(err))
		end
	end)
end

-- (2026-10-03) this player's hide-and-seek wins now (HideSeek service; 0 from the record reset product)
function Leaderboards.hideSeekWins(player, wins)
	if hidden(player) then
		return -- (a developer: never ranked)
	end
	if TutorialField.isField() or not hideStore or not PlayerData.isPersistent(player) or PlayerData.isPractice(player) then
		return
	end
	task.spawn(function()
		local ok, err = pcall(function()
			if wins > 0 then
				hideStore:SetAsync(tostring(player.UserId), wins)
			else
				hideStore:RemoveAsync(tostring(player.UserId))
			end
		end)
		if not ok then
			warn("[Leaderboards] 숨바꼭질 기록 저장 실패: " .. tostring(err))
		end
	end)
end

-- the hide-and-seek wins of all servers: ReplicatedStorage attribute HideSeekTop
local function readHideSeek()
	if not hideStore then
		return
	end
	local ok, pages = pcall(function()
		return hideStore:GetSortedAsync(false, readCount(Config.Leaderboard.Top))
	end)
	if not ok then
		return
	end
	local list = {}
	for _, entry in ipairs(pages:GetCurrentPage()) do
		local userId = tonumber(entry.key)
		if shown(userId) and entry.value > 0 and #list < Config.Leaderboard.Top then
			table.insert(list, { Name = nameOf(userId), Wins = entry.value })
		end
	end
	ReplicatedStorage:SetAttribute("HideSeekTop", HttpService:JSONEncode(list))
end

-- the best race times of all servers: ReplicatedStorage attributes RaceTopRoad / RaceTopSky (JSON: a list of
-- { Name, Seconds }, the fastest first)
local function readRaces()
	for kind, s in pairs(raceStores) do
		local ok, pages = pcall(function()
			return s:GetSortedAsync(true, readCount(Config.Leaderboard.RaceTop))
		end)
		if ok then
			local list = {}
			for _, entry in ipairs(pages:GetCurrentPage()) do
				local userId = tonumber(entry.key)
				if shown(userId) and entry.value > 0 and #list < Config.Leaderboard.RaceTop then
					table.insert(list, { Name = nameOf(userId), Seconds = entry.value / 100 })
				end
			end
			ReplicatedStorage:SetAttribute("RaceTop" .. kind, HttpService:JSONEncode(list))
		end
	end
end

local function read()
	local ok, pages = pcall(function()
		return store:GetSortedAsync(false, readCount(Config.Leaderboard.Top))
	end)
	if not ok then
		warn("[Leaderboards] 순위 읽기 실패: " .. tostring(pages))
		return
	end
	local list = {}
	for _, entry in ipairs(pages:GetCurrentPage()) do
		local userId = tonumber(entry.key)
		if shown(userId) and #list < Config.Leaderboard.Top then
			table.insert(list, { Name = nameOf(userId), Level = entry.value })
		end
	end
	ReplicatedStorage:SetAttribute("GlobalRanking", HttpService:JSONEncode(list))
end

function Leaderboards.init()
	local ok, result = pcall(function()
		return DataStoreService:GetOrderedDataStore(Config.Leaderboard.StoreName)
	end)
	store = ok and result or nil
	ReplicatedStorage:SetAttribute("GlobalRanking", "[]")
	ReplicatedStorage:SetAttribute("ChallengeTop", "[]")
	ReplicatedStorage:SetAttribute("DexTop", "[]")
	local okDex, dex = pcall(function()
		return DataStoreService:GetOrderedDataStore(Config.Collection.StoreName)
	end)
	dexStore = okDex and dex or nil
	ReplicatedStorage:SetAttribute("HideSeekTop", "[]")
	for _, game in ipairs(Config.Ranked.Games) do -- (2026-10-04) this week's 🏆 랭킹전 tops
		ReplicatedStorage:SetAttribute(game .. "WeekTop", "[]")
	end
	local okHide, hide = pcall(function()
		return DataStoreService:GetOrderedDataStore(Config.Leaderboard.HideSeekStoreName)
	end)
	hideStore = okHide and hide or nil
	task.spawn(function() -- (when this week's ranking ends, for the ♾️ window; needs no DataStore)
		while true do
			local week = RewardLogic.weekNumber(os.time())
			ReplicatedStorage:SetAttribute("ChallengeWeekEnds", RewardLogic.weekStart(week + 1))
			ReplicatedStorage:SetAttribute("ChallengeRule", Formulas.challengeRule(week).Id) -- (this week's rule, for the window)
			task.wait(WEEK_EVERY)
		end
	end)
	for _, kind in ipairs({ "Road", "Sky" }) do
		ReplicatedStorage:SetAttribute("RaceTop" .. kind, "[]")
		local okRace, raceStore = pcall(function()
			return DataStoreService:GetOrderedDataStore(Config.Leaderboard.RaceStoreName .. "_" .. kind)
		end)
		raceStores[kind] = okRace and raceStore or nil
	end
	-- (2026-10-04) the developers: marked (player attribute Developer: the screens leave them out of this server's lists
	-- too), their UserIds for the reads, and taken off every ranking when they come in
	task.spawn(function()
		for _, name in ipairs(Config.Developers.Names) do
			local ok, id = pcall(function()
				return Players:GetUserIdFromNameAsync(name)
			end)
			if ok and id then
				hiddenIds[id] = true
			end
		end
		idsReady = true
	end)
	local function offRankings(player)
		if not hidden(player) then
			return
		end
		hiddenIds[player.UserId] = true
		player:SetAttribute("Developer", true)
		if TutorialField.isField() then
			return
		end
		local key = tostring(player.UserId)
		local week = RewardLogic.weekNumber(os.time())
		local stores = {}
		for _, s in ipairs({ store or false, dexStore or false, hideStore or false, raceStores.Road or false,
			raceStores.Sky or false, challengeStore(week) or false }) do
			table.insert(stores, s)
		end
		for _, game in ipairs(Config.Ranked.Games) do
			table.insert(stores, rankedStore(game, week) or false)
		end
		for _, s in ipairs(stores) do
			if s then
				pcall(function()
					s:RemoveAsync(key)
				end)
			end
		end
		-- the lists already up (read before they came in) are read again without them
		if store then
			read()
		end
		readRaces()
		readChallenge()
		readDex()
		readHideSeek()
		readRanked()
	end
	Players.PlayerAdded:Connect(offRankings)
	for _, player in ipairs(Players:GetPlayers()) do
		task.spawn(offRankings, player)
	end
	if not store then
		warn("[Leaderboards] 전 서버 순위를 쓸 수 없어요 (DataStore 없음)")
		return
	end
	PlayerData.onChanged(function(player)
		write(player, false)
	end)
	Players.PlayerRemoving:Connect(function(player)
		write(player, true)
		written[player] = nil
		writeChallenge(player)
		challengeWritten[player] = nil
		writeDex(player)
		dexWritten[player] = nil
		for _, game in ipairs(Config.Ranked.Games) do
			writeRanked(player, game)
		end
		rankedWritten[player] = nil
	end)
	task.spawn(function()
		local waited = os.clock()
		while not idsReady and os.clock() - waited < ID_WAIT do -- (the developers left out from the first read on)
			task.wait(0.5)
		end
		while true do
			for _, player in ipairs(Players:GetPlayers()) do
				write(player, true)
				writeDex(player)
			end
			read()
			readRaces()
			payRanks()
			payRanked()
			readChallenge()
			readDex()
			readHideSeek()
			readRanked()
			task.wait(Config.Leaderboard.ReadSeconds)
		end
	end)
end

return Leaderboards
