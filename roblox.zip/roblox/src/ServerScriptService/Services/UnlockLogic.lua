local Config = if game
	then require(game:GetService("ReplicatedStorage"):WaitForChild("Config"))
	else CONFIG
local Formulas = if game
	then require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Formulas"))
	else LOAD("ReplicatedStorage/Shared/Formulas")

local UnlockLogic = {}

local function openOf(unlocks)
	return type(unlocks) == "table" and unlocks.Open or nil
end

function UnlockLogic.chapter(starter)
	if type(starter) ~= "table" then
		return 1
	end
	if starter.Extra and starter.Extra[1] then
		for _, m in ipairs(Config.StarterMissions.Missions) do
			if (m.Goal or m.Event) == starter.Extra[1] then
				return m.Ch or 1
			end
		end
	end
	if starter.Done then
		return math.huge
	end
	local m = Config.StarterMissions.Missions[starter.Step or 1]
	return m and (m.Ch or 1) or math.huge
end

function UnlockLogic.state(unlocks, id, level, passes, chapter)
	return Formulas.unlockState(id, level, passes, openOf(unlocks), chapter)
end

function UnlockLogic.need(unlocks, id, level, passes, chapter)
	local u = Formulas.unlockOf(id)
	if not u or UnlockLogic.state(unlocks, id, level, passes, chapter) ~= "Locked" then
		return nil
	end
	return Formulas.unlockNeed(u, level, passes, openOf(unlocks), chapter)
end

function UnlockLogic.start(unlocks, id, level, passes, chapter)
	if UnlockLogic.state(unlocks, id, level, passes, chapter) ~= "Ready" then
		return false
	end
	unlocks.Open[id] = { Step = 1, Count = 0 }
	return true
end

function UnlockLogic.current(unlocks)
	for _, u in ipairs(Config.Unlocks) do
		local o = unlocks.Open[u.Id]
		if type(o) == "table" then
			return u, o.Step, o.Count or 0
		end
	end
	return nil
end

function UnlockLogic.firstReady(unlocks, level, passes, chapter)
	for _, u in ipairs(Config.Unlocks) do
		if UnlockLogic.state(unlocks, u.Id, level, passes, chapter) == "Ready" then
			return u
		end
	end
	return nil
end

function UnlockLogic.wants(unlocks, kind)
	local u, step = UnlockLogic.current(unlocks)
	local m = u and u.Steps[step]
	return m ~= nil and m.Event == kind
end

function UnlockLogic.event(unlocks, kind, amount)
	local changed = {}
	if (amount or 0) <= 0 then
		return changed
	end
	for _, u in ipairs(Config.Unlocks) do
		local o = unlocks.Open[u.Id]
		local step = type(o) == "table" and u.Steps[o.Step] or nil
		if step and step.Event == kind then
			o.Count = math.min(step.Target, (o.Count or 0) + amount)
			if o.Count < step.Target then
				table.insert(changed, { Id = u.Id, Step = o.Step })
			elseif o.Step >= #u.Steps then
				unlocks.Open[u.Id] = true
				table.insert(changed, { Id = u.Id, Step = o.Step, StepDone = true, Done = true })
			else
				o.Step += 1
				o.Count = 0
				table.insert(changed, { Id = u.Id, Step = o.Step - 1, StepDone = true })
			end
		end
	end
	return changed
end

function UnlockLogic.openAll(unlocks)
	for _, u in ipairs(Config.Unlocks) do
		unlocks.Open[u.Id] = true
	end
end

function UnlockLogic.graduate(unlocks)
	for _, u in ipairs(Config.Unlocks) do
		if not u.Level then
			unlocks.Open[u.Id] = true
		end
	end
end

function UnlockLogic.openFrom(unlocks)
	return Formulas.fieldOpenFrom(openOf(unlocks))
end

return UnlockLogic
