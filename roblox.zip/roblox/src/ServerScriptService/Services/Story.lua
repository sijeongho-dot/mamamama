local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))

local Story = {}

local function line(id, ...)
	local text = Config.Story.Lines[id]
	if text and select("#", ...) > 0 then
		return string.format(text, ...)
	end
	return text
end

function Story.explain(id, ...)
	local text = Config.Story.Explains[id]
	if text and select("#", ...) > 0 then
		return string.format(text, ...)
	end
	return text
end

function Story.show(player, id, text, n, explain)
	if Config.Story.Shows[id] then
		Net.push(player, "WitchShow", id, text, n, explain)
	end
end

function Story.showAll(id, explain)
	for _, player in ipairs(Players:GetPlayers()) do
		if PlayerData.isLoaded(player) then
			Story.show(player, id, nil, nil, explain)
		end
	end
end

function Story.sayFirst(player, id, otherwise, explain, ...)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	if (profile.StorySeen or {})[id] then
		Story.show(player, otherwise, line(otherwise, ...), nil, explain)
		return
	end
	PlayerData.update(player, function(p)
		p.StorySeen = p.StorySeen or {}
		p.StorySeen[id] = true
	end)
	Story.show(player, id, line(id, ...), nil, explain)
end

function Story.firstWin(player)
	Story.show(player, "FirstWin", nil, nil, Story.explain("FirstWin"))
end

function Story.rebirth(player, n)
	local text = Config.Story.Rebirths[n]
	local profile = PlayerData.get(player)
	if not text or not profile then
		return
	end
	Story.show(player, "Rebirth", text, n, Story.explain("Rebirth", #Formulas.speciesOpenedBy(n),
		math.max(Formulas.dexSpeciesTotal() - Formulas.dexSpecies(profile), 0)))
end

function Story.init() end

return Story
