--[[
Farm: the farm and the collection (design 2.8 농장 등록).

- Net request RegisterFarm(unitId) puts one of the player's dinos on the farm (not a placed one,
  at most Formulas.farmSlots(profile)); UnregisterFarm(unitId) takes it back. Farm dinos cannot be placed.
  Each gives its theme's buff for good while it is there (Formulas.farmBuff); the defense, the
  deposit, mining and draws read them through Formulas.bonuses.
- The collection: every species × rarity the player ever owned (profile.Collection, filled by
  Gacha, TestCommands and rebirth dinos; old saves are filled from their dinos when loaded). Its
  steps give the Config.Farm.CollectionRewards; a theme with every species collected unlocks its
  slap skin, and so do collection counts (Formulas.newSkins, Config.Slap.Skins: profile.Skins[Id], a notice once).
- The farm dinos stand in the player's own pen (Base_FarmPen, folder FarmUnits under the base); the
  clients walk them round the pen to the grass and let them graze (DefenseView). Grass clumps grow here
  and there in every pen (folder FarmGrass under the base: Prop_Grass_A/B/C from ServerStorage.Assets,
  or little part tufts without them); FarmGrass attributes PenCFrame and PenSize are the pen's inside.
- Player attributes for the screens: FarmCount, FarmSlots, CollectionCount, Bonus<UnitPower, Money,
  MonsterSlow, RareChance, Mining, Slots> (fractions; the draw screen multiplies its luck by
  1 + BonusRareChance like the server does).
- Net ask GetCollection: the 도감 window's data (collection keys, skins, bonuses).
- (2026-10-02) Config.Collection: the collection milestones and rarity rows reached pay once (Formulas.collectionDue,
  profile.CollectionPaid), all of one change in one notice; a new title is told to the server. Player attributes
  DexTitle (the best title reached, nil before the first; over the head with CollectionCount: StarterPlayerScripts/Race).
- Farm slots: Config.Farm.StartSlots (1) + the ones bought one at a time with game money from the
  "농장 칸 늘리기" prompt on the base's FarmSign (Formulas.nextFarmSlotCost; profile.Upgrades.FarmSlots).
  The sign shows the owner's slots and the next price. Saves from when the farm started with 20 slots
  keep the dinos already there: their bought slots are raised to fit them.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local Defense = require(script.Parent:WaitForChild("Defense"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local Story = require(script.Parent:WaitForChild("Story"))

local Farm = {}

-- display only
local PEN_INSET = 0.18 -- keep the dinos this share of the pen away from its fence
local PEN_COLUMNS = 5
local TITLE_COLOR = Color3.fromRGB(150, 230, 120)
local TITLE_HEIGHT = 28 -- studs over the pen for its name
local BONUS_NAMES = { "UnitPower", "Money", "MonsterSlow", "RareChance", "Mining", "Slots" }
local SIGN_PIXELS_PER_STUD = 50
local SIGN_SLACK = 4 -- studs of leeway on the prompt distance (lag)
local TITLE_SLOT_COLOR = Color3.fromRGB(150, 230, 150)
-- the label over each farm dino: what it gives (2026-10-01, "show over the farm dinos what they give")
local BUFF_LOOKS = { -- [buff] = { emoji, color }
	UnitPower = { "💪", Color3.fromRGB(255, 120, 100) },
	Money = { "💰", Color3.fromRGB(255, 215, 80) },
	MonsterSlow = { "🐢", Color3.fromRGB(120, 200, 255) },
	RareChance = { "🍀", Color3.fromRGB(130, 235, 130) },
	Mining = { "⛏️", Color3.fromRGB(220, 180, 120) },
}
local BUFF_OFF_GRAY = Color3.fromRGB(150, 150, 150)
local BUFF_OFF_FADE = 0.6
local BUFF_ORDER = { "UnitPower", "Money", "MonsterSlow", "RareChance", "Mining" }
local BUFF_THEME = {}
local BUFF_EXAMPLES = {}
for _, theme in ipairs(Config.Themes) do
	if theme.FarmBuff and theme.Attack ~= "BaseTheme" and not BUFF_THEME[theme.FarmBuff] then
		BUFF_THEME[theme.FarmBuff] = (theme.Icon and theme.Icon .. " " or "") .. theme.Name
		local names = {}
		for _, s in ipairs(Config.Species) do
			if s.Theme == theme.Id and not s.UnlockRebirths and not s.MinKey then
				table.insert(names, s.Name)
			end
		end
		table.sort(names, function(a, b)
			return utf8.len(a) < utf8.len(b) or (utf8.len(a) == utf8.len(b) and a < b)
		end)
		BUFF_EXAMPLES[theme.FarmBuff] = table.concat({ names[1], names[2] }, "·")
	end
end
local BUFF_LABEL_SIZE = UDim2.fromOffset(150, 30)
local BUFF_LABEL_ABOVE = 1.5 -- studs over the dino's top
local BUFF_LABEL_DISTANCE = 90 -- seen from this close (the pen stays tidy from afar)
-- the board beside the farm sign: every lasting bonus the owner gets now, and the farm's share of it
-- (2026-10-01, "a sign at the farm showing all the effects coming in")
local TOTALS_SIZE = Vector3.new(11, 8, 0.4)
local TOTALS_BOTTOM = 1.2 -- studs over the ground
local TOTALS_POST = Vector3.new(0.5, 9, 0.5)
local TOTALS_GAP = 3 -- studs between the farm placing board and this one
local PLACE_BOARD_ROOM = 1.5 + 8 -- the farm placing board beside the sign: its gap and width (PlaceBoards SIDE_GAP, BOARD_SIZE.X)
local TOTALS_PIXELS_PER_STUD = 40
local TOTALS_COLOR = Color3.fromRGB(45, 70, 45)
local TOTALS_POST_COLOR = Color3.fromRGB(110, 80, 55)
local TOTALS_TITLE_COLOR = Color3.fromRGB(150, 230, 120)
local totals = {} -- [base number] = the board's TextLabels: { title, lines... }

local signs = {} -- [base number] = the TextLabel on its farm sign
local GRASS_COUNT = 9 -- clumps in each pen
local GRASS_SCALE = { 1.8, 2.6 }
local GRASS_MODELS = { "Prop_Grass_A", "Prop_Grass_B", "Prop_Grass_C" }
local TUFT_COLORS = { Color3.fromRGB(93, 178, 74), Color3.fromRGB(134, 207, 94) }

local pens = {} -- [base number] = { signature }

local function say(player, text)
	Net.push(player, "Notice", "🌾 농장", text)
end

local function unitsById(profile)
	local byId = {}
	for _, u in ipairs(profile.Units) do
		byId[u.Id] = u
	end
	return byId
end

-- ---------------------------------------------------------------------------
-- The pen
-- ---------------------------------------------------------------------------

local function groundAt(position, ignore)
	local params = RaycastParams.new()
	params.FilterDescendantsInstances = ignore
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true
	local hit = Workspace:Raycast(position + Vector3.new(0, 50, 0), Vector3.new(0, -200, 0), params)
	return hit and hit.Position.Y or position.Y
end

-- grass clumps here and there in a pen (see the top), and the pen's inside for the clients
local function plantGrass(folder, pen)
	local old = folder:FindFirstChild("FarmGrass")
	if old then
		old:Destroy()
	end
	local grass = Instance.new("Folder")
	grass.Name = "FarmGrass"
	local cf, size = pen:GetBoundingBox()
	local inner = Vector3.new(size.X * (1 - 2 * PEN_INSET), 0, size.Z * (1 - 2 * PEN_INSET))
	grass:SetAttribute("PenCFrame", cf)
	grass:SetAttribute("PenSize", inner)
	local assets = game:GetService("ServerStorage"):FindFirstChild("Assets")
	local rng = Random.new(folder.Name:len() * 7919 + (folder:GetAttribute("BaseIndex") or 0))
	for k = 1, GRASS_COUNT do
		local inside = Vector3.new(rng:NextNumber(-0.5, 0.5) * inner.X, 0, rng:NextNumber(-0.5, 0.5) * inner.Z)
		local spot = cf:PointToWorldSpace(inside)
		spot = Vector3.new(spot.X, groundAt(spot, { grass }), spot.Z)
		local source = assets and assets:FindFirstChild(GRASS_MODELS[(k - 1) % #GRASS_MODELS + 1], true)
		local clump
		if source then
			clump = source:Clone()
			if clump:IsA("BasePart") then
				local m = Instance.new("Model")
				clump.Parent = m
				clump = m
			end
			for _, d in ipairs(clump:GetDescendants()) do
				if d:IsA("BasePart") then
					d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
				end
			end
			local bcf, bsize = clump:GetBoundingBox()
			clump.WorldPivot = CFrame.new(bcf.Position - Vector3.new(0, bsize.Y / 2, 0))
			clump:ScaleTo(rng:NextNumber(GRASS_SCALE[1], GRASS_SCALE[2]))
		else -- a few green blades
			clump = Instance.new("Model")
			for b = 1, 4 do
				local blade = Instance.new("Part")
				blade.Size = Vector3.new(0.4, rng:NextNumber(1.6, 2.6), 0.4)
				blade.Anchored, blade.CanCollide, blade.CanQuery, blade.CanTouch = true, false, false, false
				blade.Color = TUFT_COLORS[b % 2 + 1]
				blade.CFrame = CFrame.new(math.cos(b * 1.6) * 0.4, blade.Size.Y / 2, math.sin(b * 1.6) * 0.4)
					* CFrame.Angles(math.cos(b) * 0.3, 0, math.sin(b) * 0.3)
				blade.Parent = clump
			end
			clump.WorldPivot = CFrame.new()
		end
		clump.Name = "Grass"
		clump:PivotTo(CFrame.new(spot) * CFrame.Angles(0, rng:NextNumber(0, 2 * math.pi), 0))
		clump.Parent = grass
	end
	grass.Parent = folder
end

local function refreshPen(player, profile)
	local index = Bases.of(player)
	local folder = index and Bases.folder(index)
	local pen = folder and folder:FindFirstChild("Base_FarmPen", true)
	if not pen then
		return
	end
	local list = folder:FindFirstChild("FarmUnits")
	if not list then
		list = Instance.new("Folder")
		list.Name = "FarmUnits"
		list.Parent = folder
	end
	local ids = {}
	local byId = unitsById(profile)
	for id in pairs(profile.Farm) do
		if byId[id] then
			table.insert(ids, id)
		end
	end
	table.sort(ids)
	local parts = {}
	for _, id in ipairs(ids) do
		local u = byId[id]
		table.insert(parts, id .. u.Species .. u.Rarity .. u.Size)
	end
	local signature = player.UserId .. ":" .. table.concat(parts, "|")
	if pens[index] == signature then
		return
	end
	pens[index] = signature
	list:ClearAllChildren()

	local cf, size = pen:GetBoundingBox()
	local rows = math.max(1, math.ceil(Formulas.farmSlots(profile) / PEN_COLUMNS))
	local width, depth = size.X * (1 - 2 * PEN_INSET), size.Z * (1 - 2 * PEN_INSET)
	local ignore = { list }
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	for i, id in ipairs(ids) do
		local unit = byId[id]
		local stats = Formulas.unitStats(unit)
		local model = Defense.unitModel(unit, stats)
		local column, row = (i - 1) % PEN_COLUMNS, (i - 1) // PEN_COLUMNS
		local x = -width / 2 + width * (column + 0.5) / PEN_COLUMNS
		local z = -depth / 2 + depth * (row + 0.5) / rows
		local spot = cf:PointToWorldSpace(Vector3.new(x, 0, z))
		spot = Vector3.new(spot.X, groundAt(spot, ignore), spot.Z)
		local yaw = math.rad((i * 137) % 360) -- each one looks a different way
		local rest = CFrame.new(spot) * CFrame.Angles(0, yaw, 0)
		model:PivotTo(rest)
		model:SetAttribute("Rest", rest) -- clients animate around this (DefenseView)
		-- what it gives, over its head (follows it as it wanders: on its own part)
		local buff, amount = Formulas.farmBuff(unit)
		local look = BUFF_LOOKS[buff]
		local anchorPart = model.PrimaryPart or model:FindFirstChildWhichIsA("BasePart", true)
		if look and anchorPart then
			local _, box = model:GetBoundingBox()
			local tag = Instance.new("BillboardGui")
			tag.Name = "FarmBuff"
			tag.Size = BUFF_LABEL_SIZE
			tag.StudsOffsetWorldSpace = Vector3.new(0, rest.Position.Y + box.Y - anchorPart.Position.Y + BUFF_LABEL_ABOVE, 0)
			tag.MaxDistance = BUFF_LABEL_DISTANCE
			tag.AlwaysOnTop = false
			tag.Adornee = anchorPart
			local text = Instance.new("TextLabel")
			text.Size = UDim2.fromScale(1, 1)
			text.BackgroundTransparency = 1
			text.Font = Enum.Font.GothamBold
			text.TextScaled = true
			text.TextColor3 = look[2]
			text.TextStrokeTransparency = 0.2
			local percent = amount * 100
			text.Text = string.format(percent < 10 and "%s %s +%.1f%%" or "%s %s +%.0f%%", look[1],
				Config.Farm.BuffNames[buff] or buff, percent)
			text.Parent = tag
			tag.Parent = anchorPart
		end
		model.Parent = list
	end
end

local function clearPen(index)
	local folder = Bases.folder(index)
	local list = folder and folder:FindFirstChild("FarmUnits")
	if list then
		list:ClearAllChildren()
	end
	pens[index] = nil
end

-- ---------------------------------------------------------------------------
-- Bonuses, collection and skins
-- ---------------------------------------------------------------------------

-- the farm sign of this base: the owner's slots and the next price
-- (each farm bonus's cap: Formulas.farmCaps(profile); money and mining since 2026-10-02, higher with the pass)
local CAP_EPSILON = 1e-6

-- the farm's own share of each bonus (its dinos, capped like Formulas.bonuses)
local function farmShare(profile)
	local share = { UnitPower = 0, Money = 0, MonsterSlow = 0, RareChance = 0, Mining = 0 }
	local byId = {}
	for _, u in ipairs(profile.Units or {}) do
		byId[u.Id] = u
	end
	for id in pairs(profile.Farm or {}) do
		local u = byId[id]
		if u and Formulas.species(u.Species) then
			local kind, amount = Formulas.farmBuff(u)
			share[kind] = (share[kind] or 0) + amount
		end
	end
	for kind, cap in pairs(Formulas.farmCaps(profile)) do
		share[kind] = math.min(share[kind], cap)
	end
	return share
end

local function percent(x)
	local p = x * 100
	return p < 10 and string.format("%.1f%%", p) or string.format("%.0f%%", p)
end

-- the totals board of this base: the owner's bonuses now (farm, collection and rebirth together)
local function refreshTotals(index, profile)
	local t = totals[index]
	if not t then
		return
	end
	if not profile then
		t[1].Text = "🌿 농장 효과"
		for i = 2, #t do
			t[i].Text = i == 2 and "주인이 없어요" or ""
		end
		return
	end
	local b = Formulas.bonuses(profile)
	local share = farmShare(profile)
	local caps = Formulas.farmCaps(profile)
	t[1].Text = string.format("🌿 지금 받는 효과 · 농장 %d/%d마리", Formulas.farmCount(profile), Formulas.farmSlots(profile))
	local rank = {}
	for i, kind in ipairs(BUFF_ORDER) do
		rank[kind] = i
	end
	local order = table.clone(BUFF_ORDER)
	table.sort(order, function(x, y)
		local on = b[x] > CAP_EPSILON
		if on ~= (b[y] > CAP_EPSILON) then
			return on
		end
		return rank[x] < rank[y]
	end)
	for i, kind in ipairs(order) do
		local look = BUFF_LOOKS[kind]
		local line = t[i + 1]
		if b[kind] <= CAP_EPSILON then
			line.TextColor3 = look[2]:Lerp(BUFF_OFF_GRAY, BUFF_OFF_FADE)
			line.Text = string.format("%s %s: %s 공룡(%s 등)을 넣으면 올라요", look[1], Config.Farm.BuffNames[kind] or kind,
				BUFF_THEME[kind] or "", BUFF_EXAMPLES[kind] or "")
		else
			line.TextColor3 = look[2]
			local extra = b[kind] - share[kind]
			line.Text = string.format("%s %s +%s%s", look[1], Config.Farm.BuffNames[kind] or kind, percent(b[kind]),
				extra > CAP_EPSILON and share[kind] > CAP_EPSILON and string.format("  (농장 %s)", percent(share[kind])) or "")
			if share[kind] >= caps[kind] - CAP_EPSILON then
				line.Text ..= " · " .. "🔝 농장 최대"
			end
		end
	end
	t[7].Text = b.Slots > 0 and string.format("🪑 공룡 자리 +%d (도감·환생)", b.Slots) or ""
end

local function refreshSign(index, profile, owner)
	refreshTotals(index, profile)
	local label = signs[index]
	if not label then
		return
	end
	if not profile then
		label.Text = "공룡 수집 농장"
		return
	end
	local cost = Formulas.nextFarmSlotCost(profile.Upgrades.FarmSlots, profile.DefenseLevel)
	local slots = Formulas.farmSlots(profile)
	local free = owner ~= nil and owner:GetAttribute("CocoPays") == "FarmSlot"
	label.Text = cost and free and string.format("🌾 농장 %d칸\n➕ 1칸 더: 🎁 코코가 내줘요 · 무료!", slots)
		or cost and string.format("🌾 농장 %d칸\n➕ 1칸 더: 💰 %s원", slots, Formulas.shortNumber(cost))
		or string.format("🌾 농장 %d칸\n✅ 다 늘렸어요!", slots)
end

local dexShown = {} -- [player] = true once the first refresh set their title (no "new title" for what they had)
local dexChecked = {} -- [player] = the collection count last looked through (every money change runs refresh)

-- (2026-10-02) the collection milestones and rarity rows reached, paid once, in one notice; the title over the head
local function payCollection(player, profile, count)
	if dexChecked[player] == count then
		return -- (nothing new collected: nothing new reached)
	end
	dexChecked[player] = count
	local due = Formulas.collectionDue(profile)
	if #due > 0 then
		PlayerData.update(player, function(p)
			for _, item in ipairs(due) do
				Formulas.markCollectionPaid(p, item)
			end
		end)
		local total, parts = { Keys = 0, SpecialKeys = {}, MoneyChests = 0 }, {}
		for _, item in ipairs(due) do
			total.Keys += item.Reward.Keys or 0
			total.MoneyChests += item.Reward.MoneyChests or 0
			for id, n in pairs(item.Reward.SpecialKeys or {}) do
				total.SpecialKeys[id] = (total.SpecialKeys[id] or 0) + n
			end
			table.insert(parts, item.Kind == "Milestone" and string.format("도감 %d", item.Count)
				or string.format("%s %d종", Formulas.rarity(item.Rarity).Name, item.Species))
		end
		Rewards.grant(player, total, string.format("📖 도감 보상! %s", table.concat(parts, " · ")))
	end
	local species = Formulas.dexSpecies(profile)
	player:SetAttribute("DexSpecies", species)
	local king = Config.Collection.King
	if species >= Formulas.dexSpeciesTotal() and not profile.DexKing then
		PlayerData.update(player, function(p)
			p.DexKing = true
		end)
		Rewards.grant(player, king.Reward, string.format("%s! 📖 공룡 %d종을 다 모았어요", king.Title, species))
		for _, other in ipairs(Players:GetPlayers()) do
			if other ~= player then
				Net.push(other, "Notice", king.Title, string.format("👑 %s님이 공룡 %d종을 다 모아 공룡 왕이 됐어요!",
					player.DisplayName, species))
			end
		end
		Story.show(player, "King", nil, nil, Story.explain("King", species))
	end
	local title = Formulas.collectionTitle(count)
	if (PlayerData.get(player) or profile).DexKing and count < Formulas.collectionTotal() then
		title = king.Title
	end
	local before = player:GetAttribute("DexTitle")
	player:SetAttribute("DexTitle", title)
	if title and title ~= before and dexShown[player] then
		Net.pushAll("Notice", "📖 도감", string.format("📖 %s님 새 칭호: %s! (도감 %d)", player.DisplayName, title, count))
	end
	dexShown[player] = true
end

local function refresh(player, profile)
	local index = Bases.of(player)
	if index then
		refreshSign(index, profile, player)
	end
	local bonuses = Formulas.bonuses(profile)
	for _, name in ipairs(BONUS_NAMES) do
		player:SetAttribute("Bonus" .. name, bonuses[name])
	end
	player:SetAttribute("CollectionCount", bonuses.Collection)
	payCollection(player, profile, bonuses.Collection)
	player:SetAttribute("FarmCount", Formulas.farmCount(profile))
	-- (2026-10-02) dinos neither placed nor on the farm: enhance fodder (Coco's 🦖 tip)
	local spare = 0
	for _, u in ipairs(profile.Units) do
		if not profile.Placed[u.Id] and not (profile.Farm or {})[u.Id] then
			spare += 1
		end
	end
	player:SetAttribute("SpareDinos", spare)
	player:SetAttribute("FarmSlots", Formulas.farmSlots(profile))
	-- (2026-10-02) how many farm bonuses are at their cap: the 💎 shop's farm slots card says so before buying
	local share, capped = farmShare(profile), 0
	for kind, cap in pairs(Formulas.farmCaps(profile)) do
		if share[kind] >= cap - CAP_EPSILON then
			capped += 1
		end
	end
	player:SetAttribute("FarmCapped", capped > 0 and capped or nil)
	local skins = Formulas.newSkins(profile, bonuses)
	if #skins > 0 then
		PlayerData.update(player, function(p)
			for _, id in ipairs(skins) do
				p.Skins[id] = true
			end
		end)
		for _, id in ipairs(skins) do
			local skin = Formulas.skin(id)
			if skin.Theme then
				Net.pushAll("Notice", "📖 도감", string.format("%s님이 %s 테마를 모두 모았어요! 👋 %s 스킨 획득", player.DisplayName,
					Formulas.theme(skin.Theme).Name, skin.Name))
			else
				Net.push(player, "Notice", "📖 도감", string.format("📖 도감 %d! 👋 %s 스킨이 생겼어요 (🎒 인벤토리 → 스킨)",
					skin.Collection, skin.Name))
			end
		end
	end
	refreshPen(player, profile)
end

-- saves from before the collection: every dino they own counts; saves from when the farm started with
-- 20 slots: enough bought slots for the dinos already on the farm
local function backfill(player, profile)
	local extra = Formulas.farmCount(profile) - Config.Farm.StartSlots
	if extra > profile.Upgrades.FarmSlots then
		PlayerData.update(player, function(p)
			p.Upgrades.FarmSlots = math.min(extra, Config.Farm.MaxSlots - Config.Farm.StartSlots)
		end)
		profile = PlayerData.get(player)
	end
	local missing = false
	for _, u in ipairs(profile.Units) do
		missing = missing or not profile.Collection[Formulas.collectionKey(u)]
	end
	if missing then
		PlayerData.update(player, function(p)
			for _, u in ipairs(p.Units) do
				Formulas.recordCollection(p, u)
			end
		end)
	else
		refresh(player, profile)
	end
end

-- ---------------------------------------------------------------------------
-- Requests
-- ---------------------------------------------------------------------------

local function register(player, unitId)
	if not Unlocks.shown(player, "FarmBoard") then
		return
	end
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	local ok, why = Formulas.canFarm(profile, unitId)
	if not ok then
		return say(player, why)
	end
	PlayerData.update(player, function(p)
		p.Farm[unitId] = true
	end)
	Rewards.add(player, "FarmAdd", 1) -- (2026-10-03: the tutorial field's 🌾 농장 step)
	local unit = unitsById(profile)[unitId]
	local kind, amount = Formulas.farmBuff(unit)
	say(player, string.format("🌾 %s 농장에 넣었어요! %s +%.2f%% (농장 %d/%d)", Formulas.species(unit.Species).Name,
		Config.Farm.BuffNames[kind], amount * 100, Formulas.farmCount(profile), Formulas.farmSlots(profile)))
end

-- one more farm slot, from the "농장 칸 늘리기" prompt on the player's own farm sign
local function buySlot(player, sign)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	if not Bases.near(player, sign, Config.Farm.SignRange + SIGN_SLACK) then
		return say(player, "🌾 농장 앞 표지판에서 늘려요")
	end
	local bought = profile.Upgrades.FarmSlots
	local cost = Formulas.nextFarmSlotCost(bought, profile.DefenseLevel)
	if not cost then
		return say(player, "농장 칸을 모두 늘렸어요")
	end
	local free = player:GetAttribute("CocoPays") == "FarmSlot"
	if not free and not PlayerData.spendMoney(player, cost, "farmslot") then
		return say(player, string.format("💰 돈이 모자라요 (%s원 필요)", Formulas.shortNumber(cost)))
	end
	PlayerData.update(player, function(p)
		p.Upgrades.FarmSlots = bought + 1
		if free then
			p.Starter.CocoPaid = p.Starter.CocoPaid or {}
			p.Starter.CocoPaid.FarmSlot = true
		end
	end)
	if free then
		player:SetAttribute("CocoPays", nil)
	end
	say(player, string.format(free and "🎁 코코가 내줬어요! 🌿 농장 칸 +1! 이제 %d칸" or "🌿 농장 칸 +1! 이제 %d칸",
		Formulas.farmSlots(PlayerData.get(player))))
end

local function unregister(player, unitId)
	local profile = PlayerData.get(player)
	if not profile or not profile.Farm[unitId] then
		return
	end
	if profile.FarmLock[unitId] then
		return say(player, "🔒 잠긴 공룡이에요! 🔓 잠금을 풀고 빼요")
	end
	PlayerData.update(player, function(p)
		p.Farm[unitId] = nil
	end)
	local unit = unitsById(profile)[unitId]
	local species = unit and Formulas.species(unit.Species)
	if species then
		say(player, string.format("🌾 %s 농장에서 뺐어요! (농장 %d/%d)", species.Name, Formulas.farmCount(profile),
			Formulas.farmSlots(profile)))
	end
end

local function setLock(player, unitId, lock)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	if not profile.Farm[unitId] then
		return say(player, "🌾 농장에 있는 공룡만 잠글 수 있어요")
	end
	PlayerData.update(player, function(p)
		p.FarmLock[unitId] = lock or nil
	end)
	player:SetAttribute("UnitsVersion", (player:GetAttribute("UnitsVersion") or 0) + 1)
	say(player, lock and "🔒 잠갔어요! 디펜스 자동 배치로도 농장에서 안 빠져요" or "🔓 잠금을 풀었어요")
end

local function autoFarm(player)
	if not Unlocks.shown(player, "FarmBoard") then
		return
	end
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	local keep = {}
	for id in pairs(profile.Farm) do
		if profile.FarmLock[id] then
			keep[id] = true
		end
	end
	local picked = Formulas.bestFarm(profile, keep)
	if #picked == 0 then
		return say(player, "🌾 농장에 넣을 공룡이 없어요 (아레나에 놓인 공룡은 빼고 골라요)")
	end
	PlayerData.update(player, function(p)
		p.Farm = {}
		for _, id in ipairs(picked) do
			p.Farm[id] = true
		end
		for id in pairs(p.FarmLock) do
			if not p.Farm[id] then
				p.FarmLock[id] = nil
			end
		end
	end)
	Rewards.add(player, "FarmAdd", 1)
	player:SetAttribute("UnitsVersion", (player:GetAttribute("UnitsVersion") or 0) + 1)
	say(player, string.format("🌾 농장에 좋은 공룡 %d마리를 넣었어요! (농장 %d/%d)", #picked, #picked,
		Formulas.farmSlots(PlayerData.get(player))))
end

function Farm.init()
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		local pen = folder and folder:FindFirstChild("Base_FarmPen", true)
		if pen then
			Bases.title(pen, "🌿 공룡 수집 농장", TITLE_COLOR, true, TITLE_HEIGHT)
			plantGrass(folder, pen)
		end
		-- the farm sign: the owner's slots and the "농장 칸 늘리기" prompt
		local sign = folder and folder:FindFirstChild("FarmSign")
		if sign and sign:IsA("BasePart") then
			local old = sign:FindFirstChild("FarmSlotSign")
			if old then
				old:Destroy()
			end
			local gui = Instance.new("SurfaceGui")
			gui.Name = "FarmSlotSign"
			gui.Face = Enum.NormalId.Front
			gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
			gui.PixelsPerStud = SIGN_PIXELS_PER_STUD
			local label = Instance.new("TextLabel")
			label.Size = UDim2.fromScale(1, 1)
			label.BackgroundTransparency = 1
			label.Font = Enum.Font.GothamBold
			label.TextScaled = true
			label.TextColor3 = Color3.new(1, 1, 1)
			label.TextStrokeTransparency = 0.3
			label.Parent = gui
			gui.Parent = sign
			signs[index] = label
			refreshSign(index, nil)
			local prompt = Bases.prompt(sign, "BuyFarmSlot", index, "농장 칸 늘리기", Config.Farm.SignRange)
			if prompt then
				prompt.HoldDuration = Config.UI.HoldSeconds -- held a moment: a stray tap does nothing
			end
			Bases.title(sign, "➕ 농장 칸 늘리기", TITLE_SLOT_COLOR)
			-- the totals board beside it, on the ground, on the side away from the plot's middle line (as PlaceBoards)
			-- and past the farm placing board there (2026-10-04, "게시판이 겹치는데": both stood in the same spot)
			local zone = folder:FindFirstChild("SafeZone")
			local right = Vector3.new(sign.CFrame.RightVector.X, 0, sign.CFrame.RightVector.Z).Unit
			local middle = zone and zone.Position or sign.Position
			local side = (middle - sign.Position):Dot(right) >= 0 and -1 or 1
			local step = sign.Size.X / 2 + PLACE_BOARD_ROOM + TOTALS_GAP + TOTALS_SIZE.X / 2
			local spot = sign.CFrame * CFrame.new(side * step, 0, 0)
			local ground = sign.Position.Y - sign.Size.Y / 2
			for _, d in ipairs(folder:GetDescendants()) do
				if d.Name == "FarmSignPost" and d:IsA("BasePart") then -- (the plot is flat: the posts' feet)
					ground = d.Position.Y - d.Size.Y / 2
					break
				end
			end
			local base = CFrame.new(spot.Position.X, ground, spot.Position.Z) * spot.Rotation
			local old = folder:FindFirstChild("FarmTotals")
			if old then
				old:Destroy()
			end
			local model = Instance.new("Model")
			model.Name = "FarmTotals"
			local function piece(name, size, cf, color)
				local p = Instance.new("Part")
				p.Name = name
				p.Anchored = true
				p.Size = size
				p.CFrame = cf
				p.Color = color
				p.Material = Enum.Material.WoodPlanks
				p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
				p.Parent = model
				return p
			end
			local board = piece("Board", TOTALS_SIZE, base * CFrame.new(0, TOTALS_BOTTOM + TOTALS_SIZE.Y / 2, 0), TOTALS_COLOR)
			for _, x in ipairs({ -TOTALS_SIZE.X / 2 + 0.6, TOTALS_SIZE.X / 2 - 0.6 }) do
				piece("Post", TOTALS_POST, base * CFrame.new(x, TOTALS_POST.Y / 2, 0.3), TOTALS_POST_COLOR)
			end
			local gui = Instance.new("SurfaceGui")
			gui.Face = Enum.NormalId.Front
			gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
			gui.PixelsPerStud = TOTALS_PIXELS_PER_STUD
			gui.Parent = board
			local lines = {}
			for i = 1, 7 do
				local l = Instance.new("TextLabel")
				l.BackgroundTransparency = 1
				l.Font = Enum.Font.GothamBold
				l.TextScaled = true
				l.TextColor3 = i == 1 and TOTALS_TITLE_COLOR or Color3.new(1, 1, 1)
				l.TextXAlignment = i == 1 and Enum.TextXAlignment.Center or Enum.TextXAlignment.Left
				l.Position = UDim2.new(0.04, 0, (i - 1) / 7, 0)
				l.Size = UDim2.new(0.92, 0, 1 / 7, -3)
				l.Parent = gui
				lines[i] = l
			end
			model.Parent = folder
			totals[index] = lines
			refreshTotals(index, nil)
			prompt.Triggered:Connect(function(player)
				if Bases.of(player) == index and Unlocks.shown(player, "FarmSign") then
					buySlot(player, sign)
				end
			end)
		elseif folder then
			warn(string.format("[Farm] Base%d에 FarmSign이 없어 농장 칸 늘리기 버튼을 못 놓았습니다", index))
		end
	end
	PlayerData.onLoaded(backfill)
	PlayerData.onChanged(refresh)
	local function watch(player)
		player:GetAttributeChangedSignal("Base"):Connect(function()
			local profile = PlayerData.get(player)
			if profile then
				refreshPen(player, profile)
				local index = Bases.of(player)
				if index then
					refreshSign(index, profile, player)
				end
			end
		end)
		player:GetAttributeChangedSignal("CocoPays"):Connect(function()
			local profile = PlayerData.get(player)
			local index = Bases.of(player)
			if profile and index then
				refreshSign(index, profile, player)
			end
		end)
	end
	Players.PlayerAdded:Connect(watch)
	for _, player in ipairs(Players:GetPlayers()) do
		watch(player)
	end
	Players.PlayerRemoving:Connect(function(player)
		dexShown[player] = nil
		dexChecked[player] = nil
		local index = Bases.of(player)
		if index then
			clearPen(index)
			refreshSign(index, nil)
		end
	end)
	Net.onRequest("RegisterFarm", { "string" }, register)
	Net.onRequest("UnregisterFarm", { "string" }, unregister)
	Net.onRequest("AutoFarm", {}, autoFarm)
	Net.onRequest("FarmLock", { "string", "boolean" }, setLock)
	Net.onAsk("GetCollection", {}, function(player)
		local profile = PlayerData.get(player)
		if not profile then
			return nil
		end
		Rewards.add(player, "DexLook", 1)
		local bonuses = Formulas.bonuses(profile)
		local keys = {}
		for key in pairs(profile.Collection) do
			table.insert(keys, key)
		end
		-- (2026-10-01, "각성 레벨 충족해야 하는 공룡은 왜 도감에 안 뜨는 거") the rebirth-only dinos it has had
		local rebirthOwned = {}
		for _, s in ipairs(Config.RebirthSpecies) do
			for key in pairs(profile.Collection) do
				if string.sub(key, 1, #s.Id + 1) == s.Id .. "/" then
					rebirthOwned[s.Id] = true
				end
			end
			for _, u in ipairs(profile.Units or {}) do
				if u.Species == s.Id then
					rebirthOwned[s.Id] = true
				end
			end
		end
		-- (2026-10-04, "특별 등급으로 도감에 안 뜨냐 웰컴렉스" → its own row, outside the count) the gift-only dinos it has
		local specialOwned = {}
		for _, s in ipairs(Config.GiftSpecies or {}) do
			for _, u in ipairs(profile.Units or {}) do
				if u.Species == s.Id then
					specialOwned[s.Id] = true
				end
			end
		end
		return { Collection = keys, Skins = profile.Skins, Bonuses = bonuses, Rebirths = profile.Rebirths,
			FarmCount = Formulas.farmCount(profile), FarmSlots = Formulas.farmSlots(profile), RebirthOwned = rebirthOwned,
			SpecialOwned = specialOwned, Bones = profile.BossHunt and profile.BossHunt.Bones or {} } -- (2026-10-04: 🦴 the bone dinos')
	end)
end

return Farm
