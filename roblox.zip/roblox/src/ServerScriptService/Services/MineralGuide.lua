--[[
MineralGuide: a guide board for every base, at the battlefield's edge beside the base's path in
(design 2.3 자원 채취), its face turned toward the base so players walking out to mine read it: every
mineral grade with the mineral itself in its color beside its row (a small real model standing out of the
board's face, Minerals.nodeModel), its name, money per mineral, the pickaxe tier that mines it well and how often it
turns up, and the four node sizes, each pictured, with how much more they pay and how many turns they
hold. (The pictures were ViewportFrames first, but those stayed empty on the players' screens, even
with cameras made on each screen; real little models always show.) Display only, made when the server starts from Config.Minerals, for all eight bases whether
anyone has them or not: the boards sit in their own folder Workspace.Map.MineralGuides (not inside the
base folders) and each streams in whole when near (ModelStreamingMode Atomic; 2026-10-01: Persistent sent all
eight with their mineral models at joining).
(2026-10-04, "광물안내에 곡괭이들도 모델링 박아넣어 최대한 글을 없애고 있는거야?") as few words as can be: the column heads are
icons (💎 💰 ⛏️ 📍), the pickaxe that mines a grade well is its real model (ServerStorage.Assets Pickaxe_T<n>, its tier
number in a badge), where it comes up is a little target (the key altar 🔑 in the middle, the bases' side outside, the
grade's belt in its color), and the sizes' line is icons too.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local Minerals = require(script.Parent:WaitForChild("Minerals"))

local MineralGuide = {}

-- display only
local BOARD_SIZE = Vector3.new(14, 15, 0.4) -- (was 13 × 10: the minerals beside the rows were too small to see)
local BOARD_HEIGHT = 9 -- studs from the ground to the board's middle
local POST_SIZE = Vector3.new(0.5, 16, 0.5)
local EDGE = 364 -- studs from the map center: against the battlefield's orange band (to 363), clear of its flags (360), before the race track (365)
local PATH_HALF = 9 -- half the base path's width (roblox/MapBuilder.lua PATH_W)
local SIDE = 2 -- studs between the path's side and the board
local PIXELS_PER_STUD = 40
local PICTURE_SIZE = "Chunk" -- the node size shown for each grade
local PICTURE_GRADE = 1 -- the grade the size pictures are shown in
local PICTURE_FILL = 0.9 -- a model's height: this share of its row
local PICTURE_GAP = 0.05 -- studs between the board's face and a model
local PICTURE_TURN = math.rad(25) -- each model turned a little, to show its shape
local PICKAXE_LEAN = -35 -- degrees: a pickaxe leans over on the board
local PICKAXE_DEPTH_TURN = 20 -- degrees its picks turn from running straight across toward the viewer
local PICTURE_ROCK_SHADE = 0.45 -- the rock around the crystals: the grade's color this much darker (not grey)
local COLOR_BOARD = Color3.fromRGB(70, 55, 40)
local COLOR_POST = Color3.fromRGB(110, 80, 55)
local COLOR_TITLE = Color3.fromRGB(255, 220, 90)
local COLOR_TEXT = Color3.new(1, 1, 1)
local COLOR_SUB = Color3.fromRGB(200, 200, 210)
local COLOR_TARGET = Color3.fromRGB(60, 64, 80) -- the little target's field
local COLOR_TARGET_EDGE = Color3.fromRGB(150, 150, 165)
local COLOR_BADGE = Color3.fromRGB(255, 205, 60)
local PICKAXE_FILL = 1.1 -- a pickaxe model's size: this share of its row's height (they are long and thin)
local FONT = Enum.Font.GothamBold

local gradeIds = {}
for _, g in ipairs(Config.Minerals.Grades) do
	table.insert(gradeIds, g.Id)
end
local pictures = 0 -- mineral models made (told in the output, to check in Studio)

local function part(props)
	local p = Instance.new("Part")
	p.Anchored = true
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Material = Enum.Material.WoodPlanks
	for k, v in pairs(props) do
		if k ~= "Parent" then
			p[k] = v
		end
	end
	p.Parent = props.Parent
	return p
end

local function groundY(position, ignore)
	local params = RaycastParams.new()
	params.FilterDescendantsInstances = ignore
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true
	local hit = Workspace:Raycast(position + Vector3.new(0, 30, 0), Vector3.new(0, -100, 0), params)
	return hit and hit.Position.Y or position.Y
end

local function text(parent, value, size, pos, color, align)
	local t = Instance.new("TextLabel")
	t.BackgroundTransparency = 1
	t.Font = FONT
	t.TextScaled = true
	t.TextColor3 = color or COLOR_TEXT
	t.TextXAlignment = align or Enum.TextXAlignment.Left
	t.Text = value
	t.Size = size
	t.Position = pos
	t.Parent = parent
	return t
end

-- a mineral standing out of the board's face (anchored, nothing touches or hits it), its middle at
-- the face's (sx, sy) in the face's 0..1 coordinates (as the SurfaceGui lays it out: x from the left
-- and y from the top, seen from the front), height in studs
local function picture(board, gradeId, sizeId, sx, sy, height, parent)
	local model = Minerals.nodeModel(gradeId, sizeId, height)
	model.Name = "GuideMineral"
	local color = Color3.fromRGB(table.unpack(Config.Minerals.Grades[table.find(gradeIds, gradeId)].Rgb))
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = false, false, false, false
			if not d:GetAttribute("Crystal") then -- the whole mineral in its grade's color, so it reads from afar
				d.Color = color:Lerp(Color3.new(0, 0, 0), PICTURE_ROCK_SHADE)
			end
			if d:IsA("MeshPart") then
				d.TextureID = "" -- (a texture would hide the color)
			end
		end
	end
	pictures += 1
	local cf, bounds = model:GetBoundingBox()
	model.WorldPivot = cf
	-- the Front face is the board's −Z side; seen from there its left edge is the board's +X side
	local local_ = CFrame.new((0.5 - sx) * BOARD_SIZE.X, (0.5 - sy) * BOARD_SIZE.Y,
		-(BOARD_SIZE.Z / 2 + PICTURE_GAP + math.max(bounds.X, bounds.Z) / 2))
	model:PivotTo(board.CFrame * local_ * CFrame.Angles(0, PICTURE_TURN, 0))
	model.Parent = parent
	return model
end

-- any model standing out of the board's face like the minerals (the pickaxes), its longest side `size` studs
local function standOut(board, source, sx, sy, size, parent)
	local model = Instance.new("Model")
	source:Clone().Parent = model
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, false, false, false, false
		elseif d:IsA("Script") or d:IsA("LocalScript") then
			d:Destroy()
		end
	end
	local cf, bounds = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position)
	model:ScaleTo(size / math.max(bounds.X, bounds.Y, bounds.Z, 0.1))
	local _, scaled = model:GetBoundingBox()
	local local_ = CFrame.new((0.5 - sx) * BOARD_SIZE.X, (0.5 - sy) * BOARD_SIZE.Y,
		-(BOARD_SIZE.Z / 2 + PICTURE_GAP + math.max(scaled.X, scaled.Z) / 2))
	-- (2026-10-04, "곡괭이 모델링이 방향이 왜 저래": its picks point front to back (the model stands up with its
	-- head's points along its Z), so from the front its head was a thin line) turned a quarter first so the picks run
	-- across the board, PICKAXE_DEPTH_TURN back toward the viewer for some depth, then leaned like before
	model:PivotTo(board.CFrame * local_ * CFrame.Angles(0, 0, math.rad(PICKAXE_LEAN))
		* CFrame.Angles(0, math.pi / 2 - math.rad(PICKAXE_DEPTH_TURN), 0))
	model.Parent = parent
	pictures += 1
	return model
end

-- a round mark on the face
local function circle(parent, center, diameter, color, transparency)
	local c = Instance.new("Frame")
	c.AnchorPoint = Vector2.new(0.5, 0.5)
	c.Position = center
	c.Size = diameter
	c.BackgroundColor3 = color
	c.BackgroundTransparency = transparency or 0
	c.BorderSizePixel = 0
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = c
	local square = Instance.new("UIAspectRatioConstraint")
	square.Parent = c
	c.Parent = parent
	return c
end

-- 📍 where a grade comes up: a little target, the key altar 🔑 in the middle, the bases' side at the edge, the grade's
-- belt (its Band, 0 by the altar .. 1 at the flags) in its color
local function target(parent, g, pos, size)
	local holder = Instance.new("Frame")
	holder.BackgroundTransparency = 1
	holder.Position = pos
	holder.Size = size
	holder.Parent = parent
	local square = Instance.new("UIAspectRatioConstraint")
	square.Parent = holder
	local mid = UDim2.fromScale(0.5, 0.5)
	local field = circle(holder, mid, UDim2.fromScale(1, 1), COLOR_TARGET)
	local edge = Instance.new("UIStroke")
	edge.Color = COLOR_TARGET_EDGE
	edge.Thickness = 2
	edge.Parent = field
	local band = g.Band or { 0, 1 }
	local color = Color3.fromRGB(table.unpack(g.Rgb))
	circle(holder, mid, UDim2.fromScale(band[2], band[2]), color)
	if band[1] > 0 then
		circle(holder, mid, UDim2.fromScale(band[1], band[1]), COLOR_TARGET)
	end
	local key = text(holder, "🔑", UDim2.fromScale(0.34, 0.34), UDim2.fromScale(0.33, 0.33), COLOR_TEXT,
		Enum.TextXAlignment.Center)
	key.ZIndex = 3
	return holder
end

-- the guide's face: a title, one row per grade, then the sizes
local function fill(gui, board, model)
	local back = Instance.new("Frame")
	back.Size = UDim2.fromScale(1, 1)
	back.BackgroundColor3 = Color3.fromRGB(20, 22, 30)
	back.BackgroundTransparency = 0.25
	back.Parent = gui
	text(back, "⛏️ 광물 안내 · ⚔️ 들판", UDim2.fromScale(0.94, 0.09), UDim2.fromScale(0.03, 0.02), COLOR_TITLE,
		Enum.TextXAlignment.Center)
	-- the column heads: an icon and a word a child knows ("봐도 모를만하게 그림만 막 교체하지 말고": not icons alone)
	for _, head in ipairs({ { "💎 광물", 0.02 }, { "💰 값", 0.33 }, { "⛏️ 곡괭이", 0.55 }, { "📍 나오는 곳", 0.76 } }) do
		text(back, head[1], UDim2.fromScale(0.2, 0.05), UDim2.fromScale(head[2], 0.12), COLOR_SUB, Enum.TextXAlignment.Left)
	end
	local assets = ServerStorage:FindFirstChild("Assets")
	local grades = Config.Minerals.Grades
	local rowH = 0.53 / #grades
	for i, g in ipairs(grades) do
		local y = 0.18 + (i - 1) * rowH
		picture(board, g.Id, PICTURE_SIZE, 0.07, y + rowH / 2, rowH * BOARD_SIZE.Y * PICTURE_FILL, model)
		local h = UDim2.fromScale(0.2, rowH * 0.8)
		text(back, g.Name, UDim2.fromScale(0.2, rowH * 0.8), UDim2.fromScale(0.11, y + rowH * 0.1))
		text(back, string.format("💰 %d원", g.Value), h, UDim2.fromScale(0.33, y + rowH * 0.1), COLOR_TITLE)
		-- the pickaxe that mines it well: its model (2026-10-04), its tier in a little badge; the words if no model
		-- (2026-10-04, "광물 티어별 제한을 좀 높여야겠는데") the lowest tier that may mine it at all (MinTier): "4+"
		local tier = g.MinTier or g.RecommendedTier
		local pickaxe = assets and assets:FindFirstChild("Pickaxe_T" .. tier, true)
		if pickaxe then
			standOut(board, pickaxe, 0.62, y + rowH / 2, rowH * BOARD_SIZE.Y * PICKAXE_FILL, model)
			local badge = text(back, tier .. "+", UDim2.fromScale(0.06, rowH * 0.5),
				UDim2.fromScale(0.68, y + rowH * 0.45), Color3.fromRGB(40, 30, 10), Enum.TextXAlignment.Center)
			badge.BackgroundTransparency = 0
			badge.BackgroundColor3 = COLOR_BADGE
			local round = Instance.new("UICorner")
			round.CornerRadius = UDim.new(0.5, 0)
			round.Parent = badge
		else
			text(back, string.format("⛏️ %d티어", tier) .. "+", h, UDim2.fromScale(0.55, y + rowH * 0.1))
		end
		-- 📍 where it comes up: a little target (2026-10-04; was the words, before that its chance)
		target(back, g, UDim2.fromScale(0.82, y + rowH * 0.05), UDim2.fromScale(0.09, rowH * 0.9))
	end
	text(back, "📏 큰 광물일수록 돈을 많이 줘요 (대신 오래 캐요)", UDim2.fromScale(0.9, 0.06), UDim2.fromScale(0.05, 0.73),
		COLOR_SUB, Enum.TextXAlignment.Center)
	local sizes = Config.Minerals.Sizes
	for i, s in ipairs(sizes) do
		local x = 0.03 + (i - 1) * (0.94 / #sizes)
		picture(board, Config.Minerals.Grades[PICTURE_GRADE].Id, s.Id, x + 0.05, 0.84,
			0.1 * BOARD_SIZE.Y * PICTURE_FILL * i / #sizes, model)
		text(back, s.Name, UDim2.fromScale(0.94 / #sizes - 0.1, 0.06), UDim2.fromScale(x + 0.1, 0.8), COLOR_TEXT)
		text(back, string.format("💰 ×%g · %d번 캐요", s.ValueMultiplier, s.Hits), UDim2.fromScale(0.94 / #sizes - 0.1, 0.06),
			UDim2.fromScale(x + 0.1, 0.88), COLOR_TITLE)
	end
end

local guides = nil -- Workspace.Map.MineralGuides

local function build(folder)
	local zone = folder:FindFirstChild("SafeZone")
	if not zone then
		return
	end
	local old = guides:FindFirstChild("MineralGuide" .. folder.Name)
	if old then
		old:Destroy()
	end
	local flat = Vector3.new(zone.Position.X, 0, zone.Position.Z)
	if flat.Magnitude < 1e-3 then
		return
	end
	local out = flat.Unit -- from the map center through the plot: the base's path runs along it
	local right = out:Cross(Vector3.yAxis).Unit
	local spot = out * EDGE - right * (PATH_HALF + SIDE + BOARD_SIZE.X / 2) -- beside the path, at the battlefield's edge
	local model = Instance.new("Model")
	model.Name = "MineralGuide" .. folder.Name
	pcall(function()
		model.ModelStreamingMode = Enum.ModelStreamingMode.Atomic -- whole when near (was Persistent: every one at joining, a slower start)
	end)
	local at = Vector3.new(spot.X, groundY(Vector3.new(spot.X, zone.Position.Y, spot.Z), { folder }), spot.Z)
	local facing = CFrame.lookAt(at, at + out) -- the front toward the base: read on the way out to mine
	local board = part({ Name = "Board", Size = BOARD_SIZE, CFrame = facing * CFrame.new(0, BOARD_HEIGHT, 0),
		Color = COLOR_BOARD, Parent = model })
	for _, x in ipairs({ -BOARD_SIZE.X / 2 + 0.6, BOARD_SIZE.X / 2 - 0.6 }) do
		part({ Name = "Post", Size = POST_SIZE, CFrame = facing * CFrame.new(x, POST_SIZE.Y / 2, 0.3), Color = COLOR_POST,
			Parent = model })
	end
	local gui = Instance.new("SurfaceGui")
	gui.Face = Enum.NormalId.Front
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud = PIXELS_PER_STUD
	gui.Parent = board
	fill(gui, board, model)
	model.Parent = guides
	Bases.title(model, "⛏️ 광물 안내", COLOR_TITLE)
end

function MineralGuide.init()
	local map = Workspace:FindFirstChild("Map")
	if not map then
		warn("[MineralGuide] Workspace.Map이 없어 광물 안내판을 못 세웠습니다")
		return
	end
	guides = map:FindFirstChild("MineralGuides") or Instance.new("Folder")
	guides.Name = "MineralGuides"
	guides.Parent = map
	local boards = 0
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			build(folder)
			boards += guides:FindFirstChild("MineralGuide" .. folder.Name) and 1 or 0
		end
	end
	print(string.format("[MineralGuide] 광물 안내판 %d개, 광물 모형 %d개", boards, pictures))
end

return MineralGuide
