--[[
Shop: buying at the player's own base shop (Base_Shop). Its "상점" prompt opens the shop screen on
the client (StarterPlayerScripts/Hud); the buttons send requests, and the server decides:
own base, within Config.Shop.Range, the next level in order, enough money.

It sells the pickaxe's next power step, the next speed level, the next pickaxe tier (only with all
10 power steps done; the new tier starts its power steps from 0) and the next bag level, each at
the Config price (design 5. 곡괭이, 2.4 가방), and the character upgrades that stay
on rebirth: slap (25 levels) and move speed (30) (design 6, 7).
Keys for draws (1 or 10 of a grade, at the key price of the player's defense level; they go straight
to the saved keys) are sold, and ExchangeRate keys of a grade traded for one of the next grade up
(Net request ExchangeKeys), at the key stall beside the shop (KeyStall, a copy of the shop stall made
here when the server starts, "🔑 열쇠 상점 · 🔄 교환" over it, prompt Kind "KeyShop").
Rebirth (Net request Rebirth, design 12) is not in the shop: every base has a rebirth sign beside its
spawn pad (made here when the server starts, a board on two posts facing the pad, "🔄 환생" over it);
its prompt opens the rebirth window, and the server wants the player at their own sign.
Player attributes SlapLevel, MoveSpeedLevel and Rebirths show the character levels.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))
local Story = require(script.Parent:WaitForChild("Story"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))

local Shop = {}

-- display only
local TITLE_COLOR = Color3.fromRGB(140, 220, 255)
-- (2026-10-04, "공중에 폭탄알이 하나 떠있다고") studs over the stall's top for its name: over what it sells, standing on
-- its roof (StarterPlayerScripts/StallShowcase, 3.2 studs tall)
local TITLE_OVER_SHOWCASE = 4.6
local KEY_TITLE_COLOR = Color3.fromRGB(255, 215, 90)
local KEY_STALL_COLOR = Color3.fromRGB(230, 180, 50)
local KEY_STALL_SIDE = 18 -- studs from the shop's middle toward the plot's middle line (the stalls are 13.5 wide)
-- (2026-10-01, "big keys beside the key stall, like the bombs by the bomb shop") the keys standing past it
local KEY_DECOR_SIDE = 10.5 -- studs past the key stall's middle
local KEY_DECOR = { -- { studs across, studs out front, height, color, lean (degrees) } of each big key
	{ 0, 0, 5, Color3.fromRGB(255, 200, 50), -8 }, -- gold
	{ 3.2, 1.2, 3.8, Color3.fromRGB(215, 220, 230), 10 }, -- silver
	{ -3, 1.5, 3.4, Color3.fromRGB(220, 40, 70), -14 }, -- ruby
	{ 1.2, 3.2, 2.8, Color3.fromRGB(120, 230, 255), 6 }, -- diamond
}
local KEY_DECOR_GEM = Color3.fromRGB(255, 255, 255)
local MACHINE_MODEL = "Gacha_Machine"
local MACHINE_SPOT = { 24, 12 }
local MACHINE_HEIGHT = 10
local MACHINE_RANGE = 14
local MACHINE_TITLE_COLOR = Color3.fromRGB(255, 170, 80)
local MACHINE_TITLE_HEIGHT = 2.5
local MACHINE_PROP_CLEARANCE = 7
local MACHINE_BODY = Color3.fromRGB(240, 122, 60)
local MACHINE_CREAM = Color3.fromRGB(255, 231, 163)
local MACHINE_DARK = Color3.fromRGB(58, 42, 42)
local MACHINE_BOX = Vector3.new(6.5, 6, 5)
local MACHINE_HEAD = 5.5
local MACHINE_WINDOW = Vector3.new(0.4, 3.2, 3.2)
local MACHINE_KNOB = Vector3.new(0.6, 1.8, 1.8)
local REBIRTH_COLOR = Color3.fromRGB(215, 120, 235)
local MISSED_GIFT_NOTICE_DELAY = 15
local REBIRTH_POST_COLOR = Color3.fromRGB(110, 80, 55)
local REBIRTH_BOARD_SIZE = Vector3.new(6, 3.5, 0.4)
local REBIRTH_BOARD_HEIGHT = 4 -- studs from the ground to the board's middle
local REBIRTH_POST_SIZE = Vector3.new(0.5, 5.5, 0.5)
local REBIRTH_SIDE = 9 -- studs from the spawn pad's middle toward the plot's middle line
local REBIRTH_PIXELS_PER_STUD = 50
local REBIRTH_FX_SECONDS = 6 -- the rebirth show's lift and spin (StarterPlayerScripts/RebirthFx) and a little more

local rng = Random.new()

local function say(player, text)
	Net.push(player, "Notice", "⛏️ 곡괭이 상점", text)
end

local function atOwnShop(player)
	local folder = Bases.folderOf(player)
	local shop = folder and folder:FindFirstChild("Base_Shop")
	if not shop or not Bases.near(player, shop, Config.Shop.Range) then
		say(player, "내 기지 ⛏️ 곡괭이 상점 앞에서 살 수 있어요")
		return false
	end
	return true
end

local rebirthSigns = {} -- [base number] = the sign's board
local keyStalls = {} -- [base number] = the key stall
local makeKeyDecor -- (defined below; the key stall calls it)

-- the key stall beside the shop, toward the plot's middle line, facing the same way
local function makeKeyStall(index, folder)
	local shop = folder:FindFirstChild("Base_Shop")
	local zone = folder:FindFirstChild("SafeZone")
	if not shop or not zone then
		return nil
	end
	local at = shop:GetPivot().Position
	local out = Vector3.new(zone.Position.X, 0, zone.Position.Z)
	out = out.Magnitude > 1e-3 and out.Unit or Vector3.zAxis
	local toMiddle = Vector3.new(zone.Position.X - at.X, 0, zone.Position.Z - at.Z)
	local side = toMiddle - out * toMiddle:Dot(out)
	side = side.Magnitude > 1e-3 and side.Unit or out:Cross(Vector3.yAxis).Unit
	local stall = Bases.copyStall(folder, "KeyStall", at + side * KEY_STALL_SIDE, -out, KEY_STALL_COLOR, "🔑 열쇠 상점")
	-- (2026-10-01, "tell that the key stall exchanges keys too")
	Bases.title(stall, "🔑 열쇠 상점 · 🔄 교환", KEY_TITLE_COLOR)
	Bases.prompt(stall, "KeyShop", index, "열쇠 사기 · 교환", Config.Shop.Range)
	makeKeyDecor(folder, at + side * (KEY_STALL_SIDE + KEY_DECOR_SIDE), -out)
	return stall
end

-- big standing keys with sparkles past the key stall: this is the key shop
function makeKeyDecor(folder, at, look)
	local model = Instance.new("Model")
	model.Name = "KeyDecor"
	local ground = Bases.groundBelow(at, {})
	local frame = CFrame.lookAt(Vector3.new(at.X, ground, at.Z), Vector3.new(at.X, ground, at.Z) + look)
	local function piece(name, size, cf, color, shape, material)
		local p = Instance.new("Part")
		p.Name = name
		p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch = true, false, false, false
		p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
		p.Size, p.CFrame, p.Color = size, cf, color
		p.Shape = shape or Enum.PartType.Block
		p.Material = material or Enum.Material.Metal
		p.Parent = model
		return p
	end
	for _, k in ipairs(KEY_DECOR) do
		local s, color = k[3], k[4]
		local base = frame * CFrame.new(k[1], 0, -k[2]) * CFrame.Angles(0, 0, math.rad(k[5]))
		piece("Shaft", Vector3.new(0.14 * s, 0.62 * s, 0.14 * s), base * CFrame.new(0, 0.31 * s, 0), color).CanCollide = true
		for _, y in ipairs({ 0.08, 0.22 }) do -- the teeth
			piece("Tooth", Vector3.new(0.2 * s, 0.09 * s, 0.12 * s), base * CFrame.new(0.15 * s, y * s, 0), color)
		end
		local bowAt = base * CFrame.new(0, 0.62 * s + 0.2 * s, 0)
		piece("Bow", Vector3.new(0.14 * s, 0.46 * s, 0.46 * s), bowAt * CFrame.Angles(0, math.rad(90), 0), color,
			Enum.PartType.Cylinder)
		local gem = piece("Gem", Vector3.new(0.16 * s, 0.2 * s, 0.2 * s), bowAt * CFrame.Angles(0, math.rad(90), 0),
			KEY_DECOR_GEM, Enum.PartType.Cylinder, Enum.Material.Neon)
		local sparkles = Instance.new("ParticleEmitter")
		sparkles.Color = ColorSequence.new(color, Color3.new(1, 1, 1))
		sparkles.LightEmission = 1
		sparkles.Size = NumberSequence.new(0.12 * s, 0)
		sparkles.Speed = NumberRange.new(1, 3)
		sparkles.Lifetime = NumberRange.new(0.4, 0.8)
		sparkles.SpreadAngle = Vector2.new(180, 180)
		sparkles.Rate = 8
		sparkles.Parent = gem
	end
	model.Parent = folder
	return model
end

local function machineStandIn()
	local model = Instance.new("Model")
	local function piece(name, size, cf, color, shape)
		local p = Instance.new("Part")
		p.Name = name
		p.Size, p.CFrame, p.Color = size, cf, color
		p.Shape = shape or Enum.PartType.Block
		p.Material = Enum.Material.SmoothPlastic
		p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
		p.Parent = model
		return p
	end
	local body = MACHINE_BOX
	piece("Body", body, CFrame.new(0, body.Y / 2, 0), MACHINE_BODY)
	piece("Head", Vector3.one * MACHINE_HEAD, CFrame.new(0, body.Y + MACHINE_HEAD * 0.4, 0), MACHINE_BODY, Enum.PartType.Ball)
	local face = CFrame.new(0, 0, -body.Z / 2) * CFrame.Angles(0, math.rad(90), 0)
	piece("Window", MACHINE_WINDOW, CFrame.new(-1.2, body.Y * 0.62, 0) * face, MACHINE_DARK, Enum.PartType.Cylinder)
	piece("Knob", MACHINE_KNOB, CFrame.new(1.8, body.Y * 0.55, 0) * face, MACHINE_CREAM, Enum.PartType.Cylinder)
	model.WorldPivot = CFrame.new()
	return model
end

local function makeGachaMachine(index, folder)
	local zone = folder:FindFirstChild("SafeZone")
	if not zone then
		return nil
	end
	local flat = Vector3.new(zone.Position.X, 0, zone.Position.Z)
	if flat.Magnitude < 1e-3 then
		return nil
	end
	local out = flat.Unit
	local right = out:Cross(Vector3.yAxis).Unit
	local front = flat - out * Config.Map.PlotDepth / 2
	local spot = front + right * MACHINE_SPOT[1] + out * MACHINE_SPOT[2]
	local ground = Vector3.new(spot.X, Bases.groundBelow(Vector3.new(spot.X, zone.Position.Y, spot.Z), { zone }), spot.Z)
	local assets = ServerStorage:FindFirstChild("Assets")
	local source = assets and assets:FindFirstChild(MACHINE_MODEL, true)
	local model
	if source then
		local copy = source:Clone()
		if copy:IsA("BasePart") then
			model = Instance.new("Model")
			copy.Parent = model
		else
			model = copy
		end
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("Script") or d:IsA("LocalScript") or d:IsA("ProximityPrompt") then
				d:Destroy()
			end
		end
		local cf, size = model:GetBoundingBox()
		model.PrimaryPart = nil
		model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
		model:ScaleTo(MACHINE_HEIGHT / math.max(size.Y, 0.1))
	else
		model = machineStandIn()
	end
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanTouch = true, false
		end
	end
	model.Name = "GachaMachine"
	model:PivotTo(CFrame.lookAt(ground, ground + out))
	local props = folder:FindFirstChild("BaseProps")
	for _, prop in ipairs(props and props:GetChildren() or {}) do
		local cf = prop:IsA("Model") and prop:GetBoundingBox() or prop:IsA("BasePart") and prop.CFrame
		if cf and Vector3.new(cf.Position.X - ground.X, 0, cf.Position.Z - ground.Z).Magnitude < MACHINE_PROP_CLEARANCE then
			prop:Destroy()
		end
	end
	model.Parent = folder
	Bases.title(model, "🎰 뽑기", MACHINE_TITLE_COLOR, true, MACHINE_TITLE_HEIGHT)
	Bases.prompt(model, "Gacha", index, "🎰 뽑기", MACHINE_RANGE)
	return model
end

-- the rebirth sign beside a base's spawn pad, facing the pad
local function makeRebirthSign(index, folder)
	local spawn = folder:FindFirstChild("SpawnLocation", true)
	local zone = folder:FindFirstChild("SafeZone")
	if not spawn or not zone then
		return nil
	end
	local flat = Vector3.new(zone.Position.X, 0, zone.Position.Z)
	if flat.Magnitude < 1e-3 then
		return nil
	end
	local out = flat.Unit
	local toMiddle = Vector3.new(zone.Position.X - spawn.Position.X, 0, zone.Position.Z - spawn.Position.Z)
	local side = toMiddle - out * toMiddle:Dot(out) -- across the plot, toward its middle line
	side = side.Magnitude > 1e-3 and side.Unit or out:Cross(Vector3.yAxis).Unit
	local groundY = spawn.Position.Y - spawn.Size.Y / 2
	local at = Vector3.new(spawn.Position.X, groundY, spawn.Position.Z) + side * REBIRTH_SIDE
	local facing = CFrame.lookAt(at, Vector3.new(spawn.Position.X, groundY, spawn.Position.Z) - out * 4)
	local model = Instance.new("Model")
	model.Name = "RebirthSign"
	local function part(name, size, cf, color)
		local p = Instance.new("Part")
		p.Name = name
		p.Anchored = true
		p.Size = size
		p.CFrame = cf
		p.Color = color
		p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
		p.Parent = model
		return p
	end
	local board = part("Board", REBIRTH_BOARD_SIZE, facing * CFrame.new(0, REBIRTH_BOARD_HEIGHT, 0), REBIRTH_COLOR)
	for _, x in ipairs({ -REBIRTH_BOARD_SIZE.X / 2 + 0.5, REBIRTH_BOARD_SIZE.X / 2 - 0.5 }) do
		part("Post", REBIRTH_POST_SIZE, facing * CFrame.new(x, REBIRTH_POST_SIZE.Y / 2, 0.3), REBIRTH_POST_COLOR)
	end
	local gui = Instance.new("SurfaceGui")
	gui.Face = Enum.NormalId.Front
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud = REBIRTH_PIXELS_PER_STUD
	gui.Parent = board
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBold
	text.TextScaled = true
	text.TextColor3 = Color3.new(1, 1, 1)
	text.TextStrokeTransparency = 0.3
	text.Text = string.format("🔄 환생\n디펜스 단계 끝에서 (첫 환생 LV %d)", Config.Rebirth.FirstTierLevels)
	text.Parent = gui
	model.PrimaryPart = board
	model.Parent = folder
	Bases.title(model, "🔄 환생", REBIRTH_COLOR)
	Bases.prompt(board, "Rebirth", index, "환생", Config.Rebirth.SignRange)
	return board
end

local function buyPickaxe(player)
	if not atOwnShop(player) or not Unlocks.check(player, "Shop") then
		return
	end
	local up = PlayerData.get(player).Upgrades
	local tier = up.PickaxeTier
	local price = Formulas.nextPickaxePrice(tier, PlayerData.get(player).DefenseLevel)
	if not price then
		return say(player, "⛏️ 지금 살 수 있는 가장 좋은 곡괭이예요")
	end
	if not Formulas.powerStepsDone(up.PickaxePower, tier) then
		local real = Formulas.trained(up, PlayerData.get(player).Training)
		return say(player, string.format("💪 다음 곡괭이: 💥 파워 훈련 Lv %d 필요 (지금 Lv %d)",
			Formulas.powerShown(tier, Formulas.powerStepsNeed(tier)), Formulas.powerShown(tier, real.PickaxePower)))
	end
	local level = PlayerData.get(player).DefenseLevel
	if not Formulas.pickaxeOpen(tier + 1, level) then
		return say(player, string.format("🔒 다음 곡괭이는 ⚔️ 디펜스 %s에 열려요 (지금 %s)",
			Formulas.levelText(Formulas.pickaxeNeedLevel(tier + 1)), Formulas.levelText(level)))
	end
	local real = Formulas.trained(up, PlayerData.get(player).Training)
	local gain, opens = Formulas.nextPickaxeGain(tier, real.PickaxePower, real.PickaxeSpeed)
	local free = player:GetAttribute("CocoPays") == "Pickaxe"
	if not free and not PlayerData.spendMoney(player, price, "pickaxe") then
		return say(player, string.format("💰 돈이 모자라요 (%s원 필요)", Formulas.shortNumber(price)))
	end
	Rewards.add(player, "Upgrade", 1) -- daily missions
	PlayerData.update(player, function(p)
		p.Upgrades.PickaxeTier = tier + 1
		p.Upgrades.PickaxePower = 0
		if free then
			p.Starter.CocoPaid = p.Starter.CocoPaid or {}
			p.Starter.CocoPaid.Pickaxe = true
		end
	end)
	if free then
		player:SetAttribute("CocoPays", nil)
		say(player, "🎁 코코가 곡괭이 값을 내줬어요!")
	end
	local opened = opens and Formulas.grade(opens)
	if opened then
		local value = math.floor(opened.Value * Formulas.mineralLevelMultiplier(level) + 0.5)
		Net.push(player, "Notice", "🔓 새 광물 해금!", string.format("%s %s 캘 수 있어요! · 💰 1개 %s원 · 📍 %s", opened.Icon,
			opened.Name, Formulas.shortNumber(value), opened.Where))
		Net.push(player, "GradeOpened", opens)
	else
		say(player, string.format("⛏️ %s 곡괭이(%d티어)! ⚡ 캐기 ×%.1f", Config.Pickaxe.Tiers[tier + 1].Name, tier + 1, gain or 1))
	end
end

-- character upgrades: slap (1-25), move speed (0-30); kept on rebirth
-- the character levels for the shop screen (player attributes SlapLevel, MoveSpeedLevel, Rebirths)
local function mirrorCharacter(player, profile)
	player:SetAttribute("SlapLevel", profile.Upgrades.Slap)
	player:SetAttribute("MoveSpeedLevel", profile.Upgrades.MoveSpeed)
	player:SetAttribute("Rebirths", profile.Rebirths)
end

-- rebirth (design 12): at the top of the level tier, pays Formulas.rebirthCost (the rest of the money
-- stays); the next tier opens, bonuses for good (Formulas.rebirthBonuses), keys at once, the rebirth
-- skins and rebirth-only dinos (Formulas.applyRebirth)
local function rebirth(player)
	if not Unlocks.check(player, "Rebirth") then
		return
	end
	local profile = PlayerData.get(player)
	local sign = rebirthSigns[Bases.of(player) or 0]
	if not profile or not sign or not Bases.near(player, sign, Config.Rebirth.SignRange + 4) then
		return profile and say(player, "🔄 스폰 옆 환생 표지판에서 해요")
	end
	local ok, why = Formulas.canRebirth(profile)
	if not ok then
		return say(player, why)
	end
	local cost = Formulas.rebirthCost(profile.Rebirths, profile.DefenseLevel)
	if not PlayerData.spendMoney(player, cost, "rebirth") then
		return say(player, string.format("💰 돈이 모자라요 (%s원 필요)", Formulas.shortNumber(cost)))
	end
	local special = nil
	local skins = {}
	PlayerData.update(player, function(p)
		special = Formulas.applyRebirth(p, function(k)
			return rng:NextInteger(1, k)
		end)
		for _, id in ipairs(Formulas.newSkins(p)) do -- the rebirth skins (Config.Slap.Skins Rebirth = n)
			if Formulas.skin(id).Rebirth then
				p.Skins[id] = true
				table.insert(skins, id)
			end
		end
	end)
	local after = PlayerData.get(player)
	local n = after.Rebirths
	local bonus = Formulas.rebirthBonuses(n)
	local keyParts = {}
	for _, t in ipairs(Config.Keys.Types) do
		local count = Formulas.rebirthKeys(n)[t.Id]
		if count then
			table.insert(keyParts, string.format("%s %d개", t.Name, count))
		end
	end
	say(player, string.format("🔄 환생 %d번! %s부터 다시 · 🔑 %s · 💰 +%d%% · 💪 +%d%% · 🍀 +%d%% · ➕ 자리 +%d",
		n, Formulas.levelText(after.DefenseLevel, n), table.concat(keyParts, " · "), math.floor(bonus.Money * 100 + 0.5),
		math.floor(bonus.UnitPower * 100 + 0.5), math.floor(bonus.RareChance * 100 + 0.5), bonus.Slots))
	-- (2026-10-02) the rarities this awakening opens for the draw
	local opened = Formulas.raritiesOpenedBy(n)
	if #opened > 0 then
		say(player, string.format("🔓 뽑기에 새 등급이 열렸어요: %s", table.concat(opened, "·")))
	end
	local sureRarities = Formulas.rebirthSureRarities(n)
	if #sureRarities > 0 then
		local sure = 0
		for _, k in pairs(after.GuaranteedDraws or {}) do
			sure += k
		end
		player:SetAttribute("GuaranteedDraws", sure)
		for _, id in ipairs(sureRarities) do
			say(player, string.format("⭐ %s 확정 뽑기 1회", Formulas.rarity(id).Name))
		end
	end
	-- (2026-10-02) and the new dinos it opens (every one of the first four awakenings brings some)
	local newSpecies = Formulas.speciesOpenedBy(n)
	if #newSpecies > 0 then
		say(player, string.format("🦖 새 공룡 %d종이 뽑기에 나와요: %s (📖 도감)", #newSpecies, table.concat(newSpecies, "·")))
	end
	-- (2026-10-01, a reborn tester thought the tier's LV 1 was easy) the new tier goes on from the old top
	say(player, string.format("🦴 화석은 %s부터 다시! 더 튼튼하지만(×%g) 선물이 더 커요", Formulas.levelText(after.DefenseLevel, n),
		Formulas.tierHealthMultiplier(n)))
	Net.pushAll("Notice", "🔄 환생", string.format("%s님이 %d번째 환생을 했어요! %s", player.DisplayName, n,
		Formulas.levelText(after.DefenseLevel, n)))
	if special then
		Net.pushAll("Notice", "🔄 환생", string.format("🌟 %s님이 환생 공룡 %s %s %s 얻었어요!", player.DisplayName,
			Formulas.rarity(special.Rarity).Name, Formulas.dinoSize(special.Size).Name, Formulas.species(special.Species).Name))
	end
	for _, id in ipairs(skins) do
		say(player, string.format("👋 환생 스킨 %s 생겼어요! (🎒 인벤토리 → 스킨)", Formulas.skin(id).Name))
	end
	player:SetAttribute("Rebirths", n)
	-- the show: their own screen lifts them up, spins and lands them (a few seconds; not undone as a move)
	MoveGuard.loosen(player, REBIRTH_FX_SECONDS)
	Net.pushAll("RebirthFx", player.UserId, n)
	task.delay(REBIRTH_FX_SECONDS, function()
		if player.Parent and PlayerData.isLoaded(player) then
			Unlocks.graduate(player)
			Story.rebirth(player, n)
		end
	end)
end

-- keys for draws: Config.Gacha.KeyBuyCounts at a time of one grade (Config.Keys.Types),
-- Formulas.keyShopPrice(defense level, grade) each
local function buyKeys(player, count, grade)
	local keyType = Formulas.keyType(grade)
	if not keyType or not table.find(Config.Gacha.KeyBuyCounts, count) then
		return
	end
	local stall = keyStalls[Bases.of(player) or 0]
	if not stall or not Bases.near(player, stall, Config.Shop.Range) then
		return say(player, "🔑 내 기지 열쇠 가판대 앞에서 살 수 있어요")
	end
	if not Formulas.keyShopOpen(grade, PlayerData.get(player).Rebirths) then
		return say(player, string.format("%s는 %s부터 살 수 있어요", keyType.Name, Formulas.keyShopCondition(grade)))
	end
	local price = Formulas.keyBuyPrice(PlayerData.get(player).DefenseLevel, grade, count)
	if not PlayerData.spendMoney(player, price, "keys") then
		return say(player, string.format("💰 돈이 모자라요 (%s원 필요)", Formulas.shortNumber(price)))
	end
	PlayerData.update(player, function(p)
		Formulas.addSavedKeys(p, grade, count)
	end)
	Rewards.add(player, "KeyBuy", count) -- (2026-10-03: the tutorial field's 🔑 열쇠 가판대 step)
	Net.push(player, "KeysBought", grade, count, Formulas.savedKeys(PlayerData.get(player), grade))
end

-- the key stall's exchange (Formulas.exchangeKeys): ExchangeRate keys of a grade -> one of the next
local function exchangeKeys(player, grade, times)
	local stall = keyStalls[Bases.of(player) or 0]
	if not stall or not Bases.near(player, stall, Config.Shop.Range) then
		return say(player, "🔄 내 기지 열쇠 가판대에서 교환할 수 있어요")
	end
	local up = Formulas.nextKeyType(grade)
	if not Formulas.keyType(grade) or not up or times ~= times then
		return
	end
	if not Formulas.keyShopOpen(up.Id, PlayerData.get(player).Rebirths) then
		return say(player, string.format("%s 교환은 %s부터 열려요", up.Name, Formulas.keyShopCondition(up.Id)))
	end
	local made = 0
	PlayerData.update(player, function(p)
		made = Formulas.exchangeKeys(p, grade, times)
	end)
	if made == 0 then
		return say(player, string.format("🔄 %s가 %d개 있어야 %s 1개로 바꿀 수 있어요", Formulas.keyType(grade).Name,
			Formulas.exchangeRate(grade), up.Name))
	end
	Net.push(player, "KeysTraded", grade, made * Formulas.exchangeRate(grade), up.Id, made,
		Formulas.savedKeys(PlayerData.get(player), up.Id))
	Rewards.add(player, "KeyTrade", made) -- (2026-10-03: the tutorial field's key-trade step)
end

local function giveMissedRebirthDinos(player, profile)
	if #Formulas.missedRebirthDinos(profile) == 0 then
		return
	end
	local units = {}
	PlayerData.update(player, function(p)
		units = Formulas.giveMissedRebirthDinos(p)
	end)
	local names = {}
	for _, u in ipairs(units) do
		table.insert(names, Formulas.species(u.Species).Name)
	end
	if #names == 0 then
		return
	end
	task.delay(MISSED_GIFT_NOTICE_DELAY, function()
		if player.Parent then
			Net.push(player, "Notice", "🔄 환생", string.format("🌟 지난 환생 선물 공룡이 왔어요: %s", table.concat(names, " · ")))
		end
	end)
end

function Shop.init()
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		local shop = Bases.bigStall(folder)
		if shop then
			-- (2026-10-04, "상점 이름도 조절해 바로 알아챌 수 있게": it sells only the next pickaxe now) like 🔑 열쇠 상점, 💣 폭탄 상점
			Bases.prompt(shop, "Shop", index, "곡괭이 상점", Config.Shop.Range) -- the client opens the screen
			Bases.title(shop, "⛏️ 곡괭이 상점", TITLE_COLOR, false, TITLE_OVER_SHOWCASE)
		elseif folder then
			warn(string.format("[Shop] Base%d에 Base_Shop이 없습니다", index))
		end
		if folder then
			for _, name in ipairs({ "RebirthSign", "KeyStall", "KeyDecor", "GachaMachine" }) do
				local old = folder:FindFirstChild(name)
				if old then
					old:Destroy()
				end
			end
			rebirthSigns[index] = makeRebirthSign(index, folder)
			keyStalls[index] = makeKeyStall(index, folder)
			makeGachaMachine(index, folder)
		end
	end
	Net.onRequest("BuyPickaxe", {}, buyPickaxe)
	-- (2026-10-04) the power, speed, bag, slap and move speed are trained now (Training): no buying them
	local function trained(player)
		say(player, "💪 이건 기지 훈련장에서 올려요! 훈련 기구 옆에 서 있으면 조금씩 강해져요")
	end
	Net.onRequest("UpgradeBag", {}, trained)
	Net.onRequest("UpgradePower", {}, trained)
	Net.onRequest("UpgradeSpeed", {}, trained)
	Net.onRequest("BuyKeys", { "number", "string" }, buyKeys)
	Net.onRequest("ExchangeKeys", { "string", "number" }, exchangeKeys)
	Net.onRequest("UpgradeCharacter", { "string" }, trained)
	Net.onRequest("Rebirth", {}, rebirth)
	PlayerData.onLoaded(mirrorCharacter)
	PlayerData.onLoaded(giveMissedRebirthDinos)
	PlayerData.onChanged(mirrorCharacter)
end

return Shop
