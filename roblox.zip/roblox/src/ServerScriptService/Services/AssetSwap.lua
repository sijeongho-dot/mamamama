--[[
AssetSwap: lets a remodeled dino be put into ServerStorage.Assets under a new name, Dino_<Species>1,
next to the old Dino_<Species> (2026-10-02, "새모델들에 1을 붙여 기존모델 지울때 구분하게").

At server start, before any service reads Assets, each Dino_<Species>1 is renamed to Dino_<Species>
(its inner parts named Dino_<Species>1... too) and any old Dino_<Species> left beside it is removed,
so the game always uses the new one. This only changes the running game, never the saved place: the
old model can be deleted in Studio whenever, and the "1" can stay on the new one.
Only Dino_ + a species id from Config is swapped, so names like Pickaxe_T1 are never touched.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))

local NEW_SUFFIX = "1"

local AssetSwap = {}

-- the outermost instances named `name` (not ones inside another of the same name)
local function outermost(assets, name)
	local found = {}
	for _, item in ipairs(assets:GetDescendants()) do
		if item.Name == name then
			local parent = item.Parent
			local nested = false
			while parent and parent ~= assets do
				if parent.Name == name then
					nested = true
					break
				end
				parent = parent.Parent
			end
			if not nested then
				table.insert(found, item)
			end
		end
	end
	return found
end

local function swap(assets, id)
	local oldName = "Dino_" .. id
	local newName = oldName .. NEW_SUFFIX
	local new = outermost(assets, newName)
	if #new == 0 then
		return false
	end
	for _, old in ipairs(outermost(assets, oldName)) do
		old:Destroy()
	end
	for _, model in ipairs(new) do
		for _, item in ipairs(model:GetDescendants()) do
			if string.sub(item.Name, 1, #newName) == newName then -- Dino_X1, Dino_X1_Rig
				item.Name = oldName .. string.sub(item.Name, #newName + 1)
			end
		end
		model.Name = oldName
	end
	return true
end

function AssetSwap.init()
	local assets = ServerStorage:FindFirstChild("Assets")
	if not assets then
		return
	end
	local swapped = {}
	for _, list in ipairs({ Config.Species, Config.RebirthSpecies, Config.GiftSpecies }) do
		for _, species in ipairs(list) do
			if swap(assets, species.Id) then
				table.insert(swapped, species.Id)
			end
		end
	end
	if #swapped > 0 then
		print(string.format("[AssetSwap] 새 모델 %d개를 씀: %s", #swapped, table.concat(swapped, ", ")))
	end
end

return AssetSwap
