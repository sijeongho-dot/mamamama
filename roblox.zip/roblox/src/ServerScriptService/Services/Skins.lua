--[[
Skins: the slap skin a player wears (design 7 스킨, Config.Slap.Skins; look only).

- Net request EquipSkin(id): wear an unlocked skin (profile.Skins[id]); "" goes back to the slap level's
  own look. Checked here: a skin not owned is refused.
- The worn skin's model name is mirrored as the player attribute SlapSkin ("" for none), which every
  screen reads to draw this player's slap toy (StarterPlayerScripts/CombatFx).
- Unlocking is Farm's (theme and collection count skins, Formulas.newSkins); Robux skins come with the
  shop later.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))

local Skins = {}

local function mirror(player, profile)
	local skin = profile.SlapSkin ~= "" and profile.Skins[profile.SlapSkin] and Formulas.skin(profile.SlapSkin)
	player:SetAttribute("SlapSkin", skin and skin.Model or "")
end

local function equip(player, id)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	if id ~= "" and not (profile.Skins[id] and Formulas.skin(id)) then
		Net.push(player, "Notice", "👋 스킨", "아직 없는 스킨이에요")
		return
	end
	PlayerData.update(player, function(p)
		p.SlapSkin = id
	end)
	local skin = id ~= "" and Formulas.skin(id)
	Net.push(player, "Notice", "👋 스킨", skin and string.format("👋 %s 스킨을 꼈어요", skin.Name) or "👋 기본 손바닥으로 돌아왔어요")
end

function Skins.init()
	PlayerData.onLoaded(mirror)
	PlayerData.onChanged(mirror)
	Net.onRequest("EquipSkin", { "string" }, equip)
end

return Skins
