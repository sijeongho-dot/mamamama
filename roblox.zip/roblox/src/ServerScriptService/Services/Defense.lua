--[[
Defense: the idle defense of every base whose owner is online (design 2.1 디펜스, 2.2 공룡 배치).

- Each base's arena (Base_Arena from MapBuilder) gets a flat frame: origin at the arena's bottom
  center, -Z toward the spawn portal. Placements are saved in that frame, so they look the same on
  whichever base the player gets next time. The frame is the base folder attribute "ArenaFrame".
- DefenseLogic runs the fight every Config.Defense.TickSeconds (2026-10-04: each base on its own clock, the bases spread
  over the tick, so one frame never steps all eight fights). Its events go to every client in
  one DefenseEvents push per tick; clients draw the monsters from them (StarterPlayerScripts/
  DefenseView), so no monster part moves on the server.
- Kills pay Formulas.killReward(level) × (1 + money bonus) through PlayerData.addMoney (fractions add
  up first). The owner's Formulas.bonuses (farm, collection, rebirths) also make the placed dinos hit
  harder (UnitPower), slow every monster (MonsterSlow, field.slow) and add placement slots. Rain or
  a storm (Weather) multiplies the kill money too.
- Placing: Net requests PlaceUnit(unitId, x, z) and RemoveUnit(unitId). The server checks the unit
  is the player's own, the player is at their own arena (Config.Placement.EditRange), the spot is on
  the platform and clear of the others, and a slot is free.
- Buying slots: the "➕ 공룡 자리 늘리기" prompt on the base's DefenseSign (in front of the defense field)
  adds a slot for game money (Placement.SlotUpgrade); the sign shows the owner's next price.
  Slots = Formulas.profileSlots(profile): the start, bought on the sign, rebirths and the collection.
- Placed dinos stand on the platform as models (Dino_<Species> from ServerStorage.Assets, scaled by
  size; a grey block without the asset) in the base folder's DefenseUnits.
- Promotion fight (승급전, Net request StartPromotion): against monsters of the next level; success
  raises DefenseLevel (more slots, species, rarities, stronger monsters, dearer keys) and, the first
  time, pays keys into the save (Formulas.promotionKeys: 3 + 1 per 10 levels, a silver key every 10th
  level, a gold one every 50th), failure means
  waiting Promotion.RetryCooldown (saved as PromotionRetryAt, so leaving does not skip it).
  Net request CancelPromotion gives the fight up: it ends as a failure, with the same retry wait (so
  giving up just before losing cannot skip the wait).
- Player attributes for the HUD: DefenseOnTrack, DefenseKillsPerMinute, DefenseMoneyPerMinute,
  DefenseSlots, DefensePlaced, UnitsVersion (changes when the dinos or placements change), and for
  the promotion PromoLevel, PromoTimeLeft, PromoOnTrack, PromoBoss (0-1, -1 before the boss),
  PromoRetryAt (server time).
- (2026-10-02) ♾️ 무한 도전 (Net requests StartChallenge / CancelChallenge; Config.Defense.Challenge): endless
  waves on the owner's own track, never at the same time as a promotion fight. Every wave cleared goes into
  the save at once (RewardLogic.finishChallenge: this week's best, the milestones reached pay at once), so
  leaving mid-run keeps it; the weekly ranking is the Leaderboards service's. No kill money meanwhile.
  Player attributes ChallengeWave, ChallengeWaveLeft, ChallengeOnTrack (during a run), ChallengeBest,
  ChallengeAllBest (always).
]]

local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local RarityFx = require(Shared:WaitForChild("RarityFx"))
local Net = require(Shared:WaitForChild("Net"))
local DefensePack = require(Shared:WaitForChild("DefensePack"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local DefenseGuide = require(script.Parent:WaitForChild("DefenseGuide"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))
local Weather = require(script.Parent:WaitForChild("Weather"))
local DefenseLogic = require(script.Parent:WaitForChild("DefenseLogic"))
local DeckAdvice = require(script.Parent:WaitForChild("DeckAdvice"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local Gacha = require(script.Parent:WaitForChild("Gacha"))
local Story = require(script.Parent:WaitForChild("Story"))
local TutorialField = require(script.Parent:WaitForChild("TutorialField"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))
local Leaderboards = require(script.Parent:WaitForChild("Leaderboards"))
local Analytics = require(script.Parent:WaitForChild("Analytics"))
local Friends = require(script.Parent:WaitForChild("Friends"))

local Defense = {}

local FIRST_MAP = Config.Defense.Maps[1].Id

-- display only
local LABEL_MAX_DISTANCE = 70
local THEME_COLORS = { -- grey-box dinos when the asset is missing
	Carnivore = Color3.fromRGB(200, 70, 60),
	Herbivore = Color3.fromRGB(90, 170, 80),
	Armored = Color3.fromRGB(150, 120, 80),
	Sky = Color3.fromRGB(110, 170, 230),
	Sea = Color3.fromRGB(60, 110, 200),
	Variant = Color3.fromRGB(170, 90, 200),
}
local STATS_EVERY = 1 -- seconds between HUD attribute updates
local PROMO_STATUS_EVERY = 0.25 -- seconds between the promotion fight's HUD attribute updates
local SIGN_PIXELS_PER_STUD = 50
local SIGN_SLACK = 4 -- studs of leeway on the prompt distance (lag)
local KILL_WINDOW = 60 -- seconds of kills behind "kills per minute"
local IDLE_RATE_SAVE_EVERY = 60 -- seconds between saving the measured idle money rate (offline earnings)
local FOSSIL_HIT_Y = 1.5 -- where a slapped fossil is hit, over the track (for the "찰싹!" on the clients)
local UNIT_LABEL_WIDTH = 150
local UNIT_LABEL_HEIGHT = 72
local UNIT_LABEL_ROWS = { 0.55, 0.25, 0.2 }
local UNIT_MODELS_PER_STEP = 6
local UNIT_MODEL_STEP_DELAY = 0.1
local TITLE_ARENA_COLOR = Color3.fromRGB(255, 140, 120)
local TITLE_SLOT_COLOR = Color3.fromRGB(150, 230, 150)
local TITLE_FIELD_HEIGHT = 28 -- studs over the arena for its name
local MAP_GROUND = 0
local MAP_ROAD_TOP = 0.15
local MAP_ROAD_THICK = 0.2
local MAP_EDGE = 0.6
local MAP_GATE_HEIGHT = 9
local MAP_GATE_POST = 1.4
local MAP_GATE_BAR = 1.2
local COLOR_ROAD = Color3.fromRGB(226, 200, 146)
local COLOR_ROAD_EDGE = Color3.fromRGB(150, 118, 80)
local COLOR_POND = Color3.fromRGB(70, 160, 235)
local COLOR_POND_EDGE = Color3.fromRGB(120, 105, 85)
local COLOR_GATE_START = Color3.fromRGB(150, 90, 235)
local COLOR_GATE_END = Color3.fromRGB(235, 75, 70)
local MAP_TITLE_COLOR = Color3.fromRGB(255, 230, 120)
local MAP_ROCK = "Map_Rock"
local MAP_NEST = "Map_Nest"
local MAP_ROCK_LOOK = 0.95
local MAP_ROCK_SPREAD = 0.12
local MAP_ROCK_BALL_SINK = 0.5
local MAP_NEST_LOOK = 2.05
local MAP_NEST_THICK = 0.25
local COLOR_ROCK = Color3.fromRGB(154, 149, 140)
local COLOR_NEST = Color3.fromRGB(232, 200, 120)
local NEST_TITLE_COLOR = Color3.fromRGB(255, 216, 74)
local NEST_TITLE_HEIGHT = 3
local PERCH_HEIGHT = 4.5
local PERCH_LOOK = 1.1
local COLOR_PERCH = Color3.fromRGB(150, 132, 112)
local PERCH_TITLE_COLOR = Color3.fromRGB(150, 220, 255)
local PERCH_TITLE_HEIGHT = 7.5
local BENCH_TEXT = "💤"
local BENCH_SIZE = 3
local BENCH_ABOVE = 4
local BENCH_MAX_DISTANCE = 160

local bases = {} -- [base number] = { frame, arena, owner, field, units folder, signature, carry, killLog }
local rng = Random.new()
local function rand()
	return rng:NextNumber()
end

local payKills -- defined below (pays the kills once a second)
local sendEvents -- defined below (each player's nearby bases' fight events)

local function say(player, text)
	Net.push(player, "Notice", "🦖 배치", text)
end

local function battleNotice(player, title, text, key, pinned, picture)
	if player:GetAttribute("HideDefenseNotices") then
		return
	end
	Net.push(player, "Notice", title, text, key, pinned, picture)
end

local cocoTips = {}
for _, tip in ipairs(Config.Hints.Tips) do
	cocoTips[tip.Id] = true
end

local function introduceKind(owner, profile, kindId)
	if not profile.SeenKinds or profile.SeenKinds[kindId] or cocoTips[kindId] then
		return
	end
	local k = Formulas.fossilKind(kindId)
	if not k or not k.Tip or (k.ChancePercent or 0) <= 0 then
		return
	end
	PlayerData.update(owner, function(p)
		p.SeenKinds[kindId] = true
	end)
	battleNotice(owner, string.format("🆕 새 화석: %s %s", k.Icon, k.Name),
		k.Tip .. "\n" .. string.format("💔 빠지면 ❤️ -%d", k.LeakLives or Config.Defense.Promotion.LeakLives), "Kind" .. kindId, nil,
		kindId)
end

local function assets()
	return ServerStorage:FindFirstChild("Assets")
end

-- ---------------------------------------------------------------------------
-- Arenas
-- ---------------------------------------------------------------------------

local function arenaFrame(folder)
	local arena = folder:FindFirstChild("Base_Arena", true)
	if not arena then
		return nil
	end
	local center = arena:GetPivot().Position
	local portal = folder:FindFirstChild("Base_SpawnPortal", true)
	local toward = portal and Bases.position(portal) - center or -center -- no portal: face the map center
	toward = Vector3.new(toward.X, 0, toward.Z)
	if toward.Magnitude < 1e-3 then
		toward = Vector3.new(0, 0, -1)
	end
	return CFrame.lookAt(center, center + toward.Unit), arena
end

-- monster models for the clients: ServerStorage.Assets is server-only, so copy them over once
local function shareMonsterModels()
	local source = assets()
	local folder = Instance.new("Folder")
	folder.Name = "DefenseModels"
	local names = table.clone(Config.Monsters.Models)
	table.insert(names, Config.Monsters.BossCrown)
	table.move(Config.Monsters.StatusModels, 1, #Config.Monsters.StatusModels, #names + 1, names)
	for _, kind in ipairs(Config.Defense.Kinds) do
		table.insert(names, kind.Look)
		table.insert(names, kind.Balloon)
	end
	table.insert(names, Config.Defense.Groups.FlagModel)
	for _, name in ipairs(names) do
		local model = source and source:FindFirstChild(name, true)
		if model then
			model:Clone().Parent = folder
		end
	end
	local old = ReplicatedStorage:FindFirstChild("DefenseModels")
	if old then
		old:Destroy()
	end
	folder.Parent = ReplicatedStorage
	if #folder:GetChildren() == 0 then
		warn("[Defense] Assets에 몬스터 모델(Monster_Bone...)이 없어 회색 상자로 보여줍니다")
	end

	-- dino models for the small portraits in the placement list and the draw cards (Shared/DinoPortrait)
	local dinos = Instance.new("Folder")
	dinos.Name = "DinoModels"
	local allSpecies = table.clone(Config.Species)
	table.move(Config.RebirthSpecies, 1, #Config.RebirthSpecies, #allSpecies + 1, allSpecies) -- the rebirth-only ones too
	table.move(Config.GiftSpecies, 1, #Config.GiftSpecies, #allSpecies + 1, allSpecies) -- (2026-10-04) and the gift-only ones
	for _, species in ipairs(allSpecies) do
		local model = source and source:FindFirstChild("Dino_" .. species.Id, true)
		if model then
			model:Clone().Parent = dinos
		end
	end
	-- the night's zombie dino and the boss kinds' own models (Dino_ZombieRex / Trike / Ptera): without these
	-- copies every boss was drawn as the T-Rex-shaped zombie dino
	local zombieNames = { Config.Zombies.Model, Config.Wildlife.GiantModel, Config.Wildlife.RaptorModel, -- (and the wild ones)
		Config.Zombies.Guardians.Model }
	for _, kind in ipairs(Config.Zombies.Boss.Kinds) do
		table.insert(zombieNames, kind.Model)
	end
	for _, name in ipairs(zombieNames) do
		local model = source and source:FindFirstChild(name, true)
		if model and not dinos:FindFirstChild(name) then
			model:Clone().Parent = dinos
		elseif not model then
			warn(string.format("[Defense] ServerStorage.Assets에 %s 모델이 없어요 (밤 좀비·보스 모습)", name))
		end
	end
	local oldDinos = ReplicatedStorage:FindFirstChild("DinoModels")
	if oldDinos then
		oldDinos:Destroy()
	end
	dinos.Parent = ReplicatedStorage

	-- slap toy models for the swing effect (StarterPlayerScripts/CombatFx): the level looks and the skins
	local slaps = Instance.new("Folder")
	slaps.Name = "SlapModels"
	local slapNames = table.clone(Config.Slap.Looks)
	for _, skin in ipairs(Config.Slap.Skins) do
		table.insert(slapNames, skin.Model)
	end
	for _, name in ipairs(slapNames) do
		local model = source and source:FindFirstChild(name, true)
		if model then
			model:Clone().Parent = slaps
		end
	end
	local oldSlaps = ReplicatedStorage:FindFirstChild("SlapModels")
	if oldSlaps then
		oldSlaps:Destroy()
	end
	slaps.Parent = ReplicatedStorage

	-- pickaxes, bags and mineral models for the pictures in the inventory (StarterPlayerScripts/Inventory), the next
	-- pickaxe in the ⛏️ 곡괭이 상점 (Hud) and the training stations (Training.client)
	local items = Instance.new("Folder")
	items.Name = "ItemModels"
	local itemNames = table.clone(Config.Bag.Looks)
	for tier = 1, #Config.Pickaxe.Tiers do
		table.insert(itemNames, "Pickaxe_T" .. tier)
	end
	for _, size in ipairs(Config.Minerals.Sizes) do
		table.insert(itemNames, size.Model)
	end
	for _, st in ipairs(Config.Training.Stations) do -- (2026-10-04) the training panel's picture (Training.client)
		table.insert(itemNames, st.Model)
	end
	for _, k in ipairs(Config.Bombs.Kinds) do -- (2026-10-04) the bombs: the stall window, the stall, a throw (Bombs.client)
		table.insert(itemNames, k.Model)
	end
	for _, name in ipairs(itemNames) do
		local model = source and source:FindFirstChild(name, true)
		if model then
			model:Clone().Parent = items
		end
	end
	local oldItems = ReplicatedStorage:FindFirstChild("ItemModels")
	if oldItems then
		oldItems:Destroy()
	end
	items.Parent = ReplicatedStorage
end

-- ---------------------------------------------------------------------------
-- Dinos on the platform
-- ---------------------------------------------------------------------------

local function powerText(unit, stats)
	return string.format("Lv%d · ⚔️%s", Formulas.unitLevel(unit), Formulas.shortNumber(stats.Damage + 0.5))
end

local function unitModel(unit, stats)
	local species = Formulas.species(unit.Species)
	local source = assets() and assets():FindFirstChild("Dino_" .. unit.Species, true)
	local model = Instance.new("Model")
	model.Name = unit.Id
	-- (2026-10-04) a phone gets the whole dino at once, not part by part (DefenseView puts every part by its offset)
	pcall(function()
		model.ModelStreamingMode = Enum.ModelStreamingMode.Atomic
	end)
	if source then
		source:Clone().Parent = model
		model:ScaleTo(Formulas.drawnScale(stats))
	else
		local part = Instance.new("Part")
		part.Name = "Body"
		part.Size = Vector3.new(1.4, 2.4, 2) * Formulas.drawnScale(stats)
		part.Color = THEME_COLORS[species.Theme] or Color3.new(0.6, 0.6, 0.6)
		part.Parent = model
	end
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored = true
			d.CanCollide = false
			d.CanQuery = false
		end
	end
	local cf, size = model:GetBoundingBox()
	model.PrimaryPart = nil
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))

	local gui = Instance.new("BillboardGui")
	local labelScale = math.clamp(math.sqrt(Formulas.drawnScale(stats)), 0.8, 1.4)
	gui.Size = UDim2.fromOffset(UNIT_LABEL_WIDTH * labelScale, UNIT_LABEL_HEIGHT * labelScale)
	gui.StudsOffsetWorldSpace = Vector3.new(0, size.Y + 1, 0)
	gui.MaxDistance = LABEL_MAX_DISTANCE
	gui.AlwaysOnTop = false
	local attribute = Config.Attributes[stats.Attribute]
	local rows = {
		attribute and attribute.Icon or "",
		powerText(unit, stats),
		string.format("%s · %s · %s", species.Name, Formulas.rarity(unit.Rarity).Name, Formulas.dinoSize(unit.Size).Name),
	}
	local top = 0
	for i, text in ipairs(rows) do
		local label = Instance.new("TextLabel")
		label.Name = "Row" .. i
		label.Position = UDim2.fromScale(0, top)
		label.Size = UDim2.fromScale(1, UNIT_LABEL_ROWS[i])
		label.BackgroundTransparency = 1
		label.Font = Enum.Font.GothamBold
		label.TextScaled = true
		label.TextColor3 = Color3.new(1, 1, 1)
		label.TextStrokeTransparency = 0.4
		label.Text = text
		label.Parent = gui
		top += UNIT_LABEL_ROWS[i]
	end
	gui.Parent = model

	RarityFx.apply(model, unit.Rarity, stats.Footprint) -- lights and particles by rarity
	model:SetAttribute("UnitId", unit.Id)
	model:SetAttribute("Species", unit.Species) -- its voice and attack sound on the clients (DefenseView)
	model:SetAttribute("Reach", stats.Reach)
	model:SetAttribute("Footprint", stats.Footprint)
	model:SetAttribute("Attribute", stats.Attribute)
	model:SetAttribute("Effect", stats.Effect) -- (2026-10-03) its effect's strength: how long the looks last (DefenseView)
	return model
end
Defense.unitModel = unitModel -- the farm pen shows its dinos the same way (Farm)

local function showDamage(index, report)
	local folder = Bases.folder(index)
	if folder then
		folder:SetAttribute("DamageReport", type(report) == "table" and report.U and HttpService:JSONEncode(report) or nil)
	end
end

local function unitsById(profile)
	local byId = {}
	for _, u in ipairs(profile.Units) do
		byId[u.Id] = u
	end
	return byId
end

local function signature(profile, bonuses)
	local parts = { tostring(#profile.Units), string.format("P%.6f", bonuses.UnitPower), profile.DefenseMap or FIRST_MAP }
	local levels = {}
	for _, u in ipairs(profile.Units) do
		levels[u.Id] = Formulas.unitLevel(u)
	end
	for id, pos in pairs(profile.Placed) do
		table.insert(parts, string.format("%s:%.2f:%.2f:%d:%s", id, pos.X, pos.Z, levels[id] or 1,
			profile.Targeting and profile.Targeting[id] or ""))
	end
	table.sort(parts)
	return table.concat(parts, "|")
end

local function setStats(b)
	local owner = b.owner
	if not owner then
		return
	end
	local profile = PlayerData.get(owner)
	if not profile then
		return
	end
	local now = b.field.time
	local kills = 0
	for i = #b.killLog, 1, -1 do
		if now - b.killLog[i][1] > KILL_WINDOW then
			table.remove(b.killLog, i)
		else
			kills += b.killLog[i][2]
		end
	end
	local minutes = math.min(now, KILL_WINDOW) / 60
	local perMinute = minutes > 0 and kills / minutes or 0
	owner:SetAttribute("DefenseOnTrack", #b.field.monsters)
	owner:SetAttribute("DefenseKillsPerMinute", math.floor(perMinute + 0.5))
	local money = (1 + (b.bonuses and b.bonuses.Money or 0)) * Weather.defenseMultiplier()
	owner:SetAttribute("DefenseMoneyPerMinute", math.floor(perMinute * Formulas.killReward(profile.DefenseLevel) * money + 0.5))
end

-- rebuild the dinos of a base from its owner's profile (when placements or dinos changed)
-- the defense sign shows the owner's next slot price
local function refreshSign(b, profile)
	if not b.signLabel then
		return
	end
	if not profile then
		b.signLabel.Text = "🦖 아레나"
		local nextLine = DefenseGuide.nextBossLabel(b.index)
		if nextLine then
			nextLine.Text = ""
		end
		return
	end
	local cost = Formulas.nextSlotCost(profile.Upgrades.Slots, profile.DefenseLevel)
	local slots = Formulas.profileSlots(profile, b.bonuses)
	local free = b.owner ~= nil and b.owner:GetAttribute("CocoPays") == "Slot"
	b.signLabel.Text = cost and free and string.format("🦖 아레나 · 공룡 자리 %d칸\n➕ 1칸 더: 🎁 코코가 내줘요 · 무료!", slots)
		or cost and string.format("🦖 아레나 · 공룡 자리 %d칸\n➕ 1칸 더: 💰 %s원", slots, Formulas.shortNumber(cost))
		or string.format("🦖 아레나 · 공룡 자리 %d칸\n✅ 다 늘렸어요!", slots)
	local nextLine = DefenseGuide.nextBossLabel(b.index) -- the attribute board beside the defense guide
	if nextLine then
		local attribute = Formulas.bossAttribute(profile.DefenseLevel + 1)
		local a, w = Config.Attributes[attribute], Config.Attributes[Formulas.bossWeakness(attribute)]
		nextLine.Text = string.format("👑 다음 보스 %s %s · %s %s 공룡이 ×%g 세요!", a.Icon, a.Name, w.Icon, w.Name,
			Config.Defense.Boss.WeaknessDamageMultiplier)
	end
end

local function mapPart(parent, size, cframe, color, shape)
	local part = Instance.new("Part")
	part.Anchored = true
	part.CanCollide = false
	part.CanQuery = false
	part.CanTouch = false
	part.CastShadow = false
	part.Material = Enum.Material.SmoothPlastic
	part.TopSurface = Enum.SurfaceType.Smooth
	part.Size = size
	part.CFrame = cframe
	part.Color = color
	if shape then
		part.Shape = shape
	end
	part.Parent = parent
	return part
end

local function mapGate(b, folder, path, i, color, title, modelName)
	local n = #path.x
	local j = i == 1 and 2 or n - 1
	local dx, dz = path.x[i] - path.x[j], path.z[i] - path.z[j]
	local len = math.sqrt(dx * dx + dz * dz)
	dx, dz = dx / len, dz / len
	local center = b.frame * Vector3.new(path.x[i], MAP_GROUND, path.z[i])
	local source = assets()
	local template = source and source:FindFirstChild(modelName, true)
	if template then
		local gate = template:Clone()
		if not gate:IsA("Model") then
			local wrap = Instance.new("Model")
			gate.Parent = wrap
			gate = wrap
		end
		for _, d in ipairs(gate:GetDescendants()) do
			if d:IsA("BasePart") then
				d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
			end
		end
		local cf, size = gate:GetBoundingBox()
		gate.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
		local inward = b.frame:VectorToWorldSpace(Vector3.new(-dx, 0, -dz))
		gate:PivotTo(CFrame.lookAt(center, center + inward))
		gate.Name = modelName
		gate.Parent = folder
		Bases.title(gate, title, color, false)
		return
	end
	local across = b.frame:VectorToWorldSpace(Vector3.new(-dz, 0, dx))
	local half = Config.Defense.TrackHalfWidth + MAP_GATE_POST
	for _, side in ipairs({ -1, 1 }) do
		local at = center + across * side * half + Vector3.yAxis * MAP_GATE_HEIGHT / 2
		mapPart(folder, Vector3.new(MAP_GATE_POST, MAP_GATE_HEIGHT, MAP_GATE_POST), CFrame.new(at), color).CanCollide = true
	end
	local bar = mapPart(folder, Vector3.new(half * 2 + MAP_GATE_POST, MAP_GATE_BAR, MAP_GATE_POST),
		CFrame.fromMatrix(center + Vector3.yAxis * MAP_GATE_HEIGHT, across, Vector3.yAxis), color)
	bar.Material = Enum.Material.Neon
	Bases.title(bar, title, color, false)
end

local function mapProp(template, folder, cframe, width, collide)
	local prop = template:Clone()
	if not prop:IsA("Model") then
		local wrap = Instance.new("Model")
		prop.Parent = wrap
		prop = wrap
	end
	for _, d in ipairs(prop:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch, d.CastShadow = true, collide, false, false, false
		end
	end
	prop.ModelStreamingMode = Enum.ModelStreamingMode.Atomic
	local cf, size = prop:GetBoundingBox()
	prop.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
	local wide = math.max(size.X, size.Z)
	if wide > 0 then
		prop:ScaleTo(prop:GetScale() * width / wide)
	end
	prop:PivotTo(cframe)
	prop.Parent = folder
	return prop
end

local function mapRocks(b, folder, map)
	local R = Config.Defense.Rocks
	local source = assets()
	local rock = source and source:FindFirstChild(MAP_ROCK, true)
	local nest = source and source:FindFirstChild(MAP_NEST, true)
	for i, p in ipairs(Formulas.mapRocks(map.Id)) do
		local at = b.frame * Vector3.new(p[1], MAP_GROUND, p[2])
		local turn = CFrame.Angles(0, (i * 2.39996) % (2 * math.pi), 0)
		local wide = R.Radius * 2 * MAP_ROCK_LOOK * (1 - MAP_ROCK_SPREAD * ((i * 7) % 3) / 2)
		if rock then
			mapProp(rock, folder, CFrame.new(at) * b.frame.Rotation * turn, wide, false).Name = "Rock"
		else
			local ball = mapPart(folder, Vector3.one * wide, CFrame.new(at + Vector3.yAxis * (wide / 2 - MAP_ROCK_BALL_SINK)),
				COLOR_ROCK, Enum.PartType.Ball)
			ball.Name = "Rock"
			ball.CanCollide = false
		end
	end
	for _, n in ipairs(map.Nests or {}) do
		local at = b.frame * Vector3.new(n[1], MAP_GROUND, n[2])
		local pad
		if nest then
			pad = mapProp(nest, folder, CFrame.new(at) * b.frame.Rotation, R.Nest.Pocket * MAP_NEST_LOOK, false)
		else
			pad = mapPart(folder, Vector3.new(MAP_NEST_THICK, R.Nest.Pocket * 2, R.Nest.Pocket * 2),
				CFrame.new(at + Vector3.yAxis * MAP_NEST_THICK / 2) * CFrame.Angles(0, 0, math.pi / 2), COLOR_NEST,
				Enum.PartType.Cylinder)
		end
		pad.Name = "Nest"
		Bases.title(pad, string.format("🐣 둥지 · 한 마리만 · 📏 +%d%%", math.floor(R.Nest.ReachBonus * 100 + 0.5)),
			NEST_TITLE_COLOR, false, NEST_TITLE_HEIGHT)
	end
	local P = Config.Defense.Perch
	local perch = source and source:FindFirstChild(P.Model, true)
	for _, p in ipairs(map.Perches or {}) do
		local at = b.frame * Vector3.new(p[1], MAP_GROUND, p[2])
		local pillar
		if perch then
			pillar = mapProp(perch, folder, CFrame.new(at) * b.frame.Rotation, P.Radius * 2 * PERCH_LOOK, true)
		else
			pillar = mapPart(folder, Vector3.new(PERCH_HEIGHT, P.Radius * 2, P.Radius * 2),
				CFrame.new(at + Vector3.yAxis * PERCH_HEIGHT / 2) * CFrame.Angles(0, 0, math.pi / 2), COLOR_PERCH,
				Enum.PartType.Cylinder)
			pillar.CanCollide = true
		end
		pillar.Name = "Perch"
		Bases.title(pillar, string.format("🏔️ 하늘 바위 · 🦅 하늘 공룡만 · 📏 +%d%%", math.floor(P.ReachBonus * 100 + 0.5)),
			PERCH_TITLE_COLOR, false, PERCH_TITLE_HEIGHT)
	end
end

local function arenaShown(b, shown)
	local list = b.arena:GetDescendants()
	local portal = Bases.folder(b.index):FindFirstChild("Base_SpawnPortal", true)
	if portal then
		table.move(portal:GetDescendants(), 1, #portal:GetDescendants(), #list + 1, list)
	end
	for _, d in ipairs(list) do
		if d:IsA("BasePart") then
			if d:GetAttribute("MapT") == nil then
				d:SetAttribute("MapT", d.Transparency)
				d:SetAttribute("MapC", d.CanCollide)
			end
			d.Transparency = shown and d:GetAttribute("MapT") or 1
			d.CanCollide = shown and d:GetAttribute("MapC") or false
		elseif d:IsA("Decal") or d:IsA("Texture") then
			d.Transparency = shown and 0 or 1
		end
	end
end

local function buildMap(b, mapId)
	local map = Formulas.defenseMap(mapId)
	if b.mapId == map.Id then
		return
	end
	b.mapId = map.Id
	local folder = Bases.folder(b.index)
	local old = folder:FindFirstChild("DefenseMap")
	if old then
		old:Destroy()
	end
	local parts = Instance.new("Model")
	parts.Name = "DefenseMap"
	local path = Formulas.lanePath(map.Id)
	arenaShown(b, false)
	local width = Config.Defense.TrackHalfWidth * 2
	local y = MAP_ROAD_TOP - MAP_ROAD_THICK / 2
	for i = 1, #path.x - 1 do
		local a = b.frame * Vector3.new(path.x[i], y, path.z[i])
		local c = b.frame * Vector3.new(path.x[i + 1], y, path.z[i + 1])
		local len = (c - a).Magnitude
		local cf = CFrame.lookAt((a + c) / 2, c)
		mapPart(parts, Vector3.new(width + MAP_EDGE * 2, MAP_ROAD_THICK * 0.6, len), cf, COLOR_ROAD_EDGE)
		mapPart(parts, Vector3.new(width, MAP_ROAD_THICK, len), cf, COLOR_ROAD)
		if i > 1 then
			mapPart(parts, Vector3.new(MAP_ROAD_THICK, width, width), CFrame.new(a) * CFrame.Angles(0, 0, math.pi / 2),
				COLOR_ROAD, Enum.PartType.Cylinder)
		end
	end
	local pondRadius = Config.Defense.Pond.Radius
	for _, pond in ipairs(map.Ponds or {}) do
		local at = b.frame * Vector3.new(pond[1], y, pond[2])
		local flat = CFrame.new(at) * CFrame.Angles(0, 0, math.pi / 2)
		mapPart(parts, Vector3.new(MAP_ROAD_THICK * 0.6, (pondRadius + MAP_EDGE) * 2, (pondRadius + MAP_EDGE) * 2), flat,
			COLOR_POND_EDGE, Enum.PartType.Cylinder)
		local water = mapPart(parts, Vector3.new(MAP_ROAD_THICK, pondRadius * 2, pondRadius * 2), flat, COLOR_POND,
			Enum.PartType.Cylinder)
		if water then
			water.Name = "Pond"
			water.Material = Enum.Material.Glass
			water.Transparency = 0.15
		end
	end
	mapRocks(b, parts, map)
	mapGate(b, parts, path, 1, COLOR_GATE_START, "🚪 화석 나오는 문", Config.Defense.Gates.Start)
	mapGate(b, parts, path, #path.x, COLOR_GATE_END, "🏁 끝 문 (💔 ❤️)", Config.Defense.Gates.End)
	parts.Parent = folder
	folder:SetAttribute("DefenseMap", map.Id)
	folder:SetAttribute("DefenseUnitTop", MAP_GROUND)
	folder:SetAttribute("DefensePerchTop", MAP_GROUND + PERCH_HEIGHT)
	Bases.title(b.arena, string.format("🛡️ %s %s", map.Icon, map.Name), MAP_TITLE_COLOR, true, TITLE_FIELD_HEIGHT)
end

local function benchMark(model, on)
	local mark = model:FindFirstChild("Bench")
	model:SetAttribute("Bench", on or nil)
	if not on then
		if mark then
			mark:Destroy()
		end
		return
	end
	if mark then
		return
	end
	local _, size = model:GetBoundingBox()
	mark = Instance.new("BillboardGui")
	mark.Name = "Bench"
	mark.Size = UDim2.fromScale(BENCH_SIZE, BENCH_SIZE)
	mark.StudsOffsetWorldSpace = Vector3.new(0, size.Y + BENCH_ABOVE, 0)
	mark.MaxDistance = BENCH_MAX_DISTANCE
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.TextScaled = true
	text.Text = BENCH_TEXT
	text.Parent = mark
	mark.Parent = model
end

local function refreshUnits(b, profile)
	-- the farm, the collection and rebirths (Formulas.bonuses): unit power, monster slow, money, slots
	local bonuses = Formulas.bonuses(profile)
	b.bonuses = bonuses
	b.field.slow = bonuses.MonsterSlow
	local sig = signature(profile, bonuses)
	local owner = b.owner
	owner:SetAttribute("DefenseSlots", Formulas.profileSlots(profile, bonuses))
	refreshSign(b, profile)
	if sig == b.signature then
		return
	end
	local byId = unitsById(profile)
	local list, placed = {}, 0
	local keep = {}
	local made, waiting = 0, false
	local bench = {}
	if b.twist then
		local team = {}
		for id in pairs(profile.Placed) do
			if byId[id] then
				table.insert(team, { Id = id, Stats = Formulas.unitStats(byId[id]) })
			end
		end
		bench = Formulas.twistBench(b.twist, team, b.promoLevel)
	end
	for id, pos in pairs(profile.Placed) do
		local unit = byId[id]
		if unit then
			local stats = Formulas.placedStats(Formulas.unitStats(unit), b.field.mapId, pos.X, pos.Z)
			stats.Damage *= 1 + bonuses.UnitPower
			table.insert(list, { Id = id, Species = unit.Species, X = pos.X, Z = pos.Z, Stats = stats, Target = profile.Targeting and profile.Targeting[id],
				Rest = bench[id] })
			placed += 1
			keep[id] = true
			local model = b.unitsFolder:FindFirstChild(id)
			local key = unit.Species .. unit.Rarity .. unit.Size .. Formulas.unitLevel(unit)
			if (not model or model:GetAttribute("Key") ~= key) and made >= UNIT_MODELS_PER_STEP then
				waiting = true
			elseif not model or model:GetAttribute("Key") ~= key then
				made += 1
				if model then
					model:Destroy()
				end
				model = unitModel(unit, stats)
				model:SetAttribute("Key", key)
				model.Parent = b.unitsFolder
			end
			if not model then
				continue
			end
			local power = model:FindFirstChild("Row2", true)
			if power then
				power.Text = powerText(unit, stats)
			end
			local at = b.frame * Vector3.new(pos.X, MAP_GROUND + (stats.Perch and PERCH_HEIGHT or 0), pos.Z)
			local _, along = Formulas.laneDistance(b.field.path, pos.X, pos.Z)
			local rx, rz = Formulas.lanePoint(b.field.path, along, 0)
			local out = b.frame:VectorToWorldSpace(Vector3.new(rx - pos.X, 0, rz - pos.Z))
			if out.Magnitude < 1e-3 then
				out = b.frame.LookVector
			end
			model:SetAttribute("Target", profile.Targeting and profile.Targeting[id] or "Auto")
			model:SetAttribute("Reach", stats.Reach)
			model:SetAttribute("Nest", stats.Nest)
			model:SetAttribute("Perch", stats.Perch)
			benchMark(model, bench[id] == true)
			local rest = CFrame.lookAt(at, at + out.Unit)
			if model:GetAttribute("Rest") ~= rest then -- (2026-10-04: only when it moved; was every dino at every change)
				model:PivotTo(rest)
				model:SetAttribute("Rest", rest) -- clients animate around this (DefenseView)
			end
		end
	end
	for _, model in ipairs(b.unitsFolder:GetChildren()) do
		if not keep[model.Name] then
			model:Destroy()
		end
	end
	DefenseLogic.setUnits(b.field, list)
	owner:SetAttribute("DefensePlaced", placed)
	owner:SetAttribute("UnitsVersion", (owner:GetAttribute("UnitsVersion") or 0) + 1)
	b.signature = not waiting and sig or nil
	if waiting and not b.unitsWaiting then
		b.unitsWaiting = true
		task.delay(UNIT_MODEL_STEP_DELAY, function()
			b.unitsWaiting = nil
			local p = b.owner == owner and PlayerData.get(owner)
			if p then
				refreshUnits(b, p)
			end
		end)
	end
end

-- ---------------------------------------------------------------------------
-- Owners coming and going
-- ---------------------------------------------------------------------------

local function clearPromoAttributes(player)
	for _, name in ipairs({ "PromoLevel", "PromoTimeLeft", "PromoOnTrack", "PromoBoss", "PromoLives", "PromoGroup", "PromoShell", "PromoImmune", "PromoAirship", "PromoSprinter", "PromoTwist" }) do
		player:SetAttribute(name, nil)
	end
end

local CHALLENGE_LIVE = { "ChallengeWave", "ChallengeWaveLeft", "ChallengeOnTrack", "ChallengeLives" }

-- ♾️ 무한 도전: the best of this week and ever on the player (the window and the server ranking read them)
local function showChallengeBest(player, profile)
	local week = RewardLogic.weekNumber(os.time())
	local c = profile and profile.Challenge
	player:SetAttribute("ChallengeBest", c and c.Week == week and c.Best or 0)
	player:SetAttribute("ChallengeAllBest", c and c.AllBest or 0)
end

-- this many waves cleared in the run so far: into the save when it is more than already counted (this week's
-- best, the milestones reached pay at once)
local function countWaves(b, owner, waves)
	if waves <= (b.challengeCounted or 0) then
		return
	end
	Rewards.add(owner, "ChallengeWave", waves - (b.challengeCounted or 0)) -- (2026-10-03: the tutorial field's ♾️ step)
	b.challengeCounted = waves
	local newBest, reached = false, {}
	PlayerData.update(owner, function(p)
		newBest, reached = RewardLogic.finishChallenge(p, RewardLogic.weekNumber(os.time()), waves)
	end)
	showChallengeBest(owner, PlayerData.get(owner))
	for _, m in ipairs(reached) do
		Rewards.grant(owner, m.Reward, string.format("♾️ 무한 도전 %d판 버텼어요!", m.Wave))
	end
	return newBest
end

-- the run is over (lost, given up, or the owner left): the last count, the notice, the ranking
local function finishChallenge(b, owner, waves)
	for _, name in ipairs(CHALLENGE_LIVE) do
		owner:SetAttribute(name, nil)
	end
	countWaves(b, owner, waves)
	b.challengeCounted = nil
	if owner.Parent then
		local best = owner:GetAttribute("ChallengeBest") or 0
		battleNotice(owner, "♾️ 무한 도전 끝", string.format("♾️ %d판 버텼어요! 이번 주 최고 %d판%s\n🏅 이번 주 1위는 %s! 순위는 ♾️ 창에서",
			waves, best, waves >= best and waves > 0 and " 🎉 새 기록!" or "",
			Formulas.starterRewardText(Config.Defense.Challenge.RankRewards[1].Reward)))
	end
	Leaderboards.challengeBest(owner)
end

-- (2026-10-03, "오프라인 동안 번 돈이 자기 지금 디펜스로 버는 양에 비례해야지") the idle money a second, over about the
-- last Offline.RateMemoryMinutes (older play counts less and less), into the profile once enough was watched
local function saveIdleRate(b)
	local o = Config.Rewards.Offline
	local owner = b.owner
	if not owner or (b.idleTime or 0) < o.MinRateMinutes * 60 or not PlayerData.isLoaded(owner) then
		return
	end
	local rate = b.idleMoney / b.idleTime
	PlayerData.update(owner, function(p)
		p.Stats.IdleMoneyRate = rate
	end)
end

local function gaugeNeed(profile)
	return Formulas.promoKillsNeeded(profile.DefenseLevel + 1)
end

local function saveGauge(b, now)
	local owner = b.owner
	if not owner or not b.gauge or b.gauge == b.gaugeSaved or not PlayerData.isLoaded(owner) then
		return
	end
	if not now and os.clock() - (b.gaugeSavedAt or 0) < Config.Defense.Promotion.Gauge.SaveEvery then
		return
	end
	local value = math.floor(b.gauge)
	PlayerData.update(owner, function(p)
		p.PromoKills = value
	end)
	b.gaugeSaved, b.gaugeSavedAt = b.gauge, os.clock()
end

local function showGauge(b, profile)
	local owner = b.owner
	if not owner or not profile or not b.gauge then
		return
	end
	local atTop = profile.DefenseLevel >= Formulas.maxDefenseLevel(profile.Rebirths or 0)
	local share = not atTop and math.floor(math.clamp(b.gauge / gaugeNeed(profile), 0, 1) * 100) / 100 or nil
	if owner:GetAttribute("PromoGauge") ~= share then
		owner:SetAttribute("PromoGauge", share)
	end
end

local function stop(index)
	local b = bases[index]
	if not b or not b.owner then
		return
	end
	saveIdleRate(b)
	saveGauge(b, true)
	b.bossWarnAt = nil
	b.gauge = nil
	clearPromoAttributes(b.owner)
	b.field.promotion = nil
	b.twist = nil
	local waves = DefenseLogic.cancelChallenge(b.field)
	if waves then
		finishChallenge(b, b.owner, waves)
	end
	b.owner = nil
	b.signature = nil
	DefenseGuide.showAdvice(index, false) -- (2026-10-05) the 🩺 board of an empty base
	showDamage(index, nil)
	local damageFolder = Bases.folder(index)
	if damageFolder then
		damageFolder:SetAttribute("LiveDamageReport", nil)
	end
	b.helpers, b.helperCount = nil, 0
	DefenseLogic.clear(b.field)
	DefenseLogic.setUnits(b.field, {})
	b.unitsFolder:ClearAllChildren()
	b.clearQueued = true -- clients drop this base's monsters
	refreshSign(b, nil)
	buildMap(b, FIRST_MAP)
	DefenseLogic.setMap(b.field, FIRST_MAP)
	DefenseLogic.takeEvents(b.field)
end

local function start(player)
	local index = Bases.of(player)
	local b = index and bases[index]
	local profile = PlayerData.get(player)
	if not b or not profile or b.owner == player then
		return
	end
	stop(index)
	-- more placed than slots (the slots from levels went away on 2026-10-01): the extra ones come off
	local placedIds = {}
	for id in pairs(profile.Placed) do
		table.insert(placedIds, id)
	end
	local slots = Formulas.profileSlots(profile)
	if #placedIds > slots then
		table.sort(placedIds)
		PlayerData.update(player, function(p)
			for i = slots + 1, #placedIds do
				p.Placed[placedIds[i]] = nil
			end
		end)
		profile = PlayerData.get(player)
		say(player, string.format("➕ 공룡 자리가 %d칸뿐이라 %d마리를 내려놨어요 (공룡은 그대로 있어요)", slots, #placedIds - slots))
	end
	b.owner = player
	if not Formulas.mapOpen(profile.DefenseMap, profile.Rebirths, profile.DefenseLevel) then
		PlayerData.update(player, function(p)
			p.DefenseMap = FIRST_MAP
		end)
		profile = PlayerData.get(player)
	end
	if (profile.MapLayout or 0) < Config.Defense.LayoutVersion then
		local byId = unitsById(profile)
		local team = {}
		for id in pairs(profile.Placed) do
			if byId[id] then
				table.insert(team, { Id = id, Stats = Formulas.unitStats(byId[id]) })
			end
		end
		local placed = Formulas.autoLayout(team, profile.DefenseMap)
		PlayerData.update(player, function(p)
			p.Placed = placed
			p.MapPlacements = {}
			p.MapLayout = Config.Defense.LayoutVersion
		end)
		profile = PlayerData.get(player)
		if #team > 0 then
			Net.push(player, "Notice", "🗺️ 디펜스 맵이 넓어졌어요!", "🦖 공룡을 새 길에 맞춰 놓았어요! 바꾸려면 🦖 배치")
		end
	end
	do
		local byId = unitsById(profile)
		local keep, wrong, seaMoved, rockMoved, perchMoved = {}, {}, 0, 0, 0
		local nestTaken, perchTaken = {}, {}
		for id, pos in pairs(profile.Placed) do
			local unit = byId[id]
			if unit then
				local st = Formulas.unitStats(unit)
				local sea = Formulas.isSea(st)
				local inPond = Formulas.pondAt(profile.DefenseMap, pos.X, pos.Z, sea and 0.5 or st.Footprint) ~= nil
				local onRock = not sea and Formulas.rockAt(profile.DefenseMap, pos.X, pos.Z, st.Footprint) ~= nil
				local nest = not sea and not onRock and Formulas.nestAt(profile.DefenseMap, pos.X, pos.Z, st.Footprint)
				if nest and nestTaken[nest] then
					onRock = true
				elseif nest then
					nestTaken[nest] = true
				end
				local perch, spot = Formulas.perchAt(profile.DefenseMap, pos.X, pos.Z, not sea and st.Footprint or 0)
				local perchWrong = perch ~= nil and (sea or not Formulas.isSky(st) or perchTaken[perch]
					or math.abs(pos.X - spot[1]) > 0.05 or math.abs(pos.Z - spot[2]) > 0.05)
				if perch and not perchWrong then
					perchTaken[perch] = true
				end
				if perchWrong then
					table.insert(wrong, { Id = id, Stats = st })
					perchMoved += 1
				elseif onRock then
					table.insert(wrong, { Id = id, Stats = st })
					rockMoved += 1
				elseif inPond == sea then
					table.insert(keep, { X = pos.X, Z = pos.Z, Footprint = st.Footprint })
				else
					table.insert(wrong, { Id = id, Stats = st })
					seaMoved += sea and 1 or 0
				end
			end
		end
		if #wrong > 0 then
			local moved = Formulas.autoLayout(wrong, profile.DefenseMap, keep)
			PlayerData.update(player, function(p)
				for _, u in ipairs(wrong) do
					p.Placed[u.Id] = moved[u.Id]
				end
			end)
			profile = PlayerData.get(player)
			if seaMoved > 0 then
				Net.push(player, "Notice", "🌊 바다 공룡은 이제 연못에서 싸워요!",
					string.format("🌊 바다 공룡 %d마리를 연못으로 옮겼어요 · 파도로 화석을 뒤로 밀어요", seaMoved))
			end
			if rockMoved > 0 then
				Net.push(player, "Notice", "🗺️ 맵의 바위·둥지가 바뀌었어요!",
					string.format("🦖 바위·둥지에 걸린 공룡 %d마리를 옮겼어요 · 🐣 둥지엔 한 마리만!", rockMoved))
			end
			if perchMoved > 0 then
				Net.push(player, "Notice", "🏔️ 하늘 바위가 생겼어요!",
					string.format("🦖 하늘 바위에 걸린 공룡 %d마리를 옮겼어요 · 🏔️ 하늘 바위엔 🦅 하늘 공룡만!", perchMoved))
			end
		end
	end
	b.field = DefenseLogic.newField(profile.DefenseMap)
	b.rebirthsSeen = profile.Rebirths or 0
	player:SetAttribute("DefenseMap", b.field.mapId)
	buildMap(b, b.field.mapId)
	b.carry = 0
	b.killLog = {}
	b.idleMoney, b.idleTime, b.idleSavedAt = 0, 0, os.clock()
	b.gauge = profile.PromoKills or 0
	b.gaugeSaved, b.gaugeSavedAt = b.gauge, os.clock()
	showGauge(b, profile)
	refreshUnits(b, profile)
	setStats(b)
	local advice = profile.PromoAdvice -- (2026-10-05) the owner's last lost fight, on the 🩺 board
	DefenseGuide.showAdvice(index, advice and advice.Head and advice or nil)
	showDamage(index, profile.PromoDamage)
end

-- the kills' money and mission count, once a second (2026-10-01: paying every tick ran every
-- PlayerData.onChanged listener ten times a second per player and could stall the server)
payKills = function(b)
	local owner = b.owner
	if not owner then
		b.carry, b.fossils = 0, 0
		return
	end
	if (b.fossils or 0) > 0 then
		Rewards.add(owner, "Fossils", b.fossils)
		b.fossils = 0
	end
	if b.carry >= 1 then
		local whole = math.floor(b.carry)
		b.carry -= whole
		PlayerData.addMoney(owner, whole, "defense")
	end
	saveGauge(b)
	showGauge(b, PlayerData.get(owner))
end

local function baseOf(player)
	for index, b in pairs(bases) do
		if b.owner == player then
			return index, b
		end
	end
	return nil
end

-- ---------------------------------------------------------------------------
-- Requests
-- ---------------------------------------------------------------------------

local function atOwnArena(player)
	local _, b = baseOf(player)
	if not b then
		say(player, "⏳ 내 기지가 아직 준비되지 않았어요")
		return nil
	end
	if not Bases.near(player, b.arena, Config.Placement.EditRange) then
		say(player, "🦖 내 기지 아레나 가까이에서 놓을 수 있어요")
		return nil
	end
	return b
end

local function placeUnit(player, unitId, x, z)
	local b = atOwnArena(player)
	local profile = PlayerData.get(player)
	if not b or not profile then
		return
	end
	local unit = unitsById(profile)[unitId]
	if not unit then
		return say(player, "없는 공룡이에요")
	end
	if profile.Farm[unitId] then
		return say(player, "🌾 농장에 있는 공룡이에요! 농장에서 먼저 빼요")
	end
	local stats = Formulas.unitStats(unit)
	local others = {}
	local byId = unitsById(profile)
	local count = 0
	for id, pos in pairs(profile.Placed) do
		if id ~= unitId and byId[id] then
			count += 1
			table.insert(others, { X = pos.X, Z = pos.Z, Footprint = Formulas.unitStats(byId[id]).Footprint })
		end
	end
	local sea, sky = Formulas.isSea(stats), Formulas.isSky(stats)
	if sea then
		local _, pond = Formulas.pondAt(b.field.mapId, x, z, Config.Defense.Pond.Snap)
		if pond then
			x, z = pond[1], pond[2]
		end
	elseif sky and Formulas.perchAt(b.field.mapId, x, z, Config.Defense.Perch.Snap) then
		x, z = Formulas.perchSnap(b.field.mapId, x, z)
	else
		x, z = Formulas.nestSnap(b.field.mapId, x, z, stats.Footprint)
	end
	local fits, why = Formulas.placementFits(x, z, stats.Footprint, others, b.field.mapId, sea, sky)
	if not fits then
		return say(player, why)
	end
	local slots = Formulas.profileSlots(profile)
	if not profile.Placed[unitId] and count >= slots then
		return say(player, string.format("공룡 자리 %d칸이 꽉 찼어요! ➕ 칸을 사거나 레벨을 올려요", slots))
	end
	PlayerData.update(player, function(p)
		p.Placed[unitId] = { X = math.floor(x * 100 + 0.5) / 100, Z = math.floor(z * 100 + 0.5) / 100 }
	end)
	Rewards.add(player, "DeckAdjust", 1)
	Rewards.add(player, "Place", 1) -- (the tutorial's "place a dino" steps)
	if sky and Formulas.perchAt(b.field.mapId, x, z) then
		Rewards.add(player, "PerchPlace", 1)
	end
	return true
end

-- one more placement slot, bought at the player's own arena (Config.Placement.SlotUpgrade, very dear)
-- from the "➕ 공룡 자리 늘리기" prompt on the player's own defense sign
local function buySlot(player)
	local _, b = baseOf(player)
	local profile = PlayerData.get(player)
	if not b or not profile or not b.sign then
		return
	end
	if not Bases.near(player, b.sign, Config.Placement.SignRange + SIGN_SLACK) then
		return say(player, "➕ 아레나 앞 표지판에서 살 수 있어요")
	end
	local bought = profile.Upgrades.Slots
	local cost = Formulas.nextSlotCost(bought, profile.DefenseLevel)
	if not cost then
		return say(player, "➕ 공룡 자리를 다 늘렸어요!")
	end
	local free = player:GetAttribute("CocoPays") == "Slot"
	if not free and not PlayerData.spendMoney(player, cost, "slot") then
		return say(player, string.format("💰 돈이 모자라요 (%s원 필요)", Formulas.shortNumber(cost)))
	end
	PlayerData.update(player, function(p)
		p.Upgrades.Slots = bought + 1
		if free then
			p.Starter.CocoPaid = p.Starter.CocoPaid or {}
			p.Starter.CocoPaid.Slot = true
		end
	end)
	if free then
		player:SetAttribute("CocoPays", nil)
	end
	say(player, string.format(free and "🎁 코코가 내줬어요! ➕ 공룡 자리 +1! 이제 %d칸" or "➕ 공룡 자리 +1! 이제 %d칸",
		Formulas.profileSlots(PlayerData.get(player))))
	Rewards.add(player, "SlotBuy", 1) -- (2026-10-03: the tutorial field's ➕ 배치 칸 step)
end

local function removeUnit(player, unitId)
	local b = atOwnArena(player)
	local profile = PlayerData.get(player)
	if not b or not profile or not profile.Placed[unitId] then
		return
	end
	PlayerData.update(player, function(p)
		p.Placed[unitId] = nil
	end)
	return true
end

local function mapWinsText(profile)
	local ids = {}
	for id in pairs(profile.MapWins or {}) do
		table.insert(ids, id)
	end
	table.sort(ids)
	return table.concat(ids, ",")
end

local function switchMap(player, mapId, opened)
	local _, b = baseOf(player)
	local profile = PlayerData.get(player)
	if not b or not profile then
		return
	end
	local map = Formulas.defenseMap(mapId)
	if map.Id ~= mapId or not Formulas.mapOpen(mapId, profile.Rebirths, profile.DefenseLevel) then
		if map.Level then
			return say(player, string.format("🔒 %s %s: %s부터 열려요", map.Icon, map.Name,
				Formulas.levelText(Formulas.mapUnlockLevel(map))))
		end
		return say(player, string.format("🔒 %s %s: 🔄 환생 %d번에 열려요", map.Icon, map.Name, map.Rebirths))
	end
	if b.field.promotion or b.field.challenge then
		return say(player, "⚔️ 싸우는 중엔 맵을 못 바꿔요")
	end
	local from = profile.DefenseMap or FIRST_MAP
	if from == mapId then
		return
	end
	local byId = unitsById(profile)
	local saved = profile.MapPlacements and profile.MapPlacements[mapId]
	local placed = {}
	if saved then
		local others, lost = {}, {}
		for id, pos in pairs(saved) do
			local unit = byId[id]
			local st = unit and Formulas.unitStats(unit)
			local fp = st and st.Footprint
			if unit and not profile.Farm[id] and Formulas.placementFits(pos.X, pos.Z, fp, others, mapId, Formulas.isSea(st),
				Formulas.isSky(st)) then
				placed[id] = { X = pos.X, Z = pos.Z }
				table.insert(others, { X = pos.X, Z = pos.Z, Footprint = fp })
			elseif unit and not profile.Farm[id] then
				table.insert(lost, { Id = id, Stats = st })
			end
		end
		for id, at in pairs(Formulas.autoLayout(lost, mapId, others)) do
			placed[id] = at
		end
	else
		local team = {}
		for id in pairs(profile.Placed) do
			if byId[id] then
				table.insert(team, { Id = id, Stats = Formulas.unitStats(byId[id]) })
			end
		end
		placed = Formulas.autoLayout(team, mapId)
	end
	local ids = {}
	for id in pairs(placed) do
		table.insert(ids, id)
	end
	table.sort(ids)
	for i = Formulas.profileSlots(profile) + 1, #ids do
		placed[ids[i]] = nil
	end
	PlayerData.update(player, function(p)
		p.MapPlacements = p.MapPlacements or {}
		p.MapPlacements[from] = table.clone(p.Placed)
		p.DefenseMap = mapId
		p.Placed = placed
	end)
	DefenseLogic.setMap(b.field, mapId)
	buildMap(b, mapId)
	player:SetAttribute("DefenseMap", mapId)
	b.signature = nil
	refreshUnits(b, PlayerData.get(player))
	if opened then
		Net.push(player, "Notice", "🗺️ 새 맵이 열렸어요!", string.format("%s %s · %s\n🦖 공룡을 새 길에 맞춰 놓았어요! 바꾸려면 🦖 배치",
			map.Icon, map.Name, map.Tip))
	else
		say(player, string.format("🗺️ %s %s! %s", map.Icon, map.Name, map.Tip))
		Rewards.add(player, "MapSwitch", 1)
	end
end

-- ---------------------------------------------------------------------------
-- Promotion fights
-- ---------------------------------------------------------------------------

local function retryAt(player, profile)
	local wait = (profile.PromotionRetryAt or 0) - os.time()
	player:SetAttribute("PromoRetryAt", wait > 0 and Workspace:GetServerTimeNow() + wait or nil)
	return wait
end

local function boardDone(profile)
	return type(profile.Starter) ~= "table" or profile.Starter.Done == true
end

local function promoReady(b, owner, profile)
	return #b.field.units > 0 and (profile.PromotionRetryAt or 0) <= os.time()
		and profile.DefenseLevel < Formulas.maxDefenseLevel(profile.Rebirths or 0)
		and not owner:GetAttribute("TutorialStep") and not owner:GetAttribute("FirstFight")
		and not owner:GetAttribute("CocoIntro") and not TutorialField.isField()
end

local function autoReady(b, owner, profile)
	return promoReady(b, owner, profile) and not profile.PromoAutoOff and boardDone(profile)
end

local helpNoticeAt = setmetatable({}, { __mode = "k" })

local function callFriends(owner)
	local now = os.clock()
	for _, other in ipairs(Players:GetPlayers()) do
		if other ~= owner and Friends.known(owner, other)
			and now - (helpNoticeAt[other] or -math.huge) >= Config.Help.FriendNoticeEvery then
			helpNoticeAt[other] = now
			Net.push(other, "Notice", "🤝 같이 찰싹",
				string.format("친구 %s님의 보스 웨이브! 그 아레나에서 👋 찰싹으로 도와요", owner.DisplayName))
		end
	end
end

local function thankHelpers(b, owner, won)
	local helpers = b.helpers
	b.helpers, b.helperCount = nil, 0
	if not won or not helpers then
		return
	end
	local day = RewardLogic.dayNumber(os.time())
	local names = {}
	for id, h in pairs(helpers) do
		local helper = h and h.Slaps >= Config.Help.MinSlaps and Players:GetPlayerByUserId(id)
		local profile = helper and PlayerData.get(helper)
		if profile then
			table.insert(names, helper.DisplayName)
			if RewardLogic.helpOpen(profile, day) then
				PlayerData.update(helper, function(p)
					RewardLogic.helped(p, day)
					RewardLogic.apply(p, { Keys = Config.Help.Keys })
				end)
				Net.push(helper, "Notice", "🤝 같이 깼어요!",
					string.format("%s님의 보스 웨이브를 같이 깼어요! 🔑 +%d", owner.DisplayName, Config.Help.Keys))
			else
				Net.push(helper, "Notice", "🤝 같이 깼어요!",
					string.format("%s님의 보스 웨이브를 같이 깼어요! 오늘 🔑 고마움은 다 받았어요", owner.DisplayName))
			end
		end
	end
	if #names > 0 then
		Net.push(owner, "Notice", "🤝 고마워요!", string.format("%s님 덕분에 깼어요!", table.concat(names, " · ")))
	end
end

local function startPromotion(player, auto)
	local _, b = baseOf(player)
	local profile = PlayerData.get(player)
	if not b or not profile then
		return say(player, "⏳ 내 기지가 아직 준비되지 않았어요")
	end
	if b.field.promotion then
		return
	end
	if b.field.challenge then
		return say(player, "♾️ 무한 도전 중엔 보스 도전을 못 해요")
	end
	local wait = retryAt(player, profile)
	if wait > 0 then
		return say(player, string.format("⏱️ %d초 뒤에 다시 해요! 그동안 공룡 자리를 바꿔 봐요", wait))
	end
	if #b.field.units == 0 then
		return say(player, "🦖 공룡을 먼저 놓아요!")
	end
	local rebirths = profile.Rebirths or 0
	if profile.DefenseLevel >= Formulas.maxDefenseLevel(rebirths) then -- the top of the tier: rebirth opens the next
		return say(player, string.format("🏆 끝 레벨 %s! 🔄 환생하면 %s부터 더 세게 (스폰 옆 표지판)",
			Formulas.levelText(profile.DefenseLevel, rebirths), Formulas.levelText(profile.DefenseLevel + 1, rebirths + 1)))
	end
	b.promoLevel = profile.DefenseLevel + 1
	-- the tutorial's first run: its promotion's monsters a share as tough (player attribute TutorialEasy)
	b.field.promoHealthScale = player:GetAttribute("TutorialEasy") and Config.Tutorial.PromotionHealthShare or 1
	local twist, eased, why = Formulas.activeTwist(profile, b.promoLevel)
	b.twist = twist
	if twist then
		b.field.promoHealthScale *= twist.Health
		b.signature = nil
		refreshUnits(b, profile)
	end
	DefenseLogic.startPromotion(b.field, true)
	b.helpers, b.helperCount = {}, 0
	callFriends(player)
	b.promoAuto = auto == true
	b.bossWarnAt = nil
	b.reviveUntil = nil
	local reviveId = Config.Monetization.ProductIds.PromotionRevive or 0
	b.field.reviveOffer = not player:GetAttribute("TutorialEasy") and not player:GetAttribute("FirstFight")
		and (reviveId > 0 or RunService:IsStudio()) and "can" or nil
	player:SetAttribute("PromoLevel", b.promoLevel)
	player:SetAttribute("PromoTwist", twist and twist.Id or nil)
	if twist then
		Story.sayFirst(player, "TwistFirst", "Twist", Story.explain("Twist"), Formulas.twistText(twist, b.promoLevel))
	end
	player:SetAttribute("PromoFailNote", nil) -- (2026-10-04: a new try)
	player:SetAttribute("PromoLossKind", nil)
	player:SetAttribute("PromoLossHead", nil)
	player:SetAttribute("PromoLossWho", nil)
	local w = Config.Attributes[Formulas.bossWeakness(Formulas.bossAttribute(b.promoLevel))]
	local parts = { string.format("약점 %s", w.Icon), string.format("🦴 %d마리", Formulas.bossCrowdCount(b.promoLevel)) }
	if twist then
		table.insert(parts, 1, "🎲 " .. Formulas.twistText(twist, b.promoLevel))
	elseif eased then
		table.insert(parts, 1, why == "Losses" and "🎲 두 번 져서 이번엔 변칙 없이 싸워요"
			or string.format("🎲 %s 공룡이 없어서 이번엔 모두 싸워요", eased.Icon))
	end
	if Formulas.bossAirships(b.promoLevel) > 0 then
		table.insert(parts, "🎈 비행선")
	end
	local icons = {}
	for _, g in ipairs(Formulas.fightGroups(b.promoLevel)) do
		table.insert(icons, Formulas.groupIcon(g))
	end
	if #icons > 0 then
		table.insert(parts, "🚩 " .. table.concat(icons, ""))
	end
	table.insert(parts, string.format("❤️ %d · 👑 빠지면 끝", Config.Defense.Promotion.Lives))
	battleNotice(player, string.format("👑 %s 보스 등장!", Formulas.levelText(b.promoLevel, rebirths)),
		table.concat(parts, " · "), "BossWave", true)
end

local function bestLayout(profile, mapId, fromFarm)
	local skip = {}
	for id in pairs(profile.Farm) do
		if not fromFarm or profile.FarmLock[id] then
			skip[id] = true
		end
	end
	for _, id in ipairs(profile.Starter.MergeDinos or {}) do
		skip[id] = true
	end
	local level = profile.DefenseLevel + 1
	local team = Formulas.recommendTeam(profile.Units, Formulas.profileSlots(profile), level, mapId, skip,
		Formulas.activeTwist(profile, level))
	return #team > 0 and Formulas.autoLayout(team, mapId) or {}, team
end

local function autoArrange(player)
	local _, b = baseOf(player)
	local profile = PlayerData.get(player)
	if not b or not profile then
		return false
	end
	local layout, team = bestLayout(profile, b.field.mapId, true)
	if next(layout) == nil then
		say(player, "🦖 놓을 공룡이 없어요")
		return false
	end
	local count, fromFarm = 0, 0
	PlayerData.update(player, function(p)
		p.Placed = {}
		for id, at in pairs(layout) do
			p.Placed[id] = { X = at.X, Z = at.Z }
			count += 1
			if p.Farm[id] then
				p.Farm[id] = nil
				fromFarm += 1
			end
		end
	end)
	refreshUnits(b, PlayerData.get(player))
	local bossIcon = Config.Attributes[Formulas.bossAttribute(profile.DefenseLevel + 1)].Icon
	Rewards.add(player, "AutoPlace", 1)
	Rewards.add(player, "DeckAdjust", 1)
	local twist = Formulas.activeTwist(profile, profile.DefenseLevel + 1)
	if twist and twist.Id ~= "Ace" then
		say(player, string.format("🎲 다음 변칙 승급전에 맞는 공룡부터 놓았어요: %s", Formulas.twistText(twist, profile.DefenseLevel + 1)))
	end
	if fromFarm > 0 then
		player:SetAttribute("UnitsVersion", (player:GetAttribute("UnitsVersion") or 0) + 1)
		say(player, string.format("✨ 다음 보스 %s에 맞춰 공룡 %d마리를 놓았어요! (🌾 농장에서 %d마리, 🔒 잠근 공룡은 그대로)",
			bossIcon, count, fromFarm))
	else
		say(player, string.format("✨ 다음 보스 %s에 맞춰 공룡 %d마리를 놓았어요!", bossIcon, count))
	end
	return true
end

-- the owner slaps the fossils on their own track (Combat): the nearest few in reach (more at higher slap
-- levels, Formulas.slapFossilTargets); returns where each was
-- hit (world), nearest first (empty when none)
function Defense.revive(player)
	local _, b = baseOf(player)
	local promo = b and b.field.promotion
	if not promo or b.field.reviveOffer ~= "asking" then
		PlayerData.update(player, function(p)
			p.PromotionRetryAt = 0
		end)
		retryAt(player, PlayerData.get(player))
		return false
	end
	promo.lives = Config.Products.PromotionRevive.Lives
	b.field.reviveOffer = "used"
	b.reviveUntil = nil
	DefenseLogic.resume(b.field)
	player:SetAttribute("PromoLives", promo.lives)
	return true
end

local function slapField(b, p, reach, slapLevel)
	local spots = {}
	for _, m in ipairs(DefenseLogic.slapMonster(b.field, p.X, p.Z, reach, Formulas.slapFossilDamage(slapLevel),
		Config.Slap.FossilSplashRadius, Config.Slap.FossilSplashShare,
		Formulas.slapFossilTargets(slapLevel), Config.Slap.FossilBossShare, Config.Slap.FossilPush, Config.Slap.FossilBossPush)) do
		table.insert(spots, b.frame * Vector3.new(m.x, FOSSIL_HIT_Y, m.z))
	end
	return spots
end

local function helpSlap(helper, position, reach, slapLevel)
	local id = helper.UserId
	for _, b in pairs(bases) do
		local owner = b.owner
		local p = owner and owner ~= helper and b.helpers and b.field.promotion and not b.field.challenge
			and b.frame:PointToObjectSpace(position)
		if p and math.abs(p.Y) <= Config.Slap.FossilHeight and DefenseLogic.inReach(b.field, p.X, p.Z, reach) then
			local mine = b.helpers[id]
			if mine == nil and b.helperCount >= Config.Help.MaxHelpers then
				b.helpers[id] = false
				Net.push(helper, "Notice", "🤝 같이 찰싹", string.format("도와주는 사람이 다 찼어요 (최대 %d명)", Config.Help.MaxHelpers))
			elseif mine ~= false then
				local ownerProfile = PlayerData.get(owner)
				local level = Formulas.helpSlapLevel(slapLevel,
					ownerProfile and Formulas.trained(ownerProfile.Upgrades, ownerProfile.Training).Slap or 1)
				local spots = slapField(b, p, reach, level)
				if #spots > 0 then
					if not mine then
						mine = { Slaps = 0 }
						b.helpers[id] = mine
						b.helperCount += 1
						Net.push(owner, "Notice", "🤝 같이 찰싹", string.format("%s님이 보스 웨이브를 도와줘요!", helper.DisplayName))
						Net.push(helper, "Notice", "🤝 같이 찰싹",
							string.format("%s님의 보스 웨이브를 도와요! 같이 이기면 🔑", owner.DisplayName))
						Analytics.custom(helper, "HelpSlap")
					end
					mine.Slaps += #spots
					Net.push(helper, "FossilSlap", #spots)
					return spots
				end
			end
		end
	end
	return {}
end

function Defense.slapFossil(player, position, reach, slapLevel)
	local _, b = baseOf(player)
	if not PlayerData.get(player) then
		return {}
	end
	local p = b and b.frame:PointToObjectSpace(position)
	local spots = p and math.abs(p.Y) <= Config.Slap.FossilHeight and slapField(b, p, reach, slapLevel) or {}
	if #spots > 0 then
		Net.push(player, "FossilSlap", #spots)
		Rewards.add(player, "PromoSlap", #spots)
		return spots
	end
	return helpSlap(player, position, reach, slapLevel)
end

function Defense.bombFossils(player, kind, position, reach, slapLevel)
	local _, b = baseOf(player)
	if not b or b.owner ~= player then
		return {}
	end
	local p = b.frame:PointToObjectSpace(position)
	if math.abs(p.Y) > Config.Slap.FossilHeight then
		return {}
	end
	local hit
	if kind == "Poop" then
		hit = DefenseLogic.holdMonsters(b.field, p.X, p.Z, reach, Config.Bombs.FossilHoldSeconds,
			Config.Bombs.FossilBossHoldSeconds)
	else
		hit = DefenseLogic.slapMonster(b.field, p.X, p.Z, reach,
			Formulas.slapFossilDamage(slapLevel) * Config.Bombs.FossilDamageMultiplier, nil, nil, nil, Config.Slap.FossilBossShare)
	end
	local spots = {}
	for _, m in ipairs(hit) do
		table.insert(spots, b.frame * Vector3.new(m.x, FOSSIL_HIT_Y, m.z))
	end
	if #spots > 0 then
		Rewards.add(player, "BombFossil", 1)
	end
	return spots
end

local finishPromotion -- defined below
local promotionAdvice -- defined right below

-- (2026-10-01, "a reborn tester can't pass the next defense level and doesn't know what to do") after a lost
-- promotion: how far the fight got (the boss's health left), what to do, the boss's attribute, and for a
-- reborn player that the tier's LV 1 is really the next level after the last tier's top
function promotionAdvice(b, profile, level)
	local lines = {}
	local left = b.field.lastBossLeft
	if left then
		table.insert(lines, string.format("👑 보스 체력이 %d%% 남았어요", math.ceil(left * 100)))
	else
		table.insert(lines, "🏁 화석이 너무 많이 빠졌어요! 한꺼번에 때리는 공룡을 길 끝 쪽에도 놓아요")
	end
	table.insert(lines, "더 세지려면: 🦖 공룡 키우기 · 🔑 좋은 열쇠로 뽑기 · 🌾 농장 · ➕ 공룡 자리")
	local attribute = Formulas.bossAttribute(level)
	local a, w = Config.Attributes[attribute], Config.Attributes[Formulas.bossWeakness(attribute)]
	table.insert(lines, string.format("👑 보스는 %s %s · %s %s 공룡이 ×%g 세요 · %s 공룡은 ×%g", a.Icon, a.Name,
		w.Icon, w.Name, Config.Defense.Boss.WeaknessDamageMultiplier, a.Name, Config.Defense.Boss.SameAttributeDamageMultiplier))
	local rebirths = profile and profile.Rebirths or 0
	if rebirths > 0 then
		table.insert(lines, string.format("🔄 환생 %d번: 화석은 LV 1부터 다시, 대신 체력 ×%g", rebirths,
			Formulas.tierHealthMultiplier(rebirths)))
	end
	return table.concat(lines, "\n")
end

local function cancelPromotion(player)
	local _, b = baseOf(player)
	if b and b.owner == player and DefenseLogic.cancelPromotion(b.field) then
		finishPromotion(b, player, "fail", "cancel")
	end
end

local function startChallenge(player)
	if not Unlocks.check(player, "Challenge") then
		return
	end
	local _, b = baseOf(player)
	local profile = PlayerData.get(player)
	if not b or b.owner ~= player or not profile then
		return say(player, "⏳ 내 기지가 아직 준비되지 않았어요")
	end
	if b.field.challenge then
		return
	end
	if not profile.Tutorial.Done and not TutorialField.isField() then -- (2026-10-03: the field's ♾️ step tries it)
		return say(player, "🐣 튜토리얼을 끝내면 도전할 수 있어요")
	end
	if #b.field.units == 0 then
		if next(profile.Placed) ~= nil then
			return say(player, "🦖 공룡을 먼저 놓아요!")
		end
		autoArrange(player)
		if #b.field.units == 0 then
			return
		end
	end
	local bossAside = DefenseLogic.cancelPromotion(b.field)
	if bossAside then
		clearPromoAttributes(player)
		player:SetAttribute("FirstFight", nil)
		b.promoAuto = nil
		b.reviveUntil = nil
		b.field.reviveOffer = nil
	end
	b.bossWarnAt = nil
	b.challengeCounted = 0
	local rule = Formulas.challengeRule(RewardLogic.weekNumber(os.time()))
	DefenseLogic.startChallenge(b.field, rule)
	player:SetAttribute("ChallengeWave", 1)
	local c = Config.Defense.Challenge
	say(player, string.format("♾️ 무한 도전 시작! %d초마다 더 세져요 · ❤️ %d개 다 잃으면 끝", c.WaveSeconds, c.Lives))
	say(player, string.format("이번 주 규칙 %s: %s", rule.Name, rule.Text))
	if bossAside then
		say(player, "👑 보스 웨이브는 무한 도전이 끝나면 다시 와요")
	end
end

local function cancelChallenge(player)
	local _, b = baseOf(player)
	local waves = b and b.owner == player and DefenseLogic.cancelChallenge(b.field)
	if waves then
		finishChallenge(b, player, waves)
	end
end

-- (2026-10-03) the tutorial field ends its ♾️ try when the step is done
function Defense.stopChallenge(player)
	cancelChallenge(player)
end

local function applyPromotion(b, owner, twist)
	owner:SetAttribute("PromoFailNote", nil) -- (2026-10-04: won)
	owner:SetAttribute("PromoLossKind", nil)
	owner:SetAttribute("PromoLossHead", nil)
	owner:SetAttribute("PromoLossWho", nil)
	PlayerData.update(owner, function(p) -- (2026-10-05) passed: the 🩺 board's advice goes
		p.PromoAdvice = {}
	end)
	DefenseGuide.showAdvice(b.index, nil)
	Rewards.add(owner, "Promotion", 1) -- daily missions, the weekly challenge
	local level = b.promoLevel
	local profile = PlayerData.get(owner)
	local first = profile and level > profile.DefenseLevel -- keys only the first time a level is won
	local nextTier = profile and profile.Upgrades.PickaxeTier + 1
	local opensPickaxe = first and Formulas.pickaxeNeedLevel(nextTier) ~= nil
		and not Formulas.pickaxeOpen(nextTier, profile.DefenseLevel) and Formulas.pickaxeOpen(nextTier, level)
	local keys = first and Formulas.promotionKeys(level) or {}
	local twistKeys = (first and twist) and Formulas.twistBonusKeys(level) or 0
	if twistKeys > 0 then
		keys = table.clone(keys)
		keys.Normal = (keys.Normal or 0) + twistKeys
	end
	local prize = first and Formulas.promotionFirstWin(level) or nil
	local prizeParts = first and Formulas.promotionPrizeParts(level) or {}
	local mapId = profile and profile.DefenseMap
	local mapFirst = mapId and mapId ~= FIRST_MAP and not (profile.MapWins and profile.MapWins[mapId])
	local mapPrize = mapFirst and Formulas.mapFirstWin(Formulas.defenseMap(mapId))
	PlayerData.update(owner, function(p)
		p.DefenseLevel = math.max(p.DefenseLevel, level)
		for kind, n in pairs(keys) do
			Formulas.addSavedKeys(p, kind, n)
		end
		if prize then
			if (prize.Keys or 0) > 0 then
				Formulas.addSavedKeys(p, "Normal", prize.Keys)
			end
			for kind, n in pairs(prize.SpecialKeys or {}) do
				Formulas.addSavedKeys(p, kind, n)
			end
			if prize.GuaranteedRarity then
				p.GuaranteedDraws = p.GuaranteedDraws or {}
				p.GuaranteedDraws[prize.GuaranteedRarity] = (p.GuaranteedDraws[prize.GuaranteedRarity] or 0) + 1
			end
			if prize.LuckMinutes then
				p.LuckUntil = math.max(p.LuckUntil or 0, os.time()) + prize.LuckMinutes * 60
			end
		end
		if mapFirst then
			p.MapWins = p.MapWins or {}
			p.MapWins[mapId] = true
			Formulas.addSavedKeys(p, mapPrize.Key, mapPrize.Count)
		end
	end)
	local boxGrade = first and Formulas.promotionBox(level)
	if boxGrade and not Gacha.giveBox(owner, boxGrade) then
		PlayerData.update(owner, function(p)
			Formulas.addSavedKeys(p, boxGrade, 1)
		end)
	end
	local after = PlayerData.get(owner)
	if prize and prize.LuckMinutes and after then
		owner:SetAttribute("Luck", Config.StarterMissions.LuckMultiplier)
		owner:SetAttribute("LuckEndsAt", after.LuckUntil)
	end
	if prize and prize.GuaranteedRarity and after then
		local n = 0
		for _, k in pairs(after.GuaranteedDraws or {}) do
			n += k
		end
		owner:SetAttribute("GuaranteedDraws", n)
	end
	if mapFirst then
		owner:SetAttribute("MapWins", mapWinsText(PlayerData.get(owner)))
		local map = Formulas.defenseMap(mapId)
		say(owner, string.format("🗺️ %s %s 첫 승리! 🔑 %s %d개", map.Icon, map.Name, Formulas.keyType(mapPrize.Key).Name, mapPrize.Count))
	end
	if first then
		for _, map in ipairs(Formulas.mapsOpenedAt(level)) do
			Net.push(owner, "Notice", "🗺️ 새 맵이 열렸어요!", string.format("%s %s · %s\n👆 아레나 옆 🗺️ 맵 게시판에서 골라요",
				map.Icon, map.Name, map.Tip))
		end
	end
	if twist then
		Rewards.add(owner, "TwistWin", 1)
		table.insert(prizeParts, 1, string.format("🎲 변칙 보너스 🔑 +%d", twistKeys))
	elseif Formulas.twistRule(level) then
		Rewards.add(owner, "TwistWin", 1)
	end
	battleNotice(owner, twist and "🎲 변칙 승급 성공!" or "⚔️ 승급 성공!",
		string.format("디펜스 %s!", Formulas.levelText(level, profile and profile.Rebirths))
		.. (#prizeParts > 0 and ("\n" .. table.concat(prizeParts, " · ")) or ""))
	if opensPickaxe then
		Net.push(owner, "Notice", "⛏️ 새 곡괭이가 열렸어요!", string.format("⛏️ %s 곡괭이 (%d티어) · ⛏️ 곡괭이 상점으로",
			Config.Pickaxe.Tiers[nextTier].Name, nextTier))
	end
	if first and level == 2 then
		Story.firstWin(owner)
	end
end

-- (2026-10-05, "거기 실패 이유를 적어주자. 이번에 어떤 점이 가장 부족했는지 평가해서 거기 통과할때까지 올려주는거야") a
-- lost fight judged (Formulas.promoWeakness): the one thing most lacking, in a big picture and a few lines for the 🩺 board
-- (DefenseGuide.showAdvice) and the fail window; saved (profile PromoAdvice) until a level is won
local function lines(...)
	return table.concat({ ... }, "\n")
end

local FAR_NAMES = 3

local function damageReport(b, owner, won, live)
	local profile = PlayerData.get(owner)
	if not profile then
		return nil
	end
	local byId = unitsById(profile)
	local mode = b.field.promotion and "Boss" or b.field.challenge and "Challenge" or "Normal"
	local dealt = live and (mode == "Boss" and b.field.dealt or mode == "Challenge" and b.field.challengeDealt or b.field.idleDealt) or b.field.lastDealt
	dealt = dealt or {}
	local list, seen, total = {}, {}, 0
	local function add(id, u)
		local unit = byId[id]
		if seen[id] or not unit then
			return
		end
		seen[id] = true
		local d = math.floor((dealt[id] or 0) + 0.5)
		total += d
		table.insert(list, { I = id, S = unit.Species, R = unit.Rarity, Z = unit.Size, E = Formulas.unitLevel(unit),
			A = u and u.Stats.Attribute or Formulas.unitStats(unit).Attribute, D = d,
			H = u and (u.Stats.SlowAura or u.Stats.Attribute == "Ice" or u.Stats.Attribute == "Water") and true or nil,
			F = u and not u.active and not u.Rest and 1 or nil, Q = u and u.Rest and 1 or nil })
	end
	for _, u in ipairs(b.field.units) do
		add(u.Id, u)
	end
	for id in pairs(dealt) do
		add(id, nil)
	end
	table.sort(list, function(x, y)
		if x.D ~= y.D then
			return x.D > y.D
		end
		return x.I < y.I
	end)
	return { L = live and mode == "Normal" and profile.DefenseLevel or b.promoLevel, W = won, T = os.time(),
		N = total, U = list, M = live and mode or "Boss", Live = live or nil, Y = b.field.synergies }
end

local function farNames(b, profile)
	local byId = profile and unitsById(profile) or {}
	local names, more = {}, 0
	for _, u in ipairs(b.field.units) do
		if not u.active and not u.Rest and byId[u.Id] then
			if #names < FAR_NAMES then
				table.insert(names, Formulas.unitName(byId[u.Id]))
			else
				more += 1
			end
		end
	end
	if more > 0 then
		table.insert(names, string.format("외 %d마리", more))
	end
	return table.concat(names, " · ")
end

local function judgeLoss(b, owner, reason)
	local profile = PlayerData.get(owner)
	local level = b.promoLevel
	local boss = Formulas.bossAttribute(level)
	local weak = Formulas.bossWeakness(boss)
	local units = {}
	for _, u in ipairs(b.field.units) do
		table.insert(units, { Attack = u.Stats.Attack, Attribute = u.Stats.Attribute, Theme = u.Stats.Theme, active = u.active,
			Rest = u.Rest })
	end
	local bought = profile and profile.Upgrades and profile.Upgrades.Slots or 0
	local kind, c = Formulas.promoWeakness({ reason = (b.field.lastLeakBoss or reason == "time" or (b.field.lastCrowdLeft == 0 and (b.field.lastBossLeft or 0) > 0)) and "boss" or "leak", units = units,
		slots = owner:GetAttribute("DefenseSlots") or #units, bossAttribute = boss, weakAttribute = weak, twist = b.twist,
		leakedKinds = b.field.lastLeakKinds, crowd = Formulas.bossCrowdCount(level),
		moreSlots = bought < #Config.Placement.SlotUpgrade.Cost })
	local B, a, w = Config.Defense.Boss, Config.Attributes[boss], Config.Attributes[weak]
	local icon, head, body
	local who = nil
	if kind == "Placement" then
		icon, head = "📍", "공룡이 길에서 너무 멀어요"
		who = farNames(b, profile)
		body = lines(string.format("📍 공격을 못 한 공룡 %d마리", c.far), "🦖 " .. who,
			"🦖 공룡 배치에서 화석 길 가까이 옮겨요", "📊 옆 간판에서 공룡마다 피해를 봐요")
	elseif kind == "Twist" then
		icon, head = b.twist.Icon, "변칙 규칙에 맞는 공룡이 모자라요"
		body = lines(string.format("🎲 %s", Formulas.twistText(b.twist, level)), string.format("💤 쉬는 공룡 %d마리", c.rest),
			"✨ 자동 배치: 규칙에 맞는 공룡부터 놓아요", "🎲 2번 지면 다음엔 변칙 없이 싸워요")
	elseif kind == "Slots" then
		icon, head = "➕", "빈 공룡 자리가 있어요"
		body = lines(string.format("➕ %d칸이 비어 있어요", c.empty), "🦖 공룡 배치에서 공룡을 더 놓아요")
	elseif kind == "Hidden" or kind == "Immune" then
		local k = Formulas.fossilKind(c.kind)
		icon = k.Icon
		if kind == "Hidden" then
			head = "유령 화석을 못 찾았어요"
			body = lines(string.format("%s %s · %s", k.Icon, k.Name, k.Tip), "🦖 공룡 배치에서 🌊 바다 공룡을 연못에 놓아요")
		else
			head = "안 통하는 화석이 빠져나갔어요"
			body = lines(string.format("%s %s · %s", k.Icon, k.Name, k.Tip),
				string.format("🚫 안 통하는 공룡 %d/%d마리", c.blocked, c.placed), "🦖 다른 종류·속성 공룡을 섞어요")
		end
	elseif kind == "Few" then
		icon, head = "➕", "공룡 수가 모자라요"
		body = lines(string.format("🦴 무리 %d마리 · 🦖 공룡 %d마리", c.crowd, c.placed), "👆 아레나 앞 표지판에서 '공룡 자리 늘리기'",
			"👋 보스 웨이브 땐 화석 무리를 찰싹!")
	elseif kind == "Area" then
		icon, head = "🦴", "한꺼번에 때리는 공룡이 모자라요"
		body = lines("🏁 화석이 끝 문으로 빠져나갔어요",
			string.format("💥 범위 공격(밟기·관통·물) 공룡 %d/%d마리", c.area, c.placed), "🎰 범위 공격 공룡을 뽑아 놓아요")
	elseif kind == "Matchup" then
		icon, head = w.Icon, "보스 약점 공룡이 모자라요"
		body = lines(string.format("👑 보스는 %s %s · %s %s 공룡이 ×%g", a.Icon, a.Name, w.Icon, w.Name, B.WeaknessDamageMultiplier),
			string.format("%s 공룡 %d마리 · 보스와 같은 %s 공룡 %d마리(×%g)", w.Icon, c.weak, a.Icon, c.same,
				B.SameAttributeDamageMultiplier), string.format("🎰 %s %s 공룡을 놓아요", w.Icon, w.Name))
	else
		icon, head = "⚔️", "공격력이 모자라요"
		local left = b.field.lastBossLeft
		body = lines(left and string.format("👑 보스 체력이 %d%% 남았어요", math.ceil(left * 100)) or "🦴 화석을 다 못 잡았어요",
			"🔧 공룡 강화 · ⭐ 레벨업", "🎰 좋은 열쇠로 뽑기 · 🌾 농장")
	end
	local plan = profile and DeckAdvice.plan(profile, b.field, kind, level, Formulas.activeTwist(profile, level), c.kind)
	if plan then
		plan.Map = b.field.mapId
		body = DeckAdvice.describe(profile, plan) .. "\n" .. body
	end
	local before = profile and profile.PromoAdvice
	local tries = (before and before.Level == level and before.Tries or 0) + 1
	local advice = { Level = level, Tries = tries, Kind = kind, Icon = icon, Head = head, Body = body, Who = who, Plan = plan, Enemy = c.kind }
	PlayerData.update(owner, function(p)
		p.PromoAdvice = advice
	end)
	DefenseGuide.showAdvice(b.index, advice)
	return advice
end

local function applyDeckAdvice(player)
	local _, b = baseOf(player)
	local profile = PlayerData.get(player)
	if not b or not profile or b.field.promotion or b.field.challenge then return false end
	if os.clock() - (b.deckAppliedAt or 0) < Config.Defense.Promotion.Advice.RequestCooldown then return false end
	b.deckAppliedAt = os.clock()
	local advice = profile.PromoAdvice
	local old = advice and advice.Plan
	if not old or old.Action == "Enhance" or old.Action == "Review" or advice.Level ~= profile.DefenseLevel + 1 then return false end
	local plan = DeckAdvice.plan(profile, b.field, advice.Kind, advice.Level,
		Formulas.activeTwist(profile, advice.Level), advice.Enemy)
	if plan.In ~= old.In or plan.Out ~= old.Out or plan.Action ~= old.Action or old.Map ~= b.field.mapId then
		plan.Map = b.field.mapId
		PlayerData.update(player, function(p) p.PromoAdvice.Plan = plan end)
		player:SetAttribute("PromoDeckPlan", DeckAdvice.describe(profile, plan))
		player:SetAttribute("PromoDeckAction", plan.Action)
		return say(player, "🦖 덱이 바뀌었어요. 새 추천을 확인해요")
	end
	PlayerData.update(player, function(p)
		if plan.Out then p.Placed[plan.Out] = nil end
		p.Placed[plan.In] = { X = plan.X, Z = plan.Z }
		p.PromoAdvice.Plan = nil
	end)
	b.signature = nil
	refreshUnits(b, PlayerData.get(player))
	player:SetAttribute("PromoDeckAction", nil)
	player:SetAttribute("PromoDeckPlan", "✅ 추천 배치 완료! 피해량과 조합을 확인해요")
	Rewards.add(player, "DeckAdjust", 1)
	return true
end

local function endTwist(b, owner)
	if not b.twist then
		return
	end
	b.twist = nil
	b.signature = nil
	local profile = PlayerData.get(owner)
	if profile then
		refreshUnits(b, profile)
	end
end

function finishPromotion(b, owner, result, reason)
	clearPromoAttributes(owner)
	thankHelpers(b, owner, result == "success")
	owner:SetAttribute("FirstFight", nil)
	if reason ~= "cancel" then
		local report = damageReport(b, owner, result == "success")
		if report then
			PlayerData.update(owner, function(p)
				p.PromoDamage = report
			end)
			showDamage(b.index, report)
			owner:SetAttribute("DamageAt", report.T)
		end
	end
	local auto = b.promoAuto
	b.promoAuto = nil
	if b.gauge then
		local profile = PlayerData.get(owner)
		b.gauge = result == "success" and 0
			or profile and math.floor(gaugeNeed(profile) * Config.Defense.Promotion.Gauge.RetryShare) or 0
		saveGauge(b, true)
		showGauge(b, PlayerData.get(owner))
	end
	if result == "success" then
		Rewards.add(owner, "PromoPerfect", 1)
		if b.field.mapId ~= Config.Defense.Maps[1].Id then
			Rewards.add(owner, "NewMapWin", 1)
		end
		PlayerData.update(owner, function(p)
			p.PromoAssist = nil
			p.PromoAutoOff = nil
		end)
		owner:SetAttribute("PromoAutoOff", nil)
		applyPromotion(b, owner, b.twist)
		endTwist(b, owner)
		return
	end
	if reason ~= "cancel" then
		local firstLoss = not (PlayerData.get(owner) or {}).LostOnce
		PlayerData.update(owner, function(p)
			local streak = p.PromoAssist
			p.PromoAssist = { Level = b.promoLevel,
				Losses = (streak and streak.Level == b.promoLevel and streak.Losses or 0) + 1 }
			p.LostOnce = true
		end)
		if firstLoss then
			Unlocks.restage(owner)
		end
		Rewards.add(owner, "PromotionFailed", 1)
	end
	Rewards.add(owner, "PromotionLost", 1) -- (Coco's lessons; the starter pack no longer, 2026-10-04)
	local before = PlayerData.get(owner) or {}
	local wasAuto = not before.PromoAutoOff and boardDone(before)
	PlayerData.update(owner, function(p)
		p.PromotionRetryAt = os.time() + Config.Defense.Promotion.RetryCooldown
		p.PromoAutoOff = true
	end)
	owner:SetAttribute("PromoAutoOff", boardDone(before) or nil)
	if wasAuto then
		Net.push(owner, "Notice", "⏸️ 자동 보스 웨이브 멈춤", "🦖 공룡을 키우고 다시 놓은 뒤 '⚔️ 보스 도전'을 직접 눌러요 · 이기면 다시 자동!")
	end
	retryAt(owner, PlayerData.get(owner))
	local advice = reason ~= "cancel" and judgeLoss(b, owner, reason)
	local text = reason == "cancel" and "🏳️ 승급전을 포기했어요. 공룡 자리를 바꾸고 다시 해 봐요"
		or reason == "leak" and not b.field.lastLeakBoss and "💔 ❤️를 다 잃었어요! 🎯 공격 대상 '🏁 맨 앞' · ❄️ 얼음 공룡을 써 봐요"
		or "👑 보스를 못 잡았어요! 화석 나오는 문 가까이에 공룡을 모아요"
	local near = Config.Defense.Promotion.Gauge.NearMiss
	local crowdLeft, bossLeft = b.field.lastCrowdLeft, b.field.lastBossLeft or 0
	if reason ~= "cancel" and crowdLeft and crowdLeft <= near.Crowd and bossLeft <= near.Boss then
		text = string.format("😮 아깝다! 👑 보스 %d%% · 🦴 %d마리만 남았었어요", math.ceil(bossLeft * 100), crowdLeft) .. "\n" .. text
	end
	if reason ~= "cancel" then
		text = (advice.Plan and DeckAdvice.describe(PlayerData.get(owner), advice.Plan) .. "\n" or "")
			.. text .. "\n" .. string.format("🩺 가장 부족한 것: %s %s", advice.Icon, advice.Head) .. "\n"
			.. promotionAdvice(b, PlayerData.get(owner), b.promoLevel)
	end
	if reason == "cancel" then
		Net.push(owner, "Notice", "🏳️ 승급전 포기", text)
	else
		battleNotice(owner, b.field.lastLeakBoss and "👑 보스가 끝 문을 지나갔어요" or "💔 ❤️를 다 잃었어요",
			string.format("🩺 %s %s", advice.Icon, advice.Head))
		owner:SetAttribute("PromoLossKind", advice.Kind)
		owner:SetAttribute("PromoLossHead", advice.Icon .. " " .. advice.Head)
		owner:SetAttribute("PromoLossWho", advice.Who)
		owner:SetAttribute("PromoDeckPlan", advice.Plan and DeckAdvice.describe(PlayerData.get(owner), advice.Plan))
		owner:SetAttribute("PromoDeckAction", advice.Plan and advice.Plan.Action)
		owner:SetAttribute("PromoLostAt", Workspace:GetServerTimeNow())
	end
	-- (2026-10-04, "승급전실패 왜인지 알려주는 기능 있네. 근데너무잠깐지나가잖아", "어디 적어놔주든가 해야지") written down: why it
	-- was lost and what to do, kept until the next fight starts or a level is won; the screen opens it in a window
	-- that stays until closed, and again from the 승급전 button while the retry waits (StarterPlayerScripts/Placement)
	if reason ~= "cancel" and not auto then
		owner:SetAttribute("PromoFailNote", text)
	end
	endTwist(b, owner)
end

-- ---------------------------------------------------------------------------
-- The fight loop
-- ---------------------------------------------------------------------------

-- each player gets the events of the bases near them (Config.Defense.EventRange) and their own; a base
-- that just came near starts with all its monsters ("C" then an "S" for each, from the snapshot)
local subscribed = {} -- [player] = { [baseIndex] = true }
sendEvents = function(batch)
	-- (2026-10-02, "진행중인 남의 기지 들어갔는데 서버지연 걸렸어 … 서버지연 일으킬만한 문제들 전부 해결해") the health
	-- events (H, about half of a busy fight's bytes: tools/load_bench) go only to the track's owner, the only one
	-- with health bars; the others get the rest (spawns, speeds, deaths, attacks)
	local byBase, byBaseLite = {}, {}
	for _, item in ipairs(batch) do
		byBase[item[1]] = byBase[item[1]] or {}
		byBaseLite[item[1]] = byBaseLite[item[1]] or {}
		for _, e in ipairs(item[2]) do
			table.insert(byBase[item[1]], e)
			if e[1] ~= "H" then
				table.insert(byBaseLite[item[1]], e)
			end
		end
	end
	local packed, packedLite = {}, {}
	local now = Workspace:GetServerTimeNow()
	local range, leave = Config.Defense.EventRange, Config.Defense.EventLeaveRange
	for _, player in ipairs(Players:GetPlayers()) do
		local subs = subscribed[player]
		if not subs then
			subs = {}
			subscribed[player] = subs
		end
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		local list = {}
		for index, b in pairs(bases) do
			local d = root and (Vector3.new(root.Position.X, 0, root.Position.Z)
				- Vector3.new(b.frame.Position.X, 0, b.frame.Position.Z)).Magnitude or math.huge
			local near = b.owner == player or d <= range or (subs[index] and d <= leave)
			-- (2026-10-04, "8명이 풀로 승급전 돌리고 배틀필드 밤에 돌아다닐때 … 매끄럽게") the owner gets the health events
			-- only while within range of their track (its bars are drawn only then): out on the battlefield their own
			-- fight comes lite like a neighbour's, and coming back it comes whole again from a fresh snapshot
			local want = (b.owner == player and d <= range) and "full" or true
			if near and (not subs[index] or (want == "full" and subs[index] ~= "full")) then
				subs[index] = want
				local fresh = { { "C" } }
				if b.owner then
					for _, m in ipairs(DefenseLogic.snapshot(b.field)) do
						table.insert(fresh, { "S", table.unpack(m) })
					end
				end
				table.insert(list, { index, fresh })
			elseif near then
				subs[index] = want
				local events = want == "full" and byBase[index] or byBaseLite[index]
				if events and #events > 0 then
					local cache = want == "full" and packed or packedLite
					cache[index] = cache[index] or DefensePack.pack(events)
					table.insert(list, { index, cache[index] })
				end
			else
				subs[index] = nil
			end
		end
		if #list > 0 then
			Net.push(player, "DefenseEvents", now, list)
		end
	end
end

-- one base's fight a step on (its events into batch, sent by the caller)
local function tickBase(index, b, dt, batch)
	if b.clearQueued then
		b.clearQueued = false
		table.insert(batch, { index, { { "C" } } })
	end
	local owner = b.owner
	local profile = owner and PlayerData.get(owner)
	if profile then
		local fighting = b.field.promotion ~= nil
		local level = fighting and b.promoLevel or profile.DefenseLevel
		local kills, reward, result, reason = DefenseLogic.step(b.field, dt, level, rand)
		local events = DefenseLogic.takeEvents(b.field)
		-- (2026-10-03, "속성 공격이 안나가는데 속성조합을 지켜보라고 하면 어떡해": a frozen-wet fossil came 1 time in 5)
		-- while the tutorial waits for a combo, an ice hit on a wet fossil always freezes it
		b.field.sureCombo = owner:GetAttribute("TutorialStep") == "Combo"
		if owner:GetAttribute("TutorialStep") == "Combo" then -- (2026-10-02) the tutorial's "see a combo" step
			for _, e in ipairs(events) do
				if e[1] == "A" and e[5] then
					Rewards.add(owner, "Combo", 1)
					break
				end
			end
		end
		if b.reviveUntil and os.clock() > b.reviveUntil then
			b.reviveUntil = nil
			if b.field.reviveOffer == "asking" then
				b.field.reviveOffer = "used"
			end
			DefenseLogic.resume(b.field)
		end
		if result == "revive" then
			local R = Config.Products.PromotionRevive
			local root = owner.Character and owner.Character:FindFirstChild("HumanoidRootPart")
			if root and (root.Position - b.frame.Position).Magnitude <= R.WatchRange then
				b.reviveUntil = os.clock() + R.OfferSeconds
				Net.push(owner, "PromoReviveOffer", R.Lives, not profile.FreeReviveUsed)
			else
				b.field.reviveOffer = "used"
				DefenseLogic.resume(b.field)
			end
		elseif result == "challenge" then
			finishChallenge(b, owner, reason)
		elseif result then
			finishPromotion(b, owner, result, reason)
		elseif b.field.challenge then
			local wave, waveLeft, onTrack, lives = DefenseLogic.challengeStatus(b.field)
			if wave - 1 > (b.challengeCounted or 0) then
				countWaves(b, owner, wave - 1) -- (a wave cleared: saved at once)
			end
			if os.clock() - (b.promoShownAt or 0) >= PROMO_STATUS_EVERY then
				b.promoShownAt = os.clock()
				owner:SetAttribute("ChallengeWave", wave)
				owner:SetAttribute("ChallengeWaveLeft", waveLeft)
				owner:SetAttribute("ChallengeOnTrack", onTrack)
				owner:SetAttribute("ChallengeLives", lives)
			end
		elseif fighting and os.clock() - (b.promoShownAt or 0) >= PROMO_STATUS_EVERY then
			-- (four times a second, not every tick: each attribute goes to every screen)
			b.promoShownAt = os.clock()
			local left, onTrack, boss, lives = DefenseLogic.promotionStatus(b.field)
			owner:SetAttribute("PromoTimeLeft", left)
			owner:SetAttribute("PromoLives", lives)
			owner:SetAttribute("PromoOnTrack", onTrack)
			owner:SetAttribute("PromoBoss", boss or -1)
		end
		if os.clock() - (b.damageShownAt or 0) >= Config.Defense.LiveDamageEvery then
			b.damageShownAt = os.clock()
			local folder = Bases.folder(index)
			local report = damageReport(b, owner, nil, true)
			if folder and report then
				folder:SetAttribute("LiveDamageReport", HttpService:JSONEncode(report))
			end
		end
		if #events > 0 then
			table.insert(batch, { index, events })
			if fighting or b.field.challenge then
				for _, e in ipairs(events) do
					if e[1] == "S" and e[11] then
						introduceKind(owner, profile, e[11])
					end
				end
			end
			if fighting then
				for _, e in ipairs(events) do
					if e[1] == "S" then
						if e[13] == true and not owner:GetAttribute("PromoGroup") then
							owner:SetAttribute("PromoGroup", e[12])
						end
						local k = e[11] and Formulas.fossilKind(e[11])
						if k and k.Split and k.Id ~= "Airship" then
							owner:SetAttribute("PromoShell", true)
						elseif k and (k.ImmuneAttack or k.ImmuneAttribute) then
							owner:SetAttribute("PromoImmune", k.Id)
						elseif k and k.Id == "Airship" then
							owner:SetAttribute("PromoAirship", true)
						elseif k and k.Id == "Sprinter" then
							owner:SetAttribute("PromoSprinter", true)
						end
					end
				end
			end
		end
		local popped = (b.field.popped or 0) - (b.poppedCounted or 0)
		if popped > 0 then
			b.poppedCounted = b.field.popped
			Rewards.add(owner, "ShellPop", popped)
		end
		local downed = (b.field.airshipsDown or 0) - (b.airshipsCounted or 0)
		if downed > 0 then
			b.airshipsCounted = b.field.airshipsDown
			Rewards.add(owner, "AirshipDown", downed)
		end
		local cleared = b.field.groupsCleared - (b.groupsCounted or 0)
		if cleared > 0 then
			b.groupsCounted = b.field.groupsCleared
			if fighting or b.field.challenge or result then
				Rewards.add(owner, "GroupClear", cleared)
			end
		end
		local autoOff = profile.PromoAutoOff == true and boardDone(profile) or nil
		if owner:GetAttribute("PromoAutoOff") ~= autoOff then
			owner:SetAttribute("PromoAutoOff", autoOff)
		end
		if not fighting and not b.field.challenge and b.gauge then
			b.gauge += kills
			local full = not result and b.gauge >= gaugeNeed(profile)
			if not full then
				b.fullTold = nil
			end
			if full and autoReady(b, owner, profile) then
				if not b.bossWarnAt then
					b.bossWarnAt = os.clock() + Config.Defense.Promotion.Gauge.WarnSeconds
					battleNotice(owner, "👑 보스 웨이브!", string.format(Formulas.bossAirships(profile.DefenseLevel + 1) > 0
						and "👑 %d초 뒤 보스와 🎈 비행선, 🏃 빠른 화석 떼가 와요!" or "👑 %d초 뒤 보스와 🏃 빠른 화석 떼가 와요!",
						Config.Defense.Promotion.Gauge.WarnSeconds), "BossWave")
				elseif os.clock() >= b.bossWarnAt then
					b.bossWarnAt = nil
					startPromotion(owner, true)
				end
			elseif full and not b.fullTold and not boardDone(profile) and promoReady(b, owner, profile) then
				b.fullTold = true
				if profile.Starter.PromoTold then
					battleNotice(owner, "👑 보스 도전 준비 끝!", "⚔️ 노란 줄이 가득! 위쪽 '⚔️ 보스 도전'을 눌러요", "BossWave")
				else
					PlayerData.update(owner, function(p)
						p.Starter.PromoTold = true
					end)
					Net.push(owner, "CocoCard", { "👑 보스 도전 준비 끝!", "⚔️ 노란 줄이 가득 찼어요! 위쪽 '⚔️ 보스 도전'을 눌러 레벨을 올려요",
						"📋 초보 미션 동안엔 직접 눌러요 · 미션을 다 끝내면 자동으로 올라가요!" }, "Base_Arena")
				end
			end
		end
		if kills > 0 then
			b.fossils = (b.fossils or 0) + kills -- daily missions, paid with the money (payKills)
			table.insert(b.killLog, { b.field.time, kills })
			-- farm, collection and rebirth money, and rain or a storm (Weather)
			b.carry += reward * (1 + (b.bonuses and b.bonuses.Money or 0)) * Weather.defenseMultiplier()
		end
		-- what the arena really makes idle (no fight, some dino placed), for the offline earnings (no weather:
		-- that's for the moment); saveIdleRate keeps it in the profile
		if not fighting and not b.field.challenge and next(profile.Placed) ~= nil then
			b.idleTime = (b.idleTime or 0) + dt
			if kills > 0 then
				b.idleMoney = (b.idleMoney or 0) + reward * (1 + (b.bonuses and b.bonuses.Money or 0))
			end
		end
	end
end

function Defense.init()
	shareMonsterModels()
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		local frame, arena = nil, nil
		if folder then
			frame, arena = arenaFrame(folder)
		end
		if frame then
			local unitsFolder = folder:FindFirstChild("DefenseUnits") or Instance.new("Folder")
			unitsFolder.Name = "DefenseUnits"
			unitsFolder:ClearAllChildren()
			unitsFolder.Parent = folder
			folder:SetAttribute("ArenaFrame", frame)
			Bases.title(arena, "🛡️ 화석 방어 아레나", TITLE_ARENA_COLOR, true, TITLE_FIELD_HEIGHT)
			local b = { index = index, frame = frame, arena = arena, unitsFolder = unitsFolder,
				field = DefenseLogic.newField(FIRST_MAP), carry = 0, killLog = {} }
			bases[index] = b
			local sign = folder:FindFirstChild("DefenseSign")
			if sign and sign:IsA("BasePart") then
				b.sign = sign
				local old = sign:FindFirstChild("SlotSign")
				if old then
					old:Destroy()
				end
				local gui = Instance.new("SurfaceGui")
				gui.Name = "SlotSign"
				gui.Face = Enum.NormalId.Front
				gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
				gui.PixelsPerStud = SIGN_PIXELS_PER_STUD
				local label = Instance.new("TextLabel")
				label.Size = UDim2.fromScale(1, 1)
				label.BackgroundTransparency = 1
				label.Font = Enum.Font.GothamBold
				label.TextScaled = true
				label.TextColor3 = Color3.new(1, 1, 1)
				label.TextStrokeTransparency = 0.3
				label.Parent = gui
				gui.Parent = sign
				b.signLabel = label
				refreshSign(b, nil)
				local prompt = Bases.prompt(sign, "BuySlot", index, "➕ 공룡 자리 늘리기", Config.Placement.SignRange)
				if prompt then
					prompt.HoldDuration = Config.UI.HoldSeconds -- held a moment: a stray tap does nothing
				end
				Bases.title(sign, "➕ 공룡 자리 늘리기", TITLE_SLOT_COLOR)
				prompt.Triggered:Connect(function(player)
					if Bases.of(player) == index and Unlocks.shown(player, "DefenseSign") then
						buySlot(player)
					end
				end)
			else
				warn(string.format("[Defense] Base%d에 DefenseSign이 없어 배치 칸 구매 버튼을 못 놓았습니다", index))
			end
		elseif folder then
			warn(string.format("[Defense] Base%d에 Base_Arena가 없어 디펜스를 건너뜁니다", index))
		end
	end

	PlayerData.onLoaded(function(player, profile)
		start(player)
		player:SetAttribute("MapWins", mapWinsText(profile))
	end)
	PlayerData.onChanged(function(player, profile)
		local _, b = baseOf(player)
		if b then
			refreshUnits(b, profile)
			local rebirths = profile.Rebirths or 0
			if rebirths > (b.rebirthsSeen or rebirths) then
				b.rebirthsSeen = rebirths
				b.gauge = 0
				local newest = Formulas.newestMap(rebirths)
				if newest.Rebirths == rebirths then
					task.defer(switchMap, player, newest.Id, true)
				end
			end
		end
	end)
	local function watch(player) -- the base can be given before or after the data loads
		player:GetAttributeChangedSignal("Base"):Connect(function()
			start(player)
		end)
		player:GetAttributeChangedSignal("CocoPays"):Connect(function()
			local _, b = baseOf(player)
			local profile = PlayerData.get(player)
			if b and b.owner == player and profile then
				refreshSign(b, profile)
			end
		end)
		start(player)
	end
	Players.PlayerAdded:Connect(watch)
	for _, player in ipairs(Players:GetPlayers()) do
		watch(player)
	end
	Players.PlayerRemoving:Connect(function(player)
		subscribed[player] = nil
		local index = baseOf(player)
		if index then
			stop(index)
		end
	end)

	Net.onRequest("PlaceUnit", { "string", "number", "number" }, placeUnit)
	Net.onRequest("RemoveUnit", { "string" }, removeUnit)
	Net.onRequest("AutoArrange", {}, autoArrange)
	Net.onRequest("ApplyDeckAdvice", {}, applyDeckAdvice)
	Net.onRequest("StartPromotion", {}, startPromotion)
	Net.onRequest("CancelPromotion", {}, cancelPromotion)
	Net.onRequest("PromoReviveNo", {}, function(player)
		local _, b = baseOf(player)
		if b and b.reviveUntil then
			b.reviveUntil = os.clock()
		end
	end)
	Net.onRequest("PromoReviveFree", {}, function(player)
		local _, b = baseOf(player)
		local profile = PlayerData.get(player)
		if not b or b.owner ~= player or not profile or profile.FreeReviveUsed or b.field.reviveOffer ~= "asking" then
			return
		end
		PlayerData.update(player, function(p)
			p.FreeReviveUsed = true
		end)
		Defense.revive(player)
		Analytics.custom(player, "FreeRevive")
	end)
	Net.onRequest("SetTargeting", { "string", "string" }, function(player, unitId, mode)
		local profile = PlayerData.get(player)
		local valid = false
		for _, t in ipairs(Config.Defense.Targets) do
			valid = valid or t.Id == mode
		end
		if not profile or not valid or not profile.Placed[unitId] then
			return
		end
		PlayerData.update(player, function(p)
			p.Targeting = p.Targeting or {}
			p.Targeting[unitId] = mode ~= "Auto" and mode or nil
		end)
		Rewards.add(player, "SetTargeting", 1)
	end)
	Net.onRequest("SetDefenseMap", { "string" }, function(player, mapId)
		if Unlocks.check(player, "MapBoard") then
			switchMap(player, mapId, false)
		end
	end)
	Net.onRequest("TopViewUsed", {}, function(player)
		local _, b = baseOf(player)
		if b and Bases.near(player, b.arena, Config.Placement.EditRange) then
			Rewards.add(player, "TopView", 1)
		end
	end)
	Net.onRequest("StartChallenge", {}, startChallenge)
	Net.onRequest("CancelChallenge", {}, cancelChallenge)
	PlayerData.onLoaded(function(player, profile)
		retryAt(player, profile)
		showChallengeBest(player, profile)
		if profile.Settings.AutoArrangeOn ~= nil then
			PlayerData.update(player, function(p)
				p.Settings.AutoArrangeOn = nil
			end)
		end
	end)
	Net.onAsk("GetMyUnits", {}, function(player)
		local profile = PlayerData.get(player)
		return {
			Units = profile.Units,
			Placed = profile.Placed,
			Targeting = profile.Targeting,
			Slots = Formulas.profileSlots(profile),
			SlotsBought = profile.Upgrades.Slots,
			Farm = profile.Farm,
			FarmLock = profile.FarmLock,
			FarmSlots = Formulas.farmSlots(profile),
			PromoAssist = profile.PromoAssist,
			MergeDinos = profile.Starter.MergeDinos,
		}
	end)
	Net.onAsk("GetDefense", {}, function()
		local list = {}
		for index, b in pairs(bases) do
			if b.owner then
				table.insert(list, { index, DefenseLogic.snapshot(b.field) })
			end
		end
		return { Workspace:GetServerTimeNow(), list }
	end)

	-- (2026-10-04, "8명이 풀로 승급전 돌리고 배틀필드 밤에 돌아다닐때 문제없게 최적화 해 매끄럽게") each base's fight
	-- steps on its own clock, the bases spread over the tick (base i starts (i - 1) / BaseCount of a tick ahead), so a
	-- frame steps one or two fights, not all eight at once (8 strong fights at LV 330 took up to 10 ms in one frame
	-- every tick: tools/load_bench); the events of the fights stepped go out in that frame
	local step = Config.Defense.TickSeconds
	local statsAcc = 0
	local clocks = {} -- [base index] = the time its fight is owed
	RunService.Heartbeat:Connect(function(dt)
		local started = os.clock()
		local batch, stepped = {}, false
		for index, b in pairs(bases) do
			local acc = clocks[index] or step * ((index - 1) % Config.Map.BaseCount) / Config.Map.BaseCount
			acc = math.min(acc + dt, step * 5) -- a long hitch skips time instead of piling up steps
			while acc >= step do
				acc -= step
				tickBase(index, b, step, batch)
				stepped = true
			end
			clocks[index] = acc
		end
		if stepped then
			sendEvents(batch)
		end
		statsAcc += dt
		if statsAcc >= STATS_EVERY then
			statsAcc = 0
			local fade = math.exp(-STATS_EVERY / (Config.Rewards.Offline.RateMemoryMinutes * 60))
			for _, b in pairs(bases) do
				payKills(b)
				setStats(b)
				b.idleMoney, b.idleTime = (b.idleMoney or 0) * fade, (b.idleTime or 0) * fade
				if b.owner and os.clock() - (b.idleSavedAt or 0) >= IDLE_RATE_SAVE_EVERY then
					b.idleSavedAt = os.clock()
					saveIdleRate(b)
				end
			end
		end
		if Defense.meter then
			Defense.meter("loop", "Defense", os.clock() - started)
		end
	end)
end

return Defense
