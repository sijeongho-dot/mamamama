--[[
MoveGuard: movement checks (design 기술 원칙: a position change bigger than the upgraded move speed
allows is undone).

- The server sets every character's WalkSpeed from the move speed upgrade (Config.MoveSpeed). A
  client that raises its own WalkSpeed only changes its copy; the server still knows the real one.
- Every Config.MoveGuard.CheckInterval seconds the horizontal distance each character moved is
  compared with WalkSpeed × time × SpeedTolerance + ExtraStuds. Too far: back to the last good spot.
- Weather (ReplicatedStorage attribute Weather, from the Weather service): everyone walks
  MoveSpeedMultiplier times as fast while it lasts (rain, storm ×2, rainbow ×3); set again for
  everyone when the weather changes.
- Speed pads (SpeedPads) raise the walk speed for a moment (MoveGuard.boost; no stacking: a better
  pad replaces the boost at once, a weaker one keeps the speed and starts the time over); the check
  uses the WalkSpeed of the moment, so the boost counts.
- Riding a dino (player attribute Riding, Ride service): Config.Ride.SpeedMultiplier × the trained walk speed.
  Flying ones too: only the horizontal move is checked (the Ride service keeps them under
  Config.Ride.FlyMaxHeight).
- Racing (player attribute Racing, Race service): standing still while it is "Countdown"; while
  "Go" and riding, everyone rides at Config.Race.Speed (times a race pad's boost and the weather's
  MoveSpeedMultiplier, the same for both racers; 2026-10-01), whatever their upgrades, carried keys or
  a speed potion.
- Server code that moves a player on purpose (a teleport, a push out of a base) calls MoveGuard.allow(player)
  first so that move is not undone: the checks pause for a moment. Moves a player can set off themselves
  (getting on or off a dino, a wild dino's ride and throw, a slap's flight, a rebirth's show, the end of a
  pad's boost) only loosen the check instead (MoveGuard.loosen: up to Config.MoveGuard.LooseSpeed studs a
  second), so asking for them again and again can't open a window to teleport in (2026-10-01).
- A new character is only trusted once it stands near a SpawnLocation (within SpawnRadius): a character
  that is somewhere else when GraceAfterSpawn runs out is put back on its spawn (no teleporting while
  respawning).
- Flying (2026-10-01): a character not riding, not loosened, with nothing under it for FlyGap studs and not
  falling, FlyChecks checks in a row, is put back where it last stood on something. (2026-10-04) Not one beside a tree
  trunk: climbing it (TreeClimb).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local TreeClimb = require(script.Parent:WaitForChild("TreeClimb"))

local MoveGuard = {}

local state = {} -- [player] = { lastPos, lastTime, graceUntil, looseUntil, looseSpeed, strikes, spawnCheck,
--   spawnUntil, airChecks, groundPos }
local spawns = {} -- [SpawnLocation] = true, every one in the Workspace
local rayParams = RaycastParams.new()
rayParams.FilterType = Enum.RaycastFilterType.Exclude
rayParams.RespectCanCollide = true
local JUMP_HEIGHT, JUMP_POWER = 7.2, 50 -- Roblox's defaults, back after a stun
local SPAWN_ABOVE = 4 -- studs over a SpawnLocation a character is put back on

local boosts = {} -- [player] = { multiplier, untilTime } from a speed pad
local stuns = {} -- [player] = os.clock() until which the player can't move (groggy, hit by a dropping)

-- the walk speed the player has earned, slower while carrying keys (player attribute CarriedKeys),
-- times the weather's and a speed pad's boost while they last
function MoveGuard.walkSpeed(player)
	local racing = player:GetAttribute("Racing") -- (Race service)
	if (stuns[player] or 0) > os.clock() or racing == "Countdown" then -- waiting at the start line
		return 0
	end
	local boost = boosts[player]
	local boostBy = boost and os.clock() < boost.untilTime and boost.multiplier or 1
	-- every racer rides as fast, the race's pads aside: no upgrade or Robux speed potion counts
	-- (2026-10-01, "레이스에 스피드 로벅스 아이템이 영향을 안 미치게"); the weather does, for both
	-- alike ("레이스에 날씨 영향은 주자")
	if racing == "Go" and player:GetAttribute("Riding") then
		local weather = Formulas.weather(ReplicatedStorage:GetAttribute("Weather")).MoveSpeedMultiplier or 1
		return Config.Race.Speed * weather * boostBy
	end
	-- (2026-10-03, "지금 술래 스피드가 더 빠른거 맞지?") in a hide-and-seek game everyone walks as fast (no upgrade or
	-- potion), the seeker faster while seeking ("술래한테 이득을 좀 줘야"); pads and weather for all alike (HideSeek)
	if player:GetAttribute("HideSeekRoom") then
		local weather = Formulas.weather(ReplicatedStorage:GetAttribute("Weather")).MoveSpeedMultiplier or 1
		local role = player:GetAttribute("HideSeekRole")
		local seeking = role == "Seeker" and player:GetAttribute("HideSeekPhase") == "Seeking"
		-- (2026-10-04, "튀는 사람을 술래 기본속도보다 빠르게.. 패드를 못쓰니까") the hiders faster than the seeker
		local by = seeking and Config.HideSeek.SeekerSpeed or role == "Hider" and Config.HideSeek.HiderSpeed or 1
		-- (2026-10-04, "이 기본공룡은 seeker 와 hider에게 부여된 이동속도에 따라 속도가 결정" → "차이가 너무 크게나나" → 2번:
		-- "공룡끼리는 차이를 걸을 때와 같은 4로") the default dino they ride outside the battlefield adds the same to everyone
		-- (a dino's usual extra, WalkSpeed × (Ride.SpeedMultiplier − 1)), so the seeker stays as many studs a second
		-- faster as on foot: 64 against 60 (× 3 on top was 72 against 60, caught up three times as fast)
		local ride = player:GetAttribute("Riding") and Config.HideSeek.WalkSpeed * (Config.Ride.SpeedMultiplier - 1) or 0
		return (Config.HideSeek.WalkSpeed * by + ride) * weather * boostBy
	end
	local profile = PlayerData.get(player)
	local level = profile and Formulas.trained(profile.Upgrades, profile.Training).MoveSpeed or 0
	if player:GetAttribute("Riding") then
		return math.min(Formulas.moveSpeed(level) * Config.Ride.SpeedMultiplier, Config.Ride.MaxSpeed) * boostBy
	end
	local speed = Formulas.carrySpeed(Formulas.moveSpeed(level), player:GetAttribute("CarrySlow"))
	speed *= MoveGuard.chaseBoost(player)
	if (player:GetAttribute("SpeedPotionUntil") or 0) > Workspace:GetServerTimeNow() then -- (Monetization)
		speed *= 1 + Config.Products.SpeedPotion.SpeedBonus
	end
	return speed
end

function MoveGuard.chaseBoost(player)
	local boost = boosts[player]
	local boostBy = boost and os.clock() < boost.untilTime and boost.multiplier or 1
	if (player:GetAttribute("CarriedKing") or 0) > 0 then
		boostBy = 1 + (boostBy - 1) * Config.Keys.KingCarrierPadShare
	elseif (player:GetAttribute("CarriedKeys") or 0) > 0 then
		boostBy = 1 + (boostBy - 1) * Config.Keys.CarrierPadShare
	end
	return boostBy * (Formulas.weather(ReplicatedStorage:GetAttribute("Weather")).MoveSpeedMultiplier or 1)
end

function MoveGuard.stunned(player)
	return (stuns[player] or 0) > os.clock()
end

-- can't walk or jump for seconds (a longer stun already running wins). Player attribute StunnedUntil
-- (server time) and StunReason ("Groggy" or "Poop") tell the client for its countdown.
function MoveGuard.stun(player, seconds, reason)
	local untilTime = os.clock() + seconds
	if (stuns[player] or 0) >= untilTime then
		return
	end
	stuns[player] = untilTime
	player:SetAttribute("StunnedUntil", Workspace:GetServerTimeNow() + seconds)
	player:SetAttribute("StunReason", reason)
	local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	if humanoid then
		humanoid.WalkSpeed = 0
		humanoid.JumpHeight = 0
		humanoid.JumpPower = 0
	end
	MoveGuard.loosen(player, seconds + Config.MoveGuard.CheckInterval * 2)
	task.delay(seconds, function()
		if stuns[player] == untilTime then
			stuns[player] = nil
			player:SetAttribute("StunnedUntil", nil)
			player:SetAttribute("StunReason", nil)
			local h = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
			if h then
				h.JumpHeight = JUMP_HEIGHT
				h.JumpPower = JUMP_POWER
			end
			MoveGuard.refresh(player) -- (defined below; looked up when the stun ends)
		end
	end)
end

local function applyWalkSpeed(player)
	local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	if humanoid then
		humanoid.WalkSpeed = MoveGuard.walkSpeed(player)
	end
end

-- set the walk speed again now (e.g. when the player picks up or loses keys)
MoveGuard.refresh = applyWalkSpeed

function MoveGuard.boosted(player)
	local boost = boosts[player]
	return boost ~= nil and os.clock() < boost.untilTime
end

-- a speed pad: multiplier for seconds. No stacking: while a boost is on, a better pad (higher
-- multiplier) takes over at once, with its own time; an equal or weaker one keeps the better speed
-- and starts its time over (seconds from now), so a player who keeps hitting pads keeps the speed.
-- Player attributes SpeedBoost / SpeedBoostUntil (server time) tell the client for its effect.
function MoveGuard.boost(player, multiplier, seconds)
	local current = boosts[player]
	if MoveGuard.boosted(player) and multiplier <= current.multiplier then
		multiplier = current.multiplier
	end
	local b = { multiplier = multiplier, untilTime = os.clock() + seconds }
	boosts[player] = b
	player:SetAttribute("SpeedBoost", multiplier)
	player:SetAttribute("SpeedBoostUntil", Workspace:GetServerTimeNow() + seconds)
	applyWalkSpeed(player)
	task.delay(seconds, function()
		if boosts[player] == b then
			boosts[player] = nil
			player:SetAttribute("SpeedBoost", nil)
			player:SetAttribute("SpeedBoostUntil", nil)
			MoveGuard.settle(player) -- the faster moves just before are fine
			applyWalkSpeed(player)
		end
	end)
	return true
end

-- end a speed pad's boost now (a race's mud, Race service)
function MoveGuard.clearBoost(player)
	if not boosts[player] then
		return
	end
	boosts[player] = nil
	player:SetAttribute("SpeedBoost", nil)
	player:SetAttribute("SpeedBoostUntil", nil)
	MoveGuard.settle(player) -- the faster moves just before are fine
	applyWalkSpeed(player)
end

-- a server move: let the next moves through for a while (seconds, default Config.MoveGuard.GraceAfterSpawn)
function MoveGuard.allow(player, seconds)
	local s = state[player]
	if s then
		s.graceUntil = os.clock() + (seconds or Config.MoveGuard.GraceAfterSpawn)
		s.lastPos = nil
		s.spawnCheck = false -- (the server placed them)
		s.airChecks = 0
	end
end

-- a move the player can set off: for seconds, up to speed (default Config.MoveGuard.LooseSpeed) studs a
-- second is fine too, and flying isn't checked
function MoveGuard.loosen(player, seconds, speed)
	local s = state[player]
	if s then
		local now = os.clock()
		local running = (s.looseUntil or 0) > now and s.looseSpeed or 0 -- (a faster loosening still on wins)
		s.looseSpeed = math.max(speed or Config.MoveGuard.LooseSpeed, running)
		s.looseUntil = math.max(s.looseUntil or 0, now + seconds)
		s.airChecks = 0
	end
end

-- the walk speed is about to drop: the moves at the speed of a moment ago stay fine for two checks
function MoveGuard.settle(player)
	local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	MoveGuard.loosen(player, Config.MoveGuard.CheckInterval * 2, math.max(humanoid and humanoid.WalkSpeed or 0, 1))
end

local function nearSpawn(pos)
	local radius = Config.MoveGuard.SpawnRadius
	for spawn in pairs(spawns) do
		if (spawn.Position - pos).Magnitude <= radius then
			return true
		end
	end
	return next(spawns) == nil -- (no spawns in this place: nothing to check against)
end

local function sendToSpawn(player, root)
	local target = player.RespawnLocation
	if not target or not spawns[target] then
		local best = math.huge
		for spawn in pairs(spawns) do
			local d = (spawn.Position - root.Position).Magnitude
			if d < best then
				target, best = spawn, d
			end
		end
	end
	if target then
		root.CFrame = CFrame.new(target.Position + Vector3.new(0, SPAWN_ABOVE, 0)) * root.CFrame.Rotation
		root.AssemblyLinearVelocity = Vector3.zero
	end
end

local function checkPlayer(player, now)
	local s = state[player]
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not s or not root or not humanoid or humanoid.Health <= 0 then
		return
	end
	local c = Config.MoveGuard
	local pos = root.Position
	if s.spawnCheck then -- a new character: trusted once it stands at a spawn
		if nearSpawn(pos) then
			s.spawnCheck = false
			s.lastPos, s.lastTime, s.groundPos, s.graceUntil = pos, now, pos, 0
		elseif now >= s.spawnUntil then
			s.spawnCheck = false
			s.strikes += 1
			warn(string.format("[MoveGuard] %s's new character was away from every spawn, put back (%d times)",
				player.Name, s.strikes))
			sendToSpawn(player, root)
			s.lastPos, s.lastTime, s.groundPos = root.Position, now, root.Position
		end
		return
	end
	if not s.lastPos or now < s.graceUntil then
		s.lastPos, s.lastTime = pos, now
		s.airChecks = 0
		return
	end
	local dt = now - s.lastTime
	local moved = Vector3.new(pos.X - s.lastPos.X, 0, pos.Z - s.lastPos.Z).Magnitude
	local allowed = humanoid.WalkSpeed * dt * c.SpeedTolerance + c.ExtraStuds
	local loose = now < (s.looseUntil or 0)
	if loose then
		allowed = math.max(allowed, s.looseSpeed * dt * c.SpeedTolerance + c.ExtraStuds)
	end
	if moved > allowed then
		s.strikes += 1
		root.CFrame = root.CFrame - pos + s.lastPos -- back, keeping the facing
		root.AssemblyLinearVelocity = Vector3.zero
		warn(string.format("[MoveGuard] %s moved %.1f studs in %.2fs (allowed %.1f), moved back (%d times)",
			player.Name, moved, dt, allowed, s.strikes))
		s.lastTime = now
		return
	end
	local dy = pos.Y - s.lastPos.Y
	if moved >= c.StillStuds or dt >= c.CatchUpSeconds then
		s.lastTime = now
	end
	s.lastPos = pos
	-- flying: nothing under the character for FlyGap studs and not falling, FlyChecks checks in a row
	if loose or player:GetAttribute("Riding") or humanoid.Sit then
		s.airChecks = 0
		return
	end
	local characters = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(characters, p.Character)
		end
	end
	rayParams.FilterDescendantsInstances = characters
	if Workspace:Raycast(pos, Vector3.new(0, -c.FlyGap, 0), rayParams) then
		s.airChecks, s.groundPos = 0, pos
	elseif TreeClimb.nearTrunk(pos, characters) then -- (2026-10-04) climbing a tree (StarterPlayerScripts/Climb)
		s.airChecks = 0
	elseif dy > -c.FallStuds then -- (falling is fine)
		s.airChecks = (s.airChecks or 0) + 1
		if s.airChecks >= c.FlyChecks and s.groundPos then
			s.strikes += 1
			s.airChecks = 0
			root.CFrame = CFrame.new(s.groundPos) * root.CFrame.Rotation
			root.AssemblyLinearVelocity = Vector3.zero
			s.lastPos = s.groundPos
			warn(string.format("[MoveGuard] %s stayed in the air, put back on the ground (%d times)", player.Name, s.strikes))
		end
	end
end

function MoveGuard.init()
	local function added(player)
		state[player] = { lastPos = nil, lastTime = 0, graceUntil = 0, looseUntil = 0, looseSpeed = 0, strikes = 0,
			spawnCheck = false, spawnUntil = 0, airChecks = 0, groundPos = nil }
		player:GetAttributeChangedSignal("CarriedKeys"):Connect(function()
			applyWalkSpeed(player)
		end)
		player:GetAttributeChangedSignal("CarriedKing"):Connect(function()
			applyWalkSpeed(player)
		end)
		player:GetAttributeChangedSignal("CarrySlow"):Connect(function()
			applyWalkSpeed(player)
		end)
		for _, name in ipairs({ "HideSeekPhase", "HideSeekRoom" }) do -- (a game's own speed, the seeker's)
			player:GetAttributeChangedSignal(name):Connect(function()
				MoveGuard.allow(player, Config.MoveGuard.CheckInterval * 2)
				applyWalkSpeed(player)
			end)
		end
		player:GetAttributeChangedSignal("Racing"):Connect(function()
			MoveGuard.allow(player, Config.MoveGuard.CheckInterval * 2) -- faster or slower than a moment ago
			applyWalkSpeed(player)
		end)
		local function newCharacter()
			local s = state[player]
			if s then
				s.lastPos, s.groundPos, s.airChecks, s.looseUntil = nil, nil, 0, 0
				s.spawnCheck, s.spawnUntil = true, os.clock() + Config.MoveGuard.GraceAfterSpawn
			end
		end
		player.CharacterAdded:Connect(function()
			newCharacter()
			task.defer(applyWalkSpeed, player)
		end)
		player:GetAttributeChangedSignal("TrainReal_MoveSpeed"):Connect(function()
			applyWalkSpeed(player)
		end)
		if player.Character then
			newCharacter()
			applyWalkSpeed(player)
		end
	end
	Players.PlayerAdded:Connect(added)
	Players.PlayerRemoving:Connect(function(player)
		state[player] = nil
		boosts[player] = nil
		stuns[player] = nil
	end)
	for _, player in ipairs(Players:GetPlayers()) do
		added(player)
	end
	PlayerData.onLoaded(applyWalkSpeed)
	PlayerData.onChanged(applyWalkSpeed)
	ReplicatedStorage:GetAttributeChangedSignal("Weather"):Connect(function() -- faster or back to normal
		for player in pairs(state) do
			MoveGuard.settle(player) -- the faster steps just before are fine
			applyWalkSpeed(player)
		end
	end)
	local function watchSpawn(item)
		if item:IsA("SpawnLocation") then
			spawns[item] = true
			item.AncestryChanged:Connect(function()
				if not item:IsDescendantOf(Workspace) then
					spawns[item] = nil
				end
			end)
		end
	end
	for _, item in ipairs(Workspace:GetDescendants()) do
		watchSpawn(item)
	end
	Workspace.DescendantAdded:Connect(watchSpawn)

	if not Config.MoveGuard.Enabled then
		return
	end
	task.spawn(function()
		while true do
			task.wait(Config.MoveGuard.CheckInterval)
			local now = os.clock()
			for player in pairs(state) do
				checkPlayer(player, now)
			end
		end
	end)
end

return MoveGuard
