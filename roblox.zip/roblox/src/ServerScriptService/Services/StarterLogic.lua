--[[
StarterLogic: the beginner mission board's rules as plain data (no Roblox), so they can be tested
(tools/tests/starter_test.lua). The StarterMissions service keeps a player's state in the profile
(profile.Starter) and calls these.

State: { Step = index in Config.StarterMissions.Missions, Count = an event mission's count, Done = bool,
Order = the missions' order Step counts in (nil = 1), Skip = { [mission name] = true }: done on an older order, passed
by when their turn comes (StarterLogic.upgrade), Extra = { mission names }: added since an older order behind where the
save was, done first and apart, MainCount = the board mission's count meanwhile }
Facts (what the service reads off the player): { PickaxeTier, BagLevel, DefenseLevel, PlacedDinos, Friends, SlapLevel,
Rebirths, Collection }
]]

local Config = if game
	then require(game:GetService("ReplicatedStorage"):WaitForChild("Config"))
	else CONFIG
local Formulas = if game
	then require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Formulas"))
	else LOAD("ReplicatedStorage/Shared/Formulas")

local StarterLogic = {}

local function missions()
	return Config.StarterMissions.Missions
end

-- a mission's name in a save (one of each on the board): its Goal or Event
local function idOf(m)
	return m.Id or m.Goal or m.Event
end
StarterLogic.idOf = idOf

-- (2026-10-04, "본게임에서 광질 조금 하다 가던데" → the key stall first) the boards before Config.StarterMissions.Order, by
-- mission name: [order] = the names in that order
local OLD_ORDERS = {
	[1] = { "PickaxeTier", "BagLevel", "PlacedDinos", "Bell", "RewardClaim", "KeysHome", "HomeTeleport", "MineSprout",
		"Chests", "Pads", "SlapLevel", "Enhance", "FruitHome", "Feed", "FarmAdd", "KeyBuy", "KeyTrade", "StealKeys",
		"PlaceBossPath", "SlotBuy", "DefenseLevel", "ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap",
		"BossHit", "NightMine", "Mount", "WildRide", "RaceDone", "Merge", "Collection", "HideSeekGame", "Friends",
		"Rebirths" },
	[2] = { "KeyBuy", "PlacedDinos", "PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport",
		"MineSprout", "Chests", "Pads", "SlapLevel", "Enhance", "FruitHome", "Feed", "FarmAdd", "KeyTrade", "StealKeys",
		"PlaceBossPath", "SlotBuy", "DefenseLevel", "ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap",
		"BossHit", "NightMine", "Mount", "WildRide", "RaceDone", "Merge", "Collection", "HideSeekGame", "Friends",
		"Rebirths" },
	[3] = { "Draws", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PickaxeTier", "BagLevel", "Bell",
		"RewardClaim", "KeysHome", "HomeTeleport", "MineSprout", "Chests", "Pads", "SlapLevel", "Enhance", "FruitHome",
		"Feed", "FarmAdd", "KeyTrade", "StealKeys", "PlaceBossPath", "SlotBuy", "DefenseLevel", "ChallengeWave", "BombBuy",
		"BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "Mount", "WildRide", "RaceDone", "Merge", "Collection",
		"HideSeekGame", "Friends", "Rebirths" },
	[4] = { "Draws", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap", "PickaxeTier", "BagLevel",
		"Bell", "RewardClaim", "KeysHome", "HomeTeleport", "MineSprout", "Chests", "Pads", "SlapLevel", "Enhance", "FruitHome",
		"Feed", "FarmAdd", "KeyTrade", "StealKeys", "PlaceBossPath", "SlotBuy", "DefenseLevel", "ChallengeWave", "BombBuy",
		"BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "Mount", "WildRide", "RaceDone", "Merge", "Collection",
		"HideSeekGame", "Friends", "Rebirths" },
	[5] = { "Draws", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap", "PickaxeTier", "BagLevel",
		"Bell", "RewardClaim", "KeysHome", "HomeTeleport", "MineSprout", "Chests", "Pads", "SlapLevel", "MoveLevel", "SpeedLevel",
		"Enhance", "FruitHome", "Feed", "FarmAdd", "KeyTrade", "StealKeys", "MineTreasure", "PlaceBossPath", "SlotBuy",
		"DefenseLevel", "ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "WeatherMine",
		"Mount", "WildRide", "RaceDone", "RaceMedal", "Merge", "SuperThief", "Collection", "HideSeekGame", "Friends",
		"Rebirths" },
	[6] = { "Draws", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap", "GroupClear",
		"PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport", "MineSprout", "Chests", "Pads",
		"SlapLevel", "MoveLevel", "SpeedLevel", "Enhance", "FruitHome", "Feed", "FarmAdd", "KeyTrade", "StealKeys",
		"MineTreasure", "PlaceBossPath", "PromoPerfect", "SlotBuy", "DefenseLevel", "ChallengeWave", "BombBuy", "BombEgg",
		"BombPoop", "ZombieSlap", "BossHit", "NightMine", "WeatherMine", "Mount", "WildRide", "RaceDone", "RaceMedal",
		"Merge", "SuperThief", "Collection", "HideSeekGame", "Friends", "Rebirths", "NewMapWin" },
	[7] = { "Draws", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap", "GroupClear",
		"SetTargeting", "PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport", "MineSprout",
		"Chests", "Pads", "SlapLevel", "MoveLevel", "SpeedLevel", "Enhance", "FruitHome", "Feed", "FarmAdd", "KeyTrade",
		"StealKeys", "MineTreasure", "PlaceBossPath", "PromoPerfect", "SlotBuy", "DefenseLevel", "ChallengeWave",
		"BombBuy", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "WeatherMine", "Mount", "WildRide",
		"RaceDone", "RaceMedal", "Merge", "SuperThief", "Collection", "HideSeekGame", "Friends", "ShellPop",
		"AirshipDown", "Rebirths", "NewMapWin" },
	[8] = { "Draws", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap", "GroupClear",
		"SetTargeting", "PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport", "MineSprout",
		"Chests", "Pads", "SlapLevel", "MoveLevel", "SpeedLevel", "Enhance", "FruitHome", "Feed", "FarmAdd", "KeyTrade",
		"StealKeys", "MineTreasure", "PlaceBossPath", "PromoPerfect", "SlotBuy", "DefenseLevel", "MapSwitch",
		"ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "WeatherMine", "Mount",
		"WildRide", "RaceDone", "RaceMedal", "Merge", "SuperThief", "Collection", "HideSeekGame", "Friends", "ShellPop",
		"AirshipDown", "Rebirths", "NewMapWin" },
	[9] = { "Draws", "BoxOpen", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap", "GroupClear",
		"SetTargeting", "PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport", "MineSprout",
		"Chests", "Pads", "SlapLevel", "MoveLevel", "SpeedLevel", "Enhance", "FruitHome", "Feed", "FarmAdd", "KeyTrade",
		"StealKeys", "MineTreasure", "PlaceBossPath", "PromoPerfect", "SlotBuy", "DefenseLevel", "MapSwitch",
		"ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "WeatherMine", "Mount",
		"WildRide", "RaceDone", "RaceMedal", "Merge", "SuperThief", "Collection", "HideSeekGame", "Friends", "ShellPop",
		"AirshipDown", "Rebirths", "NewMapWin" },
	[10] = { "Draws", "BoxOpen", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap",
		"GroupClear", "SetTargeting", "PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport",
		"MineSprout", "Chests", "Pads", "SlapLevel", "MoveLevel", "SpeedLevel", "Enhance", "FruitHome", "Feed", "FarmAdd",
		"KeyTrade", "StealKeys", "MineTreasure", "PlaceBossPath", "PlaceNest", "PromoPerfect", "SlotBuy", "DefenseLevel",
		"MapSwitch", "ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine",
		"WeatherMine", "Mount", "WildRide", "RaceDone", "RaceMedal", "Merge", "SuperThief", "Collection", "HideSeekGame",
		"Friends", "ShellPop", "AirshipDown", "Rebirths", "NewMapWin" },
	[11] = { "Draws", "BoxOpen", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap",
		"GroupClear", "SetTargeting", "PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport",
		"MineSprout", "Chests", "Pads", "SlapLevel", "MoveLevel", "SpeedLevel", "Enhance", "FruitHome", "Feed", "FarmAdd",
		"KeyTrade", "StealKeys", "MineTreasure", "PlaceBossPath", "PromoPerfect", "SlotBuy", "DefenseLevel", "MapSwitch",
		"PlaceNest", "ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine",
		"WeatherMine", "Mount", "WildRide", "RaceDone", "RaceMedal", "Merge", "SuperThief", "Collection", "HideSeekGame",
		"Friends", "ShellPop", "AirshipDown", "Rebirths", "NewMapWin" },
	[12] = { "Draws", "BoxOpen", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap",
		"GroupClear", "SetTargeting", "PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport",
		"MineSprout", "Chests", "Pads", "SlapLevel", "MoveLevel", "SpeedLevel", "Enhance", "FruitHome", "Feed", "FarmAdd",
		"KeyTrade", "StealKeys", "MineTreasure", "PlaceBossPath", "TopView", "PromoPerfect", "SlotBuy", "DefenseLevel",
		"MapSwitch", "PlaceNest", "ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine",
		"WeatherMine", "Mount", "WildRide", "RaceDone", "RaceMedal", "Merge", "SuperThief", "Collection", "HideSeekGame",
		"Friends", "ShellPop", "AirshipDown", "Rebirths", "NewMapWin" },
	[13] = { "Draws", "BoxOpen", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap",
		"GroupClear", "SetTargeting", "PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport",
		"MineSprout", "Chests", "Pads", "SlapLevel", "MoveLevel", "SpeedLevel", "Enhance", "FruitHome", "Feed", "FarmAdd",
		"KeyTrade", "StealKeys", "MineTreasure", "TopView", "PromoPerfect", "SlotBuy", "DefenseLevel", "MapSwitch",
		"PlaceNest", "ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine",
		"WeatherMine", "Mount", "WildRide", "RaceDone", "RaceMedal", "Merge", "SuperThief", "Collection", "HideSeekGame",
		"Friends", "ShellPop", "AirshipDown", "Rebirths", "NewMapWin" },
	[14] = { "Draws", "BoxOpen", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap",
		"GroupClear", "SetTargeting", "PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport",
		"MineSprout", "Chests", "Pads", "SlapLevel", "MoveLevel", "SpeedLevel", "Enhance", "FruitHome", "Feed", "FarmAdd",
		"KeyTrade", "StealKeys", "MineTreasure", "TopView", "PromoPerfect", "SlotBuy", "DefenseLevel", "MapSwitch",
		"ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "WeatherMine", "Mount",
		"WildRide", "RaceDone", "RaceMedal", "Merge", "SuperThief", "Collection", "HideSeekGame", "Friends", "ShellPop",
		"AirshipDown", "Rebirths", "NewMapWin" },
	[15] = { "Draws", "BoxOpen", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap",
		"GroupClear", "SetTargeting", "PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport",
		"MineSprout", "Chests", "Pads", "SlapLevel", "MoveLevel", "SpeedLevel", "Enhance", "FruitHome", "Feed",
		"FarmAdd", "KeyTrade", "StealKeys", "MineTreasure", "TopView", "PromoPerfect", "SlotBuy", "DefenseLevel",
		"MapSwitch", "ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "Mount",
		"WildRide", "RaceDone", "Merge", "Collection", "HideSeekGame", "Friends", "ShellPop", "AirshipDown",
		"NewMapWin" },
	[16] = { "Draws", "BoxOpen", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap",
		"GroupClear", "SetTargeting", "PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport",
		"MineSprout", "Chests", "Pads", "SlapLevel", "MoveLevel", "SpeedLevel", "Enhance", "FruitHome", "Feed",
		"FarmAdd", "KeyTrade", "StealKeys", "MineTreasure", "TopView", "PromoPerfect", "SlotBuy", "DefenseLevel",
		"MapSwitch", "ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine",
		"Mount", "WildRide", "RaceDone", "Merge", "Collection", "ShellPop", "AirshipDown", "NewMapWin" },
	[17] = { "Draws", "BoxOpen", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap",
		"GroupClear", "SetTargeting", "PickaxeTier", "BagLevel", "Bell", "RewardClaim", "KeysHome", "HomeTeleport",
		"MineSprout", "Chests", "Pads", "SlapLevel", "MoveLevel", "SpeedLevel", "Enhance", "FruitHome", "Feed",
		"FarmAdd", "KeyTrade", "StealKeys", "MineTreasure", "TopView", "PromoPerfect", "SlotBuy", "DefenseLevel",
		"MapSwitch", "ChallengeWave", "BombBuy", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine",
		"Mount", "WildRide", "RaceDone", "Merge", "Collection", "ShellPop", "AirshipDown", "NewMapWin", "PerchPlace",
		"TwistWin" },
	[18] = { "Draws", "BoxOpen", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap",
		"BagLevel", "SlapLevel", "MoveLevel", "SpeedLevel", "PickaxeTier", "GroupClear", "SetTargeting", "Bell",
		"RewardClaim", "DefenseLevel", "Enhance", "FruitHome", "Feed", "KeysHome", "HomeTeleport", "MineSprout", "Chests",
		"Pads", "FarmAdd", "KeyTrade", "StealKeys", "MineTreasure", "TopView", "PromoPerfect", "SlotBuy", "BombBuy",
		"BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "ChallengeWave", "MapSwitch", "NewMapWin", "ShellPop",
		"AirshipDown", "Mount", "WildRide", "Merge", "Collection", "RaceDone", "PerchPlace", "TwistWin" },
	[19] = { "Draws", "BoxOpen", "MineDroplet", "Deposit", "KeyBuy", "PlacedDinos", "Promotion", "PromoSlap",
		"BagLevel", "SlapLevel", "MoveLevel", "SpeedLevel", "Bell", "RewardClaim", "PickaxeTier", "GroupClear",
		"SetTargeting", "DefenseLevel", "FruitHome", "TopView", "Collection", "Merge", "HomeTeleport", "Chests", "Pads",
		"WildRide", "MineTreasure", "KeyTrade", "SlotBuy", "PromoPerfect", "NewMapWin", "ShellPop", "AirshipDown",
		"TwistWin", "MineSprout", "PerchPlace", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "KeysHome",
		"StealKeys" },
	[20] = { "Promotion", "PromoSlap", "Draws", "BoxOpen", "PlacedDinos", "MineDroplet", "Deposit", "KeyBuy",
		"BagLevel", "SlapLevel", "MoveLevel", "SpeedLevel", "Bell", "RewardClaim", "GroupClear", "SetTargeting",
		"TopView", "Collection", "DefenseLevel", "NewMapWin", "ShellPop", "AirshipDown", "TwistWin", "PromoPerfect",
		"KeyTrade", "Merge", "PerchPlace", "PickaxeTier", "FruitHome", "Chests", "Pads", "WildRide", "HomeTeleport",
		"SlotBuy", "MineTreasure", "MineSprout", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "KeysHome",
		"StealKeys" },
	[21] = { "Draws", "BoxOpen", "PlacedDinos", "Promotion", "PromoSlap", "MineDroplet", "Deposit", "KeyBuy",
		"BagLevel", "SlapLevel", "MoveLevel", "SpeedLevel", "Bell", "RewardClaim", "GroupClear", "SetTargeting",
		"TopView", "Collection", "DefenseLevel", "NewMapWin", "ShellPop", "AirshipDown", "TwistWin", "PromoPerfect",
		"KeyTrade", "Merge", "PerchPlace", "PickaxeTier", "FruitHome", "Chests", "Pads", "WildRide", "HomeTeleport",
		"SlotBuy", "MineTreasure", "MineSprout", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "KeysHome",
		"StealKeys" },
	[22] = { "Draws", "BoxOpen", "PlacedDinos", "Promotion", "PromoSlap", "FarmAdd", "MineDroplet", "Deposit", "KeyBuy",
		"BagLevel", "SlapLevel", "MoveLevel", "SpeedLevel", "Bell", "RewardClaim", "GroupClear", "SetTargeting",
		"TopView", "Collection", "DefenseLevel", "NewMapWin", "ShellPop", "AirshipDown", "TwistWin", "PromoPerfect",
		"KeyTrade", "Merge", "PerchPlace", "PickaxeTier", "FruitHome", "Chests", "Pads", "WildRide", "HomeTeleport",
		"SlotBuy", "FarmSlots", "MineTreasure", "MineSprout", "BombPoop", "ZombieSlap", "BossHit", "NightMine",
		"KeysHome", "StealKeys" },
	[23] = { "Draws", "BoxOpen", "PlacedDinos", "Promotion", "PromoSlap", "FarmAdd", "MineDroplet", "Deposit", "KeyBuy",
		"BagLevel", "SlapLevel", "MoveLevel", "SpeedLevel", "Bell", "RewardClaim", "GroupClear", "SetTargeting",
		"TopView", "Collection", "NewMapWin", "KeyTrade", "Merge", "PerchPlace", "PickaxeTier", "TwistWin", "SlotBuy",
		"FarmSlots", "ShellPop", "AirshipDown", "PromoPerfect", "DefenseLevel", "ChallengeWave", "Pads", "Chests",
		"MineTreasure", "ZombieSlap", "BombEgg", "BossHit", "BombPoop", "MineSprout", "NightMine", "StealKeys",
		"KeysHome", "FruitHome", "WildRide", "HomeTeleport", "Rebirths" },
	[24] = { "Draws", "BoxOpen", "PlacedDinos", "Promotion", "PromoSlap", "FarmAdd", "MineDroplet", "Deposit", "KeyBuy",
		"BagLevel", "SlapLevel", "MoveLevel", "SpeedLevel", "Bell", "RewardClaim", "GroupClear", "SetTargeting",
		"TopView", "Collection", "NewMapWin", "KeyTrade", "Merge", "PerchPlace", "PickaxeTier", "TwistWin", "SlotBuy",
		"FarmSlots", "ShellPop", "AirshipDown", "PromoPerfect", "DefenseLevel", "ChallengeWave", "Pads", "Chests",
		"MineTreasure", "ZombieSlap", "BombEgg", "BossHit", "BombPoop", "MineSprout", "NightMine", "StealKeys",
		"KeysHome", "HomeTeleport", "FruitHome", "WildRide", "Rebirths" },
	[25] = { "Draws", "BoxOpen", "PlacedDinos", "Promotion", "PromoSlap", "FarmAdd", "FarmSlots", "MineDroplet", "Deposit",
		"KeyBuy", "KeyTrade", "Bell", "RewardClaim", "BagLevel", "SlapLevel", "MoveLevel", "SpeedLevel", "Merge", "Collection",
		"SetTargeting", "TopView", "SlotBuy", "PerchPlace", "NewMapWin", "GroupClear", "PromoPerfect", "PickaxeTier", "Pads",
		"Chests", "HomeTeleport", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "NightMine", "StealKeys", "KeysHome",
		"FruitHome", "WildRide", "Rebirths" },
	[26] = { "Draws", "BoxOpen", "PlacedDinos", "Promotion", "PromoSlap", "FarmAdd", "FarmSlots", "MineDroplet", "Deposit",
		"KeyBuy", "KeyTrade", "Bell", "RewardClaim", "BagLevel", "SlapLevel", "MoveLevel", "SpeedLevel", "Merge", "Collection",
		"SetTargeting", "TopView", "SlotBuy", "PerchPlace", "NewMapWin", "GroupClear", "PromoPerfect", "PickaxeTier", "Pads",
		"Chests", "HomeTeleport", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "BossBomb", "NightMine", "StealKeys",
		"KeysHome", "FruitHome", "WildRide", "Rebirths" },
	[27] = { "Draws", "BoxOpen", "PlacedDinos", "Promotion", "PromoSlap", "FarmAdd", "FarmSlots", "KeyBuy", "Merge",
		"Collection", "KeyTrade", "RewardClaim", "SetTargeting", "TopView", "SlotBuy", "PerchPlace", "NewMapWin", "GroupClear",
		"PromoPerfect", "BagLevel", "SlapLevel", "MoveLevel", "SpeedLevel", "MineDroplet", "Deposit", "PickaxeTier", "Pads",
		"Chests", "HomeTeleport", "Bell", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "BossBomb", "NightMine", "StealKeys",
		"KeysHome", "FruitHome", "WildRide", "Rebirths" },
	[28] = { "Draws", "BoxOpen", "PlacedDinos", "Promotion", "FarmAdd", "FarmSlots", "KeyBuy", "MineDroplet", "Deposit",
		"PickaxeTier", "Pads", "Chests", "HomeTeleport", "FruitHome", "WildRide", "PromoSlap", "SetTargeting", "TopView",
		"SlotBuy", "PerchPlace", "GroupClear", "PromoPerfect", "Merge", "Collection", "KeyTrade", "RewardClaim", "BagLevel",
		"SlapLevel", "MoveLevel", "SpeedLevel", "ZombieSlap", "BossHit", "NightMine", "StealKeys", "KeysHome", "BombEgg",
		"BombPoop", "BossBomb", "NewMapWin", "Bell", "Rebirths" },
	[29] = { "Draws", "BoxOpen", "PlacedDinos", "Promotion", "PromoSlap", "FarmAdd", "FarmSlots", "KeyBuy", "Merge",
		"Collection", "KeyTrade", "RewardClaim", "SetTargeting", "TopView", "SlotBuy", "PerchPlace", "GroupClear",
		"PromoPerfect", "BagLevel", "SlapLevel", "MoveLevel", "SpeedLevel", "PowerReady", "PickaxeTier", "MineDroplet",
		"Deposit", "Pads", "Chests", "HomeTeleport", "Bell", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "BossBomb",
		"NightMine", "StealKeys", "KeysHome", "FruitHome", "WildRide", "Rebirths" },
	[30] = { "Draws", "BoxOpen", "PlacedDinos", "Promotion", "PromoSlap", "FarmAdd", "FarmSlots", "KeyBuy", "Merge",
		"Collection", "KeyTrade", "RewardClaim", "SetTargeting", "TopView", "SlotBuy", "PerchPlace", "GroupClear",
		"PromoPerfect", "BagLevel", "SlapLevel", "MoveLevel", "SpeedLevel", "PowerReady", "PickaxeTier", "MineDroplet",
		"Deposit", "Pads", "Chests", "HomeTeleport", "Bell", "BombEgg", "BombPoop", "ZombieSlap", "BossHit", "BossBomb",
		"PracticeBossDown", "NightMine", "StealKeys", "KeysHome", "FruitHome", "WildRide", "GrowBoss", "GrowDraw",
		"GrowBoxes", "GrowEnhance", "GrowPlace", "GrowChests", "GrowAltar", "Rebirths" },
}

StarterLogic.OLD_ORDERS = OLD_ORDERS

local function indexOf(id)
	for i, m in ipairs(missions()) do
		if idOf(m) == id then
			return i
		end
	end
	return nil
end

-- the mission now (its table and index), nil when done
function StarterLogic.current(state)
	while state.Extra and state.Extra[1] and not indexOf(state.Extra[1]) do
		table.remove(state.Extra, 1)
		state.Count = 0
		if not state.Extra[1] then
			state.Extra = nil
			state.Count = state.MainCount or 0
			state.MainCount = nil
		end
	end
	if state.Extra and state.Extra[1] then
		local i = indexOf(state.Extra[1])
		return missions()[i], i
	end
	if state.Done then
		return nil
	end
	local m = missions()[state.Step]
	if not m then
		return nil
	end
	return m, state.Step
end

-- how far the mission is: the count toward its Target (capped)
function StarterLogic.progress(state, facts)
	local m = StarterLogic.current(state)
	if not m then
		return 0
	end
	local n = if m.Comeback then state.Count or 0
		elseif m.Event then math.max(state.Count or 0, not m.Fresh and facts.Ever and facts.Ever[m.Event] or 0)
		else facts[m.Goal] or 0
	if m.FirstWave and (facts.DefenseLevel or 1) > 1 then
		n = m.Target
	end
	return math.min(n, m.Target)
end

function StarterLogic.ready(state, facts)
	local m = StarterLogic.current(state)
	if m and m.VisitFirst and not (facts.Visited and facts.Visited[idOf(m)]) then
		return false
	end
	return m ~= nil and StarterLogic.progress(state, facts) >= m.Target
end

-- an event (a Rewards.add kind) counts toward the mission now if it is that mission's; true when it is
function StarterLogic.event(state, kind, amount)
	local m = StarterLogic.current(state)
	if not m or m.Event ~= kind or (amount or 0) <= 0 then
		return false
	end
	state.Count = math.min(m.Target, (state.Count or 0) + amount)
	return true
end

local function loopStart()
	for i, m in ipairs(missions()) do
		if m.Loop then
			return i
		end
	end
	return nil
end

local function passBy(state)
	local m = missions()[state.Step]
	while m and (m.Comeback or (state.Skip and state.Skip[idOf(m)])) do
		if state.Skip then
			state.Skip[idOf(m)] = nil
		end
		state.Step += 1
		m = missions()[state.Step]
	end
	if state.Skip and next(state.Skip) == nil then
		state.Skip = nil
	end
	return m
end

local function pastLoop(state)
	local m = missions()[state.Step]
	while m and m.Loop do
		state.Step += 1
		m = missions()[state.Step]
	end
	return passBy(state)
end

-- the next mission, passing by the ones done on an older order (Skip)
local function nextMission(state, facts)
	if state.Extra and state.Extra[1] then
		table.remove(state.Extra, 1)
		state.Count = 0
		if not state.Extra[1] then
			state.Extra = nil
			state.Count = state.MainCount or 0
			state.MainCount = nil
		end
		return
	end
	state.Step += 1
	local m = passBy(state)
	if m and m.Loop and facts and facts.AtTop then
		m = pastLoop(state)
	elseif m and m.LoopBack and facts and not facts.AtTop and loopStart() then
		state.Step = loopStart()
		m = missions()[state.Step]
	end
	state.Count = 0
	if not m then
		state.Done = true
	end
end

-- (2026-10-04) a save on an older order (state.Order below Config.StarterMissions.Order): the missions it had done
-- go in Skip (no reward twice), and it goes to the first one in the new order it hasn't done (keeping its count if
-- that is the one it was on). A new save (Step 1) just takes the new order. True when it changed
function StarterLogic.upgrade(state)
	local order = Config.StarterMissions.Order
	local from = state.Order or 1
	if from >= order then
		return false
	end
	state.Order = order
	local old = OLD_ORDERS[from]
	if not old then
		return true
	end
	local inOldList = {}
	for _, id in ipairs(old) do
		inOldList[id] = true
	end
	for _, m in ipairs(missions()) do
		if m.DoneWith and inOldList[m.DoneWith] then
			inOldList[idOf(m)] = true
		end
	end
	if state.Done then
		local extra = {}
		for _, m in ipairs(missions()) do
			if not m.Comeback and not m.Loop and not m.NoCatchUp and not inOldList[idOf(m)] then
				table.insert(extra, idOf(m))
			end
		end
		if extra[1] then
			state.Extra, state.MainCount, state.Count = extra, 0, 0
		end
		return true
	end
	local extra = {}
	local done, was, count = {}, old[state.Step], state.Count
	for i = 1, math.min((state.Step or 1) - 1, #old) do
		done[old[i]] = true
	end
	for _, m in ipairs(missions()) do
		if m.DoneWith and done[m.DoneWith] then
			done[idOf(m)] = true
		end
	end
	if next(done) then
		local inOld, limit = inOldList, 0
		local resume = #missions() + 1
		for i, m in ipairs(missions()) do
			if done[idOf(m)] or idOf(m) == was then
				limit = math.max(limit, idOf(m) == was and i - 1 or i)
			end
			if resume > #missions() and not m.Comeback and inOld[idOf(m)] and not done[idOf(m)] then
				resume = i
			end
		end
		limit = math.min(limit, resume - 1)
		for i = 1, limit do
			local id = idOf(missions()[i])
			if not inOld[id] and not missions()[i].Comeback and not missions()[i].Loop then
				done[id] = true
				table.insert(extra, id)
			end
		end
	end
	for id in pairs(done) do
		if not indexOf(id) then
			done[id] = nil
		end
	end
	state.Skip = next(done) and done or nil
	state.Step = 0
	nextMission(state)
	local m = missions()[state.Step]
	local wasAt = was and indexOf(was)
	local carry = wasAt ~= nil and missions()[wasAt].Event ~= nil and (count or 0) > 0 and not (m and idOf(m) == was)
		and (missions()[wasAt].Ch or 1) <= (m and m.Ch or math.huge)
	if carry then
		table.insert(extra, 1, was)
		state.Skip = state.Skip or {}
		state.Skip[was] = true
	end
	if m and idOf(m) == was then
		state.Count = count
	end
	if extra[1] then
		state.Extra, state.MainCount, state.Count = extra, state.Count or 0, carry and count or 0
	end
	return true
end

function StarterLogic.merge(a, b)
	local done, counts = {}, {}
	for _, st in ipairs({ a, b }) do
		local waiting = {}
		for _, id in ipairs(st.Extra or {}) do
			waiting[id] = true
		end
		for i, m in ipairs(missions()) do
			local id = idOf(m)
			if not m.Comeback and not waiting[id] and (st.Done or i < (st.Step or 1) or (st.Skip and st.Skip[id])) then
				done[id] = true
			end
		end
		local on = not st.Done and missions()[st.Step or 1]
		if on then
			local n = if st.Extra and st.Extra[1] then st.MainCount else st.Count
			counts[idOf(on)] = math.max(counts[idOf(on)] or 0, n or 0)
		end
	end
	local merged = table.clone(a)
	merged.Step, merged.Count, merged.Done, merged.Skip = 0, 0, false, done
	merged.Extra, merged.MainCount = nil, nil
	merged.Order = Config.StarterMissions.Order
	merged.Comeback = (a.Comeback or b.Comeback) or nil
	nextMission(merged)
	local m = not merged.Done and missions()[merged.Step]
	merged.Count = m and counts[idOf(m)] or 0
	return merged
end

function StarterLogic.reached(state, id)
	if type(state) ~= "table" or state.Done or (state.Skip and state.Skip[id]) then
		return true
	end
	for _, e in ipairs(state.Extra or {}) do
		if e == id then
			return true
		end
	end
	local at = indexOf(id)
	return at == nil or at <= (state.Step or 1)
end

function StarterLogic.comeback(state, ids)
	if state.Done or state.Comeback or (state.Extra and state.Extra[1]) or not ids[1] then
		return false
	end
	state.Comeback = true
	state.Extra, state.MainCount, state.Count = ids, state.Count or 0, 0
	return true
end

function StarterLogic.finished(state)
	return state.Done == true and not (state.Extra and state.Extra[1])
end

function StarterLogic.pastFirstFight(state)
	if state.Done then
		return true
	end
	for i, m in ipairs(missions()) do
		if m.Fight then
			return (state.Step or 1) > i
		end
	end
	return true
end

-- take the mission's reward when it is reached: the reward or nil
function StarterLogic.claim(state, facts)
	if not StarterLogic.ready(state, facts) then
		return nil
	end
	local reward = StarterLogic.current(state).Reward
	nextMission(state, facts)
	return reward
end

function StarterLogic.skipLoop(state)
	local m = StarterLogic.current(state)
	if not m or not m.Loop or (state.Extra and state.Extra[1]) then
		return false
	end
	state.Count = 0
	if not pastLoop(state) then
		state.Done = true
	end
	return true
end

function StarterLogic.passable(state, atTop)
	local m = StarterLogic.current(state)
	return m ~= nil and (m.Optional == true or (atTop == true and m.Fight == true))
end

function StarterLogic.pass(state, atTop)
	if not StarterLogic.passable(state, atTop) then
		return false
	end
	nextMission(state, { AtTop = atTop == true })
	return true
end

-- the reward in words, with pictures (the board and the notice)
-- (2026-10-04: the words are Formulas', shared with the 🎁 window's 📋 tab)
function StarterLogic.rewardText(reward)
	return Formulas.starterRewardText(reward)
end

function StarterLogic.mergeDinos(units, rarity)
	local ids = {}
	for i = #units, 1, -1 do
		local u = units[i]
		if #ids < Config.Merge.Count and u.Rarity == rarity and u.Size == "Young" and u.Level == Config.Merge.Level
			and (u.Exp or 0) == 0 then
			table.insert(ids, u.Id)
		end
	end
	return ids
end

return StarterLogic
