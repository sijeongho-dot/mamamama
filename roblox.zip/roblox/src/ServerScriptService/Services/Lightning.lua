--[[
Lightning: storm bolts that land where things are (2026-10-02, "천둥번개 날씨에 번개치는 곳에 사람이나
좀비공룡 농장공룡 야생공룡들이 있으면 약간 튕겨나게 하자. 공룡들은 맞으면 짧게 비명지름"; Config.Lightning).

While the weather is Storm (ReplicatedStorage attribute Weather, the Weather service), every EverySeconds
a bolt lands NearPlayer studs from a random player (on the ground there). Every screen gets Net push
Lightning (x, y, z, warnSeconds, radius): the spot crackles for WarnSeconds (WeatherFx), then the bolt and
the thunder. Then, within Radius:
- players fly PlayerStuds away from it, a light throw: nothing drops, no groggy (MoveGuard.loosen lets
  them fly). Not one racing, flying on a dino, stuck, or in the tutorial's shield;
- zombie dinos (not the bosses) are thrown like a slap and cry out (Zombies.lightning);
- farm and wild dinos are drawn by each screen: they hop away and yelp there (DefenseView, Wildlife).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local Zombies = require(script.Parent:WaitForChild("Zombies"))

local Lightning = {}

local FLY_GRACE = 1.5 -- seconds MoveGuard lets a struck player fly (and land)
local rng = Random.new()

local function groundAt(position)
	local params = RaycastParams.new()
	local ignore = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	params.FilterDescendantsInstances = ignore
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true
	local hit = Workspace:Raycast(position + Vector3.new(0, 60, 0), Vector3.new(0, -200, 0), params)
	return hit and hit.Position or position
end

local function knockable(player)
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not root or not humanoid or humanoid.Health <= 0 or player:GetAttribute("Racing") or player:GetAttribute("HideSeekRoom") or player:GetAttribute("Flying")
		or player:GetAttribute("TutorialShield") or player:GetAttribute("InTutorial") or MoveGuard.stunned(player) then
		return nil
	end
	return root
end

-- a bolt at `at` (Studio tests call it with a spot; the loop picks one near a player)
function Lightning.strike(at)
	local c = Config.Lightning
	local spot = groundAt(at)
	Net.pushAll("Lightning", spot.X, spot.Y, spot.Z, c.WarnSeconds, c.Radius)
	task.delay(c.WarnSeconds, function()
		for _, p in ipairs(Players:GetPlayers()) do
			local root = knockable(p)
			if root then
				local off = root.Position - spot
				local flat = Vector3.new(off.X, 0, off.Z)
				if flat.Magnitude <= c.Radius and math.abs(off.Y) < c.Radius then
					local away = flat.Magnitude > 0.1 and flat.Unit or Vector3.xAxis
					MoveGuard.loosen(p, c.PlayerFlightSeconds + FLY_GRACE)
					Net.push(p, "Knockback", away.X, away.Z, c.PlayerStuds, c.PlayerFlightSeconds, 0)
					Net.pushAll("FlyFx", p.UserId, c.PlayerFlightSeconds)
				end
			end
		end
		Zombies.lightning(spot, c.Radius)
	end)
end

function Lightning.init()
	task.spawn(function()
		local c = Config.Lightning
		while true do
			task.wait(rng:NextNumber(c.EverySeconds[1], c.EverySeconds[2]))
			if ReplicatedStorage:GetAttribute("Weather") == "Storm" then
				local roots = {}
				for _, p in ipairs(Players:GetPlayers()) do
					local root = p.Character and p.Character:FindFirstChild("HumanoidRootPart")
					if root then
						table.insert(roots, root)
					end
				end
				if #roots > 0 then
					local root = roots[rng:NextInteger(1, #roots)]
					local angle, r = rng:NextNumber(0, 2 * math.pi), rng:NextNumber(c.NearPlayer[1], c.NearPlayer[2])
					Lightning.strike(root.Position + Vector3.new(math.cos(angle) * r, 0, math.sin(angle) * r))
				end
			end
		end
	end)
end

return Lightning
