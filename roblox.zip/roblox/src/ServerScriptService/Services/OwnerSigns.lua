--[[
OwnerSigns: a sign at every base's entrance saying whose base it is: the owner's avatar picture,
display name, @name and defense level (and rebirths), and the owner's picture and name high in the sky
over the middle of the base, big enough to find home from anywhere. An empty base says so (and has no
picture in the sky). Display only.

The sign is made when the server starts, just outside the front fence beside the entrance (a board
on two posts in the base's team color, facing out toward the map center). It follows the base's
OwnerUserId attribute (Bases) and the owner's profile (PlayerData.onChanged, level and rebirths).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))

local OwnerSigns = {}

-- display only
local BOARD_SIZE = Vector3.new(9, 5, 0.4)
local BOARD_HEIGHT = 4.5 -- studs from the ground to the board's middle
local POST_SIZE = Vector3.new(0.5, 7, 0.5)
local SIDE = 6 -- studs from the edge of the entrance gap to the sign
local OUT = 3 -- studs outside the front fence
local PIXELS_PER_STUD = 50
local COLOR_POST = Color3.fromRGB(110, 80, 55)
local COLOR_EMPTY = Color3.fromRGB(150, 150, 155)
local COLOR_TEXT = Color3.new(1, 1, 1)
local COLOR_LEVEL = Color3.fromRGB(255, 220, 90)
-- the owner's picture high over the middle of the base, sized in studs so it reads from far away
-- (2026-10-01, "bigger, seen well from afar": was 30 studs at 58 up, shrinking away with distance)
local SKY_PICTURE_HEIGHT = 78 -- studs over the plot
local SKY_PICTURE_STUDS = 45 -- the picture's width and height in the world
local SKY_NAME_STUDS = 9
local SKY_NAME_WIDE = 1.8
local SKY_NAME_TEXT_MAX = 64
local SKY_SEE_THROUGH = 0.55 -- the picture see-through, so it does not block the view (2026-10-01: was 0.3, "more see-through")
local SKY_MAX_DISTANCE = 2000

local signs = {} -- [base number] = { board, picture, name, handle, level, sky, skyPicture, skyName }

local function groundY(position, ignore)
	local params = RaycastParams.new()
	params.FilterDescendantsInstances = ignore
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true
	local hit = Workspace:Raycast(position + Vector3.new(0, 60, 0), Vector3.new(0, -200, 0), params)
	return hit and hit.Position.Y or position.Y
end

local function part(props)
	local p = Instance.new("Part")
	p.Anchored = true
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	for k, v in pairs(props) do
		p[k] = v
	end
	return p
end

local function text(parent, size, pos, textSize, color)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = Enum.Font.GothamBold
	l.TextScaled = true
	l.TextColor3 = color
	l.TextStrokeTransparency = 0.4
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.Size = size
	l.Position = pos
	local limit = Instance.new("UITextSizeConstraint")
	limit.MaxTextSize = textSize
	limit.Parent = l
	l.Parent = parent
	return l
end

local function makeSign(index, folder)
	local zone = folder:FindFirstChild("SafeZone")
	if not zone then
		return nil
	end
	local flat = Vector3.new(zone.Position.X, 0, zone.Position.Z)
	if flat.Magnitude < 1e-3 then
		return nil
	end
	local out = flat.Unit -- from the map center through the plot; the entrance faces the other way
	local right = out:Cross(Vector3.yAxis).Unit
	local front = flat - out * (Config.Map.PlotDepth / 2)
	local spot = front + right * (Config.Map.EntranceWidth / 2 + SIDE) - out * OUT
	local model = Instance.new("Model")
	model.Name = "OwnerSign"
	local y = groundY(Vector3.new(spot.X, zone.Position.Y, spot.Z), { folder })
	local at = Vector3.new(spot.X, y, spot.Z)
	local facing = CFrame.lookAt(at, at - out) -- the board's front toward the map center
	local teamColor = folder:GetAttribute("TeamColor")
	local board = part({ Name = "Board", Size = BOARD_SIZE, CFrame = facing * CFrame.new(0, BOARD_HEIGHT, 0),
		Color = teamColor and BrickColor.new(teamColor).Color or COLOR_EMPTY, Parent = model })
	for _, x in ipairs({ -BOARD_SIZE.X / 2 + 0.6, BOARD_SIZE.X / 2 - 0.6 }) do
		part({ Name = "Post", Size = POST_SIZE, CFrame = facing * CFrame.new(x, POST_SIZE.Y / 2, 0.3), Color = COLOR_POST,
			Parent = model })
	end

	local gui = Instance.new("SurfaceGui")
	gui.AutoLocalize = false
	gui.Face = Enum.NormalId.Front
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud = PIXELS_PER_STUD
	gui.Parent = board
	local back = Instance.new("Frame")
	back.Size = UDim2.fromScale(1, 1)
	back.BackgroundColor3 = Color3.new(0, 0, 0)
	back.BackgroundTransparency = 0.55
	back.Parent = gui
	local picture = Instance.new("ImageLabel")
	picture.AnchorPoint = Vector2.new(0, 0.5)
	picture.Position = UDim2.new(0.04, 0, 0.5, 0)
	picture.Size = UDim2.fromScale(0.36, 0.72)
	picture.BackgroundColor3 = Color3.fromRGB(40, 44, 60)
	picture.Parent = back
	local aspect = Instance.new("UIAspectRatioConstraint")
	aspect.Parent = picture
	local round = Instance.new("UICorner")
	round.CornerRadius = UDim.new(0.5, 0)
	round.Parent = picture
	local s = {
		board = board,
		picture = picture,
		owner = text(back, UDim2.fromScale(0.52, 0.14), UDim2.fromScale(0.44, 0.1), 40, COLOR_TEXT),
		name = text(back, UDim2.fromScale(0.52, 0.26), UDim2.fromScale(0.44, 0.24), 90, COLOR_TEXT),
		handle = text(back, UDim2.fromScale(0.52, 0.14), UDim2.fromScale(0.44, 0.5), 50, COLOR_TEXT),
		level = text(back, UDim2.fromScale(0.52, 0.2), UDim2.fromScale(0.44, 0.68), 70, COLOR_LEVEL),
	}
	-- the picture in the sky over the plot
	local anchor = part({ Name = "SkyAnchor", Size = Vector3.one, Transparency = 1, CanCollide = false, CanQuery = false,
		CanTouch = false, CFrame = CFrame.new(flat.X, zone.Position.Y + SKY_PICTURE_HEIGHT, flat.Z), Parent = model })
	local sky = Instance.new("BillboardGui")
	sky.AutoLocalize = false
	sky.Name = "OwnerPicture"
	-- scale = studs (bigger up close), plus pixels (still a good size far away)
	local tall = SKY_PICTURE_STUDS + SKY_NAME_STUDS
	sky.Size = UDim2.fromScale(SKY_PICTURE_STUDS * SKY_NAME_WIDE, tall)
	sky.MaxDistance = SKY_MAX_DISTANCE
	sky.LightInfluence = 0
	-- drawn over the haze (rain and storms thicken it: the picture faded out from afar), as it hangs high
	-- above everything anyway
	sky.AlwaysOnTop = true
	sky.Adornee = anchor
	sky.Enabled = false
	sky.Parent = anchor
	local ring = Instance.new("ImageLabel")
	ring.Size = UDim2.fromScale(1 / SKY_NAME_WIDE, SKY_PICTURE_STUDS / (SKY_PICTURE_STUDS + SKY_NAME_STUDS))
	ring.Position = UDim2.fromScale((1 - 1 / SKY_NAME_WIDE) / 2, 0)
	ring.BackgroundColor3 = board.Color
	ring.ImageTransparency = SKY_SEE_THROUGH
	ring.BackgroundTransparency = SKY_SEE_THROUGH
	ring.Parent = sky
	local ringRound = Instance.new("UICorner")
	ringRound.CornerRadius = UDim.new(0.5, 0)
	ringRound.Parent = ring
	local ringStroke = Instance.new("UIStroke")
	ringStroke.Color = board.Color
	ringStroke.Thickness = 6
	ringStroke.Transparency = SKY_SEE_THROUGH
	ringStroke.Parent = ring
	s.sky = sky
	s.skyPicture = ring
	s.skyName = text(sky, UDim2.fromScale(1, SKY_NAME_STUDS / (SKY_PICTURE_STUDS + SKY_NAME_STUDS)),
		UDim2.fromScale(0, SKY_PICTURE_STUDS / (SKY_PICTURE_STUDS + SKY_NAME_STUDS)), SKY_NAME_TEXT_MAX, COLOR_TEXT)
	s.skyName.TextXAlignment = Enum.TextXAlignment.Center
	s.skyName:SetAttribute("KeepText", true)
	s.name:SetAttribute("KeepText", true)
	s.handle:SetAttribute("KeepText", true)
	model.Parent = folder
	return s
end

local function refresh(index)
	local s = signs[index]
	local folder = Bases.folder(index)
	if not s or not folder then
		return
	end
	local userId = folder:GetAttribute("OwnerUserId")
	local owner = userId and Players:GetPlayerByUserId(userId)
	if not owner then
		s.sky.Enabled = false
		s.picture.Image = ""
		s.owner.Text = string.format("기지 %d", index)
		s.name.Text = "빈 기지"
		s.handle.Text = ""
		s.level.Text = ""
		return
	end
	s.picture.Image = string.format("rbxthumb://type=AvatarHeadShot&id=%d&w=150&h=150", owner.UserId)
	s.skyPicture.Image = string.format("rbxthumb://type=AvatarHeadShot&id=%d&w=420&h=420", owner.UserId)
	s.skyName.Text = owner.DisplayName
	s.sky.Enabled = true
	s.owner.Text = "이곳의 주인"
	s.name.Text = owner.DisplayName
	s.handle.Text = "@" .. owner.Name
	local profile = PlayerData.get(owner)
	if profile then
		s.level.Text = (profile.Rebirths or 0) > 0
				and string.format("디펜스 %s · 환생 %d", Formulas.levelText(profile.DefenseLevel, profile.Rebirths), profile.Rebirths)
			or string.format("디펜스 %s", Formulas.levelText(profile.DefenseLevel, 0))
	else
		s.level.Text = ""
	end
end

function OwnerSigns.init()
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			local old = folder:FindFirstChild("OwnerSign")
			if old then
				old:Destroy()
			end
			signs[index] = makeSign(index, folder)
			folder:GetAttributeChangedSignal("OwnerUserId"):Connect(function()
				refresh(index)
			end)
			refresh(index)
		end
	end
	local shown = {} -- [player] = "level|rebirths" last shown, to skip the many money-only changes
	local function changed(player, profile)
		local index = Bases.of(player)
		local key = profile.DefenseLevel .. "|" .. (profile.Rebirths or 0)
		if index and shown[player] ~= key then
			shown[player] = key
			refresh(index)
		end
	end
	PlayerData.onLoaded(changed)
	PlayerData.onChanged(changed)
	Players.PlayerRemoving:Connect(function(player)
		shown[player] = nil
	end)
end

return OwnerSigns
