--[[
SpeedPads: speed pads out in the open for the key race (Config.SpeedPads).

Every SpawnInterval seconds, while fewer than MaxOnField lie around, a pad appears at a random spot
on the battlefield, between the key zone and the battlefield's edge (Config.Battlefield.Radius, the
orange band; never inside a SafeZone): of Candidates
random spots, the one farthest from the pads already out, so they spread evenly over the field. The first
player to step on it runs MultiplierMin-MultiplierMax times faster for BoostSeconds, CarryBoostSeconds
while carrying keys (Formulas.speedPadSeconds, MoveGuard.boost)
and the pad is gone. No stacking: while a boost is on, a better pad (higher multiplier) replaces it
at once, and an equal or weaker pad keeps the better speed and starts its time over (keep hitting pads,
keep the speed). Pads nobody took disappear after Lifetime seconds.

(2026-10-04, "게임 최적화", with 850 pads out) a pad is one part with its multiplier as the attribute Multiplier; the
"⚡ 속도 x1.8" label is drawn by each client only near its camera (StarterPlayerScripts/SpeedPadLabels), not sent
with every pad (it was 5 more instances per pad, ~27 pads a second, to every player). Who stands on a pad is looked
up in a grid of CELL studs around each player (was every pad against every player, 10 times a second).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))
local SafeZones = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("SafeZones"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))

local SpeedPads = {}

-- display only
local PAD_HEIGHT = 0.3
local PAD_COLOR = Color3.fromRGB(80, 230, 255)
local TRIES = 20 -- random spots tried for one pad
local CELL = 16 -- studs: the grid the pads are looked up in (bigger than a pad's Radius)
local REACH_Y = 6 -- studs up or down from a pad that still count as on it

local folder = nil
local pads = {} -- [part] = { multiplier, born, cell }
local grid = {} -- [cell key] = { [part] = true }
local count = 0 -- pads out
local OFF_GROUND = { "Decor", "FieldDecor", "BattlefieldFlags" } -- Map folders a pad never goes on (trees, rocks)
local rng = Random.new()

local function cellKey(x, z)
	return math.floor(x / CELL) * 65536 + math.floor(z / CELL)
end

-- the ray's filter: the pads and the players (made once for every spot tried in one spawn)
local function groundParams()
	local params = RaycastParams.new()
	local ignore = { folder }
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	params.FilterDescendantsInstances = ignore
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true -- the invisible Battlefield cylinder and SafeZones are not ground
	return params
end

local function groundAt(x, z, params)
	params = params or groundParams()
	local hit = Workspace:Raycast(Vector3.new(x, 300, z), Vector3.new(0, -600, 0), params)
	if not hit then
		return nil
	end
	-- not on (or under) a tree, a rock or a flag: only on open ground
	local map = Workspace:FindFirstChild("Map")
	for _, name in ipairs(OFF_GROUND) do
		local f = map and map:FindFirstChild(name)
		if f and hit.Instance:IsDescendantOf(f) then
			return nil
		end
	end
	return hit.Position
end

-- one random open spot, evenly likely anywhere on the battlefield (between the key zone and its edge)
local function randomSpot(params)
	local c = Config.SpeedPads
	local inner = Config.Map.KeyZoneRadius + c.EdgeMargin
	local outer = Config.Battlefield.Radius - c.EdgeMargin
	for _ = 1, TRIES do
		local angle = rng:NextNumber(0, 2 * math.pi)
		local r = math.sqrt(rng:NextNumber(inner * inner / (outer * outer), 1)) * outer -- even over the area
		local ground = groundAt(math.cos(angle) * r, math.sin(angle) * r, params)
		if ground and not SafeZones.isSafe(ground + Vector3.new(0, 2, 0)) then
			return ground
		end
	end
	return nil
end

-- where the next pad goes: of Candidates random spots, the one farthest from every pad already out,
-- so the pads spread evenly over the field instead of bunching up (still random)
local function spot()
	local best, bestGap = nil, -1
	local params = groundParams()
	for _ = 1, Config.SpeedPads.Candidates do
		local p = randomSpot(params)
		if p then
			-- (squared, no new Vector3 each: with 850 pads out this runs about 25 times a second)
			local gap = math.huge
			for part in pairs(pads) do
				local at = part.Position
				local dx, dz = at.X - p.X, at.Z - p.Z
				gap = math.min(gap, dx * dx + dz * dz)
			end
			if gap > bestGap then
				best, bestGap = p, gap
			end
		end
	end
	return best
end

local function removePad(part)
	local info = pads[part]
	if info then
		pads[part] = nil
		count -= 1
		local cell = grid[info.cell]
		if cell then
			cell[part] = nil
			if next(cell) == nil then
				grid[info.cell] = nil
			end
		end
	end
	part:Destroy()
end

local function spawnPad(at)
	at = at or spot()
	if not at then
		return
	end
	local c = Config.SpeedPads
	local multiplier = math.floor(rng:NextNumber(c.MultiplierMin, c.MultiplierMax) * 10 + 0.5) / 10
	local part = Instance.new("Part")
	part.Name = "SpeedPad"
	part.Shape = Enum.PartType.Cylinder
	part.Size = Vector3.new(PAD_HEIGHT, c.Radius * 2, c.Radius * 2)
	part.CFrame = CFrame.new(at + Vector3.new(0, PAD_HEIGHT / 2, 0)) * CFrame.Angles(0, 0, math.rad(90))
	part.Anchored = true
	part.CanCollide = false
	part.CanQuery = false
	part.CanTouch = false -- (who stands on it is checked here, from positions)
	part.CastShadow = false
	part.Material = Enum.Material.Neon
	part.Color = PAD_COLOR
	part.Transparency = 0 -- (2026-10-04: was 0.15; 850 see-through parts cost phones more to draw than solid ones)
	part:SetAttribute("Multiplier", multiplier) -- (the label: StarterPlayerScripts/SpeedPadLabels)
	part.Parent = folder
	local key = cellKey(at.X, at.Z)
	grid[key] = grid[key] or {}
	grid[key][part] = true
	pads[part] = { multiplier = multiplier, born = os.clock(), cell = key }
	count += 1
end

-- who stands on a pad: checked on the server from the players' positions (not Touched, which the
-- client could fake from afar)
-- (2026-10-04, "술래잡기때 튀는 사람은 속도발판 이용 못하게") a hider can't use a pad while the seeker looks for them
-- (the pad stays for others); while hiding they still can
-- (2026-10-04, briefly the seeker neither; then "술래도 속도 발판을 쓸 수 있게 해야 밸런스 맞는 거 아님": the hiders run
-- faster than the seeker (Config.HideSeek.HiderSpeed), the pads are how the seeker catches up) the hiders only
-- (2026-10-04, "그리고 숨는 사람도 스피드패드 쓸 수 있게. 하지만 술래가 기본 이속이 더 빨라서 숨는사람이 조금 불리하지")
-- everyone in a game uses them again; the seeker walks a little faster instead (Config.HideSeek.SeekerSpeed)
local function canUse(player)
	return not player:GetAttribute("Flying") -- (2026-10-04: flying over the battlefield is only to look)
end

local function check()
	local c = Config.SpeedPads
	local now = os.clock()
	local old = {}
	for part, info in pairs(pads) do
		if now - info.born > c.Lifetime then
			table.insert(old, part)
		end
	end
	for _, part in ipairs(old) do
		removePad(part)
	end
	local reach = c.Radius * c.Radius
	for _, player in ipairs(Players:GetPlayers()) do
		local character = player.Character
		local root = character and character:FindFirstChild("HumanoidRootPart")
		local humanoid = character and character:FindFirstChildOfClass("Humanoid")
		if root and humanoid and humanoid.Health > 0 and canUse(player) then
			local at = root.Position
			local cx, cz = math.floor(at.X / CELL), math.floor(at.Z / CELL)
			local hit = nil
			for dx = -1, 1 do
				for dz = -1, 1 do
					for part in pairs(grid[(cx + dx) * 65536 + cz + dz] or {}) do
						local p = part.Position
						local x, z = p.X - at.X, p.Z - at.Z
						if not hit and x * x + z * z <= reach and math.abs(p.Y - at.Y) < REACH_Y then
							hit = part
						end
					end
				end
			end
			local info = hit and pads[hit]
			if info and MoveGuard.boost(player, info.multiplier,
				Formulas.speedPadSeconds((player:GetAttribute("CarriedKeys") or 0) > 0)) then
				removePad(hit)
				Rewards.add(player, "Pads", 1) -- daily missions
			end
		end
	end
end

-- Studio tests: a pad right here (at the ground below position)
function SpeedPads.spawnAt(position)
	spawnPad(groundAt(position.X, position.Z) or position)
end

function SpeedPads.init()
	folder = Workspace:FindFirstChild("SpeedPads") or Instance.new("Folder")
	folder.Name = "SpeedPads"
	folder:ClearAllChildren()
	folder.Parent = Workspace
	task.spawn(function()
		local since = Config.SpeedPads.SpawnInterval -- the first one at once
		while true do
			local dt = task.wait(0.1)
			since += dt
			-- (2026-10-04) as many pads as SpawnInterval says in this tick: one per tick at most made it one
			-- every 0.1 s whatever SpawnInterval said (about 320 out, never the MaxOnField)
			while since >= Config.SpeedPads.SpawnInterval do
				since -= Config.SpeedPads.SpawnInterval
				if count < Config.SpeedPads.MaxOnField then
					spawnPad()
				end
			end
			check()
		end
	end)
end

return SpeedPads
