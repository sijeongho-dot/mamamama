--[[
Wildlife: climbing onto the wild dinos of the safe land (design 9장 야생 공룡). The dinos themselves are
drawn by each screen (StarterPlayerScripts/Wildlife); a player who uses one's "🦖 올라타기" prompt sits on
its back on their own screen and sends Net request WildRide. The server checks they are in the safe land,
not on their own dino, not racing and past Config.Wildlife.RideCooldown, lets them move
(MoveGuard.loosen: a ride can't open a window to teleport in), and after RideSeconds throws them off (Net push Knockback: ThrowStuds away in a
random direction, ThrowFlight seconds in the air). Just for fun: nothing drops, nothing is lost.

(2026-10-02) Slapped, they hit back (the screens draw it; only the slapper's own screen asks): a little one
that caught its slapper sends Net request WildCounter (dx, dz), a giant's kick WildKick (dx, dz). The
server throws them that way (Knockback: CounterStuds / CounterFlight, or ThrowStuds / ThrowFlight like a
ride) when they are in the safe land, not riding, racing or knocked down, and slapped within CounterWindow
/ KickWindow seconds; once a slap at most (a throw only ever moves the one asking, nothing else).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local Combat = require(script.Parent:WaitForChild("Combat"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))

local Wildlife = {}

local THROW_GROGGY = 0.3 -- seconds on the ground after landing (display; no stun)
local DISMOUNT_SETTLE = 0.15 -- seconds after getting a rider off before the throw (their screen takes the mount away first)
local lastRide = {} -- [player] = os.clock()
local lastThrow = {} -- [player] = os.clock(): the last kick or slap back (once a slap)
local rides = {}

-- (giant: the rider climbed a giant, from their screen; only which buck sound every screen plays)
local function feed(player)
	local w = Config.Wildlife
	local r = rides[player]
	local profile = PlayerData.get(player)
	if not r or not profile or r.feeds >= w.FeedMax or (player:GetAttribute("CarriedKeys") or 0) > 0
		or (profile.Fruit or 0) < w.FeedFood then
		return
	end
	PlayerData.update(player, function(p)
		p.Fruit = (p.Fruit or 0) - w.FeedFood
	end)
	player:SetAttribute("Fruit", PlayerData.get(player).Fruit)
	r.feeds += 1
	r.untilTime += w.FeedSeconds
	local left = r.untilTime - os.clock()
	MoveGuard.loosen(player, left + w.ThrowFlight + 1.5)
	Net.push(player, "WildFed", left, w.FeedMax - r.feeds)
end

local function ride(player, giant)
	local w = Config.Wildlife
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not root or not humanoid or humanoid.Health <= 0 or not SafeZones.isSafe(root.Position)
		or player:GetAttribute("Racing") or MoveGuard.stunned(player) then
		return
	end
	if not Unlocks.usable(player, "Wild") then
		return
	end
	if lastRide[player] and os.clock() - lastRide[player] < w.RideCooldown then
		return
	end
	lastRide[player] = os.clock()
	Rewards.add(player, "WildRide", 1) -- daily missions, the weekly challenge
	MoveGuard.loosen(player, w.RideSeconds + w.ThrowFlight + 1.5) -- up on its back, then flying off
	local r = { untilTime = os.clock() + w.RideSeconds, feeds = 0 }
	rides[player] = r
	task.spawn(function()
		while rides[player] == r and os.clock() < r.untilTime do
			task.wait(math.max(0.05, r.untilTime - os.clock()))
		end
		if rides[player] ~= r then
			return
		end
		rides[player] = nil
		if player.Parent and player.Character == character then
			local a = math.random() * 2 * math.pi
			MoveGuard.loosen(player, w.ThrowFlight + 1.5)
			Net.push(player, "Knockback", math.cos(a), math.sin(a), w.ThrowStuds, w.ThrowFlight, THROW_GROGGY)
			-- (2026-10-03: the buck and the whoosh, on every screen; 2026-10-04, "야생 작은 공룡 탔을때 떨궈지는 소리가
			-- 거대공룡이랑 같으면 안 되지": a giant's heavy buck, a little one's light)
			Net.pushAll("FlyFx", player.UserId, w.ThrowFlight, giant and "BuckBig" or "Buck")
		end
	end)
end

-- a wild dino the player slapped throws them (see the top): dx, dz the way, from their screen
local function thrownBack(player, dx, dz, studs, flight, window)
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not root or not humanoid or humanoid.Health <= 0 or not SafeZones.isSafe(root.Position)
		or player:GetAttribute("Racing") or MoveGuard.stunned(player) or player:GetAttribute("InTutorial") then
		return
	end
	local now = os.clock()
	local slapped = Combat.slappedAt(player)
	if not slapped or now - slapped > window or (lastThrow[player] and lastThrow[player] >= slapped) then
		return
	end
	lastThrow[player] = now
	local way = Vector3.new(dx, 0, dz)
	if way.Magnitude < 0.01 then
		local a = math.random() * 2 * math.pi
		way = Vector3.new(math.cos(a), 0, math.sin(a))
	end
	way = way.Unit
	-- (2026-10-02, "공룡타기중에 야생공룡한테 시비걸고 튕겨나오지 않는 현상": a rider was never thrown) off the mount
	-- first, then thrown like anyone
	local riding = player:GetAttribute("Riding")
	if riding then
		require(script.Parent:WaitForChild("Ride")).getOff(player)
	end
	MoveGuard.loosen(player, flight + 1.5)
	task.delay(riding and DISMOUNT_SETTLE or 0, function()
		if player.Parent then
			Net.push(player, "Knockback", way.X, way.Z, studs, flight, THROW_GROGGY)
			Net.pushAll("FlyFx", player.UserId, flight)
		end
	end)
end

function Wildlife.init()
	local w = Config.Wildlife
	Net.onRequest("WildRide", { "boolean" }, ride)
	Net.onRequest("WildFeed", {}, feed)
	Net.onRequest("WildCounter", { "number", "number" }, function(player, dx, dz)
		thrownBack(player, dx, dz, w.CounterStuds, w.CounterFlight, w.CounterWindow)
	end)
	Net.onRequest("WildKick", { "number", "number" }, function(player, dx, dz)
		thrownBack(player, dx, dz, w.ThrowStuds, w.ThrowFlight, w.KickWindow)
	end)
	Players.PlayerRemoving:Connect(function(player)
		lastRide[player] = nil
		lastThrow[player] = nil
		rides[player] = nil
	end)
end

return Wildlife
