--[[
HomeTeleport: the "기지로" button. From anywhere, the player is moved to their own base's
SpawnLocation Config.HomeTeleport.Delay seconds after asking (player attribute TeleportAt =
the server time it happens, for the client's countdown).

- One at a time, and Config.HomeTeleport.Cooldown seconds between uses.
- Not while carrying keys (player attribute CarriedKeys, from the key stage): the keys have to be
  run home through the battlefield (design 2.5 열쇠 쟁탈).
- Not in a hide-and-seek game (player attribute HideSeekRoom, 2026-10-03).
- Mining stops, and MoveGuard is told first so the jump is not undone.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local Minerals = require(script.Parent:WaitForChild("Minerals"))

local HomeTeleport = {}

local ABOVE_SPAWN = 4 -- display: studs above the SpawnLocation the character lands

local pending = {} -- [player] = true while counting down
local lastUse = {} -- [player] = os.clock() of the last teleport

local function say(player, text)
	Net.push(player, "Notice", "🏠 기지로", text)
end

local function carryingKeys(player)
	return (player:GetAttribute("CarriedKeys") or 0) > 0
end

local function spawnOf(player)
	local folder = Bases.folderOf(player)
	local spawn = folder and folder:FindFirstChild("SpawnLocation", true)
	return spawn and spawn:IsA("BasePart") and spawn or nil
end

local function alive(player)
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	return character ~= nil and humanoid ~= nil and humanoid.Health > 0 and character:FindFirstChild("HumanoidRootPart") ~= nil
end

local function request(player)
	if pending[player] then
		return
	end
	local wait = Config.HomeTeleport.Cooldown - (os.clock() - (lastUse[player] or -math.huge))
	if wait > 0 then
		return say(player, string.format("⏱️ %d초 뒤에 다시 쓸 수 있어요", math.ceil(wait)))
	end
	if carryingKeys(player) then
		return say(player, "🔑 열쇠를 들고 있을 때는 기지로 순간이동할 수 없어요")
	end
	if player:GetAttribute("HideSeekRoom") then -- (2026-10-03) a hide-and-seek game keeps them on the battlefield
		return say(player, "🙈 숨바꼭질 중에는 기지로 갈 수 없어요")
	end
	if not spawnOf(player) or not alive(player) then
		return say(player, "🚫 지금은 기지로 갈 수 없어요")
	end
	pending[player] = true
	player:SetAttribute("TeleportAt", Workspace:GetServerTimeNow() + Config.HomeTeleport.Delay)
	task.delay(Config.HomeTeleport.Delay, function()
		pending[player] = nil
		if not player.Parent then
			return
		end
		player:SetAttribute("TeleportAt", nil)
		local spawn = spawnOf(player)
		if not spawn or not alive(player) then
			return
		end
		if carryingKeys(player) then
			return say(player, "🔑 열쇠를 들고 있어 순간이동이 취소됐어요")
		end
		if player:GetAttribute("HideSeekRoom") then
			return say(player, "🙈 숨바꼭질 중에는 기지로 갈 수 없어요")
		end
		lastUse[player] = os.clock()
		Minerals.stopMining(player)
		MoveGuard.allow(player)
		player.Character:PivotTo(spawn.CFrame * CFrame.new(0, ABOVE_SPAWN, 0))
		Rewards.add(player, "HomeTeleport", 1) -- (2026-10-03: the tutorial field's 🏠 기지로 step)
	end)
end

function HomeTeleport.init()
	Net.onRequest("TeleportHome", {}, request)
	Players.PlayerRemoving:Connect(function(player)
		pending[player] = nil
		lastUse[player] = nil
	end)
end

return HomeTeleport
