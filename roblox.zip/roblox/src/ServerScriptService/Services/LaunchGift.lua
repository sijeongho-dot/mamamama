--[[
LaunchGift (2026-10-04, "튜토 끝내면 신규 게임 런칭 웰컴 기념 한정 공룡 하나 선물해주자 … 얼리어댑터에게 주는 호칭같은
느낌", "튜토 안 끝내고 그냥 나와도 일단 1회는 한정공룡 주면서 창 띄우는거야 웰컴 런칭기념 공룡 드립니다 이런식으로 모델링
보여주면서", "한정 공룡 막 대단한거 받은 거처럼"): the launch gift, once a player.

- The first time a player's real save loads on a main server (tutorial done or not; never on a tutorial field, whose save
  is apart), while Config.LaunchGift.LastDay has not passed: a Config.LaunchGift dino goes into their dinos, marked 🎉
  (unit.Launch), of its own given-only rarity (⭐ 특별, Config.SpecialRarities), saved at once (profile.LaunchGiftAt).
  One given before that rarity is raised to it on load, and one of another size (it was Giant before 2026-10-04) gets the size.
- Its celebration window (Net push LaunchGift → StarterPlayerScripts/LaunchGift) shows once, where they first are to
  see it: on this main server when they stay here (no language to pick, not off to the tutorial field), or on the
  tutorial field when they are sent there (the Tutorial service passes LaunchGift in the teleport data and marks it
  shown; the field shows the window from that).
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))
local TutorialField = require(script.Parent:WaitForChild("TutorialField"))

local LaunchGift = {}

local G = Config.LaunchGift
local SHOW_AFTER = 3 -- seconds after the save loads before the window may show (the screen settles)
local LOOK_EVERY = 0.5

local function show(player)
	Net.push(player, "LaunchGift", G.Species, G.Rarity, G.Size)
end

-- give it (once); true when given now
local function give(player)
	local given = false
	PlayerData.update(player, function(p)
		-- (2026-10-04, "등급은 특별 등급으로 하나 새로 만들어") one given before the ⭐ 특별 grade: raised to it, and its old
		-- pair out of the collection (gifts aren't collected)
		for _, u in ipairs(p.Units) do
			if u.Launch and u.Rarity ~= G.Rarity then
				if p.Collection then
					p.Collection[Formulas.collectionKey(u)] = nil
				end
				u.Rarity = G.Rarity
			end
			if u.Launch and u.Size ~= G.Size then -- (2026-10-04: the gift's size changed, Giant → Big: the same for all)
				u.Size = G.Size
			end
		end
		if (p.LaunchGiftAt or 0) > 0 then
			return
		end
		if G.LastDay and RewardLogic.dayNumber(os.time()) > G.LastDay then
			return -- (the launch is over: later players don't get it)
		end
		if #p.Units >= Config.Gacha.MaxOwnedUnits then
			return -- (no room: asked again next time)
		end
		local unit = { Id = "U" .. p.NextUnitId, Species = G.Species, Rarity = G.Rarity, Size = G.Size, Launch = true }
		p.NextUnitId += 1
		table.insert(p.Units, unit)
		Formulas.recordCollection(p, unit)
		p.LaunchGiftAt = os.time()
		p.LaunchGiftShown = false
		given = true
	end)
	return given
end

-- the main server: the window once they stay here (not picking a language, not travelling to the tutorial field,
-- whose run shows it instead), else nothing
local function showHere(player)
	task.wait(SHOW_AFTER)
	while player.Parent do
		local profile = PlayerData.get(player)
		if not profile or profile.LaunchGiftShown or (profile.LaunchGiftAt or 0) == 0 then
			return
		end
		if player:GetAttribute("TutorialTravel") then
			return -- (off to the field: it shows there)
		end
		if not player:GetAttribute("LanguagePick") and profile.Tutorial and profile.Tutorial.Done
			and (profile.DefenseLevel or 1) >= G.ShowLevel and not profile.FreshStart and not profile.Stash then
			PlayerData.update(player, function(p)
				p.LaunchGiftShown = true
			end)
			show(player)
			return
		end
		task.wait(LOOK_EVERY)
	end
end

-- the Tutorial service, sending a player to the field: whether the field is to show the window (and it is then marked
-- shown in the real save)
function LaunchGift.takeForField(player)
	local profile = PlayerData.get(player)
	if not profile or profile.LaunchGiftShown or (profile.LaunchGiftAt or 0) == 0 then
		return false
	end
	PlayerData.update(player, function(p)
		p.LaunchGiftShown = true
	end)
	return true
end

function LaunchGift.init()
	if TutorialField.isField() then
		-- the field: the window when the main server said so (its dino is in the real save already)
		PlayerData.onLoaded(function(player)
			if TutorialField.joinData(player).LaunchGift then
				task.delay(SHOW_AFTER, function()
					if player.Parent then
						show(player)
					end
				end)
			end
		end)
		return
	end
	PlayerData.onLoaded(function(player)
		give(player)
		task.spawn(showHere, player)
	end)
end

return LaunchGift
