--[[
Bombs: the bomb stall beside every base's shop and the bombs thrown on the battlefield (2026-10-01,
Config.Bombs).

- The stall: a copy of the shop stall (Bases.copyStall, BombStall) on the shop's other side from the key
  stall, "💣 폭탄 상점" over it, prompt Kind "BombShop" (the client's window, StarterPlayerScripts/Bombs),
  and a heap of big round bombs with lit fuses beside it (BombDecor) so it reads as the bomb shop.
- Net request BuyBombs(kind, count): at the player's own stall (Config.Bombs.StallRange), up to MaxHeld of
  each kind, Formulas.bombPrice(level, kind) each (PlayerData.spendMoney). Held in profile Bombs; player
  attributes BombsEgg / BombsPoop for the buttons.
- Net request ThrowBomb(kind, aim): a bomb held, alive, Cooldown seconds since the last throw (player
  attribute BombReadyAt, server time). It lands on the ground toward aim, at most ThrowRange away, after
  FlightSeconds (Net push BombFx(userId, kind, from, to, seconds) for everyone to see it fly), then goes off
  (Net push BombBlast(kind, at, hit, spots)). Only a blast on the battlefield does anything:
    Egg: Combat.blast: a slap from the bomb itself, all round, with the thrower's slap reach and level
         (players in reach drop their keys and are thrown, zombies are thrown, bosses take slap damage).
    Poop: everyone else in the thrower's slap reach is stuck like under a pterosaur's dropping
         (MoveGuard.stun Config.Poop.StunSeconds, "Poop"); zombies and bosses in reach can't move for
         RootSeconds but still hit (Zombies.root).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local Combat = require(script.Parent:WaitForChild("Combat"))
local Zombies = require(script.Parent:WaitForChild("Zombies"))

local Bombs = {}

-- display only
local STALL_SIDE = 18 -- studs from the shop's middle, on the side away from the key stall
local STALL_COLOR = Color3.fromRGB(70, 70, 80)
local TITLE_COLOR = Color3.fromRGB(255, 140, 70)
-- (2026-10-04, "공중에 폭탄알이 하나 떠있다고") studs over the stall's top for its name: over what it sells, standing on
-- its roof (StarterPlayerScripts/StallShowcase, 3.2 studs tall)
local TITLE_OVER_SHOWCASE = 4.6
local DECOR_SIDE = 10.5 -- studs past the bomb stall's middle for the heap of bombs
local DECOR_BOMBS = { -- { studs across, studs out front, size } of each bomb in the heap
	{ 0, 0, 4.2 }, { 3.4, 1.2, 3 }, { -2.8, 1.6, 2.6 }, { 0.8, 3.2, 2.2 },
}
local DECOR_COLOR = Color3.fromRGB(35, 35, 42)
local DECOR_BAND = Color3.fromRGB(230, 60, 50)
local DECOR_FUSE = Color3.fromRGB(150, 110, 70)
local DECOR_SPARK = Color3.fromRGB(255, 190, 60)
local GROUND_LOOK = 200 -- studs down to look for the ground under a landing spot

local lastThrow = {} -- [player] = os.clock()

local function say(player, text)
	Net.push(player, "Notice", "💣 폭탄", text)
end

local function mirror(player, profile)
	for _, k in ipairs(Config.Bombs.Kinds) do
		player:SetAttribute("Bombs" .. k.Id, profile.Bombs and profile.Bombs[k.Id] or 0)
	end
end

local function part(props, parent)
	local p = Instance.new("Part")
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch = true, false, false, false
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	for k, v in pairs(props) do
		p[k] = v
	end
	p.Parent = parent
	return p
end

-- big round bombs with lit fuses beside the stall: this is the bomb shop
local function makeDecor(folder, at, look)
	local model = Instance.new("Model")
	model.Name = "BombDecor"
	local ground = Bases.groundBelow(at, {})
	local frame = CFrame.lookAt(Vector3.new(at.X, ground, at.Z), Vector3.new(at.X, ground, at.Z) + look)
	for _, b in ipairs(DECOR_BOMBS) do
		local size = b[3]
		local center = frame * CFrame.new(b[1], size / 2, -b[2])
		part({ Name = "Bomb", Shape = Enum.PartType.Ball, Size = Vector3.one * size, CFrame = center, Color = DECOR_COLOR,
			Material = Enum.Material.SmoothPlastic, CanCollide = true }, model)
		part({ Name = "Band", Shape = Enum.PartType.Cylinder, Size = Vector3.new(size * 0.18, size * 1.02, size * 1.02),
			CFrame = center * CFrame.Angles(0, 0, math.rad(90)), Color = DECOR_BAND, Material = Enum.Material.SmoothPlastic }, model)
		local fuse = part({ Name = "Fuse", Size = Vector3.new(size * 0.12, size * 0.35, size * 0.12),
			CFrame = center * CFrame.new(0, size * 0.55, 0) * CFrame.Angles(0, 0, math.rad(15)), Color = DECOR_FUSE }, model)
		local spark = part({ Name = "Spark", Shape = Enum.PartType.Ball, Size = Vector3.one * size * 0.14, Transparency = 0.2,
			CFrame = fuse.CFrame * CFrame.new(0, size * 0.2, 0), Color = DECOR_SPARK, Material = Enum.Material.Neon }, model)
		local sparkles = Instance.new("ParticleEmitter")
		sparkles.Color = ColorSequence.new(DECOR_SPARK, Color3.fromRGB(255, 255, 200))
		sparkles.LightEmission = 1
		sparkles.Size = NumberSequence.new(size * 0.08, 0)
		sparkles.Speed = NumberRange.new(2, 5)
		sparkles.Lifetime = NumberRange.new(0.2, 0.45)
		sparkles.SpreadAngle = Vector2.new(60, 60)
		sparkles.Rate = 20
		sparkles.Parent = spark
	end
	model.Parent = folder
	return model
end

-- the bomb stall on the shop's other side from the key stall, and the heap of bombs past it
local function makeStall(index, folder)
	local shop = folder:FindFirstChild("Base_Shop")
	local zone = folder:FindFirstChild("SafeZone")
	if not shop or not zone then
		return nil
	end
	local at = shop:GetPivot().Position
	local out = Vector3.new(zone.Position.X, 0, zone.Position.Z)
	out = out.Magnitude > 1e-3 and out.Unit or Vector3.zAxis
	local toMiddle = Vector3.new(zone.Position.X - at.X, 0, zone.Position.Z - at.Z)
	local side = toMiddle - out * toMiddle:Dot(out)
	side = side.Magnitude > 1e-3 and side.Unit or out:Cross(Vector3.yAxis).Unit
	local spot = at - side * STALL_SIDE -- (the key stall is toward the middle line: this one away from it)
	local stall = Bases.copyStall(folder, "BombStall", spot, -out, STALL_COLOR, "💣 폭탄 상점")
	Bases.title(stall, "💣 폭탄 상점", TITLE_COLOR, false, TITLE_OVER_SHOWCASE)
	Bases.prompt(stall, "BombShop", index, "폭탄 사기", Config.Bombs.StallRange)
	makeDecor(folder, spot - side * DECOR_SIDE, -out)
	return stall
end

local stalls = {} -- [base number] = the bomb stall

local function buy(player, kind, count)
	if not Unlocks.check(player, "Bombs") then
		return
	end
	local profile = PlayerData.get(player)
	local k = Formulas.bombKind(kind)
	local stall = stalls[Bases.of(player)]
	if not profile or not k or not stall then
		return
	end
	if not Bases.near(player, stall, Config.Bombs.StallRange) then
		return say(player, "💣 내 기지 폭탄 상점에서 사요")
	end
	local held = profile.Bombs[kind] or 0
	count = math.clamp(math.floor(tonumber(count) or 0), 0, Config.Bombs.MaxHeld - held)
	if count <= 0 then
		return say(player, string.format("%s %s: %d개까지만 들 수 있어요", k.Icon, k.Name, Config.Bombs.MaxHeld))
	end
	local price = Formulas.bombPrice(profile.DefenseLevel, kind) * count
	if not PlayerData.spendMoney(player, price, "bomb") then
		return say(player, "돈이 모자라요")
	end
	PlayerData.update(player, function(p)
		p.Bombs[kind] = (p.Bombs[kind] or 0) + count
	end)
	Rewards.add(player, "BombBuy", count) -- (2026-10-03: the beginner mission "💣 폭탄 사기")
	say(player, string.format("%s %s %d개 샀어요! (지금 %d개)", k.Icon, k.Name, count, held + count))
end

local function groundAt(position, ignore)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true
	params.FilterDescendantsInstances = ignore
	local hit = Workspace:Raycast(position + Vector3.new(0, GROUND_LOOK / 2, 0), Vector3.new(0, -GROUND_LOOK, 0), params)
	return hit and hit.Position or position
end

-- a poop bomb going off: everyone else in reach on the battlefield is stuck, zombies and bosses held
local function poopBlast(player, at, reach)
	local ids = {}
	local spots, boss = Zombies.root(at, reach, Config.Bombs.RootSeconds)
	local mine, myBoss = require(script.Parent:WaitForChild("Practice")).poop(player, at, reach, Config.Bombs.RootSeconds)
	for _, spot in ipairs(mine) do
		table.insert(spots, spot)
	end
	if boss or myBoss then
		Rewards.add(player, "BossBomb", 1)
	end
	if player:GetAttribute("TutorialShield") then
		return ids, spots
	end
	local seconds = Config.Poop.StunSeconds
	for _, other in ipairs(Players:GetPlayers()) do
		local root = other ~= player and other.Character and other.Character:FindFirstChild("HumanoidRootPart")
		local humanoid = root and other.Character:FindFirstChildOfClass("Humanoid")
		if humanoid and humanoid.Health > 0 and Combat.inBattlefield(root.Position) and not Combat.invulnerable(other)
			and not Combat.protected(other, root.Position) and not SafeZones.inSky(other, root.Position) then
			local d = root.Position - at
			if Vector3.new(d.X, 0, d.Z).Magnitude <= reach and math.abs(d.Y) <= reach then
				table.insert(ids, other.UserId)
				MoveGuard.stun(other, seconds, "Poop")
				Net.push(other, "Banner", string.format("💩 %s님의 똥 폭탄! %d초 동안 못 움직여요", player.DisplayName, seconds),
					"Poop")
			end
		end
	end
	return ids, spots
end

local function throw(player, kind, aim)
	local profile = PlayerData.get(player)
	local k = Formulas.bombKind(kind)
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not profile or not k or not root or not humanoid or humanoid.Health <= 0 then
		return
	end
	if not Unlocks.check(player, "Bombs") then
		return
	end
	if (profile.Bombs[kind] or 0) <= 0 then
		return say(player, "폭탄이 없어요. 기지 💣 폭탄 상점에서 사요")
	end
	if player:GetAttribute("HideSeekRoom") then -- (2026-10-03) not in a hide-and-seek game
		return say(player, "숨바꼭질 중에는 폭탄을 못 써요")
	end
	if SafeZones.inSky(player, root.Position) then -- (2026-10-04) flying over the battlefield: only looking
		return say(player, "🦅 하늘 구경 중엔 폭탄을 못 써요")
	end
	local now = os.clock()
	if now - (lastThrow[player] or -math.huge) < Config.Bombs.Cooldown or MoveGuard.stunned(player) then
		return
	end
	if aim.X ~= aim.X or aim.Z ~= aim.Z or math.abs(aim.X) > 1e6 or math.abs(aim.Z) > 1e6 then -- NaN, nonsense
		return
	end
	-- toward aim, at most ThrowRange away, on the ground there
	local from = root.Position
	local flat = Vector3.new(aim.X - from.X, 0, aim.Z - from.Z)
	if flat.Magnitude < 0.1 then
		flat = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z)
	end
	local distance = math.min(flat.Magnitude, Config.Bombs.ThrowRange)
	local ignore = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	local to = groundAt(from + flat.Unit * distance, ignore)
	if Unlocks.closedAt(player, to) then
		return say(player, "🌑 아직 안 열린 곳으로는 못 던져요")
	end
	lastThrow[player] = now
	PlayerData.update(player, function(p)
		p.Bombs[kind] -= 1
	end)
	player:SetAttribute("BombReadyAt", Workspace:GetServerTimeNow() + Config.Bombs.Cooldown)
	local seconds = Config.Bombs.FlightSeconds
	Net.pushAll("BombFx", player.UserId, kind, from, to, seconds)
	task.delay(seconds, function()
		local inField = not SafeZones.isSafe(to)
		local ids, spots = {}, {}
		local fossils = player.Parent and require(script.Parent:WaitForChild("Defense")).bombFossils(player, kind, to,
			Formulas.slapReach(Combat.slapLevel(player)), Combat.slapLevel(player)) or {}
		for _, spot in ipairs(fossils) do
			table.insert(spots, spot)
		end
		if #fossils > 0 then
			inField = true
		elseif inField and player.Parent then
			local level = Combat.slapLevel(player)
			local reach = Formulas.slapReach(level)
			if kind == "Egg" then
				ids, spots = Combat.blast(player, to, reach, level, Formulas.bombKind("Egg").BossDamageMultiplier)
			else
				ids, spots = poopBlast(player, to, reach)
			end
			local practice = require(script.Parent:WaitForChild("Practice")).kindOf(player)
			if #spots > 0 or #ids > 0 then
				Rewards.add(player, "Bomb" .. kind, 1)
			elseif practice == "Boss" then
				say(player, "🎯 아깝다! 👑 연습 보스 가까이에 던져요")
			elseif practice == "Zombies" then
				say(player, "🎯 아깝다! 🧟 연습 좀비 가까이에 던져요")
			end
		end
		Net.pushAll("BombBlast", kind, to, ids, spots, inField, Formulas.slapReach(Combat.slapLevel(player)), player.UserId)
	end)
end

function Bombs.init()
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			for _, name in ipairs({ "BombStall", "BombDecor" }) do
				local old = folder:FindFirstChild(name)
				if old then
					old:Destroy()
				end
			end
			stalls[index] = makeStall(index, folder)
		end
	end
	Net.onRequest("BuyBombs", { "string", "number" }, buy)
	Net.onRequest("ThrowBomb", { "string", "Vector3" }, throw)
	PlayerData.onLoaded(mirror)
	PlayerData.onChanged(mirror)
	Players.PlayerRemoving:Connect(function(player)
		lastThrow[player] = nil
	end)
end

-- Studio tests: give bombs of a kind (TestCommands)
function Bombs.give(player, kind, count)
	if not Formulas.bombKind(kind) then
		return false
	end
	PlayerData.update(player, function(p)
		p.Bombs[kind] = math.max(0, (p.Bombs[kind] or 0) + count)
	end)
	-- (2026-10-03, "튜토에서 코코가 폭탄 안 주는데": saved but never shown, so no bomb buttons came)
	mirror(player, PlayerData.get(player))
	return true
end

return Bombs
