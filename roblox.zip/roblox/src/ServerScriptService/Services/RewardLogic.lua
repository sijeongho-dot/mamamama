--[[
RewardLogic: the rules of the extra rewards, without Roblox (tested by tools/tests/reward_logic_test.lua;
the Rewards service runs them). Config.Rewards holds the numbers.

- A reward is a table: { Keys = n, KeyHours = h, SpecialKeys = { Silver = n, ... }, MoneyChests = n } (money = n
  treasure chests' worth at the player's defense level; KeyHours: that many hours of Products.KeysPerHour keys). RewardLogic.apply puts the keys in the
  profile and returns the money (the service pays it through PlayerData.addMoney) and a text.
- Playtime gifts: gift i may be taken once a day, after its Minutes of play today (all sessions of
  the day add up; Daily.Played, Daily.Gifts).
- Offline: time away pays a share of what the arena earns idle, capped (only with dinos placed).
- Daily missions: Count missions a day, picked from the pool by the day and the player (the same all
  day); progress by kind; each finished one gives Daily.Reward, all of them Daily.AllReward.
- Weekly key challenge: carried keys brought home this week; each milestone gives its reward once.
- Weekly challenges (Weekly.Challenges): each counts its kind all week (Weekly.Progress[kind]) and pays
  at each of its steps once, in order (Weekly.Steps[kind] = steps taken).
- Attendance (2026-10-02, design 2.9; Config.Attendance): checkIn on a new day moves the 7-day streak on (or
  back to day 1 after a missed day) and counts the day this month; today's streak reward and each monthly
  milestone reached are taken once (claimStreak, claimMonthly). The service gives them (attendance kinds).
- Days and weeks turn at Config.Rewards.ResetOffsetHours from UTC midnight (08:00 UTC: US/UK kids' night or early
  morning); weeks on Monday.
]]

local Config = if game then require(game:GetService("ReplicatedStorage"):WaitForChild("Config")) else CONFIG
local Formulas = if game
	then require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Formulas"))
	else LOAD("ReplicatedStorage/Shared/Formulas")

local RewardLogic = {}

local DAY = 86400
local MONDAY_OFFSET = 3 * DAY -- the Unix epoch was a Thursday

function RewardLogic.dayNumber(now)
	return math.floor((now + Config.Rewards.ResetOffsetHours * 3600) / DAY)
end

function RewardLogic.weekNumber(now)
	return math.floor((now + Config.Rewards.ResetOffsetHours * 3600 + MONDAY_OFFSET) / (7 * DAY))
end

-- os.time() when week number `week` starts (the inverse of weekNumber)
function RewardLogic.weekStart(week)
	return week * 7 * DAY - MONDAY_OFFSET - Config.Rewards.ResetOffsetHours * 3600
end

-- ---------------------------------------------------------------------------
-- Giving a reward
-- ---------------------------------------------------------------------------

function RewardLogic.money(reward, level)
	local keyMoney = (reward.KeyMoney or 0) > 0 and reward.KeyMoney * Formulas.keyShopPrice(level or 1, "Normal") or 0
	return math.floor((reward.MoneyChests or 0) * Formulas.treasureMoney(level, 0.5) + keyMoney + 0.5)
end

-- the reward in words, e.g. "열쇠 2개 · 은 열쇠 1개 · 3,000원"; with icons each part starts with its
-- emoji ("🔑 열쇠 2개 · 🔑 은 열쇠 1개 · 💰 3,000원": the 🎁 window; the notices go without)
-- the plain keys a reward gives at this level: Keys, and KeyHours of Products.KeysPerHour (2026-10-02, the season pass)
function RewardLogic.keys(reward, level)
	local n = reward.Keys or 0
	if (reward.KeyHours or 0) > 0 then
		n += Formulas.keyPackKeys(level, reward.KeyHours)
	end
	return n
end

function RewardLogic.text(reward, level, icons)
	local key, coin = icons and "🔑 " or "", icons and "💰 " or ""
	local parts = {}
	local keys = RewardLogic.keys(reward, level)
	if keys > 0 then
		table.insert(parts, key .. "열쇠 " .. keys .. "개")
	end
	for _, t in ipairs(Config.Keys.Types) do
		local n = reward.SpecialKeys and reward.SpecialKeys[t.Id] or 0
		if n > 0 then
			table.insert(parts, key .. t.Name .. " " .. n .. "개")
		end
	end
	local money = RewardLogic.money(reward, level)
	if money > 0 then
		table.insert(parts, coin .. Formulas.shortNumber(money) .. "원")
	end
	return table.concat(parts, " · ")
end

-- the reward's picture: its best key grade ("Normal", "Silver", ...), or "Money" when it is only money
function RewardLogic.icon(reward)
	local best = nil
	for _, t in ipairs(Config.Keys.Types) do
		if reward.SpecialKeys and (reward.SpecialKeys[t.Id] or 0) > 0 then
			best = t.Id
		end
	end
	return best or (((reward.Keys or 0) > 0 or (reward.KeyHours or 0) > 0) and "Normal") or "Money"
end

-- the keys go into the profile; returns the money to pay
function RewardLogic.apply(profile, reward)
	local keys = RewardLogic.keys(reward, profile.DefenseLevel)
	if keys > 0 then
		Formulas.addSavedKeys(profile, "Normal", keys)
	end
	for id, n in pairs(reward.SpecialKeys or {}) do
		Formulas.addSavedKeys(profile, id, n)
	end
	return RewardLogic.money(reward, profile.DefenseLevel)
end

-- ---------------------------------------------------------------------------
-- Playtime gifts (today)
-- ---------------------------------------------------------------------------

-- may gift i be taken now (today's play time, not taken today)?
function RewardLogic.playtimeReady(profile, i)
	local gift = Config.Rewards.Playtime[i]
	local d = profile.Daily
	return gift ~= nil and not d.Gifts[tostring(i)] and d.Played >= gift.Minutes * 60
end

-- take gift i: its reward or nil
function RewardLogic.claimPlaytime(profile, i)
	if not RewardLogic.playtimeReady(profile, i) then
		return nil
	end
	profile.Daily.Gifts[tostring(i)] = true -- string keys: a saved table stays a dictionary
	return Config.Rewards.Playtime[i].Reward
end

function RewardLogic.mergeRewards(a, b)
	local out = table.clone(a or {})
	for k, v in pairs(b or {}) do
		if type(v) == "number" and type(out[k]) == "number" then
			out[k] += v
		elseif type(v) == "table" and type(out[k]) == "table" then
			out[k] = RewardLogic.mergeRewards(out[k], v)
		elseif out[k] == nil then
			out[k] = type(v) == "table" and table.clone(v) or v
		end
	end
	return out
end

function RewardLogic.claimPlaytimeAll(profile)
	local total, n = nil, 0
	for i = 1, #Config.Rewards.Playtime do
		local reward = RewardLogic.claimPlaytime(profile, i)
		if reward then
			total, n = RewardLogic.mergeRewards(total, reward), n + 1
		end
	end
	return total, n
end

-- seconds of play today
function RewardLogic.addPlayed(profile, seconds)
	profile.Daily.Played += seconds
	profile.PlaySeconds = (profile.PlaySeconds or 0) + seconds -- (2026-10-04) and in all: the 🐣 rookie buff, the funnel
end

-- ---------------------------------------------------------------------------
-- Offline earnings
-- ---------------------------------------------------------------------------

-- money for `away` seconds away for an arena that made `rate` money a second idle (profile.Stats.IdleMoneyRate,
-- measured by Defense); 0 when too short, no dino was placed or nothing was measured yet
function RewardLogic.offlineMoney(away, rate, hasPlaced)
	local o = Config.Rewards.Offline
	if not hasPlaced or away < o.MinMinutes * 60 or not rate or rate <= 0 then
		return 0, 0
	end
	local seconds = math.min(away, o.MaxHours * 3600)
	local idle = rate
	-- each tier's stretch of the time away at its share (the first hours pay best)
	local paid, from = 0, 0
	for _, tier in ipairs(o.Tiers) do
		local to = math.min(seconds, tier.Hours * 3600)
		if to > from then
			paid += (to - from) * tier.Share
		end
		from = math.max(from, tier.Hours * 3600)
	end
	return math.floor(paid * idle + 0.5), seconds
end

-- the most offline money that can wait at this idle rate: one full MaxHours away
function RewardLogic.offlineMax(rate)
	return (RewardLogic.offlineMoney(Config.Rewards.Offline.MaxHours * 3600, rate, true))
end

function RewardLogic.comebackTier(days)
	local best = nil
	for _, tier in ipairs(Config.Comeback.Tiers) do
		if (days or 0) >= tier.Days then
			best = tier
		end
	end
	return best
end

function RewardLogic.comeback(profile, away)
	local days = math.floor(math.max(away or 0, 0) / DAY)
	if not RewardLogic.comebackTier(days) then
		return nil
	end
	profile.Comeback.Days = math.max(profile.Comeback.Days or 0, days)
	return profile.Comeback.Days
end

function RewardLogic.claimComeback(profile, now)
	local c = profile.Comeback
	local tier = RewardLogic.comebackTier(c.Days)
	if not tier then
		return nil
	end
	local days = c.Days
	c.Days, c.Last, c.Count = 0, now, (c.Count or 0) + 1
	return tier.Reward, days
end

-- ---------------------------------------------------------------------------
-- Daily missions
-- ---------------------------------------------------------------------------

-- today's missions: the same set all day for this player (a shuffle seeded by the day and the player); (2026-10-04) a
-- mission whose MinTier the pickaxe tier hasn't reached is left out (tier nil: none left out)
local function pick(day, seed, tier, open)
	local pool = Config.Rewards.Daily.Pool
	local order = {}
	for i = 1, #pool do
		order[i] = i
	end
	local s = (day * 7919 + seed * 104729) % 2147483647
	for i = #order, 2, -1 do
		s = (s * 48271) % 2147483647
		local j = s % i + 1
		order[i], order[j] = order[j], order[i]
	end
	if tier or open then
		local kept = {}
		for _, i in ipairs(order) do
			if (not tier or (pool[i].MinTier or 0) <= tier) and (not open or not pool[i].Unlock or open(pool[i].Unlock)) then
				table.insert(kept, i)
			end
		end
		order = kept
	end
	local count = math.min(Config.Rewards.Daily.Count, #order)
	local hasMining = false
	for i = 1, count do
		hasMining = hasMining or pool[order[i]].Mining == true
	end
	if not hasMining then -- always one mining mission: the first one after today's set takes the last place
		for i = count + 1, #order do
			if pool[order[i]].Mining then
				order[count], order[i] = order[i], order[count]
				break
			end
		end
	end
	local list = {}
	for i = 1, count do
		local m = pool[order[i]]
		table.insert(list, { Kind = m.Kind, Target = m.Target, Progress = 0, Claimed = false })
	end
	return list
end

-- make sure the profile holds today's missions (a new day starts fresh); true when it changed
function RewardLogic.ensureDay(profile, day, seed)
	local d = profile.Daily
	if d.Day ~= day then
		local function open(id)
			return Formulas.unlockOpen(profile.Unlocks, id)
		end
		profile.Daily = { Day = day, Missions = pick(day, seed, profile.Upgrades and profile.Upgrades.PickaxeTier, open),
			AllClaimed = false, Played = 0, Gifts = {} }
		return true
	end
	return false
end

function RewardLogic.ensureWeek(profile, week)
	if profile.Weekly.Week ~= week then
		profile.Weekly = { Week = week, Keys = 0, Claimed = {}, Progress = {}, Steps = {} }
		return true
	end
	return false
end

-- progress of a kind (e.g. "Mine", 3); returns the indexes of missions finished by it
function RewardLogic.progress(profile, kind, amount)
	local done = {}
	for i, m in ipairs(profile.Daily.Missions) do
		if m.Kind == kind and m.Progress < m.Target then
			m.Progress = math.min(m.Target, m.Progress + amount)
			if m.Progress >= m.Target then
				table.insert(done, i)
			end
		end
	end
	return done
end

-- take mission i's reward: the reward or nil
function RewardLogic.claimDaily(profile, i)
	local m = profile.Daily.Missions[i]
	if not m or m.Claimed or m.Progress < m.Target then
		return nil
	end
	m.Claimed = true
	return Config.Rewards.Daily.Reward
end

-- the reward for finishing every mission today, once: the reward or nil
function RewardLogic.claimDailyAll(profile)
	if profile.Daily.AllClaimed or #profile.Daily.Missions == 0 then
		return nil
	end
	for _, m in ipairs(profile.Daily.Missions) do
		if not m.Claimed then
			return nil
		end
	end
	profile.Daily.AllClaimed = true
	return Config.Rewards.Daily.AllReward
end

-- ---------------------------------------------------------------------------
-- Weekly key challenge
-- ---------------------------------------------------------------------------

-- carried keys brought home; returns the milestone indexes just reached
function RewardLogic.addWeeklyKeys(profile, n)
	local before = profile.Weekly.Keys
	profile.Weekly.Keys = before + n
	local reached = {}
	for i, m in ipairs(Config.Rewards.Weekly.Milestones) do
		if before < m.Keys and profile.Weekly.Keys >= m.Keys then
			table.insert(reached, i)
		end
	end
	return reached
end

function RewardLogic.claimWeekly(profile, i)
	local m = Config.Rewards.Weekly.Milestones[i]
	local claimed = profile.Weekly.Claimed
	if not m or claimed[tostring(i)] or profile.Weekly.Keys < m.Keys then
		return nil
	end
	claimed[tostring(i)] = true -- string keys: a saved table stays a dictionary
	return m.Reward
end

-- ---------------------------------------------------------------------------
-- Weekly challenges (besides the keys)
-- ---------------------------------------------------------------------------

local function challenge(kind)
	for _, c in ipairs(Config.Rewards.Weekly.Challenges) do
		if c.Kind == kind then
			return c
		end
	end
	return nil
end

-- the week's progress of a kind (any kind counts, those without a challenge are just not shown); returns
-- true when a challenge's next step became ready by it
function RewardLogic.progressWeekly(profile, kind, amount)
	local w = profile.Weekly
	w.Progress = w.Progress or {}
	w.Steps = w.Steps or {}
	local c = challenge(kind)
	if not c then
		return false
	end
	local before = w.Progress[kind] or 0
	w.Progress[kind] = before + amount
	local step = c.Steps[(w.Steps[kind] or 0) + 1]
	return step ~= nil and before < step.Target and w.Progress[kind] >= step.Target
end

-- a challenge's state: its next step (nil when all are taken), its index, and whether it is ready
function RewardLogic.weeklyStep(profile, kind)
	local c = challenge(kind)
	local w = profile.Weekly
	local taken = (w.Steps or {})[kind] or 0
	local step = c and c.Steps[taken + 1]
	return step, taken + 1, step ~= nil and ((w.Progress or {})[kind] or 0) >= step.Target
end

-- take a challenge's next step: its reward or nil
function RewardLogic.claimWeeklyChallenge(profile, kind)
	local step, _, ready = RewardLogic.weeklyStep(profile, kind)
	if not ready then
		return nil
	end
	profile.Weekly.Steps = profile.Weekly.Steps or {}
	profile.Weekly.Steps[kind] = (profile.Weekly.Steps[kind] or 0) + 1
	return step.Reward
end

-- how many rewards are waiting to be taken (for the button's badge)
-- ---------------------------------------------------------------------------
-- Attendance
-- ---------------------------------------------------------------------------

-- the month a day is in: year × 100 + month
function RewardLogic.monthOf(day)
	local t = os.date("!*t", day * DAY)
	return t.year * 100 + t.month
end

-- today's check-in: the streak on a day (back to 1 after a missed day, round again after the last), one
-- more day this month (a new month starts over); true when it was a new day
function RewardLogic.checkIn(profile, day)
	local a = profile.Attendance
	if a.Day == day then
		return false, {}
	end
	local missed = {}
	if not a.StreakClaimed and a.Streak >= 1 and Config.Attendance.Streak[a.Streak] then
		table.insert(missed, { Reward = Config.Attendance.Streak[a.Streak], Month = a.Month })
		a.StreakClaimed = true
	end
	local month = RewardLogic.monthOf(day)
	if a.Month ~= month then
		for i, m in ipairs(Config.Attendance.Monthly) do
			if a.MonthDays >= m.Days and not a.MonthClaimed[tostring(i)] then
				a.MonthClaimed[tostring(i)] = true
				table.insert(missed, { Reward = m, Month = a.Month })
			end
		end
		a.Month, a.MonthDays, a.MonthClaimed, a.MonthLog = month, 0, {}, {}
	end
	-- (a missed day or GraceDays keeps the streak going: the next day comes next)
	local gap = day - a.Day
	a.Streak = (a.Streak > 0 and gap >= 1 and gap <= 1 + (Config.Attendance.GraceDays or 0))
		and (a.Streak % #Config.Attendance.Streak + 1) or 1
	a.MonthDays += 1
	a.MonthLog = a.MonthLog or {}
	a.MonthLog[tostring(os.date("!*t", day * DAY).day)] = true -- (the calendar's stamp)
	a.Day, a.StreakClaimed = day, false
	return true, missed
end

-- (2026-10-02) the calendar of the month a day is in: its year and month, the day's date, how many days
-- it has and the weekday of its 1st (0 = Sunday)
function RewardLogic.calendar(day)
	local t = os.date("!*t", day * DAY)
	local first = day - (t.day - 1)
	local length = 28
	while os.date("!*t", (first + length) * DAY).month == t.month do
		length += 1
	end
	return { Year = t.year, Month = t.month, Today = t.day, Length = length,
		FirstWeekday = (os.date("!*t", first * DAY).wday - 1) }
end

-- today's streak reward, once: the reward or nil
function RewardLogic.claimStreak(profile)
	local a = profile.Attendance
	if a.StreakClaimed or a.Streak < 1 then
		return nil
	end
	a.StreakClaimed = true
	return Config.Attendance.Streak[a.Streak]
end

-- monthly milestone i, once it is reached: the reward or nil
function RewardLogic.claimMonthly(profile, i)
	local a = profile.Attendance
	local m = Config.Attendance.Monthly[i]
	if not m or a.MonthDays < m.Days or a.MonthClaimed[tostring(i)] then
		return nil
	end
	a.MonthClaimed[tostring(i)] = true
	return m
end

-- how many attendance rewards wait
function RewardLogic.attendanceReady(profile)
	local a = profile.Attendance
	local n = (not a.StreakClaimed and a.Streak >= 1) and 1 or 0
	for i, m in ipairs(Config.Attendance.Monthly) do
		if a.MonthDays >= m.Days and not a.MonthClaimed[tostring(i)] then
			n += 1
		end
	end
	return n
end

-- an attendance reward in words (money at this key price; the month dino's name)
function RewardLogic.attendanceText(reward, keyPrice, monthDinoName)
	local c = Config.Attendance
	local parts = {}
	if reward.GuaranteedRarity then
		table.insert(parts, Formulas.rarity(reward.GuaranteedRarity).Name .. " 확정 뽑기 1회")
	end
	local keys = RewardLogic.text({ Keys = reward.Keys, SpecialKeys = reward.SpecialKeys }, 1)
	if keys ~= "" then
		table.insert(parts, keys)
	end
	if reward.KeyPriceTimes then
		table.insert(parts, string.format("💰 %s원", Formulas.shortNumber(math.floor(keyPrice * reward.KeyPriceTimes))))
	end
	if reward.LuckMinutes then
		table.insert(parts, string.format("🍀 뽑기 행운 ×%g %d분", Config.StarterMissions.LuckMultiplier, reward.LuckMinutes))
	end
	if reward.ServerLuckMinutes then
		table.insert(parts, string.format("🌍 서버 모두 행운 ×%g %d분 (내 이름으로)", c.ServerLuckMultiplier, reward.ServerLuckMinutes))
	end
	if reward.MonthDino then
		table.insert(parts, string.format("🗓️ 이달의 공룡 %s (%s · %s, 출석 전용)", monthDinoName or "?",
			Formulas.rarity(c.MonthDinoRarity).Name, Formulas.dinoSize(c.MonthDinoSize).Name))
	end
	return table.concat(parts, " + ")
end

-- this month's attendance dino (a species Id)
function RewardLogic.monthDino(month)
	local list = Config.Attendance.MonthDinos
	return list[((month % 100) - 1) % #list + 1]
end

-- how many rewards wait to be taken in each tab of the 🎁 window: playtime gifts, today's missions
-- (and the bonus for all three), this week's milestones and challenges
-- ---------------------------------------------------------------------------
-- Friend bonus (2026-10-02): playing together with a Roblox friend, once a day for each pair
-- ---------------------------------------------------------------------------

-- friends who gave it today (a new day starts over)
function RewardLogic.friendsToday(profile, day)
	local f = profile.FriendBonus
	if f.Day ~= day then
		f.Day, f.Paid = day, {}
	end
	local n = 0
	for _ in pairs(f.Paid) do
		n += 1
	end
	return n
end

-- may this profile get the bonus with that friend today (not with them yet, under the day's limit)?
function RewardLogic.friendBonusOpen(profile, day, friendId)
	local n = RewardLogic.friendsToday(profile, day)
	return not profile.FriendBonus.Paid[tostring(friendId)] and n < Config.FriendInvite.PerDay
end

-- record it with that friend today
function RewardLogic.friendBonus(profile, day, friendId)
	RewardLogic.friendsToday(profile, day)
	profile.FriendBonus.Paid[tostring(friendId)] = true -- (string keys: a saved table stays a dictionary)
end

function RewardLogic.helpOpen(profile, day)
	local h = profile.Help
	return h.Day ~= day or h.Count < Config.Help.PerDay
end

function RewardLogic.helped(profile, day)
	local h = profile.Help
	if h.Day ~= day then
		h.Day, h.Count = day, 0
	end
	h.Count += 1
end

function RewardLogic.readyByTab(profile)
	local gifts, daily, weekly = 0, 0, 0
	for i in ipairs(Config.Rewards.Playtime) do
		if RewardLogic.playtimeReady(profile, i) then
			gifts += 1
		end
	end
	local all = #profile.Daily.Missions > 0
	for _, m in ipairs(profile.Daily.Missions) do
		if not m.Claimed and m.Progress >= m.Target then
			daily += 1
		end
		all = all and m.Claimed
	end
	if all and not profile.Daily.AllClaimed then
		daily += 1
	end
	for i, m in ipairs(Config.Rewards.Weekly.Milestones) do
		if profile.Weekly.Keys >= m.Keys and not profile.Weekly.Claimed[tostring(i)] then
			weekly += 1
		end
	end
	for _, c in ipairs(Config.Rewards.Weekly.Challenges) do
		local _, _, ready = RewardLogic.weeklyStep(profile, c.Kind)
		if ready then
			weekly += 1
		end
	end
	return gifts, daily, weekly, RewardLogic.attendanceReady(profile), RewardLogic.eventReady(profile)
end

function RewardLogic.ready(profile)
	local gifts, daily, weekly, attendance, event = RewardLogic.readyByTab(profile)
	return gifts + daily + weekly + attendance + event
end

-- ---------------------------------------------------------------------------
-- 🎉 The launch event (2026-10-04, Config.LaunchEvent: "런칭 이벤트 임무도 하나 만들자"): its missions count while it
-- runs, each reward is taken once, and every one taken gives the all-done reward (the skin and the title for good)
-- ---------------------------------------------------------------------------

-- do its missions count on this day number (Config.LaunchEvent.LastDay; nil = no end set)?
function RewardLogic.eventOpen(day)
	local e = Config.LaunchEvent
	return e ~= nil and (e.LastDay == nil or day <= e.LastDay)
end

-- the save's event progress when it is this event's, else nil (read only)
local function eventSave(profile)
	local ev = profile.Event
	return ev and ev.Id == Config.LaunchEvent.Id and ev or nil
end

-- the save's event is this one: a new Id starts the missions over (the skins and titles had stay)
function RewardLogic.ensureEvent(profile)
	local ev = profile.Event
	if ev.Id ~= Config.LaunchEvent.Id then
		ev.Id, ev.Progress, ev.Claimed, ev.AllClaimed = Config.LaunchEvent.Id, {}, {}, false
	end
end

-- progress of a kind on that day (counted only while it runs): the missions finished by it (their numbers)
function RewardLogic.progressEvent(profile, kind, amount, day)
	if not RewardLogic.eventOpen(day) then
		return {}
	end
	RewardLogic.ensureEvent(profile)
	local ev = profile.Event
	local finished = {}
	for i, m in ipairs(Config.LaunchEvent.Missions) do
		local key = tostring(i)
		local before = ev.Progress[key] or 0
		if table.find(m.Kinds, kind) and before < m.Target then
			ev.Progress[key] = math.min(m.Target, before + amount)
			if ev.Progress[key] >= m.Target then
				table.insert(finished, i)
			end
		end
	end
	return finished
end

-- mission i's reward, done and not taken yet (also after the event: what was done is kept), else nil
function RewardLogic.claimEvent(profile, i)
	local m = Config.LaunchEvent.Missions[i]
	local ev = eventSave(profile)
	local key = tostring(i)
	if not m or not ev or ev.Claimed[key] or (ev.Progress[key] or 0) < m.Target then
		return nil
	end
	ev.Claimed[key] = true
	return m.Reward
end

-- may the all-done reward be taken: every mission's reward taken, it not yet
function RewardLogic.eventAllReady(profile)
	local ev = eventSave(profile)
	if not ev or ev.AllClaimed then
		return false
	end
	for i in ipairs(Config.LaunchEvent.Missions) do
		if not ev.Claimed[tostring(i)] then
			return false
		end
	end
	return true
end

-- take the all-done reward: its skin (profile.Skins) and the event's title (profile.EventTitles) for good; the reward
-- (its keys) or nil
function RewardLogic.claimEventAll(profile)
	if not RewardLogic.eventAllReady(profile) then
		return nil
	end
	local e = Config.LaunchEvent
	profile.Event.AllClaimed = true
	profile.EventTitles[e.Id] = true
	if e.AllReward.Skin then
		profile.Skins[e.AllReward.Skin] = true
	end
	return e.AllReward
end

-- the event rewards waiting to be taken (the 🎉 tab's badge)
function RewardLogic.eventReady(profile)
	local ev = eventSave(profile)
	if not ev then
		return 0
	end
	local n = 0
	for i, m in ipairs(Config.LaunchEvent.Missions) do
		local key = tostring(i)
		if not ev.Claimed[key] and (ev.Progress[key] or 0) >= m.Target then
			n += 1
		end
	end
	return n + (RewardLogic.eventAllReady(profile) and 1 or 0)
end

function RewardLogic.readyClaims(profile)
	local out = {}
	for i in ipairs(Config.Rewards.Playtime) do
		if RewardLogic.playtimeReady(profile, i) then
			table.insert(out, { "PlaytimeAll", 0 })
			break
		end
	end
	local all = #profile.Daily.Missions > 0
	for i, m in ipairs(profile.Daily.Missions) do
		if not m.Claimed and m.Progress >= m.Target then
			table.insert(out, { "Daily", i })
		elseif not m.Claimed then
			all = false
		end
	end
	if all and not profile.Daily.AllClaimed then
		table.insert(out, { "DailyAll", 0 })
	end
	for i, m in ipairs(Config.Rewards.Weekly.Milestones) do
		if profile.Weekly.Keys >= m.Keys and not profile.Weekly.Claimed[tostring(i)] then
			table.insert(out, { "Weekly", i })
		end
	end
	for _, c in ipairs(Config.Rewards.Weekly.Challenges) do
		local _, _, ready = RewardLogic.weeklyStep(profile, c.Kind)
		if ready then
			table.insert(out, { "WeeklyChallenge", c.Kind })
		end
	end
	local ev = eventSave(profile)
	if ev then
		for i, m in ipairs(Config.LaunchEvent.Missions) do
			local key = tostring(i)
			if not ev.Claimed[key] and (ev.Progress[key] or 0) >= m.Target then
				table.insert(out, { "Event", i })
			end
		end
	end
	return out
end

-- the event title this save shows (Config.LaunchEvent.Title once its all-done reward was taken), else nil
function RewardLogic.eventTitle(profile)
	local e = Config.LaunchEvent
	return e and profile.EventTitles and profile.EventTitles[e.Id] and e.Title or nil
end

-- ---------------------------------------------------------------------------
-- ♾️ 무한 도전 (2026-10-02, Config.Defense.Challenge): this week's best waves, its milestones, last week's rank
-- ---------------------------------------------------------------------------

-- a new week: the week that ended waits for its rank reward when it was played, this week from 0
-- (2026-10-04: a week with no run keeps the one before it waiting, so a skipped week loses nothing)
function RewardLogic.ensureChallengeWeek(profile, week)
	local c = profile.Challenge
	if c.Week ~= week then
		if c.Best > 0 then
			c.LastWeek = c.Week
			c.LastBest = c.Best
		end
		c.Week, c.Best, c.Claimed = week, 0, {}
	end
end

-- a run ended with this many waves cleared: whether it is this week's new best, and the milestones it
-- reached for the first time this week (Config rows, paid by the service)
function RewardLogic.finishChallenge(profile, week, waves)
	RewardLogic.ensureChallengeWeek(profile, week)
	local c = profile.Challenge
	local newBest = waves > c.Best
	c.Best = math.max(c.Best, waves)
	c.AllBest = math.max(c.AllBest, waves)
	local reached = {}
	for i, m in ipairs(Config.Defense.Challenge.Milestones) do
		if c.Best >= m.Wave and not c.Claimed[tostring(i)] then
			c.Claimed[tostring(i)] = true
			table.insert(reached, m)
		end
	end
	return newBest, reached
end

-- last week to look up for a rank reward (played it, not paid yet), else nil
function RewardLogic.challengeRankDue(profile, week)
	RewardLogic.ensureChallengeWeek(profile, week)
	local c = profile.Challenge
	-- (2026-10-04: any finished week not paid yet, not only last week: was lost when a week was skipped)
	if c.LastWeek < week and c.LastBest > 0 and c.RankPaid < c.LastWeek then
		return c.LastWeek
	end
	return nil
end

-- the reward of a played week's all-server rank (the first row it fits), else the reward for playing
-- (Config PlayReward, 2026-10-04); the second value says whether it was a rank row
function RewardLogic.challengeRankReward(rank)
	for _, row in ipairs(Config.Defense.Challenge.RankRewards) do
		if rank and rank <= row.Top then
			return row.Reward, true
		end
	end
	return Config.Defense.Challenge.PlayReward, false
end

-- ---------------------------------------------------------------------------
-- 🏆 랭킹전 (2026-10-04, Config.Ranked): this week's counted wins of 🙈 hide-and-seek ("Hide") and 🏁 the races
-- ("Race"), the rivals they were against, last week's rank
-- ---------------------------------------------------------------------------

-- a new week: the week that ended waits for its rank rewards when it had a counted win, this week from 0
function RewardLogic.ensureRankedWeek(profile, week)
	local r = profile.Ranked
	if r.Week ~= week then
		local any = false
		for _, game in ipairs(Config.Ranked.Games) do
			any = any or r[game] > 0
		end
		if any then
			r.LastWeek = r.Week
			for _, game in ipairs(Config.Ranked.Games) do
				r["Last" .. game] = r[game]
			end
		end
		r.Week, r.Rivals = week, {}
		for _, game in ipairs(Config.Ranked.Games) do
			r[game] = 0
		end
	end
end

-- a ranked win in that game against these rivals (userIds): it counts in this week's ranking when one of them has
-- given this player fewer than Config.Ranked.SameRivalWins counted wins this week (each of those then one more).
-- Returns whether it counted
function RewardLogic.rankedWin(profile, week, game, rivals)
	RewardLogic.ensureRankedWeek(profile, week)
	local r = profile.Ranked
	local c = Config.Ranked
	local kept = 0
	for _ in pairs(r.Rivals) do
		kept += 1
	end
	local counted = false
	for _, userId in ipairs(rivals) do
		local key = string.sub(game, 1, 1) .. tostring(userId)
		local n = r.Rivals[key]
		if n == nil and kept >= c.RivalsKept then
			counted = true -- (more rivals than are remembered: a busy week, it counts)
		elseif (n or 0) < c.SameRivalWins then
			counted = true
			r.Rivals[key] = (n or 0) + 1
			kept += n == nil and 1 or 0
		end
	end
	if counted then
		r[game] += 1
	end
	return counted
end

function RewardLogic.stakeGrade(id)
	for _, g in ipairs(Config.Ranked.Stake.Grades) do
		if g.Id == id then
			return g
		end
	end
	return nil
end

function RewardLogic.stakeWorth(id)
	local g = RewardLogic.stakeGrade(id) or Config.Ranked.Stake.Grades[1]
	return g.Keys * Formulas.keyType(g.Id).PriceMultiplier
end

function RewardLogic.stakeSplit(worth, id)
	local g = RewardLogic.stakeGrade(id) or Config.Ranked.Stake.Grades[1]
	local each = Formulas.keyType(g.Id).PriceMultiplier
	return g.Id, math.floor(worth / each), worth % each
end

function RewardLogic.stakePayouts(order, id)
	local n = 0
	for _, group in ipairs(order) do
		n += #group
	end
	local weights, total, place = {}, 0, 1
	for _, group in ipairs(order) do
		local sum = 0
		for k = place, place + #group - 1 do
			sum += (n - k) ^ 2
		end
		for _, id in ipairs(group) do
			weights[id] = sum / #group
			total += sum / #group
		end
		place += #group
	end
	local worth = RewardLogic.stakeWorth(id)
	local pot = n * worth
	local pay = {}
	for userId, w in pairs(weights) do
		pay[userId] = total > 0 and math.floor(pot * w / total + 0.5) or worth
	end
	return pay
end

function RewardLogic.stakeBonus(profile, day)
	local r = profile.Ranked
	if r.StakeDay ~= day then
		r.StakeDay, r.StakeGames = day, 0
	end
	r.StakeGames += 1
	return r.StakeGames <= Config.Ranked.Stake.BonusGamesPerDay
end

-- a finished week of that game to look up for a rank reward (a counted win in it, not paid yet), else nil
function RewardLogic.rankedDue(profile, week, game)
	RewardLogic.ensureRankedWeek(profile, week)
	local r = profile.Ranked
	if r.LastWeek < week and r["Last" .. game] > 0 and r["Paid" .. game] < r.LastWeek then
		return r.LastWeek
	end
	return nil
end

-- one more of that game this week, with no rivals to look at (the night boss hunts, "Boss"); returns this week's count
function RewardLogic.rankedAdd(profile, week, game)
	RewardLogic.ensureRankedWeek(profile, week)
	local r = profile.Ranked
	r[game] = (r[game] or 0) + 1
	return r[game]
end

-- ---------------------------------------------------------------------------
-- 🧟 The night boss hunts (2026-10-04, Config.Zombies.Boss: "밤보스는 123 다 되나"): every boss helped down is a hunt
-- (ever: the titles; this week: the "Boss" ranking) and brings 🦴 bones; BonesForDino of one kind become its zombie dino
-- ---------------------------------------------------------------------------

-- a boss helped down: the hunt counted and the bones ({ [boss kind Id] = n }) added. Returns the boss kinds whose
-- bones are full now (in Config.Zombies.Boss.Kinds order, a kind twice if twice full): each made one zombie dino
-- (RewardLogic.addBoneDino) and its bones start over with what was left
function RewardLogic.bossHunt(profile, week, bones)
	local bc = Config.Zombies.Boss
	local h = profile.BossHunt
	h.Hunts += 1
	RewardLogic.rankedAdd(profile, week, "Boss")
	local full = {}
	for _, kind in ipairs(bc.Kinds) do
		local n = bones[kind.Id] or 0
		if n > 0 and Formulas.boneDino(kind.Id) then
			h.Bones[kind.Id] = (h.Bones[kind.Id] or 0) + n
			while h.Bones[kind.Id] >= bc.BonesForDino do
				h.Bones[kind.Id] -= bc.BonesForDino
				table.insert(full, kind.Id)
			end
		end
	end
	return full
end

-- that boss kind's zombie dino into the profile's dinos (Config.Zombies.Boss.BoneDino's rarity and size); the new unit
function RewardLogic.addBoneDino(profile, kindId)
	local d = Config.Zombies.Boss.BoneDino
	local unit = { Id = "U" .. profile.NextUnitId, Species = Formulas.boneDino(kindId).Id, Rarity = d.Rarity, Size = d.Size }
	profile.NextUnitId += 1
	table.insert(profile.Units, unit)
	Formulas.recordCollection(profile, unit)
	return unit
end

-- the reward of a finished week's rank (the first row it fits), else the reward for a counted win; the second
-- value says whether it was a rank row
function RewardLogic.rankedReward(rank)
	for _, row in ipairs(Config.Ranked.RankRewards) do
		if rank and rank <= row.Top then
			return row.Reward, true
		end
	end
	return Config.Ranked.PlayReward, false
end

return RewardLogic
