--[[
Analytics: what the closed beta needs to see in Roblox's analytics (2026-10-02; design 16 관문 "튜토리얼
완료율 70% 이상, 치명적 버그 없음", 17 매주 볼 지표). Nothing here changes the game.

- The economy: every PlayerData.addMoney / spendMoney is summed per player by reason and sent every
  Config.Analytics.FlushSeconds and when the player leaves (AnalyticsService:LogEconomyEvent, currency
  "Money", the reason as the item, its kind from Config.Analytics.TransactionTypes).
- Promotion fights (Rewards.add "Promotion" / "PromotionLost"): the "Defense" progression completed at
  the level reached, or failed at the level fought for (which level stops players most).
- Actions counted (Config.Analytics.CountedKinds, from Rewards.add): one custom event each with the count.
- The tutorial's steps are the Tutorial service's onboarding funnel; visits, retention and Robux are
  Roblox's own. Every call is guarded: analytics never stops the game.
- (2026-10-04, "본게임에서 광질 조금 하다 가던데") a new player's first steps in the game (Config.Analytics.FirstPlay: arriving,
  the first mining, deposit, key bought, draw, dino placed, 3/5/10/20/40 minutes played, the second pickaxe): Roblox's
  funnel "FirstPlay", each step once ever (profile.FirstPlay.Steps), so where the new ones stop shows.
]]

local AnalyticsService = game:GetService("AnalyticsService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local TutorialField = require(script.Parent:WaitForChild("TutorialField"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))

local Analytics = {}

local money = {} -- [player] = { [reason] = { source = n, sink = n }, balance = n }
local counts = {} -- [player] = { [kind] = n }
local counted = {}
for _, kind in ipairs(Config.Analytics.CountedKinds) do
	counted[kind] = true
end

local function call(method, ...)
	local ok, err = pcall(AnalyticsService[method], AnalyticsService, ...)
	if not ok then
		warn("[Analytics] " .. method .. ": " .. tostring(err))
	end
end

function Analytics.custom(player, name)
	call("LogCustomEvent", player, name, 1)
end

local function flush(player)
	local m, c = money[player], counts[player]
	money[player], counts[player] = nil, nil
	if m then
		for reason, flow in pairs(m.reasons) do
			local kind = Config.Analytics.TransactionTypes[reason] or "Gameplay"
			if flow.source > 0 then
				call("LogEconomyEvent", player, Enum.AnalyticsEconomyFlowType.Source, "Money", flow.source, m.balance,
					kind, tostring(reason))
			end
			if flow.sink > 0 then
				call("LogEconomyEvent", player, Enum.AnalyticsEconomyFlowType.Sink, "Money", flow.sink, m.balance,
					kind, tostring(reason))
			end
		end
	end
	for kind, n in pairs(c or {}) do
		call("LogCustomEvent", player, kind, n)
	end
end

local function level(player)
	local profile = PlayerData.get(player)
	return profile and profile.DefenseLevel or 0
end

-- (2026-10-04) the first-play funnel: step index once ever for this save (not on a tutorial field, not an old save)
local FP = Config.Analytics.FirstPlay
local function logFirst(player, index)
	local step = FP.Steps[index]
	local profile = PlayerData.get(player)
	local f = profile and profile.FirstPlay
	if not step or not f or f.Done or f.Funnel ~= FP.Name or f.Steps[step.Id] or TutorialField.isField() then
		return
	end
	PlayerData.update(player, function(p)
		p.FirstPlay.Steps[step.Id] = true
		local all = true
		for _, s in ipairs(FP.Steps) do
			all = all and p.FirstPlay.Steps[s.Id] == true
		end
		p.FirstPlay.Done = all or nil
	end)
	call("LogFunnelStepEvent", player, FP.Name, tostring(player.UserId), index, step.Id)
end

-- the steps reached by play time or the pickaxe (looked at every FP.CheckSeconds and on arriving)
local function checkFirst(player)
	local profile = PlayerData.get(player)
	if not profile or not profile.FirstPlay or profile.FirstPlay.Done or profile.FirstPlay.Funnel ~= FP.Name then
		return
	end
	for i, step in ipairs(FP.Steps) do
		if (not step.Kind and not step.Minutes and not step.Tier and not step.Level)
			or (step.Minutes and (profile.PlaySeconds or 0) >= step.Minutes * 60)
			or (step.Level and profile.DefenseLevel >= step.Level)
			or (step.Tier and profile.Upgrades.PickaxeTier >= step.Tier) then
			logFirst(player, i)
		end
	end
end

function Analytics.init()
	PlayerData.onMoney(function(player, change, reason, balance)
		if TutorialField.isField() then
			return -- (2026-10-03: a tutorial field's practice money is not the game's economy)
		end
		local m = money[player] or { reasons = {}, balance = 0 }
		money[player] = m
		local key = reason or "other"
		local flow = m.reasons[key] or { source = 0, sink = 0 }
		m.reasons[key] = flow
		if change > 0 then
			flow.source += change
		else
			flow.sink -= change
		end
		m.balance = balance
	end)
	Rewards.onAdd(function(player, kind, amount)
		for i, step in ipairs(FP.Steps) do -- (2026-10-04) the first-play funnel's firsts
			if step.Kind == kind and (amount or 0) > 0 then
				logFirst(player, i)
			end
		end
		if kind == "Promotion" then
			checkFirst(player)
			local n = level(player)
			call("LogProgressionCompleteEvent", player, "Defense", n, "LV " .. n)
		elseif kind == "PromotionLost" then
			local n = level(player) + 1
			call("LogProgressionFailEvent", player, "Defense", n, "LV " .. n)
		elseif counted[kind] and (amount or 0) > 0 then
			local c = counts[player] or {}
			counts[player] = c
			c[kind] = (c[kind] or 0) + amount
		end
	end)
	Players.PlayerRemoving:Connect(flush)
	task.spawn(function()
		while true do
			task.wait(Config.Analytics.FlushSeconds)
			for _, player in ipairs(Players:GetPlayers()) do
				flush(player)
			end
		end
	end)
	PlayerData.onLoaded(checkFirst) -- (arriving)
	task.spawn(function()
		while true do
			task.wait(FP.CheckSeconds)
			for _, player in ipairs(Players:GetPlayers()) do
				checkFirst(player)
			end
		end
	end)
end

return Analytics
