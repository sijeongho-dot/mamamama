--[[
TutorialField (2026-10-03, "튜토리얼 필드를 새로 만들고 튜토리얼 진행하는 사람은 거기로 보내서 체험할 수 있는거 다해보게
하자 … 튜토리얼을 모두 끝내면 보상도 주고. 나중에 다 끝내고 재도전은 보상없고 … 튜토가 끝나면 이제 본기지로 돌아와서 할 거
하게", chosen: 나만의 튜토리얼 서버): the tutorial runs on a server of its own for one player, a reserved copy of this place
(the same map and every system), so Coco can bring rain, the night, zombies and the night boss for that one player.
What is done there is saved apart (Config.Tutorial.Field.StoreName) and never reaches the player's real save: when
it ends they go back to a public server and start their own base fresh, with the reward the first time (Tutorial).

	TutorialField.isField()        -- this server is a tutorial field
	TutorialField.decide(player)   -- (PlayerData, before a load) Studio only: whether this Studio test plays the field
	TutorialField.joinData(player) -- { Replay, Part?, Language?, Lesson, Again, Done = { part Id } } the main server sent
	                                -- (Studio: what it saved)
	TutorialField.toField(player, data) / TutorialField.toMain(player) -- the teleports (Studio: a kick that says
	                                -- to run the test again, since Studio can't teleport)
	TutorialField.fieldProfile(userId) / TutorialField.mainProfile(userId) -- a saved profile read (nil if none)

A field server is a reserved server (game.PrivateServerId set, no owner): this game makes no other reserved servers.
In Studio (no teleports) a test plays the field when the player's real save says the tutorial is still to do
(TutorialLogic.mainAction), and the main game otherwise; the ends of the field say "run the test again".
]]

local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TeleportService = game:GetService("TeleportService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local TutorialLogic = require(script.Parent:WaitForChild("TutorialLogic"))

local TutorialField = {}

local F = Config.Tutorial.Field
local TELEPORT_TRIES = 3
local TELEPORT_WAIT = 4 -- seconds between tries

local reserved = game.PrivateServerId ~= "" and game.PrivateServerOwnerId == 0
local studioField = nil -- Studio: nil until the first player's save is read, then true / false
local studioData = {} -- [userId] = { Replay, Part } (Studio: from the real save)

local function store(name)
	local ok, s = pcall(function()
		return DataStoreService:GetDataStore(name)
	end)
	return ok and s or nil
end

-- a saved profile (nil if none) and whether the store could be read at all
local function read(name, userId)
	local s = store(name)
	if not s then
		return nil, false
	end
	local ok, value = pcall(function()
		return s:GetAsync("Player_" .. userId)
	end)
	return ok and type(value) == "table" and value or nil, ok
end

function TutorialField.mainProfile(userId)
	return (read(Config.Data.StoreName, userId))
end

function TutorialField.fieldProfile(userId)
	return (read(F.StoreName, userId))
end

function TutorialField.isField()
	if RunService:IsStudio() then
		return studioField == true
	end
	return reserved
end

local function publish()
	ReplicatedStorage:SetAttribute("TutorialField", TutorialField.isField() or nil)
end

-- Studio: the first player's real save decides whether this test is the field (every later player follows it)
function TutorialField.decide(player)
	if not RunService:IsStudio() or studioField ~= nil then
		return
	end
	local main, readable = read(Config.Data.StoreName, player.UserId)
	if not readable then -- (Studio without API access: no saves to tell by, so the main game as before)
		studioField = false
		warn("[TutorialField] Studio: 저장을 읽을 수 없어 본 게임으로 시작해요 (튜토리얼 필드는 API 서비스 접근을 켜야 해요)")
		publish()
		return
	end
	local field = TutorialField.fieldProfile(player.UserId)
	local mainT = main and main.Tutorial or { Done = false }
	studioField = TutorialLogic.mainAction(mainT, field and field.Tutorial) == "field"
	local again = mainT.Done == true and mainT.ReplayCore == true -- (2026-10-04: the skipped first run again)
	studioData[player.UserId] = { Replay = mainT.Done == true and (mainT.ReplayAt or 0) > 0 and not again,
		Again = again, Part = mainT.ReplayPart,
		Asked = mainT.ReplayAt, Language = main and main.Settings and main.Settings.Language,
		Done = TutorialLogic.mainPartsDone(mainT) }
	if studioField then
		print("[TutorialField] Studio: 이번 테스트는 튜토리얼 필드예요 (본 저장과 따로)")
	end
	publish()
end

-- a list of part Ids from teleport data (strings only)
local function doneList(list)
	local out = {}
	if type(list) == "table" then
		for _, id in ipairs(list) do
			if type(id) == "string" then
				table.insert(out, id)
			end
		end
	end
	return out
end

function TutorialField.joinData(player)
	if RunService:IsStudio() then
		return studioData[player.UserId] or {}
	end
	local ok, join = pcall(function()
		return player:GetJoinData()
	end)
	local data = ok and type(join) == "table" and join.TeleportData
	if type(data) ~= "table" then
		return {}
	end
	return { Replay = data.Replay == true, Part = type(data.Part) == "string" and data.Part or nil,
		Asked = type(data.Asked) == "number" and data.Asked or nil,
		Language = type(data.Language) == "string" and data.Language or nil,
		Lesson = data.Lesson == true, -- (2026-10-03: a lesson whose reward is still to come)
		Again = data.Again == true, -- (2026-10-04: the skipped first run again, its reward at the end)
		LaunchGift = data.LaunchGift == true, -- (2026-10-04: show the launch gift's window, LaunchGift)
		Done = doneList(data.Done) } -- (2026-10-03: the parts the real save knows finished, TutorialLogic.canSkip)
end

local function teleport(player, options)
	for try = 1, TELEPORT_TRIES do
		if not player.Parent then
			return true
		end
		local ok, err = pcall(function()
			TeleportService:TeleportAsync(game.PlaceId, { player }, options)
		end)
		if ok then
			return true
		end
		warn(string.format("[TutorialField] %s 이동 실패 (%d/%d): %s", player.Name, try, TELEPORT_TRIES, tostring(err)))
		task.wait(TELEPORT_WAIT)
	end
	return false
end

-- to a field of their own (data: { Replay, Part }); false when it could not be done
function TutorialField.toField(player, data)
	if RunService:IsStudio() then
		player:Kick("[Studio] 튜토리얼 필드는 테스트를 다시 실행하면 시작돼요")
		return true
	end
	local ok, code = pcall(function()
		return TeleportService:ReserveServer(game.PlaceId)
	end)
	if not ok then
		warn("[TutorialField] 튜토리얼 서버를 못 만들었어요: " .. tostring(code))
		return false
	end
	local options = Instance.new("TeleportOptions")
	options.ReservedServerAccessCode = code
	options:SetTeleportData({ Replay = data and data.Replay == true, Part = data and data.Part,
		Asked = data and data.Asked, -- (2026-10-03: a replay left halfway goes on where it stopped)
		Language = data and data.Language, -- (2026-10-03: the field speaks the player's language)
		Lesson = data and data.Lesson == true, Again = data and data.Again == true, Done = data and data.Done })
	return teleport(player, options)
end

-- back to a public server of the game
function TutorialField.toMain(player)
	if RunService:IsStudio() then
		player:Kick("[Studio] 튜토리얼 끝! 테스트를 다시 실행하면 본 기지에서 시작해요")
		return true
	end
	return teleport(player, nil)
end

publish()
Players.PlayerRemoving:Connect(function(player)
	studioData[player.UserId] = nil
end)

return TutorialField
