--[[
Zombies: zombie dinos on the battlefield at night (design 2.12; the rules are ZombieLogic's).

- Config.Zombies.Count homes spread evenly over the battlefield. At nightfall (DayNight) each zombie
  crawls out of the ground at its home, at dawn it sinks back in.
- Every TickSeconds the server steps ZombieLogic with the players a zombie may hit
  (Combat.hittable: alive, on the battlefield, not flying or groggy). A hit throws the player like a
  slap (Combat.throw: carried keys fall, groggy after).
- What the clients draw (StarterPlayerScripts/Zombies): Workspace.Zombies holds one Configuration
  per zombie with attributes Species, P (Vector3: x, the ground's height under it, z; 2026-10-04: was X, Z and Y),
  H (heading), State ("Under", "Waiting", "Rising", "Up", "Sinking"), StateAt (server time), and AttackAt /
  HitUserId at each hit.
- The night's boss (Config.Zombies.Boss): one more, giant zombie with its own numbers (ZombieLogic
  params), at a new random spot on the battlefield each night, announced with a banner. Its stage
  (size, name) comes from the players on the server at nightfall (Formulas.bossStage); (2026-10-04) its health
  from the players on the server, kept so while it is up (Formulas.bossHealth: one joins, it grows), and
  each hitter's reward from the players when it goes down (Formulas.bossRewardShare). A slap near it hits it, along with the zombies in reach (Combat.onSlap; damage
  Formulas.bossSlapDamage(slap level); reach + its body, in front) and makes it go after the slapper.
  Players close enough to slap a boss (its body + their own reach) can't be slapped (Combat.protect).
  Slapped down it sinks for the rest of the night and drops the stage's pile of treasure chests around
  the spot (Treasure.spawnNow; each pays at the opener's own level); everyone who slapped it gets a
  daily mission step ("Boss"). Its Configuration
  "Boss" also has attributes Boss = true, BossName, BossScale, BossHP, BossMaxHP, BossHitAt (server
  time of the last slap) and DefeatedAt.
- Boss kinds (Config.Zombies.Boss.Kinds, 2026-10-01): each night one at random (Formulas.pickBossKind,
  never last night's): 🦖 좀비 티라노 (Attack "Roar": rears up for WindUp, then a shockwave throws
  everyone within Radius), 🦕 좀비 트리케라 ("Charge": paws the ground, then charges Distance studs at
  Speed in a straight line, throwing whoever it runs into), 🦅 좀비 프테라 ("Bomb": flies low, Hover,
  and drops a big dropping where a player stands; FallSeconds later everyone within Radius is thrown).
  Net push BossFx shows the attack on every screen. Its chests are its kind's (Treasure.spawnNow kind:
  money, keys or minerals). Attributes BossKind, BossModel, BossHover.
- The aurora boss (Config.Zombies.AuroraBoss, 2026-10-01): when the weather turns to the aurora at night
  (ReplicatedStorage attribute Weather "Aurora", Weather service) a second, far bigger and tougher boss
  climbs out at a random spot (Configuration "AuroraBoss", attribute Aurora = true; health from
  Formulas.auroraBossHealth). It uses Roar, Charge and Bomb in turn, more often, and throws harder.
  Down, it showers chests of every kind (AuroraBoss.Chests) and everyone who slapped it gets
  HitterReward at their own level (Rewards.grant). It sinks at dawn like the others.
- Net push BossFx carries the boss's Configuration name last, so the screens animate the right one.
- Why slap it down (2026-10-04, "밤 보스를 잡아야 되는 이유를 모르겠네 … 명분이 있으면", "밤보스는 123 다 되나";
  Config.Zombies.Boss): everyone who hit the night's boss gets ① HitterReward at their own level, and the one who took
  the most of its health MvpReward too (when MvpMinHitters or more hit it), in one notice; ② 🦴 its kind's bones (the
  MVP more; the aurora boss: AuroraBones of every kind): BonesForDino of a kind become that kind's zombie dino
  (Config.GiftSpecies, BossKind; RewardLogic.bossHunt / addBoneDino), announced to the server; ③ a hunt: this week's
  hunts are a 🏆 ranking (Config.Ranked game "Boss", Leaderboards.rankedWin, BossWeekTop) and all hunts ever give the
  titles (HuntTitles). Player attributes BossHunts (ever) and HuntTitle (the title's name, over the head: Race
  client). Net ask GetBossHunt: { Hunts, Week, Bones = { [kind Id] = n } } (the 🎮 window's 🧟 tab). Not on a
  tutorial field (its save is a practice one).
- The next day's buff: once the boss is down, the whole server gets its kind's Buff (Config.DayBuffs)
  through the next day: ReplicatedStorage attributes DayBuff (Money / Defense / Mining) and
  DayBuffEndsAt (server time); PlayerData.addMoney and Minerals read it (Formulas.dayBuff).
- The ground (2026-10-01, "지형지물 통과 못하게, 크리스탈 위에 있다면 점프해서 올라 쫓아가게, 끼지 않게
  최적 경로로"): the service is ZombieLogic's world (ZombieLogic.setWorld): surfaceAt(x, z) is the top of
  what stands there, from a ray down (players, the zombies, grass, decor, flags and keys left out). The
  zombies step up at most Zombies.StepHeight walking, so crystals, rocks and trees are in the way (they
  go round); a player holding out up on one gets jumped after (ZombieLogic). Each zombie has a height
  (P's Y, for the screens).
  A chasing zombie that ran into something (z.blocked), or whose path no longer ends near its target,
  gets a path from PathfindingService (at most PathsPerTick a tick, each zombie at most every
  RepathSeconds) and follows its waypoints; with no path it goes straight (and up onto crystals).
  Hits and the bosses' Roar and Charge need the player's feet within HitHeight of the zombie's; a
  Charge stops short of a wall. Homes on a tree or rock move to a clear spot nearby.
- Players slap the other zombies back (Combat.onSlap): every one up, in front (2026-10-01, was the nearest),
  within the slap's reach + Config.Zombies.BodyRadius is thrown SlapKnockback studs away and lies
  dizzy (ZombieLogic.knock). Attributes KnockAt (server time; the clients fly it in an arc) and
  StunUntil (server time).
]]

local Players = game:GetService("Players")
local PathfindingService = game:GetService("PathfindingService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local ZombieLogic = require(script.Parent:WaitForChild("ZombieLogic"))
local Combat = require(script.Parent:WaitForChild("Combat"))
local DayNight = require(script.Parent:WaitForChild("DayNight"))
local Treasure = require(script.Parent:WaitForChild("Treasure"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))
local Leaderboards = require(script.Parent:WaitForChild("Leaderboards"))
local TutorialField = require(script.Parent:WaitForChild("TutorialField"))
local Keys = require(script.Parent:WaitForChild("Keys"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local Story = require(script.Parent:WaitForChild("Story"))

local Zombies = {}

local rng = Random.new()
local zombies = {}
local shown = {} -- [index] = its Configuration
local lastSent = {} -- [index] = { x, z, h, state }
local folder = nil
-- the bosses: { z (its ZombieLogic entry), conf, hp, maxHp, scale, name, icon, attacks (in turn), turn,
-- everyMul, special (its big attack under way), nextSpecial, hitters, chests ({ [kind] = n }), buff, reward }
local nightBoss, auroraBoss = nil, nil
local guards = {} -- the aurora boss's guards (ordinary zombies kept by it): { z, angle }
local bosses = {}
local nightKind = nil -- tonight's boss kind (Config.Zombies.Boss.Kinds), from the first nightfall on
local pendingBuff = nil -- the buff the next day brings (the boss went down tonight)
local pendingIcon = ""

-- (2026-10-04: what everyone who hit it gets, 🔑·🦴, in place of "때리면 💰, ": the +원 over each hit says that)
local AURORA_SUMMARY = "피해 %d등 / %d명 · 때려서 번 돈 +%s원%s" -- (each hitter's own summary)
local AURORA_MVP = " · 🏆 상위 보상: 루비 열쇠!"
-- (2026-10-04) each hitter's notice once the night's boss is down, and the hunt's lines in it
local HUNT_TITLE = "%s %s 사냥 성공!"
local HUNT_MVP = "🏆 가장 많이 때렸어요!"
local HUNT_BONES = "🦴 %s 뼈 +%d (%d/%d)"
local HUNT_DINO = "🎉 🦴 뼈 %d개로 %s 완성!"
local HUNT_DINO_BANNER = "🎉 🦴 뼈 %d개가 모여 %s가 깨어났어요!"
local HUNT_DINO_ALL = "🧟 %s님이 🦴 뼈를 모아 %s를 만들었어요!"
local HUNT_COUNT = "🧟 이번 주 사냥 %d마리 · 모두 %d마리"
local HUNT_TITLE_NEW = "🏅 새 칭호: %s!"
local HUNT_TITLE_ALL = "🏅 %s님 새 칭호: %s! (보스 사냥 %d마리)"

local BUFF_BANNER = "%s 어젯밤 보스를 쓰러뜨려서 오늘 낮 동안 %s +%d%%! (%d분)"
local BUFF_BANNER_DELAY = 4 -- seconds after the day's own banner
local CHEST_NAMES = { Money = "💰 보물상자", Keys = "🔑 열쇠 상자", Minerals = "💎 광물 상자" }
local HOVER_BASE_SCALE = 2.2 -- a boss kind's Hover is for this stage Scale
local BOSS_BASE_SCALE = 2.4 -- the size Config.Zombies.Boss.BodyRadius was measured at
-- the ground under them (see the top)
local SURFACE_FROM = 300 -- studs: the ray down starts this high
local SURFACE_CELL = 1 -- studs: tops are remembered per cell of this size ...
local SURFACE_KEEP = 2 -- ... for this many seconds (crystals come and go)
local SURFACE_CACHE_MAX = 20000 -- cells remembered at most (then forgotten all at once)
local IGNORE_REFRESH = 2 -- seconds between rebuilding what the ray leaves out (characters come and go)
local NOT_SURFACE = { "FieldGrass", "SafeGrass", "Decor", "BattlefieldFlags" } -- Map folders the ray goes through
local NOT_SURFACE_TOP = { "Zombies", "Keys", "SpeedPads" } -- Workspace folders it goes through
local CLEAR_SPOT_RINGS = { 4, 8, 12, 16, 20, 24 } -- studs: a home on a tree moves out to the first clear one
local PATH_AGENT_HEIGHT = 5
local CHARGE_PROBE = 2 -- studs between the looks ahead along a boss's charge
local PATH_MAX_RADIUS = 8 -- studs: a giant's path agent at most this wide (else no way between trees)
local PATH_STATUS_OK = { [Enum.PathStatus.Success] = true, [Enum.PathStatus.ClosestNoPath] = true }
local BOSS_CHEST_DROP = 3 -- studs below the last slapper's middle: about the ground there

local function random()
	return rng:NextNumber()
end

-- ---------------------------------------------------------------------------
-- The ground under the zombies (ZombieLogic's world)
-- ---------------------------------------------------------------------------

local surfaceCache, cacheCount = {}, 0
local rayParams, rayParamsAt = nil, -math.huge
local groundParams = nil

local function surfaceRay()
	local now = os.clock()
	if rayParams and now - rayParamsAt < IGNORE_REFRESH then
		return rayParams
	end
	local ignore = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	local map = Workspace:FindFirstChild("Map")
	for _, name in ipairs(NOT_SURFACE) do
		local f = map and map:FindFirstChild(name)
		if f then
			table.insert(ignore, f)
		end
	end
	for _, name in ipairs(NOT_SURFACE_TOP) do
		local f = Workspace:FindFirstChild(name)
		if f then
			table.insert(ignore, f)
		end
	end
	rayParams = RaycastParams.new()
	rayParams.FilterType = Enum.RaycastFilterType.Exclude
	rayParams.RespectCanCollide = true
	rayParams.FilterDescendantsInstances = ignore
	rayParamsAt = now
	return rayParams
end

-- the top of what stands at (x, zz) (a crystal's, a rock's, a tree's or the ground's)
local function surfaceAt(x, zz)
	local now = os.clock()
	local key = math.floor(x / SURFACE_CELL) * 100000 + math.floor(zz / SURFACE_CELL)
	local cached = surfaceCache[key]
	if cached and now - cached[2] < SURFACE_KEEP then
		return cached[1]
	end
	local hit = Workspace:Raycast(Vector3.new(x, SURFACE_FROM, zz), Vector3.new(0, -SURFACE_FROM * 2, 0), surfaceRay())
	local top = hit and hit.Position.Y or 0
	if cacheCount >= SURFACE_CACHE_MAX then
		surfaceCache, cacheCount = {}, 0
	end
	if not cached then
		cacheCount += 1
	end
	surfaceCache[key] = { top, now }
	return top
end

-- the ground itself at (x, zz) (the map's ground and terrain only): where a zombie stands up from
local function groundAt(x, zz)
	if not groundParams then
		local map = Workspace:FindFirstChild("Map")
		local ground = map and map:FindFirstChild("Ground")
		groundParams = RaycastParams.new()
		groundParams.FilterType = Enum.RaycastFilterType.Include
		groundParams.FilterDescendantsInstances = { ground or Workspace.Terrain, Workspace.Terrain }
	end
	local hit = Workspace:Raycast(Vector3.new(x, SURFACE_FROM, zz), Vector3.new(0, -SURFACE_FROM * 2, 0), groundParams)
	return hit and hit.Position.Y or 0
end

-- (x, zz), or the first clear spot round it (on the ground: not in a tree, rock or crystal)
local function clear(x, zz)
	return surfaceAt(x, zz) - groundAt(x, zz) <= Config.Zombies.StepHeight
end
local function clearSpot(x, zz)
	if clear(x, zz) then
		return x, zz
	end
	for _, r in ipairs(CLEAR_SPOT_RINGS) do
		for k = 0, 7 do
			local a = k * math.pi / 4
			local nx, nz = x + math.cos(a) * r, zz + math.sin(a) * r
			if clear(nx, nz) then
				return nx, nz
			end
		end
	end
	return x, zz
end

ZombieLogic.setWorld({
	surface = function(_, x, zz)
		return surfaceAt(x, zz)
	end,
})

-- a zombie out of the ground without a height yet (just crawling out, put home): off any tree, on what is there
local function settle(z)
	if z.y ~= nil or z.state == "Under" then
		return
	end
	z.x, z.z = clearSpot(z.x, z.z)
	z.y = surfaceAt(z.x, z.z)
end

-- a chaser's path round what is in the way (PathfindingService; runs on its own, the zombie goes straight
-- meanwhile)
local function bodyOf(z)
	for _, b in ipairs(bosses) do
		if b.z == z then
			return Config.Zombies.Boss.BodyRadius * b.scale / BOSS_BASE_SCALE
		end
	end
	return Config.Zombies.BodyRadius
end

local function findPath(z, goal, targetId)
	z.pathBusy = true
	local radius = math.min(PATH_MAX_RADIUS, bodyOf(z))
	local path = PathfindingService:CreatePath({ AgentRadius = radius, AgentHeight = PATH_AGENT_HEIGHT,
		AgentCanJump = false, WaypointSpacing = Config.Zombies.PathWaypointSpacing })
	local ok = pcall(function()
		path:ComputeAsync(Vector3.new(z.x, (z.y or 0) + 1, z.z), goal)
	end)
	z.pathBusy = false
	if z.target ~= targetId then
		return -- (it moved on to someone else meanwhile)
	end
	z.pathGoal = goal
	if ok and PATH_STATUS_OK[path.Status] then
		local points = {}
		for i, w in ipairs(path:GetWaypoints()) do
			if i > 1 then
				table.insert(points, { w.Position.X, w.Position.Z })
			end
		end
		z.path = points
	else
		z.path = nil -- (straight on: up onto a crystal, or round what it can)
	end
end

-- every tick: paths for the chasers that ran into something or whose path ends far from the target now
local function planPaths(list, now)
	local c = Config.Zombies
	local budget = c.PathsPerTick
	for _, z in ipairs(zombies) do
		if z.state ~= "Up" or not z.target then
			z.path, z.pathGoal, z.pathFor = nil, nil, nil
		elseif not z.pathBusy and budget > 0 then
			if z.pathFor ~= z.target then
				z.path, z.pathGoal, z.pathFor = nil, nil, z.target
			end
			local t
			for _, p in ipairs(list) do
				if p.id == z.target then
					t = p
				end
			end
			local stale = t and z.path and z.pathGoal
				and Vector3.new(t.x - z.pathGoal.X, 0, t.z - z.pathGoal.Z).Magnitude > c.RepathMove
			if t and (z.blocked or stale) and now - (z.pathAt or -math.huge) >= c.RepathSeconds then
				budget -= 1
				z.pathAt, z.blocked = now, false
				task.spawn(findPath, z, Vector3.new(t.x, t.y, t.z), z.target)
			end
		end
	end
end

-- the attributes the clients read, only when they changed; positions at most every
-- Config.Zombies.PublishSeconds (the clients glide to the latest spot; every tick was 1,200 updates a
-- second to every screen with 40 zombies). (2026-10-04, "8명이 풀로 승급전 돌리고 배틀필드 밤에 돌아다닐때 … 매끄럽게")
-- the spot is one attribute P (x, the ground's height, z), the heading H only when it turned: was X, Z, Y and H
-- each time, four updates to every screen for every zombie that moved
local lastPositions = 0
local function publish(now)
	local positions = now - lastPositions >= Config.Zombies.PublishSeconds
	if positions then
		lastPositions = now
		if folder then
			folder:SetAttribute("PT", Workspace:GetServerTimeNow())
		end
	end
	for i, z in ipairs(zombies) do
		local c, last = shown[i], lastSent[i]
		if last.state ~= z.state then
			c:SetAttribute("State", z.state)
			c:SetAttribute("StateAt", Workspace:GetServerTimeNow() - (now - z.stateAt))
			last.state = z.state
		end
		if (z.thief or z.guardian) and z.state == "Up" and (math.abs(last.x - z.x) > 0.05 or math.abs(last.z - z.z) > 0.05) then
			c:SetAttribute("PT", Workspace:GetServerTimeNow())
			c:SetAttribute("P", Vector3.new(z.x, z.y or 0, z.z))
			last.x, last.z, last.y = z.x, z.z, z.y
		end
		if positions then
			if math.abs(last.x - z.x) > 0.05 or math.abs(last.z - z.z) > 0.05
				or (z.y and math.abs((last.y or -math.huge) - z.y) > 0.1) then
				c:SetAttribute("P", Vector3.new(z.x, z.y or 0, z.z))
				last.x, last.z, last.y = z.x, z.z, z.y
			end
			if math.abs(last.h - z.heading) > 0.02 then
				c:SetAttribute("H", z.heading)
				last.h = z.heading
			end
		end
	end
end

local function guardSpeedOf(player, carrying)
	if carrying <= 0 then
		return nil
	end
	local rarity, size = Keys.chaseOf(player)
	if not rarity then
		return nil
	end
	return Formulas.guardianSpeed(rarity, size) * MoveGuard.chaseBoost(player)
end

local function targets()
	local list = {}
	for _, player in ipairs(Players:GetPlayers()) do
		local ok, root = Combat.hittable(player)
		if ok then
			-- (2026-10-01) the feet's height: a zombie reaches only so high (ZombieLogic HitHeight)
			local humanoid = root.Parent and root.Parent:FindFirstChildOfClass("Humanoid")
			local feet = root.Position.Y - root.Size.Y / 2 - (humanoid and humanoid.HipHeight or 2)
			local carrying = player:GetAttribute("CarriedKeys") or 0
			table.insert(list, { id = player.UserId, x = root.Position.X, z = root.Position.Z, y = feet, root = root,
				player = player, carrying = carrying, guardSpeed = guardSpeedOf(player, carrying) })
		end
	end
	return list
end

-- one more zombie, a boss, with its own numbers and its own Configuration
local function makeBoss(name, params)
	local z = ZombieLogic.new({ { x = Config.Zombies.PlazaRadius + Config.Zombies.Boss.HomeRadius, z = 0 } })[1]
	z.params = params
	table.insert(zombies, z)
	local conf = Instance.new("Configuration")
	conf.Name = name
	conf:SetAttribute("Species", "TRex")
	conf:SetAttribute("Boss", true)
	conf:SetAttribute("P", Vector3.new(z.x, 0, z.z))
	conf:SetAttribute("H", 0)
	conf:SetAttribute("State", z.state)
	conf:SetAttribute("StateAt", 0)
	conf.Parent = folder
	shown[#zombies] = conf
	lastSent[#zombies] = { x = z.x, z = z.z, h = 0, state = z.state }
	local b = { z = z, conf = conf, hp = 0, maxHp = 0, scale = Config.Zombies.Boss.Stages[1].Scale, name = "",
		icon = "👑", attacks = { "Roar" }, turn = 1, everyMul = 1, nextSpecial = 0, hitters = {}, chests = {} }
	table.insert(bosses, b)
	return b
end

-- a random spot on the battlefield for a boss's home
local function serverPower(leaving)
	local power = 0
	for _, p in ipairs(Players:GetPlayers()) do
		local profile = p ~= leaving and PlayerData.get(p)
		if profile then
			power += Formulas.bossPower(Formulas.trained(profile.Upgrades, profile.Training).Slap)
		end
	end
	return power
end

local function bossHome(b)
	local c, bc = Config.Zombies, Config.Zombies.Boss
	local inner = c.PlazaRadius + bc.HomeRadius
	local outer = Config.Battlefield.Radius - c.EdgeMargin - bc.HomeRadius
	local a, r = rng:NextNumber(0, 2 * math.pi), rng:NextNumber(inner, math.max(inner, outer))
	b.z.homeX, b.z.homeZ = clearSpot(math.cos(a) * r, math.sin(a) * r)
end

local function attackOf(b)
	return b.attacks[(b.turn - 1) % #b.attacks + 1]
end

local function publishBoss(b, kindId, model, species, hover)
	local conf = b.conf
	conf:SetAttribute("BossName", b.name)
	conf:SetAttribute("BossKind", kindId)
	conf:SetAttribute("BossModel", model)
	conf:SetAttribute("Species", species)
	conf:SetAttribute("BossHover", hover)
	conf:SetAttribute("BossScale", b.scale)
	conf:SetAttribute("BossMaxHP", b.maxHp)
	conf:SetAttribute("BossHP", b.hp)
end

-- the night's boss for this kind and stage
local function setNightKind(b, kind, stage)
	nightKind = kind
	b.name, b.icon, b.scale = stage.Prefix .. kind.Name, kind.Icon, stage.Scale
	b.attacks, b.turn, b.everyMul = { kind.Attack }, 1, 1
	b.chestKind, b.buff, b.reward = kind.Chest, kind.Buff, Config.Zombies.Boss.HitterReward
	b.kindId = kind.Id -- (its 🦴 bones)
	b.special, b.nextSpecial = nil, os.clock() + Config.Zombies.Boss[kind.Attack].Every
	publishBoss(b, kind.Id, kind.Model, kind.Species, kind.Hover and kind.Hover * stage.Scale / HOVER_BASE_SCALE or nil)
end

-- a new night: the boss at a new random spot on the battlefield, at full health for everyone here
local function newBossNight()
	local b = nightBoss
	bossHome(b)
	local players = #Players:GetPlayers()
	local stage = Formulas.bossStage(players)
	local kind = Formulas.pickBossKind(nightKind and nightKind.Id, rng:NextNumber())
	b.maxHp, b.hitters, b.practice = Formulas.bossHealth(players, serverPower()), {}, nil
	b.hp = b.maxHp
	setNightKind(b, kind, stage)
	task.delay(Config.Zombies.RiseSpread, function()
		if DayNight.isNight() then
			Story.showAll("NightBoss", Story.explain("NightBoss", kind.Icon, b.name, CHEST_NAMES[kind.Chest]))
		end
	end)
end

local function chestCount(chests)
	local n = 0
	for _, count in pairs(chests) do
		n += count
	end
	return n
end

-- the aurora boss climbs out now at `at` (or a random spot), at full health for everyone here
local function auroraRise(at)
	local a = Config.Zombies.AuroraBoss
	local b = auroraBoss
	if at then
		b.z.homeX, b.z.homeZ = at.X, at.Z
	else
		bossHome(b)
	end
	local players = #Players:GetPlayers()
	b.maxHp = Formulas.auroraBossHealth(players, serverPower())
	b.hp, b.hitters, b.practice = b.maxHp, {}, nil
	b.name, b.icon, b.scale = a.Name, a.Icon, a.Scale
	b.attacks, b.turn, b.everyMul = a.Attacks, 1, a.EveryMultiplier
	b.chestKind, b.buff, b.reward = nil, nil, a.HitterReward
	b.kindId = nil -- (its bones: every kind's, AuroraBones)
	b.special, b.nextSpecial = nil, os.clock() + Config.Zombies.Boss[a.Attacks[1]].Every * a.EveryMultiplier
	b.conf:SetAttribute("Aurora", true)
	publishBoss(b, "Aurora", a.Model, a.Species, nil)
	local z = b.z
	z.x, z.z, z.target, z.wanderX = z.homeX, z.homeZ, nil, nil
	z.state, z.stateAt = "Rising", os.clock()
	-- its guards climb out round it
	for _, g in ipairs(guards) do
		local gz = g.z
		gz.homeX = z.homeX + math.cos(g.angle) * a.GuardRing
		gz.homeZ = z.homeZ + math.sin(g.angle) * a.GuardRing
		gz.x, gz.z, gz.target, gz.wanderX, gz.stunUntil = gz.homeX, gz.homeZ, nil, nil, nil
		gz.state, gz.stateAt = "Rising", os.clock()
	end
	Story.showAll("AuroraBoss", Story.explain("AuroraBoss", a.Name, chestCount(Formulas.auroraChests())))
end

-- dawn: the buff the boss left (if it went down), for the whole day; nightfall ends it
local function dayBuff(night)
	if night then
		ReplicatedStorage:SetAttribute("DayBuff", nil)
		ReplicatedStorage:SetAttribute("DayBuffEndsAt", nil)
		return
	end
	local id = pendingBuff
	pendingBuff = nil
	if not id then
		return
	end
	local buff = Config.DayBuffs[id]
	ReplicatedStorage:SetAttribute("DayBuff", id)
	ReplicatedStorage:SetAttribute("DayBuffEndsAt", Workspace:GetServerTimeNow() + Config.DayNight.DaySeconds)
	task.delay(BUFF_BANNER_DELAY, function()
		if ReplicatedStorage:GetAttribute("DayBuff") == id then
			Net.pushAll("Banner", string.format(BUFF_BANNER, pendingIcon, buff.Name, math.floor((buff.Multiplier - 1) * 100 + 0.5),
				math.floor(Config.DayNight.DaySeconds / 60 + 0.5)), "Day")
		end
	end)
end

-- (2026-10-04) a reward with another's added (both { Keys, KeyHours, MoneyChests, SpecialKeys })
local function addReward(a, b)
	local out = { SpecialKeys = {} }
	for _, r in ipairs({ a, b }) do
		for k, v in pairs(r) do
			if k == "SpecialKeys" then
				for id, n in pairs(v) do
					out.SpecialKeys[id] = (out.SpecialKeys[id] or 0) + n
				end
			else
				out[k] = (out[k] or 0) + v
			end
		end
	end
	return out
end

-- the player's hunts for the screens: BossHunts (ever), HuntTitle (the title's name, nil before the first)
local function showHunt(player, profile)
	local h = profile and profile.BossHunt
	if h then
		local title = Formulas.huntTitle(h.Hunts)
		player:SetAttribute("BossHunts", h.Hunts)
		player:SetAttribute("HuntTitle", title and title.Name or nil)
	end
end

-- (2026-10-04, the night boss's ②③) a boss this player helped down: a hunt (this week's 🏆 ranking, the titles) and
-- the 🦴 bones ({ [boss kind Id] = n }); full bones become that kind's zombie dino. The lines for their notice
local function hunt(player, bones)
	if TutorialField.isField() or not PlayerData.isLoaded(player) then
		return {}
	end
	local bc = Config.Zombies.Boss
	local before = PlayerData.get(player).BossHunt.Hunts
	local full, made = {}, {}
	PlayerData.update(player, function(p)
		full = RewardLogic.bossHunt(p, RewardLogic.weekNumber(os.time()), bones)
		for _, kindId in ipairs(full) do
			table.insert(made, RewardLogic.addBoneDino(p, kindId))
		end
	end)
	local profile = PlayerData.get(player)
	local h = profile.BossHunt
	Leaderboards.rankedWin(player, "Boss")
	local lines = {}
	for _, kind in ipairs(bc.Kinds) do
		local n = bones[kind.Id] or 0
		local dino = Formulas.boneDino(kind.Id)
		if n > 0 and dino and not table.find(full, kind.Id) then
			table.insert(lines, string.format(HUNT_BONES, dino.Name, n, h.Bones[kind.Id] or 0, bc.BonesForDino))
		end
	end
	for _, unit in ipairs(made) do
		local name = Formulas.species(unit.Species).Name
		table.insert(lines, string.format(HUNT_DINO, bc.BonesForDino, name))
		Net.push(player, "Banner", string.format(HUNT_DINO_BANNER, bc.BonesForDino, name), "Boss")
		Net.pushAll("Notice", "🧟 " .. name, string.format(HUNT_DINO_ALL, player.DisplayName, name))
	end
	table.insert(lines, string.format(HUNT_COUNT, profile.Ranked.Boss, h.Hunts))
	local title, old = Formulas.huntTitle(h.Hunts), Formulas.huntTitle(before)
	if title and title ~= old then
		table.insert(lines, string.format(HUNT_TITLE_NEW, title.Name))
		Net.pushAll("Notice", title.Name, string.format(HUNT_TITLE_ALL, player.DisplayName, title.Name, h.Hunts))
	end
	showHunt(player, profile)
	return lines
end

local function bossDown(b, killerRoot)
	local bc = Config.Zombies.Boss
	ZombieLogic.defeat(b.z, os.clock())
	b.conf:SetAttribute("DefeatedAt", Workspace:GetServerTimeNow())
	local y = killerRoot.Position.Y - BOSS_CHEST_DROP
	-- (2026-10-04) each hitter's reward by the players on the server now
	local players = #Players:GetPlayers()
	local share = Formulas.bossRewardShare(players)
	if b == auroraBoss then
		b.chests = Formulas.auroraChests()
	else
		b.chests = { [b.chestKind or "Money"] = Formulas.bossChests() }
	end
	local total, k = chestCount(b.chests), 0
	local spread = b.scale / BOSS_BASE_SCALE
	for chestKind, count in pairs(b.chests) do
		for _ = 1, count do
			k += 1
			local a = k * 2 * math.pi / total + rng:NextNumber(-0.2, 0.2)
			local r = rng:NextNumber(bc.ChestSpread[1], bc.ChestSpread[2]) * math.max(1, spread)
			Treasure.spawnNow(Vector3.new(b.z.x + math.cos(a) * r, y, b.z.z + math.sin(a) * r), chestKind, true)
		end
	end
	b.special = nil
	if b == auroraBoss then -- its guards go down with it
		local list = {}
		for _, g in ipairs(guards) do
			table.insert(list, g.z)
		end
		ZombieLogic.setNight(list, false, os.clock(), random)
	end
	if b.buff then
		pendingBuff, pendingIcon = b.buff, b.icon
		local buff = Config.DayBuffs[b.buff]
		local chestKind = next(b.chests)
		Story.showAll("NightBossDown", Story.explain("NightBossDown", CHEST_NAMES[chestKind] or "상자", total,
			buff.Name, math.floor((buff.Multiplier - 1) * 100 + 0.5)))
	else
		Story.showAll("AuroraBossDown", Story.explain("AuroraBossDown", total))
	end
	-- the aurora boss: the ones who hit it hardest (Config.Zombies.AuroraBoss.MvpCount) get MvpReward too
	local ranked = {}
	for player, h in pairs(b.hitters) do
		if player.Parent then
			table.insert(ranked, { player = player, h = type(h) == "table" and h or { damage = 0, money = 0 } })
		end
	end
	table.sort(ranked, function(x, y)
		return x.h.damage > y.h.damage
	end)
	local aurora = b == auroraBoss and Config.Zombies.AuroraBoss or nil
	-- (2026-10-04) the bones each hitter gets: the night boss's kind (the MVP more), the aurora boss's every kind
	local function bonesFor(mvp)
		local bones = {}
		if aurora then
			for _, kind in ipairs(bc.Kinds) do
				bones[kind.Id] = bc.AuroraBones
			end
		elseif b.kindId then
			bones[b.kindId] = bc.Bones + (mvp and bc.BonesMvp or 0)
		end
		return bones
	end
	for rank, entry in ipairs(ranked) do
		local player = entry.player
		Rewards.add(player, "Boss", 1) -- daily missions
		if aurora then
			if b.reward then
				Rewards.grant(player, Formulas.scaleReward(b.reward, share), b.icon .. " " .. b.name)
			end
			local mvp = rank <= aurora.MvpCount and #ranked >= bc.MvpMinHitters
			if mvp then
				Rewards.grant(player, aurora.MvpReward, string.format("%s %d등 상", b.icon, rank))
			end
			local lines = hunt(player, bonesFor(false))
			table.insert(lines, 1, string.format(AURORA_SUMMARY, rank, #ranked, Formulas.shortNumber(entry.h.money), mvp and AURORA_MVP or ""))
			Net.push(player, "Notice", b.icon .. " " .. b.name, table.concat(lines, "\n"))
		else
			-- (2026-10-04) the night boss: its reward (the MVP's added) and the hunt, one notice
			local mvp = rank == 1 and #ranked >= bc.MvpMinHitters
			local lines = hunt(player, bonesFor(mvp))
			if mvp then
				table.insert(lines, 1, HUNT_MVP)
			end
			local reward = Formulas.scaleReward(b.reward or bc.HitterReward, share)
			Rewards.grant(player, mvp and addReward(reward, bc.MvpReward) or reward,
				string.format(HUNT_TITLE, b.icon, b.name), table.concat(lines, "\n"))
		end
	end
	b.hitters = {}
end

-- Combat.onSlap: a slap reaching a boss's big body hits it (every boss in reach; 2026-10-01, was
-- the nearest); adds where each was hit to spots
local function slapBosses(player, root, reach, level, spots)
	local bc = Config.Zombies.Boss
	local look = root.CFrame.LookVector
	local flatLook = Vector3.new(look.X, 0, look.Z)
	for _, b in ipairs(bosses) do
		if b.z.state == "Up" and b.hp > 0 then
			local offset = Vector3.new(b.z.x - root.Position.X, 0, b.z.z - root.Position.Z)
			local d = offset.Magnitude
			local body = bc.BodyRadius * b.scale / BOSS_BASE_SCALE
			local inFront = d <= body or flatLook.Magnitude < 0.01 or offset.Unit:Dot(flatLook.Unit) >= Config.Slap.FrontDot
			if d <= reach + body and inFront then
				local damage = math.min(b.hp, Formulas.bossSlapDamage(level) * (typeof(root) == "table" and root.BossMultiplier or 1))
				b.hp -= damage
				-- (2026-10-01) the damage pays the hitter at once, shown over the boss (Net push BossHitMoney)
				local profile = PlayerData.get(player)
				local got = 0
				if profile then
					local before = profile.Money
					local times = b == auroraBoss and Config.Zombies.AuroraBoss.MoneyPerDamageMultiplier or 1
					PlayerData.addMoney(player, Formulas.bossHitMoney(profile.DefenseLevel, damage, times), "treasure")
					got = (PlayerData.get(player) or profile).Money - before
					if got > 0 then
						Net.push(player, "BossHitMoney", got, Vector3.new(b.z.x, root.Position.Y, b.z.z))
					end
				end
				-- what each hitter did to it and got for it (the aurora boss's ranking and summary)
				local h = b.hitters[player] or { damage = 0, money = 0 }
				h.damage += damage
				h.money += math.max(got, 0)
				b.hitters[player] = h
				Rewards.add(player, "BossHit", 1) -- (2026-10-03: the tutorial field's boss step)
				if typeof(root) == "table" and root.Bomb then
					Rewards.add(player, "BossBomb", 1)
				end
				b.conf:SetAttribute("BossHP", b.hp)
				b.conf:SetAttribute("BossHitAt", Workspace:GetServerTimeNow())
				if Combat.hittable(player) then
					b.z.target = player.UserId -- it turns on whoever slapped it
				end
				if b.hp <= 0 then
					bossDown(b, root)
				end
				local toward = d > 0.1 and offset.Unit or flatLook
				table.insert(spots, root.Position + toward * math.max(0, d - body * 0.6) + Vector3.new(0, 2, 0))
			end
		end
	end
end

-- a boss's big attack (see the top), every tick: starts one when someone is in reach, carries it out
local function bossAttack(b, now, list)
	local bc = Config.Zombies.Boss
	local z = b.z
	if z.state ~= "Up" or b.hp <= 0 then
		b.special = nil
		return
	end
	local scale = b.scale / BOSS_BASE_SCALE
	local knockback = ZombieLogic.param(z, "Knockback")
	local reachUp = ZombieLogic.param(z, "HitHeight") * scale
	local function throwNear(x, zz, radius, once, fromAbove)
		for _, t in ipairs(list) do
			if not (once and once[t.id]) and t.player.Parent
				and Vector3.new(t.x - x, 0, t.z - zz).Magnitude <= radius
				and (fromAbove or not z.y or math.abs(t.y - z.y) <= reachUp) then -- (2026-10-01: up high is safe)
				if once then
					once[t.id] = true
				end
				Combat.throw(t.player, Vector3.new(x, t.root.Position.Y, zz), knockback)
			end
		end
	end
	local special = b.special
	if special then
		local a = bc[special.kind]
		if special.kind == "Roar" then
			z.x, z.z = special.x0, special.z0 -- rearing up where it stands
			if now >= special.at then
				throwNear(z.x, z.z, a.Radius * scale)
				b.special = nil
			end
		elseif special.kind == "Charge" then
			local k = now < special.at and 0 or math.min(1, (now - special.at) * a.Speed / special.len)
			z.x = special.x0 + special.dx * special.len * k
			z.z = special.z0 + special.dz * special.len * k
			z.heading = math.atan2(special.dx, special.dz)
			z.y = surfaceAt(z.x, z.z)
			if k > 0 then
				throwNear(z.x, z.z, a.HitRadius * scale, special.hit)
			end
			if k >= 1 then
				b.special = nil
			end
		elseif special.kind == "Bomb" and now >= special.at then
			throwNear(special.x, special.z, a.Radius * math.max(1, scale * 0.7), nil, true) -- (it falls from above)
			b.special = nil
		end
		return
	end
	if now < b.nextSpecial then
		return
	end
	local attack = attackOf(b)
	if attack == "Charge" and z.rootUntil and now < z.rootUntil then
		attack = "Roar" -- held in place by a poop bomb: it attacks where it stands
	end
	local a = bc[attack]
	local inReach = {}
	for _, t in ipairs(list) do
		if Vector3.new(t.x - z.x, 0, t.z - z.z).Magnitude <= a.Reach * scale then
			table.insert(inReach, t)
		end
	end
	if #inReach == 0 then
		return
	end
	b.turn += 1
	local nextAttack = bc[attackOf(b)]
	b.nextSpecial = now + nextAttack.Every * b.everyMul
	local pick = inReach[rng:NextInteger(1, #inReach)]
	local name = b.conf.Name
	if attack == "Roar" then
		b.special = { kind = "Roar", at = now + a.WindUp, x0 = z.x, z0 = z.z }
		Net.pushAll("BossFx", "Roar", z.x, z.z, a.Radius * scale, a.WindUp, name)
	elseif attack == "Charge" then
		local d = Vector3.new(pick.x - z.x, 0, pick.z - z.z)
		d = d.Magnitude > 0.1 and d.Unit or Vector3.new(math.sin(z.heading), 0, math.cos(z.heading))
		local len = a.Distance * scale
		local limit = Config.Battlefield.Radius - Config.Zombies.EdgeMargin
		while len > 1 and Vector3.new(z.x + d.X * len, 0, z.z + d.Z * len).Magnitude > limit do
			len -= 2 -- never out past the flags
		end
		-- (2026-10-01) nor through a tree or rock: it stops short of the first one on the way
		local climb = ZombieLogic.param(z, "StepHeight")
		local clear, y = 0, z.y or groundAt(z.x, z.z)
		while clear + CHARGE_PROBE <= len do
			local top = surfaceAt(z.x + d.X * (clear + CHARGE_PROBE), z.z + d.Z * (clear + CHARGE_PROBE))
			if top - y > climb then
				break
			end
			clear, y = clear + CHARGE_PROBE, top
		end
		len = clear
		b.special = { kind = "Charge", at = now + a.WindUp, x0 = z.x, z0 = z.z, dx = d.X, dz = d.Z,
			len = math.max(len, 1), hit = {} }
		z.heading = math.atan2(d.X, d.Z)
		Net.pushAll("BossFx", "Charge", z.x, z.z, z.x + d.X * b.special.len, z.z + d.Z * b.special.len, name)
	else
		local radius = a.Radius * math.max(1, scale * 0.7)
		b.special = { kind = "Bomb", at = now + a.FallSeconds, x = pick.x, z = pick.z }
		Net.pushAll("BossFx", "Bomb", pick.x, pick.z, radius, a.FallSeconds, name)
	end
end

-- Studio tests (TestCommands ;boss): the boss climbs out at `at` now, with hp health (full if nil); kindId
-- picks the kind ("Rex", "Trike", "Ptera"), else tonight's
function Zombies.testBoss(at, hp, kindId)
	if not DayNight.isNight() then
		DayNight.set(true) -- nightfall: a new boss night
	end
	local b = nightBoss
	if kindId then
		setNightKind(b, Formulas.bossKind(kindId), Formulas.bossStage(#Players:GetPlayers()))
	end
	b.special, b.nextSpecial = nil, os.clock() + Config.Zombies.Boss[attackOf(b)].Every
	local z = b.z
	z.homeX, z.homeZ = at.X, at.Z
	z.x, z.z, z.target, z.wanderX = at.X, at.Z, nil, nil
	z.state, z.stateAt = "Rising", os.clock()
	if hp then -- (2026-10-03, "왜 아직도 튜토보스 체력이 50이야") a practice boss: its whole bar is that small
		b.maxHp, b.hitters, b.practice = math.min(hp, b.maxHp), {}, true -- (kept so: not by the players, below)
		b.conf:SetAttribute("BossMaxHP", b.maxHp)
	end
	b.hp = math.min(hp or b.maxHp, b.maxHp)
	b.conf:SetAttribute("BossHP", b.hp)
end

-- (2026-10-04) a player came or went: every boss still standing gets the health for the players on the server now,
-- with the same share of it left (a practice boss keeps its own)
local function fitBossHealth(leaving)
	local players = #Players:GetPlayers()
	if leaving and leaving.Parent == Players then
		players -= 1 -- (not gone from the list yet)
	end
	local power = serverPower(leaving)
	for _, b in ipairs(bosses) do
		if b.hp > 0 and b.maxHp > 0 and not b.practice then
			local max = b == auroraBoss and Formulas.auroraBossHealth(players, power) or Formulas.bossHealth(players, power)
			if max ~= b.maxHp then
				b.hp = b.hp * max / b.maxHp
				b.maxHp = max
				b.conf:SetAttribute("BossMaxHP", b.maxHp)
				b.conf:SetAttribute("BossHP", b.hp)
			end
		end
	end
end

-- Studio tests (TestCommands ;bones): a hunt with these bones ({ [boss kind Id] = n }) and its notice
function Zombies.testHunt(player, bones)
	Net.push(player, "Notice", "🧟 보스 사냥 (테스트)", table.concat(hunt(player, bones), "\n"))
end

-- the night boss's full health now (0 when there is none up)
function Zombies.bossMaxHp()
	return Zombies.bossAt() and nightBoss.maxHp or 0
end

-- (2026-10-03, the tutorial field) where the night boss stands (nil when it is not up), and the zombie nearest
-- to `at` that is up (nil when none)
function Zombies.bossAt()
	local b = nightBoss
	if b and b.hp > 0 and (b.z.state == "Up" or b.z.state == "Rising") then
		return Vector3.new(b.z.x, 0, b.z.z)
	end
	return nil
end

function Zombies.nearest(at)
	local best, bestD = nil, math.huge
	for _, z in ipairs(zombies) do
		if not z.thief and not z.guardian and (z.state == "Up" or z.state == "Rising") then
			local d = (Vector3.new(z.x, 0, z.z) - Vector3.new(at.X, 0, at.Z)).Magnitude
			if d < bestD then
				best, bestD = Vector3.new(z.x, 0, z.z), d
			end
		end
	end
	return best
end

-- Studio tests (TestCommands ;aurora): night, the aurora, and its boss climbing out at `at`
function Zombies.testAurora(at)
	if not DayNight.isNight() then
		DayNight.set(true)
	end
	auroraRise(at)
end

-- Combat.protect (2026-10-01): a player close enough to slap a boss (its body + their own slap reach)
-- can't be slapped by other players, so a crowd hitting a boss doesn't throw each other away
local function nearBoss(position, reach)
	local bc = Config.Zombies.Boss
	for _, b in ipairs(bosses) do
		if b.z.state == "Up" and b.hp > 0 then
			local body = bc.BodyRadius * b.scale / BOSS_BASE_SCALE
			if Vector3.new(b.z.x - position.X, 0, b.z.z - position.Z).Magnitude <= body + reach then
				return true
			end
		end
	end
	return false
end

-- Combat.onSlap: the bosses take damage; every other zombie in reach is thrown (2026-10-01, was the
-- nearest one, and only when no boss was hit). Returns where each was hit
local guardians = {}
local raptors = {}
local unstick
local GUARD_FIRST_SPREAD = 4
local GUARD_CAUGHT = "🛡️ 제단 지킴이!"
local GUARD_CAUGHT_TEXT = "잡혔어요! 상자 %d개가 제단으로 돌아갔어요"
local GUARD_SLAPPED = "🛡️ 지킴이를 찰싹! 잠깐 어지러워해요"
local GUARD_SLAP_GAP = 6
local SUPER_SPAWN_TRIES = 12
local SUPER_COMING = "⚡ 슈퍼 도둑 등장! 잡으면 %s!"
local SUPER_CAUGHT = "⚡ %s님이 슈퍼 도둑을 잡았어요! %s 획득!"
local superEntry = nil
local superNextAt = math.huge
local superParams = nil
local superSpeed = 0
local superDashUntil, superDashReady = 0, 0
local guardSlapSaid = {}

local function showLoot(t)
	local n = 0
	for _, k in pairs(t.loot) do
		n += k
	end
	shown[t.index]:SetAttribute("Loot", n)
	local special = {}
	for kind, k in pairs(t.loot) do
		if kind ~= "Normal" and k > 0 then
			table.insert(special, kind .. ":" .. k)
		end
	end
	table.sort(special)
	shown[t.index]:SetAttribute("LootSpecial", #special > 0 and table.concat(special, ",") or nil)
end

local function makeRaptor(name, params, super)
	local z = ZombieLogic.new({ { x = 0, z = 0 } })[1]
	z.params = params
	if super then
		z.thief = true
	else
		z.guardian = true
	end
	table.insert(zombies, z)
	local conf = Instance.new("Configuration")
	conf.Name = name
	conf:SetAttribute("Species", "WildRaptor")
	conf:SetAttribute("Thief", true)
	conf:SetAttribute("Super", super or nil)
	conf:SetAttribute("Guardian", not super or nil)
	conf:SetAttribute("Loot", 0)
	conf:SetAttribute("P", Vector3.new(z.x, 0, z.z))
	conf:SetAttribute("H", 0)
	conf:SetAttribute("State", z.state)
	conf:SetAttribute("StateAt", 0)
	conf.Parent = folder
	shown[#zombies] = conf
	lastSent[#zombies] = { x = z.x, z = z.z, h = 0, state = z.state }
	local t = { z = z, index = #zombies, loot = {}, trail = {}, nextAt = os.clock() + rng:NextNumber(0, GUARD_FIRST_SPREAD),
		wasUp = false, super = super }
	z.thiefEntry = t
	table.insert(raptors, t)
	if not super then
		table.insert(guardians, t)
	end
	return t
end

local function guardianOut(t, now)
	local G = Config.Zombies.Guardians
	local z = t.z
	local a, r = rng:NextNumber(0, 2 * math.pi), rng:NextNumber(G.PostRing[1], G.PostRing[2])
	z.homeX, z.homeZ = clearSpot(math.cos(a) * r, math.sin(a) * r)
	z.x, z.z, z.y, z.path, z.blocked = z.homeX, z.homeZ, nil, nil, false
	z.target, z.wanderX, z.moving = nil, nil, false
	z.state, z.stateAt, z.wakeAt = "Waiting", now, now
	z.stunUntil, z.nextHit, z.reactUntil = nil, 0, nil
	t.trail = {}
	shown[t.index]:SetAttribute("ChaseUserId", nil)
end

local function manageGuardians(now, list)
	local G = Config.Zombies.Guardians
	local want = Formulas.guardianCount(#Players:GetPlayers(), TutorialField.isField())
	while #guardians < want do
		makeRaptor("Guardian" .. (#guardians + 1), G, false)
	end
	if #Players:GetPlayers() == 0 then
		want = 0
	end
	local active = 0
	for _, t in ipairs(guardians) do
		if t.z.state ~= "Under" and t.z.state ~= "Sinking" then
			active += 1
		end
	end
	for _, t in ipairs(guardians) do
		local z = t.z
		if z.state == "Under" and active < want and now >= t.nextAt then
			active += 1
			guardianOut(t, now)
		elseif z.state ~= "Under" and z.state ~= "Sinking" and active > want then
			active -= 1
			ZombieLogic.defeat(z, now)
			t.nextAt = now + GUARD_FIRST_SPREAD
		end
		local chase = z.state == "Up" and z.target or nil
		if shown[t.index]:GetAttribute("ChaseUserId") ~= chase then
			shown[t.index]:SetAttribute("ChaseUserId", chase)
		end
	end
end

local function superOut(now, list)
	local S = Config.Zombies.SuperThief
	local t, z = superEntry, superEntry.z
	local outer = Config.Battlefield.Radius - Config.Zombies.EdgeMargin
	local x, zz = 0, 0
	for _ = 1, SUPER_SPAWN_TRIES do
		local a, r = rng:NextNumber(0, 2 * math.pi), math.sqrt(rng:NextNumber(0.1, 1)) * outer
		x, zz = clearSpot(math.cos(a) * r, math.sin(a) * r)
		local far = true
		for _, p in ipairs(list) do
			if (Vector3.new(p.x, 0, p.z) - Vector3.new(x, 0, zz)).Magnitude < S.SpawnAwayFrom then
				far = false
				break
			end
		end
		if far then
			break
		end
	end
	z.homeX, z.homeZ = x, zz
	z.x, z.z, z.y, z.path, z.blocked = x, zz, nil, nil, false
	z.target, z.wanderX, z.moving = nil, nil, false
	z.state, z.stateAt, z.wakeAt = "Waiting", now, now
	z.escaped, z.stunUntil, z.nextHit = nil, nil, 0
	z.escapeUntil = now + S.Params.RiseSeconds + S.LifeSeconds
	t.trail = {}
	local pick = Formulas.pickWeighted(S.Keys, "Weight", rng:NextNumber())
	local grade = pick.Grade
	superSpeed = pick.Speed
	t.loot = { [grade] = 1 }
	showLoot(t)
	shown[t.index]:SetAttribute("EscapeAt", Workspace:GetServerTimeNow() + S.Params.RiseSeconds + S.LifeSeconds)
	Net.pushAll("Banner", string.format(SUPER_COMING, Formulas.keyType(grade).Name), "Gold")
end

local function manageSuper(now, list)
	if not superEntry then
		return
	end
	local S = Config.Zombies.SuperThief
	local weather = Formulas.weather(ReplicatedStorage:GetAttribute("Weather")).MoveSpeedMultiplier or 1
	local t, z = superEntry, superEntry.z
	if z.state == "Up" and now >= superDashReady then
		for _, p in ipairs(list) do
			if Vector3.new(p.x - z.x, 0, p.z - z.z).Magnitude <= S.Dash.Range then
				superDashUntil = now + S.Dash.Seconds
				superDashReady = superDashUntil + S.Dash.Cooldown
				shown[t.index]:SetAttribute("DashAt", Workspace:GetServerTimeNow())
				break
			end
		end
	end
	local chase = 0
	for _, p in ipairs(list) do
		local humanoid = p.root.Parent and p.root.Parent:FindFirstChildOfClass("Humanoid")
		if humanoid and Vector3.new(p.x - z.x, 0, p.z - z.z).Magnitude <= S.ChaseRange then
			chase = math.max(chase, humanoid.WalkSpeed / weather)
		end
	end
	local chaseBy = math.max(1, chase / S.ChaseFrom) ^ S.ChasePower
	superParams.FleeSpeed = superSpeed * chaseBy * (now < superDashUntil and S.Dash.Multiplier or 1)
	if z.state ~= "Under" then
		t.wasUp = true
		return
	end
	if t.wasUp then
		t.wasUp = false
		t.loot = {}
		showLoot(t)
		z.escapeUntil, z.escaped = nil, nil
		shown[t.index]:SetAttribute("EscapeAt", nil)
		superNextAt = now + rng:NextNumber(S.EverySeconds[1], S.EverySeconds[2])
	end
	if superNextAt == math.huge then
		superNextAt = now + S.FirstSeconds
	end
	if now >= superNextAt and #list > 0 and not TutorialField.isField() then
		superNextAt = math.huge
		superOut(now, list)
	end
end

local function superCaught(player, i, now)
	local t = superEntry
	local grade = next(t.loot)
	if grade then
		PlayerData.update(player, function(p)
			Formulas.addSavedKeys(p, grade, 1)
		end)
		Net.pushAll("Banner", string.format(SUPER_CAUGHT, player.DisplayName, Formulas.keyType(grade).Name), grade)
		Rewards.add(player, "SuperThief", 1)
	end
	t.loot = {}
	showLoot(t)
	shown[i]:SetAttribute("CaughtAt", Workspace:GetServerTimeNow())
	shown[i]:SetAttribute("EscapeAt", nil)
	ZombieLogic.defeat(t.z, now)
end

local UNSTICK_TRIES = 8
unstick = function(z)
	local c = Config.Zombies
	local outer, inner = Config.Battlefield.Radius - ZombieLogic.param(z, "EdgeMargin"), ZombieLogic.param(z, "PlazaRadius")
	local distanceOff = (z.guardian and c.Guardians or c.SuperThief).UnstickDistance
	local first = z.way or rng:NextNumber(0, 2 * math.pi)
	for k = 0, UNSTICK_TRIES - 1 do
		local a = first + k * 2 * math.pi / UNSTICK_TRIES
		local nx, nz = clearSpot(z.x + math.sin(a) * distanceOff, z.z + math.cos(a) * distanceOff)
		local r = math.sqrt(nx * nx + nz * nz)
		if r <= outer and r >= inner then
			z.x, z.z, z.y = nx, nz, surfaceAt(nx, nz)
			break
		end
	end
	z.way, z.wanderX, z.path, z.blocked = nil, nil, nil, false
	z.stuckFor, z.stuckX, z.stuckZ = 0, z.x, z.z
end

local function guardianCatch(z, player)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local hint = Keys.escapeText(player)
	local n = Keys.returnBoxes(player, Vector3.new(z.x, root and root.Position.Y or 0, z.z))
	if n > 0 then
		Net.push(player, "Notice", GUARD_CAUGHT, string.format(GUARD_CAUGHT_TEXT, n))
		if hint then
			Net.push(player, "Notice", GUARD_CAUGHT, hint)
		end
	end
end

local function slapZombie(player, root, reach, level)
	local spots = {}
	-- (2026-10-04, "술래잡기때 당사자들 보스몹 못치게해") someone in a hide-and-seek game doesn't hit the bosses (their
	-- bombs already don't go off: Bombs)
	if not player:GetAttribute("HideSeekRoom") then
		slapBosses(player, root, reach, level, spots)
	end
	local c = Config.Zombies
	local now = os.clock()
	local serverNow = Workspace:GetServerTimeNow()
	local look = root.CFrame.LookVector
	local flatLook = Vector3.new(look.X, 0, look.Z)
	for i, z in ipairs(zombies) do
		if (not z.params or z.thief or z.guardian) and z.state == "Up" and not (z.stunUntil and now < z.stunUntil) then
			local offset = Vector3.new(z.x - root.Position.X, 0, z.z - root.Position.Z)
			if z.thief or z.guardian then
				local since = z.thiefEntry.super and now - (player:GetNetworkPing() / 2 + c.SuperThief.RewindSeconds) or -math.huge
				for _, spot in ipairs(z.thiefEntry.trail) do
					local back = Vector3.new(spot[2] - root.Position.X, 0, spot[3] - root.Position.Z)
					if back.Magnitude < offset.Magnitude and spot[1] >= since then
						offset = back
					end
				end
			end
			local d = offset.Magnitude
			local slack = z.thiefEntry and z.thiefEntry.super and c.SuperThief.HitSlack or 0
			local inFront = d <= c.BodyRadius + slack or flatLook.Magnitude < 0.01
				or offset.Unit:Dot(flatLook.Unit) >= Config.Slap.FrontDot
			if d <= reach + c.BodyRadius + slack and inFront then
				local from = Vector3.new(z.x, root.Position.Y, z.z)
				local away = d < 0.1 and flatLook or offset
				if z.thiefEntry and z.thiefEntry.super then
					if not (typeof(root) == "table" and root.Bomb) then
						superCaught(player, i, now)
						table.insert(spots, from + Vector3.new(0, 2, 0))
					end
					continue
				end
				if z.guardian and not (typeof(root) == "table" and root.Bomb)
					and os.clock() - (guardSlapSaid[player] or -math.huge) >= GUARD_SLAP_GAP then
					guardSlapSaid[player] = os.clock()
					Net.push(player, "Notice", GUARD_CAUGHT, GUARD_SLAPPED)
				end
				ZombieLogic.knock(z, away.X, away.Z, now)
				if not z.guardian then
					Rewards.add(player, "ZombieSlap", 1) -- daily missions
				end
				local conf = shown[i] -- where it lands first, then the throw (the clients fly it there)
				if z.guardian then
					conf:SetAttribute("PT", serverNow)
				end
				conf:SetAttribute("P", Vector3.new(z.x, z.y or 0, z.z))
				lastSent[i].x, lastSent[i].z = z.x, z.z
				conf:SetAttribute("StunUntil", serverNow + ZombieLogic.param(z, "SlapFlightSeconds") + ZombieLogic.param(z, "SlapStunSeconds"))
				conf:SetAttribute("KnockAt", serverNow)
				table.insert(spots, from + Vector3.new(0, 2, 0))
			end
		end
	end
	return spots
end

-- a storm bolt (Lightning service, 2026-10-02): every zombie up within radius of `at` (not the bosses) is
-- thrown away from it like a slap and lies dizzy; the clients fly it and it cries out (KnockAt)
function Zombies.lightning(at, radius)
	local c = Config.Zombies
	local now = os.clock()
	local serverNow = Workspace:GetServerTimeNow()
	for i, z in ipairs(zombies) do
		if not z.params and z.state == "Up" and not (z.stunUntil and now < z.stunUntil) then
			local away = Vector3.new(z.x - at.X, 0, z.z - at.Z)
			if away.Magnitude <= radius + c.BodyRadius then
				if away.Magnitude < 0.1 then
					away = Vector3.xAxis
				end
				ZombieLogic.knock(z, away.X, away.Z, now)
				local conf = shown[i]
				conf:SetAttribute("P", Vector3.new(z.x, z.y or 0, z.z))
				lastSent[i].x, lastSent[i].z = z.x, z.z
				conf:SetAttribute("StunUntil", serverNow + c.SlapFlightSeconds + c.SlapStunSeconds)
				conf:SetAttribute("KnockAt", serverNow)
			end
		end
	end
end

-- a poop bomb (Bombs service): every zombie and boss within reach of `at` (and its body) can't move
-- for seconds, but still hits whoever comes close (ZombieLogic.step). Returns where each was held
function Zombies.root(at, reach, seconds)
	local spots = {}
	local boss = false
	local now = os.clock()
	local c = Config.Zombies
	for i, z in ipairs(zombies) do
		if z.state == "Up" then
			local body, isBoss = c.BodyRadius, false
			for _, b in ipairs(bosses) do
				if b.z == z then
					body, isBoss = c.Boss.BodyRadius * b.scale / BOSS_BASE_SCALE, true
				end
			end
			if Vector3.new(z.x - at.X, 0, z.z - at.Z).Magnitude <= reach + body and not (z.thiefEntry and z.thiefEntry.super) then
				boss = boss or isBoss
				z.rootUntil = now + seconds
				z.wanderX = nil
				-- (2026-10-02) the clients bury it in a poop pile until then, like a player (Zombies.client)
				shown[i]:SetAttribute("PoopUntil", Workspace:GetServerTimeNow() + seconds)
				table.insert(spots, Vector3.new(z.x, at.Y + 2, z.z))
			end
		end
	end
	return spots, boss
end

-- night falls: everyone climbs out but the aurora boss (it waits for the aurora); day: all go down
local function setNight(night)
	local list = zombies
	if night then
		list = {}
		for _, z in ipairs(zombies) do
			if z ~= auroraBoss.z and not z.guard then -- (they come with the aurora boss)
				table.insert(list, z)
			end
		end
	end
	ZombieLogic.setNight(list, night, os.clock(), random)
end

function Zombies.testSuperThief(at)
	if not superEntry then
		return false
	end
	if superEntry.z.state ~= "Under" then
		superEntry.loot = {}
		showLoot(superEntry)
		superEntry.z.state, superEntry.z.stateAt = "Under", os.clock()
		superEntry.wasUp = false
	end
	superOut(os.clock(), {})
	local z = superEntry.z
	z.homeX, z.homeZ = clearSpot(at.X, at.Z)
	z.x, z.z = z.homeX, z.homeZ
	return true
end

function Zombies.testThief(at)
	local pick = guardians[1]
	for _, t in ipairs(guardians) do
		if t.z.state == "Under" then
			pick = t
			break
		end
	end
	if not pick then
		return
	end
	guardianOut(pick, os.clock())
	local z = pick.z
	z.homeX, z.homeZ = clearSpot(at.X, at.Z)
	z.x, z.z = z.homeX, z.homeZ
end

function Zombies.init()
	local c = Config.Zombies
	local inner = c.PlazaRadius + c.HomeRadius -- wandering around home stays out of the middle
	local outer = Config.Battlefield.Radius - c.EdgeMargin
	local homes = ZombieLogic.homes(c.Count, inner, outer, rng:NextNumber(0, 2 * math.pi))
	for _, h in ipairs(homes) do
		h.x, h.z = clearSpot(h.x, h.z) -- (not in a tree or rock)
	end
	zombies = ZombieLogic.new(homes)
	folder = Workspace:FindFirstChild("Zombies") or Instance.new("Folder")
	folder.Name = "Zombies"
	folder:ClearAllChildren()
	for i, z in ipairs(zombies) do
		local conf = Instance.new("Configuration")
		conf.Name = "Zombie" .. i
		conf:SetAttribute("Species", c.Species[(i - 1) % #c.Species + 1])
		conf:SetAttribute("P", Vector3.new(z.x, 0, z.z))
		conf:SetAttribute("H", 0)
		conf:SetAttribute("State", z.state)
		conf:SetAttribute("StateAt", 0)
		conf.Parent = folder
		shown[i] = conf
		lastSent[i] = { x = z.x, z = z.z, h = 0, state = z.state }
	end
	-- the bosses: two more, with their own numbers (the aurora boss: its own over the boss's)
	nightBoss = makeBoss("Boss", c.Boss)
	auroraBoss = makeBoss("AuroraBoss", setmetatable({}, { __index = function(_, key)
		local own = c.AuroraBoss[key]
		if own ~= nil and type(own) ~= "table" then
			return own
		end
		return c.Boss[key]
	end }))
	-- the aurora boss's guards: ordinary zombies that stay under until it climbs out
	for k = 1, c.AuroraBoss.Guards do
		local z = ZombieLogic.new({ { x = 0, z = 0 } })[1]
		z.guard, z.homeRadius = true, c.AuroraBoss.GuardHomeRadius
		table.insert(zombies, z)
		local conf = Instance.new("Configuration")
		conf.Name = "AuroraGuard" .. k
		conf:SetAttribute("Species", c.Species[(k - 1) % #c.Species + 1])
		conf:SetAttribute("P", Vector3.new(z.x, 0, z.z))
		conf:SetAttribute("H", 0)
		conf:SetAttribute("State", z.state)
		conf:SetAttribute("StateAt", 0)
		conf.Parent = folder
		shown[#zombies] = conf
		lastSent[#zombies] = { x = z.x, z = z.z, h = 0, state = z.state }
		table.insert(guards, { z = z, angle = (k - 1) / c.AuroraBoss.Guards * 2 * math.pi })
	end
	for k = 1, math.max(c.Guardians.Pool, table.unpack(c.Guardians.Count)) do
		makeRaptor("Guardian" .. k, c.Guardians, false)
	end
	superParams = table.clone(c.SuperThief.Params)
	superEntry = makeRaptor("SuperThief", superParams, true)
	folder.Parent = Workspace
	-- (2026-10-04) the bosses' health follows the players on the server (after the one leaving is gone)
	Players.PlayerAdded:Connect(function()
		task.defer(fitBossHealth)
	end)
	Players.PlayerRemoving:Connect(function(player)
		task.defer(fitBossHealth, player)
	end)
	Combat.onSlap(slapZombie)
	Combat.protect(nearBoss)
	-- (2026-10-04) the hunts: the title over the head from the start, and the 🎮 window's 🧟 tab
	PlayerData.onLoaded(showHunt)
	Net.onAsk("GetBossHunt", {}, function(player)
		local profile = PlayerData.get(player)
		if not profile then
			return nil
		end
		local week = RewardLogic.weekNumber(os.time())
		local r = profile.Ranked
		return { Hunts = profile.BossHunt.Hunts, Week = r.Week == week and r.Boss or 0, Bones = profile.BossHunt.Bones }
	end)

	DayNight.onChange(function(night)
		if night then
			newBossNight()
		end
		dayBuff(night)
		setNight(night)
	end)
	if DayNight.isNight() then
		newBossNight()
		setNight(true)
	end
	ReplicatedStorage:GetAttributeChangedSignal("Weather"):Connect(function()
		if ReplicatedStorage:GetAttribute("Weather") == "Aurora" and DayNight.isNight() and auroraBoss.z.state == "Under" then
			auroraRise(nil)
		end
	end)

	task.spawn(function()
		while true do
			local dt = task.wait(c.TickSeconds)
			local now = os.clock()
			local started = now
			local list = targets()
			-- the guards' spots go where the aurora boss is now (they keep round it as it chases)
			local az = auroraBoss.z
			if az.state == "Up" then
				for _, g in ipairs(guards) do
					g.z.homeX = az.x + math.cos(g.angle) * c.AuroraBoss.GuardRing
					g.z.homeZ = az.z + math.sin(g.angle) * c.AuroraBoss.GuardRing
				end
			end
			manageGuardians(now, list)
			manageSuper(now, list)
			for _, z in ipairs(zombies) do
				settle(z)
			end
			planPaths(list, now)
			local hits = ZombieLogic.step(zombies, dt, list, now, random)
			for _, t in ipairs(raptors) do
				local z = t.z
				local own = t.super and c.SuperThief or c.Guardians
				if (z.stuckFor or 0) >= own.StuckSeconds then
					unstick(z)
				end
				local trail = t.trail
				table.insert(trail, { now, z.x, z.z })
				while trail[1] and now - trail[1][1] > own.SlapRewindSeconds do
					table.remove(trail, 1)
				end
			end
			for _, b in ipairs(bosses) do
				bossAttack(b, now, list)
			end
			for _, hit in ipairs(hits) do
				local z = zombies[hit[1]]
				for _, t in ipairs(list) do
					if t.id == hit[2] and t.player.Parent then
						if z.guardian then
							guardianCatch(z, t.player)
						end
						-- (the aurora boss's plain bite only shows: its big attacks are what throw)
						if ZombieLogic.param(z, "PlainHitThrows") ~= false then
							Combat.throw(t.player, Vector3.new(z.x, t.root.Position.Y, z.z), ZombieLogic.param(z, "Knockback"))
						end
						shown[hit[1]]:SetAttribute("HitUserId", t.id)
						shown[hit[1]]:SetAttribute("AttackAt", Workspace:GetServerTimeNow())
					end
				end
			end
			publish(now)
			if Zombies.meter then
				Zombies.meter("loop", "Zombies", os.clock() - started)
			end
		end
	end)
end

return Zombies
