--[[
StarterMissions: the beginner mission board after the tutorial (design 10 초보 미션). One mission at a
time (Config.StarterMissions.Missions, rules in StarterLogic, state in profile.Starter); the board is the
client's (StarterPlayerScripts/StarterMissions).

- The board is up once the tutorial is done or skipped (or on its last step, which points at it).
- Goals are read off the player every CheckEvery seconds (pickaxe tier, bag level, defense level, dinos
  placed, friends here); event missions count the Rewards.add kinds (MineSprout from Minerals,
  StealKeys from Keys) while they are up.
- Net request ClaimStarter takes a reached mission's reward; StarterPass passes an optional one by.
- Rewards: keys as other rewards (RewardLogic.apply); LuckMinutes sets profile.LuckUntil (player
  attribute Luck = Config.StarterMissions.LuckMultiplier while it lasts, LuckEndsAt for the screens;
  Gacha reads Luck); SlapLevels raise the slap upgrade for free (up to its top); GuaranteedRarity adds a
  draw to profile.GuaranteedDraws (Gacha).
- Player attributes for the client: StarterStep (index; nil when the board is not up), StarterCount,
  StarterReady; (2026-10-04) MissionTarget (Vector3) / MissionButton (text) where the mission is done (its Guide /
  Button; StarterPlayerScripts/MissionGuide draws the way).
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TeleportService = game:GetService("TeleportService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local ProfileLogic = require(script.Parent:WaitForChild("ProfileLogic"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))
local StarterLogic = require(script.Parent:WaitForChild("StarterLogic"))
local TutorialField = require(script.Parent:WaitForChild("TutorialField"))
local Practice = require(script.Parent:WaitForChild("Practice"))
local UnlockLogic = require(script.Parent:WaitForChild("UnlockLogic"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))

local StarterMissions = {}

local EVER_CAP = {}
for _, m in ipairs(Config.StarterMissions.Missions) do
	if m.Event and not m.Comeback then
		EVER_CAP[m.Event] = math.max(EVER_CAP[m.Event] or 0, m.Target or 1)
	end
end

local TITLE = "📋 초보 미션"
local RESTART_TRIES = 2
local RESTART_WAIT = 3
local RESTART_KICK_AFTER = 20
local RESTART_POLL = 0.5
local KEPT_NOTICE_AFTER = 6
local MONEY_NOTICE_GAP = 60

local function say(player, title, text)
	Net.push(player, "Notice", title, text)
end

local function count(t)
	local n = 0
	for _ in pairs(t) do
		n += 1
	end
	return n
end

local function facts(player, profile)
	local real = Formulas.trained(profile.Upgrades, profile.Training)
	return {
		PickaxeTier = profile.Upgrades.PickaxeTier,
		BagLevel = Formulas.trainShownOf("Bag", real.Bag),
		DefenseLevel = profile.DefenseLevel,
		PlacedDinos = count(profile.Placed),
		Friends = player:GetAttribute("Friends") or 0,
		SlapLevel = Formulas.trainShownOf("Slap", real.Slap), -- (2026-10-03: every part of the game a mission)
		MoveLevel = Formulas.trainShownOf("MoveSpeed", real.MoveSpeed),
		SpeedLevel = Formulas.trainShownOf("Speed", real.PickaxeSpeed),
		PowerReady = (profile.Upgrades.PickaxeTier > 1
			or Formulas.powerStepsDone(profile.Upgrades.PickaxePower, profile.Upgrades.PickaxeTier)) and 1 or 0,
		Rebirths = profile.Rebirths or 0,
		Collection = player:GetAttribute("CollectionCount") or 0, -- (the Farm service's mirror of the 도감 count)
		FarmAdd = Formulas.farmCount(profile),
		FarmSlots = profile.Upgrades.FarmSlots or 0,
		Ever = profile.Ever or {},
		Visited = profile.Starter.Visited or {},
		AtTop = profile.DefenseLevel >= Formulas.maxDefenseLevel(profile.Rebirths or 0),
	}
end

-- the board is up after the tutorial (and on its last step, "Missions", which points at it)
local function tutorialDone(player, profile)
	return profile.Tutorial.Done or player:GetAttribute("TutorialStep") == "Missions"
end

local function boardUp(player, profile)
	return not StarterLogic.finished(profile.Starter) and tutorialDone(player, profile)
end

local readyShown = {}
local stages = {}
local topShown = {}
local moneySaid = {}
local waved = {}
local homing = {}

local function atTop(profile)
	return profile.DefenseLevel >= Formulas.maxDefenseLevel(profile.Rebirths or 0)
end

local function lockOf(player, m)
	local chapter = m and Config.StarterMissions.Chapters[m.Ch or 1]
	local id = chapter and chapter.Unlock
	if id and not Unlocks.has(player, id) then
		return id
	end
	return nil
end

-- (2026-10-04, "처음 30초에 뭘 해야 할지 모름" → "추천 다 적용해봐") where the mission at hand is done (its Guide): the spot
-- for the screen's glowing line (player attribute MissionTarget; StarterPlayerScripts/MissionGuide), or its Button's
-- text (MissionButton) for a finger. Base spots are looked up once a mission; the moving ones every GUIDE_MOVING_EVERY
local GUIDE_MOVING_EVERY = 3 -- seconds
local MOVING = { Zombie = true, Boss = true, FruitTree = true, Chest = true, Pad = true, Mineral = true, PracticeTree = true,
	PracticeTrap = true, PracticeSeeker = true, AltarBox = true }
local LOCKED_BUTTON = "보스 도전"
local NEW_MAP_LEVEL = math.huge
for _, m in ipairs(Config.Defense.Maps) do
	if m.Rebirths == 0 and m.Level then
		NEW_MAP_LEVEL = math.min(NEW_MAP_LEVEL, Formulas.mapUnlockLevel(m))
	end
end
local mapSaid = {}

-- the nearest child of a Workspace folder (a model's pivot or a part's spot) that `ok` lets through
local function nearestIn(folderName, from, ok)
	local folder = Workspace:FindFirstChild(folderName)
	local best, bestD = nil, math.huge
	for _, c in ipairs(folder and folder:GetChildren() or {}) do
		if not ok or ok(c) then
			local at = c:IsA("Model") and c:GetPivot().Position or (c:IsA("BasePart") and c.Position)
			if at then
				local d = (at - from).Magnitude
				if d < bestD then
					best, bestD = at, d
				end
			end
		end
	end
	return best
end
local function damageBoardOf(player)
	local folder = require(script.Parent:WaitForChild("Bases")).folderOf(player)
	local map = Workspace:FindFirstChild("Map")
	local holder = map and map:FindFirstChild("DefenseGuides")
	local model = folder and holder and holder:FindFirstChild("DefenseGuide" .. folder.Name)
	local board = model and model:FindFirstChild("DamageBoard")
	return board and board.Position or nil
end

local guideCache = {} -- [player] = { step, name, spot, at }
local function guideSpot(player, name)
	local Bases = require(script.Parent:WaitForChild("Bases"))
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local base = name:match("^(%a+)")
	local function open(at)
		return not Unlocks.closedAt(player, at)
	end
	local function mineOrOpen(c)
		local only = c:GetAttribute("OnlyFor")
		if only ~= nil then
			return only == player.UserId
		end
		local at = c:IsA("Model") and c:GetPivot().Position or (c:IsA("BasePart") and c.Position)
		return at ~= nil and open(at)
	end
	if name == "Gate" then
		return Unlocks.gate(player)
	elseif name == "WildTree" or name == "Wild:Pocket" then
		return Unlocks.wildTree(player)
	elseif base == "Zone" then
		local u = Formulas.unlockOf(name:match(":(%a+)$") or "")
		local folder = Bases.folderOf(player)
		local zone = folder and folder:FindFirstChild("SafeZone")
		if not u or not u.Zone or not zone then
			return nil
		end
		local out = Vector3.new(zone.Position.X, 0, zone.Position.Z).Unit
		local at = out * ((u.Zone.From + u.Zone.To) / 2)
		return Vector3.new(at.X, Bases.groundBelow(Vector3.new(at.X, 30, at.Z), {}), at.Z)
	elseif base == "PracticeTreeFoot" then
		return Practice.treeFootOf(player)
	elseif base == "PracticeTree" then
		return Practice.treeOf(player)
	elseif base == "PracticeSeeker" then
		return Practice.seekerOf(player)
	elseif base == "PracticeTrap" then
		return Practice.trapOf(player)
	elseif base == "Chest" or base == "Pad" or base == "Mineral" then
		if not root then
			return nil
		end
		if base == "Chest" then
			return nearestIn("TreasureChests", root.Position, mineOrOpen)
		elseif base == "Pad" then
			return nearestIn("SpeedPads", root.Position, mineOrOpen)
		end
		-- a mineral the player's pickaxe mines (not a 🔒 one), of the grade after ":" when there is one
		local grade = name:match(":(%a+)$")
		local within = tonumber(name:match("<(%d+)$"))
		local profile = PlayerData.get(player)
		local tier = profile and profile.Upgrades.PickaxeTier or 1
		local myBase = Bases.of(player)
		return nearestIn("Minerals", root.Position, function(m)
			local g = m:GetAttribute("Grade")
			local info = g and Formulas.grade(g)
			local home = m:GetAttribute("Home")
			local at = m:GetPivot().Position
			return g ~= nil and (not grade or g == grade) and (not info or (info.MinTier or 1) <= tier) and open(at)
				and (home == nil or home == myBase) and (not within or Vector3.new(at.X, 0, at.Z).Magnitude < within)
		end)
	elseif name == "AltarBox" then
		return Practice.thiefOf(player) or (not player:GetAttribute("InTutorial")
			and Vector3.new(0, Bases.groundBelow(Vector3.new(0, 60, 0), {}), 0)) or nil
	elseif name == "DamageBoard" then
		return damageBoardOf(player)
	elseif name == "Center" then
		return Vector3.new(0, Bases.groundBelow(Vector3.new(0, 60, 0), {}), 0)
	elseif name == "FruitTree" then
		local home = player:GetAttribute("BaseCenter")
		return typeof(home) == "Vector3" and require(script.Parent:WaitForChild("Fruits")).nearestTree(home) or nil
	elseif name == "Zombie" then
		local mine = Practice.zombieOf(player)
		if mine then
			return mine
		end
		local at = root and require(script.Parent:WaitForChild("Zombies")).nearest(root.Position) or nil
		return at and open(at) and at or nil
	elseif name == "Boss" then
		local mine = Practice.bossOf(player)
		if mine then
			return mine
		end
		local at = require(script.Parent:WaitForChild("Zombies")).bossAt()
		return at and open(at) and at or nil
	end
	local folder = Bases.folderOf(player)
	local inst = folder and folder:FindFirstChild(name, true)
	return inst and Bases.position(inst) or nil
end
local function setGuide(player, key, name, button, taps, slap, tapsNear)
	local c = guideCache[player]
	local moving = name and MOVING[name:match("^(%a+)")]
	if name and (not c or c.key ~= key or c.name ~= name or ((moving or c.spot == nil) and os.clock() - c.at >= GUIDE_MOVING_EVERY)) then
		c = { key = key, name = name, spot = name ~= "Wild" and name ~= "MyDino" and guideSpot(player, name) or nil, at = os.clock() }
		guideCache[player] = c
	end
	player:SetAttribute("MissionTarget", name and c and c.spot or nil)
	player:SetAttribute("MissionGuideKind", name)
	player:SetAttribute("MissionButton", button)
	player:SetAttribute("MissionTaps", taps and table.concat(taps, ",") or nil)
	player:SetAttribute("MissionSlap", slap)
	player:SetAttribute("MissionTapsNear", tapsNear or nil)
	player:SetAttribute("MissionStep", key)
end

local function busyNow(player, m)
	return m.Busy ~= nil and player:GetAttribute(m.Busy) ~= nil
end

local function powerShort(player, mission)
	local profile = mission.PowerFirst and PlayerData.get(player)
	return profile ~= nil and not Formulas.powerStepsDone(profile.Upgrades.PickaxePower, profile.Upgrades.PickaxeTier)
end

local function visited(profile, mission)
	return not mission.VisitFirst or (profile.Starter.Visited or {})[StarterLogic.idOf(mission)] == true
end

local function tapsFor(mission, progress)
	if mission.AutoFrom and (progress or 0) >= mission.AutoFrom then
		return mission.AutoTaps
	end
	return mission.Taps
end

local function publishGuide(player, mission, step, ready, locked, top, profile, progress)
	if not mission then
		setGuide(player, nil, nil, nil)
	elseif locked then
		setGuide(player, "S" .. step, nil, LOCKED_BUTTON)
	elseif ready then
		setGuide(player, nil, nil, nil)
	elseif profile and not visited(profile, mission) then
		setGuide(player, "S" .. step .. "V", mission.VisitFirst, nil, nil)
	elseif mission.TopGuide and top then
		local short = mission.MoneyGuides and profile
			and Formulas.rebirthCost(profile.Rebirths, profile.DefenseLevel) - profile.Money or 0
		if short > 0 then
			local name = nil
			for _, n in ipairs(mission.MoneyGuides) do
				if not name and guideSpot(player, n) then
					name = n
				end
			end
			setGuide(player, "S" .. step .. "M", name or mission.TopGuide, nil, nil)
			if os.clock() - (moneySaid[player] or -math.huge) >= MONEY_NOTICE_GAP then
				moneySaid[player] = os.clock()
				say(player, TITLE, string.format("💰 환생까지 %s원 더! 📦 배틀필드 보물상자나 ⛏️ 광물로 돈을 모아요", Formulas.shortNumber(math.ceil(short))))
			end
		else
			setGuide(player, "S" .. step .. "T", mission.TopGuide, nil, tapsFor(mission, progress))
		end
	elseif powerShort(player, mission) then
		setGuide(player, "S" .. step .. "P", mission.PowerFirst, nil, nil)
	else
		setGuide(player, "S" .. step, mission.Guide, not busyNow(player, mission) and mission.Button or nil,
			tapsFor(mission, progress), not Practice.bossChestsOut(player) and mission.Slap or nil, mission.TapsNear)
	end
end

local function publishLearning(player, profile)
	local learnUp = tutorialDone(player, profile) and not TutorialField.isField()
	local quest, step, count = nil, nil, nil
	if learnUp then
		quest, step, count = UnlockLogic.current(profile.Unlocks)
	end
	local nextUp = learnUp and not quest and UnlockLogic.firstReady(profile.Unlocks, profile.DefenseLevel, profile.Passes,
		UnlockLogic.chapter(profile.Starter)) or nil
	player:SetAttribute("UnlockQuest", quest and quest.Id or nil)
	player:SetAttribute("UnlockQuestStep", quest and step or nil)
	player:SetAttribute("UnlockQuestCount", quest and count or nil)
	player:SetAttribute("UnlockNext", nextUp and nextUp.Id or nil)
	if quest then
		local m = quest.Steps[step]
		local fruit = m.EnsureFruit and quest.Gift and quest.Gift.Fruit or 0
		if fruit > 0 and (profile.Fruit or 0) <= 0 then
			PlayerData.update(player, function(p)
				p.Fruit = (p.Fruit or 0) + fruit
			end)
			player:SetAttribute("Fruit", PlayerData.get(player).Fruit)
			say(player, quest.Name, string.format("🎁 코코가 🍎 먹이 %d개를 다시 줬어요!", fruit))
		end
		if m.NeedsNewMap and #Formulas.mapsOpen(profile.Rebirths, profile.DefenseLevel) < 2 then
			setGuide(player, "Q" .. quest.Id .. step .. "L", nil, LOCKED_BUTTON)
			if mapSaid[player] ~= quest.Id then
				mapSaid[player] = quest.Id
				say(player, quest.Name, string.format("⚔️ %s부터 새 맵이 열려요! '⚔️ 보스 도전'으로 보스 웨이브를 깨요",
					Formulas.levelText(NEW_MAP_LEVEL)))
			end
			return true, m.Practice
		end
		local down = m.TreeFirst and Practice.upTree(player)
		setGuide(player, "Q" .. quest.Id .. step .. (down and "D" or ""), down and "PracticeTreeFoot" or m.Guide,
			not down and not busyNow(player, m) and m.Button or nil, not down and m.Taps or nil, nil, m.TapsNear)
		return true, m.Practice
	elseif nextUp then
		setGuide(player, "R" .. nextUp.Id, nextUp.Where or (nextUp.Gate and "Gate") or (nextUp.Zone and ("Zone:" .. nextUp.Id)) or nil,
			nextUp.Button)
		return true, nil
	end
	return false, nil
end

local claim

local SKY_GIFT = nil
for _, sp in ipairs(Config.Species) do
	if not SKY_GIFT and sp.Theme == "Sky" and (sp.UnlockLevel or 1) <= 1 and not sp.UnlockRebirths and not sp.MinKey then
		SKY_GIFT = sp.Id
	end
end

local function ownsSky(profile)
	for _, u in ipairs(profile.Units) do
		if Formulas.isSky(Formulas.unitStats(u)) then
			return true
		end
	end
	return false
end

local function gifted(s, key)
	return s.Gifted ~= nil and s.Gifted[key] == true
end

local function markGifted(p, key)
	p.Starter.Gifted = p.Starter.Gifted or {}
	p.Starter.Gifted[key] = true
end

local function checkVisit(player, profile)
	local mission = StarterLogic.current(profile.Starter)
	if not mission or visited(profile, mission) or lockOf(player, mission) then
		return
	end
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local c = guideCache[player]
	local spot = c and c.name == mission.VisitFirst and c.spot or nil
	if not root or not spot then
		return
	end
	local flat = Vector3.new(spot.X - root.Position.X, 0, spot.Z - root.Position.Z)
	if flat.Magnitude > Config.StarterMissions.VisitRange then
		return
	end
	local id = StarterLogic.idOf(mission)
	PlayerData.update(player, function(p)
		p.Starter.Visited = p.Starter.Visited or {}
		p.Starter.Visited[id] = true
	end)
	say(player, TITLE, "🏔️ 여기가 하늘 바위예요! 👆 위쪽 '🦖 배치'를 눌러 🦅 하늘 공룡을 올려요")
end

local function checkLook(player, profile)
	local mission = StarterLogic.current(profile.Starter)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local at = mission and mission.Event == "DamageLook" and root and damageBoardOf(player)
	if at and Vector3.new(at.X - root.Position.X, 0, at.Z - root.Position.Z).Magnitude <= Config.StarterMissions.VisitRange then
		Rewards.add(player, "DamageLook", 1)
	end
end

local function gifts(player, profile, mission, giftId, f)
	local s = profile.Starter
	if mission.EnsureKeys and not gifted(s, giftId .. "Keys") then
		local short = mission.Target - StarterLogic.progress(s, f) - Formulas.savedKeys(profile, "Normal")
		if short > 0 then
			PlayerData.update(player, function(p)
				markGifted(p, giftId .. "Keys")
				Formulas.addSavedKeys(p, "Normal", short)
			end)
			say(player, TITLE, string.format("🎁 코코가 열쇠 %d개를 채워 줬어요!", short))
		end
	end
	if mission.GiftSky and not gifted(s, giftId .. "Sky") then
		local give = SKY_GIFT ~= nil and not ownsSky(profile)
		PlayerData.update(player, function(p)
			markGifted(p, giftId .. "Sky")
			if give then
				local unit = { Id = "U" .. p.NextUnitId, Species = SKY_GIFT, Rarity = mission.GiftSky, Size = "Young" }
				p.NextUnitId += 1
				table.insert(p.Units, unit)
				Formulas.recordCollection(p, unit)
			end
		end)
		if give then
			say(player, TITLE, "🎁 연습용 🦅 하늘 공룡을 줬어요! 하늘 바위에 올려 봐요")
		end
	end
	if mission.EnsureFruit and (profile.Fruit or 0) <= 0 and not gifted(s, giftId .. "Fruit") then
		PlayerData.update(player, function(p)
			markGifted(p, giftId .. "Fruit")
			p.Fruit = (p.Fruit or 0) + mission.EnsureFruit
		end)
		player:SetAttribute("Fruit", PlayerData.get(player).Fruit)
		say(player, TITLE, string.format("🎁 코코가 🍎 먹이 %d개를 줬어요!", mission.EnsureFruit))
	end
	local bomb = mission.EnsureBomb and Formulas.bombKind(mission.EnsureBomb)
	if bomb and ((profile.Bombs or {})[bomb.Id] or 0) <= 0 then
		require(script.Parent:WaitForChild("Bombs")).give(player, bomb.Id, 1)
		say(player, TITLE, string.format("🎁 연습용 %s 1개를 줬어요!", bomb.Name))
	end
end

local function publish(player)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	if not profile.Graduated and not TutorialField.isField()
		and UnlockLogic.chapter(profile.Starter) > Config.StarterMissions.TutorialChapters then
		Unlocks.graduate(player)
		profile = PlayerData.get(player)
	end
	-- the luck boost: on while profile.LuckUntil is ahead
	local luckLeft = (profile.LuckUntil or 0) - os.time()
	player:SetAttribute("Luck", luckLeft > 0 and Config.StarterMissions.LuckMultiplier or nil)
	player:SetAttribute("LuckEndsAt", luckLeft > 0 and profile.LuckUntil or nil)
	local guaranteed = 0
	for _, n in pairs(profile.GuaranteedDraws or {}) do
		guaranteed += n
	end
	player:SetAttribute("GuaranteedDraws", guaranteed > 0 and guaranteed or nil)
	-- (2026-10-04) all done: the 🎁 window's 📋 tab shows every mission ✔
	player:SetAttribute("StarterDone", StarterLogic.finished(profile.Starter) or nil)
	if profile.FreshStart and StarterLogic.pastFirstFight(profile.Starter) then
		PlayerData.update(player, function(p)
			p.FreshStart = nil
		end)
	end
	player:SetAttribute("FreshStart", (PlayerData.get(player).FreshStart or profile.Stash ~= nil) or nil)
	if profile.Stash and profile.Graduated and player:GetAttribute("Welcome") ~= "Ready" then
		player:SetAttribute("Welcome", "Ready")
	end
	-- (2026-10-04) the ones done on the board's older order, still to pass by (✔ in the 📋 tab too): their names
	local skip = {}
	for name in pairs(profile.Starter.Skip or {}) do
		table.insert(skip, name)
	end
	local extra = profile.Starter.Extra
	if extra and extra[1] then
		local waiting = {}
		for _, name in ipairs(extra) do
			waiting[name] = true
		end
		for i, m in ipairs(Config.StarterMissions.Missions) do
			local name = StarterLogic.idOf(m)
			if not m.Comeback and not waiting[name] and (profile.Starter.Done or i < (profile.Starter.Step or 1)) then
				table.insert(skip, name)
			end
		end
	end
	player:SetAttribute("StarterSkip", #skip > 0 and table.concat(skip, ",") or nil)
	local learning, practice = publishLearning(player, profile)
	if not boardUp(player, profile) then
		player:SetAttribute("StarterStep", nil)
		player:SetAttribute("StarterCount", nil)
		player:SetAttribute("StarterReady", nil)
		player:SetAttribute("StarterLocked", nil)
		player:SetAttribute("StarterMain", nil)
		player:SetAttribute("CocoPays", nil)
		if not learning then
			publishGuide(player, nil, nil, false)
		end
		Practice.want(player, practice)
		return
	end
	local s = profile.Starter
	if atTop(profile) and StarterLogic.current(s) and StarterLogic.current(s).Loop then
		PlayerData.update(player, function(p)
			StarterLogic.skipLoop(p.Starter)
		end)
		profile = PlayerData.get(player)
		s = profile.Starter
	end
	checkVisit(player, profile)
	checkLook(player, profile)
	local f = facts(player, profile)
	local stage = table.concat({ s.Step or 0, s.Done and 1 or 0, StarterLogic.ready(s, f) and 1 or 0,
		s.Extra and s.Extra[1] or "" }, "|")
	if stages[player] ~= stage then
		stages[player] = stage
		Unlocks.restage(player)
	end
	local mission, step = StarterLogic.current(s)
	local locked = lockOf(player, mission)
	local ready = not locked and StarterLogic.ready(s, f)
	local giftId = mission and StarterLogic.idOf(mission)
	local merging = mission and mission.Gift and not ready
	if mission and not locked and not ready and mission.Gift and not (s.Gifted and s.Gifted[giftId]) then
		local species = profile.Units[1] and profile.Units[1].Species or Config.Species[1].Id
		PlayerData.update(player, function(p)
			p.Starter.Gifted = p.Starter.Gifted or {}
			p.Starter.Gifted[giftId] = true
			p.Starter.MergeDinos = {}
			for _ = 1, Config.Merge.Count do
				local unit = { Id = "U" .. p.NextUnitId, Species = species, Rarity = mission.Gift, Size = "Young",
					Level = Config.Merge.Level, Exp = 0 }
				p.NextUnitId += 1
				table.insert(p.Units, unit)
				table.insert(p.Starter.MergeDinos, unit.Id)
				Formulas.recordCollection(p, unit)
			end
		end)
		say(player, TITLE, string.format("🎁 합성 연습용 Lv %d %s 공룡 %d마리를 받았어요!", Config.Merge.Level,
			Formulas.rarity(mission.Gift).Name, Config.Merge.Count))
	elseif merging and s.Gifted and s.Gifted[giftId] and not s.MergeDinos then
		local ids = StarterLogic.mergeDinos(profile.Units, mission.Gift)
		PlayerData.update(player, function(p)
			p.Starter.MergeDinos = ids
			for _, id in ipairs(ids) do
				p.Placed[id] = nil
			end
		end)
	end
	if s.MergeDinos and not merging then
		PlayerData.update(player, function(p)
			p.Starter.MergeDinos = nil
		end)
	end
	if mission and not locked and not ready then
		gifts(player, profile, mission, giftId, f)
	end
	local pays = mission and not locked and not ready and mission.CocoPays or nil
	player:SetAttribute("CocoPays", pays and not (s.CocoPaid and s.CocoPaid[pays]) and pays or nil)
	if mission and not locked and not ready and mission.Optional and mission.Needs
		and not ReplicatedStorage:GetAttribute(mission.Needs) then
		PlayerData.update(player, function(p)
			StarterLogic.pass(p.Starter, atTop(p))
		end)
		say(player, TITLE, "⏩ 지금은 할 수 없는 미션이라 넘어갔어요")
		Unlocks.refreshPlayer(player)
		publish(player)
		return
	end
	if ready and mission.FirstWave and waved[player] ~= step then
		waved[player] = step
		claim(player)
		return
	end
	player:SetAttribute("StarterLocked", locked)
	if not learning then
		publishGuide(player, mission, step, ready, locked, atTop(profile), profile, StarterLogic.progress(s, f))
	end
	Practice.want(player, practice or (mission and not locked and mission.Practice) or nil)
	player:SetAttribute("StarterStep", step)
	player:SetAttribute("StarterMain", s.Step)
	player:SetAttribute("StarterCount", StarterLogic.progress(s, f))
	player:SetAttribute("StarterReady", ready or nil)
	if ready and readyShown[player] ~= step then
		readyShown[player] = step
		task.delay(Config.StarterMissions.AutoClaim, function()
			if player.Parent then
				claim(player)
			end
		end)
	elseif not ready then
		readyShown[player] = nil
	end
	if not ready and not locked and mission and mission.Fight and atTop(profile) and topShown[player] ~= step then
		topShown[player] = step
		say(player, TITLE, "🏆 끝 레벨에선 보스 웨이브가 없어요 · 이 미션은 ⏩ 넘겨도 돼요")
	end
end

local function grant(player, reward)
	local money = 0
	PlayerData.update(player, function(p)
		money = RewardLogic.apply(p, reward)
		if (reward.LuckMinutes or 0) > 0 then
			p.LuckUntil = math.max(p.LuckUntil or 0, os.time()) + reward.LuckMinutes * 60
		end
		if (reward.SlapLevels or 0) > 0 then
			p.Upgrades.Slap = math.min(#Config.Slap.Cost, p.Upgrades.Slap + reward.SlapLevels)
		end
		if reward.GuaranteedRarity then
			p.GuaranteedDraws = p.GuaranteedDraws or {}
			p.GuaranteedDraws[reward.GuaranteedRarity] = (p.GuaranteedDraws[reward.GuaranteedRarity] or 0) + 1
		end
	end)
	if money > 0 then
		PlayerData.addMoney(player, money, "reward")
	end
	say(player, TITLE, StarterLogic.rewardText(reward) .. " 받았어요!")
end

claim = function(player)
	local profile = PlayerData.get(player)
	if not profile or not boardUp(player, profile) then
		return
	end
	if lockOf(player, StarterLogic.current(profile.Starter)) then
		return
	end
	local reward
	local f = facts(player, profile)
	local before = profile.Starter and profile.Starter.Step
	PlayerData.update(player, function(p)
		reward = StarterLogic.claim(p.Starter, f)
	end)
	if reward then
		grant(player, reward)
		local after = PlayerData.get(player).Starter
		if StarterLogic.finished(after) then
			say(player, TITLE, "초보 미션을 모두 끝냈어요! 🎉 이제 오늘의 임무와 주간 도전에 도전해요")
			Net.push(player, "CocoCard", { "🎉 초보 미션 끝!", "👑 이제 노란 줄이 가득 차면 보스 웨이브가 자동으로 시작돼요",
				"📅 오늘의 임무 · 주간 도전에도 도전해요" }, "Base_Arena")
			require(script.Parent:WaitForChild("Monetization")).offerStarter(player)
		elseif before and after.Step ~= before then
			local chapter, at, size = Formulas.starterChapter(before, #Config.StarterMissions.Missions)
			if at == size and chapter ~= Config.StarterMissions.TutorialChapters then
				Unlocks.refreshPlayer(player)
				local u = nil
				for _, c in ipairs(Config.Unlocks) do
					if not u and c.After == chapter and not Unlocks.has(player, c.Id) then
						u = c
					end
				end
				local state = u and Unlocks.state(player, u.Id)
				if state == "Ready" then
					say(player, TITLE, string.format((u.Where or u.Zone) and "🎉 %d장 끝! 🔓 %s: 가면 바로 열려요!"
						or "🎉 %d장 끝! 🔓 %s 열려요!", chapter, u.Name))
				elseif state == "Locked" and u.Level then
					say(player, TITLE, string.format("🎉 %d장 끝! 🔒 다음 %s: ⚔️ 디펜스 %s부터 열 수 있어요", chapter, u.Name,
						Formulas.levelText(u.Level)))
				else
					say(player, TITLE, string.format("🎉 %d장 끝! 다음 %d장 %s GO", chapter, chapter + 1,
						Formulas.starterChapterInfo(chapter + 1).Name))
				end
			end
		end
	end
	publish(player)
end

local function comeback(player)
	local profile = player.Parent and PlayerData.isLoaded(player) and PlayerData.get(player)
	if not profile or profile.Starter.Comeback or not boardUp(player, profile) then
		return
	end
	local ids = {}
	for _, m in ipairs(Config.StarterMissions.Missions) do
		if m.Comeback and (not m.Open or Unlocks.has(player, m.Open)) then
			table.insert(ids, StarterLogic.idOf(m))
		end
	end
	local started = false
	PlayerData.update(player, function(p)
		started = StarterLogic.comeback(p.Starter, ids)
	end)
	if started then
		say(player, TITLE, "💪 보스가 셌어요! 미션판을 따라 세져서 다시 도전해요")
		publish(player)
	end
end

local function pass(player)
	local profile = PlayerData.get(player)
	if not profile or not boardUp(player, profile) or lockOf(player, (StarterLogic.current(profile.Starter))) then
		return
	end
	PlayerData.update(player, function(p)
		StarterLogic.pass(p.Starter, atTop(p))
	end)
	if StarterLogic.finished(PlayerData.get(player).Starter) then
		require(script.Parent:WaitForChild("Monetization")).offerStarter(player)
	end
	Unlocks.refreshPlayer(player)
	publish(player)
end

local function rejoin(player, studioText, kickText)
	PlayerData.save(player)
	if RunService:IsStudio() then
		player:Kick(studioText)
		return
	end
	local failed = false
	local watch = TeleportService.TeleportInitFailed:Connect(function(who)
		if who == player then
			failed = true
		end
	end)
	local tries = {}
	if #Players:GetPlayers() > 1 then
		local same = Instance.new("TeleportOptions")
		same.ServerInstanceId = game.JobId
		table.insert(tries, same)
	end
	for _ = 1, RESTART_TRIES do
		table.insert(tries, false)
	end
	for _, options in ipairs(tries) do
		if not player.Parent then
			break
		end
		failed = false
		if pcall(TeleportService.TeleportAsync, TeleportService, game.PlaceId, { player }, options or nil) then
			local waitedFrom = os.clock()
			while player.Parent and not failed and os.clock() - waitedFrom < RESTART_KICK_AFTER do
				task.wait(RESTART_POLL)
			end
			if not failed then
				break
			end
		end
		if player.Parent then
			task.wait(RESTART_WAIT)
		end
	end
	watch:Disconnect()
	if player.Parent then
		player:Kick(kickText)
	end
end

local function markRestart(p)
	p.DevReplay = true
	p.DevWipe = nil
	if type(p.Tutorial) == "table" then
		p.Tutorial.Done = true
		p.Tutorial.ReplayAt, p.Tutorial.ReplayPart, p.Tutorial.ReplayCore = 0, nil, nil
	end
end

local function devRestart(player)
	if not Formulas.isDeveloper(player.Name) or not PlayerData.get(player) then
		return
	end
	local field = TutorialField.isField()
	if not field then
		PlayerData.update(player, markRestart)
	end
	if field or not PlayerData.isPersistent(player) then
		PlayerData.markStored(player, markRestart)
	end
	if field and not RunService:IsStudio() then
		PlayerData.save(player)
		TutorialField.toMain(player)
		return
	end
	rejoin(player, "[Studio] 테스트를 다시 실행하면 처음부터 시작해요", "다시 들어오면 처음부터 시작해요")
end

local function goHome(player)
	local profile = PlayerData.get(player)
	if homing[player] or TutorialField.isField() or not profile or not profile.Stash or not profile.Graduated then
		return
	end
	homing[player] = true
	rejoin(player, "[Studio] 테스트를 다시 실행하면 예전 데이터로 이어져요", "다시 들어오면 예전 데이터로 이어져요")
end

local function homecoming(practice)
	local back = ProfileLogic.restore(practice, Config)
	local now = ProfileLogic.copy(practice.Starter)
	StarterLogic.upgrade(back.Starter)
	StarterLogic.upgrade(now)
	back.Starter = StarterLogic.merge(back.Starter, now)
	return back
end

local function prepare(player, profile)
	local dev = Formulas.isDeveloper(player.Name)
	local kept = type(profile.Stash) == "table" and profile.Stash or nil
	if dev and (profile.DevReplay or profile.DevWipe or (profile.StarterReplay or 0) < Config.Developers.StarterReplay) then
		if kept then
			ProfileLogic.skipPractice(kept, profile)
		end
		return ProfileLogic.stash(kept or profile, Config)
	elseif kept and not dev and not ProfileLogic.pastTutorial(kept, Config) then
		return ProfileLogic.settle(profile)
	elseif kept and profile.Graduated then
		return homecoming(profile)
	elseif profile.Onboard == nil and not kept and ProfileLogic.veteran(profile) then
		if ProfileLogic.pastTutorial(profile, Config) then
			return ProfileLogic.stash(profile, Config)
		end
		return ProfileLogic.restart(profile, Config)
	end
	profile.Onboard = 1
	return nil
end

function StarterMissions.init()
	PlayerData.onPrepare(function(player, profile)
		if TutorialField.isField() then
			return nil
		end
		local ok, result = pcall(prepare, player, profile)
		if not ok then
			warn(string.format("[StarterMissions] %s: start-over step failed, the save stays as it is (%s)", player.Name,
				tostring(result)))
			return nil
		end
		return result
	end)
	Unlocks.onChange(function(player)
		if PlayerData.isLoaded(player) then
			publish(player)
		end
	end)
	Net.onRequest("ClaimStarter", {}, claim)
	Net.onRequest("StarterPass", {}, pass)
	Net.onRequest("DevRestart", {}, devRestart)
	Net.onRequest("DamageLook", {}, function(player)
		local profile = PlayerData.get(player)
		if profile then
			if profile.PromoDamage or next(profile.Placed or {}) then
				Rewards.add(player, "DamageLook", 1)
			end
		end
	end)
	Net.onRequest("WelcomeHome", {}, goHome)
	Rewards.onAdd(function(player, kind, amount)
		local profile = PlayerData.get(player)
		if not profile then
			return
		end
		local cap = EVER_CAP[kind]
		if cap and (amount or 0) > 0 and ((profile.Ever or {})[kind] or 0) < cap then
			PlayerData.update(player, function(p)
				p.Ever = p.Ever or {}
				p.Ever[kind] = math.min(cap, (p.Ever[kind] or 0) + amount)
			end)
			profile = PlayerData.get(player)
		end
		if kind == "PromotionFailed" and not profile.Starter.Comeback then
			task.delay(Config.StarterMissions.ComebackDelay, comeback, player)
		end
		if not boardUp(player, profile) then
			return
		end
		local m = StarterLogic.current(profile.Starter)
		if m and m.Event == kind and not lockOf(player, m) then
			PlayerData.update(player, function(p)
				StarterLogic.event(p.Starter, kind, amount)
			end)
			publish(player)
		end
	end)
	local busyNames = {}
	for _, m in ipairs(Config.StarterMissions.Missions) do
		if m.Busy then
			busyNames[m.Busy] = true
		end
	end
	PlayerData.onLoaded(function(player)
		-- (2026-10-04) a save on the board's older order moves to the new one once (the key stall first)
		local welcome = PlayerData.get(player).Welcome
		PlayerData.update(player, function(p)
			StarterLogic.upgrade(p.Starter)
			p.Welcome = nil
		end)
		if welcome then
			player:SetAttribute("Welcome", welcome)
		elseif PlayerData.get(player).Stash then
			task.delay(KEPT_NOTICE_AFTER, function()
				if player.Parent then
					say(player, "📦 예전 데이터 보관 중", "🎓 튜토리얼을 마치면 돌려드리고 맵이 모두 열려요")
				end
			end)
		end
		Unlocks.refreshPlayer(player)
		publish(player)
		for name in pairs(busyNames) do
			player:GetAttributeChangedSignal(name):Connect(function()
				publish(player)
			end)
		end
		local watched = { "DefenseLevel" }
		for _, u in ipairs(Config.Unlocks) do
			if u.Pass then
				table.insert(watched, "Pass" .. u.Pass)
			end
			for _, m in ipairs(u.Steps) do
				if m.Busy and not table.find(watched, m.Busy) then
					table.insert(watched, m.Busy)
				end
			end
		end
		for _, name in ipairs(watched) do
			player:GetAttributeChangedSignal(name):Connect(function()
				publish(player)
			end)
		end
	end)
	Players.PlayerRemoving:Connect(function(player)
		readyShown[player] = nil
		topShown[player] = nil
		moneySaid[player] = nil
		mapSaid[player] = nil
		stages[player] = nil
		waved[player] = nil
		homing[player] = nil
		guideCache[player] = nil
		Practice.want(player, nil)
	end)
	task.spawn(function()
		while true do
			task.wait(Config.StarterMissions.CheckEvery)
			for _, player in ipairs(Players:GetPlayers()) do
				if PlayerData.isLoaded(player) then
					publish(player)
				end
			end
		end
	end)
end

return StarterMissions
