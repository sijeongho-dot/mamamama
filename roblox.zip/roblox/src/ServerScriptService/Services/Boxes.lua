local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local Policy = require(script.Parent:WaitForChild("Policy"))

local Boxes = {}

local PILE_CELL = 5.5
local PILE_COLUMNS = 4
local PILE_ROWS = 2
local PILE_EDGE_GAP = 2.5
local LIST_MAX = 120

local quick = nil
local piles = {}
local due = {}
local lastReady = {}
local lastNotice = {}
local intents = {}

function Boxes.setQuick(fn)
	quick = fn
end

function Boxes.seconds(player, unit, firstDraw)
	local cap = quick and quick(player)
	if firstDraw then
		cap = math.min(cap or math.huge, Config.Boxes.FirstDrawSeconds)
	end
	return Formulas.boxSeconds(unit.Rarity, unit.Size, cap)
end

function Boxes.add(p, unit, pity, seconds, now)
	p.Boxes = p.Boxes or {}
	p.NextBoxId = p.NextBoxId or 1
	local box = { Id = "B" .. p.NextBoxId, Species = unit.Species, Rarity = unit.Rarity, Size = unit.Size,
		Limited = unit.Limited, Mutation = unit.Mutation, Pity = pity or nil, MadeAt = now, ReadyAt = now + seconds }
	p.NextBoxId += 1
	table.insert(p.Boxes, box)
	return box
end

function Boxes.public(box)
	return { Id = box.Id, Rarity = box.Rarity, Size = box.Size, MadeAt = box.MadeAt, ReadyAt = box.ReadyAt, Pity = box.Pity }
end

function Boxes.count(profile)
	return #(profile.Boxes or {})
end

local function sizeScale(sizeId)
	local size = Formulas.dinoSize(sizeId)
	return (size and size.Scale) or 1
end

local function rank(rarityId)
	return Formulas.rarity(rarityId .. "#") or 0
end

local function groundAt(position, ignore)
	local params = RaycastParams.new()
	params.FilterDescendantsInstances = ignore
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true
	local hit = Workspace:Raycast(position + Vector3.new(0, 50, 0), Vector3.new(0, -200, 0), params)
	return hit and hit.Position.Y or position.Y
end

local function shownBoxes(profile)
	local list = table.clone(profile.Boxes or {})
	table.sort(list, function(a, b)
		local ra, rb = rank(a.Rarity), rank(b.Rarity)
		if ra ~= rb then
			return ra > rb
		end
		return a.ReadyAt < b.ReadyAt
	end)
	local shown = {}
	for i = 1, math.min(#list, Config.Boxes.PileShown) do
		shown[i] = list[i]
	end
	return shown
end

local function idNumber(box)
	return tonumber(string.match(box.Id or "", "%d+")) or 0
end

local function stackOrder(a, b)
	local ea, eb = sizeScale(a.Size), sizeScale(b.Size)
	if ea ~= eb then
		return ea > eb
	end
	local ra, rb = rank(a.Rarity), rank(b.Rarity)
	if ra ~= rb then
		return ra > rb
	end
	if a.ReadyAt ~= b.ReadyAt then
		return a.ReadyAt < b.ReadyAt
	end
	return idNumber(a) < idNumber(b)
end

local function gridOf(folder, pen)
	local cf, size = pen:GetBoundingBox()
	local bin = folder:FindFirstChild("Base_DepositBin", true)
	local toward = cf:PointToObjectSpace(bin and Bases.position(bin) or folder:GetAttribute("Center") or cf.Position)
	local sx, sz = toward.X >= 0 and 1 or -1, toward.Z >= 0 and 1 or -1
	local columns = math.clamp(math.floor((size.X / 2 - PILE_EDGE_GAP) / PILE_CELL), 1, PILE_COLUMNS)
	local rows = math.clamp(math.floor((size.Z / 2 - PILE_EDGE_GAP) / PILE_CELL), 1, PILE_ROWS)
	local cornerX, cornerZ = sx * (size.X / 2 - PILE_EDGE_GAP), sz * (size.Z / 2 - PILE_EDGE_GAP)
	local ignore = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	for _, name in ipairs({ "FarmUnits", "FarmGrass", "BoxPile" }) do
		local f = folder:FindFirstChild(name)
		if f then
			table.insert(ignore, f)
		end
	end
	local cells = {}
	for r = 0, rows - 1 do
		for c = 0, columns - 1 do
			local at = cf:PointToWorldSpace(Vector3.new(cornerX - sx * (PILE_CELL / 2 + c * PILE_CELL), 0,
				cornerZ - sz * (PILE_CELL / 2 + r * PILE_CELL)))
			table.insert(cells, Vector3.new(at.X, groundAt(at, ignore), at.Z))
		end
	end
	local yaw = math.atan2(-cf.LookVector.X, -cf.LookVector.Z)
	local middle = cf:PointToWorldSpace(Vector3.new(cornerX - sx * columns * PILE_CELL / 2, 0, cornerZ - sz * rows * PILE_CELL / 2))
	return {
		cells = cells,
		yaw = yaw,
		spot = CFrame.new(middle.X, cells[1].Y + 0.5, middle.Z) * CFrame.Angles(0, yaw, 0),
		spotSize = Vector3.new(columns * PILE_CELL, 1, rows * PILE_CELL),
	}
end

local function setIf(inst, name, value)
	if inst:GetAttribute(name) ~= value then
		inst:SetAttribute(name, value)
	end
end

local function dropPile(player)
	local old = piles[player]
	if old and old.folder then
		old.folder:Destroy()
	end
	piles[player] = nil
end

local function refreshPile(player, profile)
	local folder = Bases.folderOf(player)
	local pen = folder and folder:FindFirstChild("Base_FarmPen", true)
	local count = profile and #(profile.Boxes or {}) or 0
	local pile = piles[player]
	if pile and (pile.base ~= folder or not pile.folder.Parent and pile.placed) then
		dropPile(player)
		pile = nil
	end
	if not pen or count == 0 then
		dropPile(player)
		return
	end
	if not pile then
		local f = Instance.new("Folder")
		f.Name = "BoxPile"
		f:SetAttribute("Owner", player.UserId)
		local spot = Instance.new("Part")
		spot.Name = "PileSpot"
		spot.Transparency = 1
		spot.Anchored, spot.CanCollide, spot.CanQuery, spot.CanTouch = true, false, false, false
		spot.Parent = f
		pile = { folder = f, spot = spot, base = folder }
		piles[player] = pile
	end
	local hidden = pen:GetAttribute("Hidden") == true
	if not pile.grid or pile.hidden ~= hidden then
		pile.hidden = hidden
		pile.grid = gridOf(folder, pen)
		pile.spot.Size = pile.grid.spotSize
		pile.spot.CFrame = pile.grid.spot
		local cells = {}
		for i, at in ipairs(pile.grid.cells) do
			cells[i] = string.format("%.2f,%.2f,%.2f", at.X, at.Y, at.Z)
		end
		setIf(pile.folder, "Cells", table.concat(cells, ";"))
		setIf(pile.folder, "Yaw", pile.grid.yaw)
		setIf(pile.folder, "Spot", pile.grid.spot)
		setIf(pile.folder, "SpotSize", pile.grid.spotSize)
	end
	local shown = shownBoxes(profile)
	table.sort(shown, stackOrder)
	local cellCount = #pile.grid.cells
	local list = {}
	for i, b in ipairs(shown) do
		local made = b.MadeAt or (b.ReadyAt - Formulas.boxSeconds(b.Rarity, b.Size))
		list[i] = table.concat({ b.Id, b.Rarity, tostring(b.Size or ""), tostring(made), tostring(b.ReadyAt),
			tostring((i - 1) % cellCount + 1) }, ",")
	end
	setIf(pile.folder, "Boxes", table.concat(list, ";"))
	setIf(pile.folder, "Total", count)
	setIf(pile.folder, "Ready", (Formulas.boxStatus(profile.Boxes, os.time())))
	if not pile.placed then
		pile.placed = true
		pile.folder.Parent = folder
	end
end

local function publish(player, profile)
	profile = profile or PlayerData.get(player)
	if not profile then
		return 0
	end
	local now = os.time()
	local ready, waiting, nextAt = Formulas.boxStatus(profile.Boxes, now)
	player:SetAttribute("BoxesReady", ready > 0 and ready or nil)
	player:SetAttribute("BoxesWaiting", waiting > 0 and waiting or nil)
	player:SetAttribute("BoxNextAt", nextAt)
	player:SetAttribute("BoxRush", (profile.BoxRush or 0) > 0 and profile.BoxRush or nil)
	local skips = profile.FreeSkips or 0
	local longest = 0
	for _, b in ipairs(profile.Boxes or {}) do
		longest = math.max(longest, b.ReadyAt - now)
	end
	player:SetAttribute("FreeSkips", skips > 0 and skips or nil)
	player:SetAttribute("FreeSkipFor", skips > 0 and longest >= Config.Boxes.FreeSkipMinSeconds or nil)
	due[player] = nextAt
	return ready
end

function Boxes.changed(player)
	local profile = PlayerData.get(player)
	local ready = publish(player, profile)
	lastReady[player] = ready
	refreshPile(player, profile)
end

local function tick(player)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	local ready = publish(player, profile)
	local before = lastReady[player] or 0
	lastReady[player] = ready
	refreshPile(player, profile)
	if ready > before and os.clock() - (lastNotice[player] or -math.huge) >= Config.Boxes.ReadyNoticeGap then
		lastNotice[player] = os.clock()
		Net.push(player, "Notice", "📦 상자", string.format("✅ 상자 %d개 열 수 있어요! 위의 📦 상자를 눌러요", ready))
	end
end

local function open(player, which)
	local profile = PlayerData.get(player)
	if not profile then
		return nil
	end
	local now = os.time()
	local results = {}
	PlayerData.update(player, function(p)
		local keep = {}
		for _, b in ipairs(p.Boxes or {}) do
			if #results < Config.Boxes.OpenAtOnce and b.ReadyAt <= now and (which == "All" or which == b.Id) then
				local unit = { Id = "U" .. p.NextUnitId, Species = b.Species, Rarity = b.Rarity, Size = b.Size,
					Limited = b.Limited, Mutation = b.Mutation }
				p.NextUnitId += 1
				table.insert(p.Units, unit)
				Formulas.recordCollection(p, unit)
				local shown = table.clone(unit)
				shown.Pity = b.Pity
				table.insert(results, shown)
			else
				table.insert(keep, b)
			end
		end
		p.Boxes = keep
	end)
	if #results == 0 then
		local _, waiting, nextAt = Formulas.boxStatus(profile.Boxes, now)
		return { Error = waiting > 0 and string.format("⏳ 아직이에요! %s 뒤에 열 수 있어요", Formulas.clockText(nextAt - now))
			or "📦 상자가 없어요! 🎰 뽑기로 상자를 받아요" }
	end
	Rewards.add(player, "BoxOpen", #results)
	local announceFrom = rank(Config.Gacha.AnnounceFromRarity)
	for _, unit in ipairs(results) do
		if rank(unit.Rarity) >= announceFrom then
			Net.pushAll("Notice", "🎰 대박 뽑기!", string.format("🎉 %s님이 %s %s 뽑았어요!", player.DisplayName,
				Formulas.rarity(unit.Rarity).Name, Formulas.species(unit.Species).Name))
		end
		if Formulas.chatFind(unit.Rarity) then
			Net.pushAll("BigFind", player.DisplayName, "Dino", unit.Rarity, unit.Species)
		end
	end
	Boxes.changed(player)
	return { Results = results, Left = #(PlayerData.get(player).Boxes or {}) }
end

local function applyRush(p, ids, now)
	local wanted = {}
	for _, id in ipairs(ids) do
		wanted[id] = true
	end
	local list = {}
	for _, b in ipairs(p.Boxes or {}) do
		if wanted[b.Id] and b.ReadyAt > now then
			table.insert(list, b)
		end
	end
	table.sort(list, function(a, b)
		return a.ReadyAt < b.ReadyAt
	end)
	local opened = 0
	for _, b in ipairs(list) do
		local left = b.ReadyAt - now
		if (p.BoxRush or 0) < left then
			break
		end
		p.BoxRush -= left
		b.ReadyAt = now
		opened += 1
	end
	return opened
end

function Boxes.rush(player, seconds)
	local intent = intents[player]
	intents[player] = nil
	local now = os.time()
	local opened = 0
	PlayerData.update(player, function(p)
		p.BoxRush = (p.BoxRush or 0) + seconds
		local ids = {}
		if intent and os.clock() - intent.at <= Config.Boxes.RushIntentSeconds then
			ids = intent.ids
		else
			for _, b in ipairs(p.Boxes or {}) do
				table.insert(ids, b.Id)
			end
		end
		opened = applyRush(p, ids, now)
	end)
	Boxes.changed(player)
	local left = PlayerData.get(player).BoxRush or 0
	local text = string.format("⚡ 상자 %d개 바로 열 수 있어요!", opened)
	if left > 0 then
		text ..= string.format(" · ⚡ 남은 빨리 열기 %s", Formulas.clockText(left))
	end
	return text
end

function Boxes.readyAll(player)
	local now = os.time()
	PlayerData.update(player, function(p)
		for _, b in ipairs(p.Boxes or {}) do
			b.ReadyAt = math.min(b.ReadyAt, now)
		end
	end)
	tick(player)
end

function Boxes.init()
	Net.onAsk("GetBoxes", {}, function(player)
		local profile = PlayerData.get(player)
		if not profile then
			return nil
		end
		local list = {}
		for _, b in ipairs(profile.Boxes or {}) do
			table.insert(list, Boxes.public(b))
		end
		table.sort(list, function(a, b)
			if a.ReadyAt ~= b.ReadyAt then
				return a.ReadyAt < b.ReadyAt
			end
			return a.Id < b.Id
		end)
		local total = #list
		for i = #list, LIST_MAX + 1, -1 do
			list[i] = nil
		end
		return { Boxes = list, Total = total, Now = os.time() }
	end)
	Net.onAsk("OpenBoxes", { "string" }, open)
	Net.onAsk("BoxFreeSkip", { "string" }, function(player, id)
		local profile = PlayerData.get(player)
		if not profile then
			return nil
		end
		if (profile.FreeSkips or 0) < 1 then
			return { Error = "🎟️ 무료 바로 열기권이 없어요" }
		end
		local now = os.time()
		local target = nil
		for _, b in ipairs(profile.Boxes or {}) do
			if b.Id == id then
				target = b
			end
		end
		if not target or target.ReadyAt <= now then
			return { Error = "⏳ 기다리는 상자에 써요" }
		end
		if target.ReadyAt - now < Config.Boxes.FreeSkipMinSeconds then
			return { Error = string.format("🎟️ %s 넘게 기다리는 상자에 써요!", Formulas.clockText(Config.Boxes.FreeSkipMinSeconds)) }
		end
		PlayerData.update(player, function(p)
			for _, b in ipairs(p.Boxes or {}) do
				if b.Id == id then
					b.ReadyAt = now
				end
			end
			p.FreeSkips = math.max(0, (p.FreeSkips or 0) - 1)
		end)
		Boxes.changed(player)
		return { Done = true }
	end)
	Net.onAsk("BoxRush", { "string" }, function(player, which)
		local profile = PlayerData.get(player)
		if not profile then
			return nil
		end
		local now = os.time()
		local ids, _, tier = Formulas.boxRushPick(profile.Boxes, now, which, profile.BoxRush)
		if #ids == 0 then
			return { Error = "⏳ 기다리는 상자가 없어요" }
		end
		if not tier then
			PlayerData.update(player, function(p)
				applyRush(p, ids, now)
			end)
			Boxes.changed(player)
			return { Done = true }
		end
		local key = "BoxRush" .. tier
		if not Policy.canBuy(player, key) then
			return { Error = "🔒 이 나라에선 살 수 없어요" }
		end
		intents[player] = { ids = ids, at = os.clock() }
		return { Product = key }
	end)
	PlayerData.onLoaded(function(player, profile)
		local ready = publish(player, profile)
		lastReady[player] = ready
		refreshPile(player, profile)
		if ready > 0 then
			lastNotice[player] = os.clock()
			task.delay(Config.Boxes.ReadyNoticeGap / 3, function()
				if player.Parent then
					Net.push(player, "Notice", "📦 상자", string.format("✅ 기다리던 상자 %d개가 다 됐어요! 위의 📦 상자를 눌러요", ready))
				end
			end)
		end
	end)
	Players.PlayerAdded:Connect(function(player)
		player:GetAttributeChangedSignal("Base"):Connect(function()
			refreshPile(player, PlayerData.get(player))
		end)
	end)
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		local pen = folder and folder:FindFirstChild("Base_FarmPen")
		if pen then
			pen:GetAttributeChangedSignal("Hidden"):Connect(function()
				local owner = Players:GetPlayerByUserId(folder:GetAttribute("OwnerUserId") or 0)
				if owner then
					refreshPile(owner, PlayerData.get(owner))
				end
			end)
		end
	end
	for _, player in ipairs(Players:GetPlayers()) do
		player:GetAttributeChangedSignal("Base"):Connect(function()
			refreshPile(player, PlayerData.get(player))
		end)
	end
	Players.PlayerRemoving:Connect(function(player)
		dropPile(player)
		due[player], lastReady[player], lastNotice[player], intents[player] = nil, nil, nil, nil
	end)
	task.spawn(function()
		while true do
			task.wait(1)
			local now = os.time()
			for player, at in pairs(due) do
				if at and at <= now and player.Parent then
					tick(player)
				end
			end
		end
	end)
end

return Boxes
