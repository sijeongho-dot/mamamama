--[[
Poop: pterosaur droppings (Config.Poop), decided on the server so everyone sees the same thing.

By day (not at night: DayNight), every Interval seconds, with ChancePercent, a dropping falls at a random player on the battlefield
(within Config.Battlefield.Radius of the middle, the orange band, and not inside a base; the spot
stays inside it too): aimed at where they are heading (at most MaxLead ahead), up to MissRadius off.
It really comes from a pterosaur: the clients (WeatherFx, Net push Poop with a heading shared by all)
see one fly in at Height for ApproachSeconds, screeching, and let go right over the spot; then the
dropping falls for FallSeconds with a shadow growing where it will land, so it can be dodged. When it lands, only players within HitRadius are hit (a direct hit): they are stuck for
StunSeconds (MoveGuard.stun, reason "Poop") and get a banner. Nothing stays on the ground.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local DayNight = require(script.Parent:WaitForChild("DayNight"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))

local Poop = {}

local rng = Random.new()

local function groundAt(position)
	local params = RaycastParams.new()
	local ignore = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	params.FilterDescendantsInstances = ignore
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true
	local hit = Workspace:Raycast(position + Vector3.new(0, 50, 0), Vector3.new(0, -200, 0), params)
	return hit and hit.Position or position
end

local function outInTheOpen()
	local list = {}
	for _, p in ipairs(Players:GetPlayers()) do
		local root = p.Character and p.Character:FindFirstChild("HumanoidRootPart")
		local humanoid = p.Character and p.Character:FindFirstChildOfClass("Humanoid")
		local flat = root and Vector3.new(root.Position.X, 0, root.Position.Z)
		if root and humanoid and humanoid.Health > 0 and not SafeZones.isSafe(root.Position)
			and flat.Magnitude <= Config.Battlefield.Radius and not SafeZones.inSky(p, root.Position)
			and not p:GetAttribute("InTutorial") then
			table.insert(list, { player = p, root = root })
		end
	end
	return list
end

-- drop one at this spot now (Studio tests call it with a spot; the loop picks one)
function Poop.drop(at)
	local c = Config.Poop
	local landing = groundAt(at)
	Net.pushAll("Poop", landing.X, landing.Y, landing.Z, c.FallSeconds, c.Height, c.ApproachSeconds,
		rng:NextNumber(0, 2 * math.pi))
	task.delay(c.ApproachSeconds + c.FallSeconds, function()
		for _, p in ipairs(Players:GetPlayers()) do
			local root = p.Character and p.Character:FindFirstChild("HumanoidRootPart")
			if root and not SafeZones.inSky(p, root.Position) and not p:GetAttribute("InTutorial") then -- (2026-10-04: up there on a flying dino, only looking)
				local d = root.Position - landing
				if Vector3.new(d.X, 0, d.Z).Magnitude <= c.HitRadius and math.abs(d.Y) < 8 then
					MoveGuard.stun(p, c.StunSeconds, "Poop")
					Net.push(p, "Banner", string.format("💩 똥에 맞았어요! %d초 동안 못 움직여요", c.StunSeconds), "Poop")
				end
			end
		end
	end)
end

function Poop.init()
	task.spawn(function()
		while true do
			task.wait(Config.Poop.Interval)
			if not DayNight.isNight() and rng:NextNumber() * 100 < Config.Poop.ChancePercent then -- asleep at night
				local list = outInTheOpen()
				if #list > 0 then
					local pick = list[rng:NextInteger(1, #list)]
					local c = Config.Poop
					local ahead = pick.root.AssemblyLinearVelocity * (c.ApproachSeconds + c.FallSeconds) -- where they are heading
					ahead = Vector3.new(ahead.X, 0, ahead.Z)
					if ahead.Magnitude > c.MaxLead then
						ahead = ahead.Unit * c.MaxLead
					end
					local angle, r = rng:NextNumber(0, 2 * math.pi), rng:NextNumber(0, Config.Poop.MissRadius)
					local aim = pick.root.Position + Vector3.new(ahead.X, 0, ahead.Z)
						+ Vector3.new(math.cos(angle) * r, 0, math.sin(angle) * r)
					local flatAim = Vector3.new(aim.X, 0, aim.Z)
					if flatAim.Magnitude > Config.Battlefield.Radius then -- never outside the battlefield
						aim = flatAim.Unit * Config.Battlefield.Radius + Vector3.new(0, aim.Y, 0)
					end
					Poop.drop(aim)
				end
			end
		end
	end)
end

return Poop
