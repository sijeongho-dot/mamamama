local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))
local StarterLogic = require(script.Parent:WaitForChild("StarterLogic"))
local TutorialField = require(script.Parent:WaitForChild("TutorialField"))
local UnlockLogic = require(script.Parent:WaitForChild("UnlockLogic"))

local Unlocks = {}

local LABEL_SIZE = UDim2.fromScale(18, 5.2)
local LABEL_UP = 7
local LABEL_DISTANCE = 260
local LABEL_TITLE_COLOR = Color3.fromRGB(255, 215, 100)
local LABEL_READY_COLOR = Color3.fromRGB(140, 255, 160)
local LABEL_LINE_COLOR = Color3.fromRGB(235, 240, 255)
local SPOT_COLOR = Color3.fromRGB(120, 255, 150)
local SPOT_SEE_THROUGH = 0.6
local SPOT_THICKNESS = 0.2
local SPOT_LIFT = 0.06
local ARRIVE_NEAR = 5
local ARRIVE_MAX = 20
local ARRIVE_HIGH = 14
local ZONE_ARRIVE = 16
local NOTICE_GAP = 10
local REFRESH_EVERY = 10
local GUARD_EVERY = 0.4
local PUSH_UP = 3
local STAGE_TAG = "Staged"
local GATE_IN = 5
local GATE_NEAR = 10
local VOID_SLACK = 14
local ISLAND_SHOW_AFTER = 4
local O = Config.OpenArea
local AREAS = {
	Training = { "TrainArea" },
	Shop = { "Base_Shop", "Npc_Shop" },
	Enhance = { "EnhanceStall", "Npc_Enhance" },
	MapBoard = { "MapBoard" },
	Bombs = { "BombStall", "BombDecor", "Npc_BombShop" },
	Rebirth = { "RebirthSign" },
	Ride = { "MountPedestal" },
	FieldEdge = { "BaseDecor", "OwnerSign", "StreetLamp", "MineralGuide" },
}
local HELD = {
	StreetLamp = { "StreetLamps", "StreetLamps", "StreetLamp" },
	ArenaSpotlight = { "StreetLamps", "StreetLamps", "ArenaSpotlight" },
	FarmSpotlight = { "StreetLamps", "StreetLamps", "FarmSpotlight" },
	DefenseGuide = { "DefenseGuides", "DefenseGuide" },
	MineralGuide = { "MineralGuides", "MineralGuide" },
}
local SHOWS = {}
for _, m in ipairs(Config.StarterMissions.Missions) do
	if m.Show then
		SHOWS[StarterLogic.idOf(m)] = m.Show
	end
end
for _, st in ipairs(Config.Training.Stations) do
	table.insert(AREAS.Training, "Train" .. st.Id)
	table.insert(AREAS.Training, "TrainRing" .. st.Id)
end
local GROUP_OF = {}
for _, list in ipairs({ AREAS, SHOWS }) do
	for id, names in pairs(list) do
		for _, name in ipairs(names) do
			GROUP_OF[name] = id
		end
	end
end
local SWITCHES = { "ProximityPrompt", "LayerCollector", "ParticleEmitter", "Beam", "Trail", "Light", "Fire", "Smoke",
	"Sparkles", "Highlight" }
local LOOKS = { Shop = "ShopLook", Rebirth = "RebirthLook", BombShop = "BombLook", MapBoard = "MapLook" }

local hiddenAreas = {}
local quarry = {}
local stageListeners = {}
local kept = {}
local covers = {}
local spots = {}
local lastNotice = {}
local lastStates = {}
local listeners = {}
local areas = {}
local wildTrees = {}

local function chapterOf(profile)
	return UnlockLogic.chapter(profile.Starter)
end

local function stateOf(profile, id)
	if TutorialField.isField() then
		return "Open"
	end
	return UnlockLogic.state(profile.Unlocks, id, profile.DefenseLevel, profile.Passes, chapterOf(profile))
end

local function needOf(profile, id)
	if TutorialField.isField() then
		return nil
	end
	return UnlockLogic.need(profile.Unlocks, id, profile.DefenseLevel, profile.Passes, chapterOf(profile))
end

function Unlocks.state(player, id)
	local profile = PlayerData.get(player)
	return profile and stateOf(profile, id) or "Locked"
end

function Unlocks.has(player, id)
	return Unlocks.state(player, id) == "Open"
end

function Unlocks.usable(player, id)
	local s = Unlocks.state(player, id)
	return s == "Open" or s == "Learning"
end

function Unlocks.shown(player, name)
	local key = GROUP_OF[name]
	if not key or TutorialField.isField() then
		return true
	end
	local profile = PlayerData.get(player)
	if not profile then
		return false
	elseif AREAS[key] then
		local state = stateOf(profile, key)
		return state ~= "Locked" and state ~= "Ready"
	end
	return profile.Graduated or StarterLogic.reached(profile.Starter, key) or Formulas.nextUnlock(profile.Unlocks.Open) == nil
		or (profile.LostOnce == true and table.find(SHOWS[key] or {}, "DefenseGuide") ~= nil)
end

function Unlocks.openFrom(player)
	return player:GetAttribute("FieldOpen") or 0
end

function Unlocks.closedAt(player, position)
	local area = areas[player]
	if not area or not area.zone.Parent then
		return false
	end
	local p = area.zone.CFrame:PointToObjectSpace(position)
	return not Formulas.inRects(area.rects, p.X, p.Z)
end

function Unlocks.learning(player)
	return player:GetAttribute("InTutorial") == true
end

local function pocketClear(index, zone, x, z)
	for _, c in ipairs({ { 0, 0 }, { -1, -1 }, { -1, 1 }, { 1, -1 }, { 1, 1 } }) do
		local w = zone.CFrame:PointToWorldSpace(Vector3.new(x + c[1] * O.WildHalf, 0, z + c[2] * O.WildHalf))
		local other = SafeZones.baseAt(w)
		if other and other ~= index then
			return false
		end
	end
	return true
end

local function wildTreeOf(index)
	if wildTrees[index] ~= nil then
		return wildTrees[index] or nil
	end
	local folder = Bases.folder(index)
	local zone = folder and folder:FindFirstChild("SafeZone")
	if not zone then
		return nil
	end
	local spots = require(script.Parent:WaitForChild("Fruits")).treeSpots()
	if #spots == 0 then
		return nil
	end
	local hx, hz = zone.Size.X / 2, zone.Size.Z / 2
	local best, bestD = nil, math.huge
	for _, at in ipairs(spots) do
		local p = zone.CFrame:PointToObjectSpace(at)
		local flat = Vector3.new(at.X, 0, at.Z).Magnitude
		local inPlot = math.abs(p.X) <= hx + O.CorridorHalf and math.abs(p.Z) <= hz + O.CorridorHalf
		if flat >= Config.Battlefield.Radius + O.WildFieldGap and not inPlot and p.Z >= -hz + O.WildHalf
			and math.abs(p.X) <= hx + O.WildSearch and pocketClear(index, zone, p.X, p.Z) then
			local d = p.X * p.X + (p.Z - hz) ^ 2
			if d < bestD then
				best, bestD = { at = at, x = p.X, z = p.Z }, d
			end
		end
	end
	wildTrees[index] = best or false
	return best
end

function Unlocks.wildTree(player)
	local index = Bases.of(player)
	local t = index and wildTreeOf(index)
	return t and t.at or nil
end

local function whyText(profile, u)
	local need, prev = needOf(profile, u.Id)
	if need == "Prev" and prev then
		return string.format("🔓 먼저 %s 열기", prev.Name)
	elseif need == "Chapter" then
		return string.format("📋 초보 미션 %d장 끝내기", u.After)
	end
	if need == "Level" then
		return string.format("⚔️ 디펜스 %s부터 · 지금 %s", Formulas.levelText(u.Level), Formulas.levelText(profile.DefenseLevel))
	end
	return ""
end

local function say(player, key, title, text)
	if os.clock() - (lastNotice[key] or -math.huge) < NOTICE_GAP then
		return
	end
	lastNotice[key] = os.clock()
	Net.push(player, "Notice", title, text)
end

local start

function Unlocks.check(player, id, quiet)
	local s = Unlocks.state(player, id)
	if s == "Open" or s == "Learning" then
		return true
	end
	local u = Formulas.unlockOf(id)
	if s == "Ready" and u and start(player, id) then
		return true
	end
	local profile = PlayerData.get(player)
	if u and profile and not quiet then
		local key = player.UserId .. id
		if s == "Ready" then
			say(player, key, "🔓 열 수 있어요", string.format("🔓 %s: %s", u.Name, "👉 가면 바로 열려요!"))
		else
			say(player, key, "🔒 잠겨 있어요", string.format("🔒 %s: %s", u.Name, whyText(profile, u)))
		end
	end
	return false
end

function Unlocks.onChange(fn)
	table.insert(listeners, fn)
end

local function changed(player)
	for _, fn in ipairs(listeners) do
		task.spawn(fn, player)
	end
end

local function analytics(player, name)
	pcall(function()
		require(script.Parent:WaitForChild("Analytics")).custom(player, name)
	end)
end

local function switchable(d)
	for _, class in ipairs(SWITCHES) do
		if d:IsA(class) then
			return true
		end
	end
	return false
end

local function hideOne(saved, d)
	if saved[d] then
		return
	end
	if d:IsA("BasePart") then
		saved[d] = { d.Transparency, d.CanCollide, d.CanQuery, d.CanTouch }
		d.Transparency, d.CanCollide, d.CanQuery, d.CanTouch = 1, false, false, false
	elseif d:IsA("Decal") then
		saved[d] = { d.Transparency }
		d.Transparency = 1
	elseif switchable(d) then
		saved[d] = { d.Enabled }
		d.Enabled = false
		if d:IsA("ProximityPrompt") then
			d:SetAttribute("Locked", true)
		end
	end
end

local function showOne(d, k)
	if d:IsA("BasePart") then
		d.Transparency, d.CanCollide, d.CanQuery, d.CanTouch = k[1], k[2], k[3], k[4]
	elseif d:IsA("Decal") then
		d.Transparency = k[1]
	else
		d.Enabled = k[1]
		if d:IsA("ProximityPrompt") then
			d:SetAttribute("Locked", nil)
		end
	end
end

local function unwatch(inst)
	for _, c in ipairs(covers[inst] or {}) do
		c:Disconnect()
	end
	covers[inst] = nil
end

local function cover(inst, on, key, index)
	if (inst:GetAttribute("Hidden") == true) == on and inst:GetAttribute("StageGroup") == key then
		return
	end
	unwatch(inst)
	inst:SetAttribute("StageGroup", key)
	inst:SetAttribute("StageBase", index)
	CollectionService:AddTag(inst, STAGE_TAG)
	if on then
		inst:SetAttribute("Hidden", true)
		local saved = kept[inst] or {}
		kept[inst] = saved
		hideOne(saved, inst)
		for _, d in ipairs(inst:GetDescendants()) do
			hideOne(saved, d)
		end
		covers[inst] = {
			inst.DescendantAdded:Connect(function(d)
				hideOne(saved, d)
			end),
			inst.Destroying:Connect(function()
				unwatch(inst)
				kept[inst] = nil
			end),
		}
	else
		local saved = kept[inst]
		kept[inst] = nil
		for d, k in pairs(saved or {}) do
			showOne(d, k)
		end
		inst:SetAttribute("Hidden", nil)
	end
end

local function instancesOf(folder, name)
	local held = HELD[name]
	if not held then
		local one = folder:FindFirstChild(name)
		return one and { one } or {}
	end
	local holder = folder.Parent and folder.Parent:FindFirstChild(held[1])
	local model = holder and holder:FindFirstChild(held[2] .. folder.Name)
	if not model then
		return {}
	elseif not held[3] then
		return { model }
	end
	local list = {}
	for _, c in ipairs(model:GetChildren()) do
		if c.Name == held[3] then
			table.insert(list, c)
		end
	end
	return list
end

local function setHidden(index, folder, key, names, on)
	hiddenAreas[index][key] = on or nil
	for _, name in ipairs(names) do
		for _, inst in ipairs(instancesOf(folder, name)) do
			cover(inst, on, key, index)
		end
	end
end

local function gateOf(folder)
	local zone = folder and folder:FindFirstChild("SafeZone")
	if not zone then
		return nil
	end
	return zone.CFrame:PointToWorldSpace(Vector3.new(0, -zone.Size.Y / 2, zone.Size.Z / 2 - GATE_IN))
end

local function arrival(folder, u)
	if u.Gate or u.Wild then
		local at = gateOf(folder)
		return at, at and GATE_NEAR
	end
	local inst = u.Where and folder and folder:FindFirstChild(u.Where)
	local cf, size
	if inst and inst:IsA("BasePart") then
		cf, size = inst.CFrame, inst.Size
	elseif inst and inst:IsA("Model") then
		cf, size = inst:GetBoundingBox()
	else
		return nil
	end
	return cf.Position - Vector3.new(0, size.Y / 2, 0), math.min(ARRIVE_MAX, math.max(size.X, size.Z) / 2 + ARRIVE_NEAR)
end

local function label(part, u, state, why)
	local gui = Instance.new("BillboardGui")
	gui.Name = "LockLabel"
	gui.Size = LABEL_SIZE
	gui.MaxDistance = LABEL_DISTANCE
	gui.LightInfluence = 0
	gui.StudsOffsetWorldSpace = Vector3.new(0, LABEL_UP, 0)
	gui.Adornee = part
	local function line(text, top, share, color)
		local l = Instance.new("TextLabel")
		l.BackgroundTransparency = 1
		l.Position = UDim2.fromScale(0, top)
		l.Size = UDim2.fromScale(1, share)
		l.Font = Enum.Font.GothamBlack
		l.TextScaled = true
		l.TextColor3 = color
		l.TextStrokeTransparency = 0.15
		l.Text = text
		l.Parent = gui
		return l
	end
	if state == "Ready" then
		line(string.format("🔓 %s", u.Name), 0, 0.55, LABEL_READY_COLOR)
		line("👉 여기로 오면 열려요!", 0.58, 0.42, LABEL_LINE_COLOR)
	else
		line(string.format("🔒 %s", u.Name), 0, 0.55, LABEL_TITLE_COLOR)
		line(why, 0.58, 0.42, LABEL_LINE_COLOR)
	end
	gui.Parent = part
end

local function caption(index, folder, u, state, why)
	local old = spots[index]
	local key = u and table.concat({ u.Id, state, why or "" }, "|") or nil
	if old and old.Parent and key and old:GetAttribute("Key") == key then
		return
	end
	if old then
		old:Destroy()
		spots[index] = nil
	end
	local at, radius = nil, nil
	if u then
		at, radius = arrival(folder, u)
	end
	if not at then
		return
	end
	local part = Instance.new("Part")
	part.Name = "UnlockSpot"
	part.Shape = Enum.PartType.Cylinder
	part.Size = Vector3.new(SPOT_THICKNESS, radius * 2, radius * 2)
	part.CFrame = CFrame.new(at + Vector3.new(0, SPOT_THICKNESS / 2 + SPOT_LIFT, 0)) * CFrame.Angles(0, 0, math.pi / 2)
	part.Color = SPOT_COLOR
	part.Material = Enum.Material.Neon
	part.Transparency = state == "Ready" and SPOT_SEE_THROUGH or 1
	part.Anchored, part.CanCollide, part.CanQuery, part.CanTouch, part.CastShadow = true, false, false, false, false
	part:SetAttribute("Key", key)
	part:SetAttribute("Unlock", u.Id)
	part:SetAttribute("State", state)
	label(part, u, state, why)
	part.Parent = folder
	spots[index] = part
end

local function focusOf(profile)
	if TutorialField.isField() then
		return nil
	end
	for _, u in ipairs(Config.Unlocks) do
		if stateOf(profile, u.Id) ~= "Open" then
			return u
		end
	end
	return nil
end

local function refresh(index)
	local folder = Bases.folder(index)
	if not folder then
		return
	end
	local ownerId = folder:GetAttribute("OwnerUserId")
	local owner = ownerId and Players:GetPlayerByUserId(ownerId)
	local profile = owner and PlayerData.isLoaded(owner) and PlayerData.get(owner)
	if owner and not profile then
		return
	end
	hiddenAreas[index] = hiddenAreas[index] or {}
	for id, names in pairs(AREAS) do
		local state = profile and stateOf(profile, id) or "Open"
		setHidden(index, folder, id, names, state == "Locked" or state == "Ready")
	end
	local staged = profile ~= nil and not TutorialField.isField()
	local allOpen = staged and (profile.Graduated or Formulas.nextUnlock(profile.Unlocks.Open) == nil)
	for id, names in pairs(SHOWS) do
		local hide = staged and not allOpen and not StarterLogic.reached(profile.Starter, id)
			and not (profile.LostOnce and table.find(names, "DefenseGuide") ~= nil)
		setHidden(index, folder, id, names, hide)
		if owner then
			owner:SetAttribute("Staged" .. id, hide or nil)
		end
	end
	local m = staged and StarterLogic.current(profile.Starter)
	local dig = m and m.Quarry == true and (profile.Starter.Count or 0) < m.Target or false
	if dig ~= (quarry[index] == true) then
		quarry[index] = dig or nil
		for _, fn in ipairs(stageListeners) do
			task.spawn(fn, index)
		end
	end
	local u = profile and focusOf(profile)
	if u and stateOf(profile, u.Id) == "Ready" then
		caption(index, folder, u, "Ready")
	else
		caption(index, folder, nil)
	end
end

local function fieldOpenOf(player)
	if TutorialField.isField() then
		return TutorialField.joinData(player).Replay and 0 or Config.Battlefield.Radius
	end
	return 0
end

local function areaOf(player, profile)
	if TutorialField.isField() or not profile or profile.Graduated then
		return nil
	end
	local index = Bases.of(player)
	local folder = index and Bases.folder(index)
	local zone = folder and folder:FindFirstChild("SafeZone")
	if not zone then
		return nil
	end
	local reach = nil
	for _, u in ipairs(Config.Unlocks) do
		if u.Zone and profile.Unlocks.Open[u.Id] ~= nil then
			reach = math.min(reach or math.huge, u.Zone.To)
		end
	end
	local tree = nil
	if profile.Unlocks.Open.Wild ~= nil then
		local t = wildTreeOf(index)
		tree = t and Vector3.new(t.x, 0, t.z)
	end
	local d = Vector3.new(zone.Position.X, 0, zone.Position.Z).Magnitude
	return { zone = zone, rects = Formulas.openRects(zone.Size.X / 2, zone.Size.Z / 2, d, reach, tree), tree = tree }
end

local function mirror(player)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	local last = lastStates[player]
	local now = {}
	for _, u in ipairs(Config.Unlocks) do
		local state = stateOf(profile, u.Id)
		now[u.Id] = state
		player:SetAttribute("Facility" .. u.Id, state)
		player:SetAttribute("FacilityWhy" .. u.Id, state == "Locked" and needOf(profile, u.Id) or nil)
		if last and last[u.Id] == "Locked" and state == "Ready" then
			Net.push(player, "UnlockReady", u.Id)
		end
	end
	lastStates[player] = now
	player:SetAttribute("FieldOpen", fieldOpenOf(player))
	local area = areaOf(player, profile)
	areas[player] = area
	player:SetAttribute("OpenArea", area and Formulas.rectsText(area.rects) or nil)
	player:SetAttribute("WildSpot", area and area.tree and area.zone.CFrame:PointToWorldSpace(area.tree) or nil)
	player:SetAttribute("InTutorial", (not TutorialField.isField() and not profile.Graduated) or nil)
end

local function refreshBase(player)
	local index = Bases.of(player)
	if index then
		refresh(index)
	end
end

local function arrived(player, u)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return false
	end
	if u.Zone and not u.Gate then
		return Vector3.new(root.Position.X, 0, root.Position.Z).Magnitude <= u.Zone.From + ZONE_ARRIVE
	end
	if not u.Where and not u.Gate then
		return true
	end
	local at, radius = arrival(Bases.folderOf(player), u)
	if not at then
		return false
	end
	local gap = root.Position - at
	return Vector3.new(gap.X, 0, gap.Z).Magnitude <= radius and math.abs(gap.Y) <= ARRIVE_HIGH
end

local function startable(player, profile, u)
	return stateOf(profile, u.Id) == "Ready" and not player:GetAttribute("Racing")
		and (Formulas.unlockedByPass(u, profile.Passes) or arrived(player, u))
end

start = function(player, id)
	local profile = PlayerData.get(player)
	local u = Formulas.unlockOf(id)
	if not profile or not u or TutorialField.isField() or not startable(player, profile, u) then
		return false
	end
	local started = false
	PlayerData.update(player, function(p)
		started = UnlockLogic.start(p.Unlocks, id, p.DefenseLevel, p.Passes, chapterOf(p))
		if started and u.Gift and (u.Gift.Fruit or 0) > 0 then
			p.Fruit = (p.Fruit or 0) + u.Gift.Fruit
		end
	end)
	if not started then
		return false
	end
	if u.Gift and (u.Gift.Fruit or 0) > 0 then
		player:SetAttribute("Fruit", PlayerData.get(player).Fruit)
	end
	mirror(player)
	refreshBase(player)
	Net.push(player, "UnlockStarted", id)
	analytics(player, "UnlockStart_" .. id)
	changed(player)
	return true
end

local function finish(player, u)
	local money = 0
	PlayerData.update(player, function(p)
		money = RewardLogic.apply(p, u.Reward)
	end)
	if money > 0 then
		PlayerData.addMoney(player, money, "reward")
	end
	Net.push(player, "UnlockDone", u.Id, Formulas.starterRewardText(u.Reward))
	analytics(player, "UnlockDone_" .. u.Id)
end

local function onEvent(player, kind, amount)
	local profile = PlayerData.get(player)
	if not profile or TutorialField.isField() or UnlockLogic.current(profile.Unlocks) == nil then
		return
	end
	local list = {}
	PlayerData.update(player, function(p)
		list = UnlockLogic.event(p.Unlocks, kind, amount)
	end)
	if #list == 0 then
		return
	end
	local done = false
	for _, c in ipairs(list) do
		local u = Formulas.unlockOf(c.Id)
		if c.Done then
			done = true
			finish(player, u)
		elseif c.StepDone then
			Net.push(player, "Notice", u.Name, string.format("✅ %d/%d 끝! 다음 단계로", c.Step, #u.Steps))
		end
	end
	if done then
		mirror(player)
		refreshBase(player)
	end
	changed(player)
end

function Unlocks.wants(player, kind)
	local profile = PlayerData.get(player)
	return profile ~= nil and not TutorialField.isField() and UnlockLogic.wants(profile.Unlocks, kind)
end

function Unlocks.event(player, kind, amount)
	onEvent(player, kind, amount)
end

function Unlocks.fieldMined(player, position, amount)
	if not position or (amount or 0) <= 0 or Vector3.new(position.X, 0, position.Z).Magnitude > Config.Battlefield.Radius then
		return
	end
	if Unlocks.wants(player, "FieldMine") then
		onEvent(player, "FieldMine", amount)
	end
	local inner = Formulas.unlockOf("FieldInner")
	if inner and inner.Zone and Unlocks.wants(player, "InnerMine")
		and Vector3.new(position.X, 0, position.Z).Magnitude < inner.Zone.From then
		onEvent(player, "InnerMine", amount)
	end
end

local ZONE_EVENTS = {
	{ Event = "EnterEdge", Id = "FieldEdge" },
	{ Event = "EnterInner", Id = "FieldInner" },
}

local function zoneEvents(player, profile, root)
	local u, step = UnlockLogic.current(profile.Unlocks)
	local m = u and u.Steps[step]
	if not m then
		return
	end
	if m.Event == "EnterWild" then
		local area = areas[player]
		if area and area.tree then
			local p = area.zone.CFrame:PointToObjectSpace(root.Position)
			if math.abs(p.X - area.tree.X) <= O.WildHalf and math.abs(p.Z - area.tree.Z) <= O.WildHalf then
				onEvent(player, "EnterWild", 1)
			end
		end
		return
	end
	local flat = Vector3.new(root.Position.X, 0, root.Position.Z).Magnitude
	if flat > Config.Battlefield.Radius then
		return
	end
	for _, z in ipairs(ZONE_EVENTS) do
		local zu = Formulas.unlockOf(z.Id)
		if m.Event == z.Event and zu and zu.Zone and flat <= zu.Zone.From and flat >= zu.Zone.To then
			onEvent(player, z.Event, 1)
			return
		end
	end
	if m.Event == "ReachAltar" and flat <= Config.Map.KeyZoneRadius then
		onEvent(player, "ReachAltar", 1)
	end
end

local function pushInto(player, root, area)
	local p = area.zone.CFrame:PointToObjectSpace(root.Position)
	local x, z = Formulas.intoRects(area.rects, p.X, p.Z, O.PushIn)
	local w = area.zone.CFrame:PointToWorldSpace(Vector3.new(x, p.Y, z))
	local y = Bases.groundBelow(Vector3.new(w.X, root.Position.Y + 20, w.Z), { player.Character })
	MoveGuard.allow(player)
	player.Character:PivotTo(CFrame.new(w.X, y + PUSH_UP, w.Z) * root.CFrame.Rotation)
	say(player, player.UserId .. "Fog", "🌑 아직 못 가요", "🎓 튜토리얼 동안엔 열린 곳만 다녀요 · 미션을 하면 더 열려요")
end

local function autoStart(player, profile)
	for _, u in ipairs(Config.Unlocks) do
		if startable(player, profile, u) then
			start(player, u.Id)
			return
		end
	end
end

local function guard()
	for _, player in ipairs(Players:GetPlayers()) do
		local character = player.Character
		local root = character and character:FindFirstChild("HumanoidRootPart")
		if root and PlayerData.isLoaded(player) and not player:GetAttribute("Racing") and not TutorialField.isField() then
			local profile = PlayerData.get(player)
			autoStart(player, profile)
			local area = areas[player]
			if area and area.zone.Parent and not player:GetAttribute("HideSeekRoom") then
				local p = area.zone.CFrame:PointToObjectSpace(root.Position)
				if not Formulas.inRects(area.rects, p.X, p.Z, -VOID_SLACK) then
					pushInto(player, root, area)
				else
					zoneEvents(player, profile, root)
				end
			end
		end
	end
end

function Unlocks.refreshPlayer(player)
	mirror(player)
	refreshBase(player)
	changed(player)
end

function Unlocks.restage(player)
	refreshBase(player)
end

function Unlocks.gate(player)
	return gateOf(Bases.folderOf(player))
end

function Unlocks.homeQuarry(index)
	return TutorialField.isField() or quarry[index] == true
end

function Unlocks.onStage(fn)
	table.insert(stageListeners, fn)
end

function Unlocks.setAll(player, open)
	PlayerData.update(player, function(p)
		p.Unlocks.Open = {}
		p.Graduated = open == true
		if open then
			UnlockLogic.openAll(p.Unlocks)
		end
	end)
	lastStates[player] = nil
	Unlocks.refreshPlayer(player)
end

function Unlocks.setFirst(player, n)
	PlayerData.update(player, function(p)
		p.Unlocks.Open = {}
		p.Graduated = false
		for i = 1, math.min(n, #Config.Unlocks) do
			p.Unlocks.Open[Config.Unlocks[i].Id] = true
		end
	end)
	lastStates[player] = nil
	Unlocks.refreshPlayer(player)
end

local function showIsland(player)
	local profile = PlayerData.get(player)
	if not profile or not profile.Graduated or profile.IslandShown or profile.Stash or TutorialField.isField() then
		return
	end
	PlayerData.update(player, function(p)
		p.IslandShown = true
	end)
	Net.push(player, "IslandCinematic")
end

function Unlocks.graduate(player)
	local profile = PlayerData.get(player)
	if not profile or profile.Graduated or TutorialField.isField() then
		return
	end
	PlayerData.update(player, function(p)
		p.Graduated = true
		UnlockLogic.graduate(p.Unlocks)
	end)
	lastStates[player] = nil
	Unlocks.refreshPlayer(player)
	analytics(player, "Graduated")
	showIsland(player)
end

function Unlocks.passBought(player, key)
	local opens = false
	for _, u in ipairs(Config.Unlocks) do
		if u.Pass == key then
			opens = true
		end
	end
	if opens then
		mirror(player)
		refreshBase(player)
		changed(player)
	end
end

function Unlocks.init()
	Net.onRequest("UnlockStart", { "string" }, function(player, id)
		start(player, id)
	end)
	require(script.Parent:WaitForChild("Rewards")).onAdd(onEvent)
	ProximityPromptService.PromptTriggered:Connect(function(prompt, player)
		local look = LOOKS[prompt:GetAttribute("Kind")]
		if look and prompt:GetAttribute("Base") == Bases.of(player) then
			onEvent(player, look, 1)
		end
	end)
	PlayerData.onLoaded(function(player, profile)
		if profile and not profile.Graduated and (profile.Rebirths or 0) > 0 and not TutorialField.isField() then
			PlayerData.update(player, function(p)
				p.Graduated = true
				UnlockLogic.openAll(p.Unlocks)
			end)
		elseif profile and profile.Graduated and Formulas.nextUnlock(profile.Unlocks.Open) ~= nil then
			PlayerData.update(player, function(p)
				UnlockLogic.graduate(p.Unlocks)
			end)
		end
		mirror(player)
		refreshBase(player)
		task.delay(ISLAND_SHOW_AFTER, showIsland, player)
		for _, name in ipairs({ "DefenseLevel", "Rebirths" }) do
			player:GetAttributeChangedSignal(name):Connect(function()
				if PlayerData.isLoaded(player) then
					mirror(player)
					refreshBase(player)
					changed(player)
				end
			end)
		end
	end)
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			hiddenAreas[index] = {}
			folder:GetAttributeChangedSignal("OwnerUserId"):Connect(function()
				refresh(index)
			end)
			folder.ChildAdded:Connect(function(child)
				local key = GROUP_OF[child.Name]
				if key and hiddenAreas[index][key] then
					cover(child, true, key, index)
				end
			end)
		end
	end
	local function watchHolder(holder)
		for _, held in pairs(HELD) do
			if held[1] == holder.Name then
				holder.ChildAdded:Connect(function(model)
					local index = tonumber(string.match(model.Name, "Base(%d+)$"))
					if index then
						task.defer(refresh, index)
					end
				end)
				return
			end
		end
	end
	local first = Bases.folder(1)
	local map = first and first.Parent
	if map then
		for _, c in ipairs(map:GetChildren()) do
			watchHolder(c)
		end
		map.ChildAdded:Connect(watchHolder)
	end
	Players.PlayerRemoving:Connect(function(player)
		lastStates[player] = nil
		areas[player] = nil
		local id = tostring(player.UserId)
		for key in pairs(lastNotice) do
			if string.sub(key, 1, #id) == id then
				lastNotice[key] = nil
			end
		end
	end)
	task.spawn(function()
		while true do
			task.wait(GUARD_EVERY)
			guard()
		end
	end)
	task.spawn(function()
		while true do
			task.wait(REFRESH_EVERY)
			for _, player in ipairs(Players:GetPlayers()) do
				if PlayerData.isLoaded(player) then
					mirror(player)
				end
			end
			for index = 1, Config.Map.BaseCount do
				refresh(index)
			end
		end
	end)
end

return Unlocks
