--[[
Training (2026-10-04, design 6.3): the pickaxe's power and speed, the bag, the slap and the move speed are trained, not
bought ("차라리 신체강화나 곡괭이 강화 같은걸 기지 내에서 훈련으로 강화시킬 수 있게하자 … 해당 지역에서 훈련하면 계속 조금씩
경험치 얻어서 강화되는 식" → 훈련만 · 서 있기만).

- Every base gets the four stations of Config.Training.Stations at their plot spots, side by side in one training
  ground (2026-10-04: a mat under all four and one big "💪 훈련장" over them): the model from ServerStorage.Assets
  (tools/make_training.py; its pivot set to its bottom middle) or a plain stand-in, a glowing ring on the ground beside it
  showing how close is close enough, a name. The treadmill gets an invisible deck to run on (its mesh doesn't collide).
- Every CheckEvery seconds, a player standing within Range of a station of their own base, or of a Roblox friend's base
  (2026-10-04, 👥), trains that station's tracks: the seconds there add up in profile.Training[track] (changed in place:
  no change event every second), at Formulas.trainRate (🔧 the station's gear level, the boost, a friend within
  FriendRange), and at Formulas.trainSeconds(track, level) the level goes up (PlayerData.update; Rewards "Upgrade" for
  the daily missions; a notice). A power step waits once the tier's ten are done (the next pickaxe is still bought at
  the shop). Every minute there counts for the "TrainMinutes" missions.
- A training boost (Net request BuyTrainBoost, standing at a station; 2026-10-04: was at the shop, now the ⛏️ 곡괭이 상점):
  Config.Training.BoostMultiplier times as fast for BoostMinutes, for Formulas.trainBoostPrice(defense level); bought
  again it adds on.
- 🔧 Gear (Net request BuyTrainGear, standing at the station): the station's next level, Formulas.trainGearPrice.
- Player attributes for the screens: TrainStation (the Id there now, nil when not), TrainAt / TrainOut (that station's
  spot and the way its plot faces out: the training motions, StarterPlayerScripts/TrainingFx), TrainXP_<track> (seconds
  trained toward the next level), TrainBoostUntil (server time), TrainFriend (a friend near), TrainGear_<station Id>.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local Friends = require(script.Parent:WaitForChild("Friends"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))

local Training = {}

-- display only
local RING_THICKNESS = 0.15
local RING_TRANSPARENCY = 0.55
local STAND_IN_SIZE = Vector3.new(5, 4, 5)
local REACH_Y = 8 -- studs above or below a station still count
local DECK_SIZE = Vector3.new(2.8, 0.62, 5.6) -- the treadmill's deck and belt (tools/make_training.py)
local MAT_MARGIN = 3 -- studs the training ground's mat reaches past the rings
local MAT_THICKNESS = 0.1
local MAT_COLOR = Color3.fromRGB(95, 80, 130)
local MAT_TRANSPARENCY = 0.35
local AREA_TITLE_COLOR = Color3.fromRGB(200, 170, 255)
local GAIN_COLOR = Color3.fromRGB(235, 245, 255)
local PROP_CLEARANCE = 3 -- studs past a ring: the base's decor props (MapBuilder BaseProps) nearer than this go
local SECONDS_A_MINUTE = 60

local FX_GAP = 1 -- seconds at least between two training level-up shows of one player's track (a whole step: always)
local lastFx = {} -- [userId .. track] = os.clock() of its last show

local T = Config.Training
local stations = {} -- [base number] = { { config, position, out } }
local minuteClock = {} -- [player] = seconds trained toward the next "TrainMinutes" minute

local function say(player, text)
	Net.push(player, "Notice", nil, text)
end

local REAL_FIELDS = { Power = "PickaxePower", Speed = "PickaxeSpeed", Slap = "Slap", MoveSpeed = "MoveSpeed", Bag = "Bag" }

local function mirrorReal(player, profile)
	profile = profile or PlayerData.get(player)
	if not profile then
		return
	end
	local real = Formulas.trained(profile.Upgrades, profile.Training)
	for track, field in pairs(REAL_FIELDS) do
		player:SetAttribute("TrainReal_" .. track, real[field])
	end
end

local function assets()
	return ServerStorage:FindFirstChild("Assets")
end

local function makeStation(folder, st, at, look)
	local source = assets() and assets():FindFirstChild(st.Model, true)
	local model
	if source then
		local copy = source:Clone()
		if copy:IsA("BasePart") then -- an imported mesh by itself: in a model, to set the pivot
			model = Instance.new("Model")
			copy.Parent = model
		else
			model = copy
		end
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") then
				d.Anchored = true
				d.CanTouch = false
				if st.Id == "Treadmill" then -- (stood on: the deck below does it, flat)
					d.CanCollide = false
				end
			end
		end
		-- an imported mesh's pivot is its middle: the bottom middle stands on the ground
		local cf, size = model:GetBoundingBox()
		model.PrimaryPart = nil
		model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
	else
		model = Instance.new("Model")
		local part = Instance.new("Part")
		part.Name = "StandIn"
		part.Size = st.Id == "Treadmill" and DECK_SIZE or STAND_IN_SIZE
		part.Color = Color3.fromRGB(table.unpack(st.Color))
		part.Anchored = true
		part.CanCollide = st.Id ~= "Treadmill"
		part.Parent = model
		model.WorldPivot = CFrame.new(0, -part.Size.Y / 2, 0)
	end
	model.Name = "Train" .. st.Id
	model:SetAttribute("TrainStation", st.Id)
	model:PivotTo(CFrame.lookAt(at, at + look))
	if st.Id == "Treadmill" then -- something flat to run on (the model's long side is along its facing)
		local deck = Instance.new("Part")
		deck.Name = "Deck"
		deck.Size = DECK_SIZE
		deck.CFrame = CFrame.lookAt(at, at + look) * CFrame.new(0, DECK_SIZE.Y / 2, 0)
		deck.Transparency = 1
		deck.Anchored, deck.CanCollide, deck.CanQuery, deck.CanTouch = true, true, false, false
		deck.Parent = model
	end
	-- the ring: how close is close enough (beside the model, so a screen can rock the model: the dummy)
	local ring = Instance.new("Part")
	ring.Name = "TrainRing" .. st.Id
	ring.Shape = Enum.PartType.Cylinder
	ring.Size = Vector3.new(RING_THICKNESS, T.Range * 2, T.Range * 2)
	ring.CFrame = CFrame.new(at + Vector3.new(0, RING_THICKNESS / 2 + 0.02, 0)) * CFrame.Angles(0, 0, math.rad(90))
	ring.Color = Color3.fromRGB(table.unpack(st.Color))
	ring.Material = Enum.Material.Neon
	ring.Transparency = RING_TRANSPARENCY
	ring.Anchored, ring.CanCollide, ring.CanQuery, ring.CanTouch, ring.CastShadow = true, false, false, false, false
	ring.Parent = folder
	model.Parent = folder
	Bases.title(model, string.format("%s · 💪 훈련", st.Name), Color3.fromRGB(table.unpack(st.Color)))
	local gains = {}
	for _, id in ipairs(st.Tracks) do
		table.insert(gains, T.Tracks[id].Name)
	end
	Bases.subtitle(model, #gains > 1 and string.format("🧍 옆에 서 있으면 %s · %s UP!", gains[1], gains[2])
		or string.format("🧍 옆에 서 있으면 %s UP!", gains[1]), GAIN_COLOR)
	return model
end

local function buildBase(index, folder)
	local zone = folder:FindFirstChild("SafeZone")
	if not zone then
		return
	end
	local flat = Vector3.new(zone.Position.X, 0, zone.Position.Z)
	if flat.Magnitude < 1e-3 then
		return
	end
	local out = flat.Unit
	local right = out:Cross(Vector3.yAxis).Unit
	local front = flat - out * Config.Map.PlotDepth / 2
	stations[index] = {}
	local oldArea = folder:FindFirstChild("TrainArea")
	if oldArea then
		oldArea:Destroy()
	end
	local lo, hi, groundSum = Vector2.new(math.huge, math.huge), Vector2.new(-math.huge, -math.huge), 0
	for _, st in ipairs(T.Stations) do
		lo = Vector2.new(math.min(lo.X, st.Spot[1]), math.min(lo.Y, st.Spot[2]))
		hi = Vector2.new(math.max(hi.X, st.Spot[1]), math.max(hi.Y, st.Spot[2]))
		for _, name in ipairs({ "Train" .. st.Id, "TrainRing" .. st.Id }) do
			local old = folder:FindFirstChild(name)
			if old then
				old:Destroy()
			end
		end
		local spot = front + right * st.Spot[1] + out * st.Spot[2]
		local ground = Bases.groundBelow(Vector3.new(spot.X, zone.Position.Y, spot.Z), { zone })
		local at = Vector3.new(spot.X, ground, spot.Z)
		makeStation(folder, st, at, -out)
		table.insert(stations[index], { config = st, position = at, out = out })
		groundSum += ground
	end
	-- (2026-10-04, the stations two by two by the spawn pad) the base's decor (MapBuilder's rocks, bushes and nests along
	-- the side fence) never stands in a station's ring: what does is taken away here
	local props = folder:FindFirstChild("BaseProps")
	for _, prop in ipairs(props and props:GetChildren() or {}) do
		local cf = prop:IsA("Model") and prop:GetBoundingBox() or prop:IsA("BasePart") and prop.CFrame
		if cf then
			for _, s in ipairs(stations[index]) do
				local gap = Vector3.new(cf.Position.X - s.position.X, 0, cf.Position.Z - s.position.Z).Magnitude
				if gap < T.Range + PROP_CLEARANCE then
					prop:Destroy()
					break
				end
			end
		end
	end
	-- the training ground: one mat under the four, one big name over it
	local pad = T.Range + MAT_MARGIN
	local mid = (lo + hi) / 2
	local spot = front + right * mid.X + out * mid.Y
	local area = Instance.new("Model")
	area.Name = "TrainArea"
	local mat = Instance.new("Part")
	mat.Name = "Mat"
	mat.Size = Vector3.new(hi.X - lo.X + 2 * pad, MAT_THICKNESS, hi.Y - lo.Y + 2 * pad)
	mat.CFrame = CFrame.lookAt(Vector3.new(spot.X, groundSum / #T.Stations + MAT_THICKNESS / 2 + 0.01, spot.Z),
		Vector3.new(spot.X, groundSum / #T.Stations + MAT_THICKNESS / 2 + 0.01, spot.Z) + out) -- (X across, Z in)
	mat.Color = MAT_COLOR
	mat.Material = Enum.Material.SmoothPlastic
	mat.Transparency = MAT_TRANSPARENCY
	mat.Anchored, mat.CanCollide, mat.CanQuery, mat.CanTouch, mat.CastShadow = true, false, false, false, false
	mat.Parent = area
	area.Parent = folder
	Bases.title(area, "💪 훈련장", AREA_TITLE_COLOR, true)
	Bases.subtitle(area, "🧍 기구 옆에 서 있기만 해도 저절로 세져요!", GAIN_COLOR)
end

-- may this player train at base `index`: their own, or a friend's who is here (👥)
local function mayTrainAt(player, index)
	if player:GetAttribute("Base") == index then
		return true
	end
	local folder = Bases.folder(index)
	local owner = folder and Players:GetPlayerByUserId(folder:GetAttribute("OwnerUserId") or 0)
	return owner ~= nil and owner:GetAttribute("Base") == index and Friends.known(player, owner)
end

local function autoOn(player)
	return player:GetAttribute("AutoMineOff") ~= true
		and (player:GetAttribute("PassAutoMine") == true or player:GetAttribute("AutoFruit") == true)
end

-- the station I stand at (of my base or a friend's), or nil
local function stationAt(player)
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not root or not humanoid or humanoid.Health <= 0 or player:GetAttribute("Riding") or autoOn(player) then
		return nil
	end
	for index, list in pairs(stations) do
		for _, s in ipairs(list) do
			local d = root.Position - s.position
			if Vector3.new(d.X, 0, d.Z).Magnitude <= T.Range and math.abs(d.Y) <= REACH_Y then
				if not Unlocks.check(player, "Training", true) then
					return nil
				end
				return mayTrainAt(player, index) and s or nil -- (stations never overlap)
			end
		end
	end
	return nil
end

-- a Roblox friend within FriendRange of me
local function friendNear(player)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return false
	end
	for _, other in ipairs(Players:GetPlayers()) do
		local theirs = other ~= player and other.Character and other.Character:FindFirstChild("HumanoidRootPart")
		if theirs and (theirs.Position - root.Position).Magnitude <= T.FriendRange and Friends.known(player, other) then
			return true
		end
	end
	return false
end

-- one level up on a track (the profile's field), told to the player
local function levelUp(player, track)
	local name = T.Tracks[track].Name
	PlayerData.update(player, function(p)
		local u = p.Upgrades
		if track == "Power" then
			u.PickaxePower += 1
		elseif track == "Speed" then
			u.PickaxeSpeed += 1
		elseif track == "Slap" then
			u.Slap += 1
		elseif track == "MoveSpeed" then
			u.MoveSpeed += 1
		else
			u.Bag += 1
		end
	end)
	Rewards.add(player, "Upgrade", 1) -- daily missions, the tutorial
	local profile = PlayerData.get(player)
	local trainNow = Formulas.trainShown(track, (Formulas.trainLevel(profile.Upgrades, track)), 0)
	local real = Formulas.trained(profile.Upgrades, profile.Training)[REAL_FIELDS[track]]
	Net.push(player, "Notice", "💪 능력 UP!", string.format("%s Lv %d · %s", name, trainNow, Formulas.trainValueText(track, real)))
	local tier = profile.Upgrades.PickaxeTier
	local need = Formulas.powerStepsNeed(tier)
	if track == "Power" and profile.Upgrades.PickaxePower == need and Formulas.nextPickaxePrice(tier, profile.DefenseLevel) then
		local nextTier = tier + 1
		if not Formulas.pickaxeOpen(nextTier, profile.DefenseLevel) then
			say(player, string.format("⛏️ 파워 강화를 모두 했어요! 🔒 다음 곡괭이는 ⚔️ 디펜스 %s에 열려요",
				Formulas.levelText(Formulas.pickaxeNeedLevel(nextTier))))
		elseif Unlocks.has(player, "Shop") then
			Net.push(player, "CocoCard", { "⛏️ 파워 훈련 끝!", string.format("💥 이제 ⛏️ %d티어 곡괭이를 살 수 있어요", nextTier),
				"👉 ⛏️ 곡괭이 상점으로 가서 곡괭이를 강화해요!" }, "Base_Shop")
		end
	end
end

local function step(player)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	local s = stationAt(player)
	local st = s and s.config
	player:SetAttribute("TrainStation", st and st.Id or nil)
	player:SetAttribute("TrainAt", s and s.position or nil)
	player:SetAttribute("TrainOut", s and s.out or nil)
	if not st then
		player:SetAttribute("TrainFriend", nil)
		return
	end
	profile.Training = profile.Training or {}
	profile.TrainGear = profile.TrainGear or {}
	local boosted = (player:GetAttribute("TrainBoostUntil") or 0) > Workspace:GetServerTimeNow()
	local withFriend = friendNear(player)
	player:SetAttribute("TrainFriend", withFriend or nil)
	Rewards.add(player, "TrainStand", T.CheckEvery)
	local gain = T.CheckEvery * Formulas.trainRate(profile.TrainGear[st.Id] or 0, boosted, withFriend)
	local trained = false
	for _, track in ipairs(st.Tracks) do
		local level, canGo = Formulas.trainLevel(profile.Upgrades, track)
		local need = canGo and Formulas.trainSeconds(track, level)
		if need then
			trained = true
			local before = profile.Training[track] or 0
			local xp = before + gain
			if xp >= need then
				profile.Training[track] = 0 -- (the rest is not carried: every level is earned on its own)
				levelUp(player, track)
				local now = Formulas.trainLevel(PlayerData.get(player).Upgrades, track)
				Net.pushAll("TrainLevelFx", player.UserId, track, (Formulas.trainShown(track, now, 0)), true)
			else
				profile.Training[track] = xp -- (in place: saved with the profile, no change event)
				-- (2026-10-04, "훈련레벨을 아주아주 많이 늘리고, 그에따라 레벨업 하는게 눈에 잘 띄게") a training level within
				-- the step reached (Config.Training.TopLevel): shown on every screen near
				local was = Formulas.trainShown(track, level, before)
				local is = Formulas.trainShown(track, level, xp)
				-- (no faster than FX_GAP seconds a track: the first power levels take a few seconds each)
				local key = player.UserId .. track
				if is > was and os.clock() - (lastFx[key] or -math.huge) >= FX_GAP then
					lastFx[key] = os.clock()
					Net.pushAll("TrainLevelFx", player.UserId, track, is, false)
				end
			end
		end
		player:SetAttribute("TrainXP_" .. track, math.floor(profile.Training[track] or 0))
	end
	mirrorReal(player, profile)
	if trained then -- (the "TrainMinutes" missions: real minutes there, while something still trains)
		minuteClock[player] = (minuteClock[player] or 0) + T.CheckEvery
		if minuteClock[player] >= SECONDS_A_MINUTE then
			minuteClock[player] -= SECONDS_A_MINUTE
			Rewards.add(player, "TrainMinutes", 1)
		end
	end
end

local function buyBoost(player)
	if not Unlocks.check(player, "Training") then
		return
	end
	local profile = PlayerData.get(player)
	if not profile or not stationAt(player) then
		return say(player, "💪 훈련 기구 원 안에 서서 사요")
	end
	local price = Formulas.trainBoostPrice(profile.DefenseLevel)
	if not PlayerData.spendMoney(player, price, "trainBoost") then
		return say(player, string.format("💰 돈이 모자라요 (%s원 필요)", Formulas.shortNumber(price)))
	end
	local now = Workspace:GetServerTimeNow()
	local untilTime = math.max(player:GetAttribute("TrainBoostUntil") or 0, now) + T.BoostMinutes * 60
	player:SetAttribute("TrainBoostUntil", untilTime)
	profile.TrainBoostUntil = untilTime -- (kept across a rejoin)
	Net.push(player, "Notice", "💪 훈련 2배!", string.format("💪 %d분 동안 훈련이 %d배 빨라요", T.BoostMinutes, T.BoostMultiplier))
end

-- 🔧 the next gear level of the station I stand at
local function buyGear(player, stationId)
	if not Unlocks.check(player, "Training") then
		return
	end
	local profile = PlayerData.get(player)
	local s = stationAt(player)
	if not profile or not s or s.config.Id ~= stationId then
		return say(player, "💪 훈련 기구 원 안에 서서 강화해요")
	end
	local level = (profile.TrainGear or {})[stationId] or 0
	local price = Formulas.trainGearPrice(level, profile.DefenseLevel)
	if not price then
		return say(player, "이미 최고 단계예요")
	end
	if not PlayerData.spendMoney(player, price, "trainGear") then
		return say(player, string.format("💰 돈이 모자라요 (%s원 필요)", Formulas.shortNumber(price)))
	end
	PlayerData.update(player, function(p)
		p.TrainGear = p.TrainGear or {}
		p.TrainGear[stationId] = level + 1
	end)
	player:SetAttribute("TrainGear_" .. stationId, level + 1)
	Net.push(player, "Notice", "🔧 훈련장 강화!", string.format("%s Lv.%d · 훈련 +%d%%", s.config.Name, level + 1,
		math.floor(T.Gear.PerLevel * (level + 1) * 100 + 0.5)))
end

function Training.init()
	Workspace:WaitForChild("Map")
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			buildBase(index, folder)
		end
	end
	PlayerData.onLoaded(function(player, profile)
		local untilTime = profile.TrainBoostUntil or 0
		player:SetAttribute("TrainBoostUntil", untilTime > Workspace:GetServerTimeNow() and untilTime or nil)
		for track in pairs(T.Tracks) do
			player:SetAttribute("TrainXP_" .. track, math.floor(profile.Training and profile.Training[track] or 0))
		end
		for _, st in ipairs(T.Stations) do
			player:SetAttribute("TrainGear_" .. st.Id, (profile.TrainGear or {})[st.Id] or 0)
		end
		mirrorReal(player, profile)
	end)
	PlayerData.onChanged(mirrorReal)
	Players.PlayerRemoving:Connect(function(player)
		for track in pairs(T.Tracks) do
			lastFx[player.UserId .. track] = nil
		end
		minuteClock[player] = nil
	end)
	Net.onRequest("BuyTrainBoost", {}, buyBoost)
	Net.onRequest("BuyTrainGear", { "string" }, buyGear)
	task.spawn(function()
		while true do
			task.wait(T.CheckEvery)
			local started = os.clock()
			for _, player in ipairs(Players:GetPlayers()) do
				local ok, err = pcall(step, player)
				if not ok then
					warn("[Training] " .. tostring(err))
				end
			end
			if Training.meter then -- (Watchdog: the "server is slow" banner names what took the time)
				Training.meter("loop", "Training", os.clock() - started)
			end
		end
	end)
end

return Training
