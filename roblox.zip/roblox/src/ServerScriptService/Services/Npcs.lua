--[[
Npcs: shopkeeper dinos, display only. When the server starts, a dino stands inside every base's
shop stall (Base_Shop), key stall (KeyStall, Shop), enhance stall (EnhanceStall, Enhance) and bomb stall
(BombStall, Bombs) while a
player has that base (2026-10-01: empty bases stand empty; base folder attribute OwnerUserId), sized
to fit behind the counter, and a bigger one beside the central board (KeyZone.Zone_Leaderboard).
They are copies of the species' models (ServerStorage.Assets.Dino_<Id>), anchored and not in the
way (no collisions, no clicks), in the base folder as Npc_<kind>. Each wears its T-shirt
(ServerStorage.Assets.NpcShirt_<Id>, tools/make_npc_shirts.py). Imported files do not keep their
origins alike (a rigged dino and a plain mesh), so the shirt is fitted by boxes (NpcShirtFit, written
by the same tool): scaled like the dino was on import, turned upright if it came in lying down, and
moved so its box sits where it did on the dino in Blender (the dino's front found from its Head
bone). Without the shirt asset the NPC stands bare; one NPC going wrong never stops the others.
NPCs growl now and then on the clients.

Each NPC model has attributes Npc (the place: "Shop", "KeyShop", "Enhance", "Board"), NpcBase (the
base number; none for the board) and Rest (where it stands). Clients (StarterPlayerScripts/Npcs)
move them: breathing and looking around always, and a motion with a speech bubble every time the
player uses that place's prompt.

The central board gets a "게시판 보기" prompt (Kind "Board", no base) that opens the server board
window on the client (StarterPlayerScripts/Npcs).
]]

local ServerStorage = game:GetService("ServerStorage")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local ShirtFit = require(script.Parent:WaitForChild("NpcShirtFit"))

local Npcs = {}

-- display only
local STALL_NPCS = { -- the stall (in the base folder) -> the dino inside it
	{ Kind = "Shop", Stall = "Base_Shop", Species = "Iguanodon" },
	{ Kind = "KeyShop", Stall = "KeyStall", Species = "Raptor" },
	{ Kind = "Enhance", Stall = "EnhanceStall", Species = "Stego" },
	{ Kind = "BombShop", Stall = "BombStall", Species = "Pteranodon" }, -- (2026-10-01) the bomb stall (Bombs), in its orange vest
}
local BOARD_SPECIES = "Trike"
-- (the stalls are 1.5 times their modeled size, Bases.bigStall: 13.5 wide, about 8 under the awning)
local STALL_NPC_HEIGHT = 6.6 -- just under the awning, the head and shoulders well over the counter
local STALL_NPC_LENGTH = 10 -- snout to tail: long-tailed dinos would come out tiny if the tail had to fit
local STALL_NPC_BACK = 1.8 -- studs from the stall's middle toward its back wall
local STALL_NPC_BACK_PLAIN = 2.5 -- behind the plain counter of a stall made without Base_Shop
local STALL_DECK = 0.55 -- the stall's wooden deck under the NPC's feet
local BOARD_NPC_HEIGHT = 7
local BOARD_NPC_LENGTH = 8
local BOARD_NPC_SIDE = 3 -- studs past the board's edge
local BOARD_NPC_FRONT = 1.5 -- studs in front of the board
local BOARD_RANGE = 9 -- the board prompt's reach (2026-10-02: was 14, "바로 앞에가야 뜨게")
local BOARD_TITLE_COLOR = Color3.fromRGB(245, 235, 210)
local BOARD_TITLE_HEIGHT = 4 -- studs over the board for its name (Bases.title: 2)

local SHIRT_SIZE_TOLERANCE = 0.2 -- a shirt box this far off the expected shape is turned or reported
local SHIRT_TURNS = { -- tried when the shirt came in lying on a side
	CFrame.Angles(math.pi / 2, 0, 0), CFrame.Angles(-math.pi / 2, 0, 0),
	CFrame.Angles(0, 0, math.pi / 2), CFrame.Angles(0, 0, -math.pi / 2), CFrame.Angles(0, math.pi / 2, 0),
}

local warned = false
local warnedShirt = {}

local function assets()
	return ServerStorage:FindFirstChild("Assets")
end

-- the world box (middle, size) around every part of inst, whatever its pivot says
local function partsBox(inst)
	local lo, hi = Vector3.one * math.huge, -Vector3.one * math.huge
	local list = inst:GetDescendants()
	table.insert(list, inst)
	for _, p in ipairs(list) do
		if p:IsA("BasePart") then
			local h = p.Size / 2
			for _, c in ipairs({ Vector3.new(-1, -1, -1), Vector3.new(-1, -1, 1), Vector3.new(-1, 1, -1), Vector3.new(-1, 1, 1),
				Vector3.new(1, -1, -1), Vector3.new(1, -1, 1), Vector3.new(1, 1, -1), Vector3.new(1, 1, 1) }) do
				local w = p.CFrame * (h * c)
				lo, hi = lo:Min(w), hi:Max(w)
			end
		end
	end
	if lo.X > hi.X then
		return nil
	end
	return (lo + hi) / 2, hi - lo
end

local function shapeError(size, want)
	return math.max(math.abs(size.X - want.X) / want.X, math.abs(size.Y - want.Y) / want.Y,
		math.abs(size.Z - want.Z) / want.Z)
end

-- puts the species' T-shirt on the dino copy (both still where the Assets folder has them)
local function wearShirt(model, dino, species)
	local fit = ShirtFit[species]
	local source = assets():FindFirstChild("NpcShirt_" .. species, true)
	if not source or not fit then
		if not warnedShirt[species] then
			warnedShirt[species] = true
			warn("[Npcs] ServerStorage.Assets에 NpcShirt_" .. species .. "이 없어 티셔츠 없이 세웁니다")
		end
		return
	end
	local dinoMid, dinoSize = partsBox(dino)
	local shirt = Instance.new("Model")
	shirt.Name = "Shirt"
	source:Clone().Parent = shirt
	local mid, size = partsBox(shirt)
	if not dinoMid or not mid then
		shirt:Destroy()
		return
	end
	-- the dino's front: from the middle toward its Head bone (-Z when there is none)
	local front = Vector3.new(0, 0, -1)
	local head = dino:FindFirstChild("Head", true)
	if head and head:IsA("Bone") then
		local d = head.WorldPosition - dinoMid
		d = Vector3.new(d.X, 0, d.Z)
		if d.Magnitude > 0.1 then
			front = d.Unit
		end
	end
	local facing = CFrame.lookAt(Vector3.zero, front) -- turns "looking along -Z" into the dino's facing
	local k = dinoSize.Y / fit.DinoSize.Y -- how much the import scaled the dino
	local want = facing:VectorToWorldSpace(fit.Size * k)
	want = Vector3.new(math.abs(want.X), math.abs(want.Y), math.abs(want.Z))
	-- came in lying on a side: stand it up the way that matches the expected box best
	if shapeError(size, want) > SHIRT_SIZE_TOLERANCE then
		local pivot = shirt:GetPivot()
		local best, bestError = nil, shapeError(size, want)
		for _, turn in ipairs(SHIRT_TURNS) do
			shirt:PivotTo(CFrame.new(mid) * turn * CFrame.new(-mid) * pivot)
			local _, s = partsBox(shirt)
			local e = shapeError(s, want)
			if e < bestError then
				best, bestError = turn, e
			end
		end
		shirt:PivotTo(best and (CFrame.new(mid) * best * CFrame.new(-mid) * pivot) or pivot)
		mid, size = partsBox(shirt)
	end
	local ratio = (want.X + want.Y + want.Z) / (size.X + size.Y + size.Z)
	if math.abs(ratio - 1) > 0.03 then
		shirt:ScaleTo(ratio)
		mid, size = partsBox(shirt)
	end
	if shapeError(size, want) > SHIRT_SIZE_TOLERANCE then
		warn(string.format("[Npcs] NpcShirt_%s의 모양이 예상과 달라요 (크기 %s, 예상 %s). 다시 불러와 주세요",
			species, tostring(size), tostring(want)))
	end
	local target = dinoMid + facing:VectorToWorldSpace(fit.Offset * k)
	shirt:PivotTo(shirt:GetPivot() + (target - mid))
	shirt.Parent = model
end

-- a copy of the species' model scaled to fit in height × length, its pivot at the bottom middle
-- (upright, the dino looking along the pivot's front)
local function npcModel(species, height, length)
	local source = assets() and assets():FindFirstChild("Dino_" .. species, true)
	if not source then
		if not warned then
			warned = true
			warn("[Npcs] ServerStorage.Assets에 공룡 모델이 없어 NPC를 못 세웠습니다 (Dino_" .. species .. ")")
		end
		return nil
	end
	local model = Instance.new("Model")
	local dino = source:Clone()
	dino.Parent = model
	local ok, err = pcall(wearShirt, model, dino, species)
	if not ok then
		warn("[Npcs] 티셔츠를 입히지 못했어요 (" .. species .. "): " .. tostring(err))
	end
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored = true
			d.CanCollide = false
			d.CanQuery = false
			d.CanTouch = false
		elseif d:IsA("Script") or d:IsA("LocalScript") then
			d:Destroy()
		end
	end
	local _, size = model:GetBoundingBox()
	local scale = math.min(height / math.max(size.Y, 0.1), length / math.max(size.X, size.Z, 0.1))
	model:ScaleTo(scale)
	local cf, scaled = model:GetBoundingBox()
	model.PrimaryPart = nil
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, scaled.Y / 2, 0))
	return model
end

local function place(model, kind, baseIndex, rest, parent, species)
	model.Name = "Npc_" .. kind
	model:SetAttribute("Species", species) -- its growl on the clients (Shared/DinoVoices)
	model:PivotTo(rest)
	model:SetAttribute("Npc", kind)
	model:SetAttribute("NpcBase", baseIndex)
	model:SetAttribute("Rest", rest)
	model.Parent = parent
end

local function stallNpcs(index, folder)
	local zone = folder:FindFirstChild("SafeZone")
	if not zone then
		return
	end
	local out = Vector3.new(zone.Position.X, 0, zone.Position.Z)
	out = out.Magnitude > 1e-3 and out.Unit or Vector3.zAxis -- stalls face -out, toward the entrance
	for _, n in ipairs(STALL_NPCS) do
		local old = folder:FindFirstChild("Npc_" .. n.Kind)
		if old then
			old:Destroy()
		end
		local stall = folder:FindFirstChild(n.Stall)
		local model = stall and npcModel(n.Species, STALL_NPC_HEIGHT, STALL_NPC_LENGTH)
		if model then
			local plain = stall:FindFirstChild("Counter") ~= nil
			local at = stall:GetPivot().Position + out * (plain and STALL_NPC_BACK_PLAIN or STALL_NPC_BACK)
				+ Vector3.new(0, plain and 0 or STALL_DECK, 0)
			place(model, n.Kind, index, CFrame.lookAt(at, at - out), folder, n.Species)
		end
	end
end

local function boardNpc()
	local map = Workspace:FindFirstChild("Map")
	local zone = map and map:FindFirstChild("KeyZone")
	local board = zone and zone:FindFirstChild("Zone_Leaderboard")
	if not board then
		return
	end
	local cf, size = board:GetBoundingBox()
	local center = Vector3.new(cf.Position.X, cf.Position.Y - size.Y / 2, cf.Position.Z)
	local toMiddle = Vector3.new(-center.X, 0, -center.Z)
	toMiddle = toMiddle.Magnitude > 1e-3 and toMiddle.Unit or Vector3.zAxis
	local right = toMiddle:Cross(Vector3.yAxis).Unit

	local screen = board:FindFirstChild("Leaderboard_Screen", true)
	local part = (screen and screen:IsA("BasePart")) and screen or board:FindFirstChildWhichIsA("BasePart", true)
	if part and not part:FindFirstChild("BoardPrompt") then
		local prompt = Instance.new("ProximityPrompt")
		prompt.Name = "BoardPrompt"
		prompt.ActionText = "게시판 보기"
		prompt.ObjectText = "서버 게시판"
		prompt.HoldDuration = 0
		prompt.RequiresLineOfSight = false
		prompt.MaxActivationDistance = BOARD_RANGE
		prompt:SetAttribute("Kind", "Board")
		prompt.Parent = part
	end
	-- (2026-10-02, "뒤에 서버보드 자막이 간판에 가려지지 않게": signs and trees in front hid it) drawn over
	-- everything, a little higher
	local title = Bases.title(board, "📋 서버 게시판", BOARD_TITLE_COLOR, false, BOARD_TITLE_HEIGHT)
	if title then
		title.AlwaysOnTop = true
	end

	local old = zone:FindFirstChild("Npc_Board")
	if old then
		old:Destroy()
	end
	local model = npcModel(BOARD_SPECIES, BOARD_NPC_HEIGHT, BOARD_NPC_LENGTH)
	if model then
		local at = center + right * (math.max(size.X, size.Z) / 2 + BOARD_NPC_SIDE) + toMiddle * BOARD_NPC_FRONT
		place(model, "Board", nil, CFrame.lookAt(at, at + toMiddle), zone, BOARD_SPECIES)
	end
end

-- the stall dinos of a base: there while a player has it, gone while it stands empty
local function refreshBase(index, folder)
	if folder:GetAttribute("OwnerUserId") then
		if not folder:FindFirstChild("Npc_" .. STALL_NPCS[1].Kind) then
			local ok, err = pcall(stallNpcs, index, folder)
			if not ok then
				warn(string.format("[Npcs] Base%d NPC: %s", index, tostring(err)))
			end
		end
	else
		for _, n in ipairs(STALL_NPCS) do
			local old = folder:FindFirstChild("Npc_" .. n.Kind)
			if old then
				old:Destroy()
			end
		end
	end
end

function Npcs.init()
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			folder:GetAttributeChangedSignal("OwnerUserId"):Connect(function()
				refreshBase(index, folder)
			end)
			refreshBase(index, folder)
		end
	end
	local ok, err = pcall(boardNpc)
	if not ok then
		warn("[Npcs] 게시판 NPC: " .. tostring(err))
	end
end

return Npcs
