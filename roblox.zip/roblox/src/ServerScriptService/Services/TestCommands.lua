--[[
TestCommands: chat commands for testing in Roblox Studio only.

They never work in a real game: init connects nothing unless RunService:IsStudio(), and every
command checks IsStudio() again before it runs. Type them in the chat while playing in Studio
(prefix Config.DevCommands.Prefix):

	;help                        list the commands
	;money 1000                  add money            ;setmoney 0     set money
	;keys 10 [Grade]             add saved keys (Normal Silver Gold Ruby Diamond Rainbow)
	;level 25                    set the defense level
	;retry                       clear the wait after a failed promotion fight
	;gachafx Golden              the draw reveal of that rarity on my screen (nothing given; no name: all from Legendary)
	;boxes 5 [등급] [크기]         dino boxes on my farm (their usual wait)
	;boxready                    every box of mine ready to open now
	;rebirthfx [n]               the rebirth show on me (nothing changes; n: the rebirth count's color)
	;starter 3                   the beginner mission board at mission 3 (shown once the tutorial is done or skipped)
	;slap 10                     set the slap level (1-25)
	;carry 5 [Grade]             carry keys (bring them home to keep them)
	;keyrain 10 [Grade]          that many keys appear on the key zone now (one of them of the grade)
	;bombs N                     N egg and N poop bombs (default: as many as one can hold)
	;drop [big]                  a real central drop now: untaken central keys vanish, 2-10 keys fall (big: a big drop)
	;pad                         a speed pad 8 studs in front of me
	;poop                        a pterosaur dropping falls on me
	;bolt [studs]                a storm bolt that far in front of me (default 3)
	;night / ;day                night or day now      ;time 10        10 more minutes of play (playtime gifts)
	;boss [종류] [hp]            the night's boss zombie climbs out 25 studs in front of me (종류 rex / trike /
	                             ptera, with hp health)
	;chest [종류]                a treasure chest in front of me (money / keys / minerals)
	;buff [종류]                 the day buff now (money / defense / mining; nothing = off)
	;dinolevel 10                every dino of mine at this enhance level (try 합성 with ;dinos Rare first)
	;fruit N                     N 🍎 food (공룡 사육: the enhance stall's 🍎 먹이 tab; default 1000)
	;weather Rain|Storm|RainbowSky|Clear [s] change the weather now (optionally for s seconds)
	;dino TRex [Rarity] [Size]   add a dino (Config.Species / Rarities / Sizes Ids, e.g. ;dino Raptor Legendary Giant)
	;dinos [Rarity] [Size]       add one of every species unlocked at your defense level
	;nodinos                     remove all your dinos and placements
	;pickaxe 3                   set the pickaxe tier  ;bag 5          set the bag level
	;power 10                    set the power steps   ;speed 30       set the speed level
	;fill                        fill the bag with droplets      ;empty    empty the bag
	;reports [n] / ;errors [n]   the bug reports / script errors kept today (n days ago), in the output (BetaLog)
	;news                        the update news window again, as on joining
	;tutorialask                 the first join's "튜토리얼 할까요?" window (nothing changes)
	;intro                       (2026-10-07) Coco's opening story again, in the main game
	;notifyme [boxes]            (2026-10-08) the friend-playing notification to myself (Notify); boxes: the box-ready one
	;promo                       (2026-10-07) the store video: stand-in players at the altar, keys, dinos, flying in the sky, my arena, a race; HUD hidden, fast zoom shots
	;weekprize [rank]            (2026-10-04) the ♾️ weekly rank reward as when a new week starts (no rank: the play reward)
	;rankprize hide|race|boss [rank]  (2026-10-04) last week's 🏆 랭킹전 reward of that game (no rank: the play reward;
	                             boss: the 🧟 night boss hunts)
	;bones rex|trike|ptera [n]   (2026-10-04) a night boss hunt with n 🦴 bones of that kind (default 1): the hunt counts
	                             (this week and ever: the titles), full bones make the zombie dino
	;event                       (2026-10-04) every 🎉 launch event mission done: take them in 🎁 → 🎉 이벤트
	;eventad                     (2026-10-04) the 🎉 launch event's pop-up, as on joining
	;superthief                  a ⚡ super thief digs out in front of you (on the battlefield)
	;fake N | keys | altar | race | hide | follow | wander | ride | stop | clear
	                             (2026-10-05) stand-in players for filming alone (FakePlayers): N of them round me, then
	                             what they do (keys: carry keys and flee, a slap spills them; altar: rush the key drops;
	                             race: line up beside my road race practice and ride with it; hide: up in trees near me)
	;perf                        (2026-10-04) the 🐢 slow-screen banner on / off (off at first)
	;season [n]                  n tiers' worth of season XP (default 1); the pass: 💎 상점 → SeasonPass (Studio grants it)
	;data                        show your saved values
	;save                        save now              ;reset          start from a fresh profile
	;tutorial                    (2026-10-03) the tutorial to do again with its reward: the next test run starts on the
	                             tutorial field (on the field: back to the start of a fresh run)
	;tutorialend                 (2026-10-03) on the tutorial field: end this run now, even a first run (it has no skip
	                             button; counted as skipped: no reward)

If chat does not reach the server, run them from the Command Bar while playing (server side):
	_G.DevCommand("PlayerName", ";money 1000")
]]

local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))

local TestCommands = {}

local function reply(player, text)
	print("[TestCommands] " .. player.Name .. ": " .. text)
	Net.push(player, "Notice", "테스트 명령", text)
end

local function wholeNumber(text, min)
	local n = tonumber(text)
	if not n or n ~= n or n == math.huge or n == -math.huge or n ~= math.floor(n) or (min and n < min) then
		return nil
	end
	return n
end

local function findId(list, text, default)
	if not text then
		return default
	end
	for _, item in ipairs(list) do
		if string.lower(item.Id) == string.lower(text) then
			return item.Id
		end
	end
	return nil
end

local function ids(list)
	local out = {}
	for _, item in ipairs(list) do
		table.insert(out, item.Id)
	end
	return table.concat(out, " ")
end

local COMMANDS = {}

COMMANDS.help = function(player)
	reply(player, ";money N  ;setmoney N  ;keys N  ;level N  ;retry  ;slap N  ;move N  ;carry N  ;keyrain N  ;altarbox [등급] [크기] [n]  ;drop [big]  ;meteor  ;bombs N  ;pad  ;chest  ;night  ;day  ;time N  ;boss [rex|trike|ptera] [hp]  ;aurora  ;chest [money|keys|minerals]  ;buff [money|defense|mining]  ;dinolevel N  ;fruit N  ;offline N  ;comeback N  ;missions  ;starter N  ;gachafx [등급]  ;boxes N [등급] [크기]  ;boxready  ;rebirthfx  ;poop  ;bolt [거리]  ;weather 종류 [초]  ;dino 종 [등급] [크기]  ;dinos [등급] [크기]  ;nodinos  ;pickaxe N  ;power N  ;speed N  ;bag N  ;fill  ;empty  ;reports [n]  ;errors [n]  ;survey [n]  ;news  ;tutorialask  ;intro  ;promo  ;notifyme [boxes]  ;weekprize [순위]  ;rankprize hide|race|boss [순위]  ;bones rex|trike|ptera [n]  ;event  ;eventad  ;thief  ;superthief  ;treasure  ;fake N|keys|altar|race|hide|follow|wander|ride|stop|clear  ;perf  ;season [n]  ;unlocks on|off|N  ;graduate  ;returner N  ;data  ;save  ;reset")
end

COMMANDS.money = function(player, args)
	local n = wholeNumber(args[1], 0)
	if not n then
		return reply(player, "사용법: ;money 1000")
	end
	PlayerData.addMoney(player, n, "test")
	reply(player, string.format("돈 +%d → %d", n, PlayerData.get(player).Money))
end

COMMANDS.setmoney = function(player, args)
	local n = wholeNumber(args[1], 0)
	if not n then
		return reply(player, "사용법: ;setmoney 0")
	end
	PlayerData.update(player, function(p)
		p.Money = n
	end)
	reply(player, "돈 = " .. n)
end

COMMANDS.keys = function(player, args)
	local n = wholeNumber(args[1], 0)
	local grade = findId(Config.Keys.Types, args[2], "Normal")
	if not n or not grade then
		return reply(player, "사용법: ;keys 10 [등급]. 등급: " .. ids(Config.Keys.Types))
	end
	PlayerData.update(player, function(p)
		Formulas.addSavedKeys(p, grade, n)
	end)
	reply(player, string.format("%s +%d → %d", Formulas.keyType(grade).Name, n,
		Formulas.savedKeys(PlayerData.get(player), grade)))
end

COMMANDS.level = function(player, args)
	local n = wholeNumber(args[1], 1)
	if not n then
		return reply(player, "사용법: ;level 25")
	end
	PlayerData.update(player, function(p) -- the shown level in the player's tier (;level 30 / 100 = ready to rebirth)
		local start = Formulas.tierStart(p.Rebirths or 0)
		p.DefenseLevel = math.min(start + n - 1, Formulas.maxDefenseLevel(p.Rebirths or 0))
	end)
	local p = PlayerData.get(player)
	reply(player, string.format("디펜스 %s (실제 레벨 %d)", Formulas.levelText(p.DefenseLevel, p.Rebirths), p.DefenseLevel))
end

COMMANDS.unlocks = function(player, args)
	local on = args[1] == "on"
	local n = tonumber(args[1])
	if args[1] ~= "on" and args[1] ~= "off" and not n then
		return reply(player, "사용법: ;unlocks on (전부 열기) | ;unlocks off (처음처럼 다 잠그기) | ;unlocks 8 (앞의 8곳만 열고 다음 곳을 바로 열 수 있게)")
	end
	local Unlocks = require(script.Parent:WaitForChild("Unlocks"))
	if not n then
		if not on then
			PlayerData.update(player, function(p)
				p.Starter = { Step = 1, Count = 0, Done = false, Order = Config.StarterMissions.Order }
			end)
		end
		Unlocks.setAll(player, on)
		return reply(player, on and "🔓 모든 시설이 열렸어요" or "🔒 모든 시설이 잠기고 📋 초보 미션도 1장부터예요")
	end
	n = math.clamp(math.floor(n), 0, #Config.Unlocks)
	local nextOne = Config.Unlocks[n + 1]
	if nextOne then
		PlayerData.update(player, function(p)
			p.DefenseLevel = math.max(p.DefenseLevel, nextOne.Level or 1)
			local step = 1
			for i, m in ipairs(Config.StarterMissions.Missions) do
				if not m.Comeback and m.Ch <= nextOne.After then
					step = i + 1
				end
			end
			p.Starter = { Step = step, Count = 0, Done = false, Order = Config.StarterMissions.Order }
		end)
	end
	Unlocks.setFirst(player, n)
	reply(player, string.format("🔓 앞의 %d곳이 열렸어요 (튜토리얼은 그대로)%s", n,
		nextOne and string.format(" · 다음: %s, 그 자리에 가면 열려요", nextOne.Name) or " · 다 열렸어요"))
end

COMMANDS.graduate = function(player)
	PlayerData.update(player, function(p)
		p.Graduated = false
		p.IslandShown = false
	end)
	require(script.Parent:WaitForChild("Unlocks")).graduate(player)
	reply(player, "🎓 튜토리얼 끝(초보 미션 4장을 끝낸 것과 같음): 맵이 모두 열리고 섬 이야기가 나와요")
end

COMMANDS.returner = function(player, args)
	local n = wholeNumber(args[1], 1)
	if not n then
		return reply(player, "사용법: ;returner 15 (예전에 그 실제 레벨까지 하던 저장처럼 바꾸고 내보내요 · 31부터는 환생한 저장)")
	end
	if not PlayerData.isPersistent(player) then
		return reply(player, "저장이 꺼져 있어요 (스튜디오 API 접근을 켜세요)")
	end
	PlayerData.update(player, function(p)
		p.Rebirths = Formulas.tierOfLevel(n)
		p.DefenseLevel = n
		p.Onboard, p.Stash, p.Welcome, p.Graduated, p.IslandShown = nil, nil, nil, nil, nil
	end)
	PlayerData.save(player)
	player:Kick("[Studio] 테스트를 다시 실행하면 예전에 하던 사람처럼 들어와요")
end

COMMANDS.slap = function(player, args)
	local n = wholeNumber(args[1], 1)
	if not n or n > #Config.Slap.Scale then
		return reply(player, "사용법: ;slap 1~" .. #Config.Slap.Scale)
	end
	PlayerData.update(player, function(p)
		p.Upgrades.Slap = n
	end)
	reply(player, "손바닥 " .. n .. "단계")
end

COMMANDS.move = function(player, args) -- (2026-10-04: the move speed level, to see the feet's training look)
	local n = wholeNumber(args[1], 0)
	if not n or n > Config.MoveSpeed.Levels then
		return reply(player, "사용법: ;move 0~" .. Config.MoveSpeed.Levels)
	end
	PlayerData.update(player, function(p)
		p.Upgrades.MoveSpeed = n
	end)
	reply(player, "이동속도 " .. n .. "단계")
end

COMMANDS.carry = function(player, args)
	local n = wholeNumber(args[1], 1)
	local grade = findId(Config.Keys.Types, args[2], "Normal")
	if not n or not grade then
		return reply(player, "사용법: ;carry 5 [등급]. 등급: " .. ids(Config.Keys.Types))
	end
	local got = require(script.Parent:WaitForChild("Keys")).give(player, n, grade)
	reply(player, string.format("🎁 선물상자 %d개 운반 중 (%s 굴림, 최대 %d개)", got, Formulas.keyType(grade).Name, Config.AltarBoxes.MaxCarry))
end

COMMANDS.keyrain = function(player, args)
	local n = wholeNumber(args[1], 1)
	local grade = findId(Config.Keys.Types, args[2], "Normal")
	if not n or not grade then
		return reply(player, "사용법: ;keyrain 10 [등급 하나 섞기]. 등급: " .. ids(Config.Keys.Types))
	end
	local placed = require(script.Parent:WaitForChild("Keys")).rain(n, grade)
	reply(player, string.format("중앙에 선물상자 %d개 (바닥에 최대 %d개)", placed, Config.Keys.MaxOnGround))
end

COMMANDS.altarbox = function(player, args)
	local rarity = findId(Config.Rarities, args[1], "Mythic")
	local size = findId(Config.Sizes, args[2], "Giant")
	local n = wholeNumber(args[3], 1) or 1
	if not rarity or not size then
		return reply(player, "사용법: ;altarbox [등급] [크기] [n]. 등급: " .. ids(Config.Rarities) .. " / 크기: " .. ids(Config.Sizes))
	end
	local placed = require(script.Parent:WaitForChild("Keys")).rainBox(rarity, size, n)
	reply(player, string.format("제단에 %s · %s 선물상자 %d개", Formulas.rarity(rarity).Name, Formulas.dinoSize(size).Name, placed))
end

COMMANDS.bombs = function(player, args)
	local n = tonumber(args[1]) or Config.Bombs.MaxHeld
	local Bombs = require(script.Parent:WaitForChild("Bombs"))
	for _, k in ipairs(Config.Bombs.Kinds) do
		Bombs.give(player, k.Id, n)
	end
	reply(player, string.format("폭탄 지급: 알 폭탄·똥 폭탄 %d개씩 (1·2 키 또는 버튼으로 던지기)", n))
end

COMMANDS.drop = function(player, args)
	local big = args[1] == "big"
	local placed = require(script.Parent:WaitForChild("Keys")).dropNow(big)
	reply(player, string.format("중앙 %s: 선물상자 %d개 (이전 중앙 상자는 사라짐, 다음 자동 드랍까지 타이머 다시 시작)",
		big and "대박 드랍" or "드랍", placed))
end

COMMANDS.meteor = function(player)
	require(script.Parent:WaitForChild("Keys")).meteorNow()
	local shower = Config.Keys.MeteorShower
	reply(player, string.format("운석 샤워 지금 시작: 선물상자 %d개(황금 굴림 %d개 확정)가 %d초 동안", shower.Keys, shower.Gold, shower.Duration))
end

COMMANDS.weather = function(player, args)
	local ids = {}
	for _, w in ipairs(Config.Weather.Types) do
		ids[w.Id:lower()] = w.Id
	end
	local id = ids[(args[1] or ""):lower()]
	local seconds = wholeNumber(args[2], 1)
	if not id then
		return reply(player, "사용법: ;weather Rain|Storm|RainbowSky|Aurora|Clear [초] (Aurora는 밤에만: ;aurora)")
	end
	require(script.Parent:WaitForChild("Weather")).change(id, seconds)
	reply(player, string.format("날씨: %s (%d초 카운트다운 뒤)", id, Config.Weather.CountdownSeconds))
end

COMMANDS.aurora = function(player)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return reply(player, "캐릭터가 없어요")
	end
	local DayNight = require(script.Parent:WaitForChild("DayNight"))
	if not DayNight.isNight() then
		DayNight.set(true)
	end
	require(script.Parent:WaitForChild("Weather")).set("Aurora")
	require(script.Parent:WaitForChild("Zombies")).testAurora(root.Position + root.CFrame.LookVector * 40)
	reply(player, "오로라! 오로라 좀비 킹이 앞에서 기어나와요")
end

COMMANDS.poop = function(player)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return reply(player, "캐릭터가 없어요")
	end
	require(script.Parent:WaitForChild("Poop")).drop(root.Position)
	reply(player, "머리 위로 똥이 떨어져요! (피해 보세요)")
end

-- (2026-10-02) a storm bolt `studs` in front of me (default 3: I'm in its reach), any weather
COMMANDS.bolt = function(player, args)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return reply(player, "캐릭터가 없어요")
	end
	local studs = tonumber(args[1]) or 3
	require(script.Parent:WaitForChild("Lightning")).strike(root.Position + root.CFrame.LookVector * studs)
	reply(player, "번개가 내리쳐요! (빛나는 원에서 피해 보세요)")
end

COMMANDS.pad = function(player)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return reply(player, "캐릭터가 없어요")
	end
	require(script.Parent:WaitForChild("SpeedPads")).spawnAt(root.Position + root.CFrame.LookVector * 8)
	reply(player, "앞에 속도 발판을 놓았어요")
end

COMMANDS.time = function(player, args)
	local minutes = tonumber(args[1]) or 10
	require(script.Parent:WaitForChild("Rewards")).addPlaytime(player, minutes)
	reply(player, string.format("플레이 시간 +%d분 (🎁 플레이 선물 확인)", minutes))
end

COMMANDS.offline = function(player, args)
	local minutes = tonumber(args[1]) or 60
	require(script.Parent:WaitForChild("Rewards")).payOffline(player, minutes * 60)
	local profile = PlayerData.get(player)
	local rate = profile and profile.Stats.IdleMoneyRate or 0
	reply(player, string.format("%d분 자리를 비웠던 것처럼 받았어요 (디펜스에 공룡이 있어야 해요). 잰 디펜스 수입: 분당 %d원 (1분 이상 지켜봐야 저장)",
		minutes, math.floor(rate * 60 + 0.5)))
end

COMMANDS.comeback = function(player, args)
	local days = tonumber(args[1]) or Config.Comeback.Tiers[1].Days
	require(script.Parent:WaitForChild("Rewards")).setComeback(player, days)
	reply(player, string.format("%d일 만에 온 것처럼 🌱 선물 카드를 띄워요 (%d일부터 받아요)", days, Config.Comeback.Tiers[1].Days))
end

COMMANDS.missions = function(player)
	local Rewards = require(script.Parent:WaitForChild("Rewards"))
	for _, e in ipairs(Config.Rewards.Daily.Pool) do
		Rewards.add(player, e.Kind, e.Target)
	end
	reply(player, "오늘의 임무를 모두 채웠어요 (1초 뒤 반영)")
end

COMMANDS.night = function(player)
	require(script.Parent:WaitForChild("DayNight")).set(true)
	reply(player, "밤이 되었어요 (좀비 공룡이 기어나와요)")
end

COMMANDS.dinolevel = function(player, args)
	local n = math.clamp(math.floor(tonumber(args[1]) or Config.Enhance.MaxLevel), 1, Config.Enhance.MaxLevel)
	PlayerData.update(player, function(p)
		for _, u in ipairs(p.Units) do
			u.Level = n > 1 and n or nil
			u.Exp = 0
		end
	end)
	player:SetAttribute("UnitsVersion", (player:GetAttribute("UnitsVersion") or 0) + 1)
	reply(player, string.format("내 공룡 모두 Lv%d (강화 가판대의 🧬 합성에서 같은 등급 3마리)", n))
end

COMMANDS.fruit = function(player, args)
	local n = math.max(0, math.floor(tonumber(args[1]) or 1000))
	PlayerData.update(player, function(p)
		p.Fruit = (p.Fruit or 0) + n
	end)
	player:SetAttribute("Fruit", PlayerData.get(player).Fruit)
	reply(player, string.format("🍎 먹이 +%d (강화 가판대 🍎 먹이 탭)", n))
end

COMMANDS.boss = function(player, args)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return reply(player, "캐릭터가 없어요")
	end
	local at = root.Position + root.CFrame.LookVector * 25
	local kinds = { rex = "Rex", trike = "Trike", ptera = "Ptera" }
	local kindId = args[1] and kinds[string.lower(args[1])]
	local hp = tonumber(kindId and args[2] or args[1])
	require(script.Parent:WaitForChild("Zombies")).testBoss(at, hp, kindId)
	reply(player, "보스 좀비가 앞에서 기어나와요 (배틀필드 안에서만 찰싹이 들어가요)")
end

COMMANDS.bones = function(player, args)
	local kinds = { rex = "Rex", trike = "Trike", ptera = "Ptera" }
	local kindId = args[1] and kinds[string.lower(args[1])]
	local n = wholeNumber(args[2] or "1", 1)
	if not kindId or not n then
		return reply(player, "사용법: ;bones rex 6  (rex · trike · ptera, 뼈 개수)")
	end
	require(script.Parent:WaitForChild("Zombies")).testHunt(player, { [kindId] = n })
	reply(player, string.format("🦴 %s 뼈 +%d (보스 사냥 1번으로 셈)", kindId, n))
end

COMMANDS.event = function(player)
	require(script.Parent:WaitForChild("Rewards")).testEvent(player)
	reply(player, "🎉 이벤트 임무를 모두 끝냈어요: 🎁 보상 → 🎉 이벤트에서 받아요")
end

-- (2026-10-05) stand-in players for filming (FakePlayers; Studio only, as every command here)
COMMANDS.fake = function(player, args)
	local text = require(script.Parent:WaitForChild("FakePlayers")).command(player, args)
	if text then
		reply(player, text)
	end
end

COMMANDS.thief = function(player)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end
	require(script.Parent:WaitForChild("Zombies")).testThief(root.Position + root.CFrame.LookVector * 25)
	reply(player, "🛡️ 제단 지킴이가 나왔어요 (배틀필드 안에서만)")
end

COMMANDS.treasure = function(player)
	local ok = require(script.Parent:WaitForChild("Minerals")).testTreasure()
	reply(player, ok and "💰 특급석이 나왔어요 (배틀필드 어딘가)" or "💰 특급석 놓을 자리를 못 찾았어요")
end

COMMANDS.superthief = function(player)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end
	local ok = require(script.Parent:WaitForChild("Zombies")).testSuperThief(root.Position + root.CFrame.LookVector * Config.Zombies.SuperThief.SpawnAwayFrom)
	reply(player, ok and "⚡ 슈퍼 도둑이 나왔어요 (배틀필드 안에서만)" or "⚡ 슈퍼 도둑을 못 꺼냈어요")
end

-- (2026-10-04) the 🐢 slow-screen banner (StarterPlayerScripts/PerfCheck) on or off
COMMANDS.perf = function(player)
	local on = player:GetAttribute("PerfBanner") ~= true
	player:SetAttribute("PerfBanner", on or nil)
	reply(player, on and "🐢 느린 화면 표시 켬" or "🐢 느린 화면 표시 끔")
end

-- (2026-10-04) the 🎉 event's pop-up as on joining (StarterPlayerScripts/EventAd)
COMMANDS.eventad = function(player)
	Net.push(player, "EventAd")
	reply(player, "🎉 런칭 이벤트 광고를 띄웠어요")
end

COMMANDS.day = function(player)
	require(script.Parent:WaitForChild("DayNight")).set(false)
	reply(player, "낮이 되었어요")
end

COMMANDS.chest = function(player, args)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root then
		return reply(player, "캐릭터가 없어요")
	end
	local kinds = { money = "Money", keys = "Keys", minerals = "Minerals" }
	require(script.Parent:WaitForChild("Treasure")).spawnNow(root.Position + root.CFrame.LookVector * 8,
		kinds[string.lower(args[1] or "money")] or "Money")
	reply(player, "앞에 상자를 놓았어요")
end

COMMANDS.buff = function(player, args)
	local ReplicatedStorage = game:GetService("ReplicatedStorage")
	local kinds = { money = "Money", defense = "Defense", mining = "Mining" }
	local id = args[1] and kinds[string.lower(args[1])]
	ReplicatedStorage:SetAttribute("DayBuff", id)
	ReplicatedStorage:SetAttribute("DayBuffEndsAt", id and game:GetService("Workspace"):GetServerTimeNow() + Config.DayNight.DaySeconds or nil)
	reply(player, id and ("낮 버프 켬: " .. Config.DayBuffs[id].Name) or "낮 버프 끔")
end

COMMANDS.retry = function(player)
	PlayerData.update(player, function(p)
		p.PromotionRetryAt = 0
	end)
	player:SetAttribute("PromoRetryAt", nil)
	reply(player, "승급전 대기 없앰")
end

COMMANDS.rebirthfx = function(player, args)
	local n = math.max(1, math.floor(tonumber(args[1]) or 1))
	MoveGuard.allow(player, 6)
	Net.pushAll("RebirthFx", player.UserId, n)
	reply(player, "환생 연출 미리 보기")
end

COMMANDS.gachafx = function(player, args)
	local id = args[1]
	if id and not Formulas.rarity(id) then
		return reply(player, "등급 Id: Legendary Mythic Transcendent Rainbow Golden Onyx Celestial Secret Cosmic Primeval Divine")
	end
	Net.push(player, "GachaPreview", id or "")
	reply(player, "뽑기 연출 미리 보기: " .. (id or "전설부터 신까지 차례로"))
end

COMMANDS.starter = function(player, args)
	local main = 0
	for _, m in ipairs(Config.StarterMissions.Missions) do
		main += m.Comeback and 0 or 1
	end
	local n = math.clamp(math.floor(tonumber(args[1]) or 1), 1, main)
	PlayerData.update(player, function(p)
		p.Starter = { Step = n, Count = 0, Done = false, Order = Config.StarterMissions.Order }
	end)
	reply(player, string.format("초보 미션 %d번부터 (튜토리얼 중이면 ;tutorialend 뒤에 보여요)", n))
end

COMMANDS.tutorial = function(player)
	PlayerData.update(player, function(p)
		-- (ReplayAt now: an earlier field run counts as old, so the next run is the field, not its result)
		p.Tutorial.Done, p.Tutorial.Paid, p.Tutorial.ReplayAt, p.Tutorial.ReplayPart = false, false, os.time(), nil
		p.Tutorial.StartedAt = 0 -- (on the field: the next run starts fresh)
		p.Tutorial.Unpaid, p.Tutorial.ReplayCore = nil, nil
	end)
	PlayerData.save(player)
	reply(player, "튜토리얼을 처음부터 다시 (보상 포함): 테스트를 멈추고 다시 실행하면 튜토리얼 필드에서 시작해요")
end

COMMANDS.notifyme = function(player, args)
	local result = require(script.Parent:WaitForChild("Notify")).testSelf(player, args[1])
	reply(player, "🔔 " .. (({ id = "ConfigNotify의 MessageId가 비어 있어요", package = "ServerScriptService에 Open Cloud 패키지가 없어요",
		sent = "나에게 보냈어요 (로블록스 알림함 확인)", failed = "실패 (출력 창 확인)" })[result or ""] or "?"))
end

local PROMO_SECONDS = { Altar = 9, Chase = 6, Ride = 7, Sky = 8, Arena = 7, Race = 9 }
local PROMO_ALTAR_SIDE = Vector3.new(30, 0, 30)
local PROMO_ARENA_SIDE = 40
COMMANDS.promo = function(player)
	local Fake = require(script.Parent:WaitForChild("FakePlayers"))
	local function fake(word)
		Fake.command(player, { word })
	end
	local function goTo(at)
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if root then
			MoveGuard.allow(player, 3)
			root.CFrame = CFrame.new(at + Vector3.new(0, 4, 0))
		end
	end
	local function shot(kind, at)
		Net.push(player, "PromoShot", kind, PROMO_SECONDS[kind] or 0, at)
		if PROMO_SECONDS[kind] then
			task.wait(PROMO_SECONDS[kind])
		end
	end
	reply(player, "🎬 홍보 영상 모드: 화면 녹화를 켜 두세요 (약 50초, 끝나면 원래대로)")
	task.spawn(function()
		goTo(Fake.altarMiddle() + PROMO_ALTAR_SIDE)
		task.wait(0.5)
		fake("6")
		fake("altar")
		task.delay(1.5, function()
			require(script.Parent:WaitForChild("Keys")).dropNow(true)
		end)
		shot("Altar", Fake.altarMiddle())
		fake("keys")
		shot("Chase")
		fake("wander")
		fake("ride")
		shot("Ride")
		fake("fly")
		shot("Sky")
		local map = workspace:FindFirstChild("Map")
		local base = map and map:FindFirstChild("Base" .. tostring(player:GetAttribute("Base")))
		local frame = base and base:GetAttribute("ArenaFrame")
		if frame then
			local at = frame.Position
			local flat = Vector3.new(at.X, 0, at.Z)
			goTo(at - (flat.Magnitude > 1 and flat.Unit or Vector3.xAxis) * PROMO_ARENA_SIDE)
			task.wait(0.5)
			fake("6")
			fake("wander")
			shot("Arena", at)
		end
		fake("race")
		shot("Race")
		shot("End")
		fake("clear")
	end)
end

COMMANDS.intro = function(player)
	if player:GetAttribute("TutorialStep") or player:GetAttribute("CocoIntro") then
		return reply(player, "튜토리얼 필드가 아닐 때, 코코 이야기가 끝난 뒤에 돼요")
	end
	Net.push(player, "IslandCinematic")
	reply(player, "🐣 코코 이야기를 다시 보여줘요")
end

COMMANDS.tutorialend = function(player)
	local Tutorial = require(script.Parent:WaitForChild("Tutorial")) -- (looked up here: it needs nothing from this)
	if not player:GetAttribute("TutorialStep") then
		return reply(player, "튜토리얼 필드에서 튜토리얼 중일 때만 돼요")
	end
	Tutorial.skip(player)
	reply(player, "튜토리얼을 끝냈어요 (건너뛴 것으로: 보상 없음)")
end

-- (2026-10-04) the first join's "튜토리얼 할까요?" window, to look at (nothing changes; "no" shows Coco's skipped card)
COMMANDS.weekprize = function(player, args)
	local rank = wholeNumber(args[1], 1)
	require(script.Parent:WaitForChild("Leaderboards")).giveRankReward(player, rank)
	reply(player, rank and string.format("♾️ 주간 순위 보상: %d위", rank) or "♾️ 주간 순위 밖: 참가 선물")
end

COMMANDS.rankprize = function(player, args)
	local game = args[1] == "hide" and "Hide" or args[1] == "race" and "Race" or args[1] == "boss" and "Boss" or nil
	if not game then
		return reply(player, "사용법: ;rankprize hide 1  /  ;rankprize race  /  ;rankprize boss 3 (순위 없으면 참가 선물)")
	end
	local rank = wholeNumber(args[2], 1)
	require(script.Parent:WaitForChild("Leaderboards")).giveRankedReward(player, game, rank)
	reply(player, rank and string.format("🏆 %s 랭킹전 보상: %d위", game, rank) or string.format("🏆 %s 랭킹전: 참가 선물", game))
end

COMMANDS.tutorialask = function(player)
	local Tutorial = require(script.Parent:WaitForChild("Tutorial"))
	task.spawn(function()
		local yes = Tutorial.ask(player)
		if not player.Parent then
			return
		end
		if yes then
			reply(player, "튜토리얼 질문: 네 (진짜 게임이면 튜토리얼 필드로 가요)")
		else
			player:SetAttribute("TutorialWelcome", nil)
			player:SetAttribute("TutorialWelcome", "skipped")
			reply(player, "튜토리얼 질문: 아니요 (진짜 게임이면 튜토리얼을 건너뛴 것으로)")
		end
	end)
end

COMMANDS.dino = function(player, args)
	local species = findId(Config.Species, args[1], nil)
	local rarity = findId(Config.Rarities, args[2], Config.Rarities[1].Id)
	local size = findId(Config.Sizes, args[3], "Young")
	if not species or not rarity or not size then
		return reply(player, "사용법: ;dino TRex [등급] [크기]. 종: " .. ids(Config.Species) .. " / 등급: " .. ids(Config.Rarities)
			.. " / 크기: " .. ids(Config.Sizes))
	end
	PlayerData.update(player, function(p)
		local unit = { Id = HttpService:GenerateGUID(false), Species = species, Rarity = rarity, Size = size }
		table.insert(p.Units, unit)
		Formulas.recordCollection(p, unit)
	end)
	reply(player, string.format("공룡 추가: %s %s %s (보유 %d마리)", species, rarity, size, #PlayerData.get(player).Units))
end

COMMANDS.dinos = function(player, args)
	local rarity = findId(Config.Rarities, args[1], Config.Rarities[1].Id)
	local size = findId(Config.Sizes, args[2], "Young")
	if not rarity or not size then
		return reply(player, "사용법: ;dinos [등급] [크기]. 등급: " .. ids(Config.Rarities) .. " / 크기: " .. ids(Config.Sizes))
	end
	local level = PlayerData.get(player).DefenseLevel
	local added = 0
	PlayerData.update(player, function(p)
		for _, species in ipairs(Config.Species) do
			if species.UnlockLevel <= level then
				local unit = { Id = HttpService:GenerateGUID(false), Species = species.Id, Rarity = rarity, Size = size }
				table.insert(p.Units, unit)
				Formulas.recordCollection(p, unit)
				added += 1
			end
		end
	end)
	reply(player, string.format("LV %d까지 해금된 종 %d마리 추가 (%s %s)", level, added, rarity, size))
end

COMMANDS.boxes = function(player, args)
	local n = wholeNumber(args[1] or "1", 1)
	local rarity = findId(Config.Rarities, args[2], Config.Rarities[1].Id)
	local size = findId(Config.Sizes, args[3], "Young")
	if not n or not rarity or not size then
		return reply(player, "사용법: ;boxes 5 [등급] [크기]. 등급: " .. ids(Config.Rarities) .. " / 크기: " .. ids(Config.Sizes))
	end
	local Boxes = require(script.Parent:WaitForChild("Boxes"))
	local level = PlayerData.get(player).DefenseLevel
	local open = {}
	for _, species in ipairs(Config.Species) do
		if species.UnlockLevel <= level and species.Theme ~= "Variant" then
			table.insert(open, species.Id)
		end
	end
	local now = os.time()
	PlayerData.update(player, function(p)
		for i = 1, n do
			local unit = { Species = open[(i - 1) % #open + 1], Rarity = rarity, Size = size }
			Boxes.add(p, unit, nil, Formulas.boxSeconds(rarity, size), now)
		end
	end)
	Boxes.changed(player)
	reply(player, string.format("상자 %d개 (%s %s, %d초)", n, rarity, size, Formulas.boxSeconds(rarity, size)))
end

COMMANDS.boxready = function(player)
	require(script.Parent:WaitForChild("Boxes")).readyAll(player)
	reply(player, "내 상자 모두 지금 열 수 있어요")
end

COMMANDS.nodinos = function(player)
	PlayerData.update(player, function(p)
		p.Units = {}
		p.Boxes = {}
		p.Placed = {}
		p.Farm = {} -- the collection stays (it counts what was ever owned)
	end)
	reply(player, "공룡과 배치를 모두 지움")
end

COMMANDS.pickaxe = function(player, args)
	local n = wholeNumber(args[1], 1)
	if not n or n > #Config.Pickaxe.Tiers then
		return reply(player, "사용법: ;pickaxe 1~" .. #Config.Pickaxe.Tiers)
	end
	PlayerData.update(player, function(p)
		p.Upgrades.PickaxeTier = n
		p.Upgrades.PickaxePower = 0
	end)
	reply(player, "곡괭이 " .. n .. "티어")
end

COMMANDS.power = function(player, args)
	local n = wholeNumber(args[1], 0)
	if not n or n > Config.Pickaxe.PowerSteps then
		return reply(player, "사용법: ;power 0~" .. Config.Pickaxe.PowerSteps)
	end
	PlayerData.update(player, function(p)
		p.Upgrades.PickaxePower = n
	end)
	reply(player, "파워 강화 " .. n .. "단계")
end

COMMANDS.speed = function(player, args)
	local n = wholeNumber(args[1], 0)
	if not n or n > Config.Pickaxe.SpeedUpgrade.Levels then
		return reply(player, "사용법: ;speed 0~" .. Config.Pickaxe.SpeedUpgrade.Levels)
	end
	PlayerData.update(player, function(p)
		p.Upgrades.PickaxeSpeed = n
	end)
	reply(player, "속도 강화 " .. n .. "단계")
end

COMMANDS.bag = function(player, args)
	local n = wholeNumber(args[1], 1)
	if not n or n > #Config.Bag.Capacity then
		return reply(player, "사용법: ;bag 1~" .. #Config.Bag.Capacity)
	end
	PlayerData.update(player, function(p)
		p.Upgrades.Bag = n
	end)
	reply(player, string.format("가방 %d단계 (용량 %d)", n, Formulas.bagCapacity(n, PlayerData.get(player).Passes.DoubleBag == true)))
end

COMMANDS.fill = function(player)
	local p = PlayerData.get(player)
	local room = Formulas.bagCapacity(p.Upgrades.Bag, p.Passes.DoubleBag == true) - Formulas.carryCount(p.Carry)
	local key = Formulas.carryKey(Config.Minerals.Grades[1].Id, Config.Minerals.Sizes[1].Id)
	PlayerData.update(player, function(profile)
		profile.Carry[key] = (profile.Carry[key] or 0) + math.max(room, 0)
	end)
	reply(player, "가방을 채웠어요 (+" .. math.max(room, 0) .. ")")
end

COMMANDS.empty = function(player)
	PlayerData.update(player, function(p)
		p.Carry = {}
	end)
	reply(player, "가방을 비웠어요")
end

COMMANDS.data = function(player)
	local p = PlayerData.get(player)
	reply(player, string.format("돈 %d, 열쇠 %d, 레벨 %d, 곡괭이 %d티어, 가방 %d단계(%d개 담음), 공룡 %d마리, 접속 %d회, 저장 %s",
		p.Money, p.Keys, p.DefenseLevel, p.Upgrades.PickaxeTier, p.Upgrades.Bag, Formulas.carryCount(p.Carry), #p.Units,
		p.Stats.Joins, PlayerData.isPersistent(player) and "켜짐" or "꺼짐(스튜디오 API 접근 꺼짐)"))
end

COMMANDS.save = function(player)
	if not PlayerData.isPersistent(player) then
		return reply(player, "저장이 꺼져 있어요 (스튜디오 API 접근을 켜세요)")
	end
	reply(player, PlayerData.save(player) and "저장했어요" or "저장 실패 (출력창 확인)")
end

COMMANDS.reset = function(player)
	PlayerData.reset(player)
	reply(player, "새 프로필로 바꿨어요 (저장은 다음 자동 저장이나 ;save 때)")
end

-- (2026-10-02, the closed beta) the bug reports and script errors kept for a day (BetaLog), in the output
local function betaDay(args)
	local BetaLog = require(script.Parent:WaitForChild("BetaLog"))
	return BetaLog, BetaLog.today() - (tonumber(args[1]) or 0)
end

COMMANDS.reports = function(player, args)
	local BetaLog, day = betaDay(args)
	local list, why = BetaLog.read("Reports", day)
	if not list then
		return reply(player, why)
	end
	print(string.format("[TestCommands] 버그 신고 %d개 (날 %d)", #list, day))
	for i, r in ipairs(list) do
		print(string.format("  %d. %s %s(%d) [%s] LV%d 환생%d 위치 %s 빌드 %s 서버 %s\n     %s\n     최근 오류: %s", i,
			os.date("!%m-%d %H:%M", r.Time), r.Name, r.User, r.Kind, r.Level or 0, r.Rebirths or 0, r.Where or "-",
			tostring(r.Build), tostring(r.Server), r.Text, table.concat(r.Errors or {}, " / ")))
	end
	reply(player, string.format("버그 신고 %d개를 출력 창에 적었어요", #list))
end

COMMANDS.survey = function(player, args)
	local BetaLog, day = betaDay(args)
	local counts, why = BetaLog.read("Survey", day)
	if not counts then
		return reply(player, why)
	end
	print(string.format("[TestCommands] 설문 (날 %d): 👍 %d · 👎 %d", day, counts.Up or 0, counts.Down or 0))
	for _, side in ipairs({ "Up", "Down" }) do
		for _, r in ipairs(Config.Beta.Survey[side]) do
			print(string.format("  %s %s: %d", side == "Up" and "👍" or "👎", r.Text, counts[side .. "_" .. r.Id] or 0))
		end
	end
	reply(player, string.format("설문 👍 %d · 👎 %d (출력 창에 이유별로)", counts.Up or 0, counts.Down or 0))
end

COMMANDS.errors = function(player, args)
	local BetaLog, day = betaDay(args)
	local list, dropped = BetaLog.read("Errors", day)
	if not list then
		return reply(player, dropped)
	end
	print(string.format("[TestCommands] 오류 %d종 (날 %d, 넘쳐서 빠진 것 %d번)", #list, day, dropped))
	for i, e in ipairs(list) do
		print(string.format("  %d. [%s] %d번 · %d명 · %s~%s · 빌드 %s · 예: %s\n     %s\n     %s", i, e.Side, e.C, e.U or 0,
			os.date("!%H:%M", e.First), os.date("!%H:%M", e.Last), tostring(e.Build), tostring(e.Who), e.M, e.T))
	end
	reply(player, string.format("오류 %d종을 출력 창에 적었어요", #list))
end

COMMANDS.season = function(player, args)
	local Season = require(script.Parent:WaitForChild("Season"))
	local n = tonumber(args[1]) or 1
	Season.addXp(player, n * Config.Season.XpPerTier)
	reply(player, string.format("시즌 XP +%d (%d단계만큼)", n * Config.Season.XpPerTier, n))
end

COMMANDS.news = function(player)
	PlayerData.update(player, function(p)
		p.NewsSeen = ""
	end)
	player:SetAttribute("NewsPending", true)
	Net.push(player, "OpenNews")
	reply(player, "업데이트 소식을 다시 띄웠어요 (확인을 누르면 출석 창이 이어서 떠요)")
end

-- runs one command line for a player; Studio only
local function run(player, text)
	if not RunService:IsStudio() then
		return false
	end
	local prefix = Config.DevCommands.Prefix
	if string.sub(text, 1, #prefix) ~= prefix then
		return false
	end
	local words = string.split(string.sub(text, #prefix + 1), " ")
	local name = string.lower(table.remove(words, 1) or "")
	local args = {}
	for _, w in ipairs(words) do
		if w ~= "" then
			table.insert(args, w)
		end
	end
	local command = COMMANDS[name]
	if not command then
		return false
	end
	if not PlayerData.isLoaded(player) then
		reply(player, "아직 데이터를 불러오는 중이에요")
		return true
	end
	command(player, args)
	return true
end

function TestCommands.init()
	if not RunService:IsStudio() then
		return -- a real server never gets these commands
	end
	local function hook(player)
		player.Chatted:Connect(function(message)
			run(player, message)
		end)
	end
	Players.PlayerAdded:Connect(hook)
	for _, player in ipairs(Players:GetPlayers()) do
		hook(player)
	end
	_G.DevCommand = function(playerOrName, text)
		local player = typeof(playerOrName) == "Instance" and playerOrName or Players:FindFirstChild(playerOrName)
		assert(player, "no player " .. tostring(playerOrName))
		return run(player, text)
	end
	print("[TestCommands] 스튜디오 테스트 명령이 켜졌습니다. 채팅에 ;help")
end

return TestCommands
