--[[
PlaceBoards (2026-10-04, "배치는 농장 칸 늘리기 표지 옆에 농장배치 칸 만들고 아레나 배치칸 늘리기 표지판 옆에 아레나 배치판 만들어서
직관적으로도 보이게 해 버튼에만 의존하지 말고 / 배치 가능한 수도 알아서 표기하고 거기에"): a board beside every base's
"➕ 공룡 자리 늘리기" sign (DefenseSign) and "🌾 농장 칸 늘리기" sign (FarmSign), on the side away from the plot's middle
line, showing the base owner's places as pictures (a dino for each one taken, an empty box for each free one; past
PICTURE_MAX places, one of each with its number), the numbers ("3 / 4") and one line saying what to do. Its press
prompt ("🦖 공룡 놓기" / "🌾 농장에 넣기", Kind PlaceBoard / FarmBoard, Base) opens the placing window on the owner's
screen (StarterPlayerScripts/Placement; other bases' prompts are off on every screen, Hud). Read from the owner's
attributes DefensePlaced / DefenseSlots (Defense) and FarmCount / FarmSlots (Farm) every UPDATE_EVERY seconds, written
only when they change; a base without an owner shows "빈 기지", an owner whose data has not come in "⏳ 불러오는 중".
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Formulas"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))
local Net = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Net"))

local PlaceBoards = {}

-- display only
local FONT = Enum.Font.GothamBlack
local BOARD_SIZE = Vector3.new(8, 5.6, 0.4)
local BOARD_BOTTOM = 1.2 -- studs over the ground
local POST_SIZE = Vector3.new(0.5, BOARD_BOTTOM + BOARD_SIZE.Y, 0.5)
local SIDE_GAP = 1.5 -- studs between the sign and the board
local SIGN_ABOVE_GROUND = 3.5 -- (MapBuilder) the sign's middle over the ground, if its posts are missing
local PIXELS_PER_STUD = 50
local PICTURE_MAX = 8 -- places shown one picture each; more: one of each with its number
local UPDATE_EVERY = 1
local COLOR_POST = Color3.fromRGB(110, 80, 50)
local PROMPT_RANGE = 9
local KINDS = {
	{ Sign = "DefenseSign", Kind = "PlaceBoard", Title = "🦖 아레나 공룡", Caption = "🦖 공룡 배치", Taken = "🦖", Action = "🦖 공룡 놓기",
		Free = "%d자리 비었어요! 👆 눌러서 놓기", Board = Color3.fromRGB(60, 50, 95), TitleColor = Color3.fromRGB(255, 215, 90),
		Placed = "DefensePlaced", Slots = "DefenseSlots" },
	{ Sign = "FarmSign", Kind = "FarmBoard", Title = "🌾 농장 공룡", Caption = "🌾 농장 배치", Taken = "🦕", Action = "🌾 넣기·빼기",
		Free = "%d자리 비었어요! 👆 눌러서 넣기", Board = Color3.fromRGB(45, 85, 50), TitleColor = Color3.fromRGB(200, 255, 150),
		Placed = "FarmCount", Slots = "FarmSlots" },
}
local EMPTY_PICTURE = "⬜"
local FULL_LINE = "꽉 찼어요! ➕ 옆 표지판에서 늘려요"
local NO_OWNER = "빈 기지"
local LOADING = "⏳ 불러오는 중"
local COLOR_FULL = Color3.fromRGB(255, 160, 120)
local COLOR_FREE = Color3.fromRGB(170, 255, 170)
local MAP_BOARD = { Kind = "MapBoard", Title = "🗺️ 디펜스 맵", Caption = "🗺️ 맵 바꾸기", Action = "🗺️ 맵 바꾸기", Board = Color3.fromRGB(40, 70, 105),
	TitleColor = Color3.fromRGB(150, 220, 255) }
local MAP_LINE = "👆 눌러서 맵 바꾸기"
local MAP_COUNT = "🗺️ 열린 맵 %d / %d"
local MAP_NEXT = "🔒 다음 맵: %s"

local boards = {} -- { folder, kind, pictures, count, line, shown }

local function part(props, parent)
	local p = Instance.new("Part")
	p.Anchored = true
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	for k, v in pairs(props) do
		p[k] = v
	end
	p.Parent = parent
	return p
end

local function label(parent, size, position, color)
	local t = Instance.new("TextLabel")
	t.BackgroundTransparency = 1
	t.Font = FONT
	t.TextScaled = true
	t.TextColor3 = color or Color3.new(1, 1, 1)
	t.TextStrokeTransparency = 0.35
	t.Size = size
	t.Position = position
	t.Parent = parent
	return t
end

local function build(folder, index, k, further)
	local sign = folder:FindFirstChild(k.Sign)
	local zone = folder:FindFirstChild("SafeZone")
	if not sign or not sign:IsA("BasePart") then
		return nil
	end
	-- beside the sign, away from the plot's middle line (the stall and the pedestal stand toward it)
	local right = Vector3.new(sign.CFrame.RightVector.X, 0, sign.CFrame.RightVector.Z).Unit
	local middle = zone and zone.Position or sign.Position
	local side = (middle - sign.Position):Dot(right) >= 0 and -1 or 1
	local spot = sign.Position + right * side * (sign.Size.X / 2 + SIDE_GAP + BOARD_SIZE.X / 2
		+ (further and BOARD_SIZE.X + SIDE_GAP or 0))
	-- on the ground: the sign's posts' feet (as DefenseGuide)
	local ground = sign.Position.Y - SIGN_ABOVE_GROUND
	for _, d in ipairs(folder:GetDescendants()) do
		if d.Name == k.Sign .. "Post" and d:IsA("BasePart") then
			ground = d.Position.Y - d.Size.Y / 2
			break
		end
	end
	local base = CFrame.new(spot.X, ground, spot.Z) * sign.CFrame.Rotation
	local old = folder:FindFirstChild(k.Kind)
	if old then
		old:Destroy()
	end
	local model = Instance.new("Model")
	model.Name = k.Kind
	local board = part({ Name = "Board", Size = BOARD_SIZE, Color = k.Board,
		CFrame = base * CFrame.new(0, BOARD_BOTTOM + BOARD_SIZE.Y / 2, 0) }, model)
	for _, x in ipairs({ -BOARD_SIZE.X / 2 + 0.5, BOARD_SIZE.X / 2 - 0.5 }) do
		part({ Name = "Post", Size = POST_SIZE, Color = COLOR_POST, CFrame = base * CFrame.new(x, POST_SIZE.Y / 2, 0.3) }, model)
	end
	local gui = Instance.new("SurfaceGui")
	gui.AutoLocalize = false
	gui.Face = Enum.NormalId.Front
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud = PIXELS_PER_STUD
	gui.LightInfluence = 0 -- (bright at night too)
	gui.Parent = board
	label(gui, UDim2.fromScale(0.94, 0.2), UDim2.fromScale(0.03, 0.03), k.TitleColor).Text = k.Title
	local pictures = label(gui, UDim2.fromScale(0.94, 0.3), UDim2.fromScale(0.03, 0.25))
	local count = label(gui, UDim2.fromScale(0.94, 0.2), UDim2.fromScale(0.03, 0.56))
	local line = label(gui, UDim2.fromScale(0.94, 0.16), UDim2.fromScale(0.03, 0.8))
	model.Parent = folder
	Bases.title(model, k.Caption, k.TitleColor)
	local prompt = Bases.prompt(board, k.Kind, index, k.Action, PROMPT_RANGE)
	if prompt then
		prompt.ObjectText = k.Title
		prompt.Triggered:Connect(function(player)
			if folder:GetAttribute("OwnerUserId") == player.UserId then
				if k.Kind == "MapBoard" then
					Net.push(player, "OpenMaps")
				elseif Unlocks.shown(player, k.Kind) then
					Net.push(player, "OpenPlacement", k.Kind == "FarmBoard")
				end
			end
		end)
	end
	return { folder = folder, kind = k, pictures = pictures, count = count, line = line }
end

-- the places as pictures: one each, or past PICTURE_MAX one of each with its number
local function picturesOf(k, taken, slots)
	local free = math.max(0, slots - taken)
	if slots <= PICTURE_MAX then
		return string.rep(k.Taken, math.min(taken, slots)) .. string.rep(EMPTY_PICTURE, free)
	end
	return string.format("%s %d   %s %d", k.Taken, taken, EMPTY_PICTURE, free)
end

local function showEmpty(b, key)
	b.pictures.Text, b.count.Text, b.line.Text = "", "", key == "none" and NO_OWNER or LOADING
	b.line.TextColor3 = Color3.new(1, 1, 1)
end

local function refreshMap(b, owner)
	local mapId = owner and owner:GetAttribute("DefenseMap")
	local level, rebirths = owner and owner:GetAttribute("DefenseLevel"), owner and owner:GetAttribute("Rebirths") or 0
	local key = not owner and "none" or level and string.format("%s/%d/%d", tostring(mapId), level, rebirths) or "loading"
	if key == b.shown then
		return
	end
	b.shown = key
	if key == "none" or key == "loading" then
		return showEmpty(b, key)
	end
	local map = Formulas.defenseMap(mapId)
	b.pictures.Text = string.format("%s %s", map.Icon, map.Name)
	b.count.Text = string.format(MAP_COUNT, #Formulas.mapsOpen(rebirths, level), #Config.Defense.Maps)
	local nextMap = nil
	for _, m in ipairs(Config.Defense.Maps) do
		if not Formulas.mapOpen(m.Id, rebirths, level)
			and (not nextMap or Formulas.mapUnlockLevel(m) < Formulas.mapUnlockLevel(nextMap)) then
			nextMap = m
		end
	end
	b.line.Text = nextMap and string.format(MAP_NEXT, Formulas.levelText(Formulas.mapUnlockLevel(nextMap))) or MAP_LINE
	b.line.TextColor3 = nextMap and COLOR_FULL or COLOR_FREE
end

local function refresh(b)
	local owner = Players:GetPlayerByUserId(b.folder:GetAttribute("OwnerUserId") or 0)
	if b.kind == MAP_BOARD then
		return refreshMap(b, owner)
	end
	local taken = owner and owner:GetAttribute(b.kind.Placed)
	local slots = owner and owner:GetAttribute(b.kind.Slots)
	local key = not owner and "none" or taken and slots and string.format("%d/%d", taken, slots) or "loading"
	if key == b.shown then
		return
	end
	b.shown = key
	if key == "none" or key == "loading" then
		return showEmpty(b, key)
	end
	b.pictures.Text = picturesOf(b.kind, taken, slots)
	b.count.Text = string.format("%d / %d", taken, slots)
	local free = slots - taken
	b.line.Text = free > 0 and string.format(b.kind.Free, free) or FULL_LINE
	b.line.TextColor3 = free > 0 and COLOR_FREE or COLOR_FULL
end

function PlaceBoards.init()
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			for _, k in ipairs(KINDS) do
				local ok, b = pcall(build, folder, index, k)
				if ok and b and k.Sign == "DefenseSign" then
					local okMap, mapBoard = pcall(build, folder, index, setmetatable({ Sign = k.Sign }, { __index = MAP_BOARD }), true)
					if okMap and mapBoard then
						mapBoard.kind = MAP_BOARD
						table.insert(boards, mapBoard)
					end
				end
				if ok and b then
					table.insert(boards, b)
				elseif not ok then
					warn(string.format("[PlaceBoards] Base%d %s: %s", index, k.Kind, tostring(b)))
				end
			end
		end
	end
	task.spawn(function()
		local warned = {}
		while true do
			for _, b in ipairs(boards) do
				local ok, err = pcall(refresh, b)
				if not ok and not warned[b] then
					warned[b] = true
					b.shown = nil
					warn(string.format("[PlaceBoards] %s %s: %s", b.folder.Name, b.kind.Kind or "MapBoard", tostring(err)))
				end
			end
			task.wait(UPDATE_EVERY)
		end
	end)
end

return PlaceBoards
