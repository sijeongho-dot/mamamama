--[[
TreeClimb: the trees made climbable (2026-10-04, "유저가 나무위 등반해서 숨으니까 재밌네. 기본적으로 나무위 등반할 수있게
하자"; the climbing itself: StarterPlayerScripts/Climb, Config.Climb).

- A tree's trunk is its parts named TrunkCollider (the Blender trees, MapBuilder) or Trunk (the part-built ones); the
  climb ends on the top of its highest trunk end, inside the leaves.
- The part-built trees' leaf balls stop colliding (the Blender trees' leaves never did): the climber comes up through
  them and stands hidden in them.
- A palm (a leaning trunk of several colliders) gets a small flat disc on its top end (ClimbTop: the end is slanted),
  invisible.
- (2026-10-04, "이것처럼 전나무도 안에 숨을 수 있게 해줘 야자는 위에 타고 올라갈 수 있으니까 됐고") a fir's (Prop_Tree_Pine)
  trunk collider went up half the tree, into its narrow top cones: a climber stood there with head and shoulders out.
  It now ends PINE_STAND_SHARE of the way up (still higher than a step, so walking bumps into it), inside the widest,
  lowest cones: the climber stands hidden in them, as in a round tree's leaves.
- MoveGuard lets a climber be off the ground (TreeClimb.nearTrunk: a trunk within NEAR_TRUNK studs).
]]

local Workspace = game:GetService("Workspace")

local TreeClimb = {}

-- display only
local DISC_PAD = 0.6 -- studs the palm top's disc reaches past the trunk
local DISC_THICK = 0.4
local NEAR_TRUNK = 4 -- studs from a trunk a climber still counts as on it (MoveGuard)
local PINE_STAND_SHARE = 0.32 -- a fir's climb top: this share of the way from its foot to its tip (tools/make_foliage.py
-- build_pine: the lowest cone from 0.23 to 0.62 of the height, the next from 0.48 to 0.83)
local PINE_SUNK_SHARE = 0.075 -- the share of a fir's height under the ground (MapBuilder TREE_SINK 0.9 of 12)
local PINE_MIN_TOP = 3.5 -- studs over the ground at least (a small fir's top higher than a step and a climber's waist)

local TRUNK_NAMES = { TrunkCollider = true, Trunk = true }
TreeClimb.TRUNK_NAMES = TRUNK_NAMES

local overlap = OverlapParams.new()
overlap.FilterType = Enum.RaycastFilterType.Exclude

-- the highest end of a tree's trunk parts, and the part it belongs to
local function topEnd(model)
	local best, part, count = nil, nil, 0
	for _, p in ipairs(model:GetChildren()) do
		if p:IsA("BasePart") and TRUNK_NAMES[p.Name] then
			count += 1
			for _, side in ipairs({ -1, 1 }) do -- (a cylinder's length is along its X)
				local e = p.CFrame * Vector3.new(side * p.Size.X / 2, 0, 0)
				if not best or e.Y > best.Y then
					best, part = e, p
				end
			end
		end
	end
	return best, part, count
end

-- a fir's one trunk collider cut down to end PINE_STAND_SHARE of the way up the tree
local function lowerPine(model)
	local collider = nil
	for _, p in ipairs(model:GetChildren()) do
		if p:IsA("BasePart") and p.Name == "TrunkCollider" then
			if collider then
				return false -- (not the usual one collider)
			end
			collider = p
		end
	end
	if not collider then
		return false
	end
	local cf, size = model:GetBoundingBox()
	local tip = cf.Position.Y + size.Y / 2
	local a = collider.CFrame * Vector3.new(-collider.Size.X / 2, 0, 0)
	local b = collider.CFrame * Vector3.new(collider.Size.X / 2, 0, 0)
	local foot, head = a, b
	if a.Y > b.Y then
		foot, head = b, a
	end
	local height = tip - foot.Y
	local length = math.max(height * PINE_STAND_SHARE, height * PINE_SUNK_SHARE + PINE_MIN_TOP)
	if length <= 0 or length >= collider.Size.X then
		return false
	end
	local up = (head - foot).Unit
	collider.Size = Vector3.new(length, collider.Size.Y, collider.Size.Z)
	collider.CFrame = collider.CFrame.Rotation + foot + up * length / 2
	return true
end

function TreeClimb.init()
	local map = Workspace:FindFirstChild("Map")
	if not map then
		return
	end
	local leaves, discs, pines = 0, 0, 0
	for _, d in ipairs(map:GetDescendants()) do
		if d:IsA("BasePart") and d.Name == "Leaves" and d.Parent and d.Parent.Name == "Tree" then
			d.CanCollide = false
			leaves += 1
		elseif d:IsA("Model") and d.Name == "Prop_Tree_Pine" then
			pines += lowerPine(d) and 1 or 0
		elseif d:IsA("Model") and not d:FindFirstChild("ClimbTop") then
			local top, part, count = topEnd(d)
			if top and count > 1 then -- a leaning trunk: a flat disc on its top end
				local disc = Instance.new("Part")
				disc.Name = "ClimbTop"
				disc.Shape = Enum.PartType.Cylinder
				disc.Size = Vector3.new(DISC_THICK, part.Size.Y + DISC_PAD * 2, part.Size.Z + DISC_PAD * 2)
				disc.CFrame = CFrame.new(top) * CFrame.Angles(0, 0, math.rad(90))
				disc.Transparency = 1
				disc.Anchored, disc.CanCollide, disc.CanTouch, disc.CastShadow = true, true, false, false
				disc.Parent = d
				discs += 1
			end
		end
	end
	print(string.format("[TreeClimb] 나뭇잎 %d개 통과, 기운 나무 꼭대기 %d개, 전나무 %d그루 낮춤", leaves, discs, pines))
end

-- is there a tree trunk within NEAR_TRUNK studs of this point? (a climber is off the ground there: MoveGuard)
function TreeClimb.nearTrunk(position, ignore)
	overlap.FilterDescendantsInstances = ignore or {}
	for _, p in ipairs(Workspace:GetPartBoundsInRadius(position, NEAR_TRUNK, overlap)) do
		if TRUNK_NAMES[p.Name] or p.Name == "ClimbTop" then
			return true
		end
	end
	return false
end

return TreeClimb
