--[[
Policy: asks PolicyService on join whether paid random items are restricted for the player
(design: 어린 유저 대상 필수 규칙). Restricted players cannot buy the Robux products that lead to
draws (Config.RestrictedProducts) but can still draw with keys and money earned in the game.

The answer is kept on the server and copied to the player attribute "PaidRandomItemsRestricted"
so the client can show the shop the right way. The server always decides with Policy.isRestricted.
If PolicyService fails, the player counts as restricted (Config.Policy.RestrictedWhenUnknown).
]]

local Players = game:GetService("Players")
local PolicyService = game:GetService("PolicyService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Config"))

local Policy = {}

local restricted = {} -- [player] = boolean

local function check(player)
	local answer = nil
	local share = false
	for attempt = 1, Config.Policy.Attempts do
		local ok, info = pcall(function()
			return PolicyService:GetPolicyInfoForPlayerAsync(player)
		end)
		if ok and info then
			answer = info.ArePaidRandomItemsRestricted == true
			share = info.IsContentSharingAllowed == true
			break
		end
		task.wait(attempt)
	end
	if answer == nil then
		answer = Config.Policy.RestrictedWhenUnknown
		warn(string.format("[Policy] %s: PolicyService 확인 실패, 제한 대상으로 처리합니다", player.Name))
	end
	if player.Parent then
		restricted[player] = answer
		player:SetAttribute("PaidRandomItemsRestricted", answer)
		player:SetAttribute("CanShare", share)
	end
end

function Policy.init()
	Players.PlayerAdded:Connect(check)
	Players.PlayerRemoving:Connect(function(player)
		restricted[player] = nil
	end)
	for _, player in ipairs(Players:GetPlayers()) do
		task.spawn(check, player)
	end
end

-- true while unknown (still checking) as well, so nothing restricted is sold before the answer
function Policy.isRestricted(player)
	local answer = restricted[player]
	if answer == nil then
		return true
	end
	return answer
end

-- may this player buy this product (a key of Config.Products / Config.GamePasses / "MoneyPacks")?
function Policy.canBuy(player, productName)
	if not Policy.isRestricted(player) then
		return true
	end
	return not table.find(Config.RestrictedProducts, productName)
end

return Policy
