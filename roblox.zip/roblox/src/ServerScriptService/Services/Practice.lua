local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local UnlockLogic = require(script.Parent:WaitForChild("UnlockLogic"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))

local Practice = {}

local C = Config.Practice
local ZOMBIE_HEIGHT, ZOMBIE_LENGTH = 5.5, 11
local BOSS_SCALE = 2
local ZOMBIE_SIDE = 14
local ZOMBIE_IN = { 0, 6, -4 }
local BOSS_SIDE = 22
local CHEST_SIDE = -16
local ZOMBIE_KNOCK = { Studs = 15, Up = 8, Seconds = 0.9 }
local GUARD_KNOCK = { Studs = 6, Up = 2.5, Seconds = 0.45 }
local POOP_SCALE = 1.3
local SINK_SECONDS = 1.2
local LABEL_SIZE = UDim2.fromScale(9, 2.4)
local LABEL_UP = 1.5
local LABEL_COLOR = Color3.fromRGB(190, 255, 190)
local BOSS_LABEL_COLOR = Color3.fromRGB(230, 170, 255)
local SEEKER_LABEL_COLOR = Color3.fromRGB(255, 120, 120)
local ZOMBIE_GLOW = Color3.fromRGB(120, 255, 140)
local BOSS_GLOW = Color3.fromRGB(190, 110, 255)
local THIEF_LABEL_COLOR = Color3.fromRGB(255, 220, 90)
local THIEF_GLOW = Color3.fromRGB(255, 200, 60)
local THIEF_SIDE = 0
local THIEF_IN = 0
local THIEF_HOP = 8
local THIEF_HOP_UP = 1.2
local THIEF_RUN_UP = 0.4
local THIEF_MIN_STEP = 1
local THIEF_PAUSE = { 1, 2.5 }
local SEEKER_COLOR = Color3.fromRGB(255, 70, 70)
local SEEKER_SKIN = Color3.fromRGB(255, 204, 153)
local SEEKER_SHIRT = Color3.fromRGB(196, 40, 28)
local SEEKER_PANTS = Color3.fromRGB(27, 42, 53)
local SEEKER_START = 22
local SEEKER_EYE = 2
local FOUND_SHOW = 1.6
local FOUND_NOTICE_GAP = 4
local STEP_EVERY = 0.2
local TREE_IN = 80
local TREE_TRIES = { { 0, 0 }, { -24, 0 }, { 24, 0 }, { 0, 24 }, { 0, -24 }, { -24, 24 }, { 24, 24 }, { -24, -24 },
	{ 24, -24 } }
local TREE_CLEAR = 9
local TREE_TRUNK = Vector2.new(2.4, 5.5)
local TREE_CROWN = Vector3.new(9, 7, 9)
local TREE_CROWN_UP = 2.8
local TREE_LEAF_SEE = 0.25
local TREE_TUFTS = { { 3.2, 1, 0, 4.6 }, { -2.8, 0.6, 2, 4.2 }, { 0.5, 2.6, -2.4, 3.8 } }
local TREE_HINT = 7
local TREE_FOOT = Vector3.new(8, 0, 0)
local TREE_HINT_AFTER = 2
local TREE_TRUNK_COLOR = Color3.fromRGB(110, 78, 50)
local TREE_LEAF_COLOR = Color3.fromRGB(90, 170, 80)
local TREE_TUFT_COLOR = Color3.fromRGB(110, 190, 90)
local TRAP_ON_GROUND = 8
local TRAP_CATCH = 0.55
local TRAP_SHUT_SHOW = 1.5
local TRAP_MAX = 3
local LURE_AFTER = 4
local LURE_PAST = 4
local TRAP_EVENTS = { HideTrapSet = true, HideTrapSnap = true, HideSurvive = true }

local folder = nil
local treeFolder = nil
local sessions = {}
local lastTry = {}
local rng = Random.new()

local function frameOf(player)
	local base = Bases.folderOf(player)
	local zone = base and base:FindFirstChild("SafeZone")
	local flat = zone and Vector3.new(zone.Position.X, 0, zone.Position.Z)
	if not flat or flat.Magnitude < 1e-3 then
		return nil
	end
	local out = flat.Unit
	return out, out:Cross(Vector3.yAxis).Unit
end

local function fieldSpot(player, side, inward)
	local out, right = frameOf(player)
	local edge = Formulas.unlockOf("FieldEdge")
	if not out or not edge or not edge.Zone then
		return nil
	end
	local at = out * ((edge.Zone.From + edge.Zone.To) / 2 - (inward or 0)) + right * side
	return Vector3.new(at.X, Bases.groundBelow(Vector3.new(at.X, 40, at.Z), { folder }), at.Z), out
end

local function label(model, text, color)
	local part = model.PrimaryPart or model:FindFirstChildWhichIsA("BasePart", true)
	if not part then
		return nil
	end
	local _, size = model:GetBoundingBox()
	local gui = Instance.new("BillboardGui")
	gui.Name = "PracticeLabel"
	gui.Size = LABEL_SIZE
	gui.LightInfluence = 0
	gui.Adornee = part
	gui.StudsOffsetWorldSpace = Vector3.new(0, size.Y / 2 + LABEL_UP, 0)
	local text1 = Instance.new("TextLabel")
	text1.Size = UDim2.fromScale(1, 1)
	text1.BackgroundTransparency = 1
	text1.Font = Enum.Font.GothamBlack
	text1.TextScaled = true
	text1.TextColor3 = color
	text1.TextStrokeTransparency = 0.2
	text1.Text = text
	text1.Parent = gui
	gui.Parent = model
	return text1
end

local function zombieModel(name, scale, glow)
	local models = ReplicatedStorage:FindFirstChild("DinoModels")
	local source = models and models:FindFirstChild(name, true)
	local model = Instance.new("Model")
	model.Name = "Practice"
	if source then
		source:Clone().Parent = model
	else
		local p = Instance.new("Part")
		p.Name = "Body"
		p.Size = Vector3.new(2.4, 3, 5)
		p.Color = glow
		p.Parent = model
	end
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored, d.CanCollide, d.CanQuery, d.CanTouch = true, false, false, false
		elseif d:IsA("Script") or d:IsA("LocalScript") or d:IsA("ProximityPrompt") then
			d:Destroy()
		end
	end
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
	model:ScaleTo(scale * math.min(ZOMBIE_HEIGHT / math.max(size.Y, 0.1), ZOMBIE_LENGTH / math.max(size.X, size.Z, 0.1)))
	local part = model:FindFirstChildWhichIsA("BasePart", true)
	part.PivotOffset = part.CFrame:ToObjectSpace(model:GetPivot())
	model.PrimaryPart = part
	model:SetAttribute("PoopScale", scale * POOP_SCALE)
	local outline = Instance.new("Highlight")
	outline.FillTransparency = 0.8
	outline.FillColor = glow
	outline.OutlineColor = glow
	outline.DepthMode = Enum.HighlightDepthMode.Occluded
	outline.Parent = model
	return model
end

local function put(player, model, at, out, kind)
	model:PivotTo(CFrame.lookAt(at, at + out))
	model:SetAttribute("OnlyFor", player.UserId)
	model:SetAttribute("Kind", kind)
	model.Parent = folder
end

local function tweenPivot(model, from, to, seconds, arc, spin, mid, linear)
	local value = Instance.new("NumberValue")
	local up = CFrame.new(0, mid or 0, 0)
	value.Changed:Connect(function(a)
		if model.Parent then
			model:PivotTo(from:Lerp(to, a) * CFrame.new(0, math.sin(a * math.pi) * (arc or 0), 0) * up
				* CFrame.Angles(0, 0, (spin or 0) * a) * up:Inverse())
		end
	end)
	local style = linear and Enum.EasingStyle.Linear or Enum.EasingStyle.Quad
	local tween = TweenService:Create(value, TweenInfo.new(seconds, style, Enum.EasingDirection.Out), { Value = 1 })
	tween.Completed:Connect(function()
		value:Destroy()
	end)
	local at = Workspace:GetServerTimeNow()
	model:SetAttribute("MoveFrom", from)
	model:SetAttribute("MoveTo", to)
	model:SetAttribute("MoveArc", arc or 0)
	model:SetAttribute("MoveSpin", spin or 0)
	model:SetAttribute("MoveMid", mid or 0)
	model:SetAttribute("MoveLinear", linear == true or nil)
	model:SetAttribute("MoveSeconds", seconds)
	model:SetAttribute("MoveAt", at)
	tween:Play()
	return {
		Cancel = function()
			tween:Cancel()
			if model.Parent and model:GetAttribute("MoveAt") == at then
				model:SetAttribute("MoveAt", nil)
			end
		end,
	}
end

local function knock(entry, from, how)
	if entry.tween then
		entry.tween:Cancel()
	end
	local start = entry.model:GetPivot()
	local home = entry.home
	local away = Vector3.new(home.X - from.X, 0, home.Z - from.Z)
	away = away.Magnitude > 0.01 and away.Unit or -home.LookVector
	local spot = home.Position + away * how.Studs
	local r = Vector3.new(spot.X, 0, spot.Z).Magnitude
	local edge = Formulas.unlockOf("FieldEdge")
	if edge and edge.Zone then
		local flat = Vector3.new(spot.X, 0, spot.Z).Unit * math.clamp(r, edge.Zone.To + 2, edge.Zone.From - 2)
		spot = Vector3.new(flat.X, spot.Y, flat.Z)
	end
	local ground = Bases.groundBelow(Vector3.new(spot.X, spot.Y + 20, spot.Z), { folder })
	local target = CFrame.lookAt(Vector3.new(spot.X, ground, spot.Z), Vector3.new(spot.X, ground, spot.Z) - away)
	entry.tween = tweenPivot(entry.model, start, target, how.Seconds, how.Up, math.pi * 2, ZOMBIE_HEIGHT / 2)
	entry.home = target
	return entry.tween
end

local function unopenedChests(s)
	local list = {}
	for _, chest in ipairs(s.bossChests or {}) do
		if chest.Parent and not chest:GetAttribute("Opened") then
			table.insert(list, chest)
		end
	end
	return list
end

local function removeAll(s)
	for _, entry in ipairs(s.targets or {}) do
		if entry.model.Parent then
			entry.model:Destroy()
		end
	end
	s.targets = {}
	if s.chest and s.chest.Parent and not s.chest:GetAttribute("Opened") then
		require(script.Parent:WaitForChild("Treasure")).removeChest(s.chest)
	end
	s.chest = nil
	for _, chest in ipairs(s.bossChests or {}) do
		if chest.Parent and not chest:GetAttribute("Opened") then
			require(script.Parent:WaitForChild("Treasure")).removeChest(chest)
		end
	end
	s.bossChests = nil
	if s.seeker then
		s.seeker.model:Destroy()
		s.seeker = nil
	end
	for _, trap in ipairs(s.traps or {}) do
		trap.model:Destroy()
	end
	s.traps = nil
	if s.treeModel then
		s.treeModel:Destroy()
		s.treeModel = nil
	end
	s.thief = nil
end

local function bossText(hp)
	return string.format("👑 연습 보스 ❤️ %d/%d", hp, C.BossHits)
end

local function startZombies(player, s)
	for i = 1, C.ZombieCount do
		local side = (i - (C.ZombieCount + 1) / 2) * ZOMBIE_SIDE
		local at, out = fieldSpot(player, side, ZOMBIE_IN[(i - 1) % #ZOMBIE_IN + 1])
		if not at then
			return false
		end
		local model = zombieModel(Config.Zombies.Model, 1, ZOMBIE_GLOW)
		put(player, model, at, out, "Zombie")
		label(model, "🧟 연습 좀비", LABEL_COLOR)
		table.insert(s.targets, { model = model, home = model:GetPivot(), body = C.ZombieBody, hitAt = 0, kind = "Zombie" })
	end
	return true
end

local function startBoss(player, s)
	local at, out = fieldSpot(player, BOSS_SIDE, 0)
	if not at then
		return false
	end
	local kinds = Config.Zombies.Boss.Kinds
	local model = zombieModel(kinds[1] and kinds[1].Model or Config.Zombies.Model, BOSS_SCALE, BOSS_GLOW)
	put(player, model, at, out, "Boss")
	local entry = { model = model, home = model:GetPivot(), body = C.BossBody, hitAt = 0, kind = "Boss", hp = C.BossHits,
		spawn = model:GetPivot() }
	entry.text = label(model, bossText(entry.hp), BOSS_LABEL_COLOR)
	table.insert(s.targets, entry)
	return true
end

local function startChest(player, s)
	local at = fieldSpot(player, CHEST_SIDE, 0)
	if not at then
		return false
	end
	s.chest = require(script.Parent:WaitForChild("Treasure")).spawnFor(player, at)
	return s.chest ~= nil
end

local function guardText(chasing)
	return chasing and "🛡️ 연습 지킴이 · ❗" or "🛡️ 연습 지킴이"
end

local function practiceBox(player, entry)
	local Keys = require(script.Parent:WaitForChild("Keys"))
	if Keys.carriedFor(player) > 0 or Keys.groundFor(player) > 0 then
		return
	end
	local cf = entry.spawn
	Keys.dropFor(player, cf.Position + cf.LookVector * C.GuardBoxAhead, 1)
end

local function startThief(player, s)
	local at, out = fieldSpot(player, THIEF_SIDE, THIEF_IN)
	if not at then
		return false
	end
	local model = zombieModel(Config.Zombies.Guardians.Model, 1, THIEF_GLOW)
	put(player, model, at, out, "Thief")
	local entry = { model = model, home = model:GetPivot(), spawn = model:GetPivot(), body = C.ThiefBody, hitAt = 0,
		kind = "Thief", busyUntil = 0, nextWander = 0, boxAt = 0 }
	entry.text = label(model, guardText(false), THIEF_LABEL_COLOR)
	s.thief = entry
	table.insert(s.targets, entry)
	practiceBox(player, entry)
	return true
end

local function thiefMove(entry, to, seconds, arc, linear)
	if entry.tween then
		entry.tween:Cancel()
	end
	entry.tween = tweenPivot(entry.model, entry.model:GetPivot(), to, seconds, arc, 0, nil, linear)
	entry.home = to
end

local function thiefStep(player, s, now)
	local entry = s.thief
	if not entry or not entry.model.Parent then
		return
	end
	local Keys = require(script.Parent:WaitForChild("Keys"))
	local chasing = Keys.carriedFor(player) > 0
	if chasing ~= entry.chasing then
		entry.chasing = chasing
		entry.text.Text = guardText(chasing)
	end
	if not chasing and now >= entry.boxAt then
		entry.boxAt = now + C.GuardBoxEvery
		practiceBox(player, entry)
	end
	if now < entry.busyUntil then
		return
	end
	local from = entry.model:GetPivot()
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local goal = nil
	if chasing and root then
		local to = Vector3.new(root.Position.X - from.X, 0, root.Position.Z - from.Z)
		local fromSpawn = Vector3.new(root.Position.X - entry.spawn.X, 0, root.Position.Z - entry.spawn.Z)
		if to.Magnitude <= C.GuardCatch then
			Keys.returnBoxes(player, from.Position)
			Net.push(player, "Notice", "🛡️ 연습 지킴이", "잡혔어요! 상자가 지킴이 옆으로 돌아갔어요 · 👋 찰싹하고 다시!")
			entry.busyUntil = now + C.GuardRest
			return
		end
		if fromSpawn.Magnitude <= C.GuardChaseRange then
			goal = from.Position + (to.Magnitude > 0.01 and to.Unit or from.LookVector) * math.min(THIEF_HOP, to.Magnitude)
		end
	end
	if not goal then
		if now < entry.nextWander then
			return
		end
		entry.nextWander = now + rng:NextNumber(THIEF_PAUSE[1], THIEF_PAUSE[2])
		local a, r = rng:NextNumber(0, 2 * math.pi), rng:NextNumber(0, C.ThiefRoam)
		goal = entry.spawn.Position + Vector3.new(math.cos(a) * r, 0, math.sin(a) * r)
	end
	local off = Vector3.new(goal.X - entry.spawn.X, 0, goal.Z - entry.spawn.Z)
	if off.Magnitude > C.GuardChaseRange then
		goal = entry.spawn.Position + off.Unit * C.GuardChaseRange
	end
	local flat = Vector3.new(goal.X - from.X, 0, goal.Z - from.Z)
	if flat.Magnitude < THIEF_MIN_STEP then
		return
	end
	local ground = Bases.groundBelow(Vector3.new(goal.X, from.Y + 20, goal.Z), { folder })
	local at = Vector3.new(goal.X, ground, goal.Z)
	local seconds = flat.Magnitude / C.ThiefSpeed
	thiefMove(entry, CFrame.lookAt(at, at + flat.Unit), seconds, chasing and THIEF_RUN_UP or THIEF_HOP_UP, chasing)
	entry.busyUntil = now + seconds
end

local function thiefHit(player, entry, from)
	entry.home = entry.model:GetPivot()
	if entry.tween then
		entry.tween:Cancel()
	end
	entry.tween = knock(entry, from, GUARD_KNOCK)
	entry.busyUntil = os.clock() + C.ThiefBack
end

local function seekerModel()
	local d = Instance.new("HumanoidDescription")
	d.HeadColor, d.LeftArmColor, d.RightArmColor = SEEKER_SKIN, SEEKER_SKIN, SEEKER_SKIN
	d.TorsoColor, d.LeftLegColor, d.RightLegColor = SEEKER_SHIRT, SEEKER_PANTS, SEEKER_PANTS
	local ok, model = pcall(function()
		return Players:CreateHumanoidModelFromDescription(d, Enum.HumanoidRigType.R15)
	end)
	if ok and model then
		for _, x in ipairs(model:GetDescendants()) do
			if x:IsA("Script") or x:IsA("LocalScript") then
				x:Destroy()
			end
		end
		local humanoid = model:FindFirstChildOfClass("Humanoid")
		humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
		humanoid.WalkSpeed = C.SeekerSpeed
		return model, humanoid
	end
	local stand = Instance.new("Model")
	local body = Instance.new("Part")
	body.Name = "HumanoidRootPart"
	body.Size = Vector3.new(2, 5, 1.2)
	body.Color = SEEKER_SHIRT
	body.Anchored, body.CanCollide = true, false
	body.Parent = stand
	stand.PrimaryPart = body
	return stand, nil
end

local function clearAt(at)
	local holders = {}
	local map = Workspace:FindFirstChild("Map")
	for _, x in ipairs({ map and map:FindFirstChild("FieldDecor"), Workspace:FindFirstChild("Minerals"),
		Workspace:FindFirstChild("SpeedPads"), Workspace:FindFirstChild("TreasureChests"), folder }) do
		if x then
			table.insert(holders, x)
		end
	end
	local params = OverlapParams.new()
	params.FilterType = Enum.RaycastFilterType.Include
	params.FilterDescendantsInstances = holders
	return #Workspace:GetPartBoundsInRadius(at + Vector3.new(0, TREE_CLEAR / 2, 0), TREE_CLEAR, params) == 0
end

local function plainTree()
	local model = Instance.new("Model")
	local trunk = Instance.new("Part")
	trunk.Name = "Trunk"
	trunk.Shape = Enum.PartType.Cylinder
	trunk.Size = Vector3.new(TREE_TRUNK.Y, TREE_TRUNK.X, TREE_TRUNK.X)
	trunk.CFrame = CFrame.new(0, TREE_TRUNK.Y / 2, 0) * CFrame.Angles(0, 0, math.rad(90))
	trunk.Color = TREE_TRUNK_COLOR
	trunk.Parent = model
	local up = TREE_TRUNK.Y + TREE_CROWN_UP
	local leaves = Instance.new("Part")
	leaves.Name = "Leaves"
	leaves.Size = TREE_CROWN
	leaves.CFrame = CFrame.new(0, up, 0)
	leaves.Color = TREE_LEAF_COLOR
	leaves.Transparency = TREE_LEAF_SEE
	leaves.CanCollide, leaves.CanQuery, leaves.CanTouch = false, false, false
	local shape = Instance.new("SpecialMesh")
	shape.MeshType = Enum.MeshType.Sphere
	shape.Parent = leaves
	leaves.Parent = model
	for _, t in ipairs(TREE_TUFTS) do
		local tuft = leaves:Clone()
		tuft.Name = "Tuft"
		tuft.Size = Vector3.one * t[4]
		tuft.CFrame = CFrame.new(t[1], up + t[2], t[3])
		tuft.Color = TREE_TUFT_COLOR
		tuft.Parent = model
	end
	model.WorldPivot = CFrame.new()
	return model, TREE_TRUNK.Y
end

local function plantTree(player, s)
	local at = nil
	for _, try in ipairs(TREE_TRIES) do
		local spot = fieldSpot(player, try[1], TREE_IN + try[2])
		if spot and clearAt(spot) then
			at = spot
			break
		end
	end
	at = at or fieldSpot(player, 0, TREE_IN)
	if not at then
		return nil
	end
	local model, up = plainTree()
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored = true
		end
	end
	model.Name = "PracticeTree"
	model:SetAttribute("OnlyFor", player.UserId)
	model:PivotTo(CFrame.new(at))
	model.Parent = treeFolder
	s.treeModel = model
	s.treeTop = at + Vector3.new(0, up, 0)
	return at
end

local function startSeeker(player, s)
	local tree = plantTree(player, s)
	if not tree then
		return false
	end
	s.tree = tree
	s.traps = {}
	local model, humanoid = seekerModel()
	local a = rng:NextNumber(0, 2 * math.pi)
	local at = tree + Vector3.new(math.cos(a), 0, math.sin(a)) * SEEKER_START
	local ground = Bases.groundBelow(Vector3.new(at.X, at.Y + 30, at.Z), { folder, treeFolder })
	model.Name = "Practice"
	model:SetAttribute("OnlyFor", player.UserId)
	model:SetAttribute("Kind", "Seeker")
	local root = model.PrimaryPart or model:FindFirstChild("HumanoidRootPart")
	local hip = humanoid and humanoid.HipHeight + root.Size.Y / 2 or root.Size.Y / 2
	model:PivotTo(CFrame.new(at.X, ground + hip + 0.2, at.Z))
	local outline = Instance.new("Highlight")
	outline.FillTransparency = 0.7
	outline.FillColor = SEEKER_COLOR
	outline.OutlineColor = SEEKER_COLOR
	outline.Parent = model
	model.Parent = folder
	if humanoid then
		pcall(function()
			root:SetNetworkOwner(nil)
		end)
	end
	s.seeker = { model = model, humanoid = humanoid, root = root, nextMove = 0, foundAt = -math.huge,
		text = label(model, "👀 연습 술래", SEEKER_LABEL_COLOR), last = root.Position, frozenUntil = 0 }
	player:SetAttribute("HideSeekPractice", true)
	player:SetAttribute("HideSeekDisguises", 99)
	player:SetAttribute("HideSeekDisguiseReady", 0)
	player:SetAttribute("HideSeekTraps", Config.HideSeek.TrapCount)
	s.hiddenTime = 0
	return true
end

local function stopHide(player)
	player:SetAttribute("HideSeekTrapPractice", nil)
	player:SetAttribute("HideCountLeft", nil)
	player:SetAttribute("HideCountFar", nil)
	if player:GetAttribute("HideSeekPractice") then
		player:SetAttribute("HideSeekPractice", nil)
		player:SetAttribute("HidePracticeLeft", nil)
		player:SetAttribute("HidePracticeState", nil)
		if not player:GetAttribute("HideSeekRoom") then
			player:SetAttribute("HideSeekDisguises", nil)
			player:SetAttribute("HideSeekDisguiseReady", nil)
			player:SetAttribute("HideSeekTraps", nil)
			pcall(function()
				require(script.Parent:WaitForChild("HideSeek")).clearDisguise(player)
			end)
		end
	end
end

local function stop(player)
	local s = sessions[player]
	sessions[player] = nil
	if s then
		removeAll(s)
	end
	stopHide(player)
end

local STARTS = { Zombies = startZombies, Boss = startBoss, Chest = startChest, HideSeek = startSeeker, Thief = startThief }

function Practice.want(player, kind)
	local s = sessions[player]
	if s and s.kind == kind then
		return
	end
	if s or player:GetAttribute("HideSeekPractice") then
		stop(player)
	end
	if not kind or not STARTS[kind] or not player.Parent then
		return
	end
	if os.clock() - (lastTry[player] or -math.huge) < C.RetryGap then
		return
	end
	lastTry[player] = os.clock()
	s = { kind = kind, targets = {} }
	if STARTS[kind](player, s) then
		sessions[player] = s
		lastTry[player] = nil
	else
		removeAll(s)
		stopHide(player)
	end
end

local function nearestOf(player, kind)
	local s = sessions[player]
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local best, bestD = nil, math.huge
	for _, entry in ipairs(s and s.targets or {}) do
		if entry.kind == kind and entry.model.Parent then
			local at = entry.model:GetPivot().Position
			local d = root and (at - root.Position).Magnitude or 0
			if d < bestD then
				best, bestD = at, d
			end
		end
	end
	return best
end

function Practice.kindOf(player)
	local s = sessions[player]
	return s and s.kind or nil
end

function Practice.poop(player, at, reach, seconds)
	local s = sessions[player]
	local spots, boss = {}, false
	for _, entry in ipairs(s and s.targets or {}) do
		local p = entry.model.Parent and not entry.down and entry.model:GetPivot().Position
		if p and Vector3.new(p.X - at.X, 0, p.Z - at.Z).Magnitude <= reach + entry.body then
			entry.model:SetAttribute("PoopUntil", Workspace:GetServerTimeNow() + seconds)
			if entry.kind == "Thief" then
				entry.busyUntil = math.max(entry.busyUntil or 0, os.clock() + seconds)
			end
			boss = boss or entry.kind == "Boss"
			table.insert(spots, p + Vector3.new(0, 2, 0))
		end
	end
	return spots, boss
end

function Practice.zombieOf(player)
	return nearestOf(player, "Zombie")
end

function Practice.bossOf(player)
	local s = sessions[player]
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	local best, bestD = nil, math.huge
	for _, chest in ipairs(s and unopenedChests(s) or {}) do
		local at = chest:GetPivot().Position
		local d = root and (at - root.Position).Magnitude or 0
		if d < bestD then
			best, bestD = at, d
		end
	end
	return best or nearestOf(player, "Boss")
end

function Practice.bossChestsOut(player)
	local s = sessions[player]
	return s ~= nil and #unopenedChests(s) > 0
end

function Practice.thiefOf(player)
	local s = sessions[player]
	local entry = s and s.thief
	return entry and entry.model.Parent and not entry.down and entry.model:GetPivot().Position or nil
end

function Practice.seekerOf(player)
	local s = sessions[player]
	local seeker = s and s.seeker
	return seeker and seeker.model.Parent and seeker.root.Position or nil
end

function Practice.treeOf(player)
	local s = sessions[player]
	return s and s.tree or nil
end

function Practice.upTree(player)
	local s = sessions[player]
	local top = s and s.treeTop
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not top or not root then
		return false
	end
	local p = root.Position
	return Vector3.new(p.X - top.X, 0, p.Z - top.Z).Magnitude <= TREE_HINT and p.Y >= top.Y
end

function Practice.treeFootOf(player)
	local s = sessions[player]
	local base = s and s.tree
	return base and base + TREE_FOOT or nil
end

function Practice.trapOf(player)
	local s = sessions[player]
	for i = #(s and s.traps or {}), 1, -1 do
		if not s.traps[i].shut then
			return s.traps[i].at
		end
	end
	return s and s.tree or nil
end

function Practice.placeTrap(player)
	local s = sessions[player]
	if not s or s.kind ~= "HideSeek" or not s.seeker or not player:GetAttribute("HideSeekTrapPractice") then
		return
	end
	local H = Config.HideSeek
	local now = os.clock()
	if now - (s.trapAt or -math.huge) < H.TrapCooldown then
		return
	end
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not root or not humanoid or humanoid.Health <= 0 then
		return
	end
	local ground = Bases.groundBelow(root.Position, { character, folder, treeFolder })
	if humanoid.FloorMaterial == Enum.Material.Air or root.Position.Y - ground > TRAP_ON_GROUND then
		return Net.push(player, "Notice", "🙈 숨바꼭질 연습", "🕸️ 땅 위에서 놓아요")
	end
	local at = Vector3.new(root.Position.X, ground, root.Position.Z)
	local seekerAt = s.seeker.root.Position
	if Vector3.new(seekerAt.X - at.X, 0, seekerAt.Z - at.Z).Magnitude < H.TrapSeekerGap then
		return Net.push(player, "Notice", "🙈 숨바꼭질 연습", "🕸️ 술래 가까이에는 놓을 수 없어요")
	end
	for _, other in ipairs(s.traps) do
		if not other.shut and Vector3.new(other.at.X - at.X, 0, other.at.Z - at.Z).Magnitude < H.TrapGap then
			return Net.push(player, "Notice", "🙈 숨바꼭질 연습", "🕸️ 다른 함정과 너무 가까워요")
		end
	end
	s.trapAt = now
	while #s.traps >= TRAP_MAX do
		table.remove(s.traps, 1).model:Destroy()
	end
	local yaw = rng:NextNumber(0, 2 * math.pi)
	local model = require(script.Parent:WaitForChild("HideSeek")).trapLook("Prop_HideTrap", at, yaw)
	model:SetAttribute("OnlyFor", player.UserId)
	model.Parent = folder
	table.insert(s.traps, { at = at, yaw = yaw, model = model })
	s.lureAt = nil
	Net.push(player, "HideSeekTrapFx", "Set", at)
	Unlocks.event(player, "HideTrapSet", 1)
end

local function bossHit(player, entry, bomb)
	entry.hp -= 1
	Rewards.add(player, "BossHit", 1)
	if bomb then
		Rewards.add(player, "BossBomb", 1)
	end
	if entry.text then
		entry.text.Text = bossText(math.max(entry.hp, 0))
	end
	if entry.hp > 0 then
		return
	end
	entry.down = true
	local model = entry.model
	local s = sessions[player]
	if s and #unopenedChests(s) == 0 then
		s.bossChests = {}
		local Treasure = require(script.Parent:WaitForChild("Treasure"))
		local at = entry.home.Position
		for i = 1, C.BossChests do
			local a = i * 2 * math.pi / C.BossChests
			local chest = Treasure.spawnFor(player, at + Vector3.new(math.cos(a) * C.BossChestSpread, 0, math.sin(a) * C.BossChestSpread))
			if chest then
				table.insert(s.bossChests, chest)
				chest:GetAttributeChangedSignal("Opened"):Connect(function()
					if chest:GetAttribute("Opened") == player.UserId then
						Rewards.add(player, "PracticeBossDown", 1)
					end
				end)
			end
		end
		Net.push(player, "Notice", "👑 연습 보스를 쓰러뜨렸어요!",
			string.format("📦 보물상자 %d개가 쏟아졌어요! 열어서 가져가요\n🌙 진짜 밤 보스는 다 같이 잡으면 상자가 더 많이, 🦴 뼈도 모여요", C.BossChests))
	end
	tweenPivot(model, entry.home, entry.home * CFrame.new(0, -ZOMBIE_HEIGHT * BOSS_SCALE, 0), SINK_SECONDS, 0, 0)
	task.delay(C.BossBack, function()
		if model.Parent then
			entry.hp, entry.down, entry.home = C.BossHits, false, entry.spawn
			model:PivotTo(entry.spawn)
			if entry.text then
				entry.text.Text = bossText(entry.hp)
			end
		end
	end)
end

local function onSlap(player, root, reach)
	local s = sessions[player]
	if not s or #s.targets == 0 then
		return nil
	end
	local spots = {}
	local look = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z)
	local now = os.clock()
	for _, entry in ipairs(s.targets) do
		if entry.model.Parent and not entry.down and now - entry.hitAt >= C.HitGap then
			local at = entry.model:GetPivot().Position
			local offset = Vector3.new(at.X - root.Position.X, 0, at.Z - root.Position.Z)
			local d = offset.Magnitude
			local front = (typeof(root) == "table" and root.Bomb) or d < entry.body or (look.Magnitude > 0.01 and offset.Unit:Dot(look.Unit) > 0)
			if d <= reach + entry.body and front then
				entry.hitAt = now
				table.insert(spots, at + Vector3.new(0, 2, 0))
				if entry.kind == "Boss" then
					bossHit(player, entry, typeof(root) == "table" and root.Bomb == true)
				elseif entry.kind == "Thief" then
					thiefHit(player, entry, root.Position)
				else
					Rewards.add(player, "ZombieSlap", 1)
					knock(entry, root.Position, ZOMBIE_KNOCK)
				end
			end
		end
	end
	return spots
end

local function groundUnder(position, ignore)
	return Bases.groundBelow(position, ignore)
end

local function inTree(s, root)
	local top = s.treeTop
	if not top then
		return false
	end
	local p = root.Position
	local up = p.Y - top.Y
	return Vector3.new(p.X - top.X, 0, p.Z - top.Z).Magnitude <= C.TreeStand and up >= C.TreeOn and up <= TREE_CROWN.Y
end

local function treeHint(player, s, root, now, hidden)
	local top = s.treeTop
	local p = root.Position
	local near = top and not hidden and Vector3.new(p.X - top.X, 0, p.Z - top.Z).Magnitude <= TREE_HINT and p.Y < top.Y
	if not near then
		s.underTreeSince = nil
		return
	end
	s.underTreeSince = s.underTreeSince or now
	if now - s.underTreeSince >= TREE_HINT_AFTER and now - (s.treeHintAt or -math.huge) >= FOUND_NOTICE_GAP * 2 then
		s.treeHintAt = now
		Net.push(player, "Notice", "🙈 숨바꼭질 연습", "🧗 줄기 쪽으로 계속 걸으면 올라가요! 줄기 위에 서면 잎 속이에요")
	end
end

local function seen(player, s, root, hidden)
	local seeker = s.seeker
	local eye = seeker.root.Position + Vector3.new(0, SEEKER_EYE, 0)
	local d = Vector3.new(root.Position.X - eye.X, 0, root.Position.Z - eye.Z).Magnitude
	if hidden or d > C.SeekerSee or (player:GetAttribute("HideSeekDisguise") and d > C.SeekerSeeDisguised) then
		return false
	end
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { player.Character, folder }
	local hit = Workspace:Raycast(eye, root.Position - eye, params)
	return hit == nil
end

local function walkSeeker(s, goal)
	local seeker = s.seeker
	if seeker.humanoid then
		seeker.humanoid:MoveTo(goal)
		return
	end
	local from = seeker.model:GetPivot()
	local ground = groundUnder(Vector3.new(goal.X, from.Y + 20, goal.Z), { folder, treeFolder })
	local to = CFrame.new(goal.X, ground + seeker.root.Size.Y / 2, goal.Z)
	local value = Instance.new("NumberValue")
	value.Changed:Connect(function(t)
		if seeker.model.Parent and os.clock() >= seeker.frozenUntil then
			seeker.model:PivotTo(from:Lerp(to, t))
		end
	end)
	local tween = TweenService:Create(value, TweenInfo.new((to.Position - from.Position).Magnitude / C.SeekerSpeed), { Value = 1 })
	tween.Completed:Connect(function()
		value:Destroy()
	end)
	tween:Play()
end

local function moveSeeker(s, now)
	local seeker = s.seeker
	if now < seeker.nextMove or now < seeker.frozenUntil then
		return
	end
	seeker.nextMove = now + rng:NextNumber(C.SeekerPause[1], C.SeekerPause[2]) + 2
	local a, r = rng:NextNumber(0, 2 * math.pi), rng:NextNumber(4, C.SeekerRoam)
	walkSeeker(s, s.tree + Vector3.new(math.cos(a) * r, 0, math.sin(a) * r))
end

local function snapTrap(player, s, trap, now)
	local H = Config.HideSeek
	local seeker = s.seeker
	trap.shut = true
	trap.model:Destroy()
	trap.model = require(script.Parent:WaitForChild("HideSeek")).trapLook("Prop_HideTrapShut", trap.at, trap.yaw)
	trap.model:SetAttribute("OnlyFor", player.UserId)
	trap.model.Parent = folder
	seeker.frozenUntil = now + H.TrapStunSeconds
	seeker.nextMove = seeker.frozenUntil + 0.5
	if seeker.humanoid then
		seeker.humanoid:MoveTo(seeker.root.Position)
	end
	if seeker.text then
		seeker.text.Text = "🕸️ 걸렸다!"
	end
	s.lureAt = nil
	Net.push(player, "HideSeekTrapFx", "Snap", trap.at, 0, player.UserId)
	Net.push(player, "Notice", "🙈 숨바꼭질 연습", "🕸️ 철컥! 술래가 잠깐 멈췄어요 · 그 틈에 도망가요")
	Unlocks.event(player, "HideTrapSnap", 1)
	local model = trap.model
	task.delay(TRAP_SHUT_SHOW, function()
		local i = table.find(s.traps or {}, trap)
		if i then
			table.remove(s.traps, i)
		end
		model:Destroy()
		if seeker.text and seeker.model.Parent then
			seeker.text.Text = "👀 연습 술래"
		end
	end)
end

local function checkTraps(player, s, now)
	local seeker = s.seeker
	local here = seeker.root.Position
	local was = seeker.last or here
	seeker.last = here
	if now < seeker.frozenUntil then
		return
	end
	local catch = Config.HideSeek.TrapSize * TRAP_CATCH
	local a, b = Vector3.new(was.X, 0, was.Z), Vector3.new(here.X, 0, here.Z)
	local ab = b - a
	for _, trap in ipairs(s.traps or {}) do
		if not trap.shut then
			local p = Vector3.new(trap.at.X, 0, trap.at.Z)
			local t = ab.Magnitude > 1e-3 and math.clamp((p - a):Dot(ab) / ab:Dot(ab), 0, 1) or 0
			if (a + ab * t - p).Magnitude <= catch then
				snapTrap(player, s, trap, now)
				return
			end
		end
	end
end

local function lure(s, now)
	local seeker = s.seeker
	if now < seeker.frozenUntil or now - (s.lastSeen or -math.huge) < LURE_AFTER then
		return
	end
	for i = #s.traps, 1, -1 do
		local trap = s.traps[i]
		if not trap.shut then
			if s.lureAt ~= trap.at or now >= seeker.nextMove then
				s.lureAt = trap.at
				local from = Vector3.new(seeker.root.Position.X, 0, seeker.root.Position.Z)
				local to = Vector3.new(trap.at.X, 0, trap.at.Z)
				local through = (to - from).Magnitude > 1e-3 and (to - from).Unit * LURE_PAST or Vector3.zero
				seeker.nextMove = now + C.SeekerPause[2] + 6
				walkSeeker(s, trap.at + through)
			end
			return
		end
	end
end

local CHASE_EVENTS = { HideDisguise = true, HideTree = true, HideTrapSet = true }

local function flatDistance(a, b)
	return Vector3.new(a.X - b.X, 0, a.Z - b.Z).Magnitude
end

local function seekerSays(s, text)
	if s.seeker.text then
		s.seeker.text.Text = text
	end
end

local function chase(s, at, now)
	local seeker = s.seeker
	if seeker.humanoid then
		seeker.humanoid:MoveTo(at)
	elseif now >= (seeker.chaseAt or 0) then
		seeker.chaseAt = now + 1
		walkSeeker(s, at)
	end
	seeker.nextMove = now + C.SeekerPause[1]
end

local function meetStep(player, s, root)
	seekerSays(s, "👋 나는 술래! 가까이 와요")
	if flatDistance(root.Position, s.seeker.root.Position) <= C.MeetRange then
		seekerSays(s, "👀 연습 술래")
		Net.push(player, "Notice", "🙈 숨바꼭질 연습", "👀 이게 술래예요! 술래가 숫자를 세면 멀리 도망가요")
		Unlocks.event(player, "HideMeet", 1)
	end
end

local function countStep(player, s, root, now)
	local seeker = s.seeker
	if not s.countEnd then
		s.countEnd = now + C.CountSeconds
		if seeker.humanoid then
			seeker.humanoid:MoveTo(seeker.root.Position)
		end
	end
	local left = math.max(0, s.countEnd - now)
	local far = flatDistance(root.Position, seeker.root.Position)
	player:SetAttribute("HideCountLeft", math.ceil(left))
	player:SetAttribute("HideCountFar", math.floor(far))
	seekerSays(s, string.format("🙈 %d…", math.ceil(left)))
	if left > 0 then
		return
	end
	s.countEnd = nil
	player:SetAttribute("HideCountLeft", nil)
	player:SetAttribute("HideCountFar", nil)
	seekerSays(s, "👀 연습 술래")
	if far >= C.RunDistance then
		Net.push(player, "Notice", "🙈 숨바꼭질 연습", "🏃 잘 도망갔어요! 이제 술래가 찾으러 와요")
		Unlocks.event(player, "HideRun", 1)
	else
		Net.push(player, "Notice", "🙈 숨바꼭질 연습", "😅 너무 가까워요! 술래가 다시 세요 · 🏃 더 멀리!")
	end
end

local function chaseStep(player, s, root, now, hidden)
	local seeker = s.seeker
	if now < seeker.frozenUntil or not seen(player, s, root, hidden) then
		return
	end
	s.lastSeen = now
	seeker.foundAt = now
	if flatDistance(root.Position, seeker.root.Position) <= C.CatchRange then
		seeker.frozenUntil = now + C.CatchPause
		seeker.nextMove = seeker.frozenUntil
		if seeker.humanoid then
			seeker.humanoid:MoveTo(seeker.root.Position)
		end
		seekerSays(s, "👋 잡았다!")
		if now - (s.caughtNotice or -math.huge) >= FOUND_NOTICE_GAP then
			s.caughtNotice = now
			Net.push(player, "Notice", "🙈 숨바꼭질 연습", "👋 잡혔다! 🎭 변신하거나 🌳 나무 속에 숨어요")
		end
		return
	end
	seekerSays(s, "👀 찾았다!")
	chase(s, root.Position, now)
end

local function hideStep(player, s, now, dt)
	local profile = PlayerData.get(player)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not profile or not root or not s.seeker or not s.seeker.model.Parent then
		return
	end
	if player:GetAttribute("HideSeekRoom") then
		return stop(player)
	end
	local u, step = UnlockLogic.current(profile.Unlocks)
	local m = u and u.Steps[step]
	local event = m and m.Event
	player:SetAttribute("HideSeekTrapPractice", TRAP_EVENTS[event] or nil)
	if event ~= "HideRun" and s.countEnd then
		s.countEnd = nil
		player:SetAttribute("HideCountLeft", nil)
		player:SetAttribute("HideCountFar", nil)
	end
	if event == "HideMeet" then
		return meetStep(player, s, root)
	elseif event == "HideRun" then
		return countStep(player, s, root, now)
	end
	checkTraps(player, s, now)
	local hidden = inTree(s, root)
	if event == "HideTrapSet" and Practice.upTree(player) and now - (s.downNotice or -math.huge) >= FOUND_NOTICE_GAP then
		s.downNotice = now
		Net.push(player, "Notice", "🙈 숨바꼭질 연습", "⬇️ 나무에서 내려와요! 함정은 땅에 놓아요")
	end
	if event == "HideTrapSnap" then
		if seen(player, s, root, hidden) then
			s.lastSeen = now
			if now >= s.seeker.frozenUntil then
				chase(s, root.Position, now)
			end
		else
			lure(s, now)
		end
	elseif CHASE_EVENTS[event] then
		chaseStep(player, s, root, now, hidden)
	end
	moveSeeker(s, now)
	if event == "HideTree" then
		treeHint(player, s, root, now, hidden)
		s.treeTime = hidden and (s.treeTime or 0) + dt or 0
		if s.treeTime >= C.TreeSeconds then
			s.treeTime = 0
			Unlocks.event(player, "HideTree", 1)
		end
	end
	if event ~= "HideSurvive" then
		s.hiddenTime = 0
		s.openSince = nil
		player:SetAttribute("HidePracticeLeft", nil)
		player:SetAttribute("HidePracticeState", nil)
		if s.seeker.text and now - s.seeker.foundAt > FOUND_SHOW and now >= s.seeker.frozenUntil
			and (s.seeker.text.Text == "👀 찾았다!" or s.seeker.text.Text == "👋 잡았다!") then
			seekerSays(s, "👀 연습 술래")
		end
		return
	end
	local seeker = s.seeker.root.Position
	local away = Vector3.new(root.Position.X - seeker.X, 0, root.Position.Z - seeker.Z).Magnitude > C.PlayRadius
	local state
	if now >= s.seeker.frozenUntil and seen(player, s, root, hidden) then
		state = "Seen"
		s.hiddenTime = 0
		s.seeker.foundAt = now
		seekerSays(s, "👀 찾았다!")
		if now - (s.foundNotice or -math.huge) >= FOUND_NOTICE_GAP then
			s.foundNotice = now
			Net.push(player, "Notice", "🙈 숨바꼭질 연습", "👀 들켰어요! 🎭 변신하거나 🌳 나무에 숨어요")
		end
		chase(s, root.Position, now)
	elseif away then
		state = "Away"
		if now - (s.awayNotice or -math.huge) >= FOUND_NOTICE_GAP then
			s.awayNotice = now
			Net.push(player, "Notice", "🙈 숨바꼭질 연습", "🏃 술래 가까이에서 숨어요 · 너무 멀면 안 세요")
		end
	elseif hidden or player:GetAttribute("HideSeekDisguise") then
		state = "Hidden"
		s.hiddenTime = (s.hiddenTime or 0) + dt
	else
		state = "Open"
	end
	s.openSince = state == "Open" and (s.openSince or now) or nil
	if s.openSince and now - s.openSince >= TREE_HINT_AFTER and now - (s.openNotice or -math.huge) >= FOUND_NOTICE_GAP * 2 then
		s.openNotice = now
		Net.push(player, "Notice", "🙈 숨바꼭질 연습", "🎭 변신하거나 🌳 나무 위 잎 속에 숨어야 초가 줄어요")
	end
	if state ~= "Seen" and s.seeker.text and now - s.seeker.foundAt > FOUND_SHOW then
		seekerSays(s, "👀 연습 술래")
	end
	local left = math.max(0, C.SurviveSeconds - (s.hiddenTime or 0))
	player:SetAttribute("HidePracticeLeft", math.ceil(left))
	player:SetAttribute("HidePracticeState", state)
	if left <= 0 then
		s.hiddenTime = 0
		player:SetAttribute("HidePracticeLeft", nil)
		player:SetAttribute("HidePracticeState", nil)
		Unlocks.event(player, "HideSurvive", 1)
	end
end

function Practice.init()
	folder = Workspace:FindFirstChild("Practice") or Instance.new("Folder")
	folder.Name = "Practice"
	folder:ClearAllChildren()
	folder.Parent = Workspace
	treeFolder = Workspace:FindFirstChild("PracticeTrees") or Instance.new("Folder")
	treeFolder.Name = "PracticeTrees"
	treeFolder:ClearAllChildren()
	treeFolder.Parent = Workspace
	local Combat = require(script.Parent:WaitForChild("Combat"))
	Combat.onSlap(onSlap)
	Combat.onSafeSlap(onSlap)
	Players.PlayerRemoving:Connect(function(player)
		stop(player)
		lastTry[player] = nil
	end)
	local acc = 0
	RunService.Heartbeat:Connect(function(dt)
		local now = os.clock()
		for player, s in pairs(sessions) do
			if s.kind == "Thief" then
				thiefStep(player, s, now)
			end
		end
		acc += dt
		if acc < STEP_EVERY then
			return
		end
		local step = acc
		acc = 0
		for player, s in pairs(sessions) do
			if s.kind == "HideSeek" then
				hideStep(player, s, now, step)
			end
		end
	end)
end

return Practice
