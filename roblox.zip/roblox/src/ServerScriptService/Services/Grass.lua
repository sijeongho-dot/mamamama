local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local Grass = {}

local FOLDERS = { "FieldGrass", "SafeGrass" }
local PART_TEMPLATES = 8
local XZ_STEP = 0.05
local Y_STEP = 0.02
local SCALE_STEP = 0.02
local BLADE_WIDTH = 0.2
local CHUNK = 48000
local DIGITS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

local function encode(bytes)
	local out = {}
	for i = 1, #bytes, 3 do
		local a, b, c = string.byte(bytes, i, i + 2)
		local n = a * 65536 + (b or 0) * 256 + (c or 0)
		table.insert(out, string.char(string.byte(DIGITS, n // 262144 + 1), string.byte(DIGITS, n // 4096 % 64 + 1),
			string.byte(DIGITS, n // 64 % 64 + 1), string.byte(DIGITS, n % 64 + 1)))
	end
	return table.concat(out)
end

local function bare(model)
	local copy = model:Clone()
	for _, d in ipairs(copy:GetDescendants()) do
		if d.Name == "FlowerStem" or d.Name == "Flower" then
			d:Destroy()
		end
	end
	return copy
end

local function scaleOf(model)
	local ok, s = pcall(function()
		return model:GetScale()
	end)
	return ok and s or 1
end

local function quantize(v, step, low, high)
	return math.clamp(math.floor(v / step + 0.5), low, high)
end

local function footOf(model)
	local cf, size = model:GetBoundingBox()
	return CFrame.new(cf.Position.X, cf.Position.Y - size.Y / 2, cf.Position.Z)
end

function Grass.init()
	local map = Workspace:FindFirstChild("Map")
	local data = ReplicatedStorage:FindFirstChild("GrassData") or Instance.new("Folder")
	data.Name = "GrassData"
	data:ClearAllChildren()
	local templates = Instance.new("Folder")
	templates.Name = "Templates"
	templates.Parent = data
	local stored = ServerStorage:FindFirstChild("MapGrass") or Instance.new("Folder")
	stored.Name = "MapGrass"
	stored.Parent = ServerStorage
	local rng = Random.new(1)
	local count = 0
	local byName, parts = {}, {}
	local function newTemplate(copy, part)
		count += 1
		copy:PivotTo(CFrame.identity)
		copy.Name = tostring(count)
		if part then
			copy:SetAttribute("Part", true)
		end
		copy.Parent = templates
		return count
	end
	local function record(tuft)
		local blade = tuft:FindFirstChild("Blade")
		if blade and blade:IsA("BasePart") then
			local foot = footOf(tuft)
			local index
			if #parts < PART_TEMPLATES then
				local copy = bare(tuft)
				copy.WorldPivot = foot
				index = newTemplate(copy, true)
				table.insert(parts, index)
			else
				index = parts[rng:NextInteger(1, #parts)]
			end
			return index, foot.Position, rng:NextNumber(0, 2 * math.pi), blade.Size.X / BLADE_WIDTH
		end
		local index = byName[tuft.Name]
		if not index then
			local copy = bare(tuft)
			copy:ScaleTo(1)
			index = newTemplate(copy, false)
			byName[tuft.Name] = index
		end
		local pivot = tuft:GetPivot()
		local look = pivot.LookVector
		return index, pivot.Position, math.atan2(-look.X, -look.Z), scaleOf(tuft)
	end
	for _, name in ipairs(FOLDERS) do
		local folder = map and map:FindFirstChild(name)
		if folder then
			local bytes = {}
			for _, tuft in ipairs(folder:GetChildren()) do
				if tuft:IsA("Model") then
					local index, at, yaw, s = record(tuft)
					table.insert(bytes, string.pack("<BhhhBB", index, quantize(at.X, XZ_STEP, -32768, 32767),
						quantize(at.Y, Y_STEP, -32768, 32767), quantize(at.Z, XZ_STEP, -32768, 32767),
						quantize(yaw % (2 * math.pi), 2 * math.pi / 256, 0, 255), quantize(s, SCALE_STEP, 1, 255)))
				end
			end
			local text = encode(table.concat(bytes))
			local chunk = 0
			for i = 1, #text, CHUNK do
				chunk += 1
				local value = Instance.new("StringValue")
				value.Name = name .. "_" .. chunk
				value.Value = string.sub(text, i, i + CHUNK - 1)
				value.Parent = data
			end
			folder.Parent = stored
		end
	end
	data:SetAttribute("Ready", true)
	data.Parent = ReplicatedStorage
end

return Grass
