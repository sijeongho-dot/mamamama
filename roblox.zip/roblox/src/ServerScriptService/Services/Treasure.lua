--[[
Treasure: treasure chests on the battlefield, money straight into the opener's wallet.

- Every Config.Treasure.SpawnInterval seconds, while fewer than MaxOnField are out, a chest appears
  at a random spot of the battlefield (between the key zone and the flags, EdgeMargin inside both),
  with a gold light pillar rising from it while it waits. Unopened, it goes after Lifetime seconds.
- Opening: its ProximityPrompt must be held OpenSeconds (5). Meanwhile the chest's attribute Opening
  is true (the clients shake it and make it sparkle, StarterPlayerScripts/TreasureFx). The server
  times the hold itself (from PromptButtonHoldBegan) and checks the opener is alive, near and not
  stunned; a slap that throws them away breaks the hold.
- The first to finish gets Formulas.treasureMoney(their defense LV) (PlayerData.addMoney), about five
  minutes of mining; attributes Opened (their UserId) and Money tell the clients to lift the lid and
  pop the coins, and the chest goes VanishSeconds later.
- The night boss's chests (Treasure.spawnNow(at, kind), Config.Zombies.Boss.Kinds Chest) come in three
  kinds: "Money" (the usual), "Keys" (blue bands: Formulas.bossKeyChest(level) normal keys straight into
  the saved keys) and "Minerals" (green bands: Formulas.bossMineralChest minerals worth
  MineralChest.ValueShare money chests into the bag; what doesn't fit is paid as money). Attribute
  Label is what pops out of it on the clients.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))

local Treasure = {}

-- display only
local BODY_SIZE = Vector3.new(4.2, 2.4, 3)
local LID_HEIGHT = 1
local WOOD = Color3.fromRGB(150, 95, 45)
local GOLD = Color3.fromRGB(255, 200, 60)
local BAND = 0.35 -- the gold bands' width
local BEAM_HEIGHT, BEAM_WIDTH = 220, 2
local BEAM_COLOR = Color3.fromRGB(255, 215, 90)
local BEAM_TRANSPARENCY = 0.45
local TRIES = 20
local HOLD_SLACK = 0.3 -- seconds: a hold may end this much before OpenSeconds on the server's clock (lag)
local RANGE_SLACK = 4
local TRIGGER_GRACE = 1 -- seconds: a finished hold ends (PromptButtonHoldEnded) just before Triggered comes

-- the chest kinds' looks: band and light color, the prompt's icon
local KINDS = {
	Money = { band = GOLD, icon = "💰", name = "보물상자" },
	Keys = { band = Color3.fromRGB(110, 190, 255), icon = "🔑", name = "열쇠 상자" },
	Minerals = { band = Color3.fromRGB(110, 230, 140), icon = "💎", name = "광물 상자" },
}

local OFF_GROUND = { "Decor", "FieldDecor", "BattlefieldFlags" } -- Map folders a chest never goes on (trees, rocks)
local rng = Random.new()
local folder = nil
local chests = {} -- [model] = { born, holds = { [player] = os.clock() }, ended = { [player] = { start, at } }, taken }

local function groundAt(x, z)
	local params = RaycastParams.new()
	local ignore = { folder }
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	params.FilterDescendantsInstances = ignore
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true -- the invisible Battlefield cylinder and SafeZones are not ground
	local hit = Workspace:Raycast(Vector3.new(x, 300, z), Vector3.new(0, -600, 0), params)
	if not hit then
		return nil
	end
	-- not on (or under) a tree, a rock or a flag: only on open ground
	local map = Workspace:FindFirstChild("Map")
	for _, name in ipairs(OFF_GROUND) do
		local f = map and map:FindFirstChild(name)
		if f and hit.Instance:IsDescendantOf(f) then
			return nil
		end
	end
	return hit.Position
end

local function randomSpot()
	local t = Config.Treasure
	local inner = Config.Map.KeyZoneRadius + t.EdgeMargin
	local outer = Config.Battlefield.Radius - t.EdgeMargin
	for _ = 1, TRIES do
		local angle = rng:NextNumber(0, 2 * math.pi)
		local r = math.sqrt(rng:NextNumber(inner * inner / (outer * outer), 1)) * outer -- even over the area
		local ground = groundAt(math.cos(angle) * r, math.sin(angle) * r)
		if ground and not SafeZones.isSafe(ground + Vector3.new(0, 2, 0)) then
			return ground, angle
		end
	end
	return nil
end

local function part(model, name, size, cf, color, material)
	local p = Instance.new("Part")
	p.Name = name
	p.Anchored = true
	p.CanCollide = false
	p.CanTouch = false
	p.Size = size
	p.CFrame = cf
	p.Color = color
	p.Material = material or Enum.Material.Plastic
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Parent = model
	return p
end

-- a wooden chest with gold bands and lock, its lid a separate part (the clients lift it), and a
-- light pillar over it
local function makeChest(ground, facing, kind)
	local look = KINDS[kind] or KINDS.Money
	local GOLD = look.band -- (the bands, lock, light and pillar take the kind's color)
	local BEAM_COLOR = kind == "Money" and BEAM_COLOR or look.band
	local model = Instance.new("Model")
	model.Name = "TreasureChest"
	-- (2026-10-01, "a chest gave its reward but never shook, opened or rattled") streamed to the phones whole:
	-- the model arriving before its parts made the clients give up on it (TreasureFx)
	model.ModelStreamingMode = Enum.ModelStreamingMode.Atomic
	local base = CFrame.lookAt(ground, ground + facing)
	local bodyCf = base * CFrame.new(0, BODY_SIZE.Y / 2, 0)
	local body = part(model, "Body", BODY_SIZE, bodyCf, WOOD, Enum.Material.WoodPlanks)
	body.CanCollide = true
	for _, x in ipairs({ -BODY_SIZE.X / 2 + BAND, BODY_SIZE.X / 2 - BAND }) do
		part(model, "Band", Vector3.new(BAND, BODY_SIZE.Y + 0.05, BODY_SIZE.Z + 0.05), bodyCf * CFrame.new(x, 0, 0), GOLD,
			Enum.Material.Metal)
	end
	local lidCf = base * CFrame.new(0, BODY_SIZE.Y + LID_HEIGHT / 2, 0)
	local lid = part(model, "Lid", Vector3.new(BODY_SIZE.X + 0.1, LID_HEIGHT, BODY_SIZE.Z + 0.1), lidCf, WOOD,
		Enum.Material.WoodPlanks)
	for _, x in ipairs({ -BODY_SIZE.X / 2 + BAND, BODY_SIZE.X / 2 - BAND }) do
		local band = part(model, "LidBand", Vector3.new(BAND, LID_HEIGHT + 0.05, BODY_SIZE.Z + 0.15), lidCf * CFrame.new(x, 0, 0),
			GOLD, Enum.Material.Metal)
		band.Parent = lid -- lifts with the lid
	end
	part(model, "Lock", Vector3.new(0.7, 0.8, 0.25), base * CFrame.new(0, BODY_SIZE.Y, -BODY_SIZE.Z / 2 - 0.12), GOLD,
		Enum.Material.Metal)
	local glow = Instance.new("PointLight")
	glow.Color = GOLD
	glow.Range = 14
	glow.Brightness = 2
	glow.Parent = body
	-- the pillar of light, seen from far away while the chest waits
	local beam = part(model, "Beam", Vector3.new(BEAM_WIDTH, BEAM_HEIGHT, BEAM_WIDTH),
		CFrame.new(ground + Vector3.new(0, BEAM_HEIGHT / 2, 0)), BEAM_COLOR, Enum.Material.Neon)
	beam.CanQuery, beam.CastShadow = false, false
	beam.Transparency = BEAM_TRANSPARENCY
	local rising = Instance.new("ParticleEmitter")
	rising.EmissionDirection = Enum.NormalId.Top
	rising.Shape = Enum.ParticleEmitterShape.Box
	rising.Rate = 10
	rising.Lifetime = NumberRange.new(2, 3)
	rising.Speed = NumberRange.new(30, 45)
	rising.Size = NumberSequence.new(1, 0)
	rising.LightEmission = 1
	rising.Color = ColorSequence.new(GOLD, Color3.new(1, 1, 1))
	rising.Transparency = NumberSequence.new(0.1, 1)
	rising.Parent = beam
	-- where the clients shake it from and where the lid turns (its back top edge)
	model:SetAttribute("Rest", base)
	model:SetAttribute("Hinge", base * CFrame.new(0, BODY_SIZE.Y, BODY_SIZE.Z / 2))
	model.PrimaryPart = body
	model.WorldPivot = base -- the pivot stays the bottom middle (the clients shake it from Rest)
	model.Parent = folder
	return model, body
end

local function remove(model)
	chests[model] = nil
	if model.Parent then
		model:Destroy()
	end
end

local function refreshOpening(model)
	local info = chests[model]
	model:SetAttribute("Opening", info ~= nil and next(info.holds) ~= nil and not info.taken)
end

local function mine(info, player)
	return info.personal and info.openedBy[player.UserId] == true
end

local function allOpened(info)
	for _, p in ipairs(Players:GetPlayers()) do
		if not info.openedBy[p.UserId] then
			return false
		end
	end
	return true
end

local function open(model, player)
	local info = chests[model]
	local t = Config.Treasure
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	-- holding now, or a hold that ended a moment ago (Roblox ends a finished hold right before Triggered)
	local ended = info and info.ended[player]
	local started = info and (info.holds[player]
		or (ended and os.clock() - ended.at <= TRIGGER_GRACE and ended.start))
	if info and info.onlyFor and info.onlyFor ~= player.UserId then
		return
	end
	if not info or info.taken or mine(info, player) or not started or not root or not humanoid or humanoid.Health <= 0
		or MoveGuard.stunned(player) or SafeZones.inSky(player, root.Position) then -- (2026-10-04: on a flying dino, only looking)
		return
	end
	if os.clock() - started < t.OpenSeconds - HOLD_SLACK
		or (root.Position - model:GetPivot().Position).Magnitude > t.OpenRange + RANGE_SLACK then
		return
	end
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	if info.personal then
		info.openedBy[player.UserId] = true
	else
		info.taken = true
	end
	local kind = info.kind or "Money"
	local money = Formulas.treasureMoney(profile.DefenseLevel, rng:NextNumber())
	local label, notice
	if kind == "Keys" then
		local n = Formulas.bossKeyChest(profile.DefenseLevel)
		PlayerData.update(player, function(p)
			Formulas.addSavedKeys(p, "Normal", n)
		end)
		label, notice = string.format("+🔑%d", n), string.format("열쇠 상자에서 열쇠 %d개를 찾았어요! (바로 저장)", n)
	elseif kind == "Minerals" then
		local worth = money * Config.Zombies.Boss.MineralChest.ValueShare
		local gradeId, sizeId, count = Formulas.bossMineralChest(profile.Upgrades.PickaxeTier, worth, profile.DefenseLevel)
		local room = Formulas.bagCapacity(Formulas.trained(profile.Upgrades, profile.Training).Bag, profile.Passes.DoubleBag == true) -- (the 🎒 pass too)
			- Formulas.carryCount(profile.Carry)
		local fits = math.clamp(math.floor(room / Config.Minerals.BagSlotsPerMineral), 0, count)
		local key = Formulas.carryKey(gradeId, sizeId)
		if fits > 0 then
			PlayerData.update(player, function(p)
				p.Carry[key] = (p.Carry[key] or 0) + fits
			end)
		end
		local grade = Formulas.grade(gradeId)
		local gradeName = grade and grade.Name or gradeId
		label = string.format("+💎%d", fits)
		notice = string.format("광물 상자에서 %s %d개를 가방에 넣었어요!", gradeName, fits)
		if fits < count then -- the bag is full: the rest as money
			local rest = math.floor(Formulas.carryValue({ [key] = count - fits }, profile.DefenseLevel) + 0.5)
			PlayerData.addMoney(player, rest, "treasure")
			label = label .. string.format(" +%s원", Formulas.shortNumber(rest))
			notice ..= string.format(" 가방이 가득 차서 나머지는 %s원으로 받았어요", Formulas.shortNumber(rest))
		end
	else
		PlayerData.addMoney(player, money, "treasure")
		label, notice = nil, string.format("보물상자에서 %s원을 찾았어요!", Formulas.shortNumber(money))
	end
	Rewards.add(player, "Chests", 1) -- daily missions
	if info.personal then
		local look = KINDS[kind] or KINDS.Money
		Net.push(player, "ChestMine", model, money, label)
		Net.push(player, "Notice", look.icon .. " " .. look.name, notice)
		if allOpened(info) then
			info.taken = true
			refreshOpening(model)
			task.delay(t.VanishSeconds, remove, model)
		end
		return
	end
	local prompt = model:FindFirstChild("OpenPrompt", true)
	if prompt then
		prompt:Destroy()
	end
	local beam = model:FindFirstChild("Beam")
	if beam then
		beam:Destroy()
	end
	model:SetAttribute("Opening", false)
	model:SetAttribute("Money", money)
	model:SetAttribute("Label", label)
	model:SetAttribute("Opened", player.UserId)
	local look = KINDS[kind] or KINDS.Money
	Net.push(player, "Notice", look.icon .. " " .. look.name, notice)
	task.delay(t.VanishSeconds, remove, model)
end

local function spawnChest(at, kind, personal, onlyFor)
	local ground, angle = randomSpot()
	if at then -- Studio tests: right here
		ground, angle = groundAt(at.X, at.Z) or at, math.atan2(at.Z, at.X)
	end
	if not ground then
		return
	end
	local facing = Vector3.new(-math.cos(angle), 0, -math.sin(angle)) -- its front (lock) toward the middle
	kind = KINDS[kind] and kind or "Money"
	local model, body = makeChest(ground, facing, kind)
	local info = { born = os.clock(), holds = {}, ended = {}, taken = false, kind = kind, personal = personal == true,
		openedBy = {}, onlyFor = onlyFor and onlyFor.UserId or nil }
	chests[model] = info
	if info.personal then
		model:SetAttribute("Personal", true)
	end
	if info.onlyFor then
		model:SetAttribute("OnlyFor", info.onlyFor)
	end
	local t = Config.Treasure
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "OpenPrompt"
	prompt.ActionText = KINDS[kind].name .. " 열기"
	prompt.ObjectText = KINDS[kind].icon
	prompt.HoldDuration = t.OpenSeconds
	prompt.MaxActivationDistance = t.OpenRange
	prompt.RequiresLineOfSight = false
	prompt:SetAttribute("Kind", "Treasure")
	-- (2026-10-03, "보물상자 꾹 누르고있는데 계속 놔지네") on a still, invisible spot of its own: on the body it rocked
	-- with the chest's shaking (TreasureFx), and Roblox let go of the hold as it moved; TreasureFx keeps this one still
	local spot = Instance.new("Part")
	spot.Name = "PromptSpot"
	spot.Anchored, spot.CanCollide, spot.CanQuery, spot.CanTouch = true, false, false, false
	spot.Transparency = 1
	spot.Size = Vector3.one * 0.2
	spot.CFrame = CFrame.new(body.Position)
	spot.Parent = model
	prompt.Parent = spot
	prompt.PromptButtonHoldBegan:Connect(function(player)
		if not info.taken and not mine(info, player) and (not info.onlyFor or info.onlyFor == player.UserId) then
			info.holds[player] = os.clock()
			refreshOpening(model)
		end
	end)
	prompt.PromptButtonHoldEnded:Connect(function(player)
		local start = info.holds[player]
		if start then
			info.ended[player] = { start = start, at = os.clock() }
		end
		info.holds[player] = nil
		refreshOpening(model)
	end)
	prompt.Triggered:Connect(function(player)
		open(model, player)
		info.holds[player], info.ended[player] = nil, nil
		refreshOpening(model)
	end)
	return model
end

function Treasure.init()
	folder = Workspace:FindFirstChild("TreasureChests") or Instance.new("Folder")
	folder.Name = "TreasureChests"
	folder:ClearAllChildren()
	folder.Parent = Workspace
	Players.PlayerRemoving:Connect(function(player)
		for model, info in pairs(chests) do
			info.holds[player], info.ended[player] = nil, nil
			refreshOpening(model)
		end
	end)
	task.spawn(function()
		while true do
			task.wait(Config.Treasure.SpawnInterval)
			local now, count = os.clock(), 0
			for model, info in pairs(chests) do
				local lifetime = info.personal and Config.Zombies.Boss.ChestSeconds or Config.Treasure.Lifetime
				if info.onlyFor then
					if not Players:GetPlayerByUserId(info.onlyFor) then
						remove(model)
					end
				elseif not info.taken and now - info.born > lifetime and next(info.holds) == nil then
					remove(model)
				elseif not info.taken and not info.personal then
					count += 1
				end
			end
			if count < Config.Treasure.MaxOnField then
				spawnChest(nil)
			end
		end
	end)
end

-- a chest right now at `at` (the boss's pile; Studio tests), of this kind ("Money", "Keys", "Minerals")
Treasure.spawnNow = spawnChest

function Treasure.spawnFor(player, at)
	return spawnChest(at, "Money", false, player)
end

function Treasure.removeChest(model)
	remove(model)
end

return Treasure
