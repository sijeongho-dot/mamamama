--[[
Race: two players race their dinos one lap round the paved track (design 2.11.1 공룡 레이스). Just for fun:
the winner gets nothing but the announcement.

- Challenge: walk up to another player (Config.Race.ChallengeRange) and use the "🏁 레이스 신청" prompt
  (StarterPlayerScripts/Race): Net request RaceChallenge(userId). Both must be riding a walking dino
  (not a flying one) when it is sent and when it is accepted; otherwise a notice says so. That player gets Net push RaceInvite
  and answers with RaceAnswer(userId, accept) within Config.Race.InviteSeconds.
- Accepted: both are put in the two start boxes behind the finish line (MoveGuard.allow first). Player
  attribute Racing = "Gather": each is ready (attribute RaceReady) while riding a dino that walks (flying
  ones can't race). Both ready within Config.Race.GatherSeconds: back into the boxes, "Countdown" for
  Config.Race.CountdownSeconds (MoveGuard holds them still), then "Go". RaceUntil (server time) is when
  the countdown or the race ends, RaceOpponent the other racer's userId.
- Racing: both ride at Config.Race.Speed whatever their upgrades (MoveGuard). Progress is the compass
  angle gone round the map center, counted only while riding a walking dino on the track (within
  Config.Race.OffTrack of the road): going back takes it off again, cutting across or teleporting away
  gains nothing. Attribute RaceProgress (0..1). A full lap from the start box back over the finish line
  (360 + StartBack degrees) wins; after Config.Race.TimeLimit whoever is further ahead wins.
- Race pads and obstacles (Formulas.raceLayout, new every race): Net push RacePads / RaceObstacles to
  the two racers only; their screens draw them. Pads: purple ones in short runs, a few strong yellow
  ones. The server sees a racer pass over one (the path since the last check, so fast riders don't skip
  it) and boosts them (MoveGuard.boost PadMultiplier / YellowMultiplier for PadBoostSeconds /
  YellowBoostSeconds), once per pad and racer; Net push RacePadHit(index). Obstacles (crates, pillars,
  walls from an edge) are solid only on the racers' screens; the server puts a racer it finds inside
  one (below its top) back where they were. They go with the race: everyone walks freely after.
  The moving ones (a swinging hammer, a spinning bar) hit for real (2026-10-01): the server works out
  where they are at server time (Formulas.raceMoverHit, the racers' screens move them the same way) and
  a racer touched bounces off, still riding: flown back Config.Race.HitPushBack studs along the road in an arc over
  HitBounceSeconds by their own screen (no stun: a stun takes them off the dino) (Net push RaceHit, with the "쾅!"). Jump sections: hurdles a jump apart,
  on mud where a pad's boost ends (MoveGuard.clearBoost), so each hurdle takes its own jump.
- Results are saved (2026-10-04: a 🏆 랭킹전 race only, below): profile Race { Wins, Losses, SkyWins, SkyLosses, BestRoad, BestSky (2026-10-02: the winner's time
  over the line; all-server bests in Leaderboards) } (a win or loss whenever the race
  has a winner, a forfeit too; the road race and the sky race each their own, 2026-10-01); player
  attributes RaceWins / RaceLosses / SkyWins / SkyLosses, shown over their heads (StarterPlayerScripts/Race).
- From the countdown on, a see-through barrier along both road edges (drawn by the racers' screens)
  keeps them on the road; the server puts a racer found Config.Race.BarrierSlack past an edge back
  on it (MoveGuard.allow first).
- Getting off the dino (or onto a flying one) from the countdown on loses the race (기권패), so does
  giving up (Net request RaceQuit) or leaving the game: the other one wins.
- The sky race (2026-10-01, Config.Race.Sky): a challenge sent while riding a flying dino is one (player
  attribute RaceKind "Sky", else "Road"); both must ride flying dinos (when sent, accepted, and all
  along). Accepted: both are put side by side in the air at the course's start (Formulas.skyCourse,
  over the land outside the base fences), facing the first ring. From the countdown, Net push
  SkyRings(positions, ringRadius) to the two racers only; each sees only their own next ring (player
  attribute SkyRing = its number): passing through it (the path since the last check within RingRadius
  + PassSlack of its middle, checked here) shows the next; the last, red one is back at the start and
  wins. RaceProgress = rings passed ÷ all. After Sky.TimeLimit, more rings passed (then nearer the next
  one) wins. Boost pads (2026-10-01): the road's pads standing up, at random on the way between the
  rings (Formulas.skyPads, Net push SkyPads to the two racers only); flying through one (the path since
  the last check within Sky.PadRadius + PadSlack of its middle) boosts like a road pad (purple or
  yellow), once per pad and racer; Net push RacePadHit(index).
- Practice (2026-10-02, "탈 공룡 칸에서 레이싱 연습 가능하게. 하늘 레이싱과 지상 레이싱, 탈 공룡 선택 후. 기록은 안
  남지만 방식은 대전과 같음"): Net request RacePractice(kind) from the mount window (StarterPlayerScripts/Ride).
  The registered mount must fit the kind (a walking one for "Road", a flying one for "Sky"); the player is put
  on it (Ride.getOn) and races alone, by the same rules: the start, the countdown, the pads and obstacles or
  rings, the barrier, getting off ends it. Player attribute RacePractice; no opponent, no record, no
  announcement to the server. The result screen says 완주 with the time, or 연습 끝.
- Races at the same time (2026-10-02, "레이스 중복 참가가 어떻게 보이지? 충돌 있을 거 같은데"): a road race
  takes a row of start boxes no race waiting at the start uses (Config.Race.StartSlots rows, StartSlotGap
  degrees further back each; a practice takes one box), and its lap is counted from that row. Each race's
  racers are in their own collision group (Race1, Race2, ...): they bump into each other and everything
  else, but go through the riders of another race.
- Nobody holds a race open (2026-10-02, "고의로 레이스 안 끝내는 사람 있으면 안 되잖아"): a racer getting no
  further for Config.Race.StallSeconds (road: no new ground on the lap; sky: no ring passed and no nearer the
  next one) loses, or ends their practice; a warning StallWarnSeconds in. Others never see a race's
  obstacles (only its racers do).
- Rooms (2026-10-04, "레이스도 방 열수 있게 하자 술래잡기처럼 … 얘도 방 열면 알림 가게"; RaceRoomLogic): opened, joined and
  readied from anywhere in the 🎮 놀이방 window's 🏁 tab (StarterPlayerScripts/GameRooms; Net requests
  RaceRoomCreate(kind, ranked), RaceRoomJoin(id), RaceRoomLeave, RaceRoomReady(ready); Net push RaceRooms, Net ask
  GetRaceRooms): a 🏁 road or 🦅 sky room, 🏆 랭킹전 or 🎈 일반전. Config.Race.Rooms.MinPlayers or more, all ready (ready
  needs a registered mount of the room's kind): StartSeconds later every member who still can (not racing, not in
  the tutorial or a hide-and-seek room, not carrying keys, that mount) is taken off a dino of the other kind, put at
  the start and on their own mount, and they race together; the room waits again after. A new room is told to the
  others here (once every RoomNoticeGap seconds a player). Player attribute InRoom = "Race" while in a room
  (HideSeek's rooms set "Hide": one room at a time). A challenge to a player nearby still works ("개인적으로 즐길려면
  그냥 다른 유저 가까히 가서 즐겨도 되는거고").
- Two or more racers (2026-10-04): the first over the line (or the furthest at the time limit) wins, the rest lose,
  each with their place (player attributes RacePlace while racing, RaceField = how many started). One getting off,
  standing still, giving up or leaving is out (their loss) and the rest race on: the last one left wins. Leaving
  before the start (🏳️, gone) is no loss; fewer than two left calls it off.
- 🏆 랭킹전 / 🎈 일반전 (2026-10-04, "일반전은 기록이 안남고 랭킹전은 기록이 남는", "랭킹전 보상도 주간 열쇠로"): only a ranked
  race saves the wins and losses, the best time and the all-server best times, and counts the winner's win in this
  week's race ranking (RewardLogic.rankedWin, Leaderboards: the rank's keys when the week is over). A challenge to a
  player nearby is 🎈 일반전 ("개인적으로 즐길려면"), a practice keeps nothing as before.
- No keys (2026-10-04): carrying keys, nobody challenges, answers, practises or races from a room (each start is a
  trip to the track, away from the key altar).
]]

local Players = game:GetService("Players")
local PhysicsService = game:GetService("PhysicsService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local ServerMeter = require(script.Parent:WaitForChild("ServerMeter")) -- (2026-10-04: its loop timed, Watchdog)
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))
local Ride = require(script.Parent:WaitForChild("Ride"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local Leaderboards = require(script.Parent:WaitForChild("Leaderboards"))
local RewardLogic = require(script.Parent:WaitForChild("RewardLogic"))
local RoomLogic = require(script.Parent:WaitForChild("RaceRoomLogic"))

local Race = {}

local TICK = 0.1 -- seconds between progress checks
local RANGE_SLACK = 4 -- the server allows a little more than the prompt's range (lag)
local PAD_SLACK = 1.5 -- studs past a pad's edge that still count (the rider's root is above the mount's middle)
local ROAD_TOP = 0.65 -- the road's top (roblox/MapBuilder.lua TOP.road)
local STAND_LIFT = 3.2 -- a walking character's root above the ground, when not riding
local PROGRESS_STEP = 0.005 -- RaceProgress changes are sent in steps this big
local BOUNCE_GRACE = 0.5 -- seconds past a hit's bounce the faster move stays fine (MoveGuard.loosen)
local BOUNCE_SPEED_SLACK = 1.5 -- × the bounce's speed it may go meanwhile
local OBSTACLE_SHRINK = 0.6 -- studs inside an obstacle's sides before the server counts a racer as in it (lag)
local AIRBORNE_SPEED = 4 -- studs a second up or down: in the air (jumping a hurdle), not standing on it
local SKY_LOOK_FROM = 400 -- studs up to look down for the ground under a sky ring

local inRace = {} -- [player] = race
local invites = {} -- [target player] = { [challenger] = expires (os.clock) }
local lastChallenge = {} -- [player] = os.clock() (a challenge or a practice)
local STALL_DEGREES = 0.5 -- the lap must grow by this much to count as getting further (road)
local STALL_STUDS = 5 -- or this much nearer the next ring than ever (sky)
local MAX_GROUPS = 8 -- collision groups Race1..Race8: one per race at a time (8 players: at most 8 practices)
local rooms = RoomLogic.new() -- (2026-10-04) the race rooms
local lastRoomNotice = {} -- [player] = os.clock() of their last room-opened notice to everyone
local lastRecruit = {} -- [player] = os.clock() of their last 📣 모집 (2026-10-04)
local KEYS_WHY = "🔑 열쇠를 들고는 레이스를 못 해요. 기지에 먼저 넣어요"
local RANKED_LINE = "🏆 랭킹전! 이기면 기록이 남고 이번 주 순위에 들어가요"
local NORMAL_LINE = "🎈 일반전이라 기록은 남지 않아요"
local RACE_ATTRIBUTES = { "Racing", "RaceReady", "RaceProgress", "RaceOpponent", "RaceUntil", "RaceKind", "SkyRing",
	"RacePractice", "RacePlace", "RaceField" }

local function say(player, text)
	Net.push(player, "Notice", "🏁 레이스", text)
end

local function alive(player)
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if humanoid and root and humanoid.Health > 0 then
		return character, root
	end
	return nil
end

local function onWalkingDino(player)
	return player:GetAttribute("Riding") == true and not player:GetAttribute("Flying")
end

local function onFlyingDino(player)
	return player:GetAttribute("Riding") == true and player:GetAttribute("Flying") == true
end

-- the dino this race is raced on: a walking one on the road, a flying one in the sky race
local function onRaceDino(race, player)
	if race.kind == "Sky" then
		return onFlyingDino(player)
	end
	return onWalkingDino(player)
end

local KIND_NAMES = { Road = "🏁 길 레이스", Sky = "🦅 하늘 레이스" }

local function offWhy(race, p)
	return race.practice and "🚶 공룡에서 내려 연습이 끝났어요" or p.DisplayName .. "님이 공룡에서 내려 기권패"
end

-- the ground's height under (x, z), players left out
local function groundY(x, z)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.RespectCanCollide = true
	local ignore = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	params.FilterDescendantsInstances = ignore
	local hit = Workspace:Raycast(Vector3.new(x, SKY_LOOK_FROM, z), Vector3.new(0, -SKY_LOOK_FROM * 2, 0), params)
	return hit and hit.Position.Y or 0
end

-- a new sky course in the world: race.skyStart, race.course (positions, the last the red one) and
-- race.skyPads (the upright boost pads on the way: { at, kind, facing }; Formulas.skyPads)
local function makeSkyCourse(race, center)
	local seed = math.random(1, 2147483646)
	local rand = function()
		seed = (seed * 48271) % 2147483647
		return seed / 2147483647
	end
	local course = center and Formulas.skyLoop(rand, center.X, center.Z) or Formulas.skyCourse(rand)
	local ceiling = Config.Ride.FlyMaxHeight - Config.Race.Sky.CeilingMargin -- (flyers go no higher)
	local function world(p)
		return Vector3.new(p[1], math.min(groundY(p[1], p[2]) + p[3], ceiling), p[2])
	end
	race.skyStart = world(course.Start)
	race.course = {}
	local points = { { race.skyStart.X, race.skyStart.Y, race.skyStart.Z } }
	for _, r in ipairs(course.Rings) do
		local at = world(r)
		table.insert(race.course, at)
		table.insert(points, { at.X, at.Y, at.Z })
	end
	local length, from = 0, race.skyStart
	for _, at in ipairs(race.course) do
		length += (at - from).Magnitude
		from = at
	end
	race.ideal = length / Config.Race.Speed
	race.skyPads = {}
	for _, pad in ipairs(Formulas.skyPads(rand, points)) do
		local y = math.max(pad[2], groundY(pad[1], pad[3]) + Config.Race.Sky.PadMinHeight)
		table.insert(race.skyPads, { Vector3.new(pad[1], y, pad[3]), pad[4], Vector3.new(pad[5], pad[6], pad[7]) })
	end
end

-- the sky racers side by side at the start, in the air, facing the first ring (2026-10-04: two or more, StartSide
-- either side of the middle for two, as far apart again for each more)
local function toSkyStart(race, player, i)
	local character = alive(player)
	if not character or not race.skyStart then
		return
	end
	local ahead = race.course[1] - race.skyStart
	ahead = Vector3.new(ahead.X, 0, ahead.Z)
	ahead = ahead.Magnitude > 0.1 and ahead.Unit or Vector3.zAxis
	local side = ahead:Cross(Vector3.yAxis)
	local at = race.skyStart + side * ((i - (#race.players + 1) / 2) * 2 * Config.Race.Sky.StartSide)
	MoveGuard.allow(player)
	character:PivotTo(CFrame.lookAt(at, at + ahead))
	local root = character:FindFirstChild("HumanoidRootPart")
	if root then
		root.AssemblyLinearVelocity = Vector3.zero
	end
end

-- distance from point p to the segment a-b (in 3D)
local function toSegment3(p, a, b)
	local ab = b - a
	local len2 = ab:Dot(ab)
	local t = len2 > 0 and math.clamp((p - a):Dot(ab) / len2, 0, 1) or 0
	return (a + ab * t - p).Magnitude
end

local function flat(v)
	return Vector3.new(v.X, 0, v.Z)
end

-- the degrees behind the finish line of start row `slot` (1 = the front one)
local function slotBack(slot)
	local c = Config.Race
	return c.StartBack + ((slot or 1) - 1) * c.StartSlotGap
end

-- start box i (1 or 2) of row `slot`, facing the racing direction
local function startBox(i, slot)
	local c = Config.Race
	local a = math.rad(c.FinishAngle - slotBack(slot))
	local out = Vector3.new(math.sin(a), 0, -math.cos(a))
	local ahead = Vector3.new(math.cos(a), 0, math.sin(a)) -- the compass angle going up
	local at = out * (c.Radius + (i == 1 and -1 or 1) * c.StartSide)
	return at, ahead
end

local function toStartBox(player, i, slot)
	local character = alive(player)
	if not character then
		return
	end
	local at, ahead = startBox(i, slot)
	local lift = player:GetAttribute("Riding") and (player:GetAttribute("RideDrop") or STAND_LIFT) or STAND_LIFT
	at += Vector3.new(0, ROAD_TOP + lift + 0.3, 0)
	MoveGuard.allow(player)
	character:PivotTo(CFrame.lookAt(at, at + ahead))
end

-- The record over their head: the road race's and the sky race's, each its own (2026-10-01)
local function mirrorRecord(player)
	local profile = PlayerData.get(player)
	if not profile then
		return
	end
	local record = profile.Race
	player:SetAttribute("RaceWins", record.Wins or 0)
	player:SetAttribute("RaceLosses", record.Losses or 0)
	player:SetAttribute("SkyWins", record.SkyWins or 0)
	player:SetAttribute("SkyLosses", record.SkyLosses or 0)
	player:SetAttribute("RaceTrialRoad", (record.TrialRoad or 0) > 0 and record.TrialRoad or nil)
	for _, kind in ipairs({ "Road", "Sky" }) do
		player:SetAttribute("RaceMedal" .. kind, record.Medals and record.Medals[kind] or 0)
	end
	player:SetAttribute("RaceBestRoad", (record.BestRoad or 0) > 0 and record.BestRoad or nil)
	player:SetAttribute("RaceBestSky", (record.BestSky or 0) > 0 and record.BestSky or nil)
end

-- (2026-10-02) the racers' collision group: their own race's (they bump each other), or back to Default
local function setGroup(player, group)
	local character = player.Character
	if not character then
		return
	end
	for _, part in ipairs(character:GetDescendants()) do
		if part:IsA("BasePart") then
			part.CollisionGroup = group
		end
	end
end

-- the other one of a two-racer race (else nil)
local function other(race, player)
	if #race.players ~= 2 then
		return nil
	end
	return race.players[1] == player and race.players[2] or race.players[1]
end

local function setAll(race, name, value)
	for _, p in ipairs(race.players) do
		if p.Parent then
			p:SetAttribute(name, value)
		end
	end
end

local function setState(race, state, seconds)
	race.state = state
	race.untilTime = os.clock() + seconds
	setAll(race, "RaceUntil", Workspace:GetServerTimeNow() + seconds)
	setAll(race, "Racing", state)
end

-- (2026-10-04: two or more racers) how far a racer got: the share of the way (0..1) and, in the sky race, how far
-- they are from their next ring (nearer is further on)
local function ringsOf(race)
	return race.course and #race.course or 1
end

local function howFar(race, p)
	if race.kind == "Sky" then
		local i = race.ring[p] or 1
		local _, root = alive(p)
		local target = race.course and race.course[i]
		local d = (root and target) and (root.Position - target).Magnitude or math.huge
		return math.min(1, (i - 1) / math.max(ringsOf(race), 1)), d
	end
	if race.short then
		return math.clamp((race.progress[p] or 0) / Config.Race.TutorialDegrees, 0, 1), 0
	end
	return Formulas.raceProgress(race.progress[p] or 0, race.back and race.back[p]), 0
end

-- the racers still in, the furthest first (the winner first when there is one), and how far each got
local function standings(race, winner)
	local list = table.clone(race.players)
	local far = {}
	for _, p in ipairs(list) do
		far[p] = { howFar(race, p) }
	end
	table.sort(list, function(a, b)
		if a == b then
			return false
		elseif a == winner or b == winner then
			return a == winner
		end
		local fa, fb = far[a], far[b]
		if fa[1] ~= fb[1] then
			return fa[1] > fb[1]
		end
		return fa[2] < fb[2]
	end)
	return list, far
end

-- a racer done with the race (it ended, or they are out): their race attributes, collision group and speed back
local function release(race, p)
	inRace[p] = nil
	if race.group then
		setGroup(p, "Default")
	end
	if p.Parent then
		for _, name in ipairs(RACE_ATTRIBUTES) do
			p:SetAttribute(name, nil)
		end
		MoveGuard.refresh(p)
	end
end

-- (2026-10-04) a ranked race's result in the profile: a win (counted in this week's race ranking when it was against a
-- rival who hasn't given too many this week, RewardLogic.rankedWin) or a loss; an 🎈 일반전 keeps nothing
local function recordResult(race, p, won, rivals)
	if not race.ranked or not PlayerData.get(p) then
		return
	end
	local field = (race.kind == "Road" and "" or race.kind) .. (won and "Wins" or "Losses")
	local counted = false
	local ids = {}
	for _, q in ipairs(rivals or {}) do
		table.insert(ids, q.UserId)
	end
	PlayerData.update(p, function(profile)
		profile.Race[field] = (profile.Race[field] or 0) + 1
		if won then
			counted = RewardLogic.rankedWin(profile, RewardLogic.weekNumber(os.time()), "Race", ids)
		end
	end)
	mirrorRecord(p)
	race.counted[p] = won and counted or nil
	if counted then
		Leaderboards.rankedWin(p, "Race")
	end
end

-- (2026-10-01, "show a result screen when the race ends") a racer's result, once the race had started:
-- Net push RaceResult { Outcome = "Win" | "Lose" | "Draw" | "Finish" | "Practice", Why, Opponent (the other racer, or
-- the best of the others), Seconds, Mine, Theirs (0..1 of the way), Pads (used), Hits (moving obstacles), Kind, Rings,
-- AllRings, Wins, Losses (this kind of race's record), Place, Racers (2026-10-04: how many started), Ranked, Counted
-- (the win counted in this week's ranking), WeekWins (this week's counted race wins) }
local function medalRun(race, p, seconds)
	local kind = race.kind
	local profile = PlayerData.get(p)
	if not profile or not Config.Race.Medals[kind] then
		return nil
	end
	local judged = seconds * (race.weatherMax or 1)
	local got = Formulas.raceMedal(kind, judged, race.ideal)
	local had = profile.Race.Medals[kind] or 0
	local field = kind == "Road" and "TrialRoad" or nil
	local old = field and profile.Race[field] or 0
	local newBest = field ~= nil and (old <= 0 or judged < old)
	PlayerData.update(p, function(pr)
		if got > (pr.Race.Medals[kind] or 0) then
			pr.Race.Medals[kind] = got
		end
		if newBest then
			pr.Race[field] = judged
		end
	end)
	if got > had then
		Rewards.add(p, "RaceMedal", got - had)
	end
	for i = had + 1, got do
		local m = Config.Race.Medals[kind][i]
		Rewards.grant(p, m.Reward, string.format("%s %s %s 메달!", m.Icon, KIND_NAMES[kind], m.Icon))
	end
	if got > had and got >= #Config.Race.Medals[kind] then
		Net.pushAll("Notice", "⏱️ 기록", string.format("%s %s님이 %s 최고 메달! %.1f초", Config.Race.Medals[kind][got].Icon,
			p.DisplayName, KIND_NAMES[kind], judged))
	end
	mirrorRecord(p)
	return { Got = got, New = got > had and got or nil, Best = newBest and judged or (old > 0 and old or nil), Judged = judged }
end

local function sendResult(race, p, outcome, why, place, best, medal)
	if not race.goAt or not p.Parent then
		return -- (called off before the start: the notice is enough)
	end
	local pads = 0
	for _ in pairs(race.used[p] or {}) do
		pads += 1
	end
	local profile = PlayerData.get(p)
	local record = profile and profile.Race or {}
	local sky = race.kind == "Sky"
	if outcome ~= "Practice" then -- (2026-10-03: a race run to the end, the beginner mission "🏁 레이스 한 판")
		Rewards.add(p, "RaceDone", 1)
	else
		Rewards.add(p, "RacePractice", 1) -- (2026-10-04: the launch event's race mission counts one alone too)
	end
	if outcome == "Finish" and race.practice then
		Unlocks.event(p, sky and "RacePracticeSky" or "RacePractice", 1)
	end
	if not race.practice and #race.starters >= 2 and (outcome == "Win" or (outcome == "Lose" and not race.quit[p])) then
		Rewards.miniGame(p, outcome == "Win")
	end
	Net.push(p, "RaceResult", {
		Outcome = outcome,
		Practice = race.practice or nil,
		Why = why or "",
		Opponent = best and best.DisplayName or "?",
		Seconds = os.clock() - race.goAt,
		Mine = race.final[p] or howFar(race, p),
		Theirs = best and (race.final[best] or howFar(race, best)) or 0,
		Pads = pads,
		Hits = race.hits and race.hits[p] or 0,
		Kind = race.kind,
		Rings = sky and ((race.ring and race.ring[p] or 1) - 1) or nil,
		AllRings = sky and ringsOf(race) or nil,
		Wins = (sky and record.SkyWins or not sky and record.Wins) or 0,
		Losses = (sky and record.SkyLosses or not sky and record.Losses) or 0,
		Place = place,
		Racers = #race.starters,
		Ranked = race.ranked or nil,
		Medal = medal and medal.Got or nil,
		NewMedal = medal and medal.New or nil,
		Best = medal and medal.Best or nil,
		Judged = medal and medal.Judged or nil,
		Ideal = race.ideal,
		Counted = race.counted[p],
		WeekWins = race.ranked and profile and profile.Ranked.Race or nil,
	})
end

local roomRaceOver -- (below: the room waits again)

local function crown(race, winner, why)
	-- (2026-10-02) the winner's time when they crossed the line (not a win by the others giving up): their best,
	-- and the all-server best times (Leaderboards); a ranked race only (2026-10-04)
	if race.ranked and not why and race.goAt and PlayerData.get(winner) then
		local seconds = os.clock() - race.goAt
		local field = race.kind == "Sky" and "BestSky" or "BestRoad"
		local best = PlayerData.get(winner).Race[field] or 0
		if best <= 0 or seconds < best then
			PlayerData.update(winner, function(profile)
				profile.Race[field] = seconds
			end)
			Leaderboards.raceTime(winner, race.kind == "Sky" and "Sky" or "Road", seconds)
			say(winner, string.format("🏆 새 개인 기록! %.1f초", seconds))
		end
	end
	local beaten = {} -- everyone who started but the winner (those out already lost)
	for _, p in ipairs(race.starters) do
		if p ~= winner then
			table.insert(beaten, p)
		end
	end
	recordResult(race, winner, true, beaten)
	local suffix = why and (" (" .. why .. ")") or ""
	if #race.starters == 2 then
		Net.pushAll("Notice", "🏁 레이스", string.format(race.ranked and "🏆 %s님이 %s님과의 랭킹전 레이스에서 이겼어요!%s"
			or "🏆 %s님이 %s님과의 공룡 레이스에서 이겼어요!%s", winner.DisplayName, beaten[1] and beaten[1].DisplayName or "?",
			suffix))
	else
		Net.pushAll("Notice", "🏁 레이스", string.format(race.ranked and "🏆 %s님이 랭킹전 레이스 %d명 중 1등!%s"
			or "🏆 %s님이 공룡 레이스 %d명 중 1등!%s", winner.DisplayName, #race.starters, suffix))
	end
	return beaten
end

local function finish(race, winner, why, crosser)
	if race.over then
		return
	end
	race.over = true
	local order = standings(race, winner) -- (the places of those still in)
	local before = #race.finishers
	for _, p in ipairs(race.players) do
		release(race, p)
	end
	if race.room then
		roomRaceOver(race.room)
	end
	if race.staked then
		if winner then
			for i, p in ipairs(order) do
				race.placeOf[p] = before + i
			end
			local list = {}
			for p in pairs(race.staked) do
				table.insert(list, p)
			end
			table.sort(list, function(a, b)
				return (race.placeOf[a] or math.huge) < (race.placeOf[b] or math.huge)
			end)
			local groups = {}
			for _, p in ipairs(list) do
				table.insert(groups, { p })
			end
			Rewards.payStakes(groups, race.stake)
		else
			for p in pairs(race.staked) do
				Rewards.refundStake(p, race.stake)
			end
		end
		race.staked = nil
	end
	if not winner then
		local text = why or "레이스가 끝났어요"
		for i, p in ipairs(order) do
			if p.Parent then
				say(p, text)
			end
			sendResult(race, p, race.practice and "Practice" or "Draw", why, i, order[i == 1 and 2 or 1])
		end
		return
	end
	local medal = crosser and race.goAt and medalRun(race, crosser, os.clock() - race.goAt) or nil
	if race.practice then
		say(winner, string.format("⏱️ 완주! %.1f초", os.clock() - (race.goAt or os.clock())))
		sendResult(race, winner, "Finish", why, 1, nil, medal)
		return
	end
	local beaten = table.find(order, winner) and crown(race, winner, why) or {}
	for _, p in ipairs(order) do
		if p ~= winner then
			recordResult(race, p, false)
		end
	end
	for i, p in ipairs(order) do
		sendResult(race, p, p == winner and "Win" or "Lose", why, before + i,
			p == winner and (order[2] or beaten[1]) or winner, p == crosser and medal or nil)
	end
end

local function crossLine(race, p)
	local i = table.find(race.players, p)
	if race.over or not i then
		return
	elseif race.practice or #race.players <= 2 then
		finish(race, race.winner or p, nil, p)
		return
	end
	table.insert(race.finishers, p)
	local place = #race.finishers
	race.placeOf[p] = place
	race.final[p] = howFar(race, p)
	table.remove(race.players, i)
	release(race, p)
	local medal = race.goAt and medalRun(race, p, os.clock() - race.goAt) or nil
	if not race.winner then
		race.winner = p
		crown(race, p)
	else
		recordResult(race, p, false)
	end
	sendResult(race, p, p == race.winner and "Win" or "Lose", nil, place, p == race.winner and race.players[1] or race.winner,
		medal)
	for _, q in ipairs(race.players) do
		say(q, string.format("🏁 %s님이 %d등으로 들어왔어요! 끝까지 달려요", p.DisplayName, place))
	end
end

-- (2026-10-04: two or more racers) a racer out before the end (off the dino, standing still, 🏳️ 포기, gone): their
-- loss (in a ranked race) and their result now; the others race on, and the last one left wins
local function dropOut(race, p, why)
	local i = table.find(race.players, p)
	if race.over or not i then
		return
	elseif race.practice then
		finish(race, nil, why)
		return
	end
	local place = #race.finishers + #race.players
	race.placeOf[p] = place
	race.final[p] = howFar(race, p)
	race.quit[p] = true
	table.remove(race.players, i)
	release(race, p)
	recordResult(race, p, false)
	sendResult(race, p, "Lose", why, place, race.winner or race.players[1])
	if #race.players == 1 then
		finish(race, race.winner or race.players[1], why)
	elseif #race.players == 0 then
		finish(race, race.winner, why)
	else
		for _, q in ipairs(race.players) do
			say(q, why)
		end
	end
end

-- before the start (getting on, the countdown): out with no record; with two or fewer left (or alone) it is called
-- off with cancelWhy, else the rest are told outWhy
local function leaveEarly(race, p, cancelWhy, outWhy)
	local i = table.find(race.players, p)
	if race.over or not i then
		return
	elseif race.practice or #race.players <= 2 then
		finish(race, nil, cancelWhy)
		return
	end
	table.remove(race.players, i)
	table.remove(race.starters, table.find(race.starters, p) or #race.starters + 1)
	release(race, p)
	if p.Parent then
		say(p, outWhy)
	end
	for _, q in ipairs(race.players) do
		say(q, outWhy)
		q:SetAttribute("RaceField", #race.starters)
	end
end

local function freeGroup()
	local used = {}
	for _, race in pairs(inRace) do
		if race.group then
			used[race.group] = true
		end
	end
	for i = 1, MAX_GROUPS do
		if not used["Race" .. i] then
			return "Race" .. i
		end
	end
	return nil -- (more races than groups: they bump like before)
end

-- start boxes for n racers that no road race waiting at the start uses: { { side, slot }, ... } (one: any free box;
-- two: a row of their own; more: free boxes from the front, 2026-10-04); all taken: from the front row, as before
local function freeBoxes(n)
	local taken = {}
	for _, race in pairs(inRace) do
		if race.kind ~= "Sky" and not race.over and (race.state == "Gather" or race.state == "Countdown") then
			for _, box in pairs(race.box or {}) do
				taken[box[2] .. ":" .. box[1]] = true
			end
		end
	end
	local all = {}
	for slot = 1, Config.Race.StartSlots do
		local free = {}
		for side = 1, 2 do
			if not taken[slot .. ":" .. side] then
				table.insert(free, { side, slot })
				table.insert(all, { side, slot })
			end
		end
		if n <= 2 and #free >= n then
			return { table.unpack(free, 1, n) }
		end
	end
	if n > 2 and #all >= n then
		return { table.unpack(all, 1, n) }
	end
	local boxes = {}
	for k = 1, n do
		boxes[k] = { (k - 1) % 2 + 1, math.min((k - 1) // 2 + 1, Config.Race.StartSlots) }
	end
	return boxes
end

-- (2026-10-04) players: the racers (one: a practice alone, 2026-10-02); opts: { practice = true, ranked = true (🏆 랭킹전:
-- its records are kept), room = the race room it is for }
local function startRace(players, kind, opts)
	opts = opts or {}
	for _, p in ipairs(players) do
		invites[p] = nil
		for _, list in pairs(invites) do -- their other challenges are off
			list[p] = nil
		end
	end
	local race = { players = table.clone(players), starters = table.clone(players), progress = {}, lastAngle = {},
		lastPos = {}, used = {}, warned = {}, kind = kind or "Road", ring = {}, lastWorld = {}, practice = opts.practice == true,
		box = {}, back = {}, final = {}, counted = {}, ranked = opts.ranked == true and not opts.practice, room = opts.room,
		staked = opts.staked, stake = opts.stake, placeOf = {}, finishers = {}, short = opts.short == true,
		center = opts.center, quit = {} }
	if race.kind ~= "Sky" then -- (picked before this race counts as waiting at the start)
		for i, box in ipairs(freeBoxes(#players)) do
			race.box[players[i]] = box
			race.back[players[i]] = slotBack(box[2])
		end
	end
	race.group = freeGroup()
	for _, p in ipairs(players) do
		inRace[p] = race
		if race.group then
			setGroup(p, race.group)
		end
	end
	if #players == 2 then
		players[1]:SetAttribute("RaceOpponent", players[2].UserId)
		players[2]:SetAttribute("RaceOpponent", players[1].UserId)
	end
	if race.practice then
		players[1]:SetAttribute("RacePractice", true)
	else
		setAll(race, "RaceField", #players)
	end
	setAll(race, "RaceKind", race.kind)
	setAll(race, "RaceReady", false)
	setAll(race, "RaceProgress", 0)
	setState(race, "Gather", Config.Race.GatherSeconds)
	for _, p in ipairs(players) do
		Ride.fit(p)
	end
	local function hello(p)
		local rival = other(race, p)
		if race.kind == "Sky" then
			say(p, rival and string.format("%s님과 🦅 하늘 레이스! 노란 링을 지나 빨간 링까지 (내리면 져요)", rival.DisplayName)
				or string.format("🦅 %d명 하늘 레이스! 노란 링을 지나 빨간 링까지 (내리면 져요)", #players))
		else
			say(p, rival and string.format("%s님과 레이스! 🦖 걷는 공룡을 타면 준비 끝 (내리면 져요)", rival.DisplayName)
				or string.format("🏁 %d명 레이스! 🦖 걷는 공룡을 타면 준비 끝 (내리면 져요)", #players))
		end
		say(p, race.ranked and RANKED_LINE or NORMAL_LINE)
	end
	if race.kind == "Sky" then
		makeSkyCourse(race, race.center)
		for i, p in ipairs(race.players) do
			toSkyStart(race, p, i)
		end
		if race.practice then
			say(players[1], "⏱️ 🦅 하늘 레이스 기록전! 노란 링을 지나 빨간 링까지 (내리면 끝)")
			return race
		end
		for _, p in ipairs(race.players) do
			hello(p)
		end
		return race
	end
	for _, p in ipairs(race.players) do
		toStartBox(p, race.box[p][1], race.box[p][2])
	end
	if race.practice then
		say(players[1], "⏱️ 🏁 레이스 기록전! 한 바퀴 돌아 결승선까지 (내리면 끝)")
		return race
	end
	for _, p in ipairs(race.players) do
		hello(p)
	end
	return race
end

local function countdown(race)
	if race.kind == "Sky" then
		for i, p in ipairs(race.players) do
			toSkyStart(race, p, i)
			race.ring[p] = 1
			race.used[p] = {}
			p:SetAttribute("SkyRing", 1)
			Net.push(p, "SkyRings", race.course, Config.Race.Sky.RingRadius)
			Net.push(p, "SkyPads", race.skyPads)
		end
		setState(race, "Countdown", Config.Race.CountdownSeconds)
		return
	end
	for _, p in ipairs(race.players) do
		toStartBox(p, race.box[p][1], race.box[p][2])
		if race.group then
			setGroup(p, race.group) -- (again: a new character since)
		end
	end
	local seed = math.random(1, 2147483646)
	race.pads, race.obstacles, race.mud = Formulas.raceLayout(function()
		seed = (seed * 48271) % 2147483647
		return seed / 2147483647
	end)
	for _, p in ipairs(race.players) do
		race.used[p] = {}
		Net.push(p, "RacePads", race.pads)
		Net.push(p, "RaceObstacles", race.obstacles, race.mud)
	end
	setState(race, "Countdown", Config.Race.CountdownSeconds)
end

local function go(race)
	for _, p in ipairs(race.players) do
		local _, root = alive(p)
		local pos = root and root.Position or startBox(1, race.box[p] and race.box[p][2])
		race.progress[p] = 0
		race.lastAngle[p] = Formulas.compassAngle(pos.X, pos.Z)
		race.lastPos[p] = flat(pos)
	end
	race.goAt = os.clock() -- (the result screen's time)
	race.weatherMax = Formulas.weather(ReplicatedStorage:GetAttribute("Weather")).MoveSpeedMultiplier or 1
	race.best, race.movedAt, race.stallWarned = {}, {}, {}
	for _, p in ipairs(race.players) do
		race.movedAt[p] = os.clock()
	end
	if race.kind == "Sky" then
		for _, p in ipairs(race.players) do
			local _, root = alive(p)
			race.lastWorld[p] = root and root.Position or race.skyStart
		end
		setState(race, "Go", Config.Race.Sky.TimeLimit)
		return
	end
	setState(race, "Go", Config.Race.TimeLimit)
end

-- a sky racer: through their next ring? (the path since the last check, so a fast flyer can't skip it)
local function trackSky(race, p)
	local _, root = alive(p)
	if not root then
		return
	end
	local s = Config.Race.Sky
	local now = root.Position
	local last = race.lastWorld[p] or now
	race.lastWorld[p] = now
	if not onFlyingDino(p) then
		return
	end
	-- the upright boost pads flown through (each once), like the road's
	local c = Config.Race
	local used = race.used[p] or {}
	race.used[p] = used
	for k, pad in ipairs(race.skyPads or {}) do
		if not used[k] and toSegment3(pad[1], last, now) <= s.PadRadius + s.PadSlack then
			used[k] = true
			if pad[2] == "Yellow" then
				MoveGuard.boost(p, c.YellowMultiplier, c.YellowBoostSeconds)
			else
				MoveGuard.boost(p, c.PadMultiplier, c.PadBoostSeconds)
			end
			Net.push(p, "RacePadHit", k)
		end
	end
	local i = race.ring[p] or 1
	local target = race.course[i]
	if not target or toSegment3(target, last, now) > s.RingRadius + s.PassSlack then
		return
	end
	i += 1
	race.ring[p] = i
	p:SetAttribute("SkyRing", i)
	p:SetAttribute("RaceProgress", math.min(1, (i - 1) / ringsOf(race)))
	if i > ringsOf(race) then
		crossLine(race, p)
	end
end

-- distance from point p to the segment a-b (all flat)
local function toSegment(p, a, b)
	local ab = b - a
	local len2 = ab:Dot(ab)
	local t = len2 > 0 and math.clamp((p - a):Dot(ab) / len2, 0, 1) or 0
	return (a + ab * t - p).Magnitude
end

-- a racer past the barrier (lag, a glitch): back onto the road at the same angle
local function keepOnRoad(p, root)
	local c = Config.Race
	local pos = flat(root.Position)
	local r = pos.Magnitude
	local edge = c.Width / 2
	if r < 0.1 or math.abs(r - c.Radius) <= edge + c.BarrierSlack then
		return
	end
	local back = pos.Unit * (c.Radius + math.clamp(r - c.Radius, -(edge - 1), edge - 1))
	MoveGuard.allow(p)
	root.CFrame = root.CFrame + Vector3.new(back.X - pos.X, 0, back.Z - pos.Z)
end

-- a racer in an obstacle, or standing on one (Formulas.raceObstacleHit): its screen should have stopped
-- them, so back to where they were
local function airborne(p)
	local humanoid = p.Character and p.Character:FindFirstChildOfClass("Humanoid")
	local root = humanoid and humanoid.RootPart
	if not humanoid or not root then
		return false
	end
	local state = humanoid:GetState()
	return state == Enum.HumanoidStateType.Jumping or state == Enum.HumanoidStateType.Freefall
		or math.abs(root.AssemblyLinearVelocity.Y) > AIRBORNE_SPEED
end

local function keepOutOfObstacles(race, p, root)
	local last = race.lastPos[p]
	if not last or not race.obstacles then
		return
	end
	race.safePos = race.safePos or {}
	local feet = root.Position.Y - (p:GetAttribute("RideDrop") or STAND_LIFT)
	local pos = flat(root.Position)
	local up = airborne(p)
	-- (where they are now, and halfway from the last check so a fast racer can't step past a thin one;
	-- not halfway in the air: a jump just landed may put that inside a hurdle)
	race.inSince = race.inSince or {}
	for _, at in ipairs(up and { pos } or { pos, (pos + last) / 2 }) do
		if Formulas.raceObstacleHit(race.obstacles, at, feet, up, ROAD_TOP, OBSTACLE_SHRINK) then
			-- (2026-10-04, "자꾸 장애물에 밀려나는게 조금 부자연": was at once, back to the last clear spot) only when it
			-- lasts (ObstacleGraceSeconds: a moment in one is the lag), out at the obstacle's face on the way from the
			-- last clear spot (the last check may already be on top of one)
			local now = os.clock()
			race.inSince[p] = race.inSince[p] or now
			if now - race.inSince[p] < Config.Race.ObstacleGraceSeconds then
				return
			end
			race.inSince[p] = nil
			local safe = race.safePos[p] or last
			local out = Formulas.raceClearPoint(race.obstacles, safe, at, feet, up, ROAD_TOP, OBSTACLE_SHRINK)
			MoveGuard.allow(p)
			root.CFrame = root.CFrame + Vector3.new(out.X - pos.X, 0, out.Z - pos.Z)
			root.AssemblyLinearVelocity = Vector3.new(0, math.min(root.AssemblyLinearVelocity.Y, 0), 0)
			return
		end
	end
	race.inSince[p] = nil
	if not Formulas.raceObstacleHit(race.obstacles, pos, -math.huge, false, ROAD_TOP, OBSTACLE_SHRINK) then
		race.safePos[p] = pos -- (not over any obstacle at all, at any height)
	end
end

-- a moving obstacle (hammer, spinner) touching a racer: bounced back along the road and up, still riding
local function hitByMovers(race, p, root)
	local c = Config.Race
	local pos = flat(root.Position)
	local feet = root.Position.Y - (p:GetAttribute("RideDrop") or STAND_LIFT)
	local i = Formulas.raceMoverHit(race.obstacles, pos, feet, ROAD_TOP, Workspace:GetServerTimeNow())
	race.hitAt = race.hitAt or {}
	race.hitAt[p] = race.hitAt[p] or {}
	if not i or os.clock() - (race.hitAt[p][i] or -math.huge) < c.HitCooldown then
		return
	end
	race.hitAt[p][i] = os.clock()
	-- (2026-10-04, "자꾸 장애물에 밀려나는게 조금 부자연": was put back at once, then tossed up) flown back along the road
	-- (against the race's way: the compass angle goes down) HitPushBack studs in an arc over HitBounceSeconds by the
	-- racer's own screen (Net push RaceHit), still riding (no stun: it would dismount); the server lets the move
	-- through. The way back is taken off the progress as it is ridden back, and riding it again gives it back
	local a = math.rad(Formulas.compassAngle(pos.X, pos.Z))
	local backX, backZ = -math.cos(a), -math.sin(a)
	MoveGuard.clearBoost(p)
	MoveGuard.loosen(p, c.HitBounceSeconds + BOUNCE_GRACE, c.HitPushBack / c.HitBounceSeconds * BOUNCE_SPEED_SLACK)
	race.hits = race.hits or {}
	race.hits[p] = (race.hits[p] or 0) + 1
	Net.push(p, "RaceHit", race.obstacles[i][3], backX, backZ, c.HitPushBack, c.HitBounceSeconds)
end

local function track(race, p)
	local _, root = alive(p)
	if not root then
		return
	end
	keepOnRoad(p, root)
	keepOutOfObstacles(race, p, root)
	hitByMovers(race, p, root)
	if race.mud and MoveGuard.boosted(p) then -- a pad's boost ends in a jump section's mud
		local at = flat(root.Position)
		if Formulas.inRaceMud(race.mud, Formulas.compassAngle(at.X, at.Z)) then
			MoveGuard.clearBoost(p)
		end
	end
	local c = Config.Race
	local pos = flat(root.Position)
	local angle = Formulas.compassAngle(pos.X, pos.Z)
	local prev = race.lastAngle[p]
	local step = Formulas.angleStep(prev, angle)
	race.lastAngle[p] = angle
	local onTrack = math.abs(pos.Magnitude - c.Radius) <= c.Width / 2 + c.OffTrack
	if onTrack and onRaceDino(race, p) then
		race.progress[p] += step
	elseif race.kind == "Road" and p:GetAttribute("Flying") and not race.warned[p] then
		race.warned[p] = true
		say(p, "🦅 나는 공룡은 이 레이스에 못 나가요! 🦖 걷는 공룡을 타요")
	end
	local shown = math.floor(howFar(race, p) / PROGRESS_STEP) * PROGRESS_STEP
	if p:GetAttribute("RaceProgress") ~= shown then
		p:SetAttribute("RaceProgress", shown)
	end
	-- the purple pads passed over since the last check
	local last = race.lastPos[p] or pos
	race.lastPos[p] = pos
	if onRaceDino(race, p) then
		for i, pad in ipairs(race.pads) do
			if not race.used[p][i] and toSegment(Vector3.new(pad[1], 0, pad[2]), last, pos) <= c.PadRadius + PAD_SLACK then
				race.used[p][i] = true
				if pad[3] == "Yellow" then
					MoveGuard.boost(p, c.YellowMultiplier, c.YellowBoostSeconds)
				else
					MoveGuard.boost(p, c.PadMultiplier, c.PadBoostSeconds)
				end
				Net.push(p, "RacePadHit", i)
			end
		end
	end
	if (race.short and race.progress[p] >= Config.Race.TutorialDegrees)
		or Formulas.raceFinished(race.progress[p], prev, angle, race.back[p]) then
		crossLine(race, p)
	end
end

-- (2026-10-02) has this racer got no further for Config.Race.StallSeconds? (a warning a while before)
local function stalled(race, p)
	local c = Config.Race
	local now = os.clock()
	local best = race.best[p]
	if race.kind == "Sky" then
		local _, root = alive(p)
		local ring = race.ring[p] or 1
		local target = race.course[ring]
		local d = (root and target) and (root.Position - target).Magnitude or math.huge
		if not best or ring > best[1] or d < best[2] - STALL_STUDS then
			race.best[p], race.movedAt[p] = { ring, d }, now
		end
	else
		local degrees = race.progress[p] or 0
		if not best or degrees > best + STALL_DEGREES then
			race.best[p], race.movedAt[p] = degrees, now
		end
	end
	local still = now - (race.movedAt[p] or now)
	if still >= c.StallSeconds then
		return true
	elseif still >= c.StallWarnSeconds then
		if not race.stallWarned[p] then
			race.stallWarned[p] = true
			say(p, string.format(race.practice and "⚠️ 앞으로 가지 않으면 %d초 뒤에 연습이 끝나요"
				or "⚠️ 앞으로 가지 않으면 %d초 뒤에 기권패예요", c.StallSeconds - c.StallWarnSeconds))
		end
	else
		race.stallWarned[p] = nil
	end
	return false
end

local function tick()
	local seen = {}
	for _, race in pairs(inRace) do
		if not seen[race] and not race.over then
			seen[race] = true
			local now = os.clock()
			if race.state == "Gather" then
				local ready = 0
				for _, p in ipairs(race.players) do
					local ok = onRaceDino(race, p)
					if p:GetAttribute("RaceReady") ~= ok then
						p:SetAttribute("RaceReady", ok)
					end
					if race.kind == "Road" and p:GetAttribute("Flying") and not race.warned[p] then
						race.warned[p] = true
						say(p, "🦅 나는 공룡은 이 레이스에 못 나가요! 🦖 걷는 공룡을 타요")
					end
					ready += ok and 1 or 0
				end
				if ready == #race.players then
					countdown(race)
				elseif now >= race.untilTime and not race.practice and ready >= 2 then
					-- (2026-10-04: two or more racers) those not on a dino by now are out, the rest go
					for _, p in ipairs(table.clone(race.players)) do
						if not onRaceDino(race, p) then
							local why = string.format("⏱️ %s님이 시간 안에 공룡을 타지 않아 빠졌어요", p.DisplayName)
							leaveEarly(race, p, why, why)
						end
					end
					if not race.over then
						countdown(race)
					end
				elseif now >= race.untilTime then
					finish(race, nil, race.practice and "⏱️ 시간 안에 공룡을 타지 않아 연습이 취소됐어요"
						or #race.players == 2 and "⏱️ 시간 안에 둘 다 공룡을 타지 않아 레이스가 취소됐어요"
						or "⏱️ 시간 안에 공룡을 탄 사람이 모자라 레이스가 취소됐어요")
				end
			elseif race.state == "Countdown" or race.state == "Go" then
				-- off the dino (or on a flying one) from the countdown on: 기권패 (out of the race)
				for _, p in ipairs(table.clone(race.players)) do
					if not race.over and not onRaceDino(race, p) then
						dropOut(race, p, offWhy(race, p))
					end
				end
			end
			if race.over then -- (finished just above)
				continue
			elseif race.state == "Countdown" then
				for _, p in ipairs(race.players) do
					local _, root = alive(p)
					if root and race.kind ~= "Sky" then
						keepOnRoad(p, root)
					end
				end
				if now >= race.untilTime then
					go(race)
				end
			elseif race.state == "Go" then
				local w = Formulas.weather(ReplicatedStorage:GetAttribute("Weather")).MoveSpeedMultiplier or 1
				race.weatherMax = math.max(race.weatherMax or 1, w)
				for _, p in ipairs(table.clone(race.players)) do
					if not race.over and table.find(race.players, p) then
						if race.kind == "Sky" then
							trackSky(race, p)
						else
							track(race, p)
						end
						if not race.over and stalled(race, p) then
							dropOut(race, p, race.practice
								and string.format("⏱️ %d초 동안 앞으로 가지 않아 연습이 끝났어요", Config.Race.StallSeconds)
								or string.format("%s님이 %d초 동안 멈춰 기권패", p.DisplayName, Config.Race.StallSeconds))
						end
					end
				end
				if not race.over and #race.starters > 2 then -- (2026-10-04) the places, for the bars
					for i, p in ipairs((standings(race))) do
						if p:GetAttribute("RacePlace") ~= #race.finishers + i then
							p:SetAttribute("RacePlace", #race.finishers + i)
						end
					end
				end
				if not race.over and now >= race.untilTime then
					if race.practice then
						finish(race, nil, "⏱️ 시간 초과! 연습이 끝났어요")
					elseif race.winner then
						finish(race, race.winner, "⏱️ 시간 초과! 남은 사람은 간 거리로 등수")
					else
						-- the furthest wins (the sky race: more rings passed, then nearer the next one); the first two
						-- just as far: a draw
						local order, far = standings(race)
						local a, b = far[order[1]], order[2] and far[order[2]]
						if b and a[1] == b[1] and (race.kind ~= "Sky" or math.abs(a[2] - b[2]) < 1) then
							finish(race, nil, "시간 초과! 무승부예요")
						else
							finish(race, order[1], race.kind == "Sky" and "시간 초과, 링을 더 많이 지난 사람 승리"
								or "시간 초과, 더 멀리 간 사람 승리")
						end
					end
				end
			end
		end
	end
end

local function challenge(player, userId)
	if not Unlocks.check(player, "GameRooms") then
		return
	end
	local target = Players:GetPlayerByUserId(userId)
	if not target or target == player then
		return
	end
	if inRace[player] then
		say(player, "이미 레이스 중이에요")
		return
	end
	if inRace[target] then
		say(player, target.DisplayName .. "님은 지금 레이스 중이에요")
		return
	end
	if lastChallenge[player] and os.clock() - lastChallenge[player] < Config.Race.ChallengeCooldown then
		say(player, "⏳ 조금 뒤에 다시 신청해 주세요")
		return
	end
	if (player:GetAttribute("CarriedKeys") or 0) > 0 then -- (2026-10-04: the start is a trip to the track)
		say(player, KEYS_WHY)
		return
	end
	local _, rootA = alive(player)
	local _, rootB = alive(target)
	if not rootA or not rootB or (rootA.Position - rootB.Position).Magnitude > Config.Race.ChallengeRange + RANGE_SLACK
		or SafeZones.inSky(player, rootA.Position) or SafeZones.inSky(target, rootB.Position) then -- (2026-10-04: only looking)
		return
	end
	-- (2026-10-01) on a flying dino it's a sky race: both must fly
	local kind = onFlyingDino(player) and "Sky" or onWalkingDino(player) and "Road" or nil
	if not kind then
		say(player, "🦖 공룡을 타야 레이스를 할 수 있어요! (🦖 걷는 공룡: 길 · 🦅 나는 공룡: 하늘)")
		return
	end
	if kind == "Sky" and not onFlyingDino(target) then
		say(player, string.format("%s님이 🦅 나는 공룡을 안 타고 있어요", target.DisplayName))
		return
	elseif kind == "Road" and not onWalkingDino(target) then
		say(player, string.format("🦖 %s님이 걷는 공룡을 안 타고 있어요", target.DisplayName))
		return
	end
	lastChallenge[player] = os.clock()
	invites[target] = invites[target] or {}
	invites[target][player] = { expires = os.clock() + Config.Race.InviteSeconds, kind = kind }
	Net.push(target, "RaceInvite", player.UserId, player.DisplayName, Config.Race.InviteSeconds, kind)
	say(player, target.DisplayName .. (kind == "Sky" and "님에게 🦅 하늘 레이스를 신청했어요!" or "님에게 레이스를 신청했어요! 🏁"))
end

-- can this player be in a race room now? (else why not)
local function canRoom(player)
	if not alive(player) or not PlayerData.isLoaded(player) then
		return false, "🚫 지금은 레이스를 할 수 없어요"
	elseif player:GetAttribute("TutorialStep") then
		return false, "🐣 튜토리얼을 마치고 해요"
	elseif player:GetAttribute("InRoom") == "Hide" or player:GetAttribute("HideSeekRoom") then
		return false, "🙈 숨바꼭질 방에서 먼저 나와요"
	elseif inRace[player] then
		return false, "이미 레이스 중이에요"
	elseif (player:GetAttribute("CarriedKeys") or 0) > 0 then
		return false, KEYS_WHY
	end
	return true
end

local function mountWhy(kind)
	return kind == "Sky" and "🦅 나는 공룡을 탈 공룡으로 골라야 해요 (환생 표지판 뒤 🦖 발판)"
		or "🦖 걷는 공룡을 탈 공룡으로 골라야 해요 (환생 표지판 뒤 🦖 발판)"
end

local picking = {}
local function askPick(player, kind, retry)
	picking[player] = { kind = kind, at = os.clock() }
	Net.push(player, "RaceMountPick", kind, retry or "")
end

local function setRaceMount(player, species, rarity, size)
	local ask = picking[player]
	if not ask or os.clock() - ask.at > Config.Race.Rooms.MountPickSeconds then
		return
	end
	if (ask.kind == "Sky") ~= (Formulas.flies(species) == true) then
		return say(player, ask.kind == "Sky" and "🦅 하늘 레이스는 나는 공룡만 나가요" or "🦖 길 레이스는 걷는 공룡만 나가요")
	end
	if Ride.register(player, species, rarity, size) then
		picking[player] = nil
	end
end

-- (2026-10-02) a practice race alone, from the mount window: kind "Road" (a walking mount) or "Sky" (a flying one)
local function practice(player, kind)
	if not Unlocks.check(player, "Ride") then
		return
	end
	if kind ~= "Road" and kind ~= "Sky" then
		return
	end
	if inRace[player] then
		say(player, "이미 레이스 중이에요")
		return
	end
	if lastChallenge[player] and os.clock() - lastChallenge[player] < Config.Race.ChallengeCooldown then
		say(player, "⏳ 조금 뒤에 다시 해 주세요")
		return
	end
	if (player:GetAttribute("CarriedKeys") or 0) > 0 then
		say(player, KEYS_WHY)
		return
	end
	local ok, why = canRoom(player)
	if not ok then
		say(player, why)
		return
	end
	if player:GetAttribute("InRoom") == "Race" then
		say(player, "🚪 레이스 방에서 먼저 나와요")
		return
	end
	local species = Ride.registered(player)
	if not species or (kind == "Sky") ~= (Formulas.flies(species) == true) then
		askPick(player, kind, "Practice")
		return
	end
	lastChallenge[player] = os.clock()
	if not player:GetAttribute("Riding") then
		Ride.getOn(player) -- (on it now; if it can't, the start waits Config.Race.GatherSeconds for a ride)
	end
	local short = player:GetAttribute("InTutorial") == true
	if short and kind == "Sky" then
		say(player, string.format("🦅 연습이라 링 %d개만 지나면 끝나요!", Config.Race.TutorialSky.Rings + 1))
	elseif short then
		say(player, "🏁 연습이라 트랙 1/4만 달려요! 금방 끝나요")
	end
	startRace({ player }, kind, { practice = true, short = short,
		center = short and kind == "Sky" and Unlocks.wildTree(player) or nil })
end

local function answer(player, userId, accept)
	local challenger = Players:GetPlayerByUserId(userId)
	local list = invites[player]
	local invite = challenger and list and list[challenger]
	if not invite then
		return
	end
	list[challenger] = nil
	if os.clock() > invite.expires then
		say(player, "신청 시간이 지났어요")
		return
	end
	if not accept then
		say(challenger, player.DisplayName .. "님이 레이스를 거절했어요")
		return
	end
	local both = invite.kind == "Sky" and (onFlyingDino(player) and onFlyingDino(challenger))
		or (invite.kind == "Road" and onWalkingDino(player) and onWalkingDino(challenger))
	if not both then
		local text = invite.kind == "Sky" and "🦅 둘 다 나는 공룡을 타고 있어야 하늘 레이스를 할 수 있어요!"
			or "🦖 둘 다 걷는 공룡을 타야 해요! (🦅 나는 공룡은 하늘 레이스)"
		say(player, text)
		say(challenger, text)
		return
	end
	if inRace[player] or inRace[challenger] or not alive(player) or not alive(challenger) then
		say(player, "🚫 지금은 레이스를 시작할 수 없어요")
		return
	end
	for _, p in ipairs({ player, challenger }) do
		if (p:GetAttribute("CarriedKeys") or 0) > 0 then
			local text = string.format("🔑 %s님이 열쇠를 들고 있어서 레이스를 못 해요", p.DisplayName)
			say(player, text)
			say(challenger, text)
			return
		end
	end
	-- (2026-10-04) a challenge is 🎈 일반전: nothing saved ("개인적으로 즐길려면 그냥 다른 유저 가까히 가서")
	startRace({ challenger, player }, invite.kind, {})
end

-- ---------------------------------------------------------------------------
-- 🏁 Race rooms (2026-10-04, "레이스도 방 열수 있게 하자 술래잡기처럼 … 얘도 방 열면 알림 가게")
-- ---------------------------------------------------------------------------

local function pushRooms()
	Net.pushAll("RaceRooms", RoomLogic.snapshot(rooms))
end

local function sayRoom(room, text, except)
	for _, userId in ipairs(room.Members) do
		local p = Players:GetPlayerByUserId(userId)
		if p and userId ~= except then
			say(p, text)
		end
	end
end

-- (2026-10-04, "레이스 준비도 준비하면 알림으로 방 인원들한테 가고") a member readying (or not) is told to the rest of the
-- room, with how many are ready
local function sayReady(room, player, isReady)
	local n = 0
	for _, userId in ipairs(room.Members) do
		n += room.Ready[userId] and 1 or 0
	end
	sayRoom(room, isReady and string.format("✋ %s님 준비! (%d/%d명)", player.DisplayName, n, #room.Members)
		or string.format("%s님이 준비를 취소했어요 (%d/%d명)", player.DisplayName, n, #room.Members), player.UserId)
end

-- the player's registered mount is of the room's kind (a walking one on the road, a flying one in the sky)
local function mountFits(player, kind)
	local species = Ride.registered(player)
	return species ~= nil and (kind == "Sky") == (Formulas.flies(species) == true)
end



local function lacksStake(player, grade)
	if not Rewards.hasStake(player, grade) then
		say(player, string.format("🔑 이 랭킹전은 %s를 걸어야 해요 (등수가 높으면 더 많이 돌려받아요)", Rewards.stakeText(grade)))
		return true
	end
	return false
end

local function createRoom(player, kind, ranked, grade)
	if not Unlocks.check(player, "GameRooms") then
		return
	end
	local ok, why = canRoom(player)
	if not ok then
		return say(player, why)
	end
	if ranked == true and lacksStake(player, grade) then
		return
	end
	local room, reason = RoomLogic.create(rooms, player.UserId, kind, ranked, grade)
	if not room then
		return say(player, reason)
	end
	player:SetAttribute("InRoom", "Race")
	say(player, string.format("🚪 %d번 방을 열었어요. %d명 이상 모여 모두 준비하면 시작해요", room.Id, Config.Race.Rooms.MinPlayers))
	if not mountFits(player, room.Kind) then
		askPick(player, room.Kind)
	end
	-- the others here who could join hear of it, once every RoomNoticeGap seconds a player at most
	if os.clock() - (lastRoomNotice[player] or -math.huge) >= Config.Race.Rooms.RoomNoticeGap then
		lastRoomNotice[player] = os.clock()
		local text = string.format(room.Kind == "Sky" and "🦅 %s님이 하늘 레이스 방을 열었어요! 왼쪽 아래 🎮 놀이방 버튼으로 들어와요"
			or "🏁 %s님이 레이스 방을 열었어요! 왼쪽 아래 🎮 놀이방 버튼으로 들어와요", player.DisplayName)
			.. " · " .. (room.Ranked and "🏆 랭킹전 🔑 " .. Rewards.stakeText(room.Stake) or "🎈 일반전")
		for _, other in ipairs(Players:GetPlayers()) do
			if other ~= player and not other:GetAttribute("InRoom") and canRoom(other) then
				say(other, text)
				Net.push(other, "RoomCallFx") -- (2026-10-04: the 🎮 놀이방 button flashes, so they know where)
			end
		end
	end
	pushRooms()
end

local function joinRoom(player, roomId)
	if not Unlocks.check(player, "GameRooms") then
		return
	end
	local ok, why = canRoom(player)
	if not ok then
		return say(player, why)
	end
	local target = rooms.Rooms[roomId]
	if target and target.Ranked and lacksStake(player, target.Stake) then
		return
	end
	local room, reason = RoomLogic.join(rooms, player.UserId, roomId)
	if not room then
		return say(player, reason)
	end
	player:SetAttribute("InRoom", "Race")
	sayRoom(room, string.format("%s님이 들어왔어요", player.DisplayName), player.UserId)
	if not mountFits(player, room.Kind) then
		askPick(player, room.Kind)
	end
	pushRooms()
end

-- (2026-10-04, "놀이방에서 … 모집을 위한 알림을 날릴 수 있게 해줘 서버 안 사람들에게. 10초에 한 번씩", "방 만든 이후에
-- 가능하게", "방장만 하는게 낫지") 📣 모집: the host of a waiting race room tells everyone here not in it, at most every
-- Config.HideSeek.RecruitGap seconds (the same as the hide-and-seek rooms)
local function recruitRoom(player)
	local room = RoomLogic.roomOf(rooms, player.UserId)
	if not room or room.Phase ~= "Waiting" then
		return say(player, "📣 방에 들어간 뒤에 모집할 수 있어요")
	end
	if room.Host ~= player.UserId then -- (2026-10-04, "방장만 하는게 낫지")
		return say(player, "📣 모집은 방장만 할 수 있어요")
	end
	local left = Config.HideSeek.RecruitGap - (os.clock() - (lastRecruit[player] or -math.huge))
	if left > 0 then
		return say(player, string.format("📣 %d초 뒤에 다시 모집할 수 있어요", math.ceil(left)))
	end
	lastRecruit[player] = os.clock()
	local text = string.format(room.Kind == "Sky" and "📣 %s님이 🦅 하늘 레이스 %d번 방에서 기다려요! (%d/%d명) 왼쪽 아래 🎮 놀이방 버튼으로 들어와요"
		or "📣 %s님이 🏁 레이스 %d번 방에서 기다려요! (%d/%d명) 왼쪽 아래 🎮 놀이방 버튼으로 들어와요",
		player.DisplayName, room.Id, #room.Members, Config.Race.Rooms.MaxPlayers)
		.. " · " .. (room.Ranked and "🏆 랭킹전 🔑 " .. Rewards.stakeText(room.Stake) or "🎈 일반전")
	local members = {}
	for _, userId in ipairs(room.Members) do
		members[userId] = true
	end
	for _, other in ipairs(Players:GetPlayers()) do
		if not members[other.UserId] then
			say(other, text)
			Net.push(other, "RoomCallFx")
		end
	end
	say(player, "📣 서버의 모두에게 모집 알림을 보냈어요")
end

local function leaveRoom(player)
	local room = RoomLogic.roomOf(rooms, player.UserId)
	if not room then
		return
	end
	local race = inRace[player]
	if race and race.room == room then -- (racing: as 🏳️ 포기)
		if race.state == "Go" then
			dropOut(race, player, player.DisplayName .. "님이 포기")
		else
			leaveEarly(race, player, player.DisplayName .. "님이 레이스를 취소했어요",
				string.format("%s님이 레이스에서 빠졌어요", player.DisplayName))
		end
	end
	RoomLogic.leave(rooms, player.UserId)
	if player.Parent then
		player:SetAttribute("InRoom", nil)
	end
	if rooms.Rooms[room.Id] then
		sayRoom(room, string.format("%s님이 방에서 나갔어요", player.DisplayName))
	end
	pushRooms()
end

local function readyRoom(player, isReady)
	local room = RoomLogic.roomOf(rooms, player.UserId)
	if not room or room.Phase ~= "Waiting" then
		return
	end
	if isReady then
		local ok, why = canRoom(player)
		if not ok then
			return say(player, why)
		elseif not mountFits(player, room.Kind) then
			return askPick(player, room.Kind, "Ready")
		end
	end
	local was = room.Ready[player.UserId] == true
	RoomLogic.setReady(rooms, player.UserId, isReady)
	if was ~= (isReady == true) then
		sayReady(room, player, isReady)
	end
	if RoomLogic.canStart(room) and not room.StartAt then
		room.StartAt = os.clock() + Config.Race.Rooms.StartSeconds
		sayRoom(room, string.format("✅ 모두 준비 완료! %d초 뒤 시작해요", Config.Race.Rooms.StartSeconds))
	end
	pushRooms()
end

-- everyone ready, StartSeconds on: those who still can are put at the start, each on their own mount, and race
local function beginRoom(room)
	room.StartAt = nil
	for _, userId in ipairs(table.clone(room.Members)) do
		local p = Players:GetPlayerByUserId(userId)
		local ok, why = false, "🚫 지금은 레이스를 할 수 없어요"
		if p then
			ok, why = canRoom(p)
			if ok and not mountFits(p, room.Kind) then
				ok, why = false, mountWhy(room.Kind)
			end
		end
		if not ok then
			RoomLogic.leave(rooms, userId)
			if p then
				p:SetAttribute("InRoom", nil)
				say(p, why)
				say(p, "방에서 나왔어요")
			end
		end
	end
	if room.Ranked then
		for _, userId in ipairs(table.clone(room.Members)) do
			local p = Players:GetPlayerByUserId(userId)
			if p and lacksStake(p, room.Stake) then
				RoomLogic.leave(rooms, userId)
				p:SetAttribute("InRoom", nil)
				say(p, "방에서 나왔어요")
			end
		end
	end
	if not RoomLogic.canStart(room) then
		if rooms.Rooms[room.Id] then
			sayRoom(room, "👥 사람이 모자라 시작하지 못했어요")
		end
		pushRooms()
		return
	end
	local staked = {}
	if room.Ranked then
		for _, userId in ipairs(room.Members) do
			local p = Players:GetPlayerByUserId(userId)
			if p and Rewards.takeStake(p, room.Stake) then
				staked[p] = true
			end
		end
	end
	RoomLogic.start(room)
	local players = {}
	for _, userId in ipairs(room.Members) do
		local p = Players:GetPlayerByUserId(userId)
		if p then -- (off a dino of the other kind: each goes on their own mount at the start)
			if p:GetAttribute("Riding") and (room.Kind == "Sky") ~= (p:GetAttribute("Flying") == true) then
				Ride.getOff(p, nil, true)
			end
			table.insert(players, p)
		end
	end
	startRace(players, room.Kind, { ranked = room.Ranked, room = room, staked = room.Ranked and staked or nil, stake = room.Stake })
	for _, p in ipairs(players) do
		if not p:GetAttribute("Riding") then
			Ride.getOn(p)
		end
	end
	pushRooms()
end

roomRaceOver = function(room)
	if rooms.Rooms[room.Id] ~= room then
		return -- (everyone left it)
	end
	RoomLogic.over(room)
	sayRoom(room, "✅ 다시 하려면 모두 준비를 눌러요")
	pushRooms()
end

local function stepRooms()
	local now = os.clock()
	for _, room in pairs(rooms.Rooms) do
		if room.Phase == "Waiting" and room.StartAt then
			if not RoomLogic.canStart(room) then
				room.StartAt = nil
				sayRoom(room, "시작이 취소됐어요")
				pushRooms()
			elseif now >= room.StartAt then
				beginRoom(room)
			end
		end
	end
end

function Race.init()
	-- each race's riders bump each other and everything else, never another race's (setGroup)
	for i = 1, MAX_GROUPS do
		pcall(PhysicsService.RegisterCollisionGroup, PhysicsService, "Race" .. i) -- (already there: fine)
	end
	for i = 1, MAX_GROUPS do
		for j = i + 1, MAX_GROUPS do
			PhysicsService:CollisionGroupSetCollidable("Race" .. i, "Race" .. j, false)
		end
	end
	PlayerData.onLoaded(mirrorRecord) -- the record over their head
	Net.onRequest("RaceChallenge", { "number" }, challenge)
	Net.onRequest("RaceAnswer", { "number", "boolean" }, answer)
	Net.onRequest("RacePractice", { "string" }, practice)
	Net.onRequest("RaceQuit", {}, function(player)
		local race = inRace[player]
		if race then
			if race.practice then
				finish(race, nil, "연습을 그만뒀어요")
			elseif race.state == "Go" then
				dropOut(race, player, player.DisplayName .. "님이 포기")
			else
				leaveEarly(race, player, player.DisplayName .. "님이 레이스를 취소했어요",
					string.format("%s님이 레이스에서 빠졌어요", player.DisplayName))
			end
		end
	end)
	Net.onRequest("RaceRoomCreate", { "string", "boolean", "string" }, createRoom)
	Net.onRequest("RaceRoomJoin", { "number" }, joinRoom)
	Net.onRequest("RaceRoomLeave", {}, leaveRoom)
	Net.onRequest("RaceRoomReady", { "boolean" }, readyRoom)
	Net.onRequest("RaceRoomRecruit", {}, recruitRoom)
	Net.onRequest("SetRaceMount", { "string", "string", "string" }, setRaceMount)
	Net.onAsk("GetRaceRooms", { "any" }, function(player, opened)
		if opened == true then
			Rewards.add(player, "RoomsLook", 1)
		end
		local profile = PlayerData.get(player)
		local ranked = profile and profile.Ranked
		local week = RewardLogic.weekNumber(os.time())
		return { Rooms = RoomLogic.snapshot(rooms), WeekWins = ranked and ranked.Week == week and ranked.Race or 0 }
	end)
	Players.PlayerRemoving:Connect(function(player)
		picking[player] = nil
		local race = inRace[player]
		if race then
			if race.state == "Go" then
				dropOut(race, player, player.DisplayName .. "님이 나감")
			else
				leaveEarly(race, player, player.DisplayName .. "님이 나가서 레이스가 취소됐어요",
					string.format("%s님이 레이스에서 빠졌어요", player.DisplayName))
			end
		end
		if RoomLogic.roomOf(rooms, player.UserId) then
			leaveRoom(player)
		end
		invites[player], lastChallenge[player], lastRoomNotice[player], lastRecruit[player] = nil, nil, nil, nil
		for _, list in pairs(invites) do
			list[player] = nil
		end
	end)
	local since = 0
	RunService.Heartbeat:Connect(ServerMeter.wrap("Race", function(dt)
		since += dt
		if since >= TICK then
			since = 0
			tick()
			stepRooms()
		end
	end))
end

return Race
