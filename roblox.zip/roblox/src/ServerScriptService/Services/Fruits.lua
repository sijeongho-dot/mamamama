--[[
Fruits: 공룡 사육's fruit (design 2.6.2 / 4.8, Config.Fruit; 2026-10-02, "나무에서 떨어지는 열매의 크기도 랜덤으로
클수록 확률낮게 해서 … 열매를 모아서 먹이로 주면 공룡 크기를 키울 수 있는거"; then "열매주운거 남도 먹을 수 있게",
"열쇠처럼 주웠다 내려놓기도 가능한", chosen: carried, but a slap does not scatter it).

- The fruit trees are found once in Workspace.Map (the same model names the clients shake: round trees drop
  apples, firs pine cones, palms coconuts).
- Every slap (Combat.onSlap on the battlefield, Combat.onSafeSlap in the bases and the safe land) that reaches a
  fruit tree in front of the slapper (the clients' rule: within the slap's reach and a little, in front or very
  close) drops Fruit.PerTree fruits from it (2026-10-02: was one): at most Fruit.PerSlap trees a slap, the same tree again for the same slapper
  only after TreeCooldown, at most PerMinute fruits a minute per slapper and MaxOnGround on the whole server.
  Its size is rolled (Formulas.rollFruitSize: bigger ones rarer). Everyone is told (Net push FruitDrop) and
  draws it (StarterPlayerScripts/Trees); it waits LifeSeconds.
- (2026-10-05, "열매는 굳이 기지로 돌아가는 시스템을 안 넣어도 되지") a fruit picked up is food at once (profile Fruit, player
  attribute Fruit; Net push FruitStored(food) to the picker; events "FruitPick" and "FruitHome"): nothing is carried any
  more, so nothing to take home or put down. What follows about carrying is how it was (the code below stays for
  fruit someone still carried from before: none, since it was never saved).
- Net request PickFruit(id): anyone walking over it. The server checks it is still there, the player is within
  PickRange (and a little) and carries fewer than MaxCarried (and that the one who put it down waits
  DropperPickupDelay), then the fruit is carried (player attributes CarriedFruit = how many, CarriedFood = the
  food they are worth) and everyone hears Net push FruitGone(id, picker's UserId). Each pick counts as the event
  "FruitPick" (the tutorial's step).
- Carried fruit becomes food (profile Fruit, player attribute Fruit) once the player is inside their own base
  (Keys.insideOwnBase; Net push FruitStored(food) to them). A slap does not scatter it.
- Net request DropFruit(count): that many of the carried fruit (the last picked first; 2026-10-02, "갯수 정해서
  내려놓기") are put down around the player (DropSpread) for anyone, for DroppedLifetime; the one who put them
  down can pick them up again only after DropperPickupDelay. Leaving the game puts all of it down.
- Fruits.nearestTree(position): the tutorial's "slap a tree" step points at it.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Shared = ReplicatedStorage:WaitForChild("Shared")
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))
local Combat = require(script.Parent:WaitForChild("Combat"))
local Keys = require(script.Parent:WaitForChild("Keys"))

local Fruits = {}

local KINDS = { Tree = "Apple", Prop_Tree_Round = "Apple", Prop_Tree_Pine = "Pinecone", Prop_Tree_Palm = "Coconut" }
local TRUNK_SLACK = 3 -- studs past the slap's reach that still reach a trunk (as the clients)
local CANOPY_SPREAD = 0.35 -- of the tree's width: how far from the trunk a fruit lands
local PICK_SLACK = 6 -- studs the server allows past PickRange (lag)
local PICK_HEIGHT = 12 -- studs up or down from the fruit that still count
local HOME_CHECK = 0.5 -- seconds between looks for carriers inside their own base
local HAND_HEIGHT = 2 -- studs over the root a fruit put down falls from
local TUTORIAL_STEP = "Fruit" -- the tutorial step (Config.Tutorial.Steps Id) whose fruit is the player's alone

local trees = {} -- { model, kind, at (trunk foot), top, width }
local known = {} -- [model] = true
local rng = Random.new()
local nextId = 0
local ground = {} -- [id] = { At, Kind, Size, Until, Blocked (player), BlockedUntil }
local onGround = 0
local carried = {} -- [player] = { { Kind, Size }, ... }
local cooldowns = {} -- [player] = { [tree] = os.clock() it may drop again }
local buckets = {} -- [player] = { tokens, time }: PerMinute

local function consider(model)
	local kind = model:IsA("Model") and not known[model] and KINDS[model.Name]
	if kind and model.Parent and model:FindFirstChildWhichIsA("BasePart", true) then
		known[model] = true
		local cf, size = model:GetBoundingBox()
		local trunk = model:FindFirstChild("Trunk") or model:FindFirstChild("TrunkCollider")
		local foot = trunk and trunk:IsA("BasePart") and trunk.Position or cf.Position
		table.insert(trees, {
			model = model,
			kind = kind,
			at = Vector3.new(foot.X, cf.Position.Y - size.Y / 2, foot.Z),
			top = cf.Position.Y + size.Y / 2,
			width = math.max(size.X, size.Z),
		})
	end
end

local function collect()
	local map = Workspace:FindFirstChild("Map")
	for _, model in ipairs(map and map:GetDescendants() or {}) do
		consider(model)
	end
	if map then
		map.DescendantAdded:Connect(function(d)
			if KINDS[d.Name] and d:IsA("Model") then
				task.defer(consider, d)
			end
		end)
	end
end

local function takeToken(player)
	local now = os.clock()
	local perSecond = Config.Fruit.PerMinute / 60
	local b = buckets[player]
	if not b then
		b = { tokens = Config.Fruit.PerMinute, time = now }
		buckets[player] = b
	end
	b.tokens = math.min(Config.Fruit.PerMinute, b.tokens + (now - b.time) * perSecond)
	b.time = now
	if b.tokens < 1 then
		return false
	end
	b.tokens -= 1
	return true
end

-- the fruit that waited too long is gone (each screen fades its own; nothing is sent)
local function sweep(now)
	for id, f in pairs(ground) do
		if f.Until < now then
			ground[id] = nil
			onGround -= 1
		end
	end
end

-- a new fruit on the ground at `at`; returns what the clients are told
local function place(kind, sizeId, at, top, life, blocked, owner)
	local now = os.clock()
	nextId += 1
	local id = "F" .. nextId
	ground[id] = { At = at, Kind = kind, Size = sizeId, Until = now + life, Blocked = blocked,
		BlockedUntil = blocked and now + Config.Fruit.DropperPickupDelay or 0, Owner = owner }
	onGround += 1
	return { Id = id, Kind = kind, Size = sizeId, At = at, Top = top, Life = life,
		BlockedUser = blocked and blocked.UserId or nil,
		BlockedUntil = blocked and Workspace:GetServerTimeNow() + Config.Fruit.DropperPickupDelay or nil }
end

local function setCarried(player)
	local list = carried[player] or {}
	local food = 0
	for _, f in ipairs(list) do
		food += Formulas.fruitSize(f.Size).Food
	end
	player:SetAttribute("CarriedFruit", #list > 0 and #list or nil)
	player:SetAttribute("CarriedFood", #list > 0 and food or nil)
	return food
end

-- a slap (Combat's hooks): the fruit trees it reaches drop one fruit each
local function onSlap(player, root, reach, _level)
	-- (an egg bomb's blast "looks" straight up: not a slap at a tree)
	if not PlayerData.isLoaded(player) or math.abs(root.CFrame.LookVector.Y) > 0.9 then
		return {}
	end
	local now = os.clock()
	local f = Config.Fruit
	sweep(now)
	local cool = cooldowns[player] or {}
	cooldowns[player] = cool
	local look = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z)
	look = look.Magnitude > 0.01 and look.Unit or Vector3.zAxis
	local dropped = {}
	-- (2026-10-02) on the tutorial's "slap a tree" step the fruit is the new player's alone (only they see and pick it),
	-- so nobody can take it and leave them stuck
	local owner = player:GetAttribute("TutorialStep") == TUTORIAL_STEP and player or nil
	local treesHit = 0
	for _, tree in ipairs(trees) do
		if treesHit >= f.PerSlap or onGround >= f.MaxOnGround then
			break
		end
		local offset = Vector3.new(tree.at.X - root.Position.X, 0, tree.at.Z - root.Position.Z)
		local d = offset.Magnitude
		if d <= reach + TRUNK_SLACK and (d < Config.Slap.CloseRadius + TRUNK_SLACK or offset.Unit:Dot(look) >= Config.Slap.FrontDot)
			and (cool[tree] or 0) <= now and tree.model.Parent then
			cool[tree] = now + f.TreeCooldown
			treesHit += 1
			-- (2026-10-02, "열매 나무에서 하나씩 밖에 안 나오네 중복채취도 안 되고") a few fruits a slap (PerTree)
			for _ = 1, rng:NextInteger(f.PerTree.Min, f.PerTree.Max) do
				if onGround >= f.MaxOnGround or not takeToken(player) then
					break
				end
				local size = Formulas.rollFruitSize(rng:NextNumber())
				local a = rng:NextNumber() * 2 * math.pi
				local r = rng:NextNumber() * tree.width * CANOPY_SPREAD
				local at = tree.at + Vector3.new(math.cos(a) * r, 0, math.sin(a) * r)
				table.insert(dropped, place(tree.kind, size.Id, at, tree.top, f.LifeSeconds, nil, owner))
			end
		end
	end
	if #dropped > 0 and owner then
		Net.push(player, "FruitDrop", dropped)
	elseif #dropped > 0 then
		Net.pushAll("FruitDrop", dropped)
	end
	return {} -- (nothing was "hit": no hit flash)
end

local function pick(player, id)
	local fruit = type(id) == "string" and ground[id]
	if not fruit then
		return
	end
	local now = os.clock()
	if fruit.Until < now then
		ground[id] = nil
		onGround -= 1
		return
	end
	if (fruit.Blocked == player and fruit.BlockedUntil > now) or (fruit.Owner and fruit.Owner ~= player) then
		return
	end
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not root or SafeZones.inSky(player, root.Position) then -- (2026-10-04: on a flying dino over the battlefield)
		return
	end
	local flat = Vector3.new(root.Position.X - fruit.At.X, 0, root.Position.Z - fruit.At.Z).Magnitude
	if flat > Config.Fruit.PickRange + PICK_SLACK or math.abs(root.Position.Y - fruit.At.Y) > PICK_HEIGHT then
		return
	end
	if not PlayerData.isLoaded(player) then
		return
	end
	ground[id] = nil
	onGround -= 1
	-- (2026-10-05) food at once, wherever it is picked
	local food = Formulas.fruitSize(fruit.Size).Food
	PlayerData.update(player, function(p)
		p.Fruit = (p.Fruit or 0) + food
	end)
	player:SetAttribute("Fruit", PlayerData.get(player).Fruit)
	Net.pushAll("FruitGone", id, player.UserId)
	Net.push(player, "FruitStored", food)
	Rewards.add(player, "FruitPick", 1) -- (the tutorial's step)
	Rewards.add(player, "FruitHome", 1) -- (the beginner mission "🍎 열매 줍기"; the tutorial's step after it is passed by)
end

-- put `count` of the carried fruit (the last picked first; nil: all) down around `at` (on purpose, or leaving)
local function putDown(player, at, count)
	local all = carried[player]
	if not all or #all == 0 then
		return
	end
	local n = math.clamp(math.floor(count or #all), 1, #all)
	local list = {}
	for _ = 1, n do
		table.insert(list, table.remove(all))
	end
	if #all == 0 then
		carried[player] = nil
	end
	if player.Parent then
		setCarried(player)
	end
	sweep(os.clock())
	local placed = {}
	for i, f in ipairs(list) do
		if onGround >= Config.Fruit.MaxOnGround then
			break -- (the server is full of fruit: the rest is lost)
		end
		local a = (i / #list) * 2 * math.pi + rng:NextNumber() * 0.5
		local r = 1 + rng:NextNumber() * (Config.Fruit.DropSpread - 1)
		local spot = Vector3.new(at.X + math.cos(a) * r, at.Y, at.Z + math.sin(a) * r)
		table.insert(placed, place(f.Kind, f.Size, spot, at.Y + HAND_HEIGHT, Config.Fruit.DroppedLifetime,
			player.Parent and player or nil))
	end
	if #placed > 0 then
		Net.pushAll("FruitDrop", placed)
	end
end

local function dropFruit(player, count)
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if root and count >= 1 then
		-- (the fruit lies on the ground under the player: the root is about 3 studs up)
		putDown(player, root.Position - Vector3.new(0, 3, 0), count)
	end
end

-- carriers inside their own base: the fruit becomes food
local function storeHome()
	for player, list in pairs(carried) do
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if #list > 0 and root and PlayerData.isLoaded(player) and Keys.insideOwnBase(player, root.Position) then
			local food = setCarried(player)
			carried[player] = nil
			setCarried(player)
			PlayerData.update(player, function(p)
				p.Fruit = (p.Fruit or 0) + food
			end)
			player:SetAttribute("Fruit", PlayerData.get(player).Fruit)
			Net.push(player, "FruitStored", food)
			Rewards.add(player, "FruitHome", 1) -- (2026-10-03: the tutorial field's "bring the fruit home" step)
		end
	end
end

-- the fruit tree nearest a spot (the tutorial's step points at it), nil when there is none
function Fruits.nearestTree(position)
	local best, bestD = nil, math.huge
	for _, tree in ipairs(trees) do
		local d = (Vector3.new(tree.at.X, position.Y, tree.at.Z) - position).Magnitude
		if d < bestD and tree.model.Parent then
			best, bestD = tree, d
		end
	end
	return best and best.at
end

function Fruits.treeSpots()
	local list = {}
	for _, tree in ipairs(trees) do
		if tree.model.Parent then
			table.insert(list, tree.at)
		end
	end
	return list
end

function Fruits.init()
	collect()
	Combat.onSlap(onSlap)
	Combat.onSafeSlap(onSlap)
	Net.onRequest("PickFruit", { "string" }, pick)
	Net.onRequest("DropFruit", { "number" }, dropFruit)
	PlayerData.onLoaded(function(player, profile)
		player:SetAttribute("Fruit", profile.Fruit or 0)
	end)
	Players.PlayerRemoving:Connect(function(player)
		local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if root then
			putDown(player, root.Position - Vector3.new(0, 3, 0))
		end
		carried[player], cooldowns[player], buckets[player] = nil, nil, nil
	end)
	task.spawn(function()
		while true do
			task.wait(HOME_CHECK)
			local ok, err = pcall(storeHome)
			if not ok then
				warn("[Fruits]", err)
			end
		end
	end)
end

return Fruits
