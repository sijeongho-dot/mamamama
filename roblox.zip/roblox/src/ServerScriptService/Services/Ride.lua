--[[
Ride: riding a dino in the safe land (design 2.8 공룡 타기).

- Where: the bases and all the land outside the battlefield flags (Shared/SafeZones.isSafe). Going in
  past the flags on a walking dino gets the player off at once (a flying one may fly over it: below).
- Net request Ride(on): on = true lifts the character onto its mount's back (Humanoid.HipHeight, from
  the size of Dino_<species> as big as on the defense track (player attribute RideSize), or made
  Config.Ride.MountHeight tall in a race, hide-and-seek or the default dino); off puts it down again. Player
  attributes Riding (MoveGuard moves them at Config.Ride.SpeedMultiplier × the walk speed), RideDrop (studs
  from the root part down to the mount's feet) and RideForward (how far the mount's middle is ahead of
  the root). Config.Ride.Cooldown between getting on and off.
  The mount itself is drawn by every client, outside the character (StarterPlayerScripts/Ride): inside
  it, the character's Animator put the dino's leg bones back to rest every frame.
- Which dino: profile Mount (a species), chosen at the mount pedestal behind the base's rebirth sign
  (prompt Kind "Mount", Net request SetMount(species, rarity, size)): the player picks one of the species ×
  rarity × size they own (profile MountRarity, MountSize), and every screen gives the mount that rarity's aura
  (Shared/RarityFx; player attribute MountRarity), like the dinos on the defense track (2026-10-01; the
  best one owned when the chosen one is gone, Common for the default dino not owned).
- Net request Roar: a rider's dino roars (at most every Config.Ride.RoarCooldown seconds); Net push
  RoarFx(userId) tells every screen to show it. Any species the player owns that walks
  (Formulas.rideable), or Config.Ride.DefaultSpecies which everyone may ride. Nothing registered
  (or the registered one is gone): Config.Ride.DefaultSpecies. Player attribute Mount
  is the species ridden now. The pedestal shows the base owner's mount as a statue.
- Flying mounts (Formulas.flies: the Sky species, Config.Ride.FlyThemes): player attribute Flying; the
  rider's own client flies the character (StarterPlayerScripts/Ride). The server gets them off above
  Config.Ride.FlyMaxHeight + FLY_HEIGHT_SLACK.
  (2026-10-04, "익룡타고 배틀필드도 날아보고 싶은데.. 날기만. … 익룡에서 내리면 바로 가장 가까운 곳으로 방출당하게 하자") they
  may fly over the battlefield, only to look (Shared/SafeZones.inSky: nothing there hits them, they do nothing there;
  their client keeps them Config.Ride.FieldMinHeight up), told once each time they fly in. Getting off over it, for
  any reason, puts them down at once on the ground Config.Ride.FieldDropOut outside the flags, straight out from where
  they were (MoveGuard.allow first). Carrying keys or racing, they are held back at the flags as before (inside
  anyway: off and put out).
- The clients (StarterPlayerScripts/Ride) have the button, the pedestal window, the rider's sitting
  pose and the dino's legs moving.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(ReplicatedStorage:WaitForChild("Config"))
local Formulas = require(Shared:WaitForChild("Formulas"))
local Net = require(Shared:WaitForChild("Net"))
local SafeZones = require(Shared:WaitForChild("SafeZones"))
local Bases = require(script.Parent:WaitForChild("Bases"))
local ServerMeter = require(script.Parent:WaitForChild("ServerMeter")) -- (2026-10-04: its loop timed, Watchdog)
local MoveGuard = require(script.Parent:WaitForChild("MoveGuard"))
local PlayerData = require(script.Parent:WaitForChild("PlayerData"))
local Unlocks = require(script.Parent:WaitForChild("Unlocks"))
local Rewards = require(script.Parent:WaitForChild("Rewards"))

local Ride = {}

-- display only
local SEAT_TO_ROOT = 1.2 -- a sitting character's root part is this far above what it sits on
local STATUE_HEIGHT = 5
local STATUE_LENGTH = 9
local PEDESTAL_BEHIND = 14
local PEDESTAL_RADIUS, PEDESTAL_HEIGHT = 4.5, 0.8
local PEDESTAL_COLOR = Color3.fromRGB(120, 200, 110)
local TITLE_COLOR = Color3.fromRGB(150, 235, 140)
local TITLE_OVER_STATUE = 3.5 -- studs between the statue's head and the name over it
-- (2026-10-02) the race practice prompts on the pedestal: kind -> { key, gamepad button, words }
-- (2026-10-02, "이거 겹쳐서 뭘 선택할 수가 없다": the three prompts on one spot were drawn on top of each other)
-- the practice one PROMPT_STEP pixels under "탈 공룡 고르기" (ProximityPrompt.UIOffset; each screen shows only one of
-- the two, StarterPlayerScripts/Ride)
local PRACTICE_PROMPTS = {
	{ "Road", Enum.KeyCode.Z, Enum.KeyCode.DPadLeft, "🏁 지상 레이스 기록전" },
	{ "Sky", Enum.KeyCode.X, Enum.KeyCode.DPadRight, "🦅 하늘 레이스 기록전" },
}
local PROMPT_STEP = 76 -- pixels: a prompt's height and a little gap
local PROMPT_HEIGHT = 3.5 -- studs over the pedestal where its "탈 공룡 고르기" prompt shows (not on the ground)
local CHECK_EVERY = 0.25 -- seconds between the checks that riders are still in the safe land
local STATUE_CHECK_EVERY = 1
local RANGE_SLACK = 4 -- the server allows a little more than the prompt's range (lag)
local FLY_HEIGHT_SLACK = 20 -- studs over Config.Ride.FlyMaxHeight before the server takes a flyer down
local STAND_UP = 3.5 -- studs over the ground a rider put down outside the battlefield stands (its root part)
local GROUND_LOOK_FROM = 12 -- studs up from where the ground there is looked for
local SKY_LINE = "🦅 들판 하늘 구경! 여기선 날기만 해요 · 내리면 밖으로 나가요"
local SKY_LINE_EVERY = 30 -- seconds
local DROP_LINE = "🦅 들판 밖에 내려 줬어요"

local riders = {} -- [player] = { character, hipHeight, sky (over the battlefield at the last check), skyToldAt }
local groundRay = RaycastParams.new()
groundRay.FilterType = Enum.RaycastFilterType.Exclude
groundRay.RespectCanCollide = true
local lastToggle = {} -- [player] = os.clock()
local lastRoar = {} -- [player] = os.clock()
local pedestals = {} -- [base number] = { part, statue, species }
local warned = false

local function say(player, text)
	Net.push(player, "Notice", "🦖 공룡 타기", text)
end

-- a copy of the species' model in a fresh model, its pivot the bottom middle, facing -Z, scaled to fit
-- height × length; a grey box without the model
local function dinoModel(species, height, length, drawn)
	local assets = ServerStorage:FindFirstChild("Assets")
	local source = assets and assets:FindFirstChild("Dino_" .. species, true)
	local model = Instance.new("Model")
	if source then
		source:Clone().Parent = model
	else
		if not warned then
			warned = true
			warn("[Ride] ServerStorage.Assets에 Dino_" .. species .. " 모델이 없어 상자로 보여줍니다")
		end
		local p = Instance.new("Part")
		p.Size = Vector3.new(2.4, 3, 5)
		p.Color = PEDESTAL_COLOR
		p.Parent = model
	end
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.CanCollide, d.CanQuery, d.CanTouch = false, false, false
		elseif d:IsA("Script") or d:IsA("LocalScript") or d:IsA("ProximityPrompt") then
			d:Destroy()
		end
	end
	local cf, size = model:GetBoundingBox()
	model.WorldPivot = CFrame.new(cf.Position - Vector3.new(0, size.Y / 2, 0))
	model:ScaleTo(drawn and Formulas.drawnScale(drawn)
		or math.min(height / math.max(size.Y, 0.1), length / math.max(size.X, size.Z, 0.1)))
	return model
end

local function owns(profile, species)
	for _, u in ipairs(profile.Units) do
		if u.Species == species then
			return true
		end
	end
	return false
end

-- the species this player registered at the pedestal, while it is still theirs to ride (the default
-- one always is); the default one when nothing is
local function registered(player)
	local profile = PlayerData.get(player)
	local chosen = profile and profile.Mount
	if chosen and chosen ~= "" and Formulas.rideable(chosen) and owns(profile, chosen) then
		return chosen
	end
	return profile and Config.Ride.DefaultSpecies or nil
end

-- the rarity the mount shows: the one chosen at the pedestal while the player still owns one of that
-- species and rarity, else the best they own of the species ("Common" when none)
local function mountRarity(profile, species)
	local best, bestRank, chosen = "Common", 0, profile and profile.MountRarity
	for _, u in ipairs(profile and profile.Units or {}) do
		if u.Species == species then
			if u.Rarity == chosen then
				return chosen
			end
			local rank = Formulas.rarityRank(u.Rarity)
			if rank > bestRank then
				best, bestRank = u.Rarity, rank
			end
		end
	end
	return best
end

local function mountSize(profile, species, rarity)
	local best, bestLook, chosen = nil, -math.huge, profile and profile.MountSize
	for _, u in ipairs(profile and profile.Units or {}) do
		if u.Species == species and u.Rarity == rarity then
			if u.Size == chosen then
				return chosen
			end
			local size = Formulas.dinoSize(u.Size)
			local look = size and (size.Look or size.Scale) or 0
			if look > bestLook then
				best, bestLook = u.Size, look
			end
		end
	end
	return best
end

local function showChoice(player, species)
	local profile = PlayerData.get(player)
	local rarity = species and mountRarity(profile, species) or nil
	player:SetAttribute("Mount", species or "")
	player:SetAttribute("MountRarity", rarity)
	player:SetAttribute("MountSize", rarity and mountSize(profile, species, rarity) or nil)
end

-- what the pedestal statue shows for this player
local function mountOf(player)
	return registered(player) or Config.Ride.DefaultSpecies
end

local function aliveParts(player)
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if humanoid and root and humanoid.Health > 0 then
		return character, humanoid, root
	end
	return nil
end

-- (2026-10-04) off a flying dino over the battlefield: on the ground just outside the flags, straight out from here,
-- facing away from the field
local function putOutside(player, character, root)
	local flat = Vector3.new(root.Position.X, 0, root.Position.Z)
	local out = flat.Magnitude > 1 and flat.Unit or Vector3.new(0, 0, -1)
	local spot = out * (Config.Battlefield.Radius + Config.Ride.FieldDropOut)
	local ignore = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Character then
			table.insert(ignore, p.Character)
		end
	end
	groundRay.FilterDescendantsInstances = ignore
	-- (looked for from a little up: on the ground under the race's finish arch, not on top of it)
	local hit = Workspace:Raycast(spot + Vector3.new(0, GROUND_LOOK_FROM, 0), Vector3.new(0, -GROUND_LOOK_FROM * 3, 0),
		groundRay)
	local at = Vector3.new(spot.X, (hit and hit.Position.Y or 0) + STAND_UP, spot.Z)
	MoveGuard.allow(player)
	character:PivotTo(CFrame.lookAt(at, at + out))
	root.AssemblyLinearVelocity = Vector3.zero
end

-- stay: the caller puts the player somewhere itself (hide-and-seek), so not put outside the battlefield
local function getOff(player, why, stay)
	local r = riders[player]
	if not r then
		return
	end
	local wasFlying = player:GetAttribute("Flying") == true
	riders[player] = nil
	MoveGuard.settle(player) -- dropping down, and the faster steps just before
	local character, humanoid, root = aliveParts(player)
	if humanoid then
		humanoid.HipHeight = r.hipHeight
	end
	player:SetAttribute("Riding", nil)
	player:SetAttribute("Flying", nil)
	player:SetAttribute("RideDrop", nil)
	player:SetAttribute("RideForward", nil)
	player:SetAttribute("RideSize", nil)
	MoveGuard.refresh(player)
	if wasFlying and root and not stay and not SafeZones.isSafe(root.Position) then
		putOutside(player, character, root)
		why = why or DROP_LINE
	end
	if why then
		say(player, why)
	end
end

local mountUp -- (below)

local function getOn(player)
	if riders[player] then
		return
	end
	local character, _, root = aliveParts(player)
	if not character or MoveGuard.stunned(player) then
		return
	end
	if not SafeZones.isSafe(root.Position) then
		say(player, "⚔️ 들판(깃발 안)에서는 탈 수 없어요")
		return
	end
	-- (2026-10-04, "배틀필드 밖에선 기본공룡 제공으로 그것만 탈 수 있게") in a hide-and-seek game everyone rides the same
	-- default dino (no flying, no faster or rarer one of their own), registered or not
	if player:GetAttribute("HideSeekRoom") then
		mountUp(player, Config.Ride.DefaultSpecies, "Common", true)
		say(player, "🙈 숨바꼭질 중엔 기본 공룡만 타요")
		return
	end
	local species = registered(player)
	if not species then
		say(player, "🦖 탈 공룡을 먼저 골라요! 🔄 환생 표지판 뒤 🦖 발판에서")
		return
	end
	mountUp(player, species, mountRarity(PlayerData.get(player), species))
	if Formulas.flies(species) then
		say(player, "🦅 날아요! 보는 쪽으로 날아가요 · 점프로 위로 · Shift나 아래를 보면 내려가요")
	end
end

local function fit(player)
	local r = riders[player]
	local _, humanoid, root = aliveParts(player)
	if not r or not humanoid then
		return
	end
	local sizeId = not r.fixed and player:GetAttribute("Racing") == nil and r.size or nil
	if r.drawn == (sizeId or false) then
		return
	end
	r.drawn = sizeId or false
	local c = Config.Ride
	local sizer = dinoModel(r.species, c.MountHeight, c.MountLength, sizeId and Formulas.dinoSize(sizeId))
	local _, size = sizer:GetBoundingBox()
	sizer:Destroy()
	local newHip = size.Y * c.BackHeight + SEAT_TO_ROOT - root.Size.Y / 2
	MoveGuard.loosen(player, Config.MoveGuard.CheckInterval * 2)
	humanoid.HipHeight = newHip
	player:SetAttribute("RideDrop", newHip + root.Size.Y / 2)
	player:SetAttribute("RideForward", c.SeatForward * math.max(size.X, size.Z))
	player:SetAttribute("RideSize", sizeId)
end

-- the rider on this species' back (the checks done by the caller)
mountUp = function(player, species, rarity, fixed)
	local character, humanoid = aliveParts(player)
	local size = not fixed and mountSize(PlayerData.get(player), species, rarity) or nil
	riders[player] = { character = character, hipHeight = humanoid.HipHeight, species = species, fixed = fixed, size = size }
	fit(player)
	player:SetAttribute("Mount", species)
	player:SetAttribute("MountRarity", rarity)
	player:SetAttribute("MountSize", size)
	local limited = false
	for _, u in ipairs((PlayerData.get(player) or {}).Units or {}) do
		limited = limited or (u.Limited == true and u.Species == species and u.Rarity == rarity)
	end
	player:SetAttribute("MountLimited", limited or nil)
	player:SetAttribute("Flying", Formulas.flies(species) or nil)
	player:SetAttribute("Riding", true)
	MoveGuard.refresh(player)
	Rewards.add(player, "Mount", 1) -- (2026-10-03: the tutorial field's 🦖 타기 step)
end

local function toggle(player, on)
	if player:GetAttribute("Watching") then -- (2026-10-04) a caught hider watches the hide-and-seek to its end
		say(player, "👀 숨바꼭질이 끝날 때까지 하늘에서 구경해요")
		return
	end
	-- (2026-10-04, "배틀필드 나가면 강제로 기본공룡 타고 못내리게. 배틀필드로 돌아오면 공룡 내리기") in a hide-and-seek game
	-- off the battlefield everyone rides the default dino (HideSeek puts them on it); back on the battlefield, off
	local _, _, root = aliveParts(player)
	if not on and riders[player] and player:GetAttribute("HideSeekRoom") and root and SafeZones.isSafe(root.Position) then
		say(player, "🙈 숨바꼭질 중엔 들판 밖에서 공룡에서 못 내려요")
		return
	end
	if lastToggle[player] and os.clock() - lastToggle[player] < Config.Ride.Cooldown then
		return
	end
	if on and not riders[player] and not Unlocks.check(player, "Ride") then
		return
	end
	lastToggle[player] = os.clock()
	if on then
		getOn(player)
	else
		getOff(player)
	end
end

local function register(player, species, rarity, size)
	local profile = PlayerData.get(player)
	if not profile then
		return false
	end
	if species ~= Config.Ride.DefaultSpecies and not (Formulas.rideable(species) and owns(profile, species)) then
		say(player, "탈 수 없는 공룡이에요")
		return false
	end
	PlayerData.update(player, function(p)
		p.Mount = species
		p.MountRarity = Formulas.rarity(rarity) and rarity or "" -- (mountRarity checks it is owned)
		p.MountSize = Formulas.dinoSize(size) and size or ""
	end)
	showChoice(player, species)
	say(player, string.format("🦖 %s 등록! 타기(R)로 불러서 타요", Formulas.species(species).Name))
	if riders[player] then -- on the new one at once
		getOff(player)
		getOn(player)
	end
	return true
end

local function setMount(player, species, rarity, size)
	if not Unlocks.check(player, "Ride") then
		return
	end
	local pedestal = pedestals[Bases.of(player)]
	if not PlayerData.get(player) or not pedestal then
		return
	end
	if not Bases.near(player, pedestal.model, Config.Ride.PedestalRange + RANGE_SLACK) then
		say(player, "🦖 환생 표지판 뒤 탈 공룡 발판에서 골라요")
		return
	end
	if register(player, species, rarity, size) then
		Rewards.add(player, "MountSet", 1)
	end
end

-- ---------------------------------------------------------------------------
-- The mount pedestal behind each base's rebirth sign
-- ---------------------------------------------------------------------------

local function makePedestal(index, folder)
	local rebirth = folder:FindFirstChild("RebirthSign")
	local board = rebirth and rebirth.PrimaryPart
	local zone = folder:FindFirstChild("SafeZone")
	local flat = zone and Vector3.new(zone.Position.X, 0, zone.Position.Z)
	if not board or not flat or flat.Magnitude < 1e-3 then
		warn(string.format("[Ride] Base%d에 환생 표지판이 없어 탈 공룡 발판을 못 놓았습니다", index))
		return nil
	end
	local out = flat.Unit
	local spot = Vector3.new(board.Position.X, zone.Position.Y, board.Position.Z) + out * PEDESTAL_BEHIND
	local spawn = folder:FindFirstChild("SpawnLocation", true)
	local toSpawn = spawn and Vector3.new(spawn.Position.X - spot.X, 0, spawn.Position.Z - spot.Z)
	local look = toSpawn and toSpawn.Magnitude > 1e-3 and toSpawn.Unit
		or Vector3.new(board.CFrame.LookVector.X, 0, board.CFrame.LookVector.Z).Unit
	local ground = Bases.groundBelow(spot, { zone })
	local model = Instance.new("Model")
	model.Name = "MountPedestal"
	local part = Instance.new("Part")
	part.Name = "Pedestal"
	part.Shape = Enum.PartType.Cylinder
	part.Size = Vector3.new(PEDESTAL_HEIGHT, PEDESTAL_RADIUS * 2, PEDESTAL_RADIUS * 2)
	part.CFrame = CFrame.new(spot.X, ground + PEDESTAL_HEIGHT / 2, spot.Z) * CFrame.Angles(0, 0, math.pi / 2)
	part.Anchored = true
	part.Material = Enum.Material.Plastic
	part.Color = PEDESTAL_COLOR
	part.TopSurface = Enum.SurfaceType.Studs
	part.Parent = model
	model.WorldPivot = CFrame.lookAt(Vector3.new(spot.X, ground, spot.Z), Vector3.new(spot.X, ground, spot.Z) + look)
	model.Parent = folder
	-- the name over the statue's head and the prompt at chest height, each on its own invisible part
	-- (the pedestal disc is only PEDESTAL_HEIGHT tall: on it they showed at the ground)
	local function anchor(name, at)
		local a = Instance.new("Part")
		a.Name = name
		a.Size = Vector3.one
		a.Transparency = 1
		a.Anchored, a.CanCollide, a.CanQuery, a.CanTouch = true, false, false, false
		a.CFrame = CFrame.new(at)
		a.Parent = model
		return a
	end
	local top = ground + PEDESTAL_HEIGHT
	local titleAnchor = anchor("TitleAnchor", Vector3.new(spot.X, top + STATUE_HEIGHT + TITLE_OVER_STATUE, spot.Z))
	Bases.title(titleAnchor, "🦖 탈 공룡", TITLE_COLOR, false, 0).Parent = model
	local promptAnchor = anchor("PromptAnchor", Vector3.new(spot.X, top + PROMPT_HEIGHT, spot.Z) + look * PEDESTAL_RADIUS)
	Bases.prompt(promptAnchor, "Mount", index, "탈 공룡 고르기", Config.Ride.PedestalRange)
	-- (2026-10-02, "연습은 오른쪽 창에 나오게 해줘 Pick a mount 처럼") the race practice, as prompts beside it; each
	-- screen shows only the one for its own base's mount (StarterPlayerScripts/Ride); Race checks the request
	for _, p in ipairs(PRACTICE_PROMPTS) do
		local prompt = Bases.prompt(promptAnchor, p[1] .. "Practice", index, p[4], Config.Ride.PedestalRange)
		if prompt then
			prompt.KeyboardKeyCode, prompt.GamepadKeyCode = p[2], p[3]
			prompt.UIOffset = Vector2.new(0, PROMPT_STEP)
			prompt:SetAttribute("Practice", p[1])
		end
	end
	return { model = model, top = Vector3.new(spot.X, ground + PEDESTAL_HEIGHT, spot.Z), look = look }
end

-- the base owner's mount standing on the pedestal (the default one while nobody has the base)
local function updateStatues()
	for index, p in pairs(pedestals) do
		local folder = Bases.folder(index)
		local owner = folder and Players:GetPlayerByUserId(folder:GetAttribute("OwnerUserId") or 0)
		local species = owner and mountOf(owner) or Config.Ride.DefaultSpecies
		local rarity = owner and mountRarity(PlayerData.get(owner), species) or "Common"
		if p.species ~= species or p.rarity ~= rarity or not (p.statue and p.statue.Parent) then
			if p.statue then
				p.statue:Destroy()
			end
			local statue = dinoModel(species, STATUE_HEIGHT, STATUE_LENGTH)
			statue.Name = "MountStatue"
			for _, d in ipairs(statue:GetDescendants()) do
				if d:IsA("BasePart") then
					d.Anchored = true
				end
			end
			statue:PivotTo(CFrame.lookAt(p.top, p.top + p.look))
			statue:SetAttribute("Rarity", rarity)
			statue.Parent = p.model
			p.statue, p.species, p.rarity = statue, species, rarity
		end
	end
end

function Ride.init()
	for index = 1, Config.Map.BaseCount do
		local folder = Bases.folder(index)
		if folder then
			local old = folder:FindFirstChild("MountPedestal")
			if old then
				old:Destroy()
			end
			pedestals[index] = makePedestal(index, folder)
		end
	end

	Net.onRequest("Ride", { "boolean" }, toggle)
	Net.onRequest("Roar", {}, function(player) -- the ridden dino roars, for everyone
		if riders[player] and os.clock() - (lastRoar[player] or -math.huge) >= Config.Ride.RoarCooldown then
			lastRoar[player] = os.clock()
			Net.pushAll("RoarFx", player.UserId)
		end
	end)
	Net.onRequest("SetMount", { "string", "string", "string" }, setMount)
	PlayerData.onLoaded(function(player)
		showChoice(player, registered(player)) -- "" = nothing registered yet
	end)
	Players.PlayerAdded:Connect(function(player)
		player:GetAttributeChangedSignal("Racing"):Connect(function()
			fit(player)
		end)
		player.CharacterRemoving:Connect(function()
			riders[player] = nil -- the mount goes with the character
			player:SetAttribute("Riding", nil)
			player:SetAttribute("Flying", nil)
			player:SetAttribute("Watching", nil)
		end)
	end)
	for _, player in ipairs(Players:GetPlayers()) do
		player:GetAttributeChangedSignal("Racing"):Connect(function()
			fit(player)
		end)
		player.CharacterRemoving:Connect(function()
			riders[player] = nil
			player:SetAttribute("Riding", nil)
			player:SetAttribute("Flying", nil)
		end)
	end
	Players.PlayerRemoving:Connect(function(player)
		riders[player] = nil
		lastToggle[player], lastRoar[player] = nil, nil
	end)

	local sinceCheck, sinceStatues = 0, STATUE_CHECK_EVERY
	RunService.Heartbeat:Connect(ServerMeter.wrap("Ride", function(dt)
		sinceCheck += dt
		sinceStatues += dt
		if sinceCheck >= CHECK_EVERY then
			sinceCheck = 0
			for player, r in pairs(riders) do
				local _, _, root = aliveParts(player)
				local sky = root ~= nil and SafeZones.inSky(player, root.Position)
				if not root or not r.character.Parent then
					riders[player] = nil
					player:SetAttribute("Riding", nil)
					player:SetAttribute("Flying", nil)
				elseif not SafeZones.isSafe(root.Position) and not sky then
					getOff(player, "⚔️ 들판에 들어와서 공룡에서 내렸어요")
				elseif sky and ((player:GetAttribute("CarriedKeys") or 0) > 0 or player:GetAttribute("Racing") ~= nil) then
					getOff(player) -- (their own screen holds these back at the flags) put down outside
				elseif player:GetAttribute("Flying") and root.Position.Y > Config.Ride.FlyMaxHeight + FLY_HEIGHT_SLACK then
					getOff(player, "🦅 너무 높이 올라가서 공룡에서 내렸어요")
				elseif MoveGuard.stunned(player) then
					getOff(player)
				else
					-- (each time they fly in over the battlefield, at most every SKY_LINE_EVERY seconds)
					if sky and not r.sky and os.clock() - (r.skyToldAt or -math.huge) >= SKY_LINE_EVERY then
						r.skyToldAt = os.clock()
						say(player, SKY_LINE)
					end
					r.sky = sky
				end
			end
		end
		if sinceStatues >= STATUE_CHECK_EVERY then
			sinceStatues = 0
			updateStatues()
		end
	end))
end

-- (2026-10-02) for the race practice (Race service): the registered mount (nil if none), and getting on it
Ride.registered = registered
Ride.register = register
Ride.getOn = getOn
Ride.getOff = getOff -- (2026-10-02: a wild dino throwing a rider off, Wildlife)
Ride.fit = fit

-- (2026-10-04, "숨바꼭질 끝나고 원래 본인이 타고 있던 공룡을 되돌려주기도 하고") after a hide-and-seek game (HideSeek): the
-- player's own mount shown again (the game's default one was), and with ride, on its back again; true when they are
-- on it now (false: not alive, stunned, on the battlefield, nothing registered)
function Ride.giveBack(player, ride)
	local species = registered(player)
	if not riders[player] then
		showChoice(player, species)
	end
	if not ride then
		return false
	end
	local character, _, root = aliveParts(player)
	if riders[player] or not species or not character or MoveGuard.stunned(player) or not SafeZones.isSafe(root.Position) then
		return false
	end
	mountUp(player, species, mountRarity(PlayerData.get(player), species))
	return true
end

-- (2026-10-04) hide-and-seek off the battlefield (HideSeek): on the default dino, whatever was chosen; false when it
-- can't now (not alive, stunned, already on one, on the battlefield)
function Ride.mountDefault(player)
	local character, _, root = aliveParts(player)
	if riders[player] or not character or MoveGuard.stunned(player) or not SafeZones.isSafe(root.Position) then
		return false
	end
	mountUp(player, Config.Ride.DefaultSpecies, "Common", true)
	return true
end

-- (2026-10-04, "술래잡기가 다인이면 잡힌 사람은 관전자용 익룡 타고 배틀필드 공중에서 끝날때까지 구경하게") a caught
-- hider on a spectator flying dino (HideSeek): this species whether owned or not, lifted up to `height` studs over the
-- map's floor where they are (over the battlefield: Shared/SafeZones.inSky, only looking). Player attribute Watching
-- (their screen keeps them over the battlefield; they can't get off). Ride.unwatch: off, the registered mount back.
function Ride.watch(player, species, height)
	local character, _, root = aliveParts(player)
	if not character or riders[player] then
		return false
	end
	player:SetAttribute("Watching", true)
	mountUp(player, species, "Common", true)
	MoveGuard.allow(player)
	character:PivotTo(CFrame.new(root.Position.X, height + (player:GetAttribute("RideDrop") or 0), root.Position.Z)
		* character:GetPivot().Rotation)
	root.AssemblyLinearVelocity = Vector3.zero
	return true
end

-- stay: the caller puts them somewhere itself (else put down outside the battlefield)
function Ride.unwatch(player, stay)
	player:SetAttribute("Watching", nil)
	getOff(player, nil, stay)
	if player.Parent then
		showChoice(player, registered(player))
	end
end

-- (2026-10-02) at their own base's mount pedestal? (the practice is started from its prompts; anywhere else it
-- would be a free trip to the race track, out of the battlefield with keys)
function Ride.nearPedestal(player)
	local pedestal = pedestals[Bases.of(player)]
	return pedestal ~= nil and Bases.near(player, pedestal.model, Config.Ride.PedestalRange + RANGE_SLACK)
end

return Ride
