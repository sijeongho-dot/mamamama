--[[
ZombieLogic: the zombie dinos' rules, without Roblox (tested by tools/tests/zombie_logic_test.lua; the
Zombies service runs it and shows the result).

Positions are flat (x, z) around the map's center. Each zombie has a home spot; the homes are spread
evenly over the battlefield (a sunflower pattern between PlazaRadius and the flags). They never go
into the middle (PlazaRadius: the key altar fight stays between players) or past the flags.

States: "Under" (in the ground, by day) -> "Rising" (crawling out, RiseSeconds) -> "Up" -> "Sinking"
(back into the ground at dawn, SinkSeconds) -> "Under".
Up, a zombie wanders around its home (a random spot within HomeRadius, a pause, another). A player
within AggroRange draws it: it chases at ChaseSpeed and, within HitRange, hits (at most every
HitCooldown seconds; the service throws the player like a slap). A target farther than LoseRange, or
no longer valid (safe, thrown, gone), is dropped: the zombie walks back to wander around its home.

	local zs = ZombieLogic.new(ZombieLogic.homes(count, inner, outer, seed))
	zs[1].params = { ChaseSpeed = 11, HitRange = 9 }  -- a zombie with its own numbers (the boss)
	ZombieLogic.setNight(zs, true, now, random)       -- they start crawling out
	ZombieLogic.defeat(zs[1], now)                    -- slapped down: back under until the next night
	ZombieLogic.knock(zs[2], dx, dz, now)             -- slapped: thrown away (dx, dz a direction), dizzy a while
	local hits = ZombieLogic.step(zs, dt, players, now, random) -- players: { { id, x, z, y?, carrying? } }
	-- hits: { { zombie index, player id } }

Height and the ground (2026-10-01, "고도 상관없이 공격 가능하고 지형지물 통과하는 듯", "크리스탈 위에 있다면
점프해서 올라 쫓아가게", "끼는 상황이 없도록 최적 경로"): with a world set (ZombieLogic.setWorld; the
service's: world.surface(z, x, zz) = the height of what stands at (x, zz), from above), each zombie has
a height z.y. Walking, a step more than StepHeight up is blocked (a crystal, a rock, a tree: it goes
round, it does not hop over), any step down is fine. A blocked step tries turning aside (45°, 90°,
135° either way) and marks z.blocked (the service looks for a path round). A chasing zombie follows
z.path ({ { x, z }, ... }: the service's path to its target) waypoint by waypoint when it has one, else
goes straight. A hit needs the target's feet (y) within HitHeight of the zombie's. A target holding out
up on something (more than StepHeight and at most JumpUpHeight above, within JumpReach across) is
jumped after (2026-10-01, "위에서 버티면 점프해서 위로 쫓아가게, 지형 이용해서 버티기 못하게"): it lands
beside them at their height, JumpSeconds in the air, again after JumpCooldown. Higher than that, it
waits below. Without a world (the tests) everything is flat as before.
]]

local Config = if game then require(game:GetService("ReplicatedStorage"):WaitForChild("Config")) else CONFIG

local ZombieLogic = {}

local GOLDEN = math.pi * (3 - math.sqrt(5)) -- the sunflower's turn between neighbours
local TURNS = { math.pi / 4, -math.pi / 4, math.pi / 2, -math.pi / 2, 3 * math.pi / 4, -3 * math.pi / 4 } -- blocked: try these
local WAYPOINT_REACH = 2 -- studs: a path waypoint this near counts as reached
local JUMP_LAND_BACK = 1 -- studs: it lands this far short of the target, on its side
local STANDING_SLACK = 1.5 -- studs: a target's feet this near the top under it stand on it

local world = nil -- { surface = function(z, x, zz) -> height } (the service's), nil: flat
function ZombieLogic.setWorld(w)
	world = w
end

-- count home spots spread evenly between radius inner and outer (a sunflower pattern, turned by seed)
function ZombieLogic.homes(count, inner, outer, seed)
	local list = {}
	for i = 0, count - 1 do
		local r = math.sqrt(inner * inner + (i + 0.5) / count * (outer * outer - inner * inner))
		local a = i * GOLDEN + (seed or 0)
		table.insert(list, { x = math.cos(a) * r, z = math.sin(a) * r })
	end
	return list
end

function ZombieLogic.new(homes)
	local zombies = {}
	for i, h in ipairs(homes) do
		zombies[i] = { x = h.x, z = h.z, homeX = h.x, homeZ = h.z, heading = 0, state = "Under", stateAt = 0,
			wakeAt = nil, target = nil, wanderX = nil, wanderZ = nil, pauseUntil = 0, nextHit = 0, moving = false }
	end
	return zombies
end

-- night falls (they crawl out, each after a short random wait) or day breaks (they sink back)
function ZombieLogic.setNight(zombies, night, now, random)
	local c = Config.Zombies
	for _, z in ipairs(zombies) do
		if z.thief or z.guardian then
			continue
		elseif night and (z.state == "Under" or z.state == "Sinking") then
			z.state, z.stateAt = "Waiting", now
			z.wakeAt = now + random() * c.RiseSpread
			z.x, z.z, z.target, z.wanderX = z.homeX, z.homeZ, nil, nil
			z.y, z.path, z.blocked = nil, nil, false -- (the service sets its height at its home)
		elseif not night and (z.state == "Up" or z.state == "Rising" or z.state == "Waiting") then
			z.state, z.stateAt, z.target, z.moving = "Sinking", now, nil, false
		end
	end
end

-- slapped down (the boss): it sinks into the ground now and stays under until the next night
function ZombieLogic.defeat(z, now)
	z.state, z.stateAt, z.target, z.moving, z.wanderX = "Sinking", now, nil, false, nil
end

-- keep a spot out of the middle (the key altar's plaza) and inside the flags
local function clamp(z)
	local r = math.sqrt(z.x * z.x + z.z * z.z)
	local outer = Config.Battlefield.Radius - ZombieLogic.param(z, "EdgeMargin")
	local inner = z.params and z.params.PlazaRadius or Config.Zombies.PlazaRadius -- (the key thieves go into the plaza)
	if r > outer then
		z.x, z.z = z.x / r * outer, z.z / r * outer
	elseif r < inner and r > 0 then
		z.x, z.z = z.x / r * inner, z.z / r * inner
	end
end

-- a player's slap: thrown SlapKnockback studs along (dx, dz), then dizzy; it forgets its target
function ZombieLogic.knock(z, dx, dz, now)
	local d = math.sqrt(dx * dx + dz * dz)
	if d < 1e-3 then
		dx, dz, d = 1, 0, 1
	end
	local fromX, fromZ = z.x, z.z
	local throw = ZombieLogic.param(z, "SlapKnockback")
	-- (2026-10-01) thrown onto anything, but never into something too tall: a shorter throw then
	for _, share in ipairs({ 1, 0.6, 0.3, 0 }) do
		z.x, z.z = fromX + dx / d * throw * share, fromZ + dz / d * throw * share
		clamp(z)
		if not world or share == 0 then -- (share 0: nowhere to land, it stays where it was)
			break
		end
		local top = world.surface(z, z.x, z.z)
		if top < math.huge and (not z.y or top - z.y <= ZombieLogic.param(z, "StepHeight")) then
			z.y = top
			break
		end
	end
	z.target, z.wanderX, z.moving = nil, nil, false
	z.stunUntil = now + ZombieLogic.param(z, "SlapFlightSeconds") + ZombieLogic.param(z, "SlapStunSeconds")
end

-- a zombie's own number (the boss has its own, z.params) or the common one
local function param(z, key)
	local own = z.params and z.params[key]
	if own ~= nil then
		return own
	end
	return Config.Zombies[key]
end
ZombieLogic.param = param


local function distance(ax, az, bx, bz)
	return math.sqrt((ax - bx) ^ 2 + (az - bz) ^ 2)
end

-- move toward (tx, tz) at speed for dt; true when there
local function moveToward(z, tx, tz, speed, dt, straightOnly)
	local dx, dz = tx - z.x, tz - z.z
	local d = math.sqrt(dx * dx + dz * dz)
	if z.rooted then -- held in place by a poop bomb: turns to face it, doesn't move
		z.heading = d > 0.05 and math.atan2(dx, dz) or z.heading
		z.moving = false
		return false
	end
	if d < 0.05 then
		z.moving = false
		return true
	end
	z.wantMove = true -- (a thief that keeps wanting to and gets nowhere is stuck: thiefStep)
	local stepLength = math.min(d, speed * dt)
	local ux, uz = dx / d, dz / d
	if world then -- (2026-10-01) too tall ahead: turn aside, else stand and wait for a path
		local turned = false
		local function fits(ax, az)
			local nx, nz = z.x + ax * stepLength, z.z + az * stepLength
			local top = world.surface(z, nx, nz)
			if top < math.huge and (z.y == nil or top - z.y <= param(z, "StepHeight")) then
				return top
			end
			return nil
		end
		local top = fits(ux, uz)
		if not top and not straightOnly then
			for _, turn in ipairs(TURNS) do
				local cs, sn = math.cos(turn), math.sin(turn)
				local ax, az = ux * cs - uz * sn, ux * sn + uz * cs
				top = fits(ax, az)
				if top then
					ux, uz, turned = ax, az, true
					break
				end
			end
		end
		z.blocked = z.blocked or turned or top == nil
		if not top then
			z.moving = false
			return false
		end
		z.y = top
	end
	z.x += ux * stepLength
	z.z += uz * stepLength
	z.heading = math.atan2(ux, uz)
	z.moving = true
	clamp(z) -- never past the flags, never into the middle (the key altar's plaza)
	return stepLength >= d
end

-- toward a chased target: along z.path's waypoints when there are some, else straight
local function chase(z, tx, tz, speed, dt)
	local path = z.path
	while path and path[1] and distance(z.x, z.z, path[1][1], path[1][2]) <= WAYPOINT_REACH do
		table.remove(path, 1)
	end
	if path and path[1] then
		moveToward(z, path[1][1], path[1][2], speed, dt)
	else
		moveToward(z, tx, tz, speed, dt)
	end
end

local function findPlayer(players, id)
	for _, p in ipairs(players) do
		if p.id == id then
			return p
		end
	end
	return nil
end

-- wandering round its home: a random spot within its HomeRadius, a pause, another
local function wander(z, dt, now, random)
	if now < z.pauseUntil then
		z.moving = false
		return
	end
	if not z.wanderX then
		local a, r = random() * 2 * math.pi, math.sqrt(random()) * (z.homeRadius or param(z, "HomeRadius"))
		z.wanderX, z.wanderZ = z.homeX + math.cos(a) * r, z.homeZ + math.sin(a) * r
	end
	local arrived = moveToward(z, z.wanderX, z.wanderZ, param(z, "WanderSpeed"), dt)
	if not arrived and not z.moving then -- (blocked all round: somewhere else next)
		z.wanderX = nil
		z.blocked = false
	end
	if arrived then
		z.wanderX = nil
		local pause = param(z, "PauseSeconds")
		z.pauseUntil = now + pause[1] + random() * (pause[2] - pause[1])
		z.moving = false
	end
end

-- (2026-10-04, "열쇠도둑 좋아졌는데 지형지물에 끼지 않으면 좋겠는데. 그리고 더 잘 튀고") a thief looks ahead before it
-- runs: how far it can go each way (up to WAY_LOOK studs, WAY_STEP at a time: nothing too tall to step on, inside the
-- flags, out of the plaza), and it takes the way nearest the one it wants with the most room (WAY_TURNS off it), kept
-- WAY_KEEP seconds (no dithering). Running from a player, a tree or the flags ahead turns it aside early, not into them
local WAY_LOOK, WAY_STEP = 12, 3
local WAY_TURNS = { 0, 0.45, -0.45, 0.9, -0.9, 1.35, -1.35, 1.9, -1.9, 2.5, -2.5 } -- radians
local WAY_KEEP = 0.35
local WAY_ROOM = 1.5 -- how much the room ahead counts against keeping to the wanted way
local WAY_STICK = 1.2 -- going round something, how much keeping to the way it took counts (one side, no ping-pong)
local WAY_BACK = -0.75 -- going round something, the way it took is kept while no more off the wanted one than this (cos)
local WAY_BLOCKED = 10
local WAY_OPEN = 6
local function freeAhead(z, ux, uz)
	local outer = Config.Battlefield.Radius - param(z, "EdgeMargin")
	local inner = param(z, "PlazaRadius") or Config.Zombies.PlazaRadius
	local y, free = z.y, 0
	for d = WAY_STEP, WAY_LOOK, WAY_STEP do
		local x, zz = z.x + ux * d, z.z + uz * d
		local r = math.sqrt(x * x + zz * zz)
		if r > outer or r < inner then
			break
		end
		if world then
			local top = world.surface(z, x, zz)
			if top == math.huge or (y and top - y > param(z, "StepHeight")) then
				break
			end
			y = top
		end
		free = d
	end
	return free
end

-- go the way (wantX, wantZ) at speed; to a spot `far` studs off (a key, the altar's ring) it goes straight when the way
-- there is clear, else round
local FLEE_AHEAD = 10
local function goWay(z, wantX, wantZ, speed, dt, now, far)
	local l = math.sqrt(wantX * wantX + wantZ * wantZ)
	if l < 1e-3 then
		wantX, wantZ, l = 1, 0, 1
	end
	wantX, wantZ = wantX / l, wantZ / l
	if far and freeAhead(z, wantX, wantZ) >= math.min(far, WAY_LOOK) - WAY_STEP then
		z.way, z.waySide = nil, nil
		moveToward(z, z.x + wantX * far, z.z + wantZ * far, speed, dt)
		return
	end
	local base = math.atan2(wantX, wantZ)
	if freeAhead(z, wantX, wantZ) >= WAY_LOOK then
		z.way, z.wayUntil, z.waySide = base, now, nil
	else
		local before = z.way
		local keep = before and now < (z.wayUntil or 0) and math.cos(before - base) > WAY_BACK
			and freeAhead(z, math.sin(before), math.cos(before)) >= WAY_STEP
		if not keep then
			local best, bestScore, bestOff, bestRoom = base, -math.huge, 0, 0
			local function try(a, off)
				local room = freeAhead(z, math.sin(a), math.cos(a))
				local score = math.cos(a - base) + WAY_ROOM * room / WAY_LOOK
					+ (before and WAY_STICK * math.cos(a - before) or 0) - (room < WAY_STEP and WAY_BLOCKED or 0)
				if score > bestScore then
					best, bestScore, bestOff, bestRoom = a, score, off, room
				end
			end
			for _, off in ipairs(WAY_TURNS) do
				if not z.waySide or off * z.waySide >= 0 then
					try(base + off, off)
				end
			end
			if before and math.cos(before - base) > WAY_BACK then
				try(before, 0)
			end
			if bestRoom < WAY_OPEN then
				best, bestOff = base, 0
			end
			if bestOff ~= 0 then
				z.waySide = bestOff > 0 and 1 or -1
			end
			z.way, z.wayUntil = best, now + WAY_KEEP
		end
	end
	local step = far and math.min(far, FLEE_AHEAD) or FLEE_AHEAD
	moveToward(z, z.x + math.sin(z.way) * step, z.z + math.cos(z.way) * step, speed, dt)
end

-- running away from (fx, fz) at speed (the way with room, see goWay; the flags and the plaza keep it in); turn: radians
-- off straight away (a zigzag)
local function flee(z, fx, fz, speed, dt, turn, now)
	local dx, dz = z.x - fx, z.z - fz
	local d = math.sqrt(dx * dx + dz * dz)
	if d < 1e-3 then
		dx, dz, d = 1, 0, 1
	end
	dx, dz = dx / d, dz / d
	if turn then
		local cs, sn = math.cos(turn), math.sin(turn)
		dx, dz = dx * cs - dz * sn, dx * sn + dz * cs
	end
	z.wanderX = nil
	goWay(z, dx, dz, speed, dt, now or 0)
end

-- (2026-10-04, "도둑공룡들이 키들고 유저랑 제일 멀어지도록 계산해서 움직이도록 해", "도둑공룡들은 배틀필드 내 유저 위치를 모두
-- 파악한다. 그래서 더똑똑하게 도망친다. 어디에 있든 배틀필드 내에 있다면(익룡 타기로 온 것 제외)") the way out, from
-- every player on the battlefield wherever they are (the list the service gives: on the battlefield, not flying over
-- it): of ESCAPE_WAYS ways round, the one whose spot EscapeLook studs ahead is the least in danger, each player
-- counting 1 / distance² from that spot (the near ones far the most, the far ones still: two players from two sides,
-- out between them, not into the other; a crowd on one side, away from it); the flags and the plaza count as a player
-- standing EscapeEdge studs beyond their nearest point (no running into a corner); the way it took a little less
-- (no dithering)
local ESCAPE_WAYS = 16
local ESCAPE_KEEP = 0.15 -- the way it took is that share less in danger
local ESCAPE_NEAREST = 5 -- studs: closer counts as this close
local function escapeWay(z, players)
	if #players == 0 then
		return nil
	end
	local look = param(z, "EscapeLook")
	local outer = Config.Battlefield.Radius - param(z, "EdgeMargin")
	local inner = param(z, "PlazaRadius") or Config.Zombies.PlazaRadius
	local wall = param(z, "EscapeEdge") -- the flags and the plaza weigh like a player this much farther off than they are
	local best, bestDanger = nil, math.huge
	for i = 0, ESCAPE_WAYS - 1 do
		local a = i / ESCAPE_WAYS * 2 * math.pi
		local x, zz = z.x + math.sin(a) * look, z.z + math.cos(a) * look
		local danger = 0
		for _, p in ipairs(players) do
			danger += 1 / math.max(ESCAPE_NEAREST, distance(x, zz, p.x, p.z)) ^ 2
		end
		local r = math.sqrt(x * x + zz * zz)
		danger += 1 / math.max(ESCAPE_NEAREST, outer - r + wall) ^ 2 + 1 / math.max(ESCAPE_NEAREST, r - inner + wall) ^ 2
		if r > outer or r < inner then
			danger *= 4 -- (out of its ground: only when nothing else is open)
		end
		if z.escapeAngle and math.cos(a - z.escapeAngle) > 0.9 then
			danger *= 1 - ESCAPE_KEEP
		end
		if danger < bestDanger then
			best, bestDanger = a, danger
		end
	end
	z.escapeAngle = best
	return math.sin(best), math.cos(best)
end

local function runOff(z, index, nearest, dt, now, players)
	local turn = math.rad(param(z, "JukeAngle")) * math.sin(now * param(z, "JukeSpeed") + index)
	local ux, uz = escapeWay(z, players or { nearest })
	if not ux then
		flee(z, nearest.x, nearest.z, param(z, "FleeSpeed"), dt, turn, now)
		return
	end
	flee(z, z.x - ux, z.z - uz, param(z, "FleeSpeed"), dt, turn, now)
end

local function thiefMove(z, index, dt, players, now, random)
	local nearest, nearestD = nil, math.huge
	for _, p in ipairs(players) do
		local d = distance(z.x, z.z, p.x, p.z)
		if d < nearestD then
			nearest, nearestD = p, d
		end
	end
	if z.escapeUntil and now >= z.escapeUntil then
		z.state, z.stateAt, z.target, z.moving, z.wanderX = "Sinking", now, nil, false, nil
		z.escaped = true
	elseif nearest and nearestD <= param(z, "LoseRange") then
		runOff(z, index, nearest, dt, now, players)
	else
		z.pauseUntil = 0
		wander(z, dt, now, random)
		z.pauseUntil = 0
	end
end

local function guardMove(z, index, dt, players, now, random, hits, claims)
	local target = z.target and findPlayer(players, z.target)
	if target and ((target.carrying or 0) <= 0 or distance(z.x, z.z, target.x, target.z) > param(z, "LoseRange")
		or (claims[target.id] ~= nil and claims[target.id] ~= z)) then
		target = nil
	end
	if not target then
		local bestD = param(z, "AggroRange")
		for _, p in ipairs(players) do
			local d = distance(z.x, z.z, p.x, p.z)
			if (p.carrying or 0) > 0 and d <= bestD and claims[p.id] == nil then
				target, bestD = p, d
			end
		end
		if target then
			z.reactUntil = now + param(z, "ReactSeconds")
		end
	end
	if target then
		claims[target.id] = z
	end
	z.target = target and target.id or nil
	if target then
		z.wanderX = nil
		local d = distance(z.x, z.z, target.x, target.z)
		if now < (z.reactUntil or 0) then
			z.moving = false
			z.heading = math.atan2(target.x - z.x, target.z - z.z)
		elseif d <= param(z, "HitRange") then
			z.moving = false
			z.heading = math.atan2(target.x - z.x, target.z - z.z)
			if now >= z.nextHit then
				z.nextHit = now + param(z, "HitCooldown")
				table.insert(hits, { index, target.id })
				z.target = nil
			end
		else
			chase(z, target.x, target.z, target.guardSpeed or param(z, "ChaseBase"), dt)
		end
		return
	end
	local away = distance(z.x, z.z, z.homeX, z.homeZ)
	if away > param(z, "HomeRadius") * 2 then
		z.wanderX = nil
		goWay(z, z.homeX - z.x, z.homeZ - z.z, param(z, "ReturnSpeed"), dt, now, away)
	else
		wander(z, dt, now, random)
	end
end

local STUCK_MOVE = 3
local function thiefStep(z, index, dt, players, now, random, hits, claims)
	z.wantMove = false
	if z.guardian then
		guardMove(z, index, dt, players, now, random, hits, claims)
	else
		thiefMove(z, index, dt, players, now, random)
	end
	if z.wantMove and z.state == "Up" and z.stuckX and distance(z.x, z.z, z.stuckX, z.stuckZ) < STUCK_MOVE then
		z.stuckFor = (z.stuckFor or 0) + dt
	else
		z.stuckX, z.stuckZ, z.stuckFor = z.x, z.z, 0
	end
end

function ZombieLogic.step(zombies, dt, players, now, random)
	local c = Config.Zombies
	local hits = {}
	local claims = {}
	for _, z in ipairs(zombies) do
		if z.guardian and z.state == "Up" and z.target and claims[z.target] == nil then
			claims[z.target] = z
		end
	end
	for index, z in ipairs(zombies) do
		z.rooted = z.rootUntil ~= nil and now < z.rootUntil -- (a poop bomb: no moving, hitting is fine)
		if z.state == "Waiting" and now >= z.wakeAt then
			z.state, z.stateAt = "Rising", now
		elseif z.state == "Rising" and now - z.stateAt >= param(z, "RiseSeconds") then
			z.state, z.stateAt = "Up", now
		elseif z.state == "Sinking" and now - z.stateAt >= param(z, "SinkSeconds") then
			z.state, z.stateAt = "Under", now
		elseif z.state == "Up" and z.stunUntil and now < z.stunUntil then
			z.moving, z.target = false, nil -- thrown by a slap: flying, then dizzy
		elseif z.state == "Up" and z.jumpUntil and now < z.jumpUntil then
			z.moving = false -- in the air, jumping up after someone
		elseif z.state == "Up" and (z.thief or z.guardian) then
			thiefStep(z, index, dt, players, now, random, hits, claims)
		elseif z.state == "Up" then
			-- keep the target while it is valid and near enough, else the nearest player in aggro range;
			-- (2026-10-01) someone else coming RetargetMargin studs nearer than the target takes its place
			local target = z.target and findPlayer(players, z.target)
			local targetD = target and distance(z.x, z.z, target.x, target.z)
			if target and targetD > param(z, "LoseRange") then
				target, targetD = nil, nil
			end
			local best, bestD = nil, param(z, "AggroRange")
			for _, p in ipairs(players) do
				local d = distance(z.x, z.z, p.x, p.z)
				if d <= bestD then
					best, bestD = p, d
				end
			end
			if not target or (best and best ~= target and bestD < targetD - c.RetargetMargin) then
				target = best
			end
			z.target = target and target.id or nil
			if target then
				z.wanderX = nil
				local up = (target.y and z.y) and target.y - z.y or 0
				local dy = math.abs(up)
				local across = distance(z.x, z.z, target.x, target.z)
				local near = across <= param(z, "HitRange")
				if up > param(z, "StepHeight") and up <= param(z, "JumpUpHeight") and across <= param(z, "JumpReach")
					and now >= (z.nextJump or 0) and not z.rooted and (dy > param(z, "HitHeight") or not near)
					and world and math.abs(world.surface(z, target.x, target.z) - target.y) <= STANDING_SLACK then
					-- (standing on it: a player in the middle of a jump is not jumped after)
					-- holding out up there: it jumps up beside them
					local back = math.min(across, JUMP_LAND_BACK)
					local ux, uz = 0, 0
					if across > 1e-3 then
						ux, uz = (z.x - target.x) / across, (z.z - target.z) / across
					end
					z.heading = math.atan2(target.x - z.x, target.z - z.z)
					z.x, z.z, z.y = target.x + ux * back, target.z + uz * back, target.y
					clamp(z)
					z.jumpUntil = now + param(z, "JumpSeconds")
					z.nextJump = now + param(z, "JumpCooldown")
					z.path, z.blocked, z.moving = nil, false, false
				elseif near and dy > param(z, "HitHeight") then
					-- right by but out of reach (too high to jump, or the jump not ready yet): it waits
					-- below, facing them (straight only: no circling round what they stand on)
					moveToward(z, target.x, target.z, param(z, "ChaseSpeed"), dt, true)
					z.heading = math.atan2(target.x - z.x, target.z - z.z)
				elseif near then
					z.moving = false
					z.heading = math.atan2(target.x - z.x, target.z - z.z)
					if now >= z.nextHit then
						z.nextHit = now + param(z, "HitCooldown")
						table.insert(hits, { index, target.id })
						z.target = nil -- thrown away: it looks for someone else (or goes home)
					end
				else
					chase(z, target.x, target.z, param(z, "ChaseSpeed"), dt)
				end
			else
				wander(z, dt, now, random)
			end
		end
	end
	return hits
end

return ZombieLogic
