--[[
RaceRoomLogic: the rules of the 🏁 race rooms (2026-10-04, "레이스도 방 열수 있게 하자 술래잡기처럼"), without Roblox:
the rooms, who is in which, ready, and when one can start. The Race service races them (Race.lua);
tools/tests/race_room_test.lua tests this.

A room: { Id, Host (userId), Members (userIds in joining order), Ready ([userId] = true), Phase ("Waiting" | "Racing"),
Kind ("Road": 🏁 on walking dinos | "Sky": 🦅 on flying ones), Ranked (true = 🏆 랭킹전: the records are saved and the wins
count in the week's ranking; false = 🎈 일반전), Stake (a ranked room's Config.Ranked.Stake.Grades Id, the host's pick) }.
]]

local Config = if game then require(game:GetService("ReplicatedStorage"):WaitForChild("Config")) else CONFIG
local C = Config.Race.Rooms

local RaceRoomLogic = {}

function RaceRoomLogic.new()
	return { Rooms = {}, NextId = 1, RoomOf = {} } -- RoomOf: [userId] = room
end

function RaceRoomLogic.roomOf(state, userId)
	return state.RoomOf[userId]
end

local function count(state)
	local n = 0
	for _ in pairs(state.Rooms) do
		n += 1
	end
	return n
end

local function stakeKnown(stake)
	for _, g in ipairs(Config.Ranked.Stake.Grades) do
		if g.Id == stake then
			return true
		end
	end
	return false
end

-- open a room of that kind with this player in it: the room, or nil and why
function RaceRoomLogic.create(state, userId, kind, ranked, stake)
	if kind ~= "Road" and kind ~= "Sky" then
		return nil, "없는 방이에요"
	elseif ranked == true and not stakeKnown(stake) then
		return nil, "없는 방이에요"
	elseif state.RoomOf[userId] then
		return nil, "이미 방에 있어요"
	elseif count(state) >= C.MaxRooms then
		return nil, "🚪 방이 가득 찼어요. 다른 방에 들어가요"
	end
	local room = { Id = state.NextId, Host = userId, Members = { userId }, Ready = {}, Phase = "Waiting", Kind = kind,
		Ranked = ranked == true, Stake = ranked == true and stake or nil }
	state.NextId += 1
	state.Rooms[room.Id] = room
	state.RoomOf[userId] = room
	return room
end

function RaceRoomLogic.join(state, userId, roomId)
	local room = state.Rooms[roomId]
	if state.RoomOf[userId] then
		return nil, "이미 방에 있어요"
	elseif not room then
		return nil, "없는 방이에요"
	elseif room.Phase ~= "Waiting" then
		return nil, "이미 시작한 방이에요"
	elseif #room.Members >= C.MaxPlayers then
		return nil, "방이 꽉 찼어요"
	end
	table.insert(room.Members, userId)
	state.RoomOf[userId] = room
	return room
end

-- out of their room: the room it left (an empty room goes)
function RaceRoomLogic.leave(state, userId)
	local room = state.RoomOf[userId]
	if not room then
		return nil
	end
	state.RoomOf[userId] = nil
	local i = table.find(room.Members, userId)
	if i then
		table.remove(room.Members, i)
	end
	room.Ready[userId] = nil
	if room.Host == userId then
		room.Host = room.Members[1]
	end
	if #room.Members == 0 then
		state.Rooms[room.Id] = nil
	end
	return room
end

function RaceRoomLogic.setReady(state, userId, ready)
	local room = state.RoomOf[userId]
	if not room or room.Phase ~= "Waiting" then
		return nil
	end
	room.Ready[userId] = ready and true or nil
	return room
end

-- every member ready, and enough of them
function RaceRoomLogic.canStart(room)
	if room.Phase ~= "Waiting" or #room.Members < C.MinPlayers then
		return false
	end
	for _, userId in ipairs(room.Members) do
		if not room.Ready[userId] then
			return false
		end
	end
	return true
end

-- the race is on / over (it waits again, nobody ready)
function RaceRoomLogic.start(room)
	room.Phase = "Racing"
end

function RaceRoomLogic.over(room)
	room.Phase = "Waiting"
	room.Ready = {}
end

-- the room list for the clients: { { Id, Host, Members = { userIds }, Ready = { userIds }, Phase, Kind, Ranked } }
function RaceRoomLogic.snapshot(state)
	local list = {}
	for _, room in pairs(state.Rooms) do
		local ready = {}
		for _, userId in ipairs(room.Members) do
			if room.Ready[userId] then
				table.insert(ready, userId)
			end
		end
		table.insert(list, { Id = room.Id, Host = room.Host, Members = table.clone(room.Members), Ready = ready,
			Phase = room.Phase, Kind = room.Kind, Ranked = room.Ranked, Stake = room.Stake })
	end
	table.sort(list, function(a, b)
		return a.Id < b.Id
	end)
	return list
end

return RaceRoomLogic
